# Extract Provenance

Every file in this directory is a verbatim copy from the FROZEN baseline `IPBS-AUMNITY-SaaS-Tenant-Pilot_Claude_V006_20260809_0732.zip` (SHA-256 `37d5bcc93b5fa9948dce31a9d08e8ffb1a8ee9731b4798d8966f56a92403ce43`): the three PROPOSED ADRs, the cross-product dependency register, and the four open register rows (unresolved-rpr-extract.csv: RPR-003, RPR-006, RPR-017 UNRESOLVED; RPR-050 NEW-MODULE PROPOSED). They are inputs for convenience; on any doubt, the frozen ZIP is authoritative.
