# Intake Checklist — record before any reconciliation work

| # | Input | Filename | SHA-256 (recorded on receipt) | Attestation present | Review status |
|---|---|---|---|---|---|
| 1 | AUMNITY Work Platform SaaS (latest reviewed) | _(awaiting)_ | _(awaiting)_ | ☐ | ☐ |
| 2 | AUMNITY CGWO SaaS (latest reviewed) | _(awaiting)_ | _(awaiting)_ | ☐ | ☐ |
| 3 | UraiFlow SaaS (latest reviewed) | _(awaiting)_ | _(awaiting)_ | ☐ | ☐ |
| 4 | IPBS Tenant Pilot (FROZEN) | IPBS-AUMNITY-SaaS-Tenant-Pilot_Claude_V006_20260809_0732.zip | 37d5bcc93b5fa9948dce31a9d08e8ffb1a8ee9731b4798d8966f56a92403ce43 | ✅ | ACCEPTED & FROZEN |

Rules: hashes are recorded verbatim from the artifacts on receipt and re-verified before use; a product input that arrives without independent review is flagged, not silently trusted. Note (baseline analysis §7 discipline): what each hash proves is the identity of the received artifact — chain-of-custody to its own review record depends on that package's attestation.

Specific evidence each input must yield (from CROSS-PRODUCT-DEPENDENCIES.md):
- **CGWO package** → execution-session/plan/allocation boundary and whether trackers/timesheets are internal or external systems of record via bridges (X-01, decides RPR-017); planning-state vocabulary ownership (X-06); supervision/capacity model shape (informs RPR-011/018 contracts).
- **Work Platform package** → identity/ID primitives and audit primitive scope (X-02, X-03; decides RPR-003 split and RPR-006 attestation question); reference-data mechanism scope (X-06).
- **UraiFlow package** → actual proposal/commit contract: typed targets, schema versioning, validation/preview, idempotency, failure, authorization, tenant context (X-05; confirms or amends RPR-030/032 wording).
- **All three** → whether a Capability boundary already partially exists, and where gap-response (training/recruitment/backup) naturally sits (X-04; decides ADR-0002 and RPR-050).
