# Page 00002 — Cross-Product-Requirement-Reconciliation

**Project stream:** AT-P0006 successor work (per the 09/08/2026 07:45 acceptance review and 10:33 direction)
**This package:** V000 — INTAKE SCAFFOLD ONLY. It contains structure and frozen-baseline extracts; it makes NO reconciliation decisions. Real work starts when the product inputs arrive.

## Purpose
Resolve the ownership questions the frozen IPBS discovery baseline deliberately left open, against the ACTUAL product architectures — never against convenience:
- **ADR-0002** — Capability ownership: skill/proficiency/verified-capability vs training/recruitment/backup response.
- **ADR-0003** — Timesheet/consolidation/approval/billing/bridge ownership.
- **ADR-0004** — Global identity/reference primitives vs bounded-context referential integrity.
- **X-01…X-06** — all cross-product dependencies.
- The **4 open register entries**: RPR-003, RPR-006, RPR-017 (UNRESOLVED) and RPR-050 (NEW-MODULE PROPOSED).

## Standing rules (inherited, non-negotiable)
1. The IPBS baseline is FROZEN at Claude V006 `37d5bcc93b5fa9948dce31a9d08e8ffb1a8ee9731b4798d8966f56a92403ce43`. It is an INPUT here. It is never modified.
2. Reconciliation outcomes are decisions and mappings — **not IPBS product code, and not edits to the frozen baseline**. Product work discovered here goes into the next release of the owning product (CGWO work → CGWO, UraiFlow work → UraiFlow, Platform work → Platform).
3. Decisions are made where the architecture lives: a boundary is decided by reading the owning product's actual package, not by what the tenant workbook happened to store together.
4. Register advancement happens through the V006 lifecycle machinery (events, BACKLOG references, provenance, registry) — in a post-freeze register continuation, only after decisions are ACCEPTED.

## End-to-end flow position
Discovery V006 ✅ → **[THIS PAGE] Cross-product reconciliation** → Product implementation → IPBS configuration → Real tenant testing → Evidence/acceptance → VALIDATED

## Required inputs (see 10-inputs/INTAKE-CHECKLIST.md)
Latest accepted/reviewed ZIPs + attestations for: AUMNITY Work Platform SaaS · AUMNITY CGWO SaaS · UraiFlow SaaS. The frozen IPBS V006 ZIP as the fourth input.
