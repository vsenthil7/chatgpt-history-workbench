# Reconciliation Decision Protocol

For every REC item, a decision requires, in order:
1. **Evidence citation from the owning product package(s)** — exact file/section references from the intake ZIPs (their hashes recorded in the checklist). A decision without product-package evidence is invalid; the tenant workbook alone is never sufficient.
2. **Decision statement** naming owner, contract/boundary, and rationale — recorded in the decision column and a dated decision note.
3. **Instrument update** — accept/amend/reject the gating ADR (ADR-0002/0003/0004). Amendments happen as reconciliation-page records + owning-product ADRs; the frozen baseline's ADR files are never edited. If the decision differs from the baseline ADR's proposal, the record states the delta explicitly.
4. **Product action** — a backlog entry in the owning product's next release (BACKLOG:<product>:<id> in that product's own tracker), never IPBS code.
5. **Register consequence** — recorded here for later application in the post-freeze register continuation: which RPR moves to CLASSIFIED (owner decided) or PROMOTED (backlog accepted), with the lifecycle-event entries that the V006 machinery will require (legal predecessors, evidence tokens).

Status vocabulary: AWAITING-INPUTS → EVIDENCE-GATHERED → DECIDED → INSTRUMENT-UPDATED → PRODUCT-ACTIONED.
Conflicts between product packages are recorded as explicit conflict items, escalated to the human/product owners — never resolved by this page's own preference.
