#!/usr/bin/env python3
"""V003 negative-test suite: 16 deliberate violations, each expected to FAIL validation.
R* = register/lifecycle tests (validate_register.py); M* = integrity tests (validate_manifest.py)."""
import csv, os, shutil, subprocess, sys
from pathlib import Path
SRC = Path(sys.argv[1]).resolve()
ENV = dict(os.environ, BUILD_TIMESTAMP='2026-08-08T23:09:00+01:00')
CSVP = '12-requirements/promotion-register.csv'

def mutate_csv(root, rid, **changes):
    p = root / CSVP
    with p.open(encoding='utf-8') as f:
        reader = csv.DictReader(f); fields = reader.fieldnames; rows = list(reader)
    for r in rows:
        if r['id'] == rid: r.update(changes)
    with p.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)

IMPL_OK = dict(implementation_product='AUMNITY-CGWO-SaaS', implementation_version='v1.2.0',
               implementation_contract_version='cgwo.execution.v3',
               implementation_evidence='FILE:11-analysis/workbook-inventory.json')

register_tests = [
 ('R1  ADR-gated RPR marked CLASSIFIED (ADR PROPOSED)',
  lambda rt: mutate_csv(rt, 'RPR-006', owner='PLATFORM', decision_scope='', candidate_owners='', status='CLASSIFIED')),
 ('R2  gated RPR IMPLEMENTED while ADR-0003 PROPOSED',
  lambda rt: mutate_csv(rt, 'RPR-017', status='IMPLEMENTED', **IMPL_OK)),
 ('R3  gated RPR VALIDATED while ADR-0002 PROPOSED',
  lambda rt: mutate_csv(rt, 'RPR-050', status='VALIDATED', **IMPL_OK)),
 ('R4  IMPLEMENTED without implementation fields',
  lambda rt: mutate_csv(rt, 'RPR-020', status='IMPLEMENTED')),
 ('R5  implementation_product references the pilot itself',
  lambda rt: mutate_csv(rt, 'RPR-020', status='IMPLEMENTED', **{**IMPL_OK, 'implementation_product': 'IPBS-Tenant-Pilot'})),
 ('R6  implementation fields populated at CLASSIFIED',
  lambda rt: mutate_csv(rt, 'RPR-001', implementation_version='v1.0.0')),
 ('R7  VALIDATED without the four tenant evidence classes',
  lambda rt: mutate_csv(rt, 'RPR-020', status='VALIDATED', **IMPL_OK)),
 ('R8  WB evidence cites nonexistent column',
  lambda rt: mutate_csv(rt, 'RPR-013', validation_evidence='WB:04_Weekly_Plan:No_Such_Column')),
 ('R9  FORMULA flag on non-formula column',
  lambda rt: mutate_csv(rt, 'RPR-013', validation_evidence='WB:04_Weekly_Plan:Sequence:FORMULA')),
 ('R10 FILE evidence cites valid basename but wrong exact path',
  lambda rt: mutate_csv(rt, 'RPR-021', validation_evidence='F:F-06; FILE:13-evidence/workbook-inventory.json')),
 ('R11 UNRESOLVED without candidate_owners',
  lambda rt: mutate_csv(rt, 'RPR-003', candidate_owners='')),
 ('R12 narrative owner count drift',
  lambda rt: (rt / '12-requirements/REQUIREMENT-PROMOTION-REGISTER.md').write_text(
      (rt / '12-requirements/REQUIREMENT-PROMOTION-REGISTER.md').read_text().replace('| PLATFORM | 6 |', '| PLATFORM | 7 |'))),
 ('R13 workbook DV-count drift in analysis',
  lambda rt: (rt / '11-analysis/BASELINE-ANALYSIS.md').write_text(
      (rt / '11-analysis/BASELINE-ANALYSIS.md').read_text().replace('**22** DataValidation objects', '**27** DataValidation objects'))),
]
integrity_tests = [
 ('M1  corrupted payload file (analysis doc)', '11-analysis/BASELINE-ANALYSIS.md', 'corrupt'),
 ('M2  corrupted EVIDENCE file (validate_register transcript) — the V002 hole', '13-evidence/validate_register.txt', 'corrupt'),
 ('M3  unexpected file added under 13-evidence/', '13-evidence/injected.txt', 'add'),
]

results, all_ok = [], True
for name, mutate in register_tests:
    tmp = Path('/tmp/negtest'); shutil.rmtree(tmp, ignore_errors=True); shutil.copytree(SRC, tmp)
    mutate(tmp)
    r = subprocess.run([sys.executable, str(tmp / 'scripts/validate_register.py')], capture_output=True, text=True)
    ok = r.returncode != 0
    first = next((l.strip() for l in r.stdout.splitlines() if l.startswith(' -')), '(no message)')
    results.append((name, ok, first)); all_ok &= ok

for name, target, mode in integrity_tests:
    tmp = Path('/tmp/negtest'); shutil.rmtree(tmp, ignore_errors=True); shutil.copytree(SRC, tmp)
    subprocess.run([sys.executable, str(tmp / 'scripts/generate_manifest.py')], env=ENV, capture_output=True)
    tp = tmp / target
    if mode == 'corrupt': tp.write_bytes(tp.read_bytes() + b'X')
    else: tp.write_text('injected after manifest\n')
    r = subprocess.run([sys.executable, str(tmp / 'scripts/validate_manifest.py')], capture_output=True, text=True)
    ok = r.returncode != 0
    first = next((l.strip() for l in r.stdout.splitlines() if l.startswith(' -')), '(no message)')
    results.append((name, ok, first)); all_ok &= ok

shutil.rmtree('/tmp/negtest', ignore_errors=True)
for name, ok, msg in results:
    print(f"[{'DETECTED' if ok else 'MISSED  '}] {name}: {msg}")
n_ok = sum(1 for _, ok, _ in results if ok)
print(f'NEGATIVE TESTS: {n_ok}/{len(results)} DETECTED' + ('' if all_ok else ' — VALIDATORS INSUFFICIENT'))
sys.exit(0 if all_ok else 1)
