#!/usr/bin/env python3
"""G10 register/document consistency validation, V003 schema v2 (ADR-0006).
Maturity-aware: the lifecycle can advance to IMPLEMENTED/VALIDATED when external
evidence exists; nothing hard-codes today's discovery stage as permanent.

Check groups:
 1. CSV structure: schema-v2 columns, unique well-formed IDs, required text fields.
 2. Vocabulary: owner/status/classification values.
 3. Ownership model: class↔owner map for owned rows; UNRESOLVED rows require
    decision_scope=CROSS-PRODUCT + valid candidate_owners + status PROPOSED +
    ADR/DEP reference; owned rows must have empty decision_scope/candidates;
    NEW-MODULE requires class 5 and PROPOSED/PROMOTED.
 4. Implementation traceability: the four implementation_* fields empty below
    IMPLEMENTED; at IMPLEMENTED/VALIDATED all four populated, product in the
    EXTERNAL product registry (pilot self-reference rejected), version/contract
    format-checked, implementation_evidence structured.
 5. Lifecycle & ADR↔RPR matrix: ADR PROPOSED ⇒ gated RPR ≤ PROPOSED (IMPLEMENTED/
    VALIDATED explicitly illegal); ACCEPTED ⇒ forward states allowed; REJECTED ⇒
    gated reference illegal until re-pointed; SUPERSEDED ⇒ RPR must cite successor.
    PROMOTED additionally requires a BACKLOG: reference.
 6. VALIDATED prerequisites: ACCEPTANCE/USAGE/FINDINGS/CONTRACT-TEST references
    each resolving to an existing file under 13-evidence/.
 7. Structured evidence resolution (basename matching abolished): WB sheet/column/
    FORMULA against workbook-inventory.json; F: against analysis findings; ADR:
    against ADR files; DEP: against CROSS-PRODUCT-DEPENDENCIES.md; FILE: exact path.
 8. Narrative consistency: total, owner counts, status counts, PROPOSED ID set,
    product-ownership analytics line (UNRESOLVED never counted as a product).
 9. RTM entry-count string.
10. Workbook counters: analysis quotes match machine inventory (sheets, DV objects,
    formula cells, transaction_data_rows and the named non-transaction counters).
PASS covers exactly these checks, nothing broader.
"""
from pathlib import Path
import csv, json, re, sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

OWNERS = {'PLATFORM', 'CGWO', 'URAIFLOW', 'TENANT-IPBS', 'NEW-MODULE', 'UNRESOLVED'}
STATUS_ORDER = ['OBSERVED', 'CLASSIFIED', 'PROPOSED', 'PROMOTED', 'IMPLEMENTED', 'VALIDATED']
CLASS_OWNER = {'1': 'PLATFORM', '2': 'CGWO', '3': 'URAIFLOW', '4': 'TENANT-IPBS', '5': 'NEW-MODULE'}
CANDIDATE_TOKENS = OWNERS - {'UNRESOLVED'} | {'EXTERNAL-SOR', 'PER-CONTEXT'}
EXTERNAL_PRODUCTS = {'AUMNITY-Work-Platform-SaaS', 'AUMNITY-CGWO-SaaS', 'UraiFlow-SaaS'}
SCHEMA = ['id', 'ipbs_observation', 'generic_requirement', 'classification', 'owner',
          'decision_scope', 'candidate_owners', 'status', 'implementation_product',
          'implementation_version', 'implementation_contract_version',
          'implementation_evidence', 'validation_evidence']
IMPL_FIELDS = SCHEMA[8:12]

# --- load ---------------------------------------------------------------------
with (ROOT / '12-requirements/promotion-register.csv').open(encoding='utf-8') as f:
    reader = csv.DictReader(f)
    if reader.fieldnames != SCHEMA:
        print('REGISTER/DOCS CONSISTENCY: FAIL\n - CSV columns do not match schema v2'); sys.exit(1)
    rows = list(reader)
md = (ROOT / '12-requirements/REQUIREMENT-PROMOTION-REGISTER.md').read_text(encoding='utf-8')
analysis = (ROOT / '11-analysis/BASELINE-ANALYSIS.md').read_text(encoding='utf-8')
rtm = (ROOT / '06-traceability/RTM.md').read_text(encoding='utf-8')
deps = (ROOT / '12-requirements/CROSS-PRODUCT-DEPENDENCIES.md').read_text(encoding='utf-8')
inv = json.loads((ROOT / '11-analysis/workbook-inventory.json').read_text(encoding='utf-8'))
sheets = {s['name']: s for s in inv['sheets']}
findings = set(re.findall(r'\| \**\s*(F-\d{2})\**', analysis))
dep_ids = set(re.findall(r'\| (X-\d{2}) \|', deps))
adr_files = {}
for p in (ROOT / '02-architecture/ADR').glob('ADR-*.md'):
    adr_id = '-'.join(p.stem.split('-')[:2])
    text = p.read_text(encoding='utf-8')
    sm = re.findall(r'\*\*Status:\*\* (\w+)', text)
    gates = set()
    for line in re.findall(r'^Gates: (.+)$', text, re.M):
        gates |= {g.strip() for g in line.split(',')}
    succ = re.search(r'^Superseded-by: (ADR-\d{4})$', text, re.M)
    adr_files[adr_id] = {'status': sm[-1] if sm else 'UNKNOWN', 'gates': gates,
                         'successor': succ.group(1) if succ else None}

def sidx(s): return STATUS_ORDER.index(s) if s in STATUS_ORDER else -1

def resolve_ref(rid, ref, allow_lifecycle=False):
    ref = ref.strip()
    if not ref: return
    parts = ref.split(':')
    kind = parts[0]
    if kind == 'WB':
        if len(parts) < 2 or parts[1] not in sheets:
            errors.append(f'{rid}: WB ref unknown sheet: {ref}'); return
        sh = sheets[parts[1]]
        if len(parts) >= 3:
            col = parts[2]
            if col not in sh['headers']:
                errors.append(f'{rid}: WB ref unknown column: {ref}'); return
            if len(parts) == 4:
                if parts[3] != 'FORMULA':
                    errors.append(f'{rid}: WB ref bad flag: {ref}')
                elif col not in sh['preseeded_formula_cells_by_column']:
                    errors.append(f'{rid}: FORMULA flag on non-formula column: {ref}')
    elif kind == 'F':
        if len(parts) != 2 or parts[1] not in findings:
            errors.append(f'{rid}: unknown finding ref: {ref}')
    elif kind == 'ADR':
        if len(parts) != 2 or parts[1] not in adr_files:
            errors.append(f'{rid}: unknown ADR ref: {ref}')
    elif kind == 'DEP':
        if len(parts) != 2 or parts[1] not in dep_ids:
            errors.append(f'{rid}: unknown dependency ref: {ref}')
    elif kind == 'FILE':
        path = ref[len('FILE:'):]
        if not (ROOT / path).is_file():
            errors.append(f'{rid}: FILE ref does not resolve to exact path: {ref}')
    elif kind in {'BACKLOG', 'ACCEPTANCE', 'USAGE', 'FINDINGS', 'CONTRACT-TEST'}:
        if not allow_lifecycle:
            errors.append(f'{rid}: lifecycle token {kind}: not permitted at this status')
        elif kind != 'BACKLOG':
            sub = ref[len(kind) + 1:]
            if not sub.startswith('FILE:13-evidence/') or not (ROOT / sub[len('FILE:'):]).is_file():
                errors.append(f'{rid}: {kind} evidence must be FILE:13-evidence/<existing>: {ref}')
    else:
        errors.append(f'{rid}: unstructured evidence reference: {ref}')

# --- per-row checks -----------------------------------------------------------
ids = [r['id'] for r in rows]
if len(ids) != len(set(ids)): errors.append('duplicate register IDs')
by_owner, by_status, proposed_ids = {}, {}, []
for r in rows:
    rid = r['id']
    if not re.fullmatch(r'RPR-\d{3}', rid): errors.append(f'{rid}: malformed ID')
    for field in ('ipbs_observation', 'generic_requirement', 'validation_evidence'):
        if not r[field].strip(): errors.append(f'{rid}: empty {field}')
    if r['owner'] not in OWNERS: errors.append(f"{rid}: invalid owner {r['owner']}")
    if r['status'] not in STATUS_ORDER: errors.append(f"{rid}: invalid status {r['status']}")
    if r['classification'] not in CLASS_OWNER: errors.append(f"{rid}: invalid classification")
    st = r['status']

    # ownership model
    if r['owner'] == 'UNRESOLVED':
        if r['decision_scope'] != 'CROSS-PRODUCT':
            errors.append(f'{rid}: UNRESOLVED requires decision_scope=CROSS-PRODUCT')
        cands = [c for c in r['candidate_owners'].split('|') if c]
        if not cands or any(c not in CANDIDATE_TOKENS for c in cands):
            errors.append(f'{rid}: UNRESOLVED requires valid candidate_owners, got {r["candidate_owners"]!r}')
        if st != 'PROPOSED':
            errors.append(f'{rid}: UNRESOLVED requires status PROPOSED, is {st}')
        if not re.search(r'(ADR:ADR-\d{4}|DEP:X-\d{2})', r['validation_evidence']):
            errors.append(f'{rid}: UNRESOLVED requires ADR/DEP reference')
    else:
        if r['decision_scope'] or r['candidate_owners']:
            errors.append(f'{rid}: decision_scope/candidate_owners only valid for UNRESOLVED')
        if r['owner'] == 'NEW-MODULE':
            if r['classification'] != '5': errors.append(f'{rid}: NEW-MODULE requires class 5')
            if st not in {'PROPOSED', 'PROMOTED'}: errors.append(f'{rid}: NEW-MODULE requires PROPOSED/PROMOTED')
        elif CLASS_OWNER[r['classification']] != r['owner']:
            errors.append(f'{rid}: classification/owner mismatch')

    # implementation traceability (maturity-aware, external-only)
    impl_set = [f for f in IMPL_FIELDS if r[f].strip()]
    if sidx(st) < sidx('IMPLEMENTED'):
        if impl_set:
            errors.append(f'{rid}: implementation fields populated below IMPLEMENTED ({impl_set})')
    else:
        missing = [f for f in IMPL_FIELDS if not r[f].strip()]
        if missing:
            errors.append(f'{rid}: status {st} requires all implementation fields; missing {missing}')
        prod = r['implementation_product'].strip()
        if prod:
            if 'IPBS' in prod.upper() or 'PILOT' in prod.upper():
                errors.append(f'{rid}: implementation_product references the pilot itself ({prod}) — prohibited; implementation is external only')
            elif prod not in EXTERNAL_PRODUCTS:
                errors.append(f'{rid}: implementation_product not in external product registry: {prod}')
        if r['implementation_version'].strip() and not re.fullmatch(
                r'(v?\d+\.\d+\.\d+|[A-Za-z-]+_V\d{3}_\d{8}_\d{4})', r['implementation_version'].strip()):
            errors.append(f'{rid}: implementation_version format invalid')
        if r['implementation_contract_version'].strip() and not re.fullmatch(
                r'[a-z][\w.-]*\.v\d+', r['implementation_contract_version'].strip()):
            errors.append(f'{rid}: implementation_contract_version format invalid (expect e.g. cgwo.execution.v3)')
        for ref in r['implementation_evidence'].split(';'):
            resolve_ref(rid, ref, allow_lifecycle=True)

    # lifecycle prerequisites
    if st == 'PROMOTED' and 'BACKLOG:' not in (r['validation_evidence'] + r['implementation_evidence']):
        errors.append(f'{rid}: PROMOTED requires BACKLOG: reference')
    if st == 'VALIDATED':
        for cls in ('ACCEPTANCE', 'USAGE', 'FINDINGS', 'CONTRACT-TEST'):
            if f'{cls}:' not in r['validation_evidence']:
                errors.append(f'{rid}: VALIDATED missing {cls}: evidence class')

    # evidence resolution
    for ref in r['validation_evidence'].split(';'):
        resolve_ref(rid, ref, allow_lifecycle=(sidx(st) >= sidx('PROMOTED')))

    by_owner[r['owner']] = by_owner.get(r['owner'], 0) + 1
    by_status[st] = by_status.get(st, 0) + 1
    if st == 'PROPOSED': proposed_ids.append(rid)

# --- ADR↔RPR matrix -----------------------------------------------------------
row_by_id = {r['id']: r for r in rows}
for adr_id, info in adr_files.items():
    for rid in info['gates']:
        r = row_by_id.get(rid)
        if r is None:
            errors.append(f'{adr_id} gates unknown entry {rid}'); continue
        st, a_st = r['status'], info['status']
        if a_st == 'PROPOSED' and sidx(st) > sidx('PROPOSED'):
            errors.append(f'{rid}: status {st} illegal while gating {adr_id} is PROPOSED (max PROPOSED)')
        if a_st == 'PROPOSED' and st == 'CLASSIFIED':
            errors.append(f'{rid}: gated by {adr_id} (PROPOSED) but marked CLASSIFIED')
        if a_st == 'REJECTED':
            errors.append(f'{rid}: cites REJECTED {adr_id}; must re-point to a replacement decision first')
        if a_st == 'SUPERSEDED':
            succ = info['successor']
            if not succ or f'ADR:{succ}' not in r['validation_evidence']:
                errors.append(f'{rid}: gating {adr_id} SUPERSEDED; RPR must cite successor {succ or "(none declared)"}')

# --- narrative consistency ----------------------------------------------------
tm = re.search(r'\*\*Total\*\* \| \*\*(\d+)\*\*', md)
if not tm or int(tm.group(1)) != len(rows):
    errors.append(f'narrative total != CSV rows ({len(rows)})')
for owner, n in by_owner.items():
    label = re.escape(owner) + (r' \(proposed\)' if owner == 'NEW-MODULE' else '')
    if not re.search(rf'\| {label} \| {n} \|', md):
        errors.append(f'narrative owner count for {owner} != {n}')
for status, n in by_status.items():
    if not re.search(rf'\| {status} \| {n} \|', md):
        errors.append(f'narrative status count for {status} != {n}')
nm = re.search(r'PROPOSED entries: ([^.]+)\.', md)
if not nm or set(re.findall(r'RPR-\d{3}', nm.group(1))) != set(proposed_ids):
    errors.append('narrative PROPOSED set != CSV')
prod_owned = sum(n for o, n in by_owner.items() if o in {'PLATFORM', 'CGWO', 'URAIFLOW'})
expect = (f"{prod_owned} entries owned by SaaS products (PLATFORM {by_owner.get('PLATFORM',0)}, "
          f"CGWO {by_owner.get('CGWO',0)}, URAIFLOW {by_owner.get('URAIFLOW',0)}), "
          f"{by_owner.get('NEW-MODULE',0)} proposed new module, {by_owner.get('TENANT-IPBS',0)} tenant configuration, "
          f"{by_owner.get('UNRESOLVED',0)} unresolved")
if expect not in md:
    errors.append(f'narrative product-ownership analytics line missing/mismatched (expected: "{expect}")')

# --- RTM ----------------------------------------------------------------------
if f'({len(rows)} entries' not in rtm:
    errors.append(f'RTM entry-count string does not match CSV ({len(rows)})')

# --- workbook counters --------------------------------------------------------
t = inv['totals']
checks = [(f"**{t['dv_object_count']}** DataValidation objects", 'DV-object count'),
          (f"{t['sheet_count']} sheets", 'sheet count'),
          (f"transaction_data_rows={t['transaction_data_rows']}", 'transaction row counter'),
          (f"{t['instruction_rows']} instruction", 'instruction row counter'),
          (f"{t['reference_rows']} reference", 'reference row counter'),
          (f"{t['review_template_rows']} review-template", 'review-template row counter')]
for needle, label in checks:
    if needle not in analysis:
        errors.append(f'analysis missing machine-derived {label} ("{needle}")')
if str(t['preseeded_formula_cells']) not in analysis and f"{t['preseeded_formula_cells']:,}" not in analysis:
    errors.append('analysis formula-cell count missing')

if errors:
    print('REGISTER/DOCS CONSISTENCY: FAIL')
    for e in errors: print(' -', e)
    sys.exit(1)
print(f'REGISTER/DOCS CONSISTENCY: PASS — scope: 10 check groups (see docstring); {len(rows)} entries; owners '
      + ', '.join(f'{k}={v}' for k, v in sorted(by_owner.items()))
      + '; statuses ' + ', '.join(f'{k}={v}' for k, v in sorted(by_status.items()))
      + f'; product-owned={prod_owned}; ADR matrix enforced over {len(adr_files)} ADRs '
      f'({sum(len(a["gates"]) for a in adr_files.values())} gated refs); structured evidence fully resolved. '
      'PASS covers exactly the listed checks, nothing broader.')
