# ADR-0006 — Register schema v2: ownership resolution, external implementation traceability, lifecycle matrix, evidence scheme

**Status:** ACCEPTED · **Date:** 2026-08-08 (V003) · Scope: pilot register governance (within this package's own authority; no product boundary decided)

## Context
V002 review blockers/majors: (2) the validator's blanket implementation_version prohibition made the register's own IMPLEMENTED/VALIDATED states permanently unreachable, conflating "no product code in the pilot" with "no record of external implementation"; (4) ADR gating was not a full state machine; (5) `CROSS-PRODUCT` sat in the Owner field though it is a resolution state, not an owner; (9) evidence references were syntactic (basename/sheet existence only).

## Decision
1. **Owner field holds owners only.** Unresolved rows use `owner=UNRESOLVED` + `decision_scope=CROSS-PRODUCT` + `candidate_owners` (owner vocabulary ∪ {EXTERNAL-SOR, PER-CONTEXT}) + status PROPOSED. Product analytics exclude UNRESOLVED. V002's three CROSS-PRODUCT rows migrate losslessly.
2. **External implementation traceability fields** `implementation_product/version/contract_version/evidence`: populated only at IMPLEMENTED/VALIDATED; product must be a registered EXTERNAL SaaS artifact (AUMNITY-Work-Platform-SaaS, AUMNITY-CGWO-SaaS, UraiFlow-SaaS, approved new modules); any pilot self-reference is rejected. The permanent prohibition is on product code inside this repository — never on recording external releases.
3. **Maturity-aware lifecycle with machine prerequisites** per transition (see register narrative table) and an **ADR↔RPR matrix**: PROPOSED⇒gated RPR ≤ PROPOSED; ACCEPTED⇒forward states permitted; REJECTED⇒gated RPR must re-point before re-classification; SUPERSEDED⇒RPR must cite successor. VALIDATED is gated by evidence-file existence (ACCEPTANCE/USAGE/FINDINGS/CONTRACT-TEST + implementation fields), not by a hard-coded "impossible" rule.
4. **Structured evidence scheme** `WB:sheet[:column[:FORMULA]] / F: / ADR: / DEP: / FILE:exact-path / BACKLOG: / ACCEPTANCE: / USAGE: / FINDINGS: / CONTRACT-TEST:` — resolved against the machine workbook inventory, findings table, ADR files, dependency register and exact paths. Basename matching abolished.

All rules negative-tested (see 13-evidence/validator-negative-tests.txt).
