# Requirement Traceability Matrix — starter

| ID | Requirement | Owner | Enforcement | Evidence/Test | Status |
|---|---|---|---|---|---|
| ARC-001 | Product code remains within declared bounded ownership | Architecture | architecture guard | TBD | DECLARED |
| ARC-002 | Cross-product reuse occurs through published contracts, not copied logic | Architecture | review + dependency guard | TBD | DECLARED |
| SaaS-001 | Reusable product code is tenant-neutral | Platform/Product | tenant-leak guard + tests | TBD | DECLARED |
| SaaS-002 | Tenant/org context is explicit at protected boundaries | Platform/Product | authz/isolation tests | TBD | DECLARED |
| QA-001 | New executable packages meet line+branch coverage policy | Engineering | coverage gate | TBD | DECLARED |
| QA-002 | Critical domain/policy behavior is mutation tested | Engineering | mutation gate | TBD | DECLARED |
| QA-003 | Escaped defects receive regression tests | Engineering | review/CI | TBD | DECLARED |
| DOC-001 | Version, package, test-count and ADR references are consistency checked | Governance | docs gate | scripts/validate_starter.py | ACTIVE |
| AI-001 | Claude build → independent ChatGPT ZIP review loop is used for releases | Governance | release checklist | handoff evidence | ACTIVE |

## V001 additions — register discipline (Claude V001, 2026-08-08)

| ID | Requirement | Owner | Enforcement | Evidence/Test | Status |
|---|---|---|---|---|---|
| REG-001 | Every pilot-discovered requirement is classified via the five-way ownership rule before any implementation | Governance | Requirement Promotion Register + ADR gate | 12-requirements/promotion-register.csv (29 entries) | ACTIVE |
| REG-002 | Register narrative counts/IDs stay consistent with the machine-readable CSV | Governance | scripts/validate_register.py | 13-evidence/validate_register.txt | ACTIVE |
| REG-003 | No generic product implementation exists inside the pilot package | Architecture | package inspection (no src/ of product code) + independent review | 08-ai/HANDOFF-CLAUDE-V001.md | ACTIVE |
| REG-004 | Unclear ownership requires an ADR before code (placement test) | Architecture | ADR record | ADR-0002, ADR-0003 (PROPOSED) | ACTIVE |

Starter rows ARC/SaaS/QA remain DECLARED: they bind future product implementation, which has not begun. DOC-001 and AI-001 remain ACTIVE with V001 evidence in `13-evidence/`.

## V002 additions — review corrections (Claude V002, 2026-08-08)

| ID | Requirement | Owner | Enforcement | Evidence/Test | Status |
|---|---|---|---|---|---|
| REG-005 | Workbook facts quoted in documents are machine-derived and cross-checked, never manually asserted | Governance | derive_workbook_inventory.py + validate_register.py check 9 | 11-analysis/workbook-inventory.json; 13-evidence/validate_register.txt | ACTIVE |
| REG-006 | A gate may only be claimed at the level its validator actually proves; gate states use PASS/FAIL/PARTIAL/NOT-APPLICABLE/NOT-YET-IMPLEMENTED accurately | Governance | validator output = evidence; independent review | 08-ai/HANDOFF-CLAUDE-V002.md gate table | ACTIVE |
| REG-007 | Product-boundary decisions are never cemented by the pilot; unresolved ownership is tracked as CROSS-PRODUCT/PROPOSED with explicit external dependencies | Architecture | validate_register.py ADR-gating + CROSS-PRODUCT rules | 12-requirements/CROSS-PRODUCT-DEPENDENCIES.md | ACTIVE |
| REG-008 | Package integrity is validated against the manifest by a dedicated validator (inventory, bytes, SHA-256, duplicates, naming) | Governance | validate_manifest.py | 13-evidence/post-manifest/validate_manifest.txt | ACTIVE |
| REG-009 | Tenant-validation maturity is stated honestly; VALIDATED requires the defined evidence set; no fabricated tenant data | Governance | VALIDATION-EVIDENCE-CRITERIA.md + validator VALIDATED block | 12-requirements/VALIDATION-EVIDENCE-CRITERIA.md | ACTIVE |

## V003 additions — integrity/lifecycle corrections (Claude V003, 2026-08-08)

| ID | Requirement | Owner | Enforcement | Evidence/Test | Status |
|---|---|---|---|---|---|
| REG-010 | The internal manifest covers every packaged file with no excluded directories; manifest-dependent proofs live in the external release attestation (ADR-0005) | Governance | validate_manifest.py + attestation procedure | 13-evidence/validator-negative-tests.txt (M1–M3); external attestation | ACTIVE |
| REG-011 | The register lifecycle is maturity-aware: external implementation/validation is recordable (external products only, pilot self-reference rejected); no validator rule freezes today's discovery stage as permanent (ADR-0006) | Governance | validate_register.py groups 4–6 + negative tests | 13-evidence/validator-negative-tests.txt (R2–R7) | ACTIVE |
| REG-012 | Register evidence uses the structured reference scheme resolved to exact objects (sheets, columns, formulas, findings, ADRs, dependencies, exact paths) | Governance | validate_register.py group 7 + negative tests | 13-evidence/validator-negative-tests.txt (R8–R10) | ACTIVE |

Note: REG-008's V002 evidence path (13-evidence/post-manifest/validate_manifest.txt) is superseded by ADR-0005 — the post-manifest directory is abolished; manifest-validation evidence over the exact final payload now lives in the external release attestation.
