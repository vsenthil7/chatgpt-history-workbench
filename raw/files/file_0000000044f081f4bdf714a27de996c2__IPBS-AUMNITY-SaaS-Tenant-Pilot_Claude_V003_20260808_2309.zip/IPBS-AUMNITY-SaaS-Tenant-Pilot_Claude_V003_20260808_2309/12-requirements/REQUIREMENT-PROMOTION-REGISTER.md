# Requirement Promotion Register — V003 (schema v2)

**Source of truth:** `promotion-register.csv` (schema v2, ADR-0006). This narrative is cross-checked by `scripts/validate_register.py`; counts here are validated, never hand-maintained.

## Schema v2 (ADR-0006)

Columns: `id, ipbs_observation, generic_requirement, classification, owner, decision_scope, candidate_owners, status, implementation_product, implementation_version, implementation_contract_version, implementation_evidence, validation_evidence`.

**Owner** is an actual owner only: PLATFORM · CGWO · URAIFLOW · TENANT-IPBS · NEW-MODULE · **UNRESOLVED**. `UNRESOLVED` answers "have we decided?" (no), not "who owns it?" — it is never counted as a product. UNRESOLVED rows must carry `decision_scope=CROSS-PRODUCT`, non-empty `candidate_owners` (from the owner vocabulary plus the documented tokens `EXTERNAL-SOR` and `PER-CONTEXT`), status PROPOSED, and a gating ADR/dependency reference. Migration note: V002's `owner=CROSS-PRODUCT` rows (RPR-003/006/017) became `owner=UNRESOLVED, decision_scope=CROSS-PRODUCT` with candidates preserved — no history lost; V002 remains the record of the old encoding.

**Implementation traceability (external, future):** the pilot permanently prohibits generic product implementation code *inside this repository*, but must eventually record which EXTERNAL owning-product release implemented each promoted requirement. `implementation_product` must name a registered external SaaS artifact (AUMNITY-Work-Platform-SaaS, AUMNITY-CGWO-SaaS, UraiFlow-SaaS, or an approved new module) — never this pilot; the validator rejects any pilot self-reference. The four implementation fields may only be populated at status IMPLEMENTED/VALIDATED.

**Evidence references** are structured and machine-resolved (ADR-0006): `WB:<sheet>[:<column>[:FORMULA]]` · `F:F-nn` · `ADR:ADR-nnnn` · `DEP:X-nn` · `FILE:<exact path>` · and lifecycle tokens `BACKLOG:` (PROMOTED), `ACCEPTANCE:/USAGE:/FINDINGS:/CONTRACT-TEST:` + `FILE:` (VALIDATED, per VALIDATION-EVIDENCE-CRITERIA.md). Basename guessing is abolished; wrong path, wrong column or a FORMULA flag on a non-formula column fails validation (negative-tested).

## Lifecycle (maturity-aware, ADR-0006)

`OBSERVED → CLASSIFIED → PROPOSED → PROMOTED → IMPLEMENTED → VALIDATED`, machine-checked prerequisites:

| Transition to | Machine prerequisites |
|---|---|
| CLASSIFIED | owner ≠ UNRESOLVED; class↔owner map holds; not gated by a non-ACCEPTED ADR |
| PROPOSED | gating ADR exists (PROPOSED) and/or DEP reference; UNRESOLVED rows always here until decided |
| PROMOTED | every gating ADR ACCEPTED; `BACKLOG:` reference present |
| IMPLEMENTED | all four implementation fields populated; product is a registered EXTERNAL artifact; version/contract formats valid |
| VALIDATED | IMPLEMENTED prerequisites + all four evidence classes (`ACCEPTANCE/USAGE/FINDINGS/CONTRACT-TEST`) resolving to existing files under 13-evidence/ |

ADR↔RPR matrix: ADR PROPOSED ⇒ gated RPR ≤ PROPOSED · ACCEPTED ⇒ any forward state · REJECTED ⇒ gated RPR must be re-pointed (≤ CLASSIFIED only after re-classification away from the rejected ADR) · SUPERSEDED ⇒ RPR must cite the successor ADR. Illegal states are negative-tested. Today's inability to reach VALIDATED is a consequence of missing evidence files, not a hard-coded prohibition — the register can advance without validator changes.

## V003 position

| Owner | Entries |
|---|---|
| PLATFORM | 6 |
| CGWO | 11 |
| URAIFLOW | 4 |
| TENANT-IPBS | 4 |
| UNRESOLVED | 3 |
| NEW-MODULE (proposed) | 1 |
| **Total** | **29** |

| Status | Entries |
|---|---|
| CLASSIFIED | 25 |
| PROPOSED | 4 |

Product-ownership analytics (UNRESOLVED excluded by definition): 21 entries owned by SaaS products (PLATFORM 6, CGWO 11, URAIFLOW 4), 1 proposed new module, 4 tenant configuration, 3 unresolved.

PROPOSED entries: RPR-003 (ADR-0004), RPR-006 (ADR-0003), RPR-017 (ADR-0003), RPR-050 (ADR-0002). No implementation fields are populated anywhere: no external product release exists yet, and no product code exists — or may ever exist — inside this pilot.

## V003 content changes (beyond schema)

- **RPR-007 narrowed** (review point 8): Platform owns the audit *mechanism* (append-only, actor/tenant/timestamp, correlation, evidence integrity); owning domains keep audit *policy* (which actions need reasons, reason codes, transition rules) — same mechanism-vs-semantics discipline as RPR-008.
- **RPR-021 reworded** (review point 11): the absolute "no fixed record limits" replaced by the testable form — no dependence on spreadsheet-style hard-coded ranges; supported limits explicit, engineered, tenant-safe, capacity-tested.
- **RPR-050 records its own scope question** (review point 7): capability/profile concepts vs workforce-response concepts (training/recruitment/backup) may be different domains; see ADR-0002 addendum 2 and X-04.
