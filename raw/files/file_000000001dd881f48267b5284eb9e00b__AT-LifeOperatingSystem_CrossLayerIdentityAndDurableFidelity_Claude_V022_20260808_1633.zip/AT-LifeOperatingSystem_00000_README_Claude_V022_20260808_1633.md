# AT-Life Operating System (AT-LOS) - V022

**Release:** `AT-LifeOperatingSystem_CrossLayerIdentityAndDurableFidelity_Claude_V022_20260808_1633`
**Prepared by:** Claude · **08-Aug-2026 16:33 BST**

```
V022 — CrossLayerIdentityAndDurableFidelity

pytest                 365 passed, 1 skipped
coverage               1157 statements, 292 branches, 100% line and branch
architecture guards    52 collected
integration (real venv) 2 collected
mutation regression    19/19 killed
RTM                    94 passing + 1 skipped + 2 not enforced = 97
modules / products     11 declared, 2 product applications
test suites            17 built, 4 declared not built (3 internal, 1 external)
documentation          43 pages, 2 publication profiles
packages measured      at-cli, at-identity, at-ingest-core, at-ingest-llm-export, at-ingest-whatsapp, at-store
platform version       0.13.0

Facts measured: outcomes=True coverage=True
```

## 22 findings. Every one reproduced locally before it was touched.

No new capability. This release fixes what V019, V020 and V021 left open, and
adds guards so each specific regression fails the build.

## The one that mattered most

**AI role labels were becoming people.** Importing a Claude export recorded
`assistant` and `human` as unidentified humans awaiting a `PersonRef`.

`Participant` now carries **`ActorKind`** — HUMAN, MODEL, SYSTEM, UNKNOWN.
`at-identity` refuses anything that is not HUMAN, at `observe()` and at `link()`.
An unrecognised role is UNKNOWN, never assumed human.

**This is exactly what the second adapter was for.** WhatsApp gives display
names; AI exports give roles. A single-source platform could not have exposed it.

## Durable storage now stores the whole record

`attachments` and `meta` were dropped — so a WhatsApp attachment and an AI
export's `conversation_id` vanished on restart while the store reported success.
**Ninety-two contract tests passed** because none ever built a fully populated
Event. The suite now does, and asserts `restored == original`.

Also: `get_event()` and `iter_events()` on the port (V020's durability test
reached into a *private* method, so the store was effectively write-only);
`EventCollisionError` when the same id arrives with different content; and schema
version read **read-only before any write**, asserted byte-for-byte.

## Identity integrity

`link(person_id="Alice")` **created** that id — the linking API doubled as
unvalidated person creation, so "derived from nothing" was bypassable. A supplied
id must now already exist.

State and audit now commit **in one transaction**. Forcing the decision write to
fail leaves no identity behind. Plus: workspace validated on every operation,
attribution on merge/split/unlink, canonical merge comparison, JSON instead of
`~` (the valid name `A~B` was becoming two subjects), and 128-bit ids.

## LLM source fidelity

A differently-shaped later conversation vanished at 100% coverage · an explicit
wrong provider returned 0 events, 0 issues, 100% · structured content became
empty text, counted as consumed · a malformed `mapping` raised `AttributeError`.
All four fixed, all four guarded.

## Documents

Current files said durable storage was not built, two releases after it was.
RTM-84, RTM-85 and RTM-86 now fail the build on stale capability claims,
superseded test paths and broken documentation links. The acceptance report
describes **the workflow**, not the platform. And the release summary finally
reads *"4 declared not built (3 internal, 1 external)"*.

## Two things I am not claiming

**ChatGPT branch semantics** — the node graph is still flattened by timestamp,
so alternative answers read as sequential. Recorded as **DQ-015** and marked
Partial.

**External documentation publication** — still relies on mkdocs navigation, which
is not an exclusion mechanism. Marked Partial, open since V018.

I am not repeating "none partial". You were right that it was false.

## Next

Settle **DQ-015** before `at-evidence` interprets conversation structure —
durable events already exist, so changing ingestion semantics later means
re-ingesting. `at-consent` still needs **DQ-012 and DQ-013**.

**AT-056 remains Not started.**
