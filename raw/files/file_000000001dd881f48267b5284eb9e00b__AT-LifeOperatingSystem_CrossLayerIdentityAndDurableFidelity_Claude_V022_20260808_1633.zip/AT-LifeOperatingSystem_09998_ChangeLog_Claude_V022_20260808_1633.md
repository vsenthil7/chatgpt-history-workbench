# AT-LOS V022 Change Log

**Release type:** cross-layer integrity. ADR-022, amending ADR-013, 019, 020 and 021. **No new capability.**

## Verified

22 findings raised across V019, V020 and V021. All 22 reproduced locally, then fixed. None rejected.

## Core

`ActorKind` on `Participant` (HUMAN / MODEL / SYSTEM / UNKNOWN). Only HUMAN actors are identity-eligible.

## at-store

Full `Event` fidelity: `attachments`, `meta` and `actor_kind` persisted · `get_event()` and `iter_events()` on `EventRepository` · `EventCollisionError` for the same id with different content · schema version read read-only before any write · contract suite builds a fully populated Event and asserts exact equality.

## at-identity

Supplied `person_id` must already exist · state and decision in one transaction · workspace validated on every operation · attribution required on merge, split and unlink · canonical comparison on merge · JSON decision serialisation · 128-bit person ids · non-human actors refused.

## at-ingest-llm-export

Every conversation validated against the chosen provider · explicit provider asserts rather than bypasses · structured content reported instead of silently emptied · malformed `mapping` fails controllably · issue reasons carry the detail.

## Documents and gates

RTM-84 to RTM-97 (14 new rules) · `docs/testing/internal/07-manual-testing.md` written · superseded test paths removed · stale capability claims reconciled · acceptance report describes the workflow · release summary suite classification corrected · workbook `00_Index` and `10_DerivedFacts` regenerated from `release_facts.json`.

19 mutation cases, including three for the V019/V020/V021 blockers.

## Decisions

D-083 ActorKind · D-084 whole-record durability and retrieval · D-085 atomic state and audit · D-086 a safety check must not modify what it protects · D-087 coverage counts from raw source units

## Open, and stated

**DQ-015** ChatGPT branch semantics (Partial) · external documentation publication boundary (Partial, open since V018) · DQ-004, DQ-012, DQ-013, DQ-014 · **AT-056 Not started**.
