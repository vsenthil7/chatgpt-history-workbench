# AT-Life Operating System (AT-LOS) - V027

**Release:** `AT-LifeOperatingSystem_ProviderSourceUnitAndAuthorityClosure_Claude_V027_20260809_1130`
**Prepared by:** Claude · **09-Aug-2026 11:30 BST** · Corrective only — no feature tranche, **no `at-evidence` code**.

## Gates — deterministic and environment-dependent stated separately (F11)

```
DETERMINISTIC (reproducible from the pristine repo zip, no network):
  deterministic suite              434 collected: 433 passed, 1 skipped by
                                   design (a guard that activates when product
                                   apps gain code - "no apps yet")
  coverage                         1336 statements, 378 branches, 100% line and branch
  architecture guards              54 collected (part of the above)
  mutation regression              31/31 killed (3 new mutants re-create F01-F03)
  ruff                             clean
  release_check + package audit    0 failures (incl. hygiene, semantic-version,
                                   hand-typed-count and outer-Markdown gates)

ENVIRONMENT-DEPENDENT (declared, never folded into a universal claim):
  integration/bootstrap tests      2 collected; they build a real venv and may
                                   SKIP where the environment forbids it
  Reference build environment      436 collected: 435 passed, 1 skipped
                                   (both integration tests ran)
  Your V026 environment observed   423/2 - the same deterministic core plus one
                                   environment-dependent integration skip. That
                                   is expected; the deterministic figures above
                                   are the package claim, the aggregate is not.

RTM   119 passing + 1 skipped + 3 not enforced = 123
packages 0.18.0 · 11 modules declared · ADR-001..027
```

## The central defect was real: "source unit" was under-defined

You were right that F01-F03 share one root cause. ADR-027 now defines the unit table you required, and the implementation follows it:

| Provider | Fidelity source unit | Unit locator |
|---|---|---|
| WhatsApp | candidate source line(s) | line / range (unchanged) |
| ChatGPT | message-bearing graph node | `conversation:{id}#node:{node_id}` |
| Claude | message | `conversation:{id}#message:{index}` |
| Perplexity | **query side and answer side independently** | `…#entry:{i}#query` / `…#entry:{i}#answer` |

**F01 — CLOSED.** `candidate_units` counts distinct provider-native units: consumed + rejected, nothing else. Container diagnostics (cycles, dangling parents, broken `current_node`) are issues that count **no** unit. Your inflation case re-run: a graph with 3 message nodes, a cycle and a dangling parent now reports `candidate 3, consumed 3, coverage 1.0` with 2 diagnostic issues — V026 reported `candidate 5, coverage 0.6`. Adversarial tests prove one unit with multiple issues counts once, a diagnosed-but-consumed unit counts once, and **candidate can never exceed native units** (RTM-121). The RTM-116 equality that was "partly true by construction" is gone; the invariant asserted now is representation, not a manufactured sum.

**F02 — CLOSED.** Your exact input — `query: "valid question"` beside a structured answer — now yields:

```
events=1  ("valid question", locator conversation:u#entry:0#query)
issues=1  (locator conversation:u#entry:0#answer, raw {"text": "structured answer"})
candidate=2, consumed=1, coverage=0.5
```

Sides fail independently in both directions; an absent or empty side is not a unit; an entry with neither side is one rejected unit (RTM-122).

**F03 — CLOSED.** Your `author: "BAD"` case now produces locator `conversation:c1#node:n1#message.author` with `raw` `"BAD"` — the offending value as bounded canonical JSON, produced at the point of failure, for every rejection class across ChatGPT and Claude (message, author, role, content, parts, sender, text). A cycle diagnostic carries the looping parent chain. `str(sorted(conv))[:200]` is deleted, and a mutant restoring it is killed (RTM-123). Consequence stated plainly: ChatGPT event locators moved from flat message indexes to node ids, so pre-existing ChatGPT event ids change — acceptable only because nothing downstream holds them yet, and recorded in ADR-027.

**F04 — split as you specified.** RTM-62 now claims navigation separation only (its test's own docstring corrected too — it restated the false rule). **RTM-120** "external build output contains no internal page" is **NOT ENFORCED**, and stays so until a real mechanism (separate `docs_dir`, exclude plugin, or output check) and a built-output test exist. `07_NonFunctional` carries both rows. DQ-016 open; nothing is published.

## Governance: the gates that let F05-F09/F12 ship are themselves fixed

- **F07** — the `("V010","V011","V012")` blacklist is deleted. The gate derives the current release and fails **any** older version presented as current in a current-state sheet. It caught test edits of mine during this build before the final package passed.
- **F05/F06** — the V025 "CURRENT COUNT" block is demoted to a historical snapshot recording how it shipped; the V027 CURRENT COUNT is written from `release_facts.json`. The Standard's rule 20 now names exactly which sheets are generated from which machine sources instead of the false blanket "both derived from code".
- **F08** — the remaining-modules list is generated from `architecture.toml`: `at-commitments, at-consent, at-evidence, at-questions, at-timeline`. "workspace/observe" named modules that do not exist in the manifest.
- **F09** — "5 blocking jobs" and "thirteen mutants" removed; prose references the FACTS block, and release_check check 13 fails any hand-typed count disagreeing with derived facts.
- **F10** — TEST_STRATEGY now states per-source-unit coverage (`.line_coverage` deliberately raises for LLM exports, ADR-019) and carries the verification table: WhatsApp real-export verified; ChatGPT/Claude/Perplexity synthetic-fixture verified; **real LLM export corpus: not yet verified — a named gap**.
- **F12** — the repo zip is rebuilt clean, and release_check gate 2d opens every shipped archive and fails on `.ruff_cache/`, `.pytest_cache/`, `__pycache__/`, `*.pyc`, `.coverage`, `htmlcov/`, `build/`, `dist/`, `*.egg-info`, `.idea/`, `.vscode/`, `.DS_Store`, `Thumbs.db`.
- **F13** — the Standard's hand-maintained "today is 07-Aug-2026" is replaced with the release-metadata date.

Decisions D-105–D-108, ADR-027, RTM-121–123 (+RTM-120), 10 new adversarial tests, 3 new mutants. The full F01–F13 disposition table with exact test/RTM/ADR references is sheet `20_V027ReAuditDisposition` in the Test Strategy workbook and in the metadata.

## What this release claims, exactly

The provider-native source-unit contract (ADR-027) holds for ChatGPT, Claude and Perplexity **against the synthetic adversarial fixture classes now in the suite** — malformed nested shapes, multi-issue units, valid-beside-malformed siblings, structured-only units, graph diagnostics, locator/raw provenance — and for WhatsApp against a real 500-event export. **Provider-neutral fidelity is not declared closed**: a real export corpus for the three LLM providers remains a separately named gap in `known_gaps`, and `at-evidence` starts only after your independent V027 review.

## Verification of this package

Filename, SHA-256, file counts, clean-extraction results and all gate figures are in the Metadata JSON; every artefact hash is in the Manifest CSV. The repo zip was extracted pristine and re-run before packaging; the manifest was recomputed independently after assembly.

## Next

Your V027 review. Then `at-evidence`. `at-consent` still needs **DQ-012 and DQ-013** from you. **AT-056 remains Not started.**
