# AT-LOS V027 Change Log

**Release type:** provider-native source-unit semantics and authority closure. ADR-027, amending ADR-026, ADR-019 and ADR-007. Corrective only, responding to the V026 independent enterprise re-audit (F01–F13). No feature tranche, no `at-evidence` code.

## at-ingest-llm-export (F01–F03)

**Unit accounting rebuilt (F01).** Extraction now returns messages, rejected units and container diagnostics **separately**. `candidate_units` = distinct provider-native units (consumed + rejected); a unit with several problems counts once; a cycle, dangling parent or broken `current_node` is a diagnostic issue that counts **no** unit, so the candidate count can never exceed the units actually in the source and coverage measures the source, not the diagnostics. The manufactured RTM-116 equality is gone — the asserted invariant is representation.

**Perplexity sides are independent units (F02).** The unit table (ADR-027): message-bearing node (ChatGPT), message (Claude), query side and answer side independently (Perplexity). A valid query survives its malformed answer and vice versa; an absent/empty side is not a unit; an entry with neither is one rejected unit.

**Rejection provenance (F03).** Every rejection carries `conversation:{id}#node:{id}#message.author`-style locators and the offending value as bounded canonical JSON, built at the point of failure. Cycle diagnostics carry the looping parent chain. Event locators use provider-native unit references (ChatGPT: node ids — pre-existing ChatGPT event ids change; recorded acceptable pre-evidence in ADR-027).

## RTM and guards

RTM-62 narrowed to **navigation** separation, its test docstring corrected (it restated the false rule). **RTM-120** build-output exclusion **NOT ENFORCED** (F04, DQ-016). RTM-121 (candidate counts units), RTM-122 (no valid sibling discarded), RTM-123 (locator/field/value provenance). 123 rules: 119 + 1 + 3. Ten new adversarial tests; 435 passing, 100% on 1336 statements / 378 branches; **31/31 mutants** including three that re-create F01–F03.

## Release gates (F07, F09, F12)

`release_check`: **semantic stale-version gate** — derives the current release and fails any older version presented as current in a current-state sheet (replaces the V010–V012 blacklist that let a V025 "CURRENT COUNT" ship inside V026); **check 13** fails hand-typed counts that disagree with derived facts; **gate 2d** opens every shipped zip and fails on `.ruff_cache`/`.pytest_cache`/`__pycache__`/`.pyc`/`.coverage`/`htmlcov`/`build`/`dist`/`.egg-info`/editor state. The repo zip ships clean.

## Documents and workbooks (F05, F06, F08, F09, F10, F13)

Project Memory: index → V027; the V025 CURRENT COUNT demoted to a historical snapshot recording how it shipped; **V027 CURRENT COUNT written from `release_facts.json`**; remaining-modules lists generated from `architecture.toml` (`at-commitments, at-consent, at-evidence, at-questions, at-timeline` — "workspace/observe" named modules that do not exist). Test Strategy workbook: derived sheets regenerated; `07_NonFunctional` split into NAV (Implemented) and BUILD OUTPUT (NOT ENFORCED); new `20_V027ReAuditDisposition` sheet with the full F01–F13 table. `docs/TEST_STRATEGY.md`: hand-typed "5 blocking jobs"/"thirteen mutants" removed in favour of the FACTS block; per-source-unit coverage wording; §4b verification table separating WhatsApp real-export verification from synthetic-fixture LLM verification. Standard: rule 20 names generated vs authored surfaces; "today is 07-Aug-2026" replaced with the release-metadata date; nine V027 rules added.

## Reporting (F11)

Metadata separates `gates_deterministic` (the package claims: 434 collected, 433 passed, 1 by-design skip, coverage, mutation, RTM, lint, release_check) from `gates_environment_dependent` (2 integration tests that may skip; the reference environment's 435/1 aggregate is declared as that environment's result, not a universal fact — the review's 423/2 is consistent).

## Decisions

D-105 provider-native units, counted once, siblings independent · D-106 rejection provenance · D-107 semantic gates: no blacklists, no hand-typed counts, no cache in the package, claims never exceed tests · D-108 deterministic vs environment-dependent reporting

## Open

DQ-004, DQ-012, DQ-013, DQ-014, **DQ-016 (RTM-120 NOT ENFORCED — no external publication)** · real LLM export corpus not yet verified (named gap) · `at-evidence` after independent V027 review · **AT-056 Not started**.
