"""Immutable lineage/audit events — the cross-aggregate evidence chain.

Linkage contract (ADR-0008): aggregates are linked by id references inside event
payloads (e.g. ``proposal.created`` carries ``capture_id`` and ``transcript_id``);
this payload-reference model is canonical and test-enforced.
"""
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass(frozen=True)
class LineageEvent:
    """One append-only fact about a subject, scoped to a tenant."""

    event_id: str
    tenant_id: str
    subject_id: str
    kind: str
    payload: Mapping[str, Any]
    occurred_at: datetime
