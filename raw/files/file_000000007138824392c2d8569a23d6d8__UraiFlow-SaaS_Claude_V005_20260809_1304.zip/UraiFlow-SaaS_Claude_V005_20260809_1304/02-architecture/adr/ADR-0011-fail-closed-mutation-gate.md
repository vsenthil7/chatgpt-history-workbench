# ADR-0011 — Fail-closed mutation gate (G07)

Status: ACCEPTED (V004) · Drives: P0-3 of the V003 independent review

## Context
The V003 gate had fail-open paths: the `mutmut run` exit code was ignored, an
unparseable mutant tally fell back to a hard-coded total (241), and survivors
whose patch could not be applied (`apply-failed`) were silently ignored. A
broken tool run could therefore report PASS.

## Decision
G07 PASSES only when **every discovered mutant has a machine-derived terminal
disposition**:
1. `killed` — killed by mutmut during the run;
2. `killed-on-verify` — reported survived but independently applying the mutant
   makes the full suite fail;
3. `equivalent-annotation` — provably runtime-equivalent PEP 526 function-body
   annotation mutants (governed class, §3);
4. `accepted-literal` — string-literal ("XX") message/docstring mutants that
   cannot change behaviour (governed class, §3; each listed in evidence).

Everything else fails the gate, explicitly including: mutation-tool execution
failure (exit code outside mutmut's documented result-flag range 0–15),
result/parse failures, missing or invented totals (**no fallback counts of any
kind**), `apply-failed` survivors, `timeout`/`suspicious`/`skipped`/`untested`
statuses, unknown statuses, and any accounting mismatch
(`killed + accepted + logic-survivors != total`). Evidence records the tool
exit code and the full accounting equation.

## §2a "suspicious" is verified, not blanket-failed (V005)

mutmut's `suspicious` status is a TIMING heuristic (the suite ran but slower
than a baseline multiple); under variable CI load it fires non-deterministically
even for mutants the suite handles correctly. Because the mutant WAS executed,
the gate does not blanket-fail on it. Instead each suspicious mutant is
independently verified on the same footing as a reported survivor: apply it, run
the suite deterministically, and classify (killed-on-verify, accepted prose, or
logic survivor). This keeps the gate fail-closed — nothing is accepted without
independent verification — while eliminating load-sensitivity. `timeout`,
`skipped` and `untested` remain hard fail-closed because the mutant never ran to
completion.

## §3 Governed non-behavioural classes
Only the two classes above may be accepted without failing the gate, and each
accepted mutant must be listed individually in `evidence/G07-mutation.json`.
Widening these classes requires a new ADR.

## Consequences
The gate script exposes an injectable command runner; a dedicated test module
(`tests/test_mutation_gate_script.py`) simulates tool crash, malformed output,
apply failure and non-terminal statuses and proves each fails the gate. The
literal "241" is pinned out of the script by regression test.
