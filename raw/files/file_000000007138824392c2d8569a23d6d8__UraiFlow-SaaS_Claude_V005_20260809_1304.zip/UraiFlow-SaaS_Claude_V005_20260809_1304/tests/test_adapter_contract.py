"""RTM: SLICE-004, ARC-002, SaaS-002, ADP-001/002 — target-system adapter contract,
compliance harness, runtime registry descriptor validation (ADR-0007),
rollback capability declaration, adapter-level tenant isolation."""
import pytest

from uraiflow.adapters.contract import (
    AdapterDescriptor,
    assert_adapter_contract,
    standard_validate,
)
from uraiflow.adapters.inmemory import InMemoryTargetAdapter
from uraiflow.core.errors import (
    AdapterContractError,
    RoutingError,
    TenantIsolationError,
    TrustBoundaryViolation,
)
from uraiflow.core.tenancy import TenantContext
from uraiflow.extraction.model import CandidateRecord
from uraiflow.routing.registry import AdapterRegistry

CTX_A = TenantContext(tenant_id="tenant-a", actor_id="user-1")
CTX_B = TenantContext(tenant_id="tenant-b", actor_id="user-2")


def _adapter(**kw) -> InMemoryTargetAdapter:
    return InMemoryTargetAdapter(
        name=kw.get("name", "target-x"),
        schema_version="1.0",
        required_fields={"time_entry": ("contact", "minutes"), "follow_up": ("note",)},
    )


def _record(record_type="time_entry", fields=None, record_id="rec-1") -> CandidateRecord:
    return CandidateRecord(
        record_id=record_id,
        record_type=record_type,
        fields=fields if fields is not None else {"contact": "A", "minutes": 5},
        confidence=0.9,
        source_text="s",
    )


def test_descriptor_declares_contract_surface():
    d = _adapter().descriptor()
    assert isinstance(d, AdapterDescriptor)
    assert set(d.accepted_record_types) == {"time_entry", "follow_up"}
    assert d.schema_version == "1.0"
    assert d.supports_rollback is True


def test_reference_adapter_satisfies_contract_harness():
    assert_adapter_contract(_adapter())


def test_standard_validate_accepts_complete_record():
    result = standard_validate(_adapter().descriptor(), _record())
    assert result.ok and result.errors == ()


def test_standard_validate_rejects_unaccepted_type():
    result = standard_validate(_adapter().descriptor(), _record(record_type="payroll"))
    assert not result.ok and "payroll" in result.errors[0]


def test_standard_validate_rejects_missing_and_empty_required_fields():
    result = standard_validate(
        _adapter().descriptor(), _record(fields={"contact": ""})
    )
    assert not result.ok
    assert len(result.errors) == 2  # empty contact + missing minutes


def test_preview_reports_target_without_committing():
    adapter = _adapter()
    preview = adapter.preview(CTX_A, _record())
    assert preview["adapter"] == "target-x"
    assert preview["record_type"] == "time_entry"
    assert adapter.committed_count(CTX_A) == 0


def test_commit_is_idempotent_per_key():
    adapter = _adapter()
    r1 = adapter.commit(CTX_A, _record(), idempotency_key="k1")
    r2 = adapter.commit(CTX_A, _record(), idempotency_key="k1")
    assert r1.receipt_id == r2.receipt_id
    assert adapter.committed_count(CTX_A) == 1


def test_commit_rejects_invalid_record():
    with pytest.raises(AdapterContractError):
        _adapter().commit(CTX_A, _record(fields={}), idempotency_key="k1")


def test_commit_isolated_per_tenant_and_rollback_denied_cross_tenant():
    adapter = _adapter()
    receipt = adapter.commit(CTX_A, _record(), idempotency_key="k1")
    adapter.commit(CTX_B, _record(record_id="rec-9"), idempotency_key="k1")
    assert adapter.committed_count(CTX_A) == 1
    assert adapter.committed_count(CTX_B) == 1
    with pytest.raises(TenantIsolationError):
        adapter.rollback(CTX_B, receipt)


def test_rollback_removes_commit_and_unknown_receipt_raises():
    adapter = _adapter()
    receipt = adapter.commit(CTX_A, _record(), idempotency_key="k1")
    adapter.rollback(CTX_A, receipt)
    assert adapter.committed_count(CTX_A) == 0
    with pytest.raises(AdapterContractError):
        adapter.rollback(CTX_A, receipt)


def test_registry_routes_by_record_type():
    registry = AdapterRegistry()
    adapter = _adapter()
    registry.register(adapter)
    assert registry.resolve("time_entry") is adapter


def test_registry_rejects_duplicate_record_type_ownership():
    registry = AdapterRegistry()
    registry.register(_adapter())
    with pytest.raises(RoutingError):
        registry.register(_adapter(name="target-y"))


def test_registry_rejects_unroutable_record_type():
    with pytest.raises(RoutingError):
        AdapterRegistry().resolve("time_entry")


def test_registry_resolves_by_adapter_machine_identity():
    """ADR-0010: resolution for compensation binds to adapter_id, never to the
    display name (name-based resolution was removed in V004)."""
    registry = AdapterRegistry()
    adapter = _adapter()
    registry.register(adapter)
    assert registry.resolve_by_id("target-x") is adapter
    assert not hasattr(registry, "resolve_by_name")
    with pytest.raises(RoutingError):
        registry.resolve_by_id("target-unknown")


# ---------------- V003: runtime registration validation (ADR-0007 §4) ----------------

class _MalformedAdapter(InMemoryTargetAdapter):
    def __init__(self, descriptor):
        self._descriptor = descriptor
        self._committed = {}


def _descriptor(**over):
    base = {
        "adapter_id": "ok",
        "name": "ok",
        "schema_version": "1.0",
        "accepted_record_types": ("time_entry",),
        "required_fields": {"time_entry": ("contact",)},
        "supports_rollback": True,
    }
    base.update(over)
    return AdapterDescriptor(**base)


@pytest.mark.parametrize(
    "bad",
    [
        {"accepted_record_types": ()},
        {"required_fields": {}},
    ],
)
def test_registry_rejects_malformed_descriptor_at_registration(bad):
    registry = AdapterRegistry()
    with pytest.raises(AdapterContractError):
        registry.register(_MalformedAdapter(_descriptor(**bad)))


@pytest.mark.parametrize(
    "bad",
    [
        {"name": "  "},
        {"schema_version": ""},
    ],
)
def test_blank_descriptor_identity_values_are_unconstructable(bad):
    """ADR-0014: emptiness rejection moved to construction time."""
    with pytest.raises(TrustBoundaryViolation):
        _descriptor(**bad)


def test_harness_raises_adapter_contract_error_on_malformed():
    with pytest.raises(AdapterContractError):
        assert_adapter_contract(_MalformedAdapter(_descriptor(required_fields={})))


def test_adapter_can_declare_no_rollback_and_refuses_rollback_calls():
    adapter = InMemoryTargetAdapter(
        name="no-rb",
        schema_version="1.0",
        required_fields={"time_entry": ("contact", "minutes")},
        supports_rollback=False,
    )
    assert adapter.descriptor().supports_rollback is False
    receipt = adapter.commit(CTX_A, _record(), idempotency_key="k1")
    with pytest.raises(AdapterContractError):
        adapter.rollback(CTX_A, receipt)
