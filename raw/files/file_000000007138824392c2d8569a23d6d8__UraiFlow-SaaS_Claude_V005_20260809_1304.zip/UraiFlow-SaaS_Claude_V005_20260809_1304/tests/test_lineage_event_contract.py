"""V004 lineage evidence contract (ADR-0008, ADR-0013): event KINDS and
payload KEYS are observable machine contract, pinned exactly.

Driven by the G07 acceptance-class audit: 35 surviving string mutants altered
event kinds or payload keys, which must never be dismissable as prose. The
gate classifier now marks such mutations as logic; these tests kill them.
"""
from datetime import UTC, datetime

import pytest

from uraiflow.adapters.inmemory import InMemoryTargetAdapter
from uraiflow.confirmation.service import ConfirmationService
from uraiflow.core.clock import FixedClock
from uraiflow.core.tenancy import TenantContext
from uraiflow.extraction.rules import (
    ConfigurableRuleExtractor,
    ExtractionRule,
    FieldSpec,
)
from uraiflow.lineage.store import LineageStore
from uraiflow.pipeline.orchestrator import ConversationToActionPipeline
from uraiflow.proposal.model import ProposalStatus
from uraiflow.recovery.service import RecoveryService
from uraiflow.routing.registry import AdapterRegistry
from uraiflow.transcription.provider import DeterministicEchoProvider
from uraiflow.transcription.selector import ProviderSelector

T0 = datetime(2026, 8, 9, 12, 0, tzinfo=UTC)
CTX = TenantContext(tenant_id="t1", actor_id="op-1")


class _FailingRollbackAdapter(InMemoryTargetAdapter):
    def rollback(self, ctx, receipt) -> None:
        raise ConnectionError("rollback connection reset")


class _FailingCommitAdapter(InMemoryTargetAdapter):
    def commit(self, ctx, record, idempotency_key):
        raise TimeoutError("target down")


def _rule(record_type: str, keyword: str, field: str = "title") -> ExtractionRule:
    return ExtractionRule(
        record_type=record_type,
        pattern=rf"{keyword}:\s*(?P<v>\S+)",
        confidence=0.9,
        fields=(FieldSpec(name=field, source="group:v"),),
    )


def _pipeline(registry: AdapterRegistry, *rules: ExtractionRule):
    lineage = LineageStore()
    pipeline = ConversationToActionPipeline(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={},
            default_provider="echo",
        ),
        extractor=ConfigurableRuleExtractor(rules=tuple(rules)),
        registry=registry,
        lineage=lineage,
        clock=FixedClock(T0),
    )
    return pipeline, lineage


def _events(lineage: LineageStore, subject_id: str) -> list[tuple[str, dict]]:
    return [
        (e.kind, dict(e.payload)) for e in lineage.for_subject(CTX, subject_id)
    ]


def _payload(events: list[tuple[str, dict]], kind: str) -> dict:
    matches = [p for k, p in events if k == kind]
    assert matches, f"expected an event of kind {kind!r}; saw {[k for k, _ in events]}"
    return matches[-1]


# ------------------------------------------------------------- clarification


class TestClarificationAndRevalidationEvents:
    def test_no_candidates_event_contract(self) -> None:
        registry = AdapterRegistry()
        registry.register(
            InMemoryTargetAdapter(
                adapter_id="adp.t", name="t", schema_version="1.0",
                required_fields={"task": ("title",)},
            )
        )
        pipeline, lineage = _pipeline(registry, _rule("task", "task"))
        proposal = pipeline.ingest(CTX, source_ref="s", content="nothing here")
        events = _events(lineage, proposal.proposal_id)
        payload = _payload(events, "proposal.needs_clarification")
        assert payload == {"reason": "no candidates"}

    def test_validation_error_edit_revalidate_event_contract(self) -> None:
        registry = AdapterRegistry()
        registry.register(
            InMemoryTargetAdapter(
                adapter_id="adp.t", name="t", schema_version="1.0",
                required_fields={"task": ("title",)},
            )
        )
        # rule extracts the wrong field name -> required "title" missing
        pipeline, lineage = _pipeline(registry, _rule("task", "task", field="other"))
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
        assert proposal.status is ProposalStatus.NEEDS_CLARIFICATION
        events = _events(lineage, proposal.proposal_id)
        payload = _payload(events, "proposal.needs_clarification")
        assert set(payload) == {"reason", "invalid_items"}
        assert payload["reason"] == "validation errors"
        assert payload["invalid_items"] == 1  # count of invalid items

        # edit/revalidate contract needs a commandable proposal (the
        # NEEDS_CLARIFICATION recovery flow is deferred to V005): fresh
        # pipeline with a correct rule
        pipeline2, lineage2 = _pipeline(registry, _rule("task", "task"))
        proposal2 = pipeline2.ingest(CTX, source_ref="s", content="task: a")
        assert proposal2.status is ProposalStatus.AWAITING_CONFIRMATION
        edited_id = proposal2.items[0].record_id
        confirmation = ConfirmationService(lineage=lineage2, clock=FixedClock(T0))
        confirmation.edit(CTX, proposal2, edited_id, {"title": "fixed"})
        events2 = _events(lineage2, proposal2.proposal_id)
        assert _payload(events2, "proposal.item_edited") == {"record_id": edited_id}

        pipeline2.revalidate(CTX, proposal2)
        events2 = _events(lineage2, proposal2.proposal_id)
        assert _payload(events2, "proposal.revalidated") == {"invalid_items": 0}


# ------------------------------------------------------------------- commit


class TestCommitAndCompensationEvents:
    def test_receipt_violation_and_rollback_event_contract(self) -> None:
        from tests.test_adapter_identity_and_receipts import _HostileReceiptAdapter

        registry = AdapterRegistry()
        honest = InMemoryTargetAdapter(
            adapter_id="adp.honest", name="honest", schema_version="1.0",
            required_fields={"task": ("title",)},
        )
        hostile = _HostileReceiptAdapter("adp.liar", "liar", "note")
        registry.register(honest)
        registry.register(hostile)
        pipeline, lineage = _pipeline(
            registry, _rule("task", "task"), _rule("note", "note")
        )
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
        proposal.confirm_all()
        pipeline.commit(CTX, proposal)
        events = _events(lineage, proposal.proposal_id)
        task_id = next(i.record_id for i in proposal.items if i.record_type == "task")
        note_id = next(i.record_id for i in proposal.items if i.record_type == "note")

        committed = _payload(events, "record.committed")
        assert set(committed) == {"record_id", "adapter", "target_ref"}
        assert committed["record_id"] == task_id
        assert committed["adapter"] == "honest"

        invalid = _payload(events, "record.commit_receipt_invalid")
        assert set(invalid) == {"record_id", "error"}
        assert invalid["record_id"] == note_id
        assert "tenant" in invalid["error"]

        assert set(_payload(events, "proposal.commit_failed")) == {"error"}
        assert _payload(events, "proposal.compensating") == {"to_compensate": 1}

        rolled = _payload(events, "record.rolled_back")
        assert rolled == {"record_id": task_id, "adapter": "adp.honest"}
        assert _payload(events, "proposal.rolled_back") == {"compensated": 1}

    def test_compensation_failed_event_contract(self) -> None:
        registry = AdapterRegistry()
        sticky = _FailingRollbackAdapter(
            adapter_id="adp.sticky", name="sticky", schema_version="1.0",
            required_fields={"task": ("title",)},
        )
        registry.register(sticky)
        registry.register(
            _FailingCommitAdapter(
                adapter_id="adp.down", name="down", schema_version="1.0",
                required_fields={"note": ("title",)},
            )
        )
        pipeline, lineage = _pipeline(
            registry, _rule("task", "task"), _rule("note", "note")
        )
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
        proposal.confirm_all()
        pipeline.commit(CTX, proposal)
        assert proposal.status is ProposalStatus.COMPENSATION_FAILED
        events = _events(lineage, proposal.proposal_id)
        task_id = next(i.record_id for i in proposal.items if i.record_type == "task")

        failed = _payload(events, "record.rollback_failed")
        assert set(failed) == {"record_id", "error"}
        assert failed["record_id"] == task_id
        assert "ConnectionError" in failed["error"]

        comp_failed = _payload(events, "proposal.compensation_failed")
        assert set(comp_failed) == {"unrecovered", "unrecovered_receipt_ids"}
        assert comp_failed["unrecovered"] == 1
        assert comp_failed["unrecovered_receipt_ids"] == [
            proposal.unrecovered_receipts[0].receipt_id
        ]

    def test_preflight_refusal_event_contract(self) -> None:
        registry = AdapterRegistry()
        registry.register(
            InMemoryTargetAdapter(
                adapter_id="adp.norb", name="norb", schema_version="1.0",
                required_fields={"task": ("title",)}, supports_rollback=False,
            )
        )
        registry.register(
            InMemoryTargetAdapter(
                adapter_id="adp.ok", name="ok", schema_version="1.0",
                required_fields={"note": ("title",)},
            )
        )
        pipeline, lineage = _pipeline(
            registry, _rule("task", "task"), _rule("note", "note")
        )
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
        proposal.confirm_all()
        from uraiflow.core.errors import AdapterContractError
        with pytest.raises(AdapterContractError, match="rollback support"):
            pipeline.commit(CTX, proposal)
        payload = _payload(
            _events(lineage, proposal.proposal_id), "proposal.commit_preflight_failed"
        )
        assert payload == {"adapters_without_rollback": ["norb"]}


# ----------------------------------------------------------------- recovery


def _compensation_failed_setup():
    registry = AdapterRegistry()
    sticky = _FailingRollbackAdapter(
        adapter_id="adp.sticky", name="sticky", schema_version="1.0",
        required_fields={"task": ("title",)},
    )
    registry.register(sticky)
    registry.register(
        _FailingCommitAdapter(
            adapter_id="adp.down", name="down", schema_version="1.0",
            required_fields={"note": ("title",)},
        )
    )
    pipeline, lineage = _pipeline(
        registry, _rule("task", "task"), _rule("note", "note")
    )
    proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
    proposal.confirm_all()
    pipeline.commit(CTX, proposal)
    assert proposal.status is ProposalStatus.COMPENSATION_FAILED
    service = RecoveryService(
        registry=registry,
        lineage=lineage,
        clock=FixedClock(T0),
        authorized_operators=frozenset({"op-1"}),
    )
    return proposal, lineage, service, sticky


class TestRecoveryEvents:
    def test_retry_failure_event_contract(self) -> None:
        proposal, lineage, service, _sticky = _compensation_failed_setup()
        receipt = proposal.unrecovered_receipts[0]
        service.retry_rollback(CTX, proposal)
        events = _events(lineage, proposal.proposal_id)

        started = _payload(events, "recovery.retry_started")
        assert started == {"operator_id": "op-1", "receipts": [receipt.receipt_id]}

        failed = [p for k, p in events if k == "record.rollback_failed"]
        assert len(failed) == 2  # original compensation + the retry
        assert set(failed[-1]) == {"record_id", "error"}
        assert failed[-1]["record_id"] == receipt.record_id
        assert "adp.sticky" in failed[-1]["error"]

        retry_failed = _payload(events, "recovery.retry_failed")
        assert retry_failed == {"operator_id": "op-1", "unrecovered": 1}

    def test_retry_success_event_contract(self) -> None:
        proposal, lineage, service, sticky = _compensation_failed_setup()
        receipt = proposal.unrecovered_receipts[0]
        sticky.rollback = super(  # heal: restore genuine rollback behaviour
            _FailingRollbackAdapter, sticky
        ).rollback
        service.retry_rollback(CTX, proposal)
        assert proposal.status is ProposalStatus.ROLLED_BACK
        events = _events(lineage, proposal.proposal_id)

        rolled = [p for k, p in events if k == "record.rolled_back"]
        assert rolled[-1] == {
            "record_id": receipt.record_id, "adapter": "adp.sticky"
        }
        succeeded = _payload(events, "recovery.retry_succeeded")
        assert succeeded == {"operator_id": "op-1", "compensated": 1}

    def test_manual_resolution_event_contract(self) -> None:
        proposal, lineage, service, _sticky = _compensation_failed_setup()
        receipt = proposal.unrecovered_receipts[0]
        service.resolve_manually(CTX, proposal, evidence="  ticket OPS-441  ")
        assert proposal.status is ProposalStatus.MANUALLY_RESOLVED
        payload = _payload(
            _events(lineage, proposal.proposal_id), "recovery.manually_resolved"
        )
        assert payload == {
            "operator_id": "op-1",
            "evidence": "ticket OPS-441",
            "unrecovered_receipt_ids": [receipt.receipt_id],
        }


if __name__ == "__main__":
    pytest.main([__file__, "-q"])
