"""V004 P0-3 regressions (ADR-0011): the G07 mutation gate is FAIL-CLOSED.

Simulates mutmut tool failure, malformed output, apply failure and
non-terminal mutant statuses through an injected command runner; every such
condition must raise GateFailure (exit 1 in main()).
"""
import importlib.util
import subprocess
from pathlib import Path

import pytest

_SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "run_mutation_gate.py"
_spec = importlib.util.spec_from_file_location("run_mutation_gate", _SCRIPT)
gate = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(gate)


@pytest.fixture(autouse=True)
def _isolate_gate_side_effects(tmp_path, monkeypatch):
    """The gate's real side-effect paths must never be touched from tests.

    These tests execute INSIDE mutmut's own baseline pytest run when the real
    gate runs; deleting the live .mutmut-cache under mutmut's open connection
    corrupts that run (V004 root-caused: pony 'attempt to write a readonly
    database'). Evidence writes are likewise redirected.
    """
    monkeypatch.setattr(gate, "CACHE", tmp_path / "mutmut-cache")
    monkeypatch.setattr(gate, "EVIDENCE", tmp_path / "evidence")


class FakeRunner:
    """Scriptable stand-in for subprocess execution inside the gate."""

    def __init__(self) -> None:
        self.responses: dict[str, tuple[int, str, str]] = {}

    def set(self, key: str, returncode: int, stdout: str = "", stderr: str = "") -> None:
        self.responses[key] = (returncode, stdout, stderr)

    def __call__(self, cmd: list[str]) -> subprocess.CompletedProcess:
        joined = " ".join(cmd)
        for key, (code, out, err) in self.responses.items():
            if key in joined:
                return subprocess.CompletedProcess(cmd, code, out, err)
        return subprocess.CompletedProcess(cmd, 0, "", "")


def _healthy_runner(survivors: str = "") -> FakeRunner:
    runner = FakeRunner()
    runner.set("mutmut run", 1 if survivors else 0)
    runner.set("result-ids survived", 0, survivors)
    for status in ("timeout", "suspicious", "skipped", "untested"):
        runner.set(f"result-ids {status}", 0, "")
    runner.set("mutmut results", 0, "1 2 3")
    return runner


def test_mutmut_tool_crash_fails_gate() -> None:
    runner = _healthy_runner()
    runner.set("mutmut run", 137, "", "Killed")  # e.g. OOM-killed tool
    with pytest.raises(gate.GateFailure, match="failed as a tool"):
        gate.execute(run=runner)


def test_result_ids_command_failure_fails_gate() -> None:
    runner = _healthy_runner()
    runner.set("result-ids survived", 3, "", "boom")
    with pytest.raises(gate.GateFailure, match="result-ids survived failed"):
        gate.execute(run=runner)


def test_malformed_result_ids_output_fails_gate() -> None:
    runner = _healthy_runner()
    runner.set("result-ids survived", 0, "12 garbage 14")
    with pytest.raises(gate.GateFailure, match="unparseable mutant id"):
        gate.execute(run=runner)


def test_results_parse_failure_fails_gate_no_fallback_total() -> None:
    """The hard-coded 241 fallback is gone: an unparseable total FAILS."""
    runner = _healthy_runner()
    runner.set("mutmut results", 0, "no numbers here")
    with pytest.raises(gate.GateFailure, match="no parseable mutant ids"):
        gate.execute(run=runner)


def test_results_command_failure_fails_gate() -> None:
    runner = _healthy_runner()
    runner.set("mutmut results", 2, "", "cache corrupt")
    with pytest.raises(gate.GateFailure, match="mutmut results failed"):
        gate.execute(run=runner)


@pytest.mark.parametrize("status", ["timeout", "skipped", "untested"])
def test_non_terminal_mutant_statuses_fail_gate(status: str) -> None:
    runner = _healthy_runner()
    runner.set(f"result-ids {status}", 0, "7 8")
    with pytest.raises(gate.GateFailure, match=f"non-terminal status '{status}'"):
        gate.execute(run=runner)


def test_suspicious_mutant_is_verified_not_blanket_failed() -> None:
    """V005: 'suspicious' is mutmut's load-sensitive TIMING heuristic, not a
    correctness signal. A suspicious mutant is verified on the same footing as
    a survivor: if applying it makes the suite fail, it is killed-on-verify and
    the gate PASSES (it is not blanket-failed)."""
    runner = _healthy_runner()
    runner.set("result-ids suspicious", 0, "8")   # one suspicious mutant
    runner.set("mutmut show 8", 0,
               "+++ src/x.py\n+    logic_change = 2")  # not a literal → logic
    runner.set("mutmut apply 8", 0)
    # applying it makes the suite fail => killed-on-verify => gate passes
    runner.set("pytest", 1)
    evidence = gate.execute(run=runner)
    assert evidence["summary"]["logic_survivors"] == 0
    assert evidence["summary"]["killed_on_independent_verify"] == 1


def test_suspicious_real_logic_survivor_still_fails_gate() -> None:
    """A suspicious mutant that SURVIVES independent verification and is not
    prose is a logic survivor and still fails the gate — fail-closed intact."""
    runner = _healthy_runner()
    runner.set("result-ids suspicious", 0, "9")
    runner.set("mutmut show 9", 0,
               "+++ src/x.py\n+    threshold = threshold + 1")  # behavioural
    runner.set("mutmut apply 9", 0)
    runner.set("pytest", 0)  # suite still passes => genuine survivor
    with pytest.raises(gate.GateFailure, match="verified logic survivors"):
        gate.execute(run=runner)


def test_apply_failed_survivor_fails_gate() -> None:
    """An unverifiable survivor must fail G07, never be silently accepted."""
    runner = _healthy_runner(survivors="5")
    runner.set("mutmut show 5", 0, "+++ src/x.py\n+    mutated line\n")
    runner.set("mutmut apply 5", 1, "", "could not apply")
    with pytest.raises(gate.GateFailure, match="could not be applied"):
        gate.execute(run=runner)


def test_show_failure_fails_gate() -> None:
    runner = _healthy_runner(survivors="5")
    runner.set("mutmut show 5", 1, "", "unknown mutant")
    with pytest.raises(gate.GateFailure, match="mutmut show 5 failed"):
        gate.execute(run=runner)


def test_no_hardcoded_total_remains_in_script() -> None:
    """Regression pin on the exact V003 defect: the invented 241 total."""
    source = _SCRIPT.read_text(encoding="utf-8")
    assert "241" not in source


def test_main_translates_gate_failure_to_exit_1(monkeypatch, tmp_path) -> None:
    def _boom(run=None):
        raise gate.GateFailure("simulated")

    monkeypatch.setattr(gate, "execute", _boom)
    monkeypatch.setattr(gate, "EVIDENCE", tmp_path)  # never stomp real evidence
    assert gate.main() == 1
    assert "G07 FAIL" in (tmp_path / "G07-mutation-summary.txt").read_text()


# ------- V004 review P1-2: semantic literal classification (ADR-0011 §3) -------


class TestLiteralClassification:
    """The classifier must NOT blanket-accept string literals. Identifier
    prefixes, event kinds, keys, record types and other machine-observable
    strings are LOGIC; only genuine prose (error args, docstrings, interpolated
    messages) is accepted as non-behavioural."""

    def test_id_prefix_mutation_is_logic(self) -> None:
        assert gate._classify_literal('proposal_id=new_id("XXpropXX"),') == "logic"

    def test_event_id_prefix_mutation_is_logic(self) -> None:
        assert gate._classify_literal('event_id=new_id("XXevtXX"),') == "logic"

    def test_dotted_event_kind_mutation_is_logic(self) -> None:
        assert gate._classify_literal('"XXrecord.rolled_backXX",') == "logic"

    def test_payload_key_mutation_is_logic(self) -> None:
        assert gate._classify_literal('"XXrecord_idXX": item.record_id,') == "logic"

    def test_plain_identifier_literal_defaults_to_logic(self) -> None:
        """Default-deny: an unproven literal is logic, not silently accepted."""
        assert gate._classify_literal('default_provider="XXechoXX",') == "logic"

    def test_error_message_prose_is_accepted(self) -> None:
        added = 'raise ValueError(f"XXproposal {pid}: not allowedXX")'
        assert gate._classify_literal(added) == "literal"

    def test_docstring_prose_is_accepted(self) -> None:
        assert gate._classify_literal('"""XXsome docstring textXX"""') == "literal"


# ------- V005: crash-safe source snapshot (killed-run self-healing) -----------


class TestCrashSafeSnapshot:
    def test_restore_snapshot_heals_a_left_behind_mutation(
        self, tmp_path, monkeypatch
    ) -> None:
        """Simulate a killed run: a snapshot exists and a target is mutated on
        disk. restore_snapshot() must put the pristine bytes back."""
        target = "src/pkg/mod.py"
        root = tmp_path
        (root / "src" / "pkg").mkdir(parents=True)
        (root / target).write_text("x = 1  # pristine\n")
        monkeypatch.setattr(gate, "ROOT", root)
        monkeypatch.setattr(gate, "TARGETS", [target])
        monkeypatch.setattr(gate, "SNAPSHOT_DIR", root / ".mutation-snapshot")
        monkeypatch.setattr(gate, "_snapshot_path",
                            lambda t: gate.SNAPSHOT_DIR / t.replace("/", "__"))
        gate.write_snapshot()
        # a mutant is applied and the process "dies" before restore
        (root / target).write_text("x = 2  # MUTATED\n")
        healed = gate.restore_snapshot()
        assert healed is True
        assert (root / target).read_text() == "x = 1  # pristine\n"
        # snapshot is consumed
        assert not (root / ".mutation-snapshot").exists()

    def test_restore_snapshot_noop_without_snapshot(
        self, tmp_path, monkeypatch
    ) -> None:
        monkeypatch.setattr(gate, "SNAPSHOT_DIR", tmp_path / "absent")
        monkeypatch.setattr(gate, "TARGETS", [])
        assert gate.restore_snapshot() is False

    def test_restore_cli_mode_heals_and_returns_zero(
        self, tmp_path, monkeypatch
    ) -> None:
        target = "src/pkg/mod.py"
        root = tmp_path
        (root / "src" / "pkg").mkdir(parents=True)
        (root / target).write_text("ok = True\n")
        monkeypatch.setattr(gate, "ROOT", root)
        monkeypatch.setattr(gate, "TARGETS", [target])
        monkeypatch.setattr(gate, "SNAPSHOT_DIR", root / ".mutation-snapshot")
        monkeypatch.setattr(gate, "_snapshot_path",
                            lambda t: gate.SNAPSHOT_DIR / t.replace("/", "__"))
        gate.write_snapshot()
        (root / target).write_text("ok = False  # mutated\n")
        monkeypatch.setattr(gate.sys, "argv", ["run_mutation_gate.py", "--restore"])
        assert gate.main() == 0
        assert (root / target).read_text() == "ok = True\n"


class TestLiteralClassificationRefined:
    """V005: the classifier judges a literal by its own shape (mutmut shows
    only the mutated line). Behavioural positions and identifier tokens are
    logic; whitespace/interpolated messages are prose."""

    def test_setattr_field_name_is_logic(self) -> None:
        # mutating the field name writes canonical value to the WRONG attribute
        assert gate._classify_literal('self, "XXadapter_idXX",') == "logic"
        assert gate._classify_literal('self, "XXtenant_idXX",') == "logic"

    def test_single_token_identifier_literal_is_logic(self) -> None:
        assert gate._classify_literal('default="XXechoXX",') == "logic"

    def test_whitespace_message_fragment_is_prose(self) -> None:
        assert gate._classify_literal('"XXbefore confirmationXX"') == "literal"

    def test_interpolated_fragment_is_prose(self) -> None:
        assert gate._classify_literal('f"XXadapter \'{descriptor.name}\'XX"') == "literal"

    def test_field_kwarg_label_is_prose(self) -> None:
        # field="..." only appears interpolated in a raised message
        assert gate._classify_literal(
            'canonical_identifier(x, field="XXadapter_idXX")'
        ) == "literal"

    def test_require_same_tenant_subject_is_prose(self) -> None:
        assert gate._classify_literal(
            'require_same_tenant(ctx, proposal.tenant_id, "XXproposalXX")'
        ) == "literal"


class TestLiteralClassificationV005:
    """Extra pins for the shape-based classifier (V005): setattr field names
    and message fragments are handled correctly."""

    def test_setattr_field_name_is_logic(self) -> None:
        assert gate._classify_literal('self, "XXadapter_idXX",') == "logic"

    def test_setattr_tenant_field_is_logic(self) -> None:
        assert gate._classify_literal('self, "XXtenant_idXX",') == "logic"

    def test_multiword_message_is_prose(self) -> None:
        assert gate._classify_literal('"XXbefore confirmationXX"') == "literal"

    def test_interpolated_fragment_is_prose(self) -> None:
        assert gate._classify_literal('f"XXadapter \'{descriptor.name}\'XX"') == "literal"

    def test_field_kwarg_label_is_prose(self) -> None:
        assert gate._classify_literal(
            'canonical_identifier(self.name, field="XXadapter nameXX")'
        ) == "literal"

    def test_require_commandable_label_is_prose(self) -> None:
        assert gate._classify_literal(
            'self._require_commandable("XXconfirm_selectedXX")'
        ) == "literal"

    def test_bare_single_token_defaults_to_logic(self) -> None:
        assert gate._classify_literal('default_provider="XXechoXX",') == "logic"
