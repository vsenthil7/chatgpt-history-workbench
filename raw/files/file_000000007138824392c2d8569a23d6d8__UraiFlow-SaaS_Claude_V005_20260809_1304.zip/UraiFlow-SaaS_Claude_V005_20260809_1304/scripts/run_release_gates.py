#!/usr/bin/env python3
"""Release gate orchestrator (ADR-0012 §7): distinct machine result + evidence
per gate. A general pytest invocation may execute tests shared by several
gates, but each gate's requirement and result is explicit here.

Gates:
  G01 repository/manifest      G02 lint/type          G03 tests
  G04 line+branch coverage     G05 contracts          G06 architecture
  G07 mutation (fail-closed)   G08 tenant/security    G09 RTM
  G10 docs consistency
  G11 deterministic packaging + exact-final-ZIP smoke — scripts/package_release.py
  G12 independent ChatGPT review — outside this repository by definition

Usage: python scripts/run_release_gates.py [--skip-mutation]
(--skip-mutation is for inner-loop development only; a release run must
include G07 and the packaged evidence must contain its output.)
"""
import json
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence"


def _pytest(*args: str) -> list[str]:
    # NOTE: pyproject addopts already sets -q; passing -q again would make the
    # run double-quiet and suppress the "N passed" summary line that the
    # machine-generated build report parses from G03 evidence.
    return [sys.executable, "-m", "pytest", "-p", "no:cacheprovider", *args]


GATES: list[tuple[str, str, list[str]]] = [
    ("G01-starter-validate", "repository structure valid",
     [sys.executable, "scripts/validate_starter.py"]),
    ("G02-ruff", "lint clean",
     [sys.executable, "-m", "ruff", "check", "src", "tests", "scripts"]),
    ("G02-mypy", "types clean",
     [sys.executable, "-m", "mypy", "src/uraiflow"]),
    ("G03-tests", "full behavioural suite passes",
     _pytest()),
    ("G04-coverage", "100% line+branch coverage enforced",
     _pytest("--cov=uraiflow", "--cov-branch", "--cov-report=term",
             "--cov-fail-under=100")),
    ("G05-contracts", "adapter/receipt/identity contracts hold",
     _pytest("tests/test_adapter_contract.py",
             "tests/test_adapter_identity_and_receipts.py")),
    ("G06-architecture", "layering/domain-neutrality guards hold",
     _pytest("tests/test_architecture_guards.py")),
    ("G08-tenant-security", "tenant isolation enforced at boundaries",
     _pytest("-k", "tenant or isolation or cross")),
    ("G09-rtm", "RTM rows complete and resolvable",
     [sys.executable, "scripts/validate_rtm.py"]),
]

# These run AFTER G07 so the build report reflects the mutation evidence: the
# report facts are regenerated from evidence/, then G10 validates that the
# report, versions, names and ADR references are all consistent. Only then is
# the manifest built over the final tree (with all evidence present).
POST_MUTATION_PHASE: list[tuple[str, str, list[str]]] = [
    ("build-report-regen", "build report facts regenerated from evidence",
     [sys.executable, "scripts/gen_build_report.py"]),
    ("G10-docs-consistency", "docs/versions/report consistent with evidence",
     [sys.executable, "scripts/validate_docs_consistency.py"]),
]

# Manifest steps run AFTER G07 so the manifest is generated over the tree once
# ALL evidence (including G07's) has been written and source has been restored;
# the authoritative exact-payload check re-runs inside package_release.py and
# is recorded in the external attestation (ADR-0012 §3).
MANIFEST_PHASE: list[tuple[str, str, list[str]]] = [
    ("G01-manifest-regen", "manifest regenerated over final tree",
     [sys.executable, "scripts/gen_manifest.py"]),
    ("G01-manifest-check", "complete manifest contract holds",
     [sys.executable, "scripts/gen_manifest.py", "--check"]),
]

MUTATION_GATE = ("G07-mutation", "fail-closed mutation gate, 0 logic survivors",
                 [sys.executable, "scripts/run_mutation_gate.py"])


def main(argv: list[str]) -> int:
    EVIDENCE.mkdir(exist_ok=True)
    # Heal any source left mutated by a previously-killed mutation gate BEFORE
    # running behavioural gates, so they never see mutated code (V005 fix).
    subprocess.run(
        [sys.executable, "scripts/run_mutation_gate.py", "--restore"],
        cwd=ROOT, capture_output=True, text=True, check=False,
    )
    # The mutation gate (G07) mutates source in place. It MUST run last and
    # alone: never interleaved with behavioural gates. Behavioural/static gates
    # run first; G07 is appended as the final isolated phase.
    gates = list(GATES)
    if "--skip-mutation" not in argv:
        gates.append(MUTATION_GATE)   # isolated mutation phase (mutates source)
    gates.extend(POST_MUTATION_PHASE)  # report regen + G10, using G07 evidence
    gates.extend(MANIFEST_PHASE)       # manifest sees all evidence, incl. G07
    results = {}
    failed: list[str] = []
    for name, requirement, cmd in gates:
        result = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True,
                                check=False)
        output = result.stdout + result.stderr
        if name != "G01-manifest-regen":
            # the regen step's durable effect is PACKAGE-MANIFEST.json itself;
            # writing an evidence file after regeneration would sit outside the
            # freshly generated manifest (the exact V003 P0-4 failure shape)
            (EVIDENCE / f"{name}.txt").write_text(output, encoding="utf-8")
        status = "PASS" if result.returncode == 0 else "FAIL"
        results[name] = {"requirement": requirement, "status": status,
                         "exit_code": result.returncode,
                         "evidence": f"evidence/{name}.txt"}
        print(f"{name}: {status}  — {requirement}")
        if result.returncode != 0:
            failed.append(name)
            print(output[-1500:])
    summary = {
        "generated": datetime.now(UTC).isoformat(timespec="seconds"),
        "mutation_included": "--skip-mutation" not in argv,
        "gates": results,
        "failed": failed,
    }
    (EVIDENCE / "release-gates-summary.json").write_text(
        json.dumps(summary, indent=1) + "\n", encoding="utf-8"
    )
    if "--skip-mutation" in argv:
        print("NOTE: G07 skipped (development mode); a release requires it.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
