#!/usr/bin/env python3
"""G07 mutation gate — FAIL-CLOSED (QA-002, ADR-0004, ADR-0011).

Runs mutmut over the policy modules, then independently re-verifies every
reported survivor by applying it and running the full suite.

Fail-closed policy (ADR-0011): the gate PASSES only when every discovered
mutant has a machine-derived terminal disposition:

* ``killed``                — killed by mutmut during the run;
* ``killed-on-verify``      — reported survived, but independently applying it
                              makes the suite fail;
* ``equivalent-annotation`` — provably runtime-equivalent (PEP 526 function-body
                              annotation mutants), governed by ADR-0011 §3;
* ``literal``               — PROSE-only string mutants (error-message
                              arguments and docstrings). Identifier prefixes,
                              event kinds, keys, record types and other
                              machine-observable strings are classified LOGIC
                              (default-deny), per ADR-0011 §3 as amended by the
                              V004 review (P1-2).

Everything else — tool failure, unparseable output, apply failure, unknown
status, missing mutant IDs, timeouts, skipped/untested mutants, or any
verified logic survivor — FAILS the gate. There are no fallback counts.

Evidence: evidence/G07-mutation.json and evidence/G07-mutation-summary.txt.
"""
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence"
CACHE = ROOT / ".mutmut-cache"
# Crash-safe source snapshot. mutmut mutates TARGETS in place; if this process
# is killed (e.g. SIGKILL mid-run) before its finally-block restore, a mutant
# would be left applied in the working tree. We therefore also write pristine
# copies to disk under SNAPSHOT_DIR and restore from them on the NEXT startup
# (see restore_snapshot). This makes an interrupted gate self-healing rather
# than silently corrupting source (V005: a killed run left `not in` -> `in`).
SNAPSHOT_DIR = ROOT / ".mutation-snapshot"


def _snapshot_path(target: str) -> Path:
    return SNAPSHOT_DIR / target.replace("/", "__")


def write_snapshot() -> None:
    SNAPSHOT_DIR.mkdir(exist_ok=True)
    for target in TARGETS:
        _snapshot_path(target).write_bytes((ROOT / target).read_bytes())


def restore_snapshot() -> bool:
    """If a prior run left a snapshot behind (crash mid-run), restore every
    target from it and clear the snapshot. Returns True if a restore happened.
    """
    if not SNAPSHOT_DIR.exists():
        return False
    restored = False
    for target in TARGETS:
        snap = _snapshot_path(target)
        if snap.is_file():
            live = ROOT / target
            if live.read_bytes() != snap.read_bytes():
                live.write_bytes(snap.read_bytes())
                restored = True
    shutil.rmtree(SNAPSHOT_DIR, ignore_errors=True)
    return restored
TARGETS = [
    "src/uraiflow/proposal/model.py",
    "src/uraiflow/confirmation/service.py",
    "src/uraiflow/pipeline/orchestrator.py",
    "src/uraiflow/adapters/contract.py",
    "src/uraiflow/routing/registry.py",
    "src/uraiflow/core/tenancy.py",
    "src/uraiflow/core/primitives.py",
    "src/uraiflow/recovery/service.py",
]
# mutmut communicates "survivors/timeouts exist" through exit-code flag bits
# (1=survived, 2=timeout, 4=suspicious, 8=skipped); those are *results*, not
# tool failures. Anything outside the flag range means mutmut itself broke.
_MUTMUT_RESULT_CODES = frozenset(range(16))
_STATUS_QUERIES = ("survived", "timeout", "suspicious", "skipped", "untested")


class GateFailure(Exception):
    """Raised for any condition that must fail G07 (fail-closed)."""


# ADR-0011 §3 (V004 review P1-2): a mutated string literal is accepted as
# non-behavioural ONLY when it is provably PROSE — the argument to a raised
# error, or a docstring. Every other literal is treated as LOGIC, including:
#   * new_id("prop") / new_id("evt")   — observable machine-identifier prefixes
#   * lineage event kinds ("record.rolled_back")
#   * dict/payload keys ("record_id":)
#   * record types / states / wire values
# so a mutated identifier prefix now SURVIVES as a logic mutant and fails the
# gate unless a real test kills it. No blanket "literal == non-behavioural".
# The mutated body is everything between the outer XX markers mutmut inserts.
# It may itself contain quotes and {interpolation}, so match up to the CLOSING
# XX (non-greedy) rather than stopping at the first inner quote.
_MUTATED_LITERAL = re.compile(r'XX(?P<body>.*?)XX')
# Behavioural positions: the mutated literal is used AS a value, not shown to a
# human. These are always logic regardless of the literal's text.
_ID_PREFIX_CALL = re.compile(r'new_id\(\s*[bf]?"XX[^"]*XX"')          # id prefix
_SETATTR_FIELD = re.compile(r'__setattr__\(\s*self,\s*[bf]?"XX[^"]*XX"')  # attr name
_DOTTED_OR_KEY = re.compile(r'XX\w+\.\w+XX|"XX\w+XX"\s*:')            # kind / dict key


def _default_run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, check=False)


def _clear_bytecode() -> None:
    for cache in (ROOT / "src").rglob("__pycache__"):
        shutil.rmtree(cache, ignore_errors=True)


def _suite_fails(run) -> bool:
    _clear_bytecode()
    result = run(
        [sys.executable, "-B", "-m", "pytest", "-x", "-q", "-p", "no:cacheprovider"]
    )
    return result.returncode != 0


def _result_ids(run, status: str) -> list[int]:
    result = run([sys.executable, "-m", "mutmut", "result-ids", status])
    if result.returncode != 0:
        raise GateFailure(
            f"mutmut result-ids {status} failed (exit {result.returncode})"
        )
    tokens = result.stdout.split()
    ids: list[int] = []
    for token in tokens:
        if not token.isdigit():
            raise GateFailure(
                f"unparseable mutant id {token!r} in result-ids {status}"
            )
        ids.append(int(token))
    return sorted(ids)


def _total_mutants(run) -> int:
    """Machine-derived mutant total from the mutmut cache; no fallbacks."""
    result = run([sys.executable, "-m", "mutmut", "results"])
    if result.returncode != 0:
        raise GateFailure(f"mutmut results failed (exit {result.returncode})")
    ids = re.findall(r"\b(\d+)\b", result.stdout)
    if not ids:
        raise GateFailure("mutmut results produced no parseable mutant ids")
    return max(int(i) for i in ids)


def _classify_literal(added: str) -> str:
    """Classify a mutated string literal (ADR-0011 §3, V004 review P1-2).

    Returns "literal" (accepted non-behavioural) ONLY for prose: the argument
    of a raised error, an f-string message with interpolation, or a docstring.
    Identifier prefixes (new_id("...")), event kinds, keys, record types and
    any other machine-observable string are "logic" and must be killed by a
    real test.
    """
    # 1. Behavioural POSITIONS — the string is used as a value, never shown to
    #    a human. Always logic, whatever the text.
    if _ID_PREFIX_CALL.search(added):        # new_id("prop") prefix
        return "logic"
    if _SETATTR_FIELD.search(added):         # object.__setattr__(self, "field")
        return "logic"
    if _DOTTED_OR_KEY.search(added):         # "record.rolled_back" / "key":
        return "logic"
    # 2. Otherwise judge by the literal's OWN SHAPE. mutmut mutates only the
    #    string body, so `added` may be just the literal (the surrounding
    #    raise/return is on another line). A human-readable MESSAGE contains
    #    multiple whitespace-separated words; a bare identifier token does not.
    match = _MUTATED_LITERAL.search(added)
    if match:
        body = match.group("body")
        # a keyword-argument label used only inside an error message
        # (field="...", boundary="...", subject "...") reads as prose: it is
        # never compared, only interpolated into a raised message.
        if re.search(r'(?:field|boundary|subject)\s*=\s*[bf]?"XX', added):
            return "literal"
        # a command/operation label passed to a guard that only names it in an
        # error string (e.g. _require_commandable("edit_item"),
        # _authorise(..., "retry_rollback")) is prose, not a routing value.
        if re.search(r'(?:_require_commandable|_authorise)\([^)]*"XX', added):
            return "literal"
        # a tenant-guard subject label (require_same_tenant(..., "proposal"))
        # appears only in the denial message.
        if re.search(r'require_same_tenant\([^)]*"XX', added):
            return "literal"
        # A human message contains whitespace; an identifier / key / prefix /
        # field name / event kind never does. Any multi-token body (a space in
        # the mutated text) is therefore display prose, not a compared or keyed
        # value. This also covers message fragments split across lines
        # ("before confirmation", "boundaries)" — the trailing piece of a
        # multi-line raised message).
        if " " in body.strip():
            return "literal"
        # a single-token message FRAGMENT that interpolates a value
        # (e.g. f"'{key}'") is display text, proven by the interpolation.
        if "{" in body and "}" in body:
            return "literal"
    # 3. default deny (bare identifier tokens, setattr field names, id prefixes,
    #    short non-interpolated fragments) → logic
    return "logic"


def execute(run=_default_run) -> dict:
    """Run the gate; returns the evidence dict. Raises GateFailure on any
    fail-closed condition; the caller turns that into exit 1."""
    # Heal any source left mutated by a previously-killed run before snapshotting.
    restore_snapshot()
    snapshots = {t: (ROOT / t).read_bytes() for t in TARGETS}
    write_snapshot()  # crash-safe on-disk copy for restore-on-next-startup
    _clear_bytecode()
    # CACHE is a module constant so the gate's own test suite can redirect it:
    # those tests run execute() with a fake runner INSIDE mutmut's baseline
    # pytest run, and deleting the real live cache under mutmut's open
    # connection corrupts the outer run ("attempt to write a readonly
    # database").
    if CACHE.exists():
        CACHE.unlink()
    print("running mutmut (this takes several minutes)...")
    run_result = run([sys.executable, "-m", "mutmut", "run", "--no-progress"])
    if run_result.returncode not in _MUTMUT_RESULT_CODES:
        raise GateFailure(
            f"mutmut run failed as a tool (exit {run_result.returncode}); "
            f"stderr tail: {run_result.stderr[-500:]}"
        )
    by_status = {status: _result_ids(run, status) for status in _STATUS_QUERIES}
    # timeout/skipped/untested have NO disposition (the mutant was never
    # actually run to completion): fail closed, no exceptions.
    for status in ("timeout", "skipped", "untested"):
        if by_status[status]:
            raise GateFailure(
                f"mutants with non-terminal status '{status}': {by_status[status]}"
            )
    total = _total_mutants(run)
    # "suspicious" is mutmut's TIMING heuristic (the suite ran but slower than a
    # baseline multiple) — load-sensitive, not a correctness signal. The mutant
    # WAS executed, so we do not blanket-fail; instead we independently verify
    # each one on the same footing as a reported survivor (apply, run the suite
    # deterministically, classify). This keeps the gate fail-closed — nothing is
    # accepted without independent verification — while removing flakiness under
    # variable CI load (V005: 0 suspicious in isolation, 4 under orchestrator).
    survivor_ids = list(by_status["survived"]) + list(by_status["suspicious"])
    print(f"discovered mutants: {total}; reported survivors: "
          f"{len(by_status['survived'])} + suspicious: "
          f"{len(by_status['suspicious'])} (verified identically); verifying each...")
    results = []
    try:
        for mutant_id in survivor_ids:
            for target, blob in snapshots.items():
                (ROOT / target).write_bytes(blob)
            show = run([sys.executable, "-m", "mutmut", "show", str(mutant_id)])
            if show.returncode != 0:
                raise GateFailure(
                    f"mutmut show {mutant_id} failed (exit {show.returncode})"
                )
            diff = show.stdout
            added = " ".join(
                line[1:].strip()
                for line in diff.splitlines()
                if line.startswith("+") and not line.startswith("+++")
            )
            target_file = next(
                (ln[4:].strip() for ln in diff.splitlines() if ln.startswith("+++ ")),
                "?",
            )
            if _MUTATED_LITERAL.search(added):
                kind = _classify_literal(added)
            elif re.fullmatch(r"\w+:\s*str\s*[&|]\s*None\s*=\s*None", added):
                # function-body variable annotations are never evaluated at
                # runtime (PEP 526); such mutants are provably equivalent.
                kind = "equivalent-annotation"
            else:
                kind = "logic"
            applied = run([sys.executable, "-m", "mutmut", "apply", str(mutant_id)])
            if applied.returncode != 0:
                # ADR-0011: an unverifiable survivor must fail the gate.
                raise GateFailure(
                    f"mutant {mutant_id} could not be applied for independent "
                    f"verification (exit {applied.returncode}); fail-closed"
                )
            status = "killed-on-verify" if _suite_fails(run) else "survived"
            results.append(
                {"id": mutant_id, "target": target_file, "kind": kind,
                 "mutation": added[:160], "status": status}
            )
    finally:
        for target, blob in snapshots.items():
            (ROOT / target).write_bytes(blob)
        _clear_bytecode()
        # source is restored in-memory above; the crash-safe snapshot is no
        # longer needed and is removed so a clean run leaves the tree pristine.
        shutil.rmtree(SNAPSHOT_DIR, ignore_errors=True)
    verified = [r for r in results if r["status"] == "survived"]
    logic = [r for r in verified if r["kind"] == "logic"]
    accepted = [r for r in verified if r["kind"] != "logic"]
    killed_on_verify = [r for r in results if r["status"] == "killed-on-verify"]
    killed = total - len(verified)
    # full accounting: every discovered mutant must be dispositioned
    accounted = killed + len(accepted) + len(logic)
    if accounted != total:
        raise GateFailure(
            f"mutant accounting mismatch: killed({killed}) + accepted("
            f"{len(accepted)}) + logic-survivors({len(logic)}) != total({total})"
        )
    evidence = {
        "tool_exit_code": run_result.returncode,
        "summary": {
            "total": total,
            "killed": killed,
            "killed_on_independent_verify": len(killed_on_verify),
            "logic_survivors": len(logic),
            "accepted_non_behavioural_survivors": len(accepted),
            "accounting": f"{killed} killed + {len(accepted)} accepted + "
                          f"{len(logic)} logic survivors = {total}",
        },
        "verified_survivors": results,
    }
    summary = (
        f"mutation gate (fail-closed): {killed}/{total} mutants killed "
        f"({killed / total:.1%})\n"
        f"mutmut run exit code: {run_result.returncode} (result flags)\n"
        f"verified survivors: {len(verified)} "
        f"(logic: {len(logic)}, accepted non-behavioural: {len(accepted)})\n"
        f"logic survivors (gate fails unless 0): {[r['id'] for r in logic]}\n"
        f"accepted non-behavioural survivors (ADR-0011 §3, see JSON): "
        f"{[r['id'] for r in accepted]}\n"
        f"accounting: {evidence['summary']['accounting']}\n"
    )
    EVIDENCE.mkdir(exist_ok=True)
    (EVIDENCE / "G07-mutation.json").write_text(
        json.dumps(evidence, indent=1) + "\n", encoding="utf-8"
    )
    (EVIDENCE / "G07-mutation-summary.txt").write_text(summary, encoding="utf-8")
    print(summary)
    if logic:
        raise GateFailure(f"verified logic survivors: {[r['id'] for r in logic]}")
    return evidence


def main() -> int:
    # `--restore` is an operator escape hatch: heal source from a snapshot left
    # by a killed run, without running the (long) gate.
    if "--restore" in sys.argv:
        healed = restore_snapshot()
        print("restored source from mutation snapshot" if healed
              else "no mutation snapshot to restore; source unchanged")
        return 0
    try:
        execute()
    except GateFailure as failure:
        EVIDENCE.mkdir(exist_ok=True)
        message = f"G07 FAIL (fail-closed): {failure}\n"
        (EVIDENCE / "G07-mutation-summary.txt").write_text(message, encoding="utf-8")
        print(message, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
