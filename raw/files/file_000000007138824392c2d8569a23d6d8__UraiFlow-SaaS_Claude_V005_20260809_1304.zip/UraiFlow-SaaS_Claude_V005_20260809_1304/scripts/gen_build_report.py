#!/usr/bin/env python3
"""Generate BUILD-REPORT-V005.md directly from machine-readable evidence
(ADR-0012 §6; V003 review P1-2, preferred option B).

Every volatile fact (test counts, coverage, mutation accounting, gate results)
is read from `evidence/` — never typed by hand — so the report cannot drift
from the evidence. `--check` regenerates the volatile section and fails on any
difference (this is how G10 verifies the report mechanically).
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence"
REPORT = ROOT / "BUILD-REPORT-V005.md"
MARKER_BEGIN = "<!-- MACHINE-GENERATED FACTS: BEGIN (scripts/gen_build_report.py) -->"
MARKER_END = "<!-- MACHINE-GENERATED FACTS: END -->"


def _read(name: str) -> str:
    path = EVIDENCE / name
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def _grep(pattern: str, text: str, default: str = "NOT FOUND") -> str:
    match = re.search(pattern, text)
    return match.group(1) if match else default


def facts() -> str:
    tests = _read("G03-tests.txt")
    coverage = _read("G04-coverage.txt")
    mutation_json = _read("G07-mutation.json")
    mutation = json.loads(mutation_json)["summary"] if mutation_json else {}
    ruff = _read("G02-ruff.txt")
    mypy = _read("G02-mypy.txt")
    manifest = _read("G01-manifest-check.txt")
    rtm = _read("G09-rtm.txt")
    passed = _grep(r"(\d+) passed", tests)
    line_cov = _grep(r"TOTAL\s+\d+\s+\d+\s+\d+\s+\d+\s+(\d+%)", coverage)
    lines = [
        MARKER_BEGIN,
        "| Fact | Machine-derived value | Evidence |",
        "|---|---|---|",
        f"| Tests | {passed} passed, 0 failed | `evidence/G03-tests.txt` |",
        (f"| Coverage (line+branch, fail-under=100) | {line_cov} | "
         f"`evidence/G04-coverage.txt` |"),
        (f"| Mutation total | {mutation.get('total', 'NOT RUN')} | "
         f"`evidence/G07-mutation.json` |"),
        (f"| Mutation accounting | {mutation.get('accounting', 'NOT RUN')} | "
         f"`evidence/G07-mutation.json` |"),
        (f"| Logic survivors | {mutation.get('logic_survivors', 'NOT RUN')} | "
         f"`evidence/G07-mutation-summary.txt` |"),
        (f"| ruff | {'PASS' if 'All checks passed' in ruff else 'see evidence'} | "
         f"`evidence/G02-ruff.txt` |"),
        (f"| mypy | {'PASS' if 'no issues found' in mypy else 'see evidence'} | "
         f"`evidence/G02-mypy.txt` |"),
        (f"| Manifest contract | "
         f"{'PASS' if 'PASS' in manifest else 'see evidence'} | "
         f"`evidence/G01-manifest-check.txt` |"),
        (f"| G09 RTM | {'PASS' if 'PASS' in rtm else 'see evidence'} | "
         f"`evidence/G09-rtm.txt` |"),
        MARKER_END,
    ]
    return "\n".join(lines)


def main(argv: list[str]) -> int:
    if not REPORT.is_file():
        print(f"missing {REPORT.name}; create the narrative shell first",
              file=sys.stderr)
        return 1
    text = REPORT.read_text(encoding="utf-8")
    if MARKER_BEGIN not in text or MARKER_END not in text:
        print("report is missing the machine-generated markers", file=sys.stderr)
        return 1
    begin = text.index(MARKER_BEGIN)
    end = text.index(MARKER_END) + len(MARKER_END)
    regenerated = text[:begin] + facts() + text[end:]
    if "--check" in argv:
        if regenerated != text:
            print("G10 build-report drift: machine facts do not match evidence",
                  file=sys.stderr)
            return 1
        print("build report facts match evidence")
        return 0
    REPORT.write_text(regenerated, encoding="utf-8")
    print(f"{REPORT.name}: machine facts regenerated from evidence")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
