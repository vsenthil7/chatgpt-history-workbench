# AT-Life Operating System (AT-LOS) - V031

**Release:** `AT-LifeOperatingSystem_ContentProjectionFidelityAndIngestionFreeze_Claude_V031_20260809_1730`
**Prepared by:** Claude · **09-Aug-2026 17:30 BST** · Deliberately narrow — exactly your three findings, nothing reopened, **no `at-evidence` code**. **Proposed ingestion FREEZE.**

All three findings reproduced byte-for-byte on pristine V030 before any code was touched: Case A (citations + meta vanishing), Case B (untyped `extra` vanishing), and Case C — the sharpest one — the NaN hidden in a sibling field sailing through at 0 issues because the whole block had left the structured subset before `_non_finite_at` ran.

## F01 — projection fidelity is mechanical, not a field list

Exactly the architecture you prescribed: a textual block has two representations. Keys exactly `{type?, text}` **are** the consumed projection — fully consumed by definition, no redundant storage (your sanctioned optimisation, now an explicit contract). A block carrying **any** additional key is projected to `Event.text` **and preserved whole** in the existing structured channel (`Event.meta["structured_content"]`) — one preservation path, one persistence path, and crucially the preserved block **re-enters the non-finite boundary walk**, so Case C now rejects with locator `…#message:0#content`, raw `NaN`, path `content[0].meta`. The invariant is your words: *unconsumed keys never silently disappear.* It composes with the D-118 dual-representation contract (equal and disagreeing top-level text both tested with siblings present), and the empty-projection edge is defined: text `""` beside siblings-only is a located rejection carrying the full content. ChatGPT parts were verified already safe — non-string parts are never projected, only preserved — so the class existed only where projection existed. Ten tests from your list; the mutant re-creating the projection loss dies. RTM-139; RTM-118's note widened per your instruction.

## F02 + F03 — the title is current state, and the gate now knows it

Both stale titles confirmed in the shipped V030 artefacts. Root cause traced exactly as you did: `"Index"` in `HISTORICAL_SHEET_SUFFIXES` short-circuited `stale_version_failures` for every `00_Index` sheet — and even without the exemption, the stale scan's "current"-word precondition can never see a bare title. So the fix is both of your prescriptions: the generic Index exemption is **removed** (historical rows inside an index carry the structural `HISTORICAL` prefix like anywhere else), and the invariant is **explicit and positive** — `workbook_title_failures()`: current workbook filename release == declared `00_Index` title release, with a missing declaration also failing. It's a pure function tested directly with the **exact two V030 defect titles** as permanent negative regressions (the RTM-128 pattern), wired into `audit_package` where the workbooks are open. Staging now writes both titles **from the release source** — this package's workbooks introduce themselves as V031 because `release_facts.json` says so, not because anyone typed it. The mutant re-inserting the Index exemption dies. RTM-140.

## Gates (deterministic, this build; independent rerun required)

**523 passed** / 1 by-design skip of **524 deterministic tests** · 100% on **1429 statements** / 436 branches · **49/49 mutants killed** (2 new: F01 projection loss, F03 Index exemption) · `ruff` and `mypy --strict` clean via exact CI commands · RTM **140 rules: 136 + 1 + 3** (RTM-139/140 added) · blocking package audit clean — now including the title invariant that would have rejected V030's own workbooks. Environment-dependent: 2 integration tests collected, 2 passed in this build. Identity, locators, accounting: **untouched** — Event ids differ from V030 only where V030 was dropping data.

## Next

Your independent V031 review → on pass: **INGESTION FROZEN → AT-004 to frozen/maintenance → `at-evidence` (AT-012) starts immediately.** Further ingestion change requires a demonstrated production data-loss, identity, security or raw-exception defect. Real LLM corpora, Layer-D fuzz and strict duplicate-key JSON stay named gaps that cannot generate V032 alone. `at-consent` still needs **DQ-012 and DQ-013**. **AT-056 remains Not started.**
