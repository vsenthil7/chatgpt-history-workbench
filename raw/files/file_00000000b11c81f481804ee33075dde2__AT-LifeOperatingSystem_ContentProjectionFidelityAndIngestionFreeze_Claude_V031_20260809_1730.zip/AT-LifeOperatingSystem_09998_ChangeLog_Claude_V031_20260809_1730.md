# AT-LOS V031 Change Log

**Release type:** content projection fidelity and ingestion freeze. ADR-031, amending ADR-026 and ADR-030. Deliberately narrow, responding to the V030 independent deep review (F01–F03) exactly. No identity changes, no accounting changes, no provider hardening reopened, no `at-evidence` code.

## at-ingest-llm-export

**Projection fidelity (F01).** A Claude textual block with keys exactly `{type?, text}` is the consumed projection — fully consumed by definition. Any additional key → projected to text **and** preserved whole in `Event.meta["structured_content"]`, re-entering the non-finite boundary walk: the hidden-NaN case now rejects with `content[0].meta` and the offending value. Composes with the D-118 dual-representation contract; the empty-projection + siblings edge is a located rejection carrying the full content. The structured-rejection message now says "block(s) not fully consumable as text". ChatGPT parts verified already safe (non-string parts never projected).

## Governance and tooling

**Workbook titles (F02).** Both workbook `00_Index` titles are populated from the release source at staging, never copied literals.

**Gate (F03).** `"Index"` removed from `HISTORICAL_SHEET_SUFFIXES`; new pure function `workbook_title_failures()` asserts filename release == declared title release (missing declaration fails too), called in `audit_package`; the exact two V030 defect titles are permanent negative regressions; `V030ReviewDisposition`/`V031ReviewDisposition` added to the append-only-record exemptions.

## RTM, tests, mutation

RTM-139 (projection fidelity), RTM-140 (title invariant); RTM-118 note widened. **140 rules: 136 + 1 + 3.** 12 new tests (10 projection + 2 gate); **523 of 524 deterministic passing** (1 by-design skip), 100% on **1429 statements / 436 branches**; **49/49 mutants** including two re-creating V030 F01/F03; `ruff` and `mypy --strict` clean via exact CI commands. Integration: 2 collected, 2 passed in this build environment.

## Documents and workbooks

Standard: V031 rules (D-123, D-124). Project Memory: D-123/D-124; V031 version history; V030 CURRENT COUNT demoted; V031 CURRENT COUNT from `release_facts.json`; **title V031 from the release source**. Test Strategy: derived sheets regenerated (140 RTM, 49 mutants, V031 facts); `23_V030ReviewDisposition` marked historical; new `24_V031ReviewDisposition` with the F01–F03 table; **title V031 from the release source**.

## Decisions

D-123 partial projection preserves what it does not consume · D-124 a workbook's title is current state, asserted positively

## Open

DQ-004, DQ-012, DQ-013, DQ-014, DQ-016 open · named gaps unchanged and non-blocking: real LLM corpora, Layer-D arbitrary-JSON property coverage, strict duplicate-key JSON · **on independent V031 pass: ingestion FROZEN, AT-004 frozen/maintenance, `at-evidence` (AT-012) immediately** · **AT-056 Not started**.
