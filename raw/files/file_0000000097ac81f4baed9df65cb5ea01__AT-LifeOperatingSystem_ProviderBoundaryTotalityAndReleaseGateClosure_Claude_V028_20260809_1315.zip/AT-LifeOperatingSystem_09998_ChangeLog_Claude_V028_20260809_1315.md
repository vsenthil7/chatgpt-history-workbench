# AT-LOS V028 Change Log

**Release type:** provider boundary totality and release-gate closure. ADR-028, amending ADR-026 and ADR-027. Corrective only, responding to the V027 independent deep review (F01–F11). No feature tranche, no `at-evidence` code.

## at-ingest-llm-export (F01–F04, F07)

**Traversal shares validation's graph (F01).** `_current_branch` consumes only the validated node set; a `current_node` naming a rejected node is a diagnostic, never an `AttributeError`.

**Timestamps are total (F02).** One guarded conversion handles NaN, ±Infinity, out-of-range epochs, bool (no longer silently epoch-1) and malformed ISO; every unusable value becomes an issue at `…#message.create_time` carrying the offending value (F07). The first mutant survived because a redundant `isfinite` pre-check duplicated the `except` — the guard was consolidated per the V023 must-change-behaviour lesson and the mutant repointed.

**Container tri-state (F03).** `mapping`/`chat_messages`/`entries` types are validated before defaulting or iteration; the `or {}`/`or []` collapses are deleted. Wrong type — falsy or truthy — is one conversation-granularity rejected unit with a field locator; valid empty is 0 units, 0 issues.

**Absent content is malformed; explicit emptiness is valid (F04, ADR-028 D3).** No `content` / no `parts` / neither `text` nor `content` → rejected units. `parts: []` / `text: ""` → valid empty Events. Preserved in both directions.

## CI and release gates (F05, F06, F08, F11)

Bootstrap job path corrected to `tests/internal/integration` and the exact command executed (2 passed); RTM-127 guard collects every workflow pytest path. `stale_version_failures` is an importable, structurally-classified function — historical means sheet suffix or `HISTORICAL` line prefix, never prose tokens — and the exact V026 phrase is a permanent must-fail regression (RTM-128). Gate 2e audits shipped Metadata JSONs against derived facts and the RTM NOT ENFORCED set. `build_release.py <release-dir>` runs the package audit as a blocking release-assembly step, executed for this package; `ci.yml` states the plain-CI limit.

## RTM, tests, mutation

RTM-124 (timestamp totality), RTM-125 (container tri-state), RTM-126 (absent content rejected), RTM-127 (CI paths collect), RTM-128 (permanent stale-phrase regression); RTM-123 note records the F07 overclaim and its test now covers timestamp and container classes. **128 rules: 124 + 1 + 3.** 22 new tests; 457 passing, 100% on 1359 statements / 390 branches; **37/37 mutants** including six re-creating F01–F06. `ruff` and `mypy --strict` clean via the exact CI commands.

## Documents and workbooks (F09, F10)

ADR-026 annotated in place at the superseded `candidate == events + issues` mechanism; header marked amended by ADR-027. Project Memory: V027 CURRENT COUNT demoted to a historical snapshot; the V028 CURRENT COUNT states the deterministic figure and declares integration per-environment. Test Strategy workbook: derived sheets regenerated (128 RTM, 37 mutants); new `21_V028ReviewDisposition` sheet with the full F01–F11 table.

## Decisions

D-109 total boundary; one validated graph · D-110 container tri-state; absence is not emptiness · D-111 structural gate classification; CI commands executed exactly; metadata self-audited · D-112 package audit blocks assembly; deterministic figure in the current snapshot; supersession annotated in place

## Open

DQ-004, DQ-012, DQ-013, DQ-014, **DQ-016 (RTM-120 NOT ENFORCED — no external publication)** · real LLM export corpus not yet verified (named gap) · `at-evidence` after independent V028 review · **AT-056 Not started**.
