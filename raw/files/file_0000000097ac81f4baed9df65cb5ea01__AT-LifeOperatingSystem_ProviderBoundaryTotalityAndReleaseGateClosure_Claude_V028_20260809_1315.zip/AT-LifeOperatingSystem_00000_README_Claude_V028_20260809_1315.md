# AT-Life Operating System (AT-LOS) - V028

**Release:** `AT-LifeOperatingSystem_ProviderBoundaryTotalityAndReleaseGateClosure_Claude_V028_20260809_1315`
**Prepared by:** Claude · **09-Aug-2026 13:15 BST** · Corrective only — no feature tranche, **no `at-evidence` code**.

## Gates — every one executed with the exact CI command

```
DETERMINISTIC (the package claims, reproducible from the pristine repo zip):
  deterministic suite              456 collected: 455 passed, 1 by-design skip
  coverage                         1359 statements, 390 branches, 100% line and branch
  mutation regression              37/37 killed (6 new mutants re-create F01-F06)
  ruff                             clean   (exact CI command: ruff check packages tests tools verification)
  mypy --strict                    clean   (exact CI command: mypy --strict packages/*/src)
  release_check + package audit    0 failures; the package audit ran as a BLOCKING
                                   build_release step against this assembled package

ENVIRONMENT-DEPENDENT (declared per-environment, never a universal claim):
  integration/bootstrap            2 collected; exact CI command executed:
                                   python -m pytest tests/internal/integration -q
                                   -o addopts="" -m integration  →  2 passed
  Reference build environment      458 collected: 457 passed, 1 skipped
  Your V027 environment observed   434/2 — same deterministic core, one more
                                   environment-dependent integration skip.

RTM   124 passing + 1 skipped + 3 not enforced (RTM-120, RTM-14, RTM-15) = 128
packages 0.19.0 · ADR-001..028
```

## Your five blockers — each reproduced, fixed, tested, and mutated

**F01 — CLOSED.** Your exact probe (`mapping={"n1":"BAD"}`, `current_node="n1"`) crashed because validation and traversal disagreed about the graph: `_validate_graph` rejected the node and `_current_branch` walked the raw mapping anyway. Traversal now consumes **only the validated graph**. The probe yields the node rejection (`raw "BAD"`) plus a `#current_node` diagnostic, candidate 1, no exception. Mutant restoring the raw-graph walk: killed.

**F02 — CLOSED.** `_as_utc` is total: NaN, ±Infinity, ±huge epochs, bool (which V027 silently accepted as epoch-1 — your note was right), and malformed ISO all become issues at `…#message.create_time` carrying the offending value; a timezone-aware ISO stays canonically comparable. Eight parametrised adversarial cases. One consolidated guard rather than a redundant pre-check — my first mutant *survived* because `isfinite` duplicated the `except`, which is itself the V023 lesson, so the guard was consolidated and the mutant repointed at the real `except` clause: killed. (RTM-124)

**F03 — CLOSED.** Container types are validated **before** any defaulting or iteration; the `or {}` / `or []` collapses are gone. All six of your probes — `mapping=[]`, `mapping=""`, `chat_messages={}`, `chat_messages="ab"`, `entries={}`, `entries="ab"` — are now **one rejected unit at conversation granularity** with `#mapping`/`#chat_messages`/`#entries` locators and the offending value as raw; no silence, no per-character fictional units. Valid empty containers are 0 units, 0 issues — the tri-state (missing / valid-empty / wrong-type) is explicit. (RTM-125, ADR-028)

**F04 — CLOSED.** The contract is decided and written down (ADR-028 D3): **absent content is malformed; explicit emptiness is valid.** No `content`, `content` without `parts`, and neither `text` nor `content` are rejected units with field locators; `parts: []` and `text: ""` are valid empty utterances. Your exact ChatGPT and Claude probes both yield rejections now. (RTM-126)

**F05 — CLOSED.** The workflow path is corrected to `tests/internal/integration`, and I executed the **exact shipped CI command**: 2 passed. A new guard (RTM-127) extracts every pytest path from `ci.yml`, asserts it exists, and runs `--collect-only` on it — the local suite passing is no longer treated as evidence about separately-scoped CI commands. A mutant restoring the broken path is killed by that guard.

## F06 — you were right that my "structural" fix wasn't

The V027 gate's marker list contained `"snapshot"`, so it skipped `CURRENT COUNT (V025 - the only current snapshot)` — the founding defect. The marker list is deleted. Classification is now genuinely structural: a sheet is historical by suffix, or a line is historical by starting with the workbook's `HISTORICAL` label; mid-sentence tokens exempt nothing. The logic is an importable function, and **the exact V026 phrase is a permanent negative regression** (RTM-128) — it must fail in every future release, verified by test and by a mutant that re-adds the `"snapshot"` bypass: killed.

## The rest

- **F07** — timestamp rejections carry `#message.create_time` locators and the offending value (your `create_time="bad"` probe: raw `"bad"`, not the message text); RTM-123's named test now exercises field-shape, timestamp **and** container classes, and its note records the overclaim.
- **F08** — this package's metadata line is *generated* from `rtm.toml` (`3 RTM rules unenforced: RTM-120, RTM-14, RTM-15`), and release gate 2e audits every shipped Metadata JSON: gates vs derived facts, and any "unenforced" claim vs the actual NOT ENFORCED set.
- **F09** — the Project Memory CURRENT COUNT now states the **deterministic** figure (455/456 + 1 by-design skip) and declares the integration result per-environment; the 435-style aggregate is labelled as the reference environment's result.
- **F10** — ADR-026 carries a local supersession annotation at the exact `candidate == events + issues` paragraph, pointing to ADR-027, and its header is marked amended. Two Accepted ADRs no longer read as simultaneously normative.
- **F11** — `python tools/build_release.py <release-dir>` runs the full package audit and **blocks**; it ran against this assembled package. `ci.yml` states plainly that plain CI audits the repository only, because no outer package exists at that stage.

Decisions D-109–D-112 · ADR-028 · RTM-124–128 · 22 new tests · 6 new mutants. Full F01–F11 disposition with exact references: Test Strategy workbook sheet `21_V028ReviewDisposition` and the metadata.

## What this release claims, exactly

Boundary **totality** is demonstrated against the adversarial fixture classes now in the suite — hostile timestamps, wrong-type containers falsy and truthy, absent vs explicit-empty content, rejected-node traversal, multi-issue units, sibling independence, full rejection provenance — plus the real 500-event WhatsApp corpus. It is **not** a claim about real LLM provider exports: that corpus remains a named gap. `at-evidence` starts only after your independent V028 review.

## Next

Your V028 review. Then `at-evidence`. `at-consent` still needs **DQ-012 and DQ-013**. **AT-056 remains Not started.**
