# AT-LOS V023 Change Log

**Release type:** actor identity and conversation-graph integrity. ADR-023, amending ADR-022. **Closes DQ-015.**

## Core

`LabelKind` (DISPLAY_NAME / ROLE_ONLY) and `Participant.is_identity_bearing`, requiring a HUMAN actor **and** a display name. `Event.meta` validated JSON-compatible at construction; non-string attachment names rejected.

## at-ingest-llm-export

All role labels are ROLE_ONLY. ChatGPT node graph preserved: `node_id`, `parent_id`, `on_current_branch` from `current_node`; no branch guessed when none is named; Claude carries no node metadata.

## at-identity

Refuses any label that is not identity-bearing, with a message naming why.

## at-cli

`revoke` command. Import reports identifiable people, human roles without a name, and non-human actors separately.

## Documentation and tests

ARCHITECTURE §A1 generated from `architecture.toml` · MT-006 performs the revocation it claims and no longer says packages "do not exist" · MT-007 no longer claims authority precedence · `ResourceWarning` treated as an error · RTM-98 to RTM-103 · 21 mutation cases.

## Decisions

D-088 human-authored is not human-identifiable · D-089 the conversation graph is preserved · D-090 Event.meta JSON contract · D-091 drift-prone factual sections are generated · D-092 manual evidence must not inherit automated claims

## Open, and stated

External documentation publication boundary (Partial, since V018) · DQ-004, DQ-012, DQ-013, DQ-014 · **AT-056 Not started**.
