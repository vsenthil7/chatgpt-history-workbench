# AT-Life Operating System (AT-LOS) - V023

**Release:** `AT-LifeOperatingSystem_ActorIdentityAndConversationGraphIntegrity_Claude_V023_20260808_2158`
**Prepared by:** Claude · **08-Aug-2026 21:58 BST**

```
V023 — ActorIdentityAndConversationGraphIntegrity

pytest                 384 passed, 1 skipped
coverage               1222 statements, 324 branches, 100% line and branch
architecture guards    52 collected
integration (real venv) 2 collected
mutation regression    21/21 killed
RTM                    100 passing + 1 skipped + 2 not enforced = 103
modules / products     11 declared, 2 product applications
test suites            17 built, 4 declared not built (3 internal, 1 external)
documentation          44 pages, 2 publication profiles
packages measured      at-cli, at-identity, at-ingest-core, at-ingest-llm-export, at-ingest-whatsapp, at-store
platform version       0.14.0

Facts measured: outcomes=True coverage=True
```

## You were right, and I was wrong to announce it as fixed

V022's README said AI role labels no longer became people. **`assistant` was
fixed. `human` and `user` were not** — and I shipped the claim anyway. You
reproduced it against the fixture in my own package.

That is now a rule in the Standard: *a release note must be checked against the
behaviour it describes, not the change that was intended.*

## Human-authored is not human-identifiable

`ActorKind` answered *was this written by a person?* It never answered *does the
source say which person?*

| Source | label | ActorKind | LabelKind | Identity-bearing |
|---|---|---|---|---|
| WhatsApp | `Alice` | HUMAN | DISPLAY_NAME | **yes** |
| Claude | `human` | HUMAN | ROLE_ONLY | no |
| ChatGPT | `user` | HUMAN | ROLE_ONLY | no |
| Claude | `assistant` | MODEL | ROLE_ONLY | no |

Importing the Claude fixture now reports **0 identifiable people, 1 human role
without a name, 1 non-human actor** and an empty unresolved set. WhatsApp still
yields Alice and Bob.

## DQ-015 closed — the conversation graph is preserved

A ChatGPT export is a **graph**. A regenerated answer is a **sibling**, not a
later message. V022 sorted by timestamp, so two competing answers became apparent
dialogue — and evidence built on that would have read a sequence the user never
saw.

Every node is kept, with `node_id`, `parent_id` and `on_current_branch` derived by
walking parents from `current_node`. **Nothing is discarded and nothing is
guessed**: where no current node is named, no branch is invented. Claude exports
carry no node metadata, because they are ordered lists and inventing ids would
imply structure the source does not have.

## Three more

**`Event.meta` is JSON-compatible, validated at construction.** The in-memory
store accepted a `datetime` SQLite rejected — the same Event valid in one
repository and invalid in another. An unstorable Event can no longer be *built*.

**The capability statement is generated.** ARCHITECTURE said *"4 packages
implemented, 7 planned"* beside a generated table listing six. §A1 now comes from
`architecture.toml`.

**Manual tests prove what they claim.** `at-cli revoke` added, so MT-006 actually
revokes: 4 events orphaned, purged, **import occurrences still 2**. MT-007 no
longer claims authority precedence it never attempted.

Suite is `ResourceWarning`-clean, treated as an error.

## What remains open

**The external documentation publication boundary**, since V018. `nav` omission is
not exclusion. Marked Partial; I am not claiming otherwise.

## at-evidence is unblocked

Both pre-evidence blockers are closed. `at-consent` still needs **DQ-012 and
DQ-013** from you.

**AT-056 remains Not started.**
