# Project Memory Standard

**AT-LOS | Claude | V023 | 08-Aug-2026 21:58 BST**
**Supersedes:** the V022 standard. **Fifteen registers across sixteen worksheets** — `00_Index` is not a register.

---

## 1. Authority precedence (ADR-011, D-046)

Three absolute "authority" rules were previously in force at once and gave no answer when all three were consulted. One ordered list replaces them:

```
1. the code                  what the packages actually do
2. architecture.toml         declared layers, imports, module state
3. executable tests          enforce 1 against 2
4. generated documents       docs/ARCHITECTURE.md §B §C - never hand-edited
5. hand-written documents    README, READ_THIS_FIRST, TEST_STRATEGY
6. Project Memory            decisions, planning, scope, capability claims
```

**Project Memory cannot override machine-verified implementation state.** If a register says Implemented and nothing is on disk, the register is wrong. Project Memory remains authoritative for what code cannot answer: why a decision was taken, what is deferred, what must not be built.

## 2. The fifteen registers

| Tab | Holds | Cannot hold |
|---|---|---|
| 01_ActiveSprint | Work being executed | Anything without a Decision Log reference |
| 02_NextSprint | Decided, not started | Anything without a named unblocker |
| 03_ParkingLot | Ideas kept, not worked | Anything without a trigger **and an expiry** |
| 04_ResearchRepository | Needs evidence before planning | Anything already decided |
| 05_DecisionLog | Every decision, reason, date, owner | Edits. Reversals are new rows |
| 06_DeferredDecisions | **CLOSED.** Migrated to 13_DecisionQueue | New rows of any kind |
| 07_Assumptions | Silent dependencies | Anything without a named failure consequence |
| 08_LessonsLearned | What each version got wrong | Praise |
| 09_FutureVision | Long-term IP | Dates |
| 10_HallucinationRegister | True state of every capability | Aspirational states |
| 11_VersionHistory | Added, removed, why, still open | Retrofitted entries |
| 12_Archive | Completed and rejected | Deletions |
| 13_DecisionQueue | Decisions needed, intentionally postponed | A row missing any of the five mandatory fields |
| 14_SprintTracker | Live task board with proof of completion | A Done row whose Register column says No |
| 15_NamingRegister | Naming candidates and rejections | A claim without a verification level and source |

## 3. Rules

1. **Nothing is deleted.** Completed and rejected work moves to Archive with a reason.
2. **Every parked idea carries a review trigger and an expiry.**
3. **Every register row has an owner.**
4. **Nothing enters Active Sprint without a Decision Log entry.**
5. **The Decision Log is append-only.** Reversals are new rows; the original is marked Superseded.
6. **Every architecture change states why**, in the Decision Log and an ADR.
7. **No capability may be described above its Hallucination Register state.**
8. **Version History is written at release**, never reconstructed later.
9. **One review per month**, not per version.
10. **External factual claims state their verification level and source** (D-026 as narrowed by D-035). Applies to claims about the outside world, not internal planning rows.
11. **A postponed decision needs five fields**: why it matters, trigger, owner, latest date, delay cost.
12. **A task is not Done until its Hallucination Register row carries an immutable implementation reference** (D-049) - a commit SHA where Git is available, otherwise a package version plus an ADR or RTM id. The rule does not say "commit hash" while storing something else.
13. **Fifteen registers is the ceiling** (D-023).
14. **Architecture lives in the repository, with one machine-readable source** — `architecture.toml` — from which documents are generated (D-039). Hand-editing a generated table fails the build.
15. **Precedence resolves disagreement** (§1), replacing the old absolute "test wins" and "Project Memory wins" rules.
16. **A capability state names what it is, not what it is intended to be** (D-040). A docstring guarantee that the code contradicts is the same failure: V012's `ImportOccurrence` said it "never deduplicates" while an identical tuple collapsed.
17. **Release figures are measured, never estimated** (D-052). Fact derivation refuses to produce numbers from a failing suite. V012 computed passed tests as collected-minus-one, so a red suite could still yield a clean-looking fact set.
18. **A concept name must not answer a question it cannot answer** (D-051). `owner_ref` read like a consent answer; it recorded who imported a file. Renaming it `importer_ref` was half the fix — the other half was building the second graph it was standing in for. An in-memory dictionary is not persistence. A regression harness is not a mutation baseline. Line coverage of existing code is not functional coverage (D-045).
19. **Figures that appear in more than one artefact are derived from code, not typed** (D-046, D-050). `tools/release_facts.py` derives them, `tools/release_check.py` asserts **defined machine-verifiable invariants and generated fact blocks** — not the semantics of every sentence, and `tools/build_release.py` writes `release_facts.json` from which the release workbooks are generated. Blocking gate (RTM-23).
20. **Evidence recorded at task completion is historical.** Sprint Tracker column O says what was true when a row closed. Current totals live in the Hallucination Register and the Test Strategy workbook, both derived from code.

## 4. What this guards against

Six failures, all of which have happened here:

- **Rediscovery.** Q-001 raised as Critical in V002 and V003, left open in both.
- **Capability drift.** V003 discussed conversation reconstruction as if it were software.
- **Scope substitution.** Three packages in thirteen hours, one completed task — producing a package.
- **Asserted enforcement.** V006 said CI enforced the architecture rules; there was no CI. ADR-003 named `ruff` and `mypy --strict`; neither ran until V010.
- **Drift under a guard that did not cover it.** V008 guarded the README; in V009 the *authoritative* architecture document went a version stale.
- **Drift in the files that prevent drift.** V010 generated the architecture document, then shipped an onboarding file with two contradictory adapter rules and a test workbook still reporting V009 figures.
- **A gate described above what it checked.** V011's consistency checker scanned three regex patterns across four Markdown files and reported everything clean while five stale facts survived. Rules 17 and 18 exist because of this.

## 3a. Rules added in V023

**A release note must be checked against the behaviour it describes, not the change that was intended.** V022's README announced that AI role labels no longer became people. `assistant` was fixed; `human` and `user` were not, and the claim shipped anyway.

**Human-authored does not imply human-identifiable** (D-088). Whether a person wrote something and whether the source says *which* person are different questions.

**A factual section that can drift is generated, not written** (D-091). Pattern-matching stale phrases could not keep pace with capability change.

**Manual evidence must not inherit claims from automated evidence** (D-092). MT-006 claimed a revocation it never performed; MT-007 claimed authority precedence it never attempted.

**A mutation case must be verified to change behaviour.** A mutant that disabled half a compound condition survived, which looked like a test gap and was not.

## 3b. Rules added in V022

**A safety check must not modify what it is protecting** (D-086). Both SQLite stores created their tables and *then* refused an unsupported schema version. The check damaged the file it existed to defend.

**A state change and its audit record commit together, or neither does** (D-085). An identity that exists with no decision explaining it is worse than no audit at all, because the log now looks complete.

**A contract suite must build a fully populated object.** Ninety-two contract tests passed while durable storage dropped two `Event` fields, because no test ever set them.

**Counting starts from the raw source, not from what the parser understood** (D-087). Anything the extractor failed to recognise disappeared before it could enter the denominator, so loss reported as 100% coverage.

**Do not move forward while a reproduced blocker stays open.** V019's and V020's defects were still reproducible in V021, now with another layer built on them.

## 3b. Rules added in V021

**Where a record concerns a real person, an honest gap beats a plausible guess** (D-080). A guess presented as a resolution becomes an assertion, and everything downstream inherits it. The platform lists unresolved names and waits.

**A human decision is not undone by an automatic one** (D-081). A rule or model may not overwrite a manual decision; it raises. And a manual decision must record who made it — an unattributed override is not an override.

**An injected test double can hide an untested production path.** Every identity test injected a deterministic id factory, so the real generator was never exercised; a mutant making every id identical survived 313 passing tests. Where a factory is injected for determinism, the real one needs its own test.

**A declaration that is true only because the code does not exist yet is a liability** (D-082). `person_id` was marked unimplemented to escape recomputation, and building `at-identity` made that false.

## 3b. Rules added in V020

**A replaceable component gets a port and one shared contract suite** (D-076). Two implementations that behave differently are not substitutes, and every test that passed against the easier one would silently mean less.

**The audit trail outlives the data it justified** (D-078). Purging removes events; the record of who imported what, and when they withdrew, is kept. That is what makes a deletion defensible rather than merely done.

**Do not keep a second copy of data you have no lawful basis for** (D-077). The platform records that content with a given hash was imported; it does not retain the bytes.

## 3b. Rules added in V019

**A measure correct for one source may be meaningless for another** (D-073). `line_coverage` was right for WhatsApp and nonsense for JSON. Coverage is now reported in the source's own unit, and the wrong-unit accessor **raises** rather than returning a plausible number.

**Controls exist to make capability safe, not to replace it.** V008 to V018 added eleven consecutive releases of controls over four packages. The framework is finished; it is now used. A release that adds only controls needs a reason.

## 3b. Rules added in V018

**Anything that can drift gets a machine source before it drifts, not after** (D-068). Architecture, identity and RTM each got a manifest only after a document had gone stale. Testing got `testing.toml` first.

**Verification and documentation separate internal from external audiences** (D-069). A customer must never need pytest, mutation testing or an architecture TOML to prove the product works. Internal material is excluded from the external profile by **not being navigated to** — never by deletion or duplication (D-070).

**Every manual test states what it does not prove.** A passing test is routinely read as proof of something it never touched. MT-003 proves import provenance and proves nothing whatever about consent.

**External test material is synthetic** (D-071). Real exports are internal verification evidence, never committed, never sample fixtures.

**A missing test level stays visibly missing.** L5 system, L8 security, L9 performance and L10 UI/E2E are declared `Planned` with no path and no directory. An empty directory implies work that has not been done.

## 3b. Rules added in V017

**A rule's test must establish the whole claim the rule makes, not the part that was easy to write** (D-065). Three releases produced the same shape of mistake: RTM-24 asserted "exactly one SourceRegistration" while its test built one registration; RTM-47 asserted "exactly its documented components" while checking only that each listed component influenced the id; RTM-49 asserted "runs in a clean environment" while the test supplied the environment. **When a rule cannot be fully tested, narrow the rule — not the reading of it.**

**A structured registry must be enforced across all of it, or it is a document** (D-066). `identity.toml` declared four identities and one was linked to code. Ids are now recomputed from the file and compared to the implementation, for every identity marked implemented.

**An advertised workflow is proven in a real environment** (D-067). Not one the test constructs for itself, and never with the case skipped exactly where the environment is cleanest.

**A historical snapshot may not describe itself as current.** V016 relabelled a row `HISTORICAL SNAPSHOT (V015 - the only current snapshot)` — self-contradictory in one line, in the register that exists to prevent it.

## 3b. Rules added in V016

**Generation removes stale copies of a correct fact. It does not make the generator correct.** V015's FACTS generator hard-coded "the three implemented production packages" and listed four, propagating one wrong sentence into four authoritative documents identically.

**An allow-list states current dependencies, not future permission** (D-061). Authorising ten packages for a module that uses three, or letting a product import a delivery interface, is an architecture decision taken silently.

**An advertised command must be tested as a person would run it** (D-063). `python -m at_cli` appeared in three documents while a clean checkout answered `No module named at_cli`.

**Any figure worth stating twice is worth deriving once** (D-064). The V015 chat announcement said 99 passed and 328 statements; the package said 117 and 385.

**A tool must not be able to damage the source it tests.** A mutation run killed externally left a mutant in a reviewer's checkout. `try/finally` cannot catch `SIGKILL`, so the source is no longer written to at all.

## 3b. Rules added in V015

**A rule that keeps the architecture honest must be declared in the machine source, not described.** The single principle making this platform reusable — a generic package never depends on a product — existed only in prose for fifteen versions, because `architecture.toml` declared no product application at all (D-057).

**Documents do not contain typed figures** (D-058). Four consecutive releases leaked a stale or invalid number past an ever-cleverer regex. Documents now carry a generated FACTS block; regex only detects forbidden drift.

**A regression test must assert the specific failure it exists for.** The sentinel mutant survived twice because the test accepted either of two messages, so disabling sentinel detection still passed.

## 3b. Two rules added in V014

**A rule's test must construct the case that would break it.** RTM-24 claimed an Event resolves to exactly one `SourceRegistration`. It was false for two versions because the test created only one registration and therefore could not observe the ambiguity. A passing test is not evidence unless it could have failed.

**No release artefact may contain a not-measured value** (D-055). V013 shipped `Expected: **-1 passed, -1 skipped**` because an internal sentinel escaped into documents and every numeric check accepted only digits. Unmeasured values are now `None`, release builds refuse them, and a mutation case proves the gate fails.

## 4a. Release versioning (D-048)

Every released package takes the **next integer version**: V001, V002, ... V012. No decimal patch versions. The package released as `V010.1` is canonical project release **V011** and is retained unchanged by hash; it is not reissued. Release type - synchronisation, correction, feature - is recorded in the metadata and change log, never in the version number.

## 5. Review

**Next review due 06-Sep-2026**, with the 30-day measurement (D-010). It has not happened: today is 07-Aug-2026 and AT-056 has not started. The V012 standard said "Reviewed 06-Sep-2026" — a future date written in the past tense, which is the same class of error as a capability described above its state.
