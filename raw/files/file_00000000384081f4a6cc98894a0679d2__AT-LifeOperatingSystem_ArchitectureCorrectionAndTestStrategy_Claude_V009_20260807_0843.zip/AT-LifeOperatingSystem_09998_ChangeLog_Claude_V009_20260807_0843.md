# AT-LOS V009 Change Log

## Verification of the review

19 defects raised independently. All 19 verified against the actual files and code before acceptance. None accepted on trust; none rejected. See `08_V008DefectLog`.

## Code

**Added `at-store` (L1)** — `RawSource` (immutable, content-hash keyed, `owner_ref` mandatory), `EventStore` (append-only, deduplicating), `read_source` with an injected clock, `sha256_file`. 7 tests. RTM-12 now enforced.

**ADR-005 dependency allowlist.** `ALLOWED` per-package import sets are authoritative. `at-evidence` moved L2→L3, resolving the contradiction by correcting the layer rather than weakening the rule. Adapters importable only by `at-store` and `at-cli`. `sha256_file` moved out of L0.

**ADR-006 three ID classes.** Source-derived (deterministic, now includes `source_sha256`), logical entity (opaque, never derived from an attribute), processing-run (not reproducible, explicitly excluded from the idempotency claim). `SourceRef` rejects truncated hashes.

**ADR-007 coverage definition.** `line_coverage` and `record_coverage` named separately.

**ADR-008 workspace scope.** `workspace_ref` in `SourceRef` and `RawSource`, participating in `event_id`.

**4 new architecture guards:** allowlist compliance (RTM-16), adapter isolation (RTM-17), filesystem purity by AST (RTM-18), allowlist/layer agreement (RTM-19).

**18 parser edge-case tests**, which found two real bugs: attachment filenames with spaces, and the WhatsApp encryption notice parsed as an author.

**100% coverage gate**, CI standalone-install matrix (RTM-13), mutation job. Dead code removed from `at-store` rather than tested.

Suite: **58 passed, 1 skipped, 235 statements, 0 missed, 0.27s.**

## Documents

Added `docs/TEST_STRATEGY.md`, ADR-005..008, `verification/` artifact and regenerate script, Test Strategy workbook (9 sheets), Artifact Authority table, corrected V004 call analysis successor.

Corrected: README and READ_THIS_FIRST for the new layer model and package; Hallucination Register gains an Implementation Ref column and recomputed counts (38, not 27); RTM counts restated as 16 of 19 passing, 1 skipped, 2 not implemented; metadata test counts split into collected/passed/skipped; register count stated as 15 registers in 16 worksheets.

## Decisions

D-031 dependency allowlist · D-032 three ID classes · D-033 coverage means source lines · D-034 workspace scope in contracts · D-035 D-026 narrowed to external factual claims · D-036 100% coverage is a gate, not evidence · D-037 no E2E until a screen exists · D-038 historical artefacts are labelled, never rewritten

D-026 marked Superseded (narrowed by D-035).

## Not done, deliberately

No Playwright tests — no screens exist. No feature work. No package published. `at-conversation` still UNDECIDED. RTM-14 and RTM-15 still unenforced.

## Unchanged

V001 charter and methodology. V004 decision memo and evidence register. V004 call analysis retained unchanged by hash and labelled defective. **AT-056 still not started, day 2.**
