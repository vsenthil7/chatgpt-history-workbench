# AT-Life Operating System (AT-LOS) - V009

**Release:** `AT-LifeOperatingSystem_ArchitectureCorrectionAndTestStrategy_Claude_V009_20260807_0843`
**Prepared by:** Claude · **07-Aug-2026 08:43 BST**
**Internal codename:** AT-LOS · **Public brand:** undecided, blocked (D-022)

## 19 defects raised. 19 verified against the code. 19 real.

Every one was checked against the actual files before acceptance — none taken on trust, none rejected. `08_V008DefectLog` records the verification for each.

**The three that mattered most:**

**Defect 1 — the dependency guard contradicted the design.** The guard rejected L2→L2 imports while the spec required `at-evidence` → `at-identity`/`at-consent`. The documented architecture could not have been coded. Tests were passing because the test model encoded the wrong rule.

**Defect 3 — `at-ingest-core` called `open()`** while three documents said it touched no disk. The V008 guard checked imports only and missed a plain builtin call.

**Defect 17 — the V004 workbook had 10 invalid dashboard formulas, and my own recalc check reported it clean.** LibreOffice tolerates unquoted sheet names that Excel rejects. A passing verification tool gave a false negative and the defect shipped.

## What changed in code

**`at-store` (L1)** — immutable raw store, idempotent event store. Owns all file access. 7 tests.
**ADR-005** — explicit `ALLOWED` import map replaces numeric-only layering; `at-evidence` moves to L3; adapters importable only by `at-store` and `at-cli`.
**ADR-006** — three ID classes. `event_id` now includes the content hash; `person_id` is opaque and never derived from a name; processing-run IDs are explicitly excluded from the determinism claim.
**ADR-007** — `line_coverage` and `record_coverage`, separately named.
**ADR-008** — `workspace_ref` in contracts. Multi-tenancy still not built.

**13 architecture guards** (was 9). The new filesystem guard walks the AST for `open()` calls, not just imports.

**18 parser edge cases** — which found **two real parser bugs**: attachment filenames containing spaces, and WhatsApp's encryption notice being parsed as an author.

The domain-leakage guard caught me twice more while I worked. It works.

## Test strategy — your three asks, answered

**100% coverage: done and gated.** 235 statements, 0 missed, `--cov-fail-under=100` fails the build.

But every V008 defect lived in code that was already fully covered. **Coverage is a floor, not proof.** So: mutation testing. Four mutants injected, each re-introducing a real defect. **4/4 killed.**

**Playwright: not written, and that is the correct answer today.** There are no screens. The client surface is DQ-003, undecided. `tests/e2e/` does not exist, because an empty directory implies work. Fully specified in `06_PlaywrightPlan` — journeys, fixture rules, accessibility, preconditions — and gated on a screen existing. Recorded as `Vision only`.

**Functional and non-functional "100%":** functional is at 100%. Non-functional has no meaningful percentage — `04_NonFunctional` sets 11 numeric thresholds instead, 5 implemented. A percentage there would be a number with no referent, which is what D-018 exists to stop.

## Verification you can reproduce

`verification/whatsapp_real_export_verification.json` — source hashes, event counts, line coverage, re-ingest results. Regenerable via `verification/regenerate.py` when you hold the private files, which are not in the repository. **500 events, 0 parse issues, 100% line coverage, re-ingest added 0.**

## Artifact authority

`09_ArtifactAuthority` states which document governs. The V006 design document is labelled **HISTORICAL** — it says CI enforcement exists (false when written) and that the core touches no disk (false until V009). Not rewritten. Labelled.

The V004 call analysis is retained unchanged by hash and marked defective. Its corrected successor is in this package.

## Prove it

```bash
cd at-platform && python -m pytest -q
```
**58 passed, 1 skipped, 100% coverage, 0.27s, no network.**

## Honest status

RTM-14 and RTM-15 remain unenforced. Every module beyond L0/L1 is still a contract on paper. No GDPR basis, no consent.

**Development-ready for Sprint 2** — an engineer can now build `at-identity`, `at-consent` and `at-evidence` without hitting a contradiction in dependencies, identity, provenance or idempotency. That was the completion gate, and it is met.

**AT-056 has not started. Day 2.**
