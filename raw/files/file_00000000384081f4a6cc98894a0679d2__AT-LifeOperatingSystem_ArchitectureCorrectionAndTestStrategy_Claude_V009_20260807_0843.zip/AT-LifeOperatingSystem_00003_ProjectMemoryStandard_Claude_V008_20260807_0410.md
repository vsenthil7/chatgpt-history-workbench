# Project Memory Standard

**AT-LOS | Claude | V008 | 07-Aug-2026 04:10 BST**
**Supersedes:** the V005 standard, which described twelve registers and was stale from V007 onward.

One living document that survives across versions, across AI systems, and across gaps in attention, so that no idea is rediscovered and no capability is spoken of as if it exists.

---

## 1. The sixteen registers

| Tab | Holds | Cannot hold |
|---|---|---|
| 01_ActiveSprint | Work being executed | Anything without a Decision Log reference |
| 02_NextSprint | Decided, not started | Anything without a named unblocker |
| 03_ParkingLot | Ideas kept, not worked | Anything without a trigger **and an expiry** |
| 04_ResearchRepository | Needs evidence before planning | Anything already decided |
| 05_DecisionLog | Every decision, reason, date, owner | Edits. Reversals are new rows |
| 06_DeferredDecisions | **CLOSED.** Migrated to 13_DecisionQueue | New rows of any kind |
| 07_Assumptions | Silent dependencies | Anything without a named failure consequence |
| 08_LessonsLearned | What each version got wrong | Praise |
| 09_FutureVision | Long-term IP | Dates |
| 10_HallucinationRegister | True state of every capability | Aspirational states |
| 11_VersionHistory | Added, removed, why, still open | Retrofitted entries |
| 12_Archive | Completed and rejected | Deletions |
| 13_DecisionQueue | Decisions known to be needed, intentionally postponed | A row missing any of the five mandatory fields |
| 14_SprintTracker | Live task board with proof of completion | A Done row whose register column says No |
| 15_NamingRegister | Naming candidates and rejections | A claim without a verification level and source |

## 2. Rules

1. **Nothing is deleted.** Completed and rejected work moves to Archive with a reason. Both stay readable.
2. **Every parked idea carries a review trigger and an expiry.** A trigger alone produces an infinite backlog that feels like progress.
3. **Every register row has an owner.**
4. **Nothing enters Active Sprint without a Decision Log entry.**
5. **The Decision Log is append-only.** To reverse D-005, write a new row and mark D-005 superseded. Never edit the original.
6. **Every architecture change states why**, in the Decision Log and an ADR — not in prose.
7. **No capability may be described above its Hallucination Register state.** Binds humans and AI equally. "Planned" is not "built".
8. **Version History is written at release**, never reconstructed later.
9. **One review per month**, not per version.
10. **Every register row states its verification level and source** (D-026). Absence of a search hit is recorded as Unverified, never Verified.
11. **A postponed decision needs five fields** (D-023): why it matters, the trigger, the owner, the latest acceptable date, and the cost of delay. Without these it is drifting, not postponed.
12. **A task is not Done until its Hallucination Register row carries the commit hash.** Documentation never moves Planned to Implemented.
13. **Sixteen registers is the ceiling** (D-023). No new register without a Decision Log entry.
14. **Architecture documentation lives outside this workbook** (D-029). Module catalogue, contracts, dependency rules, RTM and technology decisions belong to the Architecture Baseline workbook and `docs/ARCHITECTURE.md`. Architecture is engineering documentation, not governance.
15. **Where a document and an executable test disagree, the test wins** (D-028).

## 3. What this standard guards against

Four failures, all of which have already happened here:

- **Rediscovery.** V002 and V003 both raised Q-001 as Critical and both left it open.
- **Capability drift.** By V003 the documents discussed conversation reconstruction and a Human State engine in language indistinguishable from working software. None existed.
- **Scope substitution.** V001–V003 produced three packages in thirteen hours with one completed task, which was producing a package.
- **Asserted enforcement.** V006 stated that CI enforced the architecture rules. There was no CI. When the enforcement was finally built in V008, it immediately found a real violation. Rule 15 and D-027 exist because of this.

## 4. Review

Reviewed 06-Sep-2026 with the 30-day measurement (D-010). If the measurement failed, the V004 stop rule applies here too: this becomes documentation of a closed project.
