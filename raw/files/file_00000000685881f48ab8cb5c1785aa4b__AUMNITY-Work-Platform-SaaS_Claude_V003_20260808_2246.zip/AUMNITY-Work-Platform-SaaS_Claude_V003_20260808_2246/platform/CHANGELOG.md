# Changelog — AUMNITY Work Platform (product code)

## 0.2.0 — 2026-08-08 (Claude build V003, corrective release after independent review)
Fixes for independently reproduced V002 defects (see
`11-issues/REVIEW-FINDINGS-V002.md`); breaking changes were acceptable because
no external consumer of 0.1.0 exists.
- BREAKING (ADR-007): `OrganisationRegistry.create_organisation(name,
  founder_display_name, founder_kind)` now atomically returns `(Organisation,
  Principal)`; `require_principal` replaced by `require_member`, which raises
  `TenantIsolationError` for unknown AND foreign principals alike.
- BREAKING (ADR-007): `WorkObjectRegistry` requires a `PrincipalDirectory`;
  every protected operation binds the acting principal to the context
  organisation, and owner/assignee references are validated as members.
- BREAKING (ADR-008): `EventEnvelope.payload` is a read-only
  `Mapping[str, str]` (defensive copy); mutation attempts raise `TypeError`.
- Toolchain contract (ADR-009): pinned `requirements-dev.txt` + dev extras;
  `run_gates.py` gains build/release modes with incoming-manifest verification;
  single canonical release gate `g11_release.py` with clean-venv full-ladder
  validation, deterministic double build and extracted-final-ZIP validation;
  artifact version read from root `ARTIFACT-VERSION`.
- G07 distinguishes dependency-unavailable / formatter-execution-error /
  baseline-not-formatted; G09 requires specific test node ids for high-risk
  tenancy rows (DW-FR-013, SaaS-002, TEN-001).

## 0.1.0 — 2026-08-08 (Claude build V002)
First implementation slice (ADR-003):
- `aumnity_contracts`: typed IDs, TenantContext, EventEnvelope, error taxonomy,
  deterministic clock/id providers, standardised source-system constants.
- `aumnity_kernel`: Organisation registry, Principal identity, Work Object
  registry with the baseline lifecycle state machine, versioning, recursive
  decomposition, minimal assignment, immutable evidence with completion policy,
  append-only tenant-scoped audit.
- In-memory adapters for all kernel ports.
- Quality gates G01–G10 as runnable evidence-producing scripts.
No public contract existed before this version; nothing is breaking.
