"""Tenant isolation and cross-tenant denial tests (RTM: SaaS-001/SaaS-002, DW-FR-013).

Gate G08 evidence: every protected read/write path denies cross-tenant access.
"""

from datetime import UTC, datetime

import pytest
from aumnity_contracts import (
    EventEnvelope,
    NotFoundError,
    PrincipalId,
    TenantContext,
    TenantIsolationError,
    WorkObjectId,
)
from aumnity_kernel import AuditLog
from aumnity_kernel.evidence import EvidenceKind
from aumnity_kernel.identity import PrincipalKind
from aumnity_kernel.organisation import OrganisationRegistry
from aumnity_kernel.workobject.model import Priority, RiskLevel
from aumnity_kernel.workobject.service import WorkObjectRegistry

pytestmark = pytest.mark.isolation


def _create(registry: WorkObjectRegistry, tenant: TenantContext) -> WorkObjectId:
    return registry.create(
        tenant,
        title="Alpha-only record",
        purpose="Isolation subject",
        work_type="generic.task",
        priority=Priority.NORMAL,
        risk_level=RiskLevel.LOW,
        owner_id=tenant.principal_id,
    ).work_object_id


def test_cross_tenant_read_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.get(tenant_b, wid)


def test_cross_tenant_transition_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.mark_ready(tenant_b, wid)


def test_cross_tenant_evidence_attachment_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.attach_evidence(
            tenant_b,
            wid,
            kind=EvidenceKind.DOCUMENT,
            uri="evidence/steal.pdf",
            content_sha256="feed",
            source_system="MANUAL",
            source_reference="steal-1",
        )


def test_cross_tenant_decomposition_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    parent = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.create(
            tenant_b,
            title="Hostile child",
            purpose="Attach to foreign parent",
            work_type="generic.task",
            priority=Priority.NORMAL,
            risk_level=RiskLevel.LOW,
            owner_id=tenant_b.principal_id,
            parent_id=parent,
        )


def test_cross_tenant_children_listing_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    parent = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.children(tenant_b, parent)


def test_cross_tenant_evidence_listing_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.evidence_for(tenant_b, wid)


def test_audit_trail_is_tenant_filtered(
    registry: WorkObjectRegistry,
    tenant_a: TenantContext,
    tenant_b: TenantContext,
    audit: AuditLog,
) -> None:
    _create(registry, tenant_a)
    _create(registry, tenant_b)
    a_entries = audit.entries_for(tenant_a)
    b_entries = audit.entries_for(tenant_b)
    assert {e.organisation_id for e in a_entries} == {tenant_a.organisation_id}
    assert {e.organisation_id for e in b_entries} == {tenant_b.organisation_id}


def test_unknown_id_is_not_found_not_isolation(
    registry: WorkObjectRegistry, tenant_a: TenantContext
) -> None:
    """ADR-006: distinct internal types; edge maps both to one external shape."""
    with pytest.raises(NotFoundError):
        registry.get(tenant_a, WorkObjectId("wob-never-existed"))


class TestPrincipalBindingRegression:
    """Regressions for V002 review Findings 1 and 2 (ChatGPT, 2026-08-08).

    ChatGPT reproduced foreign owner/assignee acceptance and mismatched
    TenantContext acceptance against the delivered V002 package. Every exploit
    reproduced there must fail here permanently.
    """

    def test_foreign_owner_rejected(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        with pytest.raises(TenantIsolationError):
            registry.create(
                tenant_a,
                title="Injection attempt",
                purpose="owner from another organisation",
                work_type="TASK",
                priority=Priority.NORMAL,
                risk_level=RiskLevel.LOW,
                owner_id=tenant_b.principal_id,
            )

    def test_foreign_assignee_rejected(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        wid = _create(registry, tenant_a)
        registry.mark_ready(tenant_a, wid)
        registry.mark_assignable(tenant_a, wid)
        with pytest.raises(TenantIsolationError):
            registry.assign(tenant_a, wid, tenant_b.principal_id)
        # denial left no partial state behind
        assert registry.get(tenant_a, wid).assignee_id is None

    def test_mismatched_context_principal_rejected_on_create(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            registry.create(
                forged,
                title="Forged context",
                purpose="principal from another organisation",
                work_type="TASK",
                priority=Priority.NORMAL,
                risk_level=RiskLevel.LOW,
                owner_id=tenant_b.principal_id,
            )

    def test_cross_tenant_acting_principal_rejected_on_read(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        wid = _create(registry, tenant_a)
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            registry.get(forged, wid)

    def test_unknown_acting_principal_rejected(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        ghost = TenantContext(tenant_a.organisation_id, PrincipalId("prn-nonexistent"))
        with pytest.raises(TenantIsolationError):
            registry.get(ghost, WorkObjectId("wob-000001"))

    def test_same_tenant_owner_and_assignee_accepted(
        self,
        registry: WorkObjectRegistry,
        org_registry: OrganisationRegistry,
        tenant_a: TenantContext,
    ) -> None:
        colleague = org_registry.create_principal(tenant_a, PrincipalKind.HUMAN, "Colleague")
        wo = registry.create(
            tenant_a,
            title="Legitimate work",
            purpose="same-organisation principals",
            work_type="TASK",
            priority=Priority.NORMAL,
            risk_level=RiskLevel.LOW,
            owner_id=colleague.principal_id,
        )
        registry.mark_ready(tenant_a, wo.work_object_id)
        registry.mark_assignable(tenant_a, wo.work_object_id)
        assigned = registry.assign(tenant_a, wo.work_object_id, colleague.principal_id)
        assert assigned.owner_id == colleague.principal_id
        assert assigned.assignee_id == colleague.principal_id

    def test_rejected_operation_writes_no_audit_event(
        self,
        registry: WorkObjectRegistry,
        audit: AuditLog,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        """Audit actor can never be foreign: binding fails before any emit."""
        before = len(audit.entries_for(tenant_a))
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            registry.create(
                forged,
                title="No audit trace expected",
                purpose="rejected before emit",
                work_type="TASK",
                priority=Priority.NORMAL,
                risk_level=RiskLevel.LOW,
                owner_id=tenant_a.principal_id,
            )
        entries = audit.entries_for(tenant_a)
        assert len(entries) == before
        member_ids = {tenant_a.principal_id}
        assert all(e.actor_principal_id in member_ids for e in entries)


class TestAuditImmutabilityRegression:
    """Regression for V002 review Finding 3: recorded history cannot be tampered."""

    def test_recorded_payload_rejects_mutation(
        self, registry: WorkObjectRegistry, audit: AuditLog, tenant_a: TenantContext
    ) -> None:
        wid = _create(registry, tenant_a)
        registry.mark_ready(tenant_a, wid)
        entry = audit.entries_for(tenant_a)[0]
        with pytest.raises(TypeError):
            entry.payload["k"] = "tampered"  # type: ignore[index]
        assert "k" not in audit.entries_for(tenant_a)[0].payload

    def test_caller_supplied_payload_dict_is_decoupled(self, tenant_a: TenantContext) -> None:
        source = {"key": "original"}
        event = EventEnvelope(
            event_type="Probe",
            organisation_id=tenant_a.organisation_id,
            actor_principal_id=tenant_a.principal_id,
            subject_id="wob-000001",
            subject_version=1,
            occurred_at=datetime(2026, 1, 1, tzinfo=UTC),
            payload=source,
        )
        source["key"] = "tampered"
        source["new"] = "injected"
        assert dict(event.payload) == {"key": "original"}
