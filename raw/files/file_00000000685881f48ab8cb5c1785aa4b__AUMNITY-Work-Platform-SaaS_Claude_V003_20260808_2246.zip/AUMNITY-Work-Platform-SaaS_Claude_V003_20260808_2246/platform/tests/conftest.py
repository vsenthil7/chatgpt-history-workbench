"""Deterministic fixtures: injected clock and sequential ids; no real time, no randomness."""

import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
for pkg in ("aumnity_contracts", "aumnity_kernel"):
    sys.path.insert(0, str(_ROOT / "packages" / pkg / "src"))

import pytest  # noqa: E402
from aumnity_contracts import SequenceIdGenerator, TenantContext, TickingClock  # noqa: E402
from aumnity_kernel import AuditLog, CriticalWorkEvidencePolicy  # noqa: E402
from aumnity_kernel.adapters.memory import (  # noqa: E402
    InMemoryAuditSink,
    InMemoryEvidenceRepository,
    InMemoryOrganisationRepository,
    InMemoryPrincipalRepository,
    InMemoryWorkObjectRepository,
)
from aumnity_kernel.identity import PrincipalKind  # noqa: E402
from aumnity_kernel.organisation import OrganisationRegistry  # noqa: E402
from aumnity_kernel.workobject.service import WorkObjectRegistry  # noqa: E402


@pytest.fixture()
def clock() -> TickingClock:
    return TickingClock()


@pytest.fixture()
def ids() -> SequenceIdGenerator:
    return SequenceIdGenerator()


@pytest.fixture()
def audit_sink() -> InMemoryAuditSink:
    return InMemoryAuditSink()


@pytest.fixture()
def audit(audit_sink: InMemoryAuditSink) -> AuditLog:
    return AuditLog(audit_sink)


@pytest.fixture()
def org_registry(clock: TickingClock, ids: SequenceIdGenerator) -> OrganisationRegistry:
    return OrganisationRegistry(
        organisations=InMemoryOrganisationRepository(),
        principals=InMemoryPrincipalRepository(),
        clock=clock,
        ids=ids,
    )


@pytest.fixture()
def registry(
    clock: TickingClock,
    ids: SequenceIdGenerator,
    audit: AuditLog,
    org_registry: OrganisationRegistry,
) -> WorkObjectRegistry:
    return WorkObjectRegistry(
        work_objects=InMemoryWorkObjectRepository(),
        evidence=InMemoryEvidenceRepository(),
        audit=audit,
        completion_policy=CriticalWorkEvidencePolicy(),
        principals=org_registry,
        clock=clock,
        ids=ids,
    )


@pytest.fixture()
def tenant_a(org_registry: OrganisationRegistry) -> TenantContext:
    org, founder = org_registry.create_organisation(
        "Alpha Fixture Org", "Alpha Founder", PrincipalKind.HUMAN
    )
    return TenantContext(org.organisation_id, founder.principal_id)


@pytest.fixture()
def tenant_b(org_registry: OrganisationRegistry) -> TenantContext:
    org, founder = org_registry.create_organisation(
        "Beta Fixture Org", "Beta Founder", PrincipalKind.HUMAN
    )
    return TenantContext(org.organisation_id, founder.principal_id)
