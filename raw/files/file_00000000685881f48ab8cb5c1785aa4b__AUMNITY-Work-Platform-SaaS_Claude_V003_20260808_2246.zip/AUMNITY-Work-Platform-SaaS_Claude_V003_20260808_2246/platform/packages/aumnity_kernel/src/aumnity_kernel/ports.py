"""Kernel ports (ADR-002). Adapters implement these; the kernel owns semantics.

Annotations are deferred (PEP 563) and domain types imported only for type
checking to keep ports free of import cycles with the aggregates they store.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from collections.abc import Iterable

    from aumnity_contracts import (
        EventEnvelope,
        EvidenceId,
        OrganisationId,
        PrincipalId,
        TenantContext,
        WorkObjectId,
    )

    from aumnity_kernel.evidence import EvidenceRecord
    from aumnity_kernel.identity import Principal
    from aumnity_kernel.organisation import Organisation
    from aumnity_kernel.workobject.model import WorkObject


class OrganisationRepository(Protocol):
    def add(self, organisation: Organisation) -> None: ...
    def get(self, organisation_id: OrganisationId) -> Organisation | None: ...


class PrincipalRepository(Protocol):
    def add(self, principal: Principal) -> None: ...
    def get(self, principal_id: PrincipalId) -> Principal | None: ...


class PrincipalDirectory(Protocol):
    """Membership proof for principal references (ADR-007, DW-FR-013/TEN-001).

    Implementations must raise TenantIsolationError when the principal does not
    exist or belongs to a different organisation than the context.
    """

    def require_member(self, context: TenantContext, principal_id: PrincipalId) -> Principal: ...


class WorkObjectRepository(Protocol):
    def save(self, work_object: WorkObject) -> None: ...
    def get(self, work_object_id: WorkObjectId) -> WorkObject | None: ...
    def children_of(self, parent_id: WorkObjectId) -> Iterable[WorkObject]: ...


class EvidenceRepository(Protocol):
    def add(self, record: EvidenceRecord) -> None: ...
    def get(self, evidence_id: EvidenceId) -> EvidenceRecord | None: ...


class AuditSink(Protocol):
    def append(self, event: EventEnvelope) -> None: ...
    def all_events(self) -> Iterable[EventEnvelope]: ...
