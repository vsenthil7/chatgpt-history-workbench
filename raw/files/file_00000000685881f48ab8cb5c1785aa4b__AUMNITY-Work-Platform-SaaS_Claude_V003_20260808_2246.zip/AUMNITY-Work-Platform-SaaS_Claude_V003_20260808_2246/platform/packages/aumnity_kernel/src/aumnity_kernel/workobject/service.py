"""Work Object registry: the tenant-scoped application service of the kernel.

Every protected operation takes TenantContext first (ADR-002). Every state
change increments the aggregate version, appends to its history, emits a
baseline-named domain event and records it in the audit trail (baseline
doc 09: "Every transition is policy-validated, audit-recorded and versioned").
"""

from collections.abc import Callable
from dataclasses import replace

from aumnity_contracts import (
    EventEnvelope,
    EvidenceId,
    InvalidTransitionError,
    NotFoundError,
    PolicyViolationError,
    PrincipalId,
    TenantContext,
    TenantIsolationError,
    ValidationError,
    WorkObjectId,
)
from aumnity_contracts.providers import Clock, IdGenerator

from aumnity_kernel.audit import AuditLog
from aumnity_kernel.evidence import EvidenceKind, EvidenceRecord
from aumnity_kernel.policy import CompletionPolicy
from aumnity_kernel.ports import EvidenceRepository, PrincipalDirectory, WorkObjectRepository
from aumnity_kernel.workobject.model import Priority, RiskLevel, WorkObject
from aumnity_kernel.workobject.state import (
    BLOCKABLE_STATES,
    EVIDENCE_OPEN_STATES,
    WorkObjectState,
    assert_transition,
)

# Transition -> baseline event name (doc 09). Events not yet emitted by this
# slice (AssignmentRequested, ActorMatched, SLAAtRisk, capacity/knowledge
# events) belong to deferred modules and are declared in the RTM.
_TRANSITION_EVENTS: dict[WorkObjectState, str] = {
    WorkObjectState.READY: "WorkObjectReady",
    WorkObjectState.ASSIGNED: "WorkObjectAssigned",
    WorkObjectState.IN_PROGRESS: "WorkStarted",
    WorkObjectState.OUTPUT_SUBMITTED: "OutputSubmitted",
    WorkObjectState.REVIEW: "ReviewRequested",
    WorkObjectState.APPROVED: "ApprovalGranted",
    WorkObjectState.REJECTED: "ReviewCompleted",
    WorkObjectState.REWORK: "ReworkRequested",
    WorkObjectState.COMPLETED: "WorkCompleted",
    WorkObjectState.BLOCKED: "WorkBlocked",
    WorkObjectState.CANCELLED: "WorkCancelled",
    WorkObjectState.PAUSED: "WorkPaused",
    WorkObjectState.ASSIGNABLE: "WorkObjectAssignable",
    WorkObjectState.ARCHIVED: "WorkObjectArchived",
}


TransitionMutation = Callable[[WorkObject], WorkObject]


class WorkObjectRegistry:
    """Tenant-scoped operations over Work Objects.

    ADR-007: every protected operation first binds the context — proving the
    acting principal belongs to the context organisation — and every principal
    reference an operation accepts (owner, assignee) is proven to be a member
    of the same organisation. Foreign or unknown principals raise
    TenantIsolationError (V002 review Findings 1 and 2).
    """

    def __init__(
        self,
        work_objects: WorkObjectRepository,
        evidence: EvidenceRepository,
        audit: AuditLog,
        completion_policy: CompletionPolicy,
        principals: PrincipalDirectory,
        clock: Clock,
        ids: IdGenerator,
    ) -> None:
        self._work_objects = work_objects
        self._evidence = evidence
        self._audit = audit
        self._completion_policy = completion_policy
        self._principals = principals
        self._clock = clock
        self._ids = ids

    def _bind(self, context: TenantContext) -> None:
        """Prove the acting principal is a member of the context organisation."""
        self._principals.require_member(context, context.principal_id)

    # -- retrieval ---------------------------------------------------------

    def get(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        """Load a work object, enforcing tenant isolation in the kernel."""
        self._bind(context)
        found = self._work_objects.get(work_object_id)
        if found is None:
            raise NotFoundError(f"work object not found: {work_object_id}")
        if found.organisation_id != context.organisation_id:
            raise TenantIsolationError("work object belongs to another organisation")
        return found

    def children(self, context: TenantContext, parent_id: WorkObjectId) -> tuple[WorkObject, ...]:
        parent = self.get(context, parent_id)
        return tuple(self._work_objects.children_of(parent.work_object_id))

    def evidence_for(
        self, context: TenantContext, work_object_id: WorkObjectId
    ) -> tuple[EvidenceRecord, ...]:
        work_object = self.get(context, work_object_id)
        records: list[EvidenceRecord] = []
        for evidence_id in work_object.evidence_ids:
            record = self._evidence.get(evidence_id)
            if record is None:
                raise NotFoundError(f"evidence not found: {evidence_id}")
            records.append(record)
        return tuple(records)

    # -- creation ----------------------------------------------------------

    def create(
        self,
        context: TenantContext,
        *,
        title: str,
        purpose: str,
        work_type: str,
        priority: Priority,
        risk_level: RiskLevel,
        owner_id: PrincipalId,
        parent_id: WorkObjectId | None = None,
    ) -> WorkObject:
        """Create a Work Object in DRAFT; with parent_id, this is decomposition."""
        self._bind(context)
        self._principals.require_member(context, owner_id)
        parent: WorkObject | None = None
        if parent_id is not None:
            parent = self.get(context, parent_id)
        now = self._clock.now()
        work_object = WorkObject(
            work_object_id=WorkObjectId(self._ids.new_id("wob")),
            organisation_id=context.organisation_id,
            title=title,
            purpose=purpose,
            work_type=work_type,
            state=WorkObjectState.DRAFT,
            priority=priority,
            risk_level=risk_level,
            requester_id=context.principal_id,
            owner_id=owner_id,
            created_at=now,
            updated_at=now,
            parent_id=parent.work_object_id if parent is not None else None,
        )
        work_object.history = ((1, "WorkObjectCreated", now),)
        self._work_objects.save(work_object)
        self._emit(context, work_object, "WorkObjectCreated", {})
        if parent is not None:
            self._emit(
                context,
                parent,
                "WorkObjectDecomposed",
                {"child_work_object_id": work_object.work_object_id},
            )
        return work_object

    # -- lifecycle ---------------------------------------------------------

    def mark_ready(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.READY)

    def mark_assignable(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.ASSIGNABLE)

    def assign(
        self,
        context: TenantContext,
        work_object_id: WorkObjectId,
        assignee_id: PrincipalId,
    ) -> WorkObject:
        """Minimal direct assignment to a principal (capability matching: deferred D02/D03)."""
        self._principals.require_member(context, assignee_id)
        return self._transition(
            context,
            work_object_id,
            WorkObjectState.ASSIGNED,
            mutate=lambda wo: replace(wo, assignee_id=assignee_id),
            payload={"assignee_id": assignee_id},
        )

    def start_work(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.IN_PROGRESS)

    def pause(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.PAUSED)

    def resume(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        work_object = self.get(context, work_object_id)
        if work_object.state is not WorkObjectState.PAUSED:
            raise InvalidTransitionError("resume is only permitted from PAUSED")
        return self._transition(context, work_object_id, WorkObjectState.IN_PROGRESS)

    def block(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        work_object = self.get(context, work_object_id)
        if work_object.state not in BLOCKABLE_STATES:
            raise InvalidTransitionError(f"block is not permitted from {work_object.state.value}")
        return self._transition(
            context,
            work_object_id,
            WorkObjectState.BLOCKED,
            mutate=lambda wo: replace(wo, blocked_from=work_object.state),
        )

    def unblock(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        work_object = self.get(context, work_object_id)
        if work_object.blocked_from is None:
            raise InvalidTransitionError("work object is not blocked")
        return self._transition(
            context,
            work_object_id,
            work_object.blocked_from,
            mutate=lambda wo: replace(wo, blocked_from=None),
            event_override="WorkObjectUnblocked",
        )

    def submit_output(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.OUTPUT_SUBMITTED)

    def request_review(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.REVIEW)

    def approve(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.APPROVED)

    def reject(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.REJECTED)

    def request_rework(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.REWORK)

    def restart_after_rework(
        self, context: TenantContext, work_object_id: WorkObjectId
    ) -> WorkObject:
        work_object = self.get(context, work_object_id)
        if work_object.state is not WorkObjectState.REWORK:
            raise InvalidTransitionError("restart_after_rework is only permitted from REWORK")
        return self._transition(context, work_object_id, WorkObjectState.IN_PROGRESS)

    def complete(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        """Complete approved work; the completion policy gates this transition."""
        work_object = self.get(context, work_object_id)
        assert_transition(work_object.state, WorkObjectState.COMPLETED)
        violations = self._completion_policy.violations(work_object)
        if violations:
            raise PolicyViolationError("; ".join(violations))
        return self._transition(
            context,
            work_object_id,
            WorkObjectState.COMPLETED,
            mutate=lambda wo: replace(wo, completed_at=self._clock.now()),
        )

    def cancel(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.CANCELLED)

    def archive(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.ARCHIVED)

    # -- evidence ----------------------------------------------------------

    def attach_evidence(
        self,
        context: TenantContext,
        work_object_id: WorkObjectId,
        *,
        kind: EvidenceKind,
        uri: str,
        content_sha256: str,
        source_system: str,
        source_reference: str,
    ) -> EvidenceRecord:
        """Attach an immutable evidence record while the work object is open."""
        work_object = self.get(context, work_object_id)
        if work_object.state not in EVIDENCE_OPEN_STATES:
            raise ValidationError(f"evidence cannot be attached in state {work_object.state.value}")
        record = EvidenceRecord(
            evidence_id=EvidenceId(self._ids.new_id("evd")),
            organisation_id=context.organisation_id,
            work_object_id=work_object.work_object_id,
            kind=kind,
            uri=uri,
            content_sha256=content_sha256,
            submitted_by=context.principal_id,
            submitted_at=self._clock.now(),
            source_system=source_system,
            source_reference=source_reference,
        )
        self._evidence.add(record)
        updated = replace(
            work_object,
            evidence_ids=work_object.evidence_ids + (record.evidence_id,),
        )
        self._bump_and_save(updated, "EvidenceAdded")
        self._emit(context, updated, "EvidenceAdded", {"evidence_id": record.evidence_id})
        return record

    # -- internals ---------------------------------------------------------

    def _transition(
        self,
        context: TenantContext,
        work_object_id: WorkObjectId,
        target: WorkObjectState,
        *,
        mutate: TransitionMutation | None = None,
        payload: dict[str, str] | None = None,
        event_override: str | None = None,
    ) -> WorkObject:
        work_object = self.get(context, work_object_id)
        assert_transition(work_object.state, target)
        updated = replace(work_object, state=target)
        if mutate is not None:
            updated = mutate(updated)
        event_type = event_override if event_override is not None else _TRANSITION_EVENTS[target]
        self._bump_and_save(updated, event_type)
        self._emit(context, updated, event_type, payload if payload is not None else {})
        return updated

    def _bump_and_save(self, work_object: WorkObject, event_type: str) -> None:
        now = self._clock.now()
        work_object.version = work_object.version + 1
        work_object.updated_at = now
        work_object.history = work_object.history + ((work_object.version, event_type, now),)
        self._work_objects.save(work_object)

    def _emit(
        self,
        context: TenantContext,
        work_object: WorkObject,
        event_type: str,
        payload: dict[str, str],
    ) -> None:
        self._audit.record(
            EventEnvelope(
                event_type=event_type,
                organisation_id=context.organisation_id,
                actor_principal_id=context.principal_id,
                subject_id=work_object.work_object_id,
                subject_version=work_object.version,
                occurred_at=self._clock.now(),
                payload=payload,
            )
        )
