#!/usr/bin/env python3
"""G11 — the single canonical release gate (V002 review Findings 9/10 consolidated).

Procedure:
  1. Stage a pristine copy of the repository (caches stripped).
  2. CLEAN-ROOM VALIDATION (V002 review Finding 4/5): create a fresh venv,
     install ONLY the pinned toolchain from requirements-dev.txt, and run the
     COMPLETE gate ladder (run_gates.py release) inside the staged copy with
     that venv. This proves: declared Python + declared pins -> full ladder PASS.
  3. Write evidence into the working tree; regenerate the manifest so the
     release manifest covers that evidence; verify it.
  4. Re-stage and build the release ZIP twice with normalised metadata; the two
     hashes must match (deterministic build).
  5. FINAL-PACKAGE VALIDATION: extract the exact final ZIP and run the full
     release ladder inside the extraction with the same clean venv. Results are
     printed and written NEXT TO the ZIP (they cannot live inside an archive
     whose bytes they describe).

Artifact naming (V002 review Finding 10): the artifact version is read from the
repository root ARTIFACT-VERSION file — packaging logic is never hand-edited
per release. ZIP name: AUMNITY-Work-Platform-SaaS_Claude_<ARTIFACT-VERSION>_<UTC+1 stamp>.zip
"""

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import venv
import zipfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

from _common import REPO_ROOT, write_evidence

EXCLUDED_PARTS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".coverage"}
PRODUCT = "AUMNITY-Work-Platform-SaaS"


def _artifact_version() -> str:
    return (REPO_ROOT / "ARTIFACT-VERSION").read_text().strip()


def _stage(destination: Path) -> None:
    shutil.copytree(
        REPO_ROOT, destination, ignore=shutil.ignore_patterns(*EXCLUDED_PARTS, ".coverage")
    )


def _bootstrap_venv(venv_dir: Path, requirements: Path) -> Path:
    venv.EnvBuilder(with_pip=True, clear=True).create(venv_dir)
    python = venv_dir / "bin" / "python"
    install = subprocess.run(
        [str(python), "-m", "pip", "install", "--quiet", "-r", str(requirements)],
        capture_output=True,
        text=True,
    )
    if install.returncode != 0:
        raise RuntimeError(f"toolchain bootstrap failed:\n{install.stderr}")
    return python


def _release_ladder(python: Path, tree: Path) -> dict[str, object]:
    run = subprocess.run(
        [str(python), str(tree / "platform/scripts/gates/run_gates.py"), "release"],
        cwd=tree / "platform",
        capture_output=True,
        text=True,
        env={"PYTHONHASHSEED": "0", "PATH": "/usr/bin:/bin", "HOME": "/tmp"},
    )
    return {
        "returncode": run.returncode,
        "status": "PASS" if run.returncode == 0 else "FAIL",
        "stdout_tail": run.stdout.strip().splitlines()[-16:],
        "stderr_tail": run.stderr.strip().splitlines()[-8:],
    }


def _build_zip(staged: Path, target: Path) -> str:
    files = sorted(
        p
        for p in staged.rglob("*")
        if p.is_file() and not any(part in EXCLUDED_PARTS for part in p.parts)
    )
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            info = zipfile.ZipInfo(
                f"{target.stem}/{path.relative_to(staged).as_posix()}",
                date_time=(2026, 8, 8, 0, 0, 0),
            )
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
    return hashlib.sha256(target.read_bytes()).hexdigest()


def main() -> int:
    output_dir = Path(sys.argv[1])
    stamp = (datetime.now(UTC) + timedelta(hours=1)).strftime("%Y%m%d_%H%M")
    zip_name = f"{PRODUCT}_Claude_{_artifact_version()}_{stamp}.zip"
    gates_dir = Path(__file__).resolve().parent

    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        python = _bootstrap_venv(work / "venv", REPO_ROOT / "platform" / "requirements-dev.txt")
        pip_freeze = (
            subprocess.run([str(python), "-m", "pip", "freeze"], capture_output=True, text=True)
            .stdout.strip()
            .splitlines()
        )

        # Step 2: clean-room full ladder on a pristine staged copy.
        staged = work / "staged"
        _stage(staged)
        clean_room = _release_ladder(python, staged)
        write_evidence(
            "g11_packaging",
            {
                "status": clean_room["status"],
                "clean_room": {
                    "python": "fresh venv (python -m venv), no inherited site-packages",
                    "installed_from": "platform/requirements-dev.txt",
                    "pip_freeze": pip_freeze,
                    "release_ladder": clean_room,
                },
                "final_package_validation": "performed on the extracted final ZIP; "
                "results written next to the ZIP (cannot live inside the archive "
                "whose bytes they describe)",
            },
        )
        if clean_room["status"] != "PASS":
            print("G11 FAIL: clean-room release ladder failed")
            print(json.dumps(clean_room, indent=2))
            return 1
        print("G11 step 2: clean-room full ladder PASS (fresh venv, pinned toolchain)")

        # Step 3: release manifest covers the evidence written above.
        for argument in (["generate"], []):
            check = subprocess.run(
                [sys.executable, str(gates_dir / "g01_validate_package.py"), *argument],
                cwd=REPO_ROOT,
                capture_output=True,
                text=True,
                env={"PYTHONHASHSEED": "0", "PATH": "/usr/bin:/bin", "HOME": "/tmp"},
            )
            if check.returncode != 0:
                print(f"G11 FAIL: release manifest step {argument or ['verify']}: {check.stdout}")
                return 1
        print("G11 step 3: release manifest regenerated and verified")

        # Step 4: deterministic double build.
        release_stage = work / "release"
        _stage(release_stage)
        first_hash = _build_zip(release_stage, output_dir / zip_name)
        second_hash = _build_zip(release_stage, work / zip_name)
        if first_hash != second_hash:
            print(f"G11 FAIL: builds differ: {first_hash} != {second_hash}")
            return 1
        print(f"G11 step 4: deterministic build PASS ({first_hash})")

        # Step 5: validate the exact final ZIP by re-extraction.
        extraction = work / "extracted"
        with zipfile.ZipFile(output_dir / zip_name) as archive:
            archive.extractall(extraction)
        extracted_root = extraction / Path(zip_name).stem
        final_validation = _release_ladder(python, extracted_root)
        report = {
            "zip": zip_name,
            "sha256": first_hash,
            "deterministic_double_build": "PASS",
            "extracted_final_zip_release_ladder": final_validation,
        }
        (output_dir / f"{Path(zip_name).stem}.release-validation.json").write_text(
            json.dumps(report, indent=2) + "\n"
        )
        status = final_validation["status"]
        print(f"G11 step 5: extracted-final-ZIP full release ladder {status}")
        for line in final_validation["stdout_tail"]:
            print("   ", line)
        print(f"zip: {output_dir / zip_name}")
        print(f"sha256: {first_hash}")
        return 0 if status == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
