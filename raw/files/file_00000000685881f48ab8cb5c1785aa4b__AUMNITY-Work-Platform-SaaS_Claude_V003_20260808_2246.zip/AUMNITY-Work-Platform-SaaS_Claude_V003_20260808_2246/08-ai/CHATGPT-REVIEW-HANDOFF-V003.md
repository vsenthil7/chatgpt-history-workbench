# Handoff for Independent ChatGPT Review — Claude build V003 (corrective release)

Scope: repair and hardening per the 2026-08-08 22:25 ChatGPT review of V002
(sha256 `31aae5d9…48dcc3`). No architectural restart; every preserved-decision
item from the review is untouched. Full finding-by-finding dispositions:
`11-issues/REVIEW-FINDINGS-V002.md` — all ten findings FIXED (Finding 7 with an
acknowledged inherent limit), zero silently dropped. OD-001 remains OPEN.

## What changed (product)
- ADR-007 tenant/principal identity binding: `PrincipalDirectory` port;
  `_bind()` + membership validation of owner/assignee on every protected
  `WorkObjectRegistry` operation; `create_organisation` atomically returns the
  founding principal; `require_member` raises the same `TenantIsolationError`
  for unknown and foreign principals (no cross-tenant probing oracle).
  Authentication / identity binding / authorization are now explicitly
  separated: binding is ENFORCED (TEN-001), permissions remain DECLARED
  (SEC-001).
- ADR-008 immutable events: `EventEnvelope.payload` is a defensively copied
  read-only `Mapping[str, str]`.
- Product version 0.1.0 → 0.2.0 (breaking, no external consumer; CHANGELOG).

## What changed (quality machinery)
- ADR-009: pinned `requirements-dev.txt` (+ dev extras) as the environment
  contract; `run_gates.py build|release` with incoming-manifest verification
  first (gating in release mode, recorded in build mode) and no regeneration in
  release mode; single canonical `g11_release.py` (both old G11 files removed)
  that bootstraps a fresh venv from the pins, runs the COMPLETE ladder in a
  pristine staged copy, regenerates+verifies the release manifest, double-builds
  deterministically, then extracts the exact final ZIP and runs the full
  release ladder inside the extraction; artifact version read from root
  `ARTIFACT-VERSION`.
- G07 failure taxonomy: dependency-unavailable / formatter-execution-error /
  baseline-not-formatted.
- G09: DW-FR-013, SaaS-002 and TEN-001 must cite specific collectable test node
  ids; RTM updated with node-level references.

## Regression protection added (all from the review's own reproductions)
`TestPrincipalBindingRegression` — foreign owner rejected; foreign assignee
rejected (and no partial state); mismatched-context create rejected;
cross-tenant acting principal rejected on read; unknown acting principal
rejected; same-tenant owner/assignee accepted; rejected operation writes no
audit event (audit actor can never be foreign).
`TestAuditImmutabilityRegression` + `TestEventPayloadImmutability` — recorded
payload mutation raises and history is unchanged; caller's source dict is
decoupled; non-string keys/values rejected.

## How to verify from clean (the reproducibility contract)
```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r platform/requirements-dev.txt
cd platform && PYTHONHASHSEED=0 python3 scripts/gates/run_gates.py release
```
Release mode requires the shipped manifest to verify before anything runs.
Evidence for the packaged run: `platform/evidence/` (`g11_packaging.json`
contains the clean-room pip freeze and ladder result; per-gate outputs in
`g0*.txt`/`.json`; exact counts live only in evidence per DOC gate C2).
The extracted-final-ZIP validation report ships NEXT TO the ZIP as
`<zipname>.release-validation.json` — it cannot live inside the archive whose
bytes it describes.

## Honest notes
- Finding 7's inherent limit stands: G09 verifies traceability to specific
  collectable tests; whether those tests prove the requirement remains a
  human/independent-review judgement. That is stated, not claimed away.
- DEF-007 records the provenance of V002's stray `g11_package_release.py`
  (unreconciled pre-compaction work absorbed by generate-before-verify — the
  V003 release-mode ordering is the control that now prevents this).
- Mutation operator set remains scoped per ADR-004; adopting a full external
  mutation tool in real CI is still declared follow-up.
- No git remote / CI service exists in this environment; the clean-room venv
  ladder is the substitute evidence and the gap is stated.
