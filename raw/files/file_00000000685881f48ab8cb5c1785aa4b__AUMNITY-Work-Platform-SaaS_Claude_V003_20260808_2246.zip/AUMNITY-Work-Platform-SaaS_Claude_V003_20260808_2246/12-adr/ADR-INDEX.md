# Architecture Decision Records — V002

| ADR | Title | Status |
|---|---|---|
| ADR-001 | Repository layout, language and toolchain for the platform kernel | ACCEPTED |
| ADR-002 | Explicit tenant context and ports-and-adapters isolation model | ACCEPTED |
| ADR-003 | V002 first-slice scope: shared kernel only | ACCEPTED |
| ADR-004 | Deterministic in-repo mutation gate instead of external mutation tool | ACCEPTED |
| ADR-005 | RTM unification and baseline reference corrections | ACCEPTED |
| ADR-006 | Domain error taxonomy and edge mapping for tenant isolation | ACCEPTED |
| ADR-007 | Tenant/principal identity binding via PrincipalDirectory port and founding principal | ACCEPTED |
| ADR-008 | Structurally immutable event payloads | ACCEPTED |
| ADR-009 | Pinned toolchain contract and clean-room release validation | ACCEPTED |

---

## ADR-001 — Repository layout, language and toolchain
**Context.** The starter demands deterministic builds, 100% line+branch coverage on
executable product packages, architecture guards and machine-readable evidence. The
baseline recommends Python services (FastAPI later).
**Decision.** `platform/` is the product code root. Two packages:
`packages/aumnity_contracts` (pure shared contracts: IDs, tenant context, events, errors,
clock/id-generation protocols — no dependency on any other package) and
`packages/aumnity_kernel` (platform primitives: Organisation, Principal, Work Object
registry, Evidence, Policy, Audit; depends only on `aumnity_contracts`). Python 3.12,
pytest + coverage (branch), ruff, mypy (strict). All quality gates are runnable scripts
under `platform/scripts/gates/` producing JSON/text evidence under `platform/evidence/`.
`PYTHONHASHSEED=0` for gate runs; release ZIP built with normalised mtimes for
reproducibility.
**Consequences.** No web framework or database dependency in V002; the kernel is
importable by future `services/platform_api` without modification.

## ADR-002 — Explicit tenant context and ports-and-adapters
**Context.** SaaS guard: "Protected operations must carry explicit tenant/organisation
context and be tested for cross-tenant denial. Avoid global mutable tenant state."
**Decision.** Every protected kernel operation takes a `TenantContext`
(organisation id + acting principal id) as its first argument. Repositories and the audit
log are ports (Protocols) with in-memory adapters in V002. Repository reads are
tenant-filtered inside the kernel service, never left to the adapter alone: the service
re-checks `organisation_id` on every loaded aggregate and raises `TenantIsolationError`
on mismatch, so a defective adapter cannot silently leak. There is no module-level
mutable tenant state anywhere.
**Consequences.** A PostgreSQL adapter later implements the same ports and inherits the
same contract tests (deferred: RTM row INF-001).

## ADR-003 — V002 first-slice scope
**Context.** First build objective: "harden the platform boundary, define
tenant/organisation semantics and shared contracts, then build the minimum shared kernel
demanded by real bounded modules — not a speculative mega-core." Baseline minimum build
boundary and Brutal Readiness Audit both restrict initial scope.
**Decision.** V002 implements exactly: Organisation registry; Principal identity
(HUMAN/AI/SERVICE); Work Object registry with the baseline lifecycle state machine,
version increments, recursive decomposition (parent/child in same organisation),
minimal assignment-to-principal, immutable evidence attachment with SHA-256 content
reference, evidence-gated completion policy for critical work, and an append-only,
tenant-scoped audit trail emitting the baseline event names. Explicitly deferred with
declared RTM rows: Actor/Capability/Capacity (D02/D03), review-as-work-object (D04),
knowledge/handover (D05), UraiFlow bridge implementation (D06 — the source-system
constant and evidence linkage fields exist as contract only), SLA timers, AI gateway,
service catalogue, pricing, persistence adapter, HTTP edge, Playwright (no
browser-visible journey exists yet, so the Playwright obligation is not triggered).
**Consequences.** CGWO and UraiFlow consume the kernel through its public service API and
events; no bounded-product logic entered the kernel.

## ADR-004 — Deterministic in-repo mutation gate
**Context.** QA-002 requires mutation testing for critical domain/policy logic with
attached evidence. External mutation tools introduce nondeterminism and environment
coupling that conflict with the deterministic-build rule in this sandboxed pipeline.
**Decision.** `g07_mutation_gate.py` performs AST-based mutations (comparison-operator
swaps, boolean-operator swaps, constant flips, arithmetic swaps) over the declared
critical modules (`workobject/state.py`, `policy.py`), runs the fast unit suite per
mutant, and writes a machine-readable kill report. Threshold: 100% of generated mutants
killed; any survivor fails the gate and becomes explicit work.
**Limitation (honest).** The operator set is narrower than a full mutation tool; this is
recorded, not hidden. Adopting `mutmut` in CI proper is a declared follow-up (RTM QA-002
note).
**Consequences.** Mutation evidence is reproducible byte-for-byte across runs.

## ADR-005 — RTM unification and baseline reference corrections
**Context.** ISS-002/ISS-004: two unlinked RTMs and broken renamed references.
**Decision.** `06-traceability/RTM.md` (starter location) is the single authoritative
RTM. Baseline DW-FR-001…015 are imported into it with per-row status; the baseline RTM
file remains untouched under `10-baseline/` and is superseded by reference. Baseline
broken links are documented in `11-issues/BASELINE-ISSUES.md`; baseline files are never
edited, honouring the baseline-preservation rule.
**Consequences.** One requirement namespace; G09 enforces that every ENFORCED row maps to
collectable test node IDs.

## ADR-006 — Error taxonomy and isolation edge mapping
**Context.** Cross-tenant access must be denied and testable, but a public API must not
leak resource existence.
**Decision.** Kernel raises typed errors: `TenantIsolationError` (cross-tenant access),
`NotFoundError`, `InvalidTransitionError`, `PolicyViolationError`, `ValidationError`,
all subclassing `PlatformError`. The future HTTP edge MUST map `TenantIsolationError`
to the same external representation as `NotFoundError` (404) to avoid existence leaks;
inside the trust boundary the distinct type keeps isolation failures observable and
auditable. This mapping obligation is recorded as contract, tested at the edge when the
edge exists (deferred RTM row API-001).

## ADR-007 — Tenant/principal identity binding (V002 review Findings 1–2)

**Context.** ChatGPT's independent V002 review reproduced two exploits: a Work
Object could be created/assigned with a principal belonging to another
organisation, and a TenantContext mixing Organisation A with a principal from
Organisation B was accepted. DW-FR-013 cannot be ENFORCED while identity binding
is absent. Three concepts must be separated: authentication (out of kernel
scope), tenant/principal identity binding (this ADR — cannot be deferred), and
role/permission authorization (SEC-001, legitimately deferred).

**Decision.** The kernel validates principal membership through a
`PrincipalDirectory` port (`require_member(context, principal_id)`), implemented
in-process by `OrganisationRegistry`. Every protected `WorkObjectRegistry`
operation first *binds* the context (`require_member(context,
context.principal_id)`), and every principal reference an operation accepts
(owner, assignee) is proven a member of the context organisation. Unknown and
foreign principals raise the same `TenantIsolationError` so principal existence
in other tenants cannot be probed. `create_organisation` atomically creates the
founding principal, eliminating V002's unverified-bootstrap fixture limitation.
No CGWO/UraiFlow/IPBS coupling is introduced.

**Consequences.** Breaking change to `WorkObjectRegistry.__init__` and
`create_organisation` (product 0.1.0 → 0.2.0; no external consumer existed).
Denials occur before any state change or audit emission, so a rejected
operation leaves no trace other than the raised error.

## ADR-008 — Structurally immutable event payloads (V002 review Finding 3)

**Context.** `EventEnvelope` was a frozen dataclass, but `payload:
dict[str, str]` remained mutable; ChatGPT mutated a recorded audit entry through
its payload reference.

**Decision.** `payload` is typed `Mapping[str, str]`; `__post_init__`
defensively copies the caller's mapping and wraps the private copy in
`types.MappingProxyType`. Both the write boundary (caller keeps mutating their
own dict — envelope unaffected) and the read boundary (any holder of the
envelope gets a read-only view) are protected structurally, not by convention.
Payload keys and values are validated to be strings.

**Consequences.** Attempted mutation raises `TypeError`. Regression tests cover
tampering via a recorded audit entry and via the originally supplied dict.

## ADR-009 — Pinned toolchain and clean-room release validation (V002 review Findings 4–6, 9–10)

**Context.** V002 configured pytest/coverage/ruff/mypy but declared no
installable dependency contract; the review environment could not run the full
ladder; the G11 "smoke" ran only validator+manifest+pytest; two G11 scripts
existed; the artifact version was hard-coded in packaging logic.

**Decision.** (a) `platform/requirements-dev.txt` is the authoritative pinned
toolchain, mirrored in `[project.optional-dependencies].dev`. (b) One canonical
release gate, `scripts/gates/g11_release.py`: bootstrap a fresh venv from the
pins, run the COMPLETE ladder (`run_gates.py release`) in a pristine staged
copy, regenerate+verify the release manifest, build the ZIP twice
deterministically, then extract the exact final ZIP and run the full release
ladder inside the extraction. (c) `run_gates.py` gains build/release modes;
release mode requires the incoming manifest to verify BEFORE anything runs and
performs no regeneration, so drift can never be silently absorbed
(this control would have flagged the V002 stray `g11_package_release.py`).
(d) The artifact version is read from the root `ARTIFACT-VERSION` file.

**Consequences.** "Clean checkout reproduces the ladder" is now a tested claim
with pip-freeze evidence, not an environment assumption. Final-ZIP validation
results live next to the ZIP, since they cannot be stored inside the archive
whose bytes they describe.
