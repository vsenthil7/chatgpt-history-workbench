# AT-LOS V017 Change Log

**Release type:** executable identity and bootstrap proof. One new ADR (017), amending ADR-016.

## Verified

7 findings raised. All 7 verified against the code before acceptance. None rejected.
Cumulative across nine reviews: **101 raised, 101 confirmed, 0 rejected.**

## ADR-017

- **`identity.toml` is executable.** Gains `algorithm`, `separator`, `digest_chars`, plus `implemented` and `constructor` per identity. RTM-47 **recomputes** the id from the file and compares it to the implementation; an undocumented input now fails. Verified by injection.
- **Every implemented identity is covered** — `event_id`, `registration_id`, `occurrence_id` — parametrised from the file. RTM-53 keeps the influence check; RTM-54 stops an implemented identity being declared unimplemented.
- **`tests/integration/test_bootstrap_end_to_end.py`**: real venv, `at_cli` absent, `bootstrap.py`, four packages import from outside the repo, `--check` succeeds, acceptance command returns `RESULT: PASS`. Marked `integration`; new CI job.
- RTM-49 and RTM-47 **reworded**, not just re-tested.

## Corrected

`docs/TEST_STRATEGY.md` at-cli Outstanding → implemented · Hallucination Register historical snapshots no longer describe themselves as current · Project Memory Standard release-check claim narrowed · bootstrap prerequisites documented in `bootstrap.py` and `READ_THIS_FIRST.md`.

## Gates

Generated — run `python tools/release_summary.py`, or see the FACTS block.

## Decisions

D-065 a rule's test must establish the whole claim · D-066 a structured registry is enforced across all of it · D-067 an advertised workflow is proven in a real environment

## Not done

No product application code. `at-identity`, `at-consent`, `at-evidence` not started. Network API not started. **AT-056 remains Not started.**
