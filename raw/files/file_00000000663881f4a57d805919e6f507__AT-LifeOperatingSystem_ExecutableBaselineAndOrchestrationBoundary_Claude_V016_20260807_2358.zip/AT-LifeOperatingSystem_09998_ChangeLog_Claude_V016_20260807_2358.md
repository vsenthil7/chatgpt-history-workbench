# AT-LOS V016 Change Log

**Release type:** executable baseline and orchestration boundary. One new ADR (016), amending ADR-015.

## Verified

12 findings raised. All 12 verified against the code before acceptance. None rejected.
Cumulative across eight reviews: **94 raised, 94 confirmed, 0 rejected.**

## ADR-016

- **`at_cli` removed from every product application's allowed set.** A product must not depend on a delivery interface before DQ-014 decides where an application layer belongs.
- **`at-cli` allow-list reduced** to `at_ingest_core`, `at_ingest_whatsapp`, `at_store`. Allow-lists state current dependencies, extended alongside the feature needing them.
- **`identity.toml`** holds the structured identity definition; the architecture identity section is generated; **RTM-47** asserts every component genuinely changes the computed id.
- **`bootstrap.py`** for a clean checkout; **RTM-49** runs `python -m at_cli` in a clean subprocess environment; **RTM-50** covers `--check`.
- **Mutation harness runs in a throwaway copy.** The real tree is never written to.
- **`tools/release_summary.py`** renders the release announcement from derived facts.

## Corrected

FACTS generator count derived, not hard-coded · `READ_THIS_FIRST` no longer lists `at-cli` as specification only (RTM-51) · owner-based consent language removed everywhere (RTM-52) · Sprint Tracker S1-09, S1-19, S2-07 · schema version 2 → 3 · `at-cli` declared output · workbook capability audit against `architecture.toml`.

## Gates

Figures are generated — see the FACTS block in the repository README, or run `python tools/release_summary.py`.

## Decisions

D-061 no product depends on a delivery interface; allow-lists state current needs · D-062 identity declared and asserted against code · D-063 an advertised command must run from a clean checkout · D-064 release announcements are derived

## Not done

No product application code. `at-identity`, `at-consent`, `at-evidence` not started. Network API not started. **AT-056 remains Not started.**
