# AT-Life Operating System (AT-LOS) - V016

**Release:** `AT-LifeOperatingSystem_ExecutableBaselineAndOrchestrationBoundary_Claude_V016_20260807_2358`
**Prepared by:** Claude · **07-Aug-2026 23:58 BST**

## First — my V015 summary was wrong, and that is now fixed structurally

My V015 message said *99 passed, 328 statements*. The package said **117 passed, 385 statements**. The package was right; I typed the summary.

`tools/release_summary.py` now renders the announcement from `release_facts.json`. **The figures below are generated, not typed.**

```
V016 — ExecutableBaselineAndOrchestrationBoundary

pytest                 123 passed, 1 skipped
coverage               385 statements, 80 branches, 100% line and branch
architecture guards    33 collected
mutation regression    13/13 killed
RTM                    49 passing + 1 skipped + 2 not enforced = 52
modules / products     11 declared, 2 product applications
packages measured      at-cli, at-ingest-core, at-ingest-whatsapp, at-store
platform version       0.7.0

Facts measured: outcomes=True coverage=True
```

## 12 findings. All verified. All real.

### The two architectural ones

**`at-cli` was becoming the hidden application layer.** `apps/atlos-api.allowed` included `at_cli`, and `at-cli` was authorised to import all ten planned packages. A product HTTP API depending on a CLI makes a *delivery mechanism* the application-service layer — **pre-committing DQ-014 in the manifest, before DQ-014 has been decided.**

ADR-016: `at_cli` removed from every product allow-list. `at-cli` limited to `at_ingest_core`, `at_ingest_whatsapp`, `at_store` — what it needs today. **An allow-list states current dependencies, not future permission.**

**The authoritative document described an identity the code did not compute.** `event_id` was documented *without `origin_kind`* for a whole release after ADR-014 added it — the V013 defect surviving in the specification while the code was correct.

`identity.toml` now holds the structured definition and the document section is generated. More importantly **RTM-47 asserts it against the code**: every listed component must, when varied, actually change the id. A component you can delete from the document without a test failing was never a specification.

### The one that says something about generation

V015's FACTS generator hard-coded *"the three implemented production packages"* and then listed four — propagating **one wrong sentence into four authoritative documents**, identically and confidently.

**Generation removes stale copies of a correct fact. It does not make the generator correct.** The count is derived now; the sentence names the packages.

### The rest

`python -m at_cli` failed from a clean checkout with `No module named at_cli` while three documents advertised it — **`bootstrap.py` added, and RTM-49 runs the command in a clean subprocess with no pytest path injection.**

`READ_THIS_FIRST` listed `at-cli` as "specification only" in the release that implemented it — in the file that tells a reader *"if an AI says one of these is built, it is wrong"*. RTM-51 fails the build on recurrence.

Sprint Tracker S1-09 (CLI Planned), S1-19 (stale 4/4 evidence), S2-07 (non-owner consent) — all corrected, plus a workbook capability audit. TEST_STRATEGY's owner-based consent language removed; RTM-52 forbids it. Schema version, `at-cli`'s "persisted records" output — corrected.

**Mutation testing no longer touches your source.** Your run killed by timeout left a mutant in your checkout. `try/finally` cannot catch `SIGKILL`, so every mutant now runs in a throwaway copy.

## Manual acceptance, from a clean checkout

```bash
python bootstrap.py
python -m at_cli acceptance <whatsapp-export.txt>
```

Real consultant export: **283 lines, 283 consumed, 182 events, 0 issues, RESULT PASS.**

## What is coded

Generic platform: `at-ingest-core` ✅ · `at-ingest-whatsapp` ✅ · `at-store` 🟡 in-memory · `at-cli` ✅ — **4 of 11 packages.** AT-LOS product: **not started.** Network API: **not started.** Measured packages: at-cli, at-ingest-core, at-ingest-whatsapp, at-store.

## Next

`at-ingest-llm-export`, then `at-store` durability, then `at-identity`. **`at-consent` blocked on DQ-012 and DQ-013. No product app or HTTP layer before DQ-014.**

**AT-056 remains Not started.**
