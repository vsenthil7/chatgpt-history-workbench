#!/usr/bin/env python3
"""G07 — deterministic mutation gate for critical domain/policy logic (ADR-004, QA-002).

Mutates the declared critical modules with a fixed operator set, runs the fast
unit suite per mutant, and requires every mutant to be killed. Honest scope
note: the operator set is narrower than a full external mutation tool; this is
declared in ADR-004 and the RTM.
"""

import ast
import copy
import shutil
import subprocess
import sys

from _common import PLATFORM_ROOT, write_evidence

CRITICAL_MODULES = [
    # original scope (ADR-004)
    PLATFORM_ROOT / "packages/aumnity_kernel/src/aumnity_kernel/workobject/state.py",
    PLATFORM_ROOT / "packages/aumnity_kernel/src/aumnity_kernel/policy.py",
    # ADR-018 expansion (V005 review F7): defect history (DEF-009, DEF-012,
    # DEF-016..018, DEF-020..023) clusters on tenancy/identity/audit
    # predicates, so those modules are mutation-critical too.
    PLATFORM_ROOT / "packages/aumnity_kernel/src/aumnity_kernel/guards.py",
    PLATFORM_ROOT / "packages/aumnity_kernel/src/aumnity_kernel/audit.py",
    PLATFORM_ROOT / "packages/aumnity_kernel/src/aumnity_kernel/organisation.py",
    # ADR-018 amendment (V006 review F2): the "only orchestration" exclusion of
    # service.py was not true of the shipped code — UnitOfWork execution,
    # evidence gating/verification, policy invocation, expected-version
    # propagation and write/audit sequencing live there, and DEF-027 escaped
    # across exactly that boundary. Transactional/CAS/duplicate integrity
    # lives in the memory adapter. Both are mutation-critical now.
    PLATFORM_ROOT / "packages/aumnity_kernel/src/aumnity_kernel/workobject/service.py",
    PLATFORM_ROOT / "packages/aumnity_kernel/src/aumnity_kernel/adapters/memory.py",
]
TEST_COMMAND = [
    sys.executable,
    "-m",
    "pytest",
    "-q",
    "-x",
    "--no-header",
    "-p",
    "no:cacheprovider",
    "tests/unit",
    "tests/contract",
    "tests/isolation",
]

_COMPARE_SWAPS = {
    ast.Eq: ast.NotEq,
    ast.NotEq: ast.Eq,
    ast.Lt: ast.GtE,
    ast.GtE: ast.Lt,
    ast.Gt: ast.LtE,
    ast.LtE: ast.Gt,
    ast.In: ast.NotIn,
    ast.NotIn: ast.In,
    ast.Is: ast.IsNot,
    ast.IsNot: ast.Is,
}


def _mutants(tree: ast.Module) -> list[tuple[str, ast.Module]]:
    mutants: list[tuple[str, ast.Module]] = []
    for index, node in enumerate(ast.walk(tree)):
        if isinstance(node, ast.Compare) and len(node.ops) == 1:
            op_type = type(node.ops[0])
            if op_type in _COMPARE_SWAPS:
                clone = copy.deepcopy(tree)
                for cindex, cnode in enumerate(ast.walk(clone)):
                    if cindex == index:
                        assert isinstance(cnode, ast.Compare)
                        cnode.ops = [_COMPARE_SWAPS[op_type]()]
                        break
                mutants.append(
                    (f"cmp@{node.lineno}:{op_type.__name__}", ast.fix_missing_locations(clone))
                )
        elif isinstance(node, ast.BoolOp):
            clone = copy.deepcopy(tree)
            for cindex, cnode in enumerate(ast.walk(clone)):
                if cindex == index:
                    assert isinstance(cnode, ast.BoolOp)
                    cnode.op = ast.Or() if isinstance(node.op, ast.And) else ast.And()
                    break
            mutants.append((f"bool@{node.lineno}", ast.fix_missing_locations(clone)))
        elif isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
            clone = copy.deepcopy(tree)
            for cindex, cnode in enumerate(ast.walk(clone)):
                if cindex == index:
                    assert isinstance(cnode, ast.UnaryOp)
                    # replace `not X` with `X`
                    parent_replace(clone, cindex, cnode.operand)
                    break
            mutants.append((f"not@{node.lineno}", ast.fix_missing_locations(clone)))
    return mutants


def parent_replace(tree: ast.Module, target_index: int, replacement: ast.expr) -> None:
    """Replace the node at walk-index target_index with replacement, in place."""
    target = None
    for cindex, cnode in enumerate(ast.walk(tree)):
        if cindex == target_index:
            target = cnode
            break
    for node in ast.walk(tree):
        for field_name, value in ast.iter_fields(node):
            if value is target:
                setattr(node, field_name, replacement)
                return
            if isinstance(value, list):
                for i, item in enumerate(value):
                    if item is target:
                        value[i] = replacement
                        return


def _table_removal_mutants(tree: ast.Module) -> list[tuple[str, ast.Module]]:
    """For the _ALLOWED transition table: drop each literal target once.

    Kills require a test that pins or exercises every allowed transition.
    """
    mutants: list[tuple[str, ast.Module]] = []
    for index, node in enumerate(ast.walk(tree)):
        if not (isinstance(node, ast.Set) and len(node.elts) > 0):
            continue
        for position in range(len(node.elts)):
            clone = copy.deepcopy(tree)
            for cindex, cnode in enumerate(ast.walk(clone)):
                if cindex == index:
                    assert isinstance(cnode, ast.Set)
                    if len(cnode.elts) == 1:
                        # empty set literal is invalid; replace with empty-set call
                        parent_replace(
                            clone,
                            cindex,
                            ast.Call(func=ast.Name(id="set", ctx=ast.Load()), args=[], keywords=[]),
                        )
                    else:
                        del cnode.elts[position]
                    break
            mutants.append((f"setdrop@{node.lineno}+{position}", ast.fix_missing_locations(clone)))
    return mutants


def main() -> int:
    results = []
    survivors = []
    for module_path in CRITICAL_MODULES:
        original = module_path.read_text()
        # DEF-003 guard (see evidence/defect-log.md): the captured baseline must be
        # canonically formatted; if a prior interrupted run left ast.unparse output
        # on disk, refusing to proceed prevents that text becoming the "original"
        # this gate would faithfully restore.
        fmt = subprocess.run(
            [sys.executable, "-m", "ruff", "format", "--check", str(module_path)],
            cwd=PLATFORM_ROOT,
            capture_output=True,
            text=True,
        )
        if fmt.returncode != 0:
            print(f"G07 ABORT: {module_path.name} not canonically formatted; refusing to mutate")
            write_evidence(
                "g07_mutation",
                {"status": "FAIL", "reason": f"{module_path.name} baseline not formatted"},
            )
            return 1
        tree = ast.parse(original)
        module_mutants = _mutants(tree)
        if module_path.name == "state.py":
            module_mutants = module_mutants + _table_removal_mutants(tree)
        for label, mutant_tree in module_mutants:
            mutated_source = ast.unparse(mutant_tree)
            if mutated_source == ast.unparse(ast.parse(original)):
                continue  # equivalent under unparse; skip
            module_path.write_text(mutated_source)
            try:
                run = subprocess.run(
                    TEST_COMMAND,
                    cwd=PLATFORM_ROOT,
                    capture_output=True,
                    text=True,
                    env={
                        "PYTHONHASHSEED": "0",
                        "PYTHONDONTWRITEBYTECODE": "1",
                        "PATH": "/usr/bin:/bin",
                        "PYTHONPATH": (
                            "packages/aumnity_contracts/src:packages/aumnity_kernel/src"
                        ),
                    },
                    timeout=300,
                )
                killed = run.returncode != 0
            finally:
                module_path.write_text(original)
                if module_path.read_text() != original:  # defensive restore verification
                    raise RuntimeError(f"restore failed for {module_path}")
            record = {"module": module_path.name, "mutant": label, "killed": killed}
            results.append(record)
            if not killed:
                survivors.append(record)
            print(f"  {module_path.name} {label}: {'KILLED' if killed else 'SURVIVED'}")
    for module_path in CRITICAL_MODULES:
        cache = module_path.parent / "__pycache__"
        if cache.is_dir():  # DEF-006: never leave mutant-derived bytecode behind
            shutil.rmtree(cache)
    status = "PASS" if results and not survivors else "FAIL"
    write_evidence(
        "g07_mutation",
        {
            "status": status,
            "critical_modules": [p.name for p in CRITICAL_MODULES],
            "mutants_generated": len(results),
            "mutants_killed": len(results) - len(survivors),
            "survivors": survivors,
            "operator_set": [
                "compare-swap",
                "boolop-swap",
                "not-removal",
                "set-element-drop (state.py transition/membership tables)",
            ],
            "limitation": "narrower than full mutation tool; see ADR-004",
        },
    )
    print(f"G07 {status}: {len(results) - len(survivors)}/{len(results)} mutants killed")
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
