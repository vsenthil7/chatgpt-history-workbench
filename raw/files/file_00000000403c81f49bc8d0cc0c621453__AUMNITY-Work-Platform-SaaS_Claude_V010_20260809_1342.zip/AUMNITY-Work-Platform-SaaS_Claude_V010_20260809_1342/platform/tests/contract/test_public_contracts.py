"""Contract tests for the kernel's published surface (RTM: ARC-002; gate G05).

These freeze the shapes that CGWO, UraiFlow and future adapters depend on.
Breaking any assertion here is a breaking contract change requiring a version
rationale and migration note (09-governance/VERSIONING-AND-PACKAGING.md).
"""

import inspect

import aumnity_contracts
import aumnity_kernel
import pytest
from aumnity_kernel.workobject.service import WorkObjectRegistry
from aumnity_kernel.workobject.state import (
    BLOCKABLE_STATES,
    EVIDENCE_OPEN_STATES,
    TERMINAL_STATES,
    WorkObjectState,
    allowed_targets,
)

pytestmark = pytest.mark.contract


def test_contracts_public_api_is_stable() -> None:
    assert set(aumnity_contracts.__all__) == {
        "SOURCE_SYSTEM_URAIFLOW",
        "Clock",
        "EventEnvelope",
        "EvidenceId",
        "IdGenerator",
        "InvalidTransitionError",
        "ConcurrencyError",  # ADR-017: optimistic concurrency (0.5.0)
        "NotFoundError",
        "OrganisationId",
        "PlatformError",
        "PolicyViolationError",
        "PrincipalId",
        "SequenceIdGenerator",
        "TenantContext",
        "TenantIsolationError",
        "TickingClock",
        "ValidationError",
        "WorkObjectId",
        "require_identifier",
    }


def test_kernel_public_api_is_stable() -> None:
    assert set(aumnity_kernel.__all__) == {
        "AuditLog",
        "CompletionPolicy",
        "CriticalWorkEvidencePolicy",
        "EvidenceRecord",
        "Organisation",
        "OrganisationDirectory",  # ADR-013: replaced OrganisationRegistry (0.4.0)
        "Principal",
        "PrincipalKind",
        "RiskLevel",
        "WorkObject",
        "WorkObjectRegistry",
        "WorkObjectState",
    }


def test_every_state_has_a_transition_rule() -> None:
    for state in WorkObjectState:
        targets = allowed_targets(state)
        assert isinstance(targets, frozenset)


def test_terminal_states_have_no_targets() -> None:
    for state in TERMINAL_STATES:
        assert allowed_targets(state) == frozenset()


def test_non_terminal_states_have_targets() -> None:
    for state in WorkObjectState:
        if state not in TERMINAL_STATES:
            assert allowed_targets(state), f"{state} has no exit and is not declared terminal"


def test_core_lifecycle_path_is_reachable() -> None:
    """The baseline doc 04 core path must remain valid end to end."""
    path = [
        WorkObjectState.DRAFT,
        WorkObjectState.READY,
        WorkObjectState.ASSIGNABLE,
        WorkObjectState.ASSIGNED,
        WorkObjectState.IN_PROGRESS,
        WorkObjectState.OUTPUT_SUBMITTED,
        WorkObjectState.REVIEW,
        WorkObjectState.APPROVED,
        WorkObjectState.COMPLETED,
    ]
    for current, target in zip(path[:-1], path[1:], strict=True):
        assert target in allowed_targets(current), f"core path broken at {current} -> {target}"


def test_protected_operations_take_tenant_context_first() -> None:
    """SaaS-002: every public registry operation carries explicit tenant context."""
    for name, member in inspect.getmembers(WorkObjectRegistry, inspect.isfunction):
        if name.startswith("_"):
            continue
        parameters = list(inspect.signature(member).parameters)
        assert parameters[0] == "self" and parameters[1] == "context", (
            f"WorkObjectRegistry.{name} must take TenantContext as its first argument"
        )


def test_event_envelope_field_contract() -> None:
    fields = set(aumnity_contracts.EventEnvelope.__dataclass_fields__)
    assert fields == {
        "event_type",
        "organisation_id",
        "actor_principal_id",
        "subject_id",
        "subject_version",
        "occurred_at",
        "payload",
    }


def test_full_transition_table_matches_baseline_specification() -> None:
    """Baseline doc 04/09 restated as the complete expected transition map.

    This pins every allowed transition; any table drift (including a single
    dropped target) is a contract break. Mutation gate G07 relies on this test.
    """
    st = WorkObjectState
    expected: dict[WorkObjectState, set[WorkObjectState]] = {
        st.DRAFT: {st.READY, st.CANCELLED},
        st.READY: {st.ASSIGNABLE, st.BLOCKED, st.CANCELLED},
        st.ASSIGNABLE: {st.ASSIGNED, st.BLOCKED, st.CANCELLED},
        st.ASSIGNED: {st.IN_PROGRESS, st.BLOCKED, st.CANCELLED},
        st.IN_PROGRESS: {st.OUTPUT_SUBMITTED, st.PAUSED, st.BLOCKED, st.CANCELLED},
        st.PAUSED: {st.IN_PROGRESS, st.CANCELLED},
        st.BLOCKED: {st.READY, st.ASSIGNABLE, st.ASSIGNED, st.IN_PROGRESS, st.CANCELLED},
        st.OUTPUT_SUBMITTED: {st.REVIEW, st.CANCELLED},
        st.REVIEW: {st.APPROVED, st.REJECTED, st.REWORK},
        st.REWORK: {st.IN_PROGRESS},
        st.APPROVED: {st.COMPLETED},
        st.REJECTED: {st.ARCHIVED},
        st.COMPLETED: {st.ARCHIVED},
        st.CANCELLED: {st.ARCHIVED},
        st.ARCHIVED: set(),
    }
    for state in WorkObjectState:
        assert allowed_targets(state) == frozenset(expected[state]), state


def test_membership_sets_match_baseline_specification() -> None:
    """Pins BLOCKABLE_STATES, EVIDENCE_OPEN_STATES and TERMINAL_STATES exactly."""
    s = WorkObjectState
    assert frozenset({s.READY, s.ASSIGNABLE, s.ASSIGNED, s.IN_PROGRESS}) == BLOCKABLE_STATES
    assert (
        frozenset(
            {
                s.DRAFT,
                s.READY,
                s.ASSIGNABLE,
                s.ASSIGNED,
                s.IN_PROGRESS,
                s.OUTPUT_SUBMITTED,
                s.REVIEW,
                s.REWORK,
                s.PAUSED,
                s.BLOCKED,
            }
        )
        == EVIDENCE_OPEN_STATES
    )
    assert frozenset({s.ARCHIVED}) == TERMINAL_STATES


def test_audit_log_protected_operations_take_tenant_context_first() -> None:
    """ADR-010: the published audit boundary is protected like the registry."""
    import inspect

    from aumnity_kernel import AuditLog

    for name in ("record", "entries_for"):
        parameters = list(inspect.signature(getattr(AuditLog, name)).parameters)
        assert parameters[0] == "self" and parameters[1] == "context", name


def test_audit_sink_is_not_published() -> None:
    """ADR-010: the infrastructure-trusted sink is not part of the kernel API."""
    import aumnity_kernel

    assert "AuditSink" not in aumnity_kernel.__all__


class TestPublicBoundaryInventory:
    """Machine-checkable classification of the ENTIRE published kernel surface
    (ADR-013, V004 review Finding 1).

    Every name in `aumnity_kernel.__all__` must be classified below; every
    public method of a PROTECTED service must take `context` first. A new
    export or method that is not classified — or that drops the context
    parameter — fails this contract, so boundary drift cannot ship silently
    the way `OrganisationRegistry.get_organisation` did in V004.
    """

    PROTECTED_SERVICES: frozenset[str] = frozenset(
        {"WorkObjectRegistry", "AuditLog", "OrganisationDirectory"}
    )
    VALUE_TYPES: frozenset[str] = frozenset(
        {
            "EvidenceRecord",
            "Organisation",
            "Principal",
            "PrincipalKind",
            "RiskLevel",
            "WorkObject",
            "WorkObjectState",
        }
    )
    POLICY_TYPES: frozenset[str] = frozenset({"CompletionPolicy", "CriticalWorkEvidencePolicy"})
    TRUSTED_UNPUBLISHED: frozenset[str] = frozenset(
        {"PlatformProvisioning", "AuditSink", "TenantProvisioner"}
    )

    def test_every_export_is_classified(self) -> None:
        import aumnity_kernel

        exported = set(aumnity_kernel.__all__)
        classified = self.PROTECTED_SERVICES | self.VALUE_TYPES | self.POLICY_TYPES
        assert exported == classified, (
            f"unclassified exports: {exported - classified}; "
            f"stale classifications: {classified - exported}"
        )

    def test_every_protected_service_method_takes_context_first(self) -> None:
        import inspect

        import aumnity_kernel

        for service_name in sorted(self.PROTECTED_SERVICES):
            service = getattr(aumnity_kernel, service_name)
            for name, member in inspect.getmembers(service, predicate=inspect.isfunction):
                if name.startswith("_"):
                    continue
                parameters = list(inspect.signature(member).parameters)
                assert parameters[:2] == ["self", "context"], (
                    f"{service_name}.{name} must take TenantContext first; got {parameters}"
                )

    def test_trusted_boundaries_are_not_published(self) -> None:
        import aumnity_kernel

        for name in sorted(self.TRUSTED_UNPUBLISHED):
            assert name not in aumnity_kernel.__all__, f"{name} must not be published"
