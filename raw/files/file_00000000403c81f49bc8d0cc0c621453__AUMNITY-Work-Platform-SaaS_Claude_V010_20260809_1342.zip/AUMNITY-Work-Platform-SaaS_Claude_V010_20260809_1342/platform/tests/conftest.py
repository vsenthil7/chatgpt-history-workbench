"""Deterministic fixtures: injected clock and sequential ids; no real time, no randomness."""

import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
for pkg in ("aumnity_contracts", "aumnity_kernel"):
    sys.path.insert(0, str(_ROOT / "packages" / pkg / "src"))

import pytest  # noqa: E402
from aumnity_contracts import SequenceIdGenerator, TenantContext, TickingClock  # noqa: E402
from aumnity_kernel import AuditLog, CriticalWorkEvidencePolicy  # noqa: E402
from aumnity_kernel.adapters.memory import InMemoryPlatformStores  # noqa: E402
from aumnity_kernel.identity import PrincipalKind  # noqa: E402
from aumnity_kernel.organisation import (  # noqa: E402
    OrganisationDirectory,
    PlatformProvisioning,
)
from aumnity_kernel.workobject.service import WorkObjectRegistry  # noqa: E402


@pytest.fixture()
def clock() -> TickingClock:
    return TickingClock()


@pytest.fixture()
def ids() -> SequenceIdGenerator:
    return SequenceIdGenerator()


@pytest.fixture()
def stores() -> InMemoryPlatformStores:
    """One composition root, one serialisation domain (ADR-021/ADR-022)."""
    return InMemoryPlatformStores()


@pytest.fixture()
def directory(
    stores: InMemoryPlatformStores, clock: TickingClock, ids: SequenceIdGenerator
) -> OrganisationDirectory:
    return OrganisationDirectory(
        organisations=stores.organisations,
        principals=stores.principals,
        unit_of_work=stores.identity_unit_of_work(),
        clock=clock,
        ids=ids,
    )


@pytest.fixture()
def provisioning(
    stores: InMemoryPlatformStores, clock: TickingClock, ids: SequenceIdGenerator
) -> PlatformProvisioning:
    """Trusted platform-admin boundary (ADR-013); NOT part of the published API."""
    return PlatformProvisioning(
        provisioner=stores.tenant_provisioner(),
        clock=clock,
        ids=ids,
    )


@pytest.fixture()
def audit(stores: InMemoryPlatformStores, directory: OrganisationDirectory) -> AuditLog:
    return AuditLog(
        stores.audit_sink, principals=directory, unit_of_work=stores.audit_unit_of_work()
    )


@pytest.fixture()
def registry(
    stores: InMemoryPlatformStores,
    clock: TickingClock,
    ids: SequenceIdGenerator,
    audit: AuditLog,
    directory: OrganisationDirectory,
) -> WorkObjectRegistry:
    return WorkObjectRegistry(
        work_objects=stores.work_objects,
        evidence=stores.evidence,
        audit=audit,
        completion_policy=CriticalWorkEvidencePolicy(),
        principals=directory,
        unit_of_work=stores.unit_of_work(),
        clock=clock,
        ids=ids,
    )


@pytest.fixture()
def tenant_a(provisioning: PlatformProvisioning) -> TenantContext:
    org, founder = provisioning.create_organisation(
        "Alpha Fixture Org", "Alpha Founder", PrincipalKind.HUMAN
    )
    return TenantContext(org.organisation_id, founder.principal_id)


@pytest.fixture()
def tenant_b(provisioning: PlatformProvisioning) -> TenantContext:
    org, founder = provisioning.create_organisation(
        "Beta Fixture Org", "Beta Founder", PrincipalKind.HUMAN
    )
    return TenantContext(org.organisation_id, founder.principal_id)
