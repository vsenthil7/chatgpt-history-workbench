"""Unit tests for the Work Object registry lifecycle (RTM: DW-FR-001/002/005/012)."""

import pytest
from aumnity_contracts import (
    InvalidTransitionError,
    NotFoundError,
    PolicyViolationError,
    PrincipalId,
    TenantContext,
    ValidationError,
    WorkObjectId,
)
from aumnity_kernel import AuditLog
from aumnity_kernel.evidence import EvidenceKind
from aumnity_kernel.workobject.model import Priority, RiskLevel, WorkObject
from aumnity_kernel.workobject.service import WorkObjectRegistry
from aumnity_kernel.workobject.state import WorkObjectState


def _create(
    registry: WorkObjectRegistry,
    tenant: TenantContext,
    *,
    risk: RiskLevel = RiskLevel.LOW,
    parent: WorkObjectId | None = None,
) -> WorkObject:
    return registry.create(
        tenant,
        title="Prepare quarterly summary",
        purpose="Demonstrate lifecycle",
        work_type="generic.summary",
        priority=Priority.NORMAL,
        risk_level=risk,
        owner_id=tenant.principal_id,
        parent_id=parent,
    )


def _drive_to_approved(
    registry: WorkObjectRegistry, tenant: TenantContext, work_object: WorkObject
) -> WorkObject:
    registry.mark_ready(tenant, work_object.work_object_id)
    registry.mark_assignable(tenant, work_object.work_object_id)
    registry.assign(tenant, work_object.work_object_id, tenant.principal_id)
    registry.start_work(tenant, work_object.work_object_id)
    registry.submit_output(tenant, work_object.work_object_id)
    registry.request_review(tenant, work_object.work_object_id)
    return registry.approve(tenant, work_object.work_object_id)


class TestCreation:
    def test_create_starts_in_draft_version_one(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a)
        assert wo.state is WorkObjectState.DRAFT
        assert wo.version == 1
        assert wo.organisation_id == tenant_a.organisation_id
        assert wo.requester_id == tenant_a.principal_id
        assert wo.history == ((1, "WorkObjectCreated", wo.created_at),)

    def test_create_emits_created_event(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext, audit: AuditLog
    ) -> None:
        wo = _create(registry, tenant_a)
        events = audit.entries_for(tenant_a)
        assert [e.event_type for e in events] == ["WorkObjectCreated"]
        assert events[0].subject_id == wo.work_object_id

    def test_decomposition_links_child_and_emits_event(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext, audit: AuditLog
    ) -> None:
        parent = _create(registry, tenant_a)
        child = _create(registry, tenant_a, parent=parent.work_object_id)
        assert child.parent_id == parent.work_object_id
        children = registry.children(tenant_a, parent.work_object_id)
        assert [c.work_object_id for c in children] == [child.work_object_id]
        decomposed = [
            e for e in audit.entries_for(tenant_a) if e.event_type == "WorkObjectDecomposed"
        ]
        assert len(decomposed) == 1
        assert decomposed[0].payload == {"child_work_object_id": child.work_object_id}

    def test_create_with_unknown_parent_raises(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        with pytest.raises(NotFoundError):
            _create(registry, tenant_a, parent=WorkObjectId("wob-missing"))


class TestHappyPath:
    def test_full_lifecycle_to_archive(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext, audit: AuditLog
    ) -> None:
        wo = _create(registry, tenant_a)
        approved = _drive_to_approved(registry, tenant_a, wo)
        assert approved.state is WorkObjectState.APPROVED
        completed = registry.complete(tenant_a, wo.work_object_id)
        assert completed.state is WorkObjectState.COMPLETED
        assert completed.completed_at is not None
        archived = registry.archive(tenant_a, wo.work_object_id)
        assert archived.state is WorkObjectState.ARCHIVED
        event_types = [e.event_type for e in audit.entries_for(tenant_a)]
        assert event_types == [
            "WorkObjectCreated",
            "WorkObjectReady",
            "WorkObjectAssignable",
            "WorkObjectAssigned",
            "WorkStarted",
            "OutputSubmitted",
            "ReviewRequested",
            "ApprovalGranted",
            "WorkCompleted",
            "WorkObjectArchived",
        ]

    def test_version_increments_and_history_records_each_transition(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a)
        registry.mark_ready(tenant_a, wo.work_object_id)
        loaded = registry.get(tenant_a, wo.work_object_id)
        assert loaded.version == 2
        assert [entry[1] for entry in loaded.history] == [
            "WorkObjectCreated",
            "WorkObjectReady",
        ]
        assert loaded.updated_at > loaded.created_at

    def test_assign_records_assignee(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext, audit: AuditLog
    ) -> None:
        wo = _create(registry, tenant_a)
        registry.mark_ready(tenant_a, wo.work_object_id)
        registry.mark_assignable(tenant_a, wo.work_object_id)
        assigned = registry.assign(tenant_a, wo.work_object_id, PrincipalId(tenant_a.principal_id))
        assert assigned.assignee_id == tenant_a.principal_id
        assign_events = [
            e for e in audit.entries_for(tenant_a) if e.event_type == "WorkObjectAssigned"
        ]
        assert assign_events[0].payload == {"assignee_id": tenant_a.principal_id}


class TestAlternativePaths:
    def test_pause_and_resume(self, registry: WorkObjectRegistry, tenant_a: TenantContext) -> None:
        wo = _create(registry, tenant_a)
        registry.mark_ready(tenant_a, wo.work_object_id)
        registry.mark_assignable(tenant_a, wo.work_object_id)
        registry.assign(tenant_a, wo.work_object_id, tenant_a.principal_id)
        registry.start_work(tenant_a, wo.work_object_id)
        paused = registry.pause(tenant_a, wo.work_object_id)
        assert paused.state is WorkObjectState.PAUSED
        resumed = registry.resume(tenant_a, wo.work_object_id)
        assert resumed.state is WorkObjectState.IN_PROGRESS

    def test_resume_from_non_paused_rejected(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a)
        with pytest.raises(InvalidTransitionError, match="only permitted from PAUSED"):
            registry.resume(tenant_a, wo.work_object_id)

    def test_block_remembers_origin_and_unblock_returns(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext, audit: AuditLog
    ) -> None:
        wo = _create(registry, tenant_a)
        registry.mark_ready(tenant_a, wo.work_object_id)
        blocked = registry.block(tenant_a, wo.work_object_id)
        assert blocked.state is WorkObjectState.BLOCKED
        assert blocked.blocked_from is WorkObjectState.READY
        unblocked = registry.unblock(tenant_a, wo.work_object_id)
        assert unblocked.state is WorkObjectState.READY
        assert unblocked.blocked_from is None
        types = [e.event_type for e in audit.entries_for(tenant_a)]
        assert types[-2:] == ["WorkBlocked", "WorkObjectUnblocked"]

    def test_block_from_draft_rejected(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a)
        with pytest.raises(InvalidTransitionError, match="block is not permitted"):
            registry.block(tenant_a, wo.work_object_id)

    def test_unblock_when_not_blocked_rejected(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a)
        with pytest.raises(InvalidTransitionError, match="not blocked"):
            registry.unblock(tenant_a, wo.work_object_id)

    def test_reject_then_archive(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a)
        registry.mark_ready(tenant_a, wo.work_object_id)
        registry.mark_assignable(tenant_a, wo.work_object_id)
        registry.assign(tenant_a, wo.work_object_id, tenant_a.principal_id)
        registry.start_work(tenant_a, wo.work_object_id)
        registry.submit_output(tenant_a, wo.work_object_id)
        registry.request_review(tenant_a, wo.work_object_id)
        rejected = registry.reject(tenant_a, wo.work_object_id)
        assert rejected.state is WorkObjectState.REJECTED
        assert registry.archive(tenant_a, wo.work_object_id).state is WorkObjectState.ARCHIVED

    def test_rework_loop(self, registry: WorkObjectRegistry, tenant_a: TenantContext) -> None:
        wo = _create(registry, tenant_a)
        registry.mark_ready(tenant_a, wo.work_object_id)
        registry.mark_assignable(tenant_a, wo.work_object_id)
        registry.assign(tenant_a, wo.work_object_id, tenant_a.principal_id)
        registry.start_work(tenant_a, wo.work_object_id)
        registry.submit_output(tenant_a, wo.work_object_id)
        registry.request_review(tenant_a, wo.work_object_id)
        reworked = registry.request_rework(tenant_a, wo.work_object_id)
        assert reworked.state is WorkObjectState.REWORK
        restarted = registry.restart_after_rework(tenant_a, wo.work_object_id)
        assert restarted.state is WorkObjectState.IN_PROGRESS

    def test_restart_after_rework_from_other_state_rejected(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a)
        with pytest.raises(InvalidTransitionError, match="only permitted from REWORK"):
            registry.restart_after_rework(tenant_a, wo.work_object_id)

    def test_cancel_then_archive(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a)
        cancelled = registry.cancel(tenant_a, wo.work_object_id)
        assert cancelled.state is WorkObjectState.CANCELLED
        assert registry.archive(tenant_a, wo.work_object_id).state is WorkObjectState.ARCHIVED

    def test_invalid_transition_rejected(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a)
        with pytest.raises(InvalidTransitionError, match="DRAFT -> COMPLETED"):
            registry.complete(tenant_a, wo.work_object_id)


class TestEvidenceAndCompletionPolicy:
    def test_critical_work_cannot_complete_without_evidence(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a, risk=RiskLevel.CRITICAL)
        _drive_to_approved(registry, tenant_a, wo)
        with pytest.raises(PolicyViolationError, match="at least one verified evidence"):
            registry.complete(tenant_a, wo.work_object_id)

    def test_critical_work_completes_with_evidence(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext, audit: AuditLog
    ) -> None:
        wo = _create(registry, tenant_a, risk=RiskLevel.CRITICAL)
        registry.mark_ready(tenant_a, wo.work_object_id)
        registry.mark_assignable(tenant_a, wo.work_object_id)
        registry.assign(tenant_a, wo.work_object_id, tenant_a.principal_id)
        registry.start_work(tenant_a, wo.work_object_id)
        record = registry.attach_evidence(
            tenant_a,
            wo.work_object_id,
            kind=EvidenceKind.TEST_RESULT,
            uri="evidence/run-0001.json",
            content_sha256="deadbeef",
            source_system="MANUAL",
            source_reference="run-0001",
        )
        registry.submit_output(tenant_a, wo.work_object_id)
        registry.request_review(tenant_a, wo.work_object_id)
        registry.approve(tenant_a, wo.work_object_id)
        completed = registry.complete(tenant_a, wo.work_object_id)
        assert completed.state is WorkObjectState.COMPLETED
        assert record.evidence_id in completed.evidence_ids
        assert "EvidenceAdded" in [e.event_type for e in audit.entries_for(tenant_a)]

    def test_evidence_records_are_retrievable(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a)
        record = registry.attach_evidence(
            tenant_a,
            wo.work_object_id,
            kind=EvidenceKind.DOCUMENT,
            uri="evidence/doc.pdf",
            content_sha256="cafe",
            source_system="MANUAL",
            source_reference="doc-1",
        )
        assert registry.evidence_for(tenant_a, wo.work_object_id) == (record,)

    def test_evidence_attachment_rejected_in_closed_state(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a)
        registry.cancel(tenant_a, wo.work_object_id)
        with pytest.raises(ValidationError, match="cannot be attached in state CANCELLED"):
            registry.attach_evidence(
                tenant_a,
                wo.work_object_id,
                kind=EvidenceKind.DOCUMENT,
                uri="evidence/late.pdf",
                content_sha256="beef",
                source_system="MANUAL",
                source_reference="late-1",
            )

    def test_evidence_attach_bumps_version(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wo = _create(registry, tenant_a)
        registry.attach_evidence(
            tenant_a,
            wo.work_object_id,
            kind=EvidenceKind.DOCUMENT,
            uri="evidence/doc.pdf",
            content_sha256="cafe",
            source_system="MANUAL",
            source_reference="doc-1",
        )
        assert registry.get(tenant_a, wo.work_object_id).version == 2


class TestEvidenceOpenInEveryDeclaredState:
    """Kills G07 set-drop mutants: evidence attaches in every EVIDENCE_OPEN_STATE."""

    @staticmethod
    def _drive(
        registry: WorkObjectRegistry, tenant: TenantContext, target: WorkObjectState
    ) -> WorkObjectId:
        wo = _create(registry, tenant)
        wid = wo.work_object_id
        steps = {
            WorkObjectState.DRAFT: [],
            WorkObjectState.READY: [registry.mark_ready],
            WorkObjectState.ASSIGNABLE: [registry.mark_ready, registry.mark_assignable],
            WorkObjectState.ASSIGNED: [
                registry.mark_ready,
                registry.mark_assignable,
                lambda t, w: registry.assign(t, w, t.principal_id),
            ],
            WorkObjectState.IN_PROGRESS: [
                registry.mark_ready,
                registry.mark_assignable,
                lambda t, w: registry.assign(t, w, t.principal_id),
                registry.start_work,
            ],
            WorkObjectState.PAUSED: [
                registry.mark_ready,
                registry.mark_assignable,
                lambda t, w: registry.assign(t, w, t.principal_id),
                registry.start_work,
                registry.pause,
            ],
            WorkObjectState.BLOCKED: [registry.mark_ready, registry.block],
            WorkObjectState.OUTPUT_SUBMITTED: [
                registry.mark_ready,
                registry.mark_assignable,
                lambda t, w: registry.assign(t, w, t.principal_id),
                registry.start_work,
                registry.submit_output,
            ],
            WorkObjectState.REVIEW: [
                registry.mark_ready,
                registry.mark_assignable,
                lambda t, w: registry.assign(t, w, t.principal_id),
                registry.start_work,
                registry.submit_output,
                registry.request_review,
            ],
            WorkObjectState.REWORK: [
                registry.mark_ready,
                registry.mark_assignable,
                lambda t, w: registry.assign(t, w, t.principal_id),
                registry.start_work,
                registry.submit_output,
                registry.request_review,
                registry.request_rework,
            ],
        }
        for step in steps[target]:
            step(tenant, wid)
        return wid

    # Deliberately restated (not derived from EVIDENCE_OPEN_STATES): a test
    # parametrized over the production constant would shrink together with a
    # mutated constant and kill nothing.
    @pytest.mark.parametrize(
        "target",
        [
            WorkObjectState.DRAFT,
            WorkObjectState.READY,
            WorkObjectState.ASSIGNABLE,
            WorkObjectState.ASSIGNED,
            WorkObjectState.IN_PROGRESS,
            WorkObjectState.OUTPUT_SUBMITTED,
            WorkObjectState.REVIEW,
            WorkObjectState.REWORK,
            WorkObjectState.PAUSED,
            WorkObjectState.BLOCKED,
        ],
    )
    def test_evidence_attaches_in_state(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        target: WorkObjectState,
    ) -> None:
        wid = self._drive(registry, tenant_a, target)
        assert registry.get(tenant_a, wid).state is target
        record = registry.attach_evidence(
            tenant_a,
            wid,
            kind=EvidenceKind.DOCUMENT,
            uri=f"evidence/{target.value.lower()}.pdf",
            content_sha256="feedface",
            source_system="MANUAL",
            source_reference=f"ref-{target.value.lower()}",
        )
        assert record.evidence_id in registry.get(tenant_a, wid).evidence_ids
