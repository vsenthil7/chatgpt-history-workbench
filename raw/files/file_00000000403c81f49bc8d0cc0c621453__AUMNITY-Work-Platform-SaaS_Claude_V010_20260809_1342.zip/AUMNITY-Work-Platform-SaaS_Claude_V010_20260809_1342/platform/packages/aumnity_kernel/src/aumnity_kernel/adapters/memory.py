"""Deterministic in-memory adapters for kernel ports (ADR-002/ADR-003).

These are the default adapters for tests and for the future modular-monolith
bootstrap until the PostgreSQL adapter (deferred, RTM INF-001) exists.
"""

import threading
from collections.abc import Callable, Iterable
from dataclasses import replace
from typing import TypeVar

from aumnity_contracts import (
    ConcurrencyError,
    EventEnvelope,
    EvidenceId,
    OrganisationId,
    PrincipalId,
    ValidationError,
    WorkObjectId,
)

from aumnity_kernel.evidence import EvidenceRecord
from aumnity_kernel.identity import Principal
from aumnity_kernel.organisation import Organisation
from aumnity_kernel.workobject.model import WorkObject


class _SerialisationDomainMember:
    """Mixin: a store belongs to at most ONE serialisation domain (ADR-021).

    The domain is machine-derived, never injected: transactional adapters read
    it FROM their participating stores, so two transaction boundaries over the
    same stores cannot acquire independent locks — the V007 review executed
    exactly that construction (two UoWs, same stores, different mutexes) and
    reproduced the V006 lost-commit race through it.
    """

    _domain: "TransactionMutex | None" = None

    def bind_domain(self, domain: "TransactionMutex") -> None:
        if self._domain is not None and self._domain is not domain:
            raise ValidationError(
                "store already belongs to a different serialisation domain (ADR-021)"
            )
        self._domain = domain

    def serialisation_domain(self) -> "TransactionMutex":
        if self._domain is None:
            raise ValidationError(
                "store has no serialisation domain; bind it (bind_serialisation_domain "
                "or InMemoryPlatformStores) before transactional use (ADR-021)"
            )
        return self._domain

    def _require_mutation_context(self) -> None:
        """ADR-022 (V008 review F1): EVERY mutation of a transactional store
        must occur inside its serialisation domain's transaction. This is the
        machine enforcement for future services too: a new write path that
        skips the transaction boundary fails here at its first test, instead
        of becoming the next rollback-erasure victim."""
        if not self.serialisation_domain().writable_by_current_thread():
            raise ValidationError(
                "store mutation outside its serialisation domain's WRITE transaction "
                "(ADR-022/ADR-023)"
            )


class TransactionMutex:
    """One serialisation domain: the transaction lock over a store composition
    (ADR-019/ADR-021/ADR-022).

    A transaction's snapshot → operation → commit/rollback is one critical
    section, so a failed transaction can never erase a concurrent committed
    one. ADR-022 additions: the domain records WHICH stores the active
    transaction snapshotted, so a coordinator invoked while a transaction is
    already active on this thread JOINS it iff its own stores are covered by
    the enclosing snapshot (the enclosing coordinator then owns rollback), and
    is rejected otherwise; and stores refuse mutation unless the domain is
    held (see _require_mutation_context), so no published write path can
    bypass the transaction regime.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._owner: int | None = None
        self._covered: frozenset[int] = frozenset()
        self._writable = False

    def owned_by_current_thread(self) -> bool:
        return self._owner == threading.get_ident()

    def writable_by_current_thread(self) -> bool:
        """True iff the current thread holds a WRITE transaction (ADR-023):
        read transactions serialise against writers but grant no mutation
        rights, so a read path that tries to write fails mechanically."""
        return self.owned_by_current_thread() and self._writable

    def covers(self, stores: tuple[_SerialisationDomainMember, ...]) -> bool:
        return {id(store) for store in stores} <= self._covered

    def begin(
        self, stores: tuple[_SerialisationDomainMember, ...], *, writable: bool = True
    ) -> None:
        if self.owned_by_current_thread():
            raise ValidationError(
                "a transaction is already active on this thread; coordinators join it, "
                "bare re-entry cannot nest (ADR-019/ADR-022)"
            )
        self._lock.acquire()
        self._owner = threading.get_ident()
        self._covered = frozenset(id(store) for store in stores)
        self._writable = writable

    def end(self) -> None:
        self._owner = None
        self._covered = frozenset()
        self._writable = False
        self._lock.release()

    def __enter__(self) -> "TransactionMutex":
        """Bare WRITE critical section covering no stores (test/tooling use)."""
        self.begin(())
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.end()


class InMemoryOrganisationRepository(_SerialisationDomainMember):
    def __init__(self) -> None:
        self._items: dict[OrganisationId, Organisation] = {}

    def add(self, organisation: Organisation) -> None:
        self._require_mutation_context()
        if organisation.organisation_id in self._items:
            raise ValidationError(f"duplicate organisation id: {organisation.organisation_id}")
        self._items[organisation.organisation_id] = organisation

    def get(self, organisation_id: OrganisationId) -> Organisation | None:
        return self._items.get(organisation_id)

    def snapshot(self) -> dict[OrganisationId, Organisation]:
        """Adapter-level transaction API (ADR-011/ADR-013): copy of full state."""
        return dict(self._items)

    def restore(self, state: dict[OrganisationId, Organisation]) -> None:
        """Replace full state wholesale. Non-raising by construction: a dict
        rebind cannot fail partway, so rollback itself cannot corrupt state."""
        self._items = dict(state)


class InMemoryPrincipalRepository(_SerialisationDomainMember):
    def __init__(self) -> None:
        self._items: dict[PrincipalId, Principal] = {}

    def add(self, principal: Principal) -> None:
        self._require_mutation_context()
        if principal.principal_id in self._items:
            raise ValidationError(f"duplicate principal id: {principal.principal_id}")
        self._items[principal.principal_id] = principal

    def get(self, principal_id: PrincipalId) -> Principal | None:
        return self._items.get(principal_id)

    def snapshot(self) -> dict[PrincipalId, Principal]:
        """Adapter-level transaction API (ADR-011/ADR-013): copy of full state."""
        return dict(self._items)

    def restore(self, state: dict[PrincipalId, Principal]) -> None:
        """Replace full state wholesale; non-raising by construction."""
        self._items = dict(state)


class InMemoryTenantProvisioner:
    """Atomic bootstrap over the two in-memory stores (ADR-011, hardened per
    V004 review Finding 2).

    Transaction model: snapshot BOTH stores through their explicit adapter
    transaction API, attempt both writes, and on ANY failure — whether a store
    raised before or after mutating itself — restore BOTH snapshots wholesale,
    then re-raise the original failure. From an observer's perspective the
    provision either fully happened or never happened; no orphan organisation
    and no orphan principal can survive any failure path.

    Rollback contract (explicitly defined, not pretended away): `restore`
    replaces internal state by rebinding a dict, which cannot fail partway, so
    compensation itself is non-raising for the shipped adapter. A future
    transactional adapter (PostgreSQL, INF-001) replaces this whole class with
    a database transaction.
    """

    def __init__(
        self,
        organisations: InMemoryOrganisationRepository,
        principals: InMemoryPrincipalRepository,
    ) -> None:
        # ADR-021: domain derived from the stores, never injected.
        domain = organisations.serialisation_domain()
        if principals.serialisation_domain() is not domain:
            raise ValidationError(
                "participating stores belong to different serialisation domains (ADR-021)"
            )
        self._organisations = organisations
        self._principals = principals
        self._mutex = domain

    def provision(self, organisation: Organisation, founder: Principal) -> None:
        # ADR-019/ADR-022: enter the domain registering exactly the stores this
        # transaction snapshots; when a transaction is already active on this
        # thread, join only if it covers our stores (its rollback then protects
        # our writes), else reject.
        if self._mutex.owned_by_current_thread():
            if not self._mutex.covers((self._organisations, self._principals)):
                raise ValidationError(
                    "nested transaction touches stores outside the enclosing "
                    "transaction's snapshot (ADR-022)"
                )
            self._organisations.add(organisation)
            self._principals.add(founder)
            return
        self._mutex.begin((self._organisations, self._principals))
        try:
            organisations_before = self._organisations.snapshot()
            principals_before = self._principals.snapshot()
            try:
                self._organisations.add(organisation)
                self._principals.add(founder)
            except Exception:
                self._organisations.restore(organisations_before)
                self._principals.restore(principals_before)
                raise
        finally:
            self._mutex.end()


class InMemoryWorkObjectRepository(_SerialisationDomainMember):
    """Stores defensive copies so callers cannot mutate persisted state in place.

    ADR-017 (V005 review F5/F6): `create` rejects duplicate ids — a colliding
    id generator can never silently overwrite an aggregate, least of all one
    belonging to another tenant — and `update` uses expected-version
    (optimistic concurrency): the losing concurrent writer gets
    ConcurrencyError instead of silently erasing the winner's change.
    """

    def __init__(self) -> None:
        self._items: dict[WorkObjectId, WorkObject] = {}

    def create(self, work_object: WorkObject) -> None:
        self._require_mutation_context()
        if work_object.work_object_id in self._items:
            raise ValidationError(f"duplicate work object id: {work_object.work_object_id}")
        self._items[work_object.work_object_id] = replace(work_object)

    def update(self, work_object: WorkObject, *, expected_version: int) -> None:
        self._require_mutation_context()
        stored = self._items.get(work_object.work_object_id)
        if stored is None:
            raise ValidationError(
                f"cannot update unknown work object: {work_object.work_object_id}"
            )
        if stored.version != expected_version:
            raise ConcurrencyError(
                f"stale write: stored version {stored.version} != expected {expected_version}"
            )
        self._items[work_object.work_object_id] = replace(work_object)

    def snapshot(self) -> dict[WorkObjectId, WorkObject]:
        return {key: replace(value) for key, value in self._items.items()}

    def restore(self, state: dict[WorkObjectId, WorkObject]) -> None:
        self._items = {key: replace(value) for key, value in state.items()}

    def get(self, work_object_id: WorkObjectId) -> WorkObject | None:
        found = self._items.get(work_object_id)
        return replace(found) if found is not None else None

    def children_of(self, parent_id: WorkObjectId) -> Iterable[WorkObject]:
        return tuple(replace(item) for item in self._items.values() if item.parent_id == parent_id)


class InMemoryEvidenceRepository(_SerialisationDomainMember):
    def __init__(self) -> None:
        self._items: dict[EvidenceId, EvidenceRecord] = {}

    def add(self, record: EvidenceRecord) -> None:
        """Evidence is immutable: a duplicate id would REPLACE a record via the
        dict key even though the dataclass is frozen — rejected (ADR-017)."""
        self._require_mutation_context()
        if record.evidence_id in self._items:
            raise ValidationError(f"duplicate evidence id: {record.evidence_id}")
        self._items[record.evidence_id] = record

    def snapshot(self) -> dict[EvidenceId, EvidenceRecord]:
        return dict(self._items)

    def restore(self, state: dict[EvidenceId, EvidenceRecord]) -> None:
        self._items = dict(state)

    def get(self, evidence_id: EvidenceId) -> EvidenceRecord | None:
        return self._items.get(evidence_id)


class InMemoryAuditSink(_SerialisationDomainMember):
    """Append-only event store; no update or delete API exists by design.

    snapshot/restore participate in the command unit of work (ADR-016) only;
    they are adapter transaction plumbing, not an update/delete capability.
    """

    def __init__(self) -> None:
        self._events: list[EventEnvelope] = []

    def append(self, event: EventEnvelope) -> None:
        self._require_mutation_context()
        self._events.append(event)

    def all_events(self) -> Iterable[EventEnvelope]:
        return tuple(self._events)

    def snapshot(self) -> list[EventEnvelope]:
        return list(self._events)

    def restore(self, state: list[EventEnvelope]) -> None:
        self._events = list(state)


_T = TypeVar("_T")


class InMemoryUnitOfWork:
    """Atomic command boundary over any set of domain-bound stores (ADR-016,
    ADR-019/021/022).

    Transaction model: enter the serialisation domain registering exactly the
    participating stores, snapshot them, run the command, and on ANY failure
    restore ALL snapshots wholesale and re-raise. If a transaction is ALREADY
    active on this thread, the run JOINS it — permitted only when the
    enclosing transaction's registered stores cover this coordinator's stores,
    so the enclosing snapshot/rollback fully protects the nested writes
    (ADR-022); otherwise construction of the nested scope is rejected. A
    transactional persistence adapter (INF-001) replaces all of this with a
    database transaction.
    """

    def __init__(self, *stores: _SerialisationDomainMember) -> None:
        if not stores:
            raise ValidationError("a unit of work needs at least one participating store")
        domain = stores[0].serialisation_domain()
        for participant in stores[1:]:
            if participant.serialisation_domain() is not domain:
                raise ValidationError(
                    "participating stores belong to different serialisation domains (ADR-021)"
                )
        self._stores = stores
        self._mutex = domain

    def run(self, operation: Callable[[], _T]) -> _T:
        if self._mutex.owned_by_current_thread():
            # Join the ambient transaction (ADR-022): the enclosing coordinator
            # owns commit/rollback, so it must have snapshotted our stores.
            if not self._mutex.covers(self._stores):
                raise ValidationError(
                    "nested transaction touches stores outside the enclosing "
                    "transaction's snapshot (ADR-022)"
                )
            return operation()
        self._mutex.begin(self._stores, writable=True)
        try:
            snapshots = [store.snapshot() for store in self._stores]  # type: ignore[attr-defined]
            try:
                return operation()
            except Exception:
                for store, state in zip(self._stores, snapshots, strict=True):
                    store.restore(state)  # type: ignore[attr-defined]
                raise
        finally:
            self._mutex.end()

    def read(self, operation: Callable[[], _T]) -> _T:
        """Consistent multi-store READ (ADR-023, V009 review F1): the whole
        read sequence executes inside the serialisation domain, so no writer's
        commit can land between its constituent loads — a torn cross-store
        view cannot exist. Inside an already-active transaction the read
        simply joins it (any mode, no coverage requirement: the single domain
        lock already excludes concurrent writers). Read transactions grant no
        mutation rights (see writable_by_current_thread)."""
        if self._mutex.owned_by_current_thread():
            return operation()
        self._mutex.begin((), writable=False)
        try:
            return operation()
        finally:
            self._mutex.end()


def bind_serialisation_domain(
    *stores: _SerialisationDomainMember, domain: TransactionMutex | None = None
) -> TransactionMutex:
    """Bind stores into ONE serialisation domain (creating it if needed).

    Binding a store that already belongs to a DIFFERENT domain raises — the
    machine enforcement of "same transactional resources ⇒ same serialisation
    domain" (ADR-021). Rebinding into the same domain is idempotent.
    """
    resolved = domain if domain is not None else TransactionMutex()
    # DEF-033 (V008 review F2): preflight the WHOLE set before mutating any
    # binding, so a failed bind leaves every participant's prior binding
    # unchanged (no partially-mutated composition).
    for store in stores:
        if store._domain is not None and store._domain is not resolved:
            raise ValidationError(
                "store already belongs to a different serialisation domain (ADR-021)"
            )
    for store in stores:
        store.bind_domain(resolved)
    return resolved


class InMemoryPlatformStores:
    """Composition root: ALL in-memory stores under ONE serialisation domain
    (ADR-021). It owns the repositories and the lock and manufactures the
    transactional adapters, so the unit of work and the tenant provisioner can
    never accidentally form separate serialisation domains over shared
    transactional resources.
    """

    def __init__(self) -> None:
        self.organisations = InMemoryOrganisationRepository()
        self.principals = InMemoryPrincipalRepository()
        self.work_objects = InMemoryWorkObjectRepository()
        self.evidence = InMemoryEvidenceRepository()
        self.audit_sink = InMemoryAuditSink()
        self.domain = bind_serialisation_domain(
            self.organisations,
            self.principals,
            self.work_objects,
            self.evidence,
            self.audit_sink,
        )

    def unit_of_work(self) -> InMemoryUnitOfWork:
        """Command transaction over work objects, evidence and audit."""
        return InMemoryUnitOfWork(self.work_objects, self.evidence, self.audit_sink)

    def identity_unit_of_work(self) -> InMemoryUnitOfWork:
        """Transaction for published identity writes (ADR-022): principal
        creation participates in the same regime a provisioning rollback uses,
        so it can never be erased by one."""
        return InMemoryUnitOfWork(self.organisations, self.principals)

    def audit_unit_of_work(self) -> InMemoryUnitOfWork:
        """Transaction for direct audit publication (ADR-022). Inside a
        registry command it JOINS the ambient command transaction, whose
        snapshot covers the sink."""
        return InMemoryUnitOfWork(self.audit_sink)

    def tenant_provisioner(self) -> InMemoryTenantProvisioner:
        return InMemoryTenantProvisioner(self.organisations, self.principals)
