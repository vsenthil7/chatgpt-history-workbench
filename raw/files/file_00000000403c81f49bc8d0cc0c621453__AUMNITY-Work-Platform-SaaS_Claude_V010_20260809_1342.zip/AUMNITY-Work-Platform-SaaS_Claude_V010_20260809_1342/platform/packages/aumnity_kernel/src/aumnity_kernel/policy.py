"""Completion policies (baseline evidence rule).

"No critical Work Object completes without required evidence."
Policies are pure and side-effect free; the registry enforces them.

DEF-023 (V005 review F4): a policy judges VERIFIED evidence records that the
registry has already resolved and validated (existence, tenancy, linkage) —
never a denormalised id list, so a dangling or mismatched reference can no
longer count as evidence.
"""

from typing import Protocol

from aumnity_kernel.evidence import EvidenceRecord
from aumnity_kernel.workobject.model import RiskLevel, WorkObject


class CompletionPolicy(Protocol):
    """Decides whether a work object may complete."""

    def violations(
        self, work_object: WorkObject, verified_evidence: tuple[EvidenceRecord, ...]
    ) -> tuple[str, ...]:
        """Return zero or more violation messages; empty means permitted."""
        ...


class CriticalWorkEvidencePolicy:
    """Default platform policy: critical-risk work requires at least one
    VERIFIED evidence record."""

    def violations(
        self, work_object: WorkObject, verified_evidence: tuple[EvidenceRecord, ...]
    ) -> tuple[str, ...]:
        if work_object.risk_level is RiskLevel.CRITICAL and not verified_evidence:
            return ("critical work object requires at least one verified evidence record",)
        return ()
