"""Tenancy and identity integrity guards (ADR-002 addendum, ADR-018).

CRITICAL INTEGRITY MODULE — mutation gate target (QA-002, expanded per V005
review F7: escaped defects clustered on exactly these predicates).

Every domain object returned by a repository passes through these guards
before the kernel discloses or acts on it, so a defective adapter — returning
a foreign aggregate, or the wrong aggregate for a requested id — fails closed
instead of silently leaking (V005 review F2/F3).
"""

from aumnity_contracts import TenantContext, TenantIsolationError


def require_tenant_match(organisation_id: str, context: TenantContext, what: str) -> None:
    """Fail closed unless the loaded aggregate belongs to the context organisation."""
    if organisation_id != context.organisation_id:
        raise TenantIsolationError(f"{what} belongs to another organisation")


def require_identity(actual_id: str, requested_id: str, what: str) -> None:
    """Fail closed unless the repository returned the aggregate that was asked for.

    A repository handing back a DIFFERENT row than requested is corruption or a
    hostile adapter; treating its answer as proof (of membership, existence or
    linkage) would launder the defect into a security guarantee.
    """
    if actual_id != requested_id:
        raise TenantIsolationError(f"{what} identity mismatch for requested id")
