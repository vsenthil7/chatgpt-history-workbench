# Independent Review Findings — V009 (ChatGPT deep review, 2026-08-09 13:31) and dispositions in V010

Source: full-package review and adversarial probes against the extracted
`AUMNITY-Work-Platform-SaaS_Claude_V009_20260809_1326.zip`
(sha256 `2b17033740daf3a2367579a2b2da2b15aeb1191508f9c77879aad43f4b50a073`).
Rule applied: no finding may silently disappear.

| # | Finding | Disposition | Where |
|---|---|---|---|
| F1 | HIGH: multi-store read paths outside the transaction regime — a concurrent attach commit landed between `evidence_for`'s parent load and record loads, producing an executed torn cross-store view | **FIXED** | ADR-023: `UnitOfWork.read` on the port; get/children/evidence_for/entries_for/get_organisation/require_member each execute as ONE consistent read inside the serialisation domain, joining any active transaction; read transactions grant no mutation rights (writable-mode adapter guard — a read path that writes fails mechanically, mutation-tested); deterministic torn-read choreography: writer asserted BLOCKED mid-read, reader's view exactly the pre-attach state; per-operation scope stated honestly with caller-scoped read views DECLARED (RD-002); DEF-034; RTM RD-001 |
| F2 | MEDIUM: `create_principal` validated membership outside its write transaction (TOCTOU window, demonstrated); audit/record and registry commands shared the validate-outside shape | **FIXED (pattern applied universally, not point-patched)** | ADR-023: every public mutating operation runs its FULL validate→write sequence inside one write transaction — directory `create_principal`, `AuditLog.record`, registry `create`/every transition/`attach_evidence`/`complete` (policy verification included); internal reads join the ambient write transaction; deterministic critical-section choreography: a competing transaction is asserted EXCLUDED from the validate→write window; DEF-035; RTM RD-001 |

Preserved and re-proven: every prior fix, baseline byte-identity, OD-001 OPEN,
deterministic double build, read-only double ladder with unchanged digest.
Freeze remains the reviewer's call.
