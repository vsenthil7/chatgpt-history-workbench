# Independent Review Findings — V006 (ChatGPT deep review, 2026-08-09 12:11) and dispositions in V007

Source: full-package review and adversarial probes against the extracted
`AUMNITY-Work-Platform-SaaS_Claude_V006_20260809_1040.zip`
(sha256 `1a42ea33a9c063c301a3ad17abae942075f98dc8e0eb45b14a620948579c8f26`).
Rule applied: no finding may silently disappear.

| # | Finding | Disposition | Where |
|---|---|---|---|
| F1 | BLOCKER: unlocked whole-store snapshot rollback let a failed transaction erase a concurrent committed one (executed: final DRAFT/v1 instead of committed READY/v2); provisioner shared the technique and the race | **FIXED (architectural, not test-only)** | ADR-019 `TransactionMutex`: transactions over one shared store composition are serialised — snapshot→operation→commit/rollback is a single critical section, so no commit can fall between another transaction's snapshot and restore; provisioner shares the mutex; same-thread nesting raises `ValidationError` instead of deadlocking; deterministic two-thread choreography of the exact probe proves B waits, A rolls back, B commits and survives; DEF-027; RTM TXN-002 |
| F2 | HIGH: ADR-018's service.py mutation exclusion untrue of shipped code (UoW usage, evidence gating/verification, policy invocation, version propagation, write→audit sequencing all live there; DEF-027 escaped across it) | **FIXED (exclusion withdrawn)** | ADR-018 amended; `workobject/service.py` AND `adapters/memory.py` (CAS/duplicate/transaction integrity) added to G07's critical set with the full operator set — no integrity-bearing module remains excluded; all mutants killed in the shipped evidence; DEF-028 |
| F3 | MEDIUM: defective-adapter validation stopped at the aggregate shell — correct id+org with foreign requester/owner/assignee disclosed; evidence `submitted_by` unverified | **FIXED (invariant extended, claim kept)** | ADR-020: every embedded principal reference proven a member before disclosure (`get`, every child in `children`); evidence submitter proven in `evidence_for` AND completion-time verification; failures use the normalised non-oracle isolation error; the review's poisoned-aggregate and foreign-submitter probes are permanent regressions; DEF-029; RTM ADP-001 extended |

Preserved and re-proven: all V005-finding fixes, baseline byte-identity,
OD-001 OPEN, deterministic double build, two read-only release ladders with
G01 after each and unchanged tree digest. Freeze remains the reviewer's call.
