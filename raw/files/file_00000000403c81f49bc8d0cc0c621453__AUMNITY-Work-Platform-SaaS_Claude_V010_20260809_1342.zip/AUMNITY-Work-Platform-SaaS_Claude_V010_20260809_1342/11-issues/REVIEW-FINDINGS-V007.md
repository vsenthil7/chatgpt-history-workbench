# Independent Review Findings — V007 (ChatGPT deep review, 2026-08-09 12:33) and dispositions in V008

Source: full-package review and adversarial probes against the extracted
`AUMNITY-Work-Platform-SaaS_Claude_V007_20260809_1224.zip`
(sha256 `4c487c5e16f2581a6e81a335c7d796b1172a4ff403a27a2bd8bf2e2108b8d08d`).
Rule applied: no finding may silently disappear.

| # | Finding | Disposition | Where |
|---|---|---|---|
| F1 | BLOCKER: ADR-019's serialisation invariant was a programmer convention — two UoWs over the same stores with different injected mutexes was a permitted construction, and the executed probe reproduced the V006 lost-commit race (FINAL DRAFT/v1) against the shipped classes | **FIXED (construction invariant, not regression-only; new ADR, ADR-019 history intact)** | ADR-021: stores each belong to at most one serialisation domain; binding into a second domain raises; the mutex parameter is REMOVED from `InMemoryUnitOfWork`/`InMemoryTenantProvisioner`, which derive the domain from their participants and reject unbound or mixed-domain construction; `InMemoryPlatformStores` composition root owns all stores + the lock and manufactures both adapters. The three mandated regressions exist: (a) independent locking over same stores impossible/rejected, (b) failed-A/concurrent-B rerun with two independently constructed UoWs — B waits and survives, (c) UoW/provisioner domain identity via the composition root. Domain predicates are mutation-tested; DEF-030; RTM TXN-003 |
| minor | G07 evidence `operator_set` omitted the executed set-element-drop table mutation | **FIXED** | operator set enumerates every executed operator; DEF-031 |
| — | F2/F3 of the V006 review confirmed materially addressed by the reviewer | CLOSED (no action) | `REVIEW-FINDINGS-V006.md` unchanged |

Preserved and re-proven: all prior fixes, baseline byte-identity, OD-001 OPEN,
deterministic double build, two read-only ladders with G01 after each and
unchanged tree digest. Freeze remains the reviewer's call.
