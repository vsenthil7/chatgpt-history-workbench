# Independent Review Findings — V005 (ChatGPT deeper review, 2026-08-09 09:34) and dispositions in V006

Source: adversarial probes executed against the extracted
`AUMNITY-Work-Platform-SaaS_Claude_V005_20260809_0646.zip`
(sha256 `7ed154a9cab3fb14bec5ed1bfb0ba78f76696e603f0e8f17c3ae918961723d95`).
Rule applied: no finding may silently disappear.

| # | Finding | Disposition | Where |
|---|---|---|---|
| F1 | Work Object write succeeded when the mandatory audit append failed (executed: orphan work object after audit-sink fault) | **FIXED** | ADR-016 `UnitOfWork` port — architectural transaction boundary, not local try/except; create, every transition and evidence attachment run domain writes + audit append atomically; memory adapter snapshot/restores work-object, evidence and audit stores; after-write fault injections for all three command shapes; DEF-020; RTM TXN-001 |
| F2 | ADR-002's defective-adapter promise false: hostile `children_of` leaked an Org-B object; `evidence_for` unvalidated; `get_organisation` returned any row | **FIXED (ADR-002 hardened, not competed)** | ADR-002 addendum + `guards` module: identity/tenancy/linkage revalidation on every repository-returned aggregate (children incl. parentage; evidence incl. work-object linkage; organisation identity); hostile-adapter regressions execute the review's exact probes; DEF-021; RTM ADP-001 |
| F3 | `require_member` accepted a wrong-row repository response as membership proof (executed: "not-real" bound as founder) | **FIXED** | returned principal id AND organisation both verified; outcomes normalised to the single "not accessible" message so unknown/foreign/wrong-row stay indistinguishable (no existence oracle); wrong-row same-org and wrong-row foreign-org hostile tests; DEF-022 |
| F4 | Critical completion accepted a dangling evidence id (executed: `("dangling",)` → no violations) | **FIXED (architecture decided)** | registry resolves and validates every referenced record; `CompletionPolicy` signature now takes VERIFIED records; dangling → `PolicyViolationError("…cannot be verified")`, foreign record → `TenantIsolationError`, wrong work object → `PolicyViolationError`; DEF-023; RTM EVD-001 |
| F5 | Duplicate ids silently overwrote work objects/principals/organisations/evidence | **FIXED** | ADR-017 create-vs-update semantics; duplicate rejection at every persistence boundary; evidence protected from key replacement; DEF-024; RTM INT-001 |
| F6 | `version` informational only; concurrent writers silently lost updates; gap undecided in ADRs | **FIXED (decided-and-implemented, not deferred)** | ADR-017 expected-version CAS `update`; published `ConcurrencyError` (contracts 0.5.0); registry passes the version it read; stale-write regression (both-writers-read-v1 scenario); DEF-025; RTM INT-002 |
| F7 | Mutation scope (state, policy) stale vs defect history | **FIXED (scope expanded + remaining exclusion ADR-justified)** | ADR-018: integrity predicates centralised in mutation-critical `guards.py`; G07 now mutates state, policy, guards, audit, organisation — all mutants killed; service orchestration exclusion justified in the ADR; DEF-026 |

Accepted V005 verifications (DEF-016..019 fixes, deterministic build, double
ladder, unchanged digest) are preserved and re-proven by the V006 release
evidence. OD-001 remains **OPEN**. Freeze remains ChatGPT's/partner's call — 
V006 does not self-declare freeze-readiness.
