# Independent Review Findings — V008 (ChatGPT deep review, 2026-08-09 13:07) and dispositions in V009

Source: full-package review and adversarial probes against the extracted
`AUMNITY-Work-Platform-SaaS_Claude_V008_20260809_1300.zip`
(sha256 `9f865998b5459a63c282d68300b17a8aa51ccca3383d77ef74ec1c39e092e015`).
Rule applied: no finding may silently disappear.

| # | Finding | Disposition | Where |
|---|---|---|---|
| F1 | BLOCKER: write paths outside the serialisation regime — public `create_principal` wrote the principal store directly, and a concurrent provisioning failure's whole-store rollback erased the committed principal (executed via public APIs); direct `AuditLog` publication shared the shape | **FIXED (transaction port participation + adapter-level mechanical guard; no kernel↔mutex coupling)** | ADR-022: `OrganisationDirectory` and `AuditLog` take the `UnitOfWork` port and run writes inside it (composition root supplies `identity_unit_of_work`/`audit_unit_of_work`); the domain registers each transaction's covered stores; coordinators invoked inside an active transaction JOIN it iff covered (audit inside registry commands), else are rejected; in-memory store MUTATORS refuse out-of-transaction writes — the mechanical guard that makes any future bypass path fail at its first test (a static guard was considered and rejected as weaker, recorded in the ADR); the V006 "nesting rejected" contract is deliberately evolved to join-with-coverage and TXN-002's evidence updated; DEF-032; RTM TXN-004 |
| F2 | MEDIUM: `bind_serialisation_domain` left partially-mutated bindings after a failed bind | **FIXED** | whole-set preflight before any binding mutation; regression asserts the unbound participant stays unbound and the conflicting one keeps its original domain; DEF-033; RTM TXN-005 |

Mandated regressions delivered: (1) the exact executed scenario through PUBLIC
paths as a deterministic two-thread choreography — B's `create_principal` is
serialised behind A's failing provision and its principal SURVIVES the
rollback (V008 printed False); (2) direct out-of-transaction mutation of
principal store, audit sink and work-object store each rejected at the
adapter; (3) atomic-bind failure leaves prior bindings unchanged. Plus:
covered-join, uncovered-rejection, bare-re-entry and joined-provision-rollback
tests. Preserved: all prior fixes, baseline byte-identity, OD-001 OPEN,
deterministic build, read-only double ladder. Freeze remains the reviewer's
call.
