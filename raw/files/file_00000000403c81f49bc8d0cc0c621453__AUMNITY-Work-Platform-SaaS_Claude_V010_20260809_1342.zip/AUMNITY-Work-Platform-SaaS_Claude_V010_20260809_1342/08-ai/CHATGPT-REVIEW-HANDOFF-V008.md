# Handoff for Independent ChatGPT Review — Claude build V008 (hardening release)

Scope: exactly the V007 review — the construction-invariant blocker plus the
minor mutation-evidence correction. No feature tranche; all prior fixes
preserved; freeze not self-declared. Dispositions:
`11-issues/REVIEW-FINDINGS-V007.md`. OD-001 OPEN.

## Product changes (0.6.0 → 0.7.0, breaking, no external consumer)
ADR-021 makes `same transactional resources ⇒ same serialisation domain`
mechanically guaranteed rather than documented:
- every in-memory store belongs to at most ONE domain
  (`bind_serialisation_domain`; second-domain binding raises; same-domain
  rebinding idempotent);
- `InMemoryUnitOfWork` and `InMemoryTenantProvisioner` no longer accept a
  mutex AT ALL — they derive the domain from their participating stores and
  reject unbound/mixed-domain construction;
- `InMemoryPlatformStores` composition root owns all stores under one domain
  and manufactures both adapters, so UoW and provisioner cannot form separate
  domains over shared resources.
The V007 probe construction (two UoWs, same stores) now yields one shared
lock by derivation; injecting different ones is not an expressible program.
ADR-019's history is intact; its enforcement model is superseded by ADR-021.

## Regression protection (the mandated three, plus)
(a) independently-locked-boundaries-impossible: derived-domain identity for
two independently constructed UoWs; unbound stores rejected (UoW and
provisioner); mixed-domain stores rejected (both adapters); second-domain
binding rejected with idempotent same-domain rebind pinned.
(b) the failed-A/concurrent-B interleaving reruns with the SECOND UoW
independently constructed — B is asserted to wait and its READY/v2 survives.
(c) composition-root domain identity across UoW and provisioner (plus the
existing nested-provision rejection).
Minor: `g07_mutation.json` operator_set now enumerates compare-swap,
boolop-swap, not-removal AND set-element-drop.

## How to verify
```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r platform/requirements-dev.txt
cd platform && PYTHONHASHSEED=0 python3 scripts/gates/run_gates.py release   # twice — identical
```
Counts in evidence only (DOC C2); pip freeze, double-ladder idempotence and
tree digests in `evidence/g11_packaging.json` + sidecar.

## Honest notes
- The domain-derivation predicates live in the mutation-critical memory
  adapter and are covered by the expanded G07 scope.
- INF-001's PostgreSQL adapter replaces the whole mechanism with database
  transactions; cross-process concurrency proof belongs there. SEC-001,
  AUD-004 and external mutation tooling remain declared.
