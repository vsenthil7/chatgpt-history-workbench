# Handoff for Independent ChatGPT Review — Claude build V007 (hardening release)

Scope: exactly the V006 review's three findings — transaction serialisation,
mutation-scope completion, whole-aggregate reference integrity. No feature
tranche; all V006 fixes preserved; freeze not self-declared. Dispositions:
`11-issues/REVIEW-FINDINGS-V006.md` (F1–F3 FIXED, none dropped). OD-001 OPEN.

## Product changes (0.5.0 → 0.6.0, breaking, no external consumer)
- ADR-019: `TransactionMutex` serialises in-memory transactions per shared
  store composition (unit of work AND tenant provisioner share it);
  snapshot→operation→commit/rollback is one critical section; same-thread
  nesting rejected explicitly. Constructors take the mutex (breaking).
- ADR-020: whole-aggregate invariant — embedded requester/owner/assignee
  proven members before any disclosure; evidence `submitted_by` proven in
  reads and completion verification.
- ADR-018 amended: service.py + memory adapters in mutation scope; the
  "only orchestration" exclusion is withdrawn as untrue.

## Regression protection (the review's exact probes)
Deterministic two-thread interleaving: A holds its transaction, B *waits*
(asserted), A fails and rolls back, B commits, B survives (the V006 defect
produced DRAFT/v1 here; the regression pins READY/v2). Nested transaction and
provision-inside-transaction rejected. Poisoned aggregate (correct id+org,
foreign refs) fails closed on `get`; foreign evidence submitter fails closed
on `evidence_for`.

## How to verify
```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r platform/requirements-dev.txt
cd platform && PYTHONHASHSEED=0 python3 scripts/gates/run_gates.py release   # twice — identical
```
Counts in evidence only (DOC C2); clean-room pip freeze, double-ladder
idempotence and tree digests in `evidence/g11_packaging.json` + sidecar.

## Honest notes
- The mutex is the in-memory adapter's answer; INF-001's PostgreSQL adapter
  replaces it with database transactions and row locking, and cross-process
  concurrency proof belongs there — stated, not claimed.
- Deferred, declared: SEC-001, AUD-004, INF-001, external mutation tooling.
