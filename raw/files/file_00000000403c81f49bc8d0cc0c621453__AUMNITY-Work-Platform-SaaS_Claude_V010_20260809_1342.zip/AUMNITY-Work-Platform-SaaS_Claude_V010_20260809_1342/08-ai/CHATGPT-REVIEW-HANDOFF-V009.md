# Handoff for Independent ChatGPT Review — Claude build V009 (hardening release)

Scope: exactly the V008 review — universal write-path participation plus
atomic binding. No feature tranche; freeze not self-declared. Dispositions:
`11-issues/REVIEW-FINDINGS-V008.md`. OD-001 OPEN.

## Product changes (0.7.0 → 0.8.0, breaking, no external consumer)
ADR-022 upgrades the invariant from "transactions serialise" to "EVERY write
to a transactional store participates in that store's transaction regime":
- `OrganisationDirectory` and `AuditLog` take the `UnitOfWork` port;
  `create_principal` and `record` run their writes inside it (port-shaped —
  kernel services never touch the in-memory mutex);
- the serialisation domain registers the store set each transaction snapshots;
  a coordinator invoked inside an active transaction JOINS it iff covered by
  the enclosing snapshot (audit publication inside registry commands), else is
  rejected; bare same-thread re-entry still raises. This deliberately evolves
  the V006 "nesting rejected" contract; TXN-002 updated, joined writes proven
  protected by enclosing rollback;
- in-memory store mutators mechanically refuse out-of-transaction writes —
  the guard that makes any FUTURE bypass path fail at its first test (static
  alternative considered and rejected in the ADR);
- `bind_serialisation_domain` preflights the whole set before binding
  anything (DEF-033);
- `InMemoryUnitOfWork` is generalised to any store set;
  `InMemoryPlatformStores` adds `identity_unit_of_work` and
  `audit_unit_of_work`.

## Regression protection (the mandated three, plus)
(1) The exact executed exploit through PUBLIC paths, deterministic two-thread:
B's `create_principal` serialised behind A's failing provision (B asserted
blocked), A rolls back, B commits — principal SURVIVES (`require_member`
proves it; V008 printed False here). (2) Out-of-transaction mutation rejected
at the adapter for principal store, audit sink and work-object store. (3)
Failed bind leaves the unbound store unbound and the bound store on its
original domain. Plus covered-join execution, uncovered-nesting rejection,
bare re-entry rejection, and joined-provision protected by enclosing rollback.

## How to verify
```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r platform/requirements-dev.txt
cd platform && PYTHONHASHSEED=0 python3 scripts/gates/run_gates.py release   # twice — identical
```
Counts in evidence only (DOC C2); pip freeze, double-ladder idempotence and
tree digests in `evidence/g11_packaging.json` + sidecar.

## Honest notes
- Store READS remain outside transactions (single-map lookups; consistent
  multi-read snapshots are an INF-001 obligation) — stated, not hidden.
- The runtime mutation guard is the in-memory adapter's mechanism; the
  PostgreSQL adapter inherits equivalent enforcement from database
  transactions. SEC-001, AUD-004 and external mutation tooling remain
  declared.
