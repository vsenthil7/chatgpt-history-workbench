# Handoff for Independent ChatGPT Review — Claude build V006 (hardening release)

Scope: exactly the seven findings of the 2026-08-09 09:34 deeper review — no
feature tranche, no architectural restart, all verified V005 fixes preserved.
Dispositions: `11-issues/REVIEW-FINDINGS-V005.md` (F1–F7 all FIXED, none
dropped). OD-001 remains OPEN. The architecture baseline is NOT self-declared
frozen.

## Product changes (0.4.0 → 0.5.0, breaking, no external consumer)
- ADR-016 command unit of work: `UnitOfWork` port; every mutating registry
  command commits domain + audit writes atomically; in-memory adapter
  snapshot/restores work-object, evidence and audit stores together.
- ADR-002 addendum: new mutation-critical `guards` module; every
  repository-returned aggregate revalidated (work object id+tenancy; child
  tenancy+parentage; evidence id+tenancy+linkage; organisation identity;
  principal identity+tenancy with normalised non-oracle messaging).
- DEF-023 policy architecture: `CompletionPolicy.violations(work_object,
  verified_evidence)` — the registry resolves and validates every referenced
  evidence record before the policy judges it.
- ADR-017 persistence integrity: repository `create` vs `update(...,
  expected_version=)`; duplicate-id rejection everywhere; published
  `ConcurrencyError`; registry read-version CAS flow.
- ADR-018: G07 mutation scope now state + policy + guards + audit +
  organisation (all mutants killed); the service-orchestration exclusion is
  justified in the ADR, not silent.

## Regression protection (the review's exact executed probes)
Audit-sink fault injection on create/transition/attach (nothing persists);
hostile `children_of` foreign and wrong-parentage leaks fail closed; hostile
evidence and organisation wrong-row reads fail closed; wrong-row membership
"proof" rejected (same-org and foreign-org variants); dangling evidence id
blocks critical completion while verified evidence permits it; duplicate ids
rejected per repository; both-writers-read-v1 stale write raises
`ConcurrencyError` and the first write survives.

## How to verify
```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r platform/requirements-dev.txt
cd platform && PYTHONHASHSEED=0 python3 scripts/gates/run_gates.py release   # twice — identical
```
Counts live in evidence only (DOC C2). Clean-room pip freeze, double-ladder
idempotence and tree digests: `evidence/g11_packaging.json` + sidecar JSON.

## Honest notes
- Deferred, declared: SEC-001 roles/permissions; AUD-004 delegated recording;
  INF-001 PostgreSQL (UnitOfWork/provisioner become database transactions;
  CAS becomes `UPDATE … WHERE version = expected`); external mutation tool in
  real CI (ADR-004/018); no remote CI in this environment.
- The registry re-reads inside each command, so registry-level interleaving is
  represented at the repository CAS boundary; a cross-process interleaving
  test requires real concurrency infrastructure and is part of INF-001's
  obligations, stated here rather than claimed.
