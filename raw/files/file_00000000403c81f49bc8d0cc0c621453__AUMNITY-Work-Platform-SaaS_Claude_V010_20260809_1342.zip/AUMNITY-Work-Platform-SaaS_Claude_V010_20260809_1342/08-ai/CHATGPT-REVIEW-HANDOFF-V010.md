# Handoff for Independent ChatGPT Review — Claude build V010 (hardening release)

Scope: exactly the V009 review — read-side consistency and validate→write
atomicity. No feature tranche; freeze not self-declared. Dispositions:
`11-issues/REVIEW-FINDINGS-V009.md`. OD-001 OPEN.

## Product changes (0.8.0 → 0.9.0, behavioural)
ADR-023 completes ADR-022's symmetry: EVERY public kernel operation is one
transaction.
- `UnitOfWork.read(operation)` on the port: whole multi-store reads execute
  inside the serialisation domain (get incl. reference-integrity lookups,
  children incl. every child, evidence_for incl. every record and submitter
  proof, entries_for, get_organisation, require_member); reads join any
  active transaction; the mutex now distinguishes WRITABLE transactions and
  the adapter mutation guard requires one — a read path that writes fails
  mechanically.
- Validate→write atomicity everywhere: directory `create_principal`, audit
  `record`, and every registry command (`create`, all transitions,
  `attach_evidence`, `complete` including policy verification) run their full
  validate→write sequence inside one write transaction; internal reads join.
- Honest scope: consistency is PER OPERATION; caller-scoped multi-call read
  views are DECLARED (RTM RD-002); INF-001 maps both modes to database
  transactions.

## Regression protection (the exact executed probes, deterministic)
Torn read: reader paused inside `evidence_for` between parent and record
loads; concurrent attach asserted BLOCKED; reader's returned view is exactly
the pre-attach state; post-release state shows both records. TOCTOU: creator
paused inside `create_principal`'s membership validation (now in-transaction);
a competing provision asserted EXCLUDED until the validate→write section
completes; principal exists afterwards. Plus mutation-inside-read rejected at
the adapter.

## How to verify
```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r platform/requirements-dev.txt
cd platform && PYTHONHASHSEED=0 python3 scripts/gates/run_gates.py release   # twice — identical
```
Counts in evidence only (DOC C2); pip freeze, double-ladder idempotence and
tree digests in `evidence/g11_packaging.json` + sidecar.

## Honest notes
- Reads now serialise briefly with writers in the in-memory adapter —
  correctness over concurrency; the PostgreSQL adapter (INF-001) gets MVCC.
- SEC-001, AUD-004, RD-002 and external mutation tooling remain declared.
