# Changelog — AUMNITY Work Platform (product code)

## 0.13.0 — 2026-08-09 (Claude build V014, hardening release after independent V013 freeze-oriented review)
All twelve V013 findings closed (`11-issues/REVIEW-FINDINGS-V013.md`).
Hardening only — no new platform functionality. F01–F04 were reproduced
against the untouched V013 package before any change.
- ADR-027 (DEF-042/043, F03 BLOCKER + F10): runtime type boundary — enum
  membership and 64-lowercase-hex digest syntax validated at aggregate
  construction. Raw "CRITICAL" no longer bypasses the evidence policy.
- ADR-028 (DEF-044, F01 BLOCKER): rollback is transaction-internal — private
  `_restore_snapshot` guarded by current-frame WRITE mode and current-scope
  coverage on all five stores.
- ADR-029 (DEF-045, F04 HIGH): rollback covers BaseException, re-raising the
  original exception unchanged.
- ADR-030 (DEF-046, F02 BLOCKER): one public operation, one transaction —
  `assign`, `resume`, `block`, `unblock`, `restart_after_rework` no longer
  read in a separate transaction from their write.
- ADR-034 (DEF-047, F05 HIGH): machine-derived MUTATION-INVENTORY.json and
  new gate G12 gate the RTM's universal claims on population completeness.
- ADR-031/032/033/035/036 (DEF-048..053, F06–F09/F11/F12): Clock port
  enforcement, bare-frame kind, normalised tenant-neutrality matching,
  provenance-clean evidence and current-version handoff, and a release proof
  that states its scope with two named digests.

## 0.12.0 — 2026-08-09 (Claude build V013, correction release after independent V012 freeze-oriented review)
Fix for the single V012 finding (`11-issues/REVIEW-FINDINGS-V012.md`);
deliberately narrow — no new platform functionality, per the review.
- ADR-026 (DEF-041, V012 review F1 BLOCKER): transaction mode is a frame
  property. Every frame carries {declared stores, READ|WRITE}; the global
  `_writable` boolean is eliminated; a joined `read()` pushes a READ frame so
  read-only holds regardless of ambient context; a WRITE frame cannot be
  pushed under a READ frame. The review's executed probe
  (`run(read(add))` persisting an Organisation) is a permanent regression
  with zero-mutation assertions (RTM RD-003).

## 0.11.0 — 2026-08-09 (Claude build V012, correction release after independent V011 deep review)
Fixes for both V011 findings (`11-issues/REVIEW-FINDINGS-V011.md`).
- ADR-025 (DEF-039, V011 review F1 BLOCKER): nested transaction scopes are
  mutation boundaries. The serialisation domain maintains a scope stack;
  store mutation is authorised against the CURRENT scope only (ambient
  writability is no longer authority); joins enforce nested scope ⊆
  IMMEDIATE parent scope; base transactions and bare critical sections
  follow the same uniform rule (bare sections grant no writes and accept no
  joins). The reviewer's executed Principal-leak probe and the
  child-coordinator escape attempt are permanent regressions (RTM TXN-007).
- DEF-040 (V011 review F2): the 188-vs-168 release headline discrepancy is
  recorded openly; G11 now emits a machine-derived `release_summary` in the
  release-validation sidecar (pytest collection, coverage/mutation evidence,
  ZIP entry count, all from the extracted final ZIP) and release counts are
  quoted from it, never hand-typed.

## 0.10.0 — 2026-08-09 (Claude build V011, correction release after independent V010 deep review)
Fixes for the V010 findings (`11-issues/REVIEW-FINDINGS-V010.md`), including
the actual V009 blocker V010 failed to carry (DEF-036/DEF-037).
- ADR-024: savepoint semantics on every covered transaction join (generic
  UnitOfWork and TenantProvisioner) — a caught nested failure leaves zero
  nested effects; outer pre-join work survives; successful joins commit.
- DEF-038: snapshot()/restore() purity contract documented at the port and
  adapter boundary.
- DEF-037: review ledger repaired; DEF-034/DEF-035 attribution corrected
  openly; ADR-023 attribution addendum; new verbatim-source packaging rule.

## 0.9.0 — 2026-08-09 (Claude build V010, hardening release after independent V009 deep review)
Fixes for the V009 findings (`11-issues/REVIEW-FINDINGS-V009.md`).
- ADR-023: every public kernel operation is ONE transaction. `UnitOfWork`
  gains `read(operation)`; all multi-store reads are consistent; read
  transactions grant no mutation rights (writable-mode guard); every
  mutating operation runs its full validate→write sequence inside one write
  transaction. Per-operation scope stated; RD-002 declared for caller-scoped
  read views.

## 0.8.0 — 2026-08-09 (Claude build V009, hardening release after independent V008 deep review)
Fixes for the V008 findings (`11-issues/REVIEW-FINDINGS-V008.md`).
- BREAKING (ADR-022): `OrganisationDirectory` and `AuditLog` require a
  `UnitOfWork`; their writes are transactional. The serialisation domain
  registers covered stores; coordinators join ambient transactions only under
  snapshot coverage (evolves the V006 nesting contract); adapter mutators
  reject out-of-transaction writes; `bind_serialisation_domain` is atomic;
  `InMemoryUnitOfWork(*stores)` generalised; composition root gains
  `identity_unit_of_work`/`audit_unit_of_work`.

## 0.7.0 — 2026-08-09 (Claude build V008, hardening release after independent V007 deep review)
Fixes for the V007 findings (`11-issues/REVIEW-FINDINGS-V007.md`).
- BREAKING (ADR-021): serialisation domains are machine-derived. Stores bind
  to at most one domain; `InMemoryUnitOfWork`/`InMemoryTenantProvisioner`
  no longer take a mutex and reject unbound or mixed-domain participants;
  new `InMemoryPlatformStores` composition root; `bind_serialisation_domain`
  helper. Independent locking over shared stores is not expressible.
- G07 evidence enumerates every executed mutation operator (DEF-031).

## 0.6.0 — 2026-08-09 (Claude build V007, hardening release after independent V006 deep review)
Fixes for the three V006 findings (`11-issues/REVIEW-FINDINGS-V006.md`).
- BREAKING (ADR-019): `InMemoryUnitOfWork` and `InMemoryTenantProvisioner`
  require a shared `TransactionMutex`; transactions are serialised per store
  composition; a failed transaction can never erase a committed concurrent
  one; nesting raises `ValidationError`.
- ADR-020: whole-aggregate reference integrity — embedded principal
  references and evidence submitters proven members before disclosure or
  completion counting.
- ADR-018 amended: mutation scope now includes `workobject/service.py` and
  `adapters/memory.py`; no integrity-bearing module excluded.

## 0.5.0 — 2026-08-09 (Claude build V006, hardening release after independent V005 deeper review)
Fixes for the seven adversarially executed findings
(`11-issues/REVIEW-FINDINGS-V005.md`).
- BREAKING (ADR-016): `WorkObjectRegistry` requires a `UnitOfWork`; every
  mutating command commits domain and audit writes atomically.
- BREAKING (ADR-017): `WorkObjectRepository.save` replaced by `create` +
  `update(..., expected_version=)`; duplicate ids rejected on all repository
  create/add paths; new published `ConcurrencyError` (contracts).
- BREAKING (DEF-023): `CompletionPolicy.violations(work_object,
  verified_evidence)` — policies judge registry-verified evidence records.
- ADR-002 addendum: `guards` module revalidates every repository-returned
  aggregate (identity/tenancy/linkage); defective adapters fail closed;
  membership errors normalised (no existence oracle).
- ADR-018: mutation-critical scope expanded to guards/audit/organisation.

## 0.4.0 — 2026-08-09 (Claude build V005, hardening release after independent V004 review)
Fixes for independently reproduced V004 defects (`11-issues/REVIEW-FINDINGS-V004.md`).
- BREAKING (ADR-013): `OrganisationRegistry` removed. Published
  `OrganisationDirectory.get_organisation(context)` returns only the caller's
  own organisation (no arbitrary-id lookup); `create_principal` and
  `require_member` unchanged in semantics. Trusted, UNPUBLISHED
  `PlatformProvisioning.create_organisation(...)` owns tenant creation.
  A machine-checked public-boundary inventory contract classifies every
  kernel export and enforces context-first methods on protected services.
- ADR-011 hardened: in-memory tenant provisioning is atomic for ALL failure
  shapes via snapshot/restore of both stores (explicit adapter transaction
  API); no orphan organisation or principal can survive.
- BREAKING (ADR-014): `AuditLog.record` requires the event actor to equal the
  bound acting principal; same-tenant impersonation raises `ValidationError`.
  Delegated recording declared (AUD-004), not overloaded onto one field.
- ADR-015: G10 C7 v2 gate-enforces current-doc version labels against
  ARTIFACT-VERSION; stale V003/V002 headings corrected.

## 0.3.0 — 2026-08-08 (Claude build V004, hardening release after independent V003 review)
Fixes for independently reproduced V003 defects (see
`11-issues/REVIEW-FINDINGS-V003.md`); breaking changes acceptable, no external
consumer of 0.2.0 exists.
- BREAKING (ADR-010): `AuditLog` is a protected boundary — constructor takes a
  `PrincipalDirectory`; `record(context, event)` binds the context, requires
  the event organisation to match it and proves the event actor is a member;
  `entries_for(context)` binds the acting principal. `AuditSink` remains
  infrastructure-trusted and unexported.
- BREAKING (ADR-011): tenant bootstrap atomicity moved to the
  `TenantProvisioner` port; `OrganisationRegistry` makes one all-or-nothing
  provision call; in-memory adapter implements compensating rollback.
- Release validation is non-mutating and idempotent (ADR-012): release-mode
  gate output goes to an external evidence directory; G11 proves double-ladder
  idempotence on the extracted final ZIP with tree-digest comparison.
- Defect log reconciled into one chronological record (DEF-013); G10 gains
  C5–C7 (stale gate-script references, defect-ID consistency, stale slice
  labels); stale "V002 slice" labels removed from product descriptions.

## 0.2.0 — 2026-08-08 (Claude build V003, corrective release after independent review)
Fixes for independently reproduced V002 defects (see
`11-issues/REVIEW-FINDINGS-V002.md`); breaking changes were acceptable because
no external consumer of 0.1.0 exists.
- BREAKING (ADR-007): `OrganisationRegistry.create_organisation(name,
  founder_display_name, founder_kind)` now atomically returns `(Organisation,
  Principal)`; `require_principal` replaced by `require_member`, which raises
  `TenantIsolationError` for unknown AND foreign principals alike.
- BREAKING (ADR-007): `WorkObjectRegistry` requires a `PrincipalDirectory`;
  every protected operation binds the acting principal to the context
  organisation, and owner/assignee references are validated as members.
- BREAKING (ADR-008): `EventEnvelope.payload` is a read-only
  `Mapping[str, str]` (defensive copy); mutation attempts raise `TypeError`.
- Toolchain contract (ADR-009): pinned `requirements-dev.txt` + dev extras;
  `run_gates.py` gains build/release modes with incoming-manifest verification;
  single canonical release gate `g11_release.py` with clean-venv full-ladder
  validation, deterministic double build and extracted-final-ZIP validation;
  artifact version read from root `ARTIFACT-VERSION`.
- G07 distinguishes dependency-unavailable / formatter-execution-error /
  baseline-not-formatted; G09 requires specific test node ids for high-risk
  tenancy rows (DW-FR-013, SaaS-002, TEN-001).

## 0.1.0 — 2026-08-08 (Claude build V002)
First implementation slice (ADR-003):
- `aumnity_contracts`: typed IDs, TenantContext, EventEnvelope, error taxonomy,
  deterministic clock/id providers, standardised source-system constants.
- `aumnity_kernel`: Organisation registry, Principal identity, Work Object
  registry with the baseline lifecycle state machine, versioning, recursive
  decomposition, minimal assignment, immutable evidence with completion policy,
  append-only tenant-scoped audit.
- In-memory adapters for all kernel ports.
- Quality gates G01–G10 as runnable evidence-producing scripts.
No public contract existed before this version; nothing is breaking.
