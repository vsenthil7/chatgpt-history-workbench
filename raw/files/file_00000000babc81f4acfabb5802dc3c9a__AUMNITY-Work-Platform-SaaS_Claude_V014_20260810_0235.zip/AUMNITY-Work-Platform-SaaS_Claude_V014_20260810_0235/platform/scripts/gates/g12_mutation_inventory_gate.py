#!/usr/bin/env python3
"""G12 — mutation-inventory completeness gate (ADR-034, V013 review F05).

The RTM makes UNIVERSAL claims: every mutation participates in a transaction
(TXN-004), the current scope is the mutation boundary (TXN-007), every public
operation is one transaction (RD-001), read-only is context-independent
(RD-003). G09 verifies that the test nodes a row cites are collectable — which
proves the SAMPLE exists, not that the sample is the whole population. V013
failed exactly there: five unguarded `restore()` primitives and two
two-transaction commands existed while those rows read ENFORCED.

This gate closes the gap by deriving the population from the source itself:

  * adapter mutation primitives — every method in the memory adapter whose
    body calls a mutation/rollback guard;
  * published mutating operations — every public method of a kernel service
    that opens or joins a unit of work.

It then requires EXACT correspondence with `06-traceability/MUTATION-INVENTORY.json`
in BOTH directions (nothing undeclared, nothing stale), requires every entry to
cite regression nodes of the required kinds, and verifies each cited node is
individually collectable by pytest. Adding a mutating operation without
declaring and covering it therefore fails the ladder.
"""

import ast
import json
import subprocess
import sys

from _common import PLATFORM_ROOT, REPO_ROOT, write_evidence

INVENTORY_PATH = REPO_ROOT / "06-traceability" / "MUTATION-INVENTORY.json"
KERNEL = PLATFORM_ROOT / "packages" / "aumnity_kernel" / "src" / "aumnity_kernel"
ADAPTER = KERNEL / "adapters" / "memory.py"
SERVICE_MODULES = ("organisation.py", "audit.py", "workobject/service.py")
GUARDS = ("_require_mutation_context", "_require_rollback_context")
TRANSACTION_ENTRY_POINTS = ("run", "provision", "_transition", "_transition_in_transaction")
REQUIRED_NEGATIVE_KINDS = (
    "outside_any_transaction",
    "inside_top_level_read",
    "inside_read_joined_into_write",
    "nested_scope_that_did_not_declare_the_store",
)


def _called_names(node: ast.AST) -> set[str]:
    names: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Call):
            function = child.func
            if isinstance(function, ast.Attribute):
                names.add(function.attr)
            elif isinstance(function, ast.Name):
                names.add(function.id)
    return names


def _derive_primitives() -> set[tuple[str, str]]:
    tree = ast.parse(ADAPTER.read_text())
    found: set[tuple[str, str]] = set()
    for klass in (n for n in tree.body if isinstance(n, ast.ClassDef)):
        for function in (n for n in klass.body if isinstance(n, ast.FunctionDef)):
            if function.name in GUARDS:
                continue
            if _called_names(function) & set(GUARDS):
                found.add((klass.name, function.name))
    return found


def _derive_operations() -> set[tuple[str, str]]:
    found: set[tuple[str, str]] = set()
    for relative in SERVICE_MODULES:
        tree = ast.parse((KERNEL / relative).read_text())
        for klass in (n for n in tree.body if isinstance(n, ast.ClassDef)):
            for function in (n for n in klass.body if isinstance(n, ast.FunctionDef)):
                if function.name.startswith("_"):
                    continue
                if _called_names(function) & set(TRANSACTION_ENTRY_POINTS):
                    found.add((klass.name, function.name))
    return found


def _collectable(node: str) -> bool:
    run = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "--collect-only",
            "-p",
            "no:cacheprovider",
            node,
        ],
        cwd=PLATFORM_ROOT,
        capture_output=True,
        text=True,
        env={
            "PYTHONHASHSEED": "0",
            # ADR-036: no bytecode in the tree being validated read-only.
            "PYTHONDONTWRITEBYTECODE": "1",
            "PATH": "/usr/bin:/bin",
            "PYTHONPATH": "packages/aumnity_contracts/src:packages/aumnity_kernel/src",
        },
    )
    # Count the collected node ids themselves rather than parsing a summary
    # line: the -q summary format differs across pytest versions, and an exact
    # count is what this gate actually needs (exactly one test per cited node).
    collected = [line for line in run.stdout.splitlines() if "::" in line]
    return run.returncode == 0 and len(collected) == 1


def main() -> int:
    inventory = json.loads(INVENTORY_PATH.read_text())
    failures: list[str] = []

    declared_primitives = {
        (entry["store"], entry["method"]) for entry in inventory["adapter_mutation_primitives"]
    }
    declared_operations = {
        (entry["service"], entry["operation"])
        for entry in inventory["published_mutating_operations"]
    }
    derived_primitives = _derive_primitives()
    derived_operations = _derive_operations()

    for store, method in sorted(derived_primitives - declared_primitives):
        failures.append(f"undeclared adapter mutation primitive in source: {store}.{method}")
    for store, method in sorted(declared_primitives - derived_primitives):
        failures.append(f"inventory declares a primitive that no longer exists: {store}.{method}")
    for service, operation in sorted(derived_operations - declared_operations):
        failures.append(f"undeclared published mutating operation: {service}.{operation}")
    for service, operation in sorted(declared_operations - derived_operations):
        failures.append(
            f"inventory declares an operation that no longer exists: {service}.{operation}"
        )

    nodes: set[str] = set()
    for entry in inventory["adapter_mutation_primitives"]:
        name = f"{entry['store']}.{entry['method']}"
        cited = entry.get("negative_test_nodes", [])
        for kind in REQUIRED_NEGATIVE_KINDS:
            if not any(kind in node for node in cited):
                failures.append(f"{name}: missing negative regression for '{kind}'")
        nodes.update(cited)
    for entry in inventory["published_mutating_operations"]:
        name = f"{entry['service']}.{entry['operation']}"
        if entry.get("single_transaction") is not True:
            failures.append(
                f"{name}: published mutating operations must declare single_transaction"
            )
        cited = entry.get("positive_test_nodes", [])
        if not cited:
            failures.append(f"{name}: no positive regression node cited")
        nodes.update(cited)

    unresolved = sorted(node for node in nodes if not _collectable(node))
    failures.extend(
        f"cited regression node does not resolve to exactly one test: {node}" for node in unresolved
    )

    status = "PASS" if not failures else "FAIL"
    write_evidence(
        "g12_mutation_inventory",
        {
            "status": status,
            "adapter_mutation_primitives": len(derived_primitives),
            "published_mutating_operations": len(derived_operations),
            "regression_nodes_verified": len(nodes),
            "derivation": "AST over the memory adapter and kernel service modules",
            "failures": failures,
        },
    )
    print(
        f"G12 {status}: {len(derived_primitives)} primitives, "
        f"{len(derived_operations)} published operations, {len(nodes)} regression nodes"
    )
    for failure in failures:
        print(" -", failure)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
