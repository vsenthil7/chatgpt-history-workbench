#!/usr/bin/env python3
"""G11 — the single canonical release gate (V002 review Findings 9/10 consolidated).

Procedure:
  1. Stage a pristine copy of the repository (caches stripped).
  2. CLEAN-ROOM VALIDATION (V002 review Finding 4/5): create a fresh venv,
     install ONLY the pinned toolchain from requirements-dev.txt, and run the
     COMPLETE gate ladder (run_gates.py release) inside the staged copy with
     that venv. This proves: declared Python + declared pins -> full ladder PASS.
  3. Write evidence into the working tree; regenerate the manifest so the
     release manifest covers that evidence; verify it.
  4. Re-stage and build the release ZIP twice with normalised metadata; the two
     hashes must match (deterministic build).
  5. FINAL-PACKAGE VALIDATION (ADR-012, V003 review Finding 4): extract the
     exact final ZIP, hash every manifest-controlled file, then run the full
     release ladder TWICE on the same extraction with G01 verified after each
     run, then rehash. Both ladders must PASS with no regeneration and the
     tree hash must be unchanged — release validation is proven read-only and
     idempotent. Verification evidence goes to external per-run directories;
     results are written NEXT TO the ZIP (they cannot live inside an archive
     whose bytes they describe).

Artifact naming (V002 review Finding 10): the artifact version is read from the
repository root ARTIFACT-VERSION file — packaging logic is never hand-edited
per release. ZIP name: AUMNITY-Work-Platform-SaaS_Claude_<ARTIFACT-VERSION>_<UTC+1 stamp>.zip
"""

import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import venv
import zipfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

from _common import REPO_ROOT, write_evidence

EXCLUDED_PARTS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".coverage"}
PRODUCT = "AUMNITY-Work-Platform-SaaS"


def _artifact_version() -> str:
    return (REPO_ROOT / "ARTIFACT-VERSION").read_text().strip()


def _stage(destination: Path) -> None:
    shutil.copytree(
        REPO_ROOT, destination, ignore=shutil.ignore_patterns(*EXCLUDED_PARTS, ".coverage")
    )


def _bootstrap_venv(venv_dir: Path, requirements: Path) -> Path:
    venv.EnvBuilder(with_pip=True, clear=True).create(venv_dir)
    python = venv_dir / "bin" / "python"
    install = subprocess.run(
        [str(python), "-m", "pip", "install", "--quiet", "-r", str(requirements)],
        capture_output=True,
        text=True,
    )
    if install.returncode != 0:
        raise RuntimeError(f"toolchain bootstrap failed:\n{install.stderr}")
    return python


def _normalise_release(text: str, work: Path, python: Path) -> str:
    """ADR-035 (V013 review F08, DEF-051): the release procedure runs from a
    temporary work directory with a temporary venv, so its captured output
    would otherwise embed build-machine absolute roots in shipped packaging
    evidence. Roots are replaced with stable tokens; the evidence stays
    readable and carries no machine-specific provenance."""
    return (
        text.replace(str(python), "<release-venv-python>")
        .replace(f"{work}/extracted", "<extracted>")
        .replace(f"{work}/staged", "<staged>")
        .replace(str(work), "<release-work>")
    )


def _release_ladder(python: Path, tree: Path, evidence_dir: Path, work: Path) -> dict[str, object]:
    evidence_dir.mkdir(parents=True, exist_ok=True)
    run = subprocess.run(
        [str(python), str(tree / "platform/scripts/gates/run_gates.py"), "release"],
        cwd=tree / "platform",
        capture_output=True,
        text=True,
        env={
            "PYTHONHASHSEED": "0",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PATH": "/usr/bin:/bin",
            "HOME": "/tmp",
            "AUMNITY_EVIDENCE_DIR": str(evidence_dir),
        },
    )
    return {
        "returncode": run.returncode,
        "status": "PASS" if run.returncode == 0 else "FAIL",
        "stdout_tail": _normalise_release(run.stdout, work, python).strip().splitlines()[-18:],
        "stderr_tail": _normalise_release(run.stderr, work, python).strip().splitlines()[-8:],
    }


def _manifest_verifies(python: Path, tree: Path, evidence_dir: Path) -> bool:
    run = subprocess.run(
        [str(python), str(tree / "platform/scripts/gates/g01_validate_package.py")],
        cwd=tree,
        capture_output=True,
        text=True,
        env={
            "PYTHONHASHSEED": "0",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PATH": "/usr/bin:/bin",
            "HOME": "/tmp",
            "AUMNITY_EVIDENCE_DIR": str(evidence_dir),
        },
    )
    return run.returncode == 0


def _collected_tests(python: Path, tree: Path, suite: str) -> int:
    """Derive a collected-test count from pytest itself against the extracted
    final ZIP (DEF-040: release headline counts are machine-derived, never
    hand-typed). Collection is read-only; the surrounding tree-digest
    comparison proves it."""
    run = subprocess.run(
        [
            str(python),
            "-m",
            "pytest",
            f"tests/{suite}",
            "--collect-only",
            "-q",
            "-p",
            "no:cacheprovider",
        ],
        cwd=tree / "platform",
        capture_output=True,
        text=True,
        env={
            "PYTHONHASHSEED": "0",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PATH": "/usr/bin:/bin",
            "HOME": "/tmp",
        },
    )
    match = re.search(r"(\d+) tests collected", run.stdout)
    if match is not None:
        return int(match.group(1))
    per_file = re.findall(r"^\S+\.py: (\d+)$", run.stdout, flags=re.MULTILINE)
    if per_file:
        return sum(int(count) for count in per_file)
    raise RuntimeError(f"cannot derive collected-test count for {suite}:\n{run.stdout}")


def _release_summary(
    python: Path, extracted_root: Path, evidence_dir: Path, zip_path: Path
) -> dict[str, object]:
    """The single machine-derived source for every release headline number
    (DEF-040, V011 review F2): test counts from pytest collection against the
    extracted final ZIP; coverage and mutation numbers from that ZIP's own
    release-ladder evidence; the file count from the ZIP itself. The release
    handoff quotes THIS block; hand-typed totals are prohibited."""
    suites = {
        s: _collected_tests(python, extracted_root, s) for s in ("unit", "contract", "isolation")
    }
    coverage = json.loads((evidence_dir / "g04_coverage.json").read_text())["totals"]
    mutation = json.loads((evidence_dir / "g07_mutation.json").read_text())
    with zipfile.ZipFile(zip_path) as archive:
        zip_files = len([name for name in archive.namelist() if not name.endswith("/")])
    return {
        "derivation": "machine-generated from the extracted final ZIP (pytest "
        "collection, run-1 ladder evidence, ZIP entry count); release headline "
        "counts must be quoted from this block, never hand-typed (DEF-040)",
        "tests_collected": {**suites, "total": sum(suites.values())},
        "coverage": {
            "statements": coverage["num_statements"],
            "missing_statements": coverage["missing_lines"],
            "branches": coverage["num_branches"],
            "missing_branches": coverage["missing_branches"],
            "percent_covered": coverage["percent_covered"],
        },
        "mutation": {
            "mutants_generated": mutation["mutants_generated"],
            "mutants_killed": mutation["mutants_killed"],
            "survivors": len(mutation["survivors"]),
        },
        "zip_file_count": zip_files,
    }


# ADR-036 (V013 review F09, DEF-052): the four self-referential packaging
# artefacts. The manifest cannot contain its own hash, and the packaging
# evidence written BY the release procedure cannot contain the hash of a file
# that includes it. They are named explicitly so the exclusion is a declared
# fact rather than an unstated consequence of digesting manifest entries.
SELF_REFERENTIAL_PATHS = (
    "PACKAGE-MANIFEST.json",
    "platform/evidence/g01_manifest.json",
    "platform/evidence/g11_packaging.json",
    "platform/evidence/gate_ladder.json",
)


def _manifest_corpus_digest(tree: Path) -> str:
    """One digest over every MANIFEST-CONTROLLED file (path + content).

    Named for what it actually covers (ADR-036): V013 reported this as a
    "tree digest", which could be read as proving all 176 extracted files
    unchanged when it covered the 172 manifest entries. It is paired with
    `_full_extraction_digest` below, which covers everything.
    """
    import json as _json

    manifest = _json.loads((tree / "PACKAGE-MANIFEST.json").read_text())
    digest = hashlib.sha256()
    for entry in manifest["files"]:
        digest.update(entry["path"].encode())
        digest.update((tree / entry["path"]).read_bytes())
    return digest.hexdigest()


def _extraction_map(tree: Path) -> dict[str, str]:
    """Per-file hashes of the whole extraction, so a failed read-only claim
    NAMES the offending paths instead of only reporting a digest mismatch
    (ADR-036/DEF-054: the first full-extraction failure cost a separate
    diagnostic pass to attribute)."""
    return {
        path.relative_to(tree).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in tree.rglob("*")
        if path.is_file()
    }


def _extraction_drift(before: dict[str, str], after: dict[str, str]) -> dict[str, list[str]]:
    return {
        "added": sorted(set(after) - set(before)),
        "removed": sorted(set(before) - set(after)),
        "modified": sorted(k for k in before if k in after and before[k] != after[k]),
    }


def _full_extraction_digest(tree: Path) -> str:
    """One digest over EVERY file in the extracted package — including the
    four self-referential artefacts (ADR-036). Nothing is excluded here: the
    read-only release ladder writes its evidence to an external directory, so
    even the self-referential files must be byte-identical before and after."""
    digest = hashlib.sha256()
    for path in sorted(p for p in tree.rglob("*") if p.is_file()):
        digest.update(path.relative_to(tree).as_posix().encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _build_zip(staged: Path, target: Path) -> str:
    files = sorted(
        p
        for p in staged.rglob("*")
        if p.is_file() and not any(part in EXCLUDED_PARTS for part in p.parts)
    )
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            info = zipfile.ZipInfo(
                f"{target.stem}/{path.relative_to(staged).as_posix()}",
                date_time=(2026, 8, 8, 0, 0, 0),
            )
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
    return hashlib.sha256(target.read_bytes()).hexdigest()


def main() -> int:
    output_dir = Path(sys.argv[1])
    stamp = (datetime.now(UTC) + timedelta(hours=1)).strftime("%Y%m%d_%H%M")
    zip_name = f"{PRODUCT}_Claude_{_artifact_version()}_{stamp}.zip"
    gates_dir = Path(__file__).resolve().parent

    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        python = _bootstrap_venv(work / "venv", REPO_ROOT / "platform" / "requirements-dev.txt")
        pip_freeze = (
            subprocess.run([str(python), "-m", "pip", "freeze"], capture_output=True, text=True)
            .stdout.strip()
            .splitlines()
        )

        # Step 2: clean-room full ladder on a pristine staged copy.
        staged = work / "staged"
        _stage(staged)
        clean_room = _release_ladder(python, staged, work / "evidence-cleanroom", work)
        write_evidence(
            "g11_packaging",
            {
                "status": clean_room["status"],
                "clean_room": {
                    "python": "fresh venv (python -m venv), no inherited site-packages",
                    "installed_from": "platform/requirements-dev.txt",
                    "pip_freeze": pip_freeze,
                    "release_ladder": clean_room,
                },
                "final_package_validation": "performed on the extracted final ZIP; "
                "results written next to the ZIP (cannot live inside the archive "
                "whose bytes they describe)",
            },
        )
        if clean_room["status"] != "PASS":
            print("G11 FAIL: clean-room release ladder failed")
            print(json.dumps(clean_room, indent=2))
            return 1
        print("G11 step 2: clean-room full ladder PASS (fresh venv, pinned toolchain)")

        # Step 3: release manifest covers the evidence written above.
        for argument in (["generate"], []):
            check = subprocess.run(
                [sys.executable, str(gates_dir / "g01_validate_package.py"), *argument],
                cwd=REPO_ROOT,
                capture_output=True,
                text=True,
                env={"PYTHONHASHSEED": "0", "PATH": "/usr/bin:/bin", "HOME": "/tmp"},
            )
            if check.returncode != 0:
                print(f"G11 FAIL: release manifest step {argument or ['verify']}: {check.stdout}")
                return 1
        print("G11 step 3: release manifest regenerated and verified")

        # Step 4: deterministic double build.
        release_stage = work / "release"
        _stage(release_stage)
        first_hash = _build_zip(release_stage, output_dir / zip_name)
        second_hash = _build_zip(release_stage, work / zip_name)
        if first_hash != second_hash:
            print(f"G11 FAIL: builds differ: {first_hash} != {second_hash}")
            return 1
        print(f"G11 step 4: deterministic build PASS ({first_hash})")

        # Step 5: extracted-final-ZIP double-ladder idempotence proof (ADR-012).
        extraction = work / "extracted"
        with zipfile.ZipFile(output_dir / zip_name) as archive:
            archive.extractall(extraction)
        extracted_root = extraction / Path(zip_name).stem
        corpus_before = _manifest_corpus_digest(extracted_root)
        extraction_before = _full_extraction_digest(extracted_root)
        extraction_map_before = _extraction_map(extracted_root)
        ladder_one = _release_ladder(python, extracted_root, work / "evidence-run1", work)
        g01_after_one = _manifest_verifies(python, extracted_root, work / "evidence-run1")
        ladder_two = _release_ladder(python, extracted_root, work / "evidence-run2", work)
        g01_after_two = _manifest_verifies(python, extracted_root, work / "evidence-run2")
        # DEF-040: derive the headline numbers BEFORE the final digest so the
        # digest comparison also proves the derivation itself was read-only.
        summary = _release_summary(
            python, extracted_root, work / "evidence-run1", output_dir / zip_name
        )
        corpus_after = _manifest_corpus_digest(extracted_root)
        extraction_after = _full_extraction_digest(extracted_root)
        drift = _extraction_drift(extraction_map_before, _extraction_map(extracted_root))
        idempotent = (
            ladder_one["status"] == "PASS"
            and ladder_two["status"] == "PASS"
            and g01_after_one
            and g01_after_two
            and corpus_before == corpus_after
            and extraction_before == extraction_after
        )
        report = {
            "zip": zip_name,
            "sha256": first_hash,
            "deterministic_double_build": "PASS",
            "release_summary": summary,
            "extracted_final_zip": {
                "manifest_controlled_corpus_digest_before": corpus_before,
                "full_extraction_digest_before": extraction_before,
                "digest_scope": {
                    "manifest_controlled_corpus": "the manifest's file entries "
                    "(path + content); excludes the self-referential artefacts below",
                    "full_extraction": "EVERY file in the extracted package, "
                    "including the self-referential artefacts (ADR-036)",
                    "self_referential_paths": list(SELF_REFERENTIAL_PATHS),
                },
                "release_ladder_run_1": ladder_one,
                "g01_verifies_after_run_1": g01_after_one,
                "release_ladder_run_2": ladder_two,
                "g01_verifies_after_run_2": g01_after_two,
                "manifest_controlled_corpus_digest_after": corpus_after,
                "full_extraction_digest_after": extraction_after,
                "full_extraction_drift": drift,
                "read_only_idempotent_validation": "PASS" if idempotent else "FAIL",
            },
        }
        (output_dir / f"{Path(zip_name).stem}.release-validation.json").write_text(
            json.dumps(report, indent=2) + "\n"
        )
        print(f"G11 step 5: ladder run 1 {ladder_one['status']}; G01 after: {g01_after_one}")
        print(f"G11 step 5: ladder run 2 {ladder_two['status']}; G01 after: {g01_after_two}")
        print(
            "G11 step 5: manifest-controlled corpus unchanged: "
            f"{corpus_before == corpus_after}; full extraction unchanged: "
            f"{extraction_before == extraction_after}"
        )
        if extraction_before != extraction_after:
            print(f"G11 step 5: extraction drift: {json.dumps(drift)}")
        print(f"G11 release summary (machine-derived, DEF-040): {json.dumps(summary)}")
        for line in ladder_two["stdout_tail"]:
            print("   ", line)
        print(f"zip: {output_dir / zip_name}")
        print(f"sha256: {first_hash}")
        return 0 if idempotent else 1


if __name__ == "__main__":
    sys.exit(main())
