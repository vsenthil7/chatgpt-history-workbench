#!/usr/bin/env python3
"""G10 — documentation consistency gate.

Checks (all machine-verifiable, no manual counts):
  C1 product version string identical in pyproject.toml, VERSION and CHANGELOG.
  C2 narrative docs contain no hard-coded test counts (pattern '<N> tests pass');
     counts must live only in generated evidence.
  C3 every ADR listed in ADR-INDEX exists in that file (single-file index).
  C4 all relative doc links in new authoritative docs resolve
     (10-baseline/ is preserved history and exempt: ISS-002).
  C5 every gate-script filename referenced in current docs and the RTM exists
     in scripts/gates/ (V003 review Finding 5: stale canonical-gate names).
     The defect log's rows are a historical record and are exempt where marked.
  C6 defect-ID consistency: every DEF-nnn cited anywhere in current docs exists
     in the defect log, and the log defines each ID exactly once.
  C7 no stale current-version labels (ADR-015): product code/pyproject must
     not carry a stale "Vnnn slice" label, and current navigational/metadata
     surfaces (platform README, ADR index, RTM, 00-control) must be
     version-neutral or match ARTIFACT-VERSION on headings/nav lines.
     Historical records are exempt by scope.
  C8 the CURRENT (unversioned) ChatGPT review handoff declares the current
     ARTIFACT-VERSION (ADR-035, V013 review F06): until V013 that file still
     contained the V002 handoff while being cited as the review entry point.
  C9 shipped evidence is provenance-clean (ADR-035, V013 review F08): no
     build-machine absolute root and no foreign artifact-version package token
     may appear in evidence bodies.
"""

import re
import sys
import tomllib

from _common import PLATFORM_ROOT, REPO_ROOT, write_evidence

NEW_DOC_DIRS = ["00-control", "05-quality", "06-traceability", "08-ai", "11-issues", "12-adr"]


def main() -> int:
    failures: list[str] = []

    pyproject = tomllib.loads((PLATFORM_ROOT / "pyproject.toml").read_text())
    project_version = pyproject["project"]["version"]
    version_file = (PLATFORM_ROOT / "VERSION").read_text().strip()
    changelog = (PLATFORM_ROOT / "CHANGELOG.md").read_text()
    if version_file != project_version:
        failures.append(f"C1 VERSION={version_file} != pyproject={project_version}")
    if f"## {project_version}" not in changelog:
        failures.append(f"C1 CHANGELOG has no section for {project_version}")

    count_pattern = re.compile(r"\b\d+\s+tests?\s+pass", re.IGNORECASE)
    for directory in NEW_DOC_DIRS:
        for doc in sorted((REPO_ROOT / directory).rglob("*.md")):
            if count_pattern.search(doc.read_text()):
                failures.append(f"C2 hard-coded test count in {doc.relative_to(REPO_ROOT)}")

    adr_index = (REPO_ROOT / "12-adr" / "ADR-INDEX.md").read_text()
    for adr_id in re.findall(r"\| (ADR-\d+) \|", adr_index):
        if f"## {adr_id}" not in adr_index:
            failures.append(f"C3 {adr_id} listed but has no section")

    link_pattern = re.compile(r"\]\(((?!http)[^)#]+)\)")
    for directory in NEW_DOC_DIRS:
        for doc in sorted((REPO_ROOT / directory).rglob("*.md")):
            for link in link_pattern.findall(doc.read_text()):
                target = (doc.parent / link).resolve()
                if not target.exists():
                    failures.append(f"C4 broken link in {doc.relative_to(REPO_ROOT)}: {link}")

    gates_dir = PLATFORM_ROOT / "scripts" / "gates"
    existing_gate_scripts = {f.name for f in gates_dir.glob("*.py")}
    script_pattern = re.compile(r"\b(g\d{2}_[a-z_]+\.py|run_gates\.py)\b")
    defect_log = PLATFORM_ROOT / "evidence" / "defect-log.md"
    current_docs = [
        doc for directory in NEW_DOC_DIRS for doc in sorted((REPO_ROOT / directory).rglob("*.md"))
    ] + [PLATFORM_ROOT / "README.md", REPO_ROOT / "06-traceability" / "RTM.md"]
    historical_words = re.compile(
        r"removed|historical|stray|deleted|superseded|both old", re.IGNORECASE
    )
    for doc in current_docs:
        for line in doc.read_text().splitlines():
            for name in set(script_pattern.findall(line)):
                if name not in existing_gate_scripts and not historical_words.search(line):
                    failures.append(
                        f"C5 {doc.relative_to(REPO_ROOT)} references missing gate "
                        f"script as if current: {name}"
                    )
    # the defect log: only rows outside the marked historical block are checked
    log_text = defect_log.read_text()
    historical_marker = "historical-reference note"
    if historical_marker not in log_text:
        for name in set(script_pattern.findall(log_text)):
            if name not in existing_gate_scripts:
                failures.append(f"C5 defect log references missing gate script: {name}")

    defined = re.findall(r"^\| (DEF-\d+) \|", log_text, re.MULTILINE)
    duplicates = {d for d in defined if defined.count(d) > 1}
    for duplicate in sorted(duplicates):
        failures.append(f"C6 defect log defines {duplicate} more than once")
    defined_set = set(defined)
    for doc in current_docs:
        for cited in set(re.findall(r"\bDEF-\d+\b", doc.read_text())):
            if cited not in defined_set:
                failures.append(
                    f"C6 {doc.relative_to(REPO_ROOT)} cites {cited} not defined in defect log"
                )

    artifact_version = (REPO_ROOT / "ARTIFACT-VERSION").read_text().strip()
    slice_pattern = re.compile(r"V\d{3} slice")
    for source in [PLATFORM_ROOT / "pyproject.toml"] + sorted(
        (PLATFORM_ROOT / "packages").rglob("*.py")
    ):
        for match in set(slice_pattern.findall(source.read_text())):
            if not match.startswith(artifact_version):
                failures.append(
                    f"C7 stale slice label '{match}' in {source.relative_to(PLATFORM_ROOT)}"
                )
    # C7 v2 (ADR-015, V004 review Finding 4): CURRENT navigational/metadata
    # surfaces must be version-neutral or carry exactly ARTIFACT-VERSION on
    # heading lines (and every line of the reading map). Historical records
    # (CHANGELOG, review findings, handoffs, defect log, ADR bodies) are exempt
    # by scope.
    version_token = re.compile(r"\bV\d{3}\b")
    current_label_surfaces = [
        PLATFORM_ROOT / "README.md",
        REPO_ROOT / "12-adr" / "ADR-INDEX.md",
        REPO_ROOT / "06-traceability" / "RTM.md",
        *sorted((REPO_ROOT / "00-control").rglob("*.md")),
    ]
    for doc in current_label_surfaces:
        check_all_lines = doc.name == "READING-MAP.md"
        # ADR section headings ("## ADR-nnn — ... (Vnnn review ...)") are
        # historical records naming the review a decision answered (ADR-015
        # exemption); only the top-level title is a current label there.
        top_level_only = doc.name == "ADR-INDEX.md"
        for line in doc.read_text().splitlines():
            if top_level_only and not line.startswith("# "):
                continue
            if not check_all_lines and not line.startswith("#"):
                continue
            for token in set(version_token.findall(line)):
                if token != artifact_version:
                    failures.append(
                        f"C7 stale current-version label '{token}' in "
                        f"{doc.relative_to(REPO_ROOT)}: {line.strip()[:60]}"
                    )

    # C8 — current handoff must be current.
    artifact_version = (REPO_ROOT / "ARTIFACT-VERSION").read_text().strip()
    handoff_path = REPO_ROOT / "08-ai" / "CHATGPT-REVIEW-HANDOFF.md"
    handoff = handoff_path.read_text()
    if f"ARTIFACT-VERSION: {artifact_version}" not in handoff:
        failures.append(f"C8 current handoff does not declare ARTIFACT-VERSION: {artifact_version}")
    for stale in re.findall(r"# (V\d{3}) Build Handoff", handoff):
        if stale != artifact_version:
            failures.append(f"C8 current handoff carries a stale build handoff: {stale}")

    # C9 — evidence provenance.
    package_token = re.compile(r"AUMNITY-Work-Platform-SaaS_Claude_(V\d{3})_\d{8}_\d{4}")
    build_roots = ("/home/", "/Users/", "/root/", "/tmp/")
    for evidence_file in sorted((PLATFORM_ROOT / "evidence").iterdir()):
        if not evidence_file.is_file():
            continue
        if evidence_file.name == "g10_docs.json":
            # This gate's own evidence is written AFTER the scan and would
            # otherwise contain the very tokens the scan reports.
            continue
        body = evidence_file.read_text(errors="replace")
        for root in build_roots:
            if root in body:
                failures.append(
                    f"C9 build-machine absolute root ({root.strip('/')}) in "
                    f"evidence/{evidence_file.name}"
                )
                break
        for token in set(package_token.findall(body)):
            if token != artifact_version:
                failures.append(
                    f"C9 foreign artifact-version token {token} in evidence/{evidence_file.name}"
                )

    status = "PASS" if not failures else "FAIL"
    write_evidence(
        "g10_docs",
        {
            "status": status,
            "project_version": project_version,
            "checks": ["C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9"],
            "failures": failures,
        },
    )
    print(f"G10 {status}: {len(failures)} failure(s)")
    for failure in failures:
        print(" -", failure)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
