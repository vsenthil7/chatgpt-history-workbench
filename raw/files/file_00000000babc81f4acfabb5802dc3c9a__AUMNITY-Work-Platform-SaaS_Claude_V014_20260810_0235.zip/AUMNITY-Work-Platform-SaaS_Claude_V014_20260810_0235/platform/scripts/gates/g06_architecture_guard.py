#!/usr/bin/env python3
"""G06 — architecture and tenant-neutrality guard (RTM: ARC-001/ARC-002/SaaS-001).

Rules enforced by AST import analysis over product source:
  R1 aumnity_contracts imports nothing from aumnity_kernel or adapters.
  R2 aumnity_kernel domain modules do not import aumnity_kernel.adapters
     (adapters depend on the kernel, never the reverse).
  R3 product source does not import test packages.
Tenant-neutrality token scan over product source (SaaS-001, CLAUDE.md
prohibitions): customer names, withdrawn module names and hard-coded tenant
identifiers are banned from reusable code.
"""

import ast
import sys
from pathlib import Path

from _common import PLATFORM_ROOT, write_evidence

PACKAGES = PLATFORM_ROOT / "packages"

# ADR-033 (V013 review F07, DEF-050): the governed-name registry. V013 matched
# five EXACT, case-sensitive strings, so `ipbs`, `Ipbs`, `kural_flow` and any
# split literal ("IP" "BS") passed a gate advertised as tenant-neutrality
# enforcement. Names are declared once here in canonical form; matching is
# performed against a NORMALISED view of the source (casefolded, with every
# non-alphanumeric character removed), which defeats case variation,
# separators and adjacent-literal splitting alike.
# Prohibited: customer/tenant names, withdrawn module names, hard-coded tenant
# markers. Deliberately NOT listed: URAIFLOW, the governance-approved
# sibling-module source-system identifier (ISS-003, governance doc 30) which
# product source may reference only through
# `aumnity_contracts.source_systems.SOURCE_SYSTEM_URAIFLOW`. Adding a name here
# is a governance decision, recorded in this registry rather than scattered
# across the gate.
GOVERNED_NAMES = (
    "IPBS",
    "KuralFlow",
    "Evil-to-Evil",
    "tenant-hardcoded",
)


def normalise(text: str) -> str:
    """Casefold and strip every non-alphanumeric character, so `ipbs`,
    `I.P.B.S`, `IP_BS` and the concatenation of adjacent literals "IP" "BS"
    all normalise to the same token as the canonical name."""
    return "".join(char for char in text.casefold() if char.isalnum())


def _imports(path: Path) -> list[str]:
    tree = ast.parse(path.read_text())
    found: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            found.append(node.module)
    return found


def main() -> int:
    violations: list[str] = []
    for path in sorted(PACKAGES.rglob("*.py")):
        rel = path.relative_to(PLATFORM_ROOT).as_posix()
        modules = _imports(path)
        in_contracts = "aumnity_contracts" in rel
        in_kernel_domain = "aumnity_kernel" in rel and "/adapters/" not in rel
        for module in modules:
            if in_contracts and module.startswith("aumnity_kernel"):
                violations.append(f"R1 {rel}: contracts must not import {module}")
            if in_kernel_domain and module.startswith("aumnity_kernel.adapters"):
                violations.append(f"R2 {rel}: kernel domain must not import {module}")
            if module.startswith("tests"):
                violations.append(f"R3 {rel}: product source must not import {module}")
        normalised = normalise(path.read_text())
        for name in GOVERNED_NAMES:
            if normalise(name) in normalised:
                violations.append(f"SaaS-001 {rel}: governed tenant/product name '{name}'")
    status = "PASS" if not violations else "FAIL"
    write_evidence(
        "g06_architecture",
        {
            "status": status,
            "rules": ["R1", "R2", "R3", "SaaS-001 governed-name scan"],
            "matching": "casefolded, non-alphanumerics removed (ADR-033)",
            "governed_names": list(GOVERNED_NAMES),
            "files_scanned": len(list(PACKAGES.rglob("*.py"))),
            "violations": violations,
        },
    )
    print(f"G06 {status}: {len(violations)} violation(s)")
    for violation in violations:
        print(" -", violation)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
