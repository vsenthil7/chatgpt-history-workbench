"""Injectable providers: clock and id generation.

Determinism rule: production adapters may use real clocks/UUIDs; the default
test suite must inject deterministic implementations (no real-clock or random
dependence in tests).
"""

from datetime import UTC, datetime, timedelta
from typing import Protocol

from aumnity_contracts.errors import ValidationError


class Clock(Protocol):
    """Source of the current instant."""

    def now(self) -> datetime:
        """Return the current instant as an aware UTC datetime."""
        ...


class IdGenerator(Protocol):
    """Source of new opaque identifiers."""

    def new_id(self, prefix: str) -> str:
        """Return a new unique identifier carrying a human-readable prefix."""
        ...


class TickingClock:
    """Deterministic clock advancing a fixed step per call (test/default adapter)."""

    def __init__(self, start: datetime | None = None, step_seconds: int = 1) -> None:
        """ADR-031 (V013 review F12, DEF-048): the Clock port promises AWARE
        UTC values that advance, and an adapter must not be able to violate
        its own port. A naive start produced naive audit timestamps; a zero or
        negative step produced non-monotonic ones — audit ordering and
        `completed_at` comparisons silently degrade rather than fail."""
        if start is not None:
            if start.tzinfo is None or start.utcoffset() is None:
                raise ValidationError("clock start must be timezone-aware (Clock port: aware UTC)")
            start = start.astimezone(UTC)
        if step_seconds < 1:
            raise ValidationError("clock step_seconds must be >= 1 (Clock port: monotonic)")
        self._current = start if start is not None else datetime(2026, 1, 1, tzinfo=UTC)
        self._step = timedelta(seconds=step_seconds)

    def now(self) -> datetime:
        value = self._current
        self._current = self._current + self._step
        return value


class SequenceIdGenerator:
    """Deterministic sequential id generator (test/default adapter)."""

    def __init__(self) -> None:
        self._counter = 0

    def new_id(self, prefix: str) -> str:
        self._counter += 1
        return f"{prefix}-{self._counter:06d}"
