"""Typed identifiers shared across the platform.

Identifiers are opaque non-empty strings. No identifier encodes a customer,
company or environment assumption; generation strategy is injected (providers).
"""

from enum import Enum
from typing import NewType

from aumnity_contracts.errors import ValidationError

OrganisationId = NewType("OrganisationId", str)
PrincipalId = NewType("PrincipalId", str)
WorkObjectId = NewType("WorkObjectId", str)
EvidenceId = NewType("EvidenceId", str)

_MAX_IDENTIFIER_LENGTH = 128


def require_identifier(value: str, field: str) -> str:
    """Validate an opaque identifier: non-empty, stripped, bounded length."""
    if not isinstance(value, str):  # defensive: kernel is typed, edges may not be
        raise ValidationError(f"{field} must be a string")
    trimmed = value.strip()
    if not trimmed:
        raise ValidationError(f"{field} must be a non-empty string")
    if trimmed != value:
        raise ValidationError(f"{field} must not have surrounding whitespace")
    if len(value) > _MAX_IDENTIFIER_LENGTH:
        raise ValidationError(f"{field} must be at most {_MAX_IDENTIFIER_LENGTH} characters")
    return value


_SHA256_LENGTH = 64
_HEX_DIGITS = frozenset("0123456789abcdef")


def require_enum[E: Enum](value: E, expected: type[E], field: str) -> E:
    """Validate that a value is genuinely an instance of its declared enum
    (ADR-027, V013 review F03, DEF-042).

    Static annotations are NOT a runtime trust boundary: a caller (or a
    defective adapter) can pass the raw string "CRITICAL" where a RiskLevel is
    declared. Such a value renders externally as CRITICAL while every policy
    identity comparison against RiskLevel.CRITICAL is False, so the critical-
    work evidence policy silently does not apply. Enum membership is therefore
    checked at construction of every aggregate, exactly as identifiers are.

    Deliberately strict: a raw value equal to a member's `.value` is REJECTED,
    not coerced. Silent coercion would let two distinct external
    representations converge inside the kernel, and the kernel's own callers
    are typed — anything arriving as a bare string crossed a boundary that
    should have parsed it.
    """
    if not isinstance(value, expected):
        raise ValidationError(
            f"{field} must be a {expected.__name__} member, not "
            f"{type(value).__name__} {value!r} (ADR-027)"
        )
    return value


def require_sha256(value: str, field: str) -> str:
    """Validate a SHA-256 content digest: exactly 64 lowercase hex characters
    (ADR-027, V013 review F10, DEF-043).

    SCOPE, declared honestly: this validates digest SYNTAX only. It does NOT
    dereference the URI, fetch the artefact or verify that the digest is the
    artefact's actual hash — resolution and content verification belong to the
    evidence-capture slice (deferred D05) and are NOT claimed here. Uppercase
    input is rejected rather than normalised, so one artefact digest has
    exactly one representation and digest equality is plain string equality.
    """
    require_identifier(value, field)
    if len(value) != _SHA256_LENGTH or not _HEX_DIGITS.issuperset(value):
        raise ValidationError(
            f"{field} must be exactly {_SHA256_LENGTH} lowercase hexadecimal "
            "characters (SHA-256 digest syntax; ADR-027)"
        )
    return value
