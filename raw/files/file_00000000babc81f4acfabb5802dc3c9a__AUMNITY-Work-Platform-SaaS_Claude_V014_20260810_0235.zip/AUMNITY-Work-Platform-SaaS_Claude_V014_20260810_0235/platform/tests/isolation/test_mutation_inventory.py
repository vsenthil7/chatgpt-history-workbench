"""Inventory-driven universal regressions (V013 review F02/F05, ADR-030/ADR-034).

The RTM claims universals — EVERY mutation participates in a transaction,
EVERY public operation is ONE transaction, the CURRENT scope is the mutation
boundary. V013's tests proved those claims for a SAMPLE, so two published
commands ran two transactions and five adapter primitives (`restore`) bypassed
the guard entirely while the rows read ENFORCED.

These tests are driven by `06-traceability/MUTATION-INVENTORY.json`, the
machine-readable inventory that G12 keeps in exact correspondence with the
source. Adding a published mutating operation or an adapter mutation
primitive without covering it here fails G12; every inventory entry is
exercised below. The universals are therefore checked exhaustively rather
than sampled.
"""

import json
import threading
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path

import pytest
from aumnity_contracts import (
    EventEnvelope,
    OrganisationId,
    PrincipalId,
    SequenceIdGenerator,
    TenantContext,
    TickingClock,
    ValidationError,
    WorkObjectId,
)
from aumnity_kernel import AuditLog, CriticalWorkEvidencePolicy
from aumnity_kernel.adapters.memory import (
    InMemoryPlatformStores,
    InMemoryUnitOfWork,
    TransactionMutex,
)
from aumnity_kernel.evidence import EvidenceKind, EvidenceRecord
from aumnity_kernel.identity import Principal, PrincipalKind
from aumnity_kernel.organisation import (
    Organisation,
    OrganisationDirectory,
    PlatformProvisioning,
)
from aumnity_kernel.workobject.model import Priority, RiskLevel, WorkObject
from aumnity_kernel.workobject.service import WorkObjectRegistry
from aumnity_kernel.workobject.state import WorkObjectState

INVENTORY = json.loads(
    (
        Path(__file__).resolve().parents[3] / "06-traceability" / "MUTATION-INVENTORY.json"
    ).read_text()
)
PUBLISHED_OPERATIONS = [
    f"{entry['service']}.{entry['operation']}"
    for entry in INVENTORY["published_mutating_operations"]
]
MUTATION_PRIMITIVES = [
    f"{entry['store']}.{entry['method']}" for entry in INVENTORY["adapter_mutation_primitives"]
]
DIGEST = "a" * 64


class _Platform:
    """One fully wired platform with a transaction counter on its domain."""

    def __init__(self) -> None:
        self.clock = TickingClock()
        self.ids = SequenceIdGenerator()
        self.stores = InMemoryPlatformStores()
        self.directory = OrganisationDirectory(
            organisations=self.stores.organisations,
            principals=self.stores.principals,
            unit_of_work=self.stores.identity_unit_of_work(),
            clock=self.clock,
            ids=self.ids,
        )
        self.provisioning = PlatformProvisioning(
            provisioner=self.stores.tenant_provisioner(), clock=self.clock, ids=self.ids
        )
        self.audit = AuditLog(
            self.stores.audit_sink,
            principals=self.directory,
            unit_of_work=self.stores.audit_unit_of_work(),
        )
        self.registry = WorkObjectRegistry(
            work_objects=self.stores.work_objects,
            evidence=self.stores.evidence,
            principals=self.directory,
            audit=self.audit,
            unit_of_work=self.stores.unit_of_work(),
            clock=self.clock,
            ids=self.ids,
            completion_policy=CriticalWorkEvidencePolicy(),
        )
        self.organisation, self.founder = self.provisioning.create_organisation(
            "Inventory Org", "Founder", PrincipalKind.HUMAN
        )
        self.context = TenantContext(self.organisation.organisation_id, self.founder.principal_id)

    def work_object_in(self, state: WorkObjectState) -> WorkObjectId:
        """Drive a fresh work object to `state` through published commands."""
        work_object = self.registry.create(
            self.context,
            title="Inventory",
            purpose="Inventory",
            work_type="task",
            priority=Priority.NORMAL,
            risk_level=RiskLevel.LOW,
            owner_id=self.context.principal_id,
        )
        wid = work_object.work_object_id
        path: dict[WorkObjectState, tuple[str, ...]] = {
            WorkObjectState.DRAFT: (),
            WorkObjectState.READY: ("mark_ready",),
            WorkObjectState.ASSIGNABLE: ("mark_ready", "mark_assignable"),
            WorkObjectState.ASSIGNED: ("mark_ready", "mark_assignable", "assign"),
            WorkObjectState.IN_PROGRESS: (
                "mark_ready",
                "mark_assignable",
                "assign",
                "start_work",
            ),
            WorkObjectState.PAUSED: (
                "mark_ready",
                "mark_assignable",
                "assign",
                "start_work",
                "pause",
            ),
            WorkObjectState.BLOCKED: ("mark_ready", "block"),
            WorkObjectState.OUTPUT_SUBMITTED: (
                "mark_ready",
                "mark_assignable",
                "assign",
                "start_work",
                "submit_output",
            ),
            WorkObjectState.REVIEW: (
                "mark_ready",
                "mark_assignable",
                "assign",
                "start_work",
                "submit_output",
                "request_review",
            ),
            WorkObjectState.REWORK: (
                "mark_ready",
                "mark_assignable",
                "assign",
                "start_work",
                "submit_output",
                "request_review",
                "request_rework",
            ),
            WorkObjectState.APPROVED: (
                "mark_ready",
                "mark_assignable",
                "assign",
                "start_work",
                "submit_output",
                "request_review",
                "approve",
            ),
        }
        for step in path[state]:
            if step == "assign":
                self.registry.assign(self.context, wid, self.context.principal_id)
            else:
                getattr(self.registry, step)(self.context, wid)
        return wid


def _invoke(platform: _Platform, qualified: str):
    """Return a zero-argument callable that performs the named published
    mutating operation with valid preconditions already in place."""
    registry, context = platform.registry, platform.context
    service, operation = qualified.split(".")
    if service == "PlatformProvisioning":
        return lambda: platform.provisioning.create_organisation(
            "Another Org", "Another Founder", PrincipalKind.HUMAN
        )
    if service == "OrganisationDirectory":
        return lambda: platform.directory.create_principal(
            context, PrincipalKind.HUMAN, "Inventory Principal"
        )
    if service == "AuditLog":
        envelope = EventEnvelope(
            event_type="InventoryProbe",
            organisation_id=context.organisation_id,
            actor_principal_id=context.principal_id,
            subject_id="wob-inventory",
            subject_version=1,
            occurred_at=platform.clock.now(),
            payload={},
        )
        return lambda: platform.audit.record(context, envelope)
    if operation == "create":
        return lambda: registry.create(
            context,
            title="Fresh",
            purpose="Fresh",
            work_type="task",
            priority=Priority.NORMAL,
            risk_level=RiskLevel.LOW,
            owner_id=context.principal_id,
        )
    start: dict[str, WorkObjectState] = {
        "mark_ready": WorkObjectState.DRAFT,
        "mark_assignable": WorkObjectState.READY,
        "assign": WorkObjectState.ASSIGNABLE,
        "start_work": WorkObjectState.ASSIGNED,
        "pause": WorkObjectState.IN_PROGRESS,
        "resume": WorkObjectState.PAUSED,
        "block": WorkObjectState.READY,
        "unblock": WorkObjectState.BLOCKED,
        "submit_output": WorkObjectState.IN_PROGRESS,
        "request_review": WorkObjectState.OUTPUT_SUBMITTED,
        "approve": WorkObjectState.REVIEW,
        "reject": WorkObjectState.REVIEW,
        "request_rework": WorkObjectState.REVIEW,
        "restart_after_rework": WorkObjectState.REWORK,
        "complete": WorkObjectState.APPROVED,
        "cancel": WorkObjectState.DRAFT,
        "archive": WorkObjectState.REVIEW,
        "attach_evidence": WorkObjectState.DRAFT,
    }
    wid = platform.work_object_in(start[operation])
    if operation == "assign":
        return lambda: registry.assign(context, wid, context.principal_id)
    if operation == "attach_evidence":
        return lambda: registry.attach_evidence(
            context,
            wid,
            kind=EvidenceKind.DOCUMENT,
            uri="https://example.invalid/artefact",
            content_sha256=DIGEST,
            source_system="INVENTORY",
            source_reference="ref-1",
        )
    if operation == "archive":
        registry.reject(context, wid)
        return lambda: registry.archive(context, wid)
    return lambda: getattr(registry, operation)(context, wid)


class TestEveryPublishedOperationIsOneTransaction:
    """RTM RD-001 / TXN-004 as a UNIVERSAL, not a sample (ADR-030, DEF-046)."""

    @pytest.mark.parametrize("qualified", PUBLISHED_OPERATIONS)
    def test_operation_opens_exactly_one_top_level_transaction(self, qualified: str) -> None:
        platform = _Platform()
        invoke = _invoke(platform, qualified)
        begins: list[bool] = []
        original = TransactionMutex.begin

        def counting_begin(self, stores, *, writable=True, bare=False):  # type: ignore[no-untyped-def]
            begins.append(writable)
            return original(self, stores, writable=writable, bare=bare)

        TransactionMutex.begin = counting_begin  # type: ignore[method-assign]
        try:
            invoke()
        finally:
            TransactionMutex.begin = original  # type: ignore[method-assign]
        # Exactly one top-level transaction: any precondition read must JOIN it
        # (a joined read pushes a frame, it does not begin), so a second begin
        # means a window existed between check and write (the executed V013
        # `block()` corruption).
        assert len(begins) == 1, f"{qualified} opened {len(begins)} top-level transactions"
        assert begins[0] is True, f"{qualified} must open a WRITE transaction"


class TestEveryAdapterMutationPrimitiveIsGuarded:
    """RTM TXN-004 / TXN-007 / ADR-028 as a UNIVERSAL: every inventory
    primitive refuses to run outside a WRITE transaction that declares its
    store — including the wholesale rollback primitives, which V013 left
    entirely unguarded (executed restore-through-READ leak)."""

    @staticmethod
    def _target(stores: InMemoryPlatformStores, qualified: str):
        store_name, method = qualified.split(".")
        store = {
            "InMemoryOrganisationRepository": stores.organisations,
            "InMemoryPrincipalRepository": stores.principals,
            "InMemoryWorkObjectRepository": stores.work_objects,
            "InMemoryEvidenceRepository": stores.evidence,
            "InMemoryAuditSink": stores.audit_sink,
        }[store_name]
        moment = datetime(2026, 1, 1, tzinfo=UTC)
        organisation_id = OrganisationId("org-inv")
        principal_id = PrincipalId("prn-inv")
        work_object = WorkObject(
            work_object_id=WorkObjectId("wob-inv"),
            organisation_id=organisation_id,
            title="t",
            purpose="p",
            work_type="task",
            state=WorkObjectState.DRAFT,
            priority=Priority.NORMAL,
            risk_level=RiskLevel.LOW,
            requester_id=principal_id,
            owner_id=principal_id,
            created_at=moment,
            updated_at=moment,
        )
        payloads = {
            "InMemoryOrganisationRepository.add": lambda: store.add(
                Organisation(organisation_id=organisation_id, name="Inv", created_at=moment)
            ),
            "InMemoryPrincipalRepository.add": lambda: store.add(
                Principal(
                    principal_id=principal_id,
                    organisation_id=organisation_id,
                    kind=PrincipalKind.HUMAN,
                    display_name="Inv",
                )
            ),
            "InMemoryWorkObjectRepository.create": lambda: store.create(work_object),
            "InMemoryWorkObjectRepository.update": lambda: store.update(
                replace(work_object, version=2), expected_version=1
            ),
            "InMemoryEvidenceRepository.add": lambda: store.add(
                EvidenceRecord(
                    evidence_id="evd-inv",
                    organisation_id=organisation_id,
                    work_object_id=WorkObjectId("wob-inv"),
                    kind=EvidenceKind.DOCUMENT,
                    uri="https://example.invalid/a",
                    content_sha256=DIGEST,
                    submitted_by=principal_id,
                    submitted_at=moment,
                    source_system="INV",
                    source_reference="ref",
                )
            ),
            "InMemoryAuditSink.append": lambda: store.append(
                EventEnvelope(
                    event_type="Probe",
                    organisation_id=organisation_id,
                    actor_principal_id=principal_id,
                    subject_id="wob-inv",
                    subject_version=1,
                    occurred_at=moment,
                    payload={},
                )
            ),
        }
        if qualified.endswith("._restore_snapshot"):
            snapshot = store.snapshot()
            return store, lambda: store._restore_snapshot(snapshot)
        return store, payloads[qualified]

    @pytest.mark.parametrize("qualified", MUTATION_PRIMITIVES)
    def test_primitive_rejected_outside_any_transaction(self, qualified: str) -> None:
        stores = InMemoryPlatformStores()
        _, call = self._target(stores, qualified)
        with pytest.raises(ValidationError):
            call()

    @pytest.mark.parametrize("qualified", MUTATION_PRIMITIVES)
    def test_primitive_rejected_inside_top_level_read(self, qualified: str) -> None:
        stores = InMemoryPlatformStores()
        store, call = self._target(stores, qualified)
        unit_of_work = InMemoryUnitOfWork(store)
        with pytest.raises(ValidationError):
            unit_of_work.read(call)

    @pytest.mark.parametrize("qualified", MUTATION_PRIMITIVES)
    def test_primitive_rejected_inside_read_joined_into_write(self, qualified: str) -> None:
        stores = InMemoryPlatformStores()
        store, call = self._target(stores, qualified)
        unit_of_work = InMemoryUnitOfWork(store)
        with pytest.raises(ValidationError):
            unit_of_work.run(lambda: unit_of_work.read(call))

    @pytest.mark.parametrize("qualified", MUTATION_PRIMITIVES)
    def test_primitive_rejected_in_nested_scope_that_did_not_declare_the_store(
        self, qualified: str
    ) -> None:
        """A nested WRITE scope over a DIFFERENT store holds no savepoint for
        this one, so it may neither mutate nor roll it back (ADR-025/ADR-028)."""
        stores = InMemoryPlatformStores()
        store, call = self._target(stores, qualified)
        other = stores.principals if store is not stores.principals else stores.organisations
        outer = InMemoryUnitOfWork(store, other)
        inner = InMemoryUnitOfWork(other)
        with pytest.raises(ValidationError):
            outer.run(lambda: inner.run(call))


class TestTwoTransactionCommandInterleavingRegression:
    """Regression for the V013 review F02 (ADR-030/DEF-046) at the exact five
    commands named in the review. A concurrent legitimate writer is parked at
    the precise point V013 was vulnerable — after the precondition read,
    before the write. Because the whole command is now ONE transaction, the
    writer waits on the serialisation domain and cannot land in between, so
    the state the command validated is the state it acts on."""

    NAMED_COMMANDS = ("assign", "resume", "block", "unblock", "restart_after_rework")

    def test_block_records_the_state_it_actually_validated(self) -> None:
        """V013 persisted blocked_from=READY for an object that was ASSIGNABLE
        when the write landed, so a later unblock restored the wrong state."""
        platform = _Platform()
        wid = platform.work_object_in(WorkObjectState.READY)
        armed, attempted, released = (threading.Event() for _ in range(3))
        original = WorkObjectRegistry._get_in_transaction

        def hooked(self, context, work_object_id):  # type: ignore[no-untyped-def]
            found = original(self, context, work_object_id)
            if armed.is_set():
                armed.clear()
                attempted.set()
                released.wait(5)
            return found

        def racer() -> None:
            attempted.wait(5)
            try:
                # A legitimate transition that V013 allowed to land between
                # block()'s two transactions.
                platform.registry.mark_assignable(platform.context, wid)
            finally:
                released.set()

        WorkObjectRegistry._get_in_transaction = hooked  # type: ignore[method-assign]
        thread = threading.Thread(target=racer)
        thread.start()
        armed.set()
        try:
            platform.registry.block(platform.context, wid)
        finally:
            thread.join(10)
            WorkObjectRegistry._get_in_transaction = original  # type: ignore[method-assign]
        blocked = platform.registry.get(platform.context, wid)
        assert blocked.blocked_from is WorkObjectState.READY, (
            "block must record the state it validated inside its own transaction"
        )

    @pytest.mark.parametrize("command", NAMED_COMMANDS)
    def test_named_command_holds_the_domain_across_check_and_write(self, command: str) -> None:
        """Each command named in the review must keep the serialisation domain
        held from its precondition read through its write: a second
        transaction would release it in between (the V013 window)."""
        platform = _Platform()
        invoke = _invoke(platform, f"WorkObjectRegistry.{command}")
        domain = platform.stores.work_objects.serialisation_domain()
        released_between: list[bool] = []
        original = WorkObjectRegistry._get_in_transaction

        def hooked(self, context, work_object_id):  # type: ignore[no-untyped-def]
            found = original(self, context, work_object_id)
            released_between.append(not domain.owned_by_current_thread())
            return found

        WorkObjectRegistry._get_in_transaction = hooked  # type: ignore[method-assign]
        try:
            invoke()
        finally:
            WorkObjectRegistry._get_in_transaction = original  # type: ignore[method-assign]
        assert released_between and not any(released_between), (
            f"{command} performed a load outside its write transaction"
        )
