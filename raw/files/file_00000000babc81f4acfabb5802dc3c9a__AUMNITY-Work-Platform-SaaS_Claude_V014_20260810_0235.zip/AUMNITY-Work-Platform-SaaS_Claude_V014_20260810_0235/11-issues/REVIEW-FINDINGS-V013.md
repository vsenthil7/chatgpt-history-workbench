# Independent Review Findings — V013 (ChatGPT freeze-oriented deep review, 2026-08-09 21:56) and dispositions in V014

Source: full 176-file package review, independent suite execution and
adversarial probes against
`AUMNITY-Work-Platform-SaaS_Claude_V013_20260809_2003.zip`
(sha256 `5d341c47565da3480f992ba9951526bc3754d40999d782848cf3d745f4d6ec2b`).
Verdict: REJECT — NO FREEZE — 3 BLOCKERS, 2 HIGH, 5 MEDIUM, 2 LOW.
Rule applied: no finding may silently disappear; dispositions were verified
against the verbatim review text (DEF-037 packaging rule).

**Reproduced first, as instructed.** F01–F04 were reproduced against the
UNTOUCHED V013 package before any code was changed, and the outputs matched
the review exactly: `P1_JOINED_READ_RESTORE_MUTATION_PERSISTED True`,
`P1_TOP_LEVEL_READ_RESTORE_MUTATION_PERSISTED True`,
`P2_STALE_BLOCKED_FROM READY` (expected ASSIGNABLE),
`P3_RAW_CRITICAL_TYPE str 'CRITICAL'` completing with zero evidence,
`P4_BASEEXCEPTION_WRITE_PERSISTED True`.

V014 is hardening only: no new platform functionality. Freeze is NOT
self-declared.

| # | Finding | Disposition | Where |
|---|---|---|---|
| F01 | BLOCKER: public unguarded `restore()` on all five stores bypassed READ-only mode and transaction scope; state could be replaced wholesale from a top-level read, a read joined into a write, or a nested scope holding no savepoint for the store. | **FIXED (architectural)** | ADR-028, DEF-044: `restore()` → private `_restore_snapshot()` guarded by `_require_rollback_context()` (current-frame WRITE mode AND current-scope coverage). Both halves of the suggested remedy applied. All five stores × all six required contexts are permanent regressions; RTM TXN-008. |
| F02 | BLOCKER: `assign`, `resume`, `block`, `unblock`, `restart_after_rework` used two transactions; a legitimate interleaved commit made `block()` persist a stale `blocked_from` (deterministic TOCTOU state corruption). | **FIXED (architectural)** | ADR-030, DEF-046: `_transition` split into `_transition_in_transaction` + wrapper; every command with a precondition runs the full sequence in ONE `run()`. Deterministic interleaving regressions for all five named commands, plus the universal single-transaction assertion for all 22 published operations; RTM TXN-010/RD-001. |
| F03 | BLOCKER: raw `"CRITICAL"` accepted as a RiskLevel; rendered as CRITICAL externally but failed every policy identity check, so a critical work object completed with zero evidence. | **FIXED (architectural)** | ADR-027, DEF-042: `require_enum` at construction for RiskLevel, Priority, WorkObjectState, blocked_from, PrincipalKind, EvidenceKind; rejection, not coercion; malformed adapter-returned aggregates fail closed on the same path; RTM TYP-001. |
| F04 | HIGH: `except Exception` did not roll back failures deriving from `BaseException`; a custom abort left its writes committed. | **FIXED** | ADR-029, DEF-045: all four rollback sites catch `BaseException`, restore, and re-raise the original exception unchanged; regressions for top-level, joined savepoint, provisioning and exception identity; RTM TXN-009. |
| F05 | HIGH: RTM marked TXN-004/TXN-007/RD-001/RD-003 ENFORCED while F01/F02 disproved those universals; G09 verifies cited nodes, not population completeness. | **FIXED — with an explicit DEVIATION** | ADR-034, DEF-047: `06-traceability/MUTATION-INVENTORY.json` + new gate **G12** deriving both populations from source by AST, failing on any mismatch in either direction, requiring the declared regression kinds, and verifying each cited node resolves to exactly one test; 66 inventory-driven regressions. G12's ability to fail was verified adversarially. **DEVIATION:** the review directed temporarily DOWNGRADING the four rows; V014 instead repairs the defects and keeps them ENFORCED behind G12. Reviewer's call to overrule — V015 will apply the downgrade if still wanted. RTM TXN-011. |
| F06 | MEDIUM: the unversioned handoff cited as the current review entry point still contained the V002 handoff; V012/V013 versioned handoffs missing. | **FIXED** | ADR-035, DEF-053: V002 document preserved as `CHATGPT-REVIEW-HANDOFF-V002-HISTORICAL.md`; current V014 handoff written; the V012/V013 gap is recorded, NOT back-filled (writing them now would fabricate contemporaneous records); G10 check C8 fails the ladder on a stale current handoff; RTM DOC-002. |
| F07 | MEDIUM: G06 matched five exact case-sensitive strings, so lowercase, separator and split-literal forms bypassed the tenant-neutrality gate. | **FIXED** | ADR-033, DEF-050: governed-name registry matched against a casefolded, non-alphanumeric-stripped view of source; eight adversarial forms are permanent regressions. `URAIFLOW` deliberately excluded as the governance-approved sibling identifier (ISS-003); RTM SaaS-001. |
| F08 | MEDIUM: V013 evidence contained absolute V012 build paths; version checking never inspected evidence bodies. | **FIXED** | ADR-035, DEF-051: gate commands and captured output normalised to repository-relative tokens; G10 check C9 rejects build-machine roots and foreign artifact-version tokens in evidence bodies; RTM PKG-002. |
| F09 | MEDIUM: G11's unchanged-tree proof covered 172 manifest entries but was reported as a tree digest over all 176 files. | **FIXED** | ADR-036, DEF-052: two named digests — `manifest_controlled_corpus_digest` and `full_extraction_digest` (every packaged file) — with the four self-referential paths named in the sidecar's `digest_scope`; read-only idempotence requires BOTH unchanged, so the stronger claim is now made explicitly; RTM PKG-003. |
| F10 | MEDIUM: `content_sha256` accepted values that are not SHA-256 digests. | **FIXED** | ADR-027, DEF-043: `require_sha256` — exactly 64 lowercase hex; uppercase rejected rather than normalised; scope declared honestly as SYNTAX ONLY (no URI resolution, no content hashing — deferred D05); RTM EVD-002. |
| F11 | LOW: ADR/RTM said bare critical sections accept no joins, but an empty READ frame was accepted (no integrity bypass; a false statement). | **FIXED (rule made enforceable, not documentation weakened)** | ADR-032, DEF-049: frames carry a KIND; bare frames reject EVERY join explicitly. The alternative of documenting the actual behaviour was available and rejected — a bare section holds no savepoints, so nothing should compose with it. |
| F12 | LOW: `TickingClock` accepted naive starts and zero/negative steps; ADR index placed ADR-020 after ADR-026. | **FIXED** | ADR-031, DEF-048: constructor rejects naive starts and non-advancing steps; ADR index restored to numerical order; RTM ADP-002. |

**A defect found BY the F09 fix, recorded as DEF-054.** The new
full-extraction digest reported the extracted package CHANGED on its first
run, and the release correctly refused to certify read-only idempotence: the
ladder itself wrote `.coverage`, `.mypy_cache/`, `.ruff_cache/` and
`__pycache__/` into the extracted tree. Every release through V013 therefore
carried a read-only claim that was false for the package as a whole and that a
manifest-scoped digest structurally could not observe. Tool scratch state is
now redirected outside the tree and bytecode suppressed in every gate
subprocess; verified by extracting the final ZIP, running the ladder and
diffing the complete file list (no file added, removed or modified).

**Environmental note accepted.** The reviewer's direct G07 invocation aborting
outside a clean venv for lack of `ruff` is correctly not a package failure;
the clean-venv release evidence records G07 PASS twice.

Preserved as directed: all V012/V013 scope-stack and frame-mode work
(ADR-025/ADR-026), the machine-derived release summary (DEF-040), historical
review ledgers, the 81-file preserved baseline byte-identity, and OD-001
remains OPEN. Freeze remains the reviewer's decision.
