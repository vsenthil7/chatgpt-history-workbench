> HISTORICAL RECORD — PRESERVED, NOT CURRENT (V013 review F06, DEF-053).
> This is the V002-era build handoff that occupied the unversioned
> `CHATGPT-REVIEW-HANDOFF.md` filename up to and including V013, so the
> document advertised as the current review entry point described a build
> eleven releases old and made claims that were false for V013. It is kept
> verbatim below for history; the current handoff is
> `08-ai/CHATGPT-REVIEW-HANDOFF.md`, and G10 check C8 now fails the ladder if
> that file does not declare the current ARTIFACT-VERSION.

# V002 Build Handoff (Claude, 2026-08-08)

## What was attempted
Backlog items B001–B005 from `07-planning/FIRST-BUILD-BACKLOG.md`, scoped by ADR-003:
baseline acceptance with issue log; first vertical slice (organisation/tenant semantics,
shared contracts, minimum Work Object kernel); tests-first with edge/negative/tenant
cases; runnable evidence-producing gate ladder; this complete review ZIP.

## What works (verify against evidence, not this narrative)
- `platform/packages/aumnity_contracts` — typed IDs, TenantContext, EventEnvelope,
  error taxonomy, deterministic Clock/IdGenerator providers, source-system constants.
- `platform/packages/aumnity_kernel` — Organisation registry, Principal identity
  (HUMAN/AI/SERVICE), Work Object registry implementing the baseline doc 04 lifecycle
  (15 states), versioning, recursive same-organisation decomposition, minimal direct
  assignment, immutable sha256-carrying evidence, CRITICAL-risk evidence-gated
  completion policy, append-only tenant-scoped audit; in-memory adapters behind ports.
- Gate ladder G01–G11 as scripts under `platform/scripts/gates/`, each writing JSON/text
  evidence to `platform/evidence/`. Test totals and coverage percentages are in
  `evidence/g03_unit.txt`, `evidence/g04_coverage.txt`/`.json` (coverage configured
  fail_under=100 with branch measurement) and `evidence/gate_ladder.json`.

## Failures encountered during the build (all fixed, none suppressed)
See `platform/evidence/defect-log.md`: DEF-001 (defective contract test using
`zip(..., strict=True)` misuse), DEF-002 (circular import in kernel ports), DEF-003
(lint violations in gate scripts), DEF-004 (withdrawn source-system token in a
docstring caught by the G06 SaaS-001 guard).

## Assumptions and known limitations (review these hardest)
1. Bootstrap principal: test fixtures create TenantContext whose acting principal id
   equals the organisation id. Acting-principal existence/authorization is NOT yet
   verified by the kernel (SEC-001 DECLARED). Tenant isolation is enforced; role
   authorization is not.
2. Mutation gate G07 is a custom deterministic AST mutator scoped to
   `workobject/state.py` and `policy.py` (ADR-004); it is not a full mutmut run.
3. Persistence is in-memory only (INF-001 DECLARED); no HTTP edge (API-001 DECLARED;
   ADR-006 records the required TenantIsolationError→404 mapping).
4. G01 manifest is regenerated after gate evidence so the manifest covers evidence
   files; G11 evidence describes the packaging verification pass (see its JSON for
   the exact procedure and hashes).
5. OD-001 "TEE" remains undefined in the baseline (ISS-008) — needs product-owner input.

## Changed/added versus V001 starter
- New: `06-traceability/RTM.md` (authoritative, ADR-005), `11-issues/BASELINE-ISSUES.md`
  (ISS-001…010), `12-adr/ADR-INDEX.md` (ADR-001…006), `platform/` (all product code,
  tests, gates, evidence), root `PACKAGE-MANIFEST.json` regenerated.
- Preserved unchanged: everything under `10-baseline/`, starter control/product/
  architecture/engineering/testing/quality/planning/governance docs, `CLAUDE.md`,
  `scripts/validate_starter.py`.

## Deferred / blocked (traceable in RTM)
Deferred by ADR-003: capability/capacity matching (D02/D03), review-as-work-object
(D04), knowledge/handover (D05), UraiFlow bridge implementation (D06), SLA, AI
gateway, Postgres adapter, HTTP edge, role authorization. Blocked on market evidence:
DW-FR-014/015. Blocked on product owner: ISS-008 (OD-001).
