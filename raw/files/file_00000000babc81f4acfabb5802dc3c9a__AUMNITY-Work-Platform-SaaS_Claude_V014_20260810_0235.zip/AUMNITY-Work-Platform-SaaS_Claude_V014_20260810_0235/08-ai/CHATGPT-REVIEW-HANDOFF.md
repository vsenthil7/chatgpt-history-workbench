# ChatGPT Independent Review Contract

ChatGPT review is adversarial verification, not a summary of Claude's report.

Review the entire submitted ZIP and independently check:
- product/module ownership and SaaS tenant neutrality;
- architecture dependency direction and duplicated semantics;
- source, tests, fixtures and negative paths;
- line + branch coverage evidence and exclusions;
- mutation evidence for critical code;
- RTM completeness and enforcement status;
- architecture guards and whether they can be bypassed;
- docs/version/manifest/count consistency;
- security, authorization, audit and cross-tenant isolation;
- packaging/reproducibility and upgrade compatibility.

Output findings by severity with file/line evidence where possible. A Claude narrative is evidence to verify, never evidence to trust.

---

# V014 Build Handoff (Claude, 2026-08-09) — hardening release

ARTIFACT-VERSION: V014. Product version 0.13.0. Scope: exactly the V013
freeze-oriented review (21:56) — F01–F12, hardening only, no new platform
functionality. Dispositions: `11-issues/REVIEW-FINDINGS-V013.md`. Freeze is
NOT self-declared; that decision is the reviewer's. OD-001 remains OPEN.

## Handoff versioning, plainly (F06, DEF-053)
Until V013 this unversioned filename still contained the **V002** build
handoff, so the document named as the current review entry point described a
build eleven releases old. It is preserved verbatim as
`08-ai/CHATGPT-REVIEW-HANDOFF-V002-HISTORICAL.md`. The V012 and V013
versioned handoffs were never written — that gap is recorded, not
back-filled, because writing them now would fabricate contemporaneous
documents. This file is now the current handoff and G10 check C8 fails the
ladder if it does not declare the current ARTIFACT-VERSION.

## What the V013 review found, and what changed (0.12.0 → 0.13.0)
All four blocker-class findings were reproduced against the UNTOUCHED V013
package before any code was changed; the reproduction outputs matched the
review exactly.

- **ADR-028 (DEF-044, F01 BLOCKER)** — wholesale state replacement was a
  PUBLIC unguarded `restore()` on all five stores, so a callback inside a READ
  transaction (or a nested scope holding no savepoint for the store) could
  replace persisted state. It is now private `_restore_snapshot()` guarded by
  `_require_rollback_context()`: current-frame WRITE mode AND current-scope
  coverage. Legitimate rollback satisfies this by construction, so DEF-038's
  "restore is non-raising" contract is intact.
- **ADR-030 (DEF-046, F02 BLOCKER)** — `assign`, `resume`, `block`, `unblock`
  and `restart_after_rework` read/validated in one transaction and wrote in
  another. `_transition` is split into `_transition_in_transaction` plus a
  wrapper; every one of these commands now runs precondition read and write
  inside ONE `run()`. `block` captures `blocked_from` inside the transaction.
- **ADR-027 (DEF-042/DEF-043, F03 BLOCKER + F10)** — enum fields are now a
  RUNTIME trust boundary (`require_enum`) across RiskLevel, Priority,
  WorkObjectState, blocked_from, PrincipalKind and EvidenceKind: raw
  `"CRITICAL"` is rejected at construction instead of rendering as CRITICAL
  while failing every policy identity check. `require_sha256` requires exactly
  64 lowercase hex characters; its scope is declared honestly as digest SYNTAX
  only — no URI resolution or content hashing is claimed (deferred D05).
- **ADR-029 (DEF-045, F04 HIGH)** — all four rollback sites catch
  `BaseException`, restore, and re-raise the original exception unchanged.
- **ADR-034 (DEF-047, F05 HIGH)** — `06-traceability/MUTATION-INVENTORY.json`
  declares every published mutating operation (22) and every adapter mutation
  primitive (11). New gate **G12** derives both populations from source by AST
  and fails on ANY mismatch in either direction, requires the declared
  regression kinds, and verifies each cited node resolves to exactly one test.
  66 inventory-driven regressions assert the universals exhaustively rather
  than by sample. **Deviation to review explicitly:** the review directed
  temporarily DOWNGRADING TXN-004/TXN-007/RD-001/RD-003; V014 instead fixes
  the underlying defects and keeps them ENFORCED, backed by G12. If the
  reviewer prefers the downgrade, say so and V015 will apply it.
- **ADR-033 (DEF-050, F07)** — G06 matches a governed-name registry against a
  normalised (casefolded, non-alphanumerics stripped) view of source, so
  lowercase, separator and split-literal forms are all caught; verified
  adversarially. `URAIFLOW` is deliberately NOT in the prohibited registry: it
  is the governance-approved sibling source-system identifier (ISS-003).
- **ADR-035 (DEF-051, F08)** — gate records and captured output are
  normalised to repository-relative form, so no build-machine root or foreign
  package token can enter shipped evidence; G10 check C9 scans evidence
  bodies for both.
- **ADR-036 (DEF-052, F09)** — the release proof is now two explicitly named
  digests: `manifest_controlled_corpus_digest` (the 172 manifest entries) and
  `full_extraction_digest` (EVERY extracted file), with the four
  self-referential packaging artefacts named in the sidecar. Both must be
  unchanged for the read-only idempotence claim.
- **ADR-032 (DEF-049, F11)** — bare critical sections are a distinct frame
  KIND that rejects ALL joins, making the documented rule the enforced rule
  (an empty READ frame was trivially a subset of the empty bare scope).
- **ADR-031 (DEF-048, F12)** — `TickingClock` rejects naive start values and
  steps below one second, so the adapter cannot violate the Clock port's
  aware-UTC monotonic contract. ADR index restored to numerical order.

## Review these hardest
1. G12's derivation heuristics: it treats a kernel-service public method as a
   published mutating operation when it calls a transaction entry point, and
   an adapter method as a mutation primitive when it calls a guard. A mutating
   path that reaches neither would escape the inventory — attack that.
2. `require_enum` rejects rather than coerces. Confirm no legitimate edge
   (future HTTP/JSON boundary) is left without an explicit parse step.
3. The F05 deviation above.
4. SEC-001 (acting-principal authorization), INF-001 (in-memory persistence),
   API-001 (no HTTP edge) remain DECLARED, not built.
5. OD-001 "TEE supervision capacity" remains OPEN pending product-owner input.
