# AT-Life Operating System (AT-LOS) - V019

**Release:** `AT-LifeOperatingSystem_AIConversationExportAdapter_Claude_V019_20260808_1132`
**Prepared by:** Claude · **08-Aug-2026 11:32 BST**

```
V019 — AIConversationExportAdapter

pytest                 185 passed, 1 skipped
coverage               567 statements, 142 branches, 100% line and branch
architecture guards    48 collected
integration (real venv) 2 collected
mutation regression    13/13 killed
RTM                    65 passing + 1 skipped + 2 not enforced = 68
modules / products     11 declared, 2 product applications
test suites            15 built, 4 declared not built (3 external)
documentation          39 pages, 2 publication profiles
packages measured      at-cli, at-ingest-core, at-ingest-llm-export, at-ingest-whatsapp, at-store
platform version       0.10.0

Facts measured: outcomes=True coverage=True
```

## Your verdict was right, and this release acts on it

V018 was scaffolding-complete and capability-thin. **V019 is a feature** — the
first release since V008 to add a product capability rather than another control.

## `at-ingest-llm-export`

ChatGPT, Claude and Perplexity conversation exports. Three genuinely different
formats: a **node graph** (`mapping`), an **ordered list** (`chat_messages`), and
**query/answer pairs** (`entries`).

**41 tests, 100% line and branch.**

### Four decisions worth naming (ADR-019)

**Each provider gets its own `origin_kind`** — not one `llm_export`. `origin_kind`
participates in event identity (ADR-013/014), so a single kind would make the same
conversation exported from two providers indistinguishable. Tested: identical
content parsed as ChatGPT and as Claude produces **no overlapping event IDs**.

**Coverage is measured in the source's own unit.** `line_coverage` was correct for
WhatsApp and meaningless for JSON — an export can be one line or pretty-printed
across thousands. `IngestResult` now carries `candidate_units`, `consumed_units`
and `unit_name`, and **`line_coverage` raises** for a non-line source rather than
returning a number in a unit that source does not have.

WhatsApp reports *283 of 283 lines*. An AI export reports *4 of 4 messages*.

**An unrecognised shape raises**, never a partial parse. Detection is structural,
so renaming a file cannot change how it is parsed — the CLI picks its adapter
from content (RTM-68).

**Conversation boundaries survive.** Locator is
`conversation:<id>#message:<n>`; ChatGPT nodes are sorted by time then id so
dictionary order cannot decide message order; Perplexity's query and answer
become **two** messages, because a question and its answer are not one utterance.

## The V018 framework was used, not just described

`at-ingest-llm-export` was declared in `architecture.toml` **first** — which made
four guards fail until the code existed. Then registered in `testing.toml` and
`rtm.toml`. That is the intended feel of the declared-first workflow.

## What is coded

`at-ingest-core` ✅ · `at-ingest-whatsapp` ✅ · **`at-ingest-llm-export` ✅ new** ·
`at-store` 🟡 in-memory · `at-cli` ✅ — **5 of 11 packages, two independent source
adapters.**

Two adapters is what makes the generic `Event` contract a real contract rather
than a WhatsApp shape with a general name.

AT-LOS product: **not started.** Network API: **not started.**

## Try it

```bash
python bootstrap.py
python -m at_cli acceptance tests/external/sample-data/sample_claude_export.json
```

## Next

`at-store` durability (S1-20), then `at-identity`. `at-consent` stays blocked on
DQ-012 and DQ-013; no product app or HTTP layer before DQ-014.

**AT-056 remains Not started.**
