# AT-LOS V019 Change Log

**Release type:** capability. ADR-019. First release since V008 to add a product capability rather than a control.

## Added — `at-ingest-llm-export`

- ChatGPT (`chatgpt_export`), Claude (`claude_export`), Perplexity (`perplexity_export`).
- Structural provider detection; `UnknownExportFormatError` for anything else.
- Conversation boundaries preserved in locator and event metadata.
- ChatGPT node graph ordered by `create_time` then node id.
- Perplexity query and answer become two messages.
- Roles become participants; other roles become SYSTEM events.
- Missing or unparseable timestamps become `ParseIssue`s and reduce coverage.
- 37 unit tests plus 4 CLI dispatch tests. 100% line and branch.

## Changed — source-unit coverage (contract change)

`IngestResult` gains `candidate_units`, `consumed_units`, `unit_name` and `coverage`.
`line_coverage` now **raises** for a non-line source. Updated across `at-ingest-core`,
`at-ingest-whatsapp`, `at-cli` and `verification/`.

## Changed — `at-cli`

Selects the adapter from file content, never the filename. Report header and unit
labels follow the detected source type.

## Registered

`testing.toml` suite `TST-INT-UNIT-LLM` · RTM-64 to RTM-68 · MT-005 manual test ·
external sample `sample_claude_export.json` (synthetic) · EXT-UAT-001 extended.

## Decisions

D-072 per-provider origin_kind · D-073 coverage in the source's own unit · D-074 an unrecognised format is an error

## Not done

`at-identity`, `at-consent`, `at-evidence` not started. No product application. No network API. No persistence. **AT-056 remains Not started.**
