from datetime import date

import pytest

from cgwo_core.capacity import (
    AvailabilityDeclaration,
    CapacityInvariantError,
    CapacityType,
    CapacityWindow,
)
from cgwo_core.tenancy import CrossTenantAccessError, TenantContext

D1, D5, D7, D9 = date(2026, 8, 1), date(2026, 8, 5), date(2026, 8, 7), date(2026, 8, 9)


def window(**kw):
    base = {
        "tenant_id": "t1",
        "resource_ref": "actor-1",
        "period_start": D1,
        "period_end": D5,
        "available_minutes": 600,
    }
    base.update(kw)
    return CapacityWindow(**base)


def test_valid_window_defaults_to_execution_capacity():
    assert window().capacity_type is CapacityType.EXECUTION


def test_supervisory_capacity_is_first_class():
    assert window(capacity_type=CapacityType.SUPERVISORY).capacity_type is CapacityType.SUPERVISORY


@pytest.mark.parametrize(
    "kw",
    [
        {"tenant_id": " "},
        {"resource_ref": ""},
        {"period_end": date(2026, 7, 31)},
        {"available_minutes": -1},
    ],
)
def test_window_invariants_rejected(kw):
    with pytest.raises(CapacityInvariantError):
        window(**kw)


def test_zero_minutes_window_is_valid():
    assert window(available_minutes=0).available_minutes == 0


def test_single_day_window_is_valid():
    assert window(period_end=D1).period_end == D1


def test_overlap_detected_for_same_resource_and_type():
    assert window().overlaps(window(period_start=D5, period_end=D7)) is True


def test_touching_boundary_counts_as_overlap():
    assert window(period_end=D5).overlaps(window(period_start=D5, period_end=D9)) is True


@pytest.mark.parametrize(
    "kw",
    [
        {"tenant_id": "t2"},
        {"resource_ref": "actor-2"},
        {"capacity_type": CapacityType.SUPERVISORY},
        {"period_start": D7, "period_end": D9},
    ],
)
def test_no_overlap_when_dimension_differs(kw):
    other = window(**{"period_start": D1, "period_end": D5, **kw})
    assert window().overlaps(other) is False


def test_no_overlap_when_other_precedes():
    late = window(period_start=D7, period_end=D9)
    assert late.overlaps(window()) is False


def declaration(**kw):
    base = {"tenant_id": "t1", "resource_ref": "actor-1", "window": window(), "declared_on": D1}
    base.update(kw)
    return AvailabilityDeclaration(**base)


def test_valid_declaration():
    assert declaration().window.available_minutes == 600


def test_declaration_tenant_must_match_window():
    with pytest.raises(CapacityInvariantError):
        declaration(tenant_id="t2", window=window())


def test_declaration_resource_must_match_window():
    with pytest.raises(CapacityInvariantError):
        declaration(resource_ref="actor-2")


def test_guarded_window_for_owner():
    assert declaration().guarded_window(TenantContext(tenant_id="t1")) == window()


def test_guarded_window_denies_other_tenant():
    with pytest.raises(CrossTenantAccessError):
        declaration().guarded_window(TenantContext(tenant_id="t2"))
