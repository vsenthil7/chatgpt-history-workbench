import pytest

from cgwo_core.tenancy import (
    CrossTenantAccessError,
    MissingTenantContextError,
    TenantContext,
    assert_same_tenant,
)


def test_valid_context_defaults_organisation_to_none():
    ctx = TenantContext(tenant_id="t1")
    assert ctx.tenant_id == "t1"
    assert ctx.organisation_id is None


def test_context_carries_organisation():
    assert TenantContext(tenant_id="t1", organisation_id="o1").organisation_id == "o1"


@pytest.mark.parametrize("bad", ["", "   "])
def test_blank_tenant_id_rejected(bad):
    with pytest.raises(MissingTenantContextError):
        TenantContext(tenant_id=bad)


def test_same_tenant_passes():
    assert_same_tenant(TenantContext(tenant_id="t1"), "t1")


def test_cross_tenant_denied():
    with pytest.raises(CrossTenantAccessError):
        assert_same_tenant(TenantContext(tenant_id="t1"), "t2")
