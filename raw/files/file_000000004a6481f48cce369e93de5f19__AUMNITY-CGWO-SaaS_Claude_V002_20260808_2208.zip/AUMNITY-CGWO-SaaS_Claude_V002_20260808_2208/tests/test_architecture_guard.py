"""ARC-001/ARC-002/ADR-006 guard: the domain core is pure and self-contained."""
import ast
import os
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "src" / "cgwo_core"
STDLIB = set(sys.stdlib_module_names)
# The mutation harness (G07) injects its own instrumentation import into the
# mutated copies it tests against. Allow exactly that module, exactly when the
# harness is driving; the pristine tree is still checked in the normal suite.
HARNESS_ALLOWANCE = {"mutmut"} if os.environ.get("MUTANT_UNDER_TEST") else set()


def _imported_roots(path: Path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                yield alias.name.split(".")[0]
        elif isinstance(node, ast.ImportFrom):
            assert node.level == 0, f"{path.name}: relative imports are forbidden"
            yield node.module.split(".")[0]


def test_domain_core_imports_only_stdlib_and_itself():
    offenders = {}
    for module in sorted(SRC.glob("*.py")):
        bad = [
            root
            for root in _imported_roots(module)
            if root != "cgwo_core" and root not in STDLIB and root not in HARNESS_ALLOWANCE
        ]
        if bad:
            offenders[module.name] = bad
    assert offenders == {}, f"forbidden dependencies in domain core: {offenders}"


def test_domain_core_contains_no_tenant_or_pilot_literals():
    forbidden = ("IPBS", "ipbs", "TEE ", "founder")
    hits = {}
    for module in sorted(SRC.glob("*.py")):
        text = module.read_text(encoding="utf-8")
        found = [term for term in forbidden if term in text]
        if found:
            hits[module.name] = found
    assert hits == {}, f"tenant/pilot-specific literals in domain core: {hits}"
