from datetime import date

import pytest

from cgwo_core.allocation import (
    ALLOWED_TRANSITIONS,
    DEFAULT_EVENT,
    EVENT_BY_TARGET,
    AllocationInvariantError,
    CapacityAllocation,
)
from cgwo_core.allocation import (
    AllocationState as A,
)
from cgwo_core.capacity import CapacityWindow
from cgwo_core.plan_item import InvalidTransitionError
from cgwo_core.tenancy import CrossTenantAccessError, TenantContext

CTX = TenantContext(tenant_id="t1")
WINDOW = CapacityWindow(
    tenant_id="t1",
    resource_ref="actor-1",
    period_start=date(2026, 8, 1),
    period_end=date(2026, 8, 5),
    available_minutes=600,
)


def allocation(state=A.PROPOSED, allocated=120, consumed=0, **kw):
    base = {
        "tenant_id": "t1",
        "window": WINDOW,
        "plan_item_ref": "pi-1",
        "allocated_minutes": allocated,
        "consumed_minutes": consumed,
        "state": state,
    }
    base.update(kw)
    return CapacityAllocation(**base)


ALL_PAIRS = [(f, t) for f, targets in ALLOWED_TRANSITIONS.items() for t in targets]


def test_state_machine_covers_full_baseline_catalogue():
    assert set(ALLOWED_TRANSITIONS) == set(A)


@pytest.mark.parametrize("frm,to", ALL_PAIRS)
def test_every_declared_transition_succeeds(frm, to):
    change = allocation(frm).transition(to, CTX)
    assert change.allocation.state is to
    assert change.event == EVENT_BY_TARGET.get(to, DEFAULT_EVENT)


def test_reservation_emits_capacity_reserved():
    assert allocation().transition(A.RESERVED, CTX).event == "CapacityReserved"


@pytest.mark.parametrize(
    "frm,to",
    [(A.PROPOSED, A.CONSUMING), (A.CONSUMED, A.RELEASED), (A.RELEASED, A.PROPOSED)],
)
def test_undeclared_transitions_rejected(frm, to):
    with pytest.raises(InvalidTransitionError):
        allocation(frm).transition(to, CTX)


def test_cross_tenant_transition_denied():
    with pytest.raises(CrossTenantAccessError):
        allocation().transition(A.RESERVED, TenantContext(tenant_id="t2"))


def test_partial_consumption():
    change = allocation(A.RESERVED).consume(50, CTX)
    assert change.allocation.state is A.PARTIALLY_CONSUMED
    assert change.allocation.consumed_minutes == 50
    assert change.event == "TimeRecorded"


def test_exact_consumption_completes_allocation():
    change = allocation(A.PARTIALLY_CONSUMED, consumed=70).consume(50, CTX)
    assert change.allocation.state is A.CONSUMED
    assert change.event == "TimeRecorded"


def test_overrun_detected_and_signalled():
    change = allocation(A.CONSUMING, consumed=100).consume(30, CTX)
    assert change.allocation.state is A.OVERRUN
    assert change.allocation.consumed_minutes == 130
    assert change.event == "CapacityOverrunDetected"


def test_consumption_illegal_before_reservation():
    with pytest.raises(InvalidTransitionError):
        allocation(A.PROPOSED).consume(10, CTX)


@pytest.mark.parametrize("minutes", [0, -5])
def test_nonpositive_consumption_rejected(minutes):
    with pytest.raises(AllocationInvariantError):
        allocation(A.RESERVED).consume(minutes, CTX)


def test_cross_tenant_consumption_denied():
    with pytest.raises(CrossTenantAccessError):
        allocation(A.RESERVED).consume(10, TenantContext(tenant_id="t2"))


@pytest.mark.parametrize(
    "kw",
    [
        {"tenant_id": "t2"},
        {"plan_item_ref": "  "},
        {"allocated": 0},
        {"consumed": -1},
    ],
)
def test_allocation_invariants_rejected(kw):
    with pytest.raises(AllocationInvariantError):
        allocation(**kw)
