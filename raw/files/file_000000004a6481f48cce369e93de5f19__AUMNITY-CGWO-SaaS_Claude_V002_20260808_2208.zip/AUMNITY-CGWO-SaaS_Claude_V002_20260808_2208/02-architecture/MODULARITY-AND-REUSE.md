# Modularity and Reuse Architecture

## Ownership for this package
Canonical scope: **CGWO-SCOPE-1** in `01-product/CANONICAL-SCOPE.md` (ADR-004). Platform primitive consumption per ADR-006 (`PLATFORM-PRIMITIVES-CONTRACT.md`); external-system bridges per ADR-001/ADR-005 (`INTEGRATION-BOUNDARIES.md`).

## Dependency principle
Depend on stable contracts at bounded-context edges. Do not reach into another module's persistence model or copy its domain rules. Shared core must remain smaller than the products that consume it.

## Placement test
Before adding a significant component, classify it as: tenant configuration/data; bounded-product domain logic; shared platform primitive; integration adapter; or cross-cutting infrastructure. If ownership is unclear, create an ADR before code.

## SaaS guard
Protected operations must carry explicit tenant/organisation context and be tested for cross-tenant denial. Avoid global mutable tenant state.
