# Requirement Traceability Matrix — V002

| ID | Requirement | Owner | Enforcement | Evidence/Test | Status |
|---|---|---|---|---|---|
| ARC-001 | Product code remains within declared bounded ownership | Architecture | architecture guard | tests/test_architecture_guard.py | ENFORCED |
| ARC-002 | Cross-product reuse occurs through published contracts, not copied logic | Architecture | review + dependency guard | tests/test_architecture_guard.py; ADR-006; 02-architecture/PLATFORM-PRIMITIVES-CONTRACT.md | ENFORCED (code) / DECLARED (contracts) |
| ARC-003 | Execution Session state is owned by CGWO; trackers/timesheets are bridged systems of record | Architecture | ADR + boundary docs | 11-decisions/ADR-001-execution-session-and-tracker-ownership.md; 02-architecture/INTEGRATION-BOUNDARIES.md | DECLARED |
| ARC-004 | Boundary wording has a single canonical source | Governance | consistency validator | 01-product/CANONICAL-SCOPE.md; scripts/validate_consistency.py; evidence/consistency-output.txt | ENFORCED |
| SaaS-001 | Reusable product code is tenant-neutral | Platform/Product | tenant-leak guard + tests | tests/test_architecture_guard.py; scripts/validate_consistency.py | ENFORCED |
| SaaS-002 | Tenant/org context is explicit at protected boundaries | Platform/Product | authz/isolation tests | tests/test_tenancy.py; cross-tenant denial tests in tests/test_plan_item.py, tests/test_allocation.py, tests/test_capacity.py | ENFORCED (domain core) |
| SaaS-003 | Supervisory/review capacity is a generic, tenant-configurable capacity type | Product | ADR + domain tests | 11-decisions/ADR-002-supervisory-capacity-generalisation.md; tests/test_capacity.py | ENFORCED (enum) / DECLARED (tenant config) |
| DOM-001 | Plan Item honours the baseline state catalogue with explicit transition rules | Product | unit/domain tests | tests/test_plan_item.py (full transition matrix) | ENFORCED |
| DOM-002 | Adaptive replanning transitions require an explicit change reason | Product | unit/domain tests | tests/test_plan_item.py reason-required cases | ENFORCED |
| DOM-003 | Capacity allocation honours the baseline state catalogue including overrun detection | Product | unit/domain tests | tests/test_allocation.py (full transition matrix + consume paths) | ENFORCED |
| DOM-004 | Capacity windows enforce period/effort invariants and overlap detection | Product | unit/domain tests | tests/test_capacity.py | ENFORCED |
| INT-001 | Recruitment/training needs are raised as events; ATS/LMS remain external | Architecture | ADR + boundary docs | 11-decisions/ADR-005-recruitment-training-boundary.md | DECLARED |
| INT-002 | UraiFlow record proposals are inbound suggestions requiring confirmation | Architecture | ADR + boundary docs | 02-architecture/INTEGRATION-BOUNDARIES.md | DECLARED |
| QA-001 | New executable packages meet line+branch coverage policy | Engineering | coverage gate | evidence/test-summary.json; evidence/coverage.json | ENFORCED |
| QA-002 | Critical domain/policy behavior is mutation tested | Engineering | mutation gate | evidence/mutation-summary.json (tooling gap recorded) | PARTIAL — RED |
| QA-003 | Escaped defects receive regression tests | Engineering | review/CI | none escaped yet | DECLARED |
| DOC-001 | Version, package, test-count and ADR references are consistency checked | Governance | docs gate | scripts/validate_starter.py; scripts/validate_consistency.py; evidence/consistency-output.txt | ACTIVE |
| AI-001 | Claude build → independent ChatGPT ZIP review loop is used for releases | Governance | release checklist | 08-ai/CLAUDE-V002-HANDOFF.md | ACTIVE |
