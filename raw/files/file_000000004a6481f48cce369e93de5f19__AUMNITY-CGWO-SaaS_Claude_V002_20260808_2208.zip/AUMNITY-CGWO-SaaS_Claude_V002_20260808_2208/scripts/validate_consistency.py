#!/usr/bin/env python3
"""Machine-detectable contradiction checks for the CGWO repository (DOC-001, ADR-004).

Checks: required files; ADR status headers; canonical-scope single source of truth;
superseded/tenant-specific vocabulary placement; manifest hash integrity; evidence
presence and gate-status cross-reference.
Exit code 0 = PASS, 1 = violations found.
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

REQUIRED = [
    "00-control/PROJECT-START.md", "00-control/READING-MAP.md",
    "00-control/RELEASE-NOTES-V002.md", "CLAUDE.md",
    "01-product/CANONICAL-SCOPE.md", "01-product/PRODUCT-BOUNDARY-AND-SAAS.md",
    "02-architecture/MODULARITY-AND-REUSE.md",
    "02-architecture/PLATFORM-PRIMITIVES-CONTRACT.md",
    "02-architecture/INTEGRATION-BOUNDARIES.md",
    "03-engineering/ENGINEERING-OPERATING-SYSTEM.md",
    "04-testing/TESTING-STRATEGY.md", "05-quality/QUALITY-GATES.md",
    "05-quality/GATE-STATUS-V002.md", "06-traceability/RTM.md",
    "07-planning/FIRST-BUILD-BACKLOG.md", "08-ai/CHATGPT-REVIEW-HANDOFF.md",
    "08-ai/CLAUDE-V002-HANDOFF.md", "09-governance/VERSIONING-AND-PACKAGING.md",
    "evidence/test-summary.json",
]
for rel in REQUIRED:
    if not (ROOT / rel).is_file():
        errors.append(f"missing required file: {rel}")

# --- ADR status headers -------------------------------------------------------
ADR_DIR = ROOT / "11-decisions"
adr_files = sorted(ADR_DIR.glob("ADR-*.md")) if ADR_DIR.is_dir() else []
if not adr_files:
    errors.append("no ADR files found in 11-decisions/")
STATUS_RE = re.compile(r"^Status:\s*(ACCEPTED|PROPOSED|SUPERSEDED|REJECTED)", re.MULTILINE)
for adr in adr_files:
    if not STATUS_RE.search(adr.read_text(encoding="utf-8")):
        errors.append(f"{adr.relative_to(ROOT)}: missing/invalid 'Status:' header")

# --- Canonical scope: defined once, referenced elsewhere ----------------------
DEFINING = Path("01-product/CANONICAL-SCOPE.md")
REFERENCING = [
    "00-control/PROJECT-START.md",
    "01-product/PRODUCT-BOUNDARY-AND-SAAS.md",
    "02-architecture/MODULARITY-AND-REUSE.md",
]
scope_text = (ROOT / DEFINING).read_text(encoding="utf-8") if (ROOT / DEFINING).is_file() else ""
for scope_id in ("CGWO-SCOPE-1", "CGWO-NOTOWNED-1"):
    if f"## {scope_id}" not in scope_text:
        errors.append(f"{DEFINING}: canonical id {scope_id} not defined")
    for rel in REFERENCING:
        f = ROOT / rel
        if f.is_file() and scope_id == "CGWO-SCOPE-1" and scope_id not in f.read_text(encoding="utf-8"):
            errors.append(f"{rel}: does not reference {scope_id}")

# --- Vocabulary placement (ADR-002, tenant neutrality) ------------------------
SELF = Path(__file__).resolve()
# Enforcement points necessarily name the tokens they forbid.
ENFORCEMENT_FILES = {"scripts/validate_consistency.py", "tests/test_architecture_guard.py"}
EXEMPT_PREFIXES = ("10-baseline/", "11-decisions/", "evidence/provenance/")
SUPERSEDED = [re.compile(p) for p in (r"\bTEE\b", r"\bfounder\b", r"body/mind")]
PILOT = re.compile(r"\bIPBS\b")
PILOT_DOC_ALLOWLIST = {
    "00-control/PROJECT-START.md",        # names IPBS as tenant/pilot, per SaaS rule
    "00-control/RELEASE-NOTES-V002.md",
    "01-product/CANONICAL-SCOPE.md",      # states the exclusion itself
    "01-product/PRODUCT-BOUNDARY-AND-SAAS.md",
    "02-architecture/INTEGRATION-BOUNDARIES.md",
    "07-planning/FIRST-BUILD-BACKLOG.md",
    "08-ai/CLAUDE-V002-HANDOFF.md",
    "CLAUDE.md",
}
for path in sorted(ROOT.rglob("*")):
    if not path.is_file() or path.resolve() == SELF:
        continue
    rel = path.relative_to(ROOT).as_posix()
    if rel in ENFORCEMENT_FILES or rel.startswith(EXEMPT_PREFIXES) or rel.startswith(("mutants/", ".")) or "__pycache__" in rel:
        continue
    if path.suffix not in {".md", ".py", ".json", ".ini", ".cfg", ".txt"}:
        continue
    text = path.read_text(encoding="utf-8", errors="ignore")
    in_code = rel.startswith(("src/", "tests/"))
    for rx in SUPERSEDED:
        if rx.search(text):
            errors.append(f"{rel}: superseded vocabulary '{rx.pattern}' outside baseline/ADRs (ADR-002)")
    if PILOT.search(text) and (in_code or (not rel.startswith(("src/", "tests/")) and rel not in PILOT_DOC_ALLOWLIST)):
        errors.append(f"{rel}: pilot-tenant name outside allowlisted pilot/evidence docs")

# --- Manifest hash integrity --------------------------------------------------
if "--skip-manifest" not in sys.argv:
    mf = ROOT / "PACKAGE-MANIFEST.json"
    if mf.is_file():
        manifest = json.loads(mf.read_text(encoding="utf-8"))
        for entry in manifest.get("files", []):
            p = ROOT / entry["path"]
            if not p.is_file():
                errors.append(f"manifest lists missing file: {entry['path']}")
            elif hashlib.sha256(p.read_bytes()).hexdigest() != entry["sha256"]:
                errors.append(f"manifest hash mismatch: {entry['path']}")
    else:
        errors.append("PACKAGE-MANIFEST.json missing")

# --- Evidence and gate-status cross-checks ------------------------------------
summary_path = ROOT / "evidence/test-summary.json"
if summary_path.is_file():
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    if summary.get("tests_passed", 0) <= 0 or summary.get("tests_failed", 1) != 0:
        errors.append("evidence/test-summary.json does not record a fully passing suite")
    for key in ("coverage_line_percent", "coverage_branch_percent"):
        if summary.get(key) != 100.0:
            errors.append(f"evidence: {key} is not 100 (G04)")
gate_status = ROOT / "05-quality/GATE-STATUS-V002.md"
if gate_status.is_file() and "evidence/test-summary.json" not in gate_status.read_text(encoding="utf-8"):
    errors.append("GATE-STATUS-V002.md must reference evidence/test-summary.json, not hand-typed counts")

if errors:
    print("CONSISTENCY: FAIL")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("CONSISTENCY: PASS")
