#!/usr/bin/env python3
"""Regenerate PACKAGE-MANIFEST.json with SHA-256 hashes (one source of truth)."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDE_DIRS = {"mutants", "__pycache__", ".pytest_cache", ".ruff_cache"}
EXCLUDE_FILES = {"PACKAGE-MANIFEST.json", ".coverage"}

files = []
for path in sorted(ROOT.rglob("*")):
    if not path.is_file():
        continue
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDE_DIRS or part.startswith(".") for part in rel.parts):
        continue
    if rel.name in EXCLUDE_FILES:
        continue
    files.append({
        "path": rel.as_posix(),
        "bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    })

manifest = {
    "schema": "aumnity-package-manifest/1",
    "project": "AUMNITY CGWO SaaS",
    "release": ROOT.name,
    "generated": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "file_count": len(files),
    "files": files,
}
(ROOT / "PACKAGE-MANIFEST.json").write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
print(f"manifest written: {len(files)} files")
