# Canonical CGWO Scope — single source of truth (ADR-004)

## CGWO-SCOPE-1
CGWO owns capacity-governed work orchestration as reusable multi-tenant SaaS: idea/opportunity intake; service/product readiness modelling; capability demand; availability declarations and capacity horizons (execution and supervisory capacity per ADR-002); resource-to-work matching; overall/weekly/daily planning; adaptive replanning with change reasons; capacity allocation and conflict detection; execution session recording and execution coordination; tracker/timesheet domain bridges (ADR-001); and review/learning feedback.

## CGWO-NOTOWNED-1
CGWO does not own: identity, tenancy, actor, organisation, capability-taxonomy or generic work-object primitives (AUMNITY Work Platform, ADR-006); audio, transcription or conversation extraction (UraiFlow); tracker or timesheet products (external systems of record, ADR-001); applicant tracking or learning management (ADR-005); payroll, full HRMS, CRM or accounting; any IPBS-specific implementation (IPBS is a tenant/pilot/evidence source only).

All other artefacts must reference the IDs **CGWO-SCOPE-1** / **CGWO-NOTOWNED-1** rather than restating the boundary in different words. The preserved baseline under `10-baseline/` is historical evidence and exempt.
