"""Plan Item state machine — baseline state catalogue with change-reason rules."""
from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum

from cgwo_core.tenancy import TenantContext, assert_same_tenant


class PlanItemState(str, Enum):
    CANDIDATE = "CANDIDATE"
    WEEK_PLANNED = "WEEK_PLANNED"
    DAY_PLANNED = "DAY_PLANNED"
    STARTED = "STARTED"
    PAUSED = "PAUSED"
    BLOCKED = "BLOCKED"
    INTERRUPTED = "INTERRUPTED"
    DEFERRED = "DEFERRED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


S = PlanItemState

#: Allowed transitions. Terminal states have empty target sets.
ALLOWED_TRANSITIONS: dict[PlanItemState, frozenset[PlanItemState]] = {
    S.CANDIDATE: frozenset({S.WEEK_PLANNED, S.DEFERRED, S.CANCELLED}),
    S.WEEK_PLANNED: frozenset({S.DAY_PLANNED, S.CANDIDATE, S.DEFERRED, S.CANCELLED}),
    S.DAY_PLANNED: frozenset({S.STARTED, S.WEEK_PLANNED, S.DEFERRED, S.CANCELLED}),
    S.STARTED: frozenset({S.PAUSED, S.BLOCKED, S.INTERRUPTED, S.COMPLETED, S.CANCELLED}),
    S.PAUSED: frozenset({S.STARTED, S.INTERRUPTED, S.DEFERRED, S.CANCELLED}),
    S.BLOCKED: frozenset({S.STARTED, S.DEFERRED, S.CANCELLED}),
    S.INTERRUPTED: frozenset({S.DAY_PLANNED, S.WEEK_PLANNED, S.DEFERRED, S.CANCELLED}),
    S.DEFERRED: frozenset({S.CANDIDATE, S.WEEK_PLANNED, S.CANCELLED}),
    S.COMPLETED: frozenset(),
    S.CANCELLED: frozenset(),
}

#: Targets that always demand an explicit change reason (adaptive replanning).
REASON_REQUIRED_TARGETS: frozenset[PlanItemState] = frozenset(
    {S.BLOCKED, S.INTERRUPTED, S.DEFERRED, S.CANCELLED}
)

#: Demotions (plan rollbacks) that also demand a change reason.
REASON_REQUIRED_DEMOTIONS: frozenset[tuple[PlanItemState, PlanItemState]] = frozenset(
    {(S.WEEK_PLANNED, S.CANDIDATE), (S.DAY_PLANNED, S.WEEK_PLANNED)}
)

#: Domain event emitted per transition (baseline event catalogue); default below.
EVENT_BY_TRANSITION: dict[tuple[PlanItemState, PlanItemState], str] = {
    (S.CANDIDATE, S.WEEK_PLANNED): "WeeklyPlanChanged",
    (S.WEEK_PLANNED, S.CANDIDATE): "WeeklyPlanChanged",
    (S.DEFERRED, S.WEEK_PLANNED): "WeeklyPlanChanged",
    (S.INTERRUPTED, S.WEEK_PLANNED): "WeeklyPlanChanged",
    (S.WEEK_PLANNED, S.DAY_PLANNED): "DailyPlanChanged",
    (S.DAY_PLANNED, S.WEEK_PLANNED): "DailyPlanChanged",
    (S.INTERRUPTED, S.DAY_PLANNED): "DailyPlanChanged",
    (S.STARTED, S.INTERRUPTED): "WorkInterrupted",
    (S.PAUSED, S.INTERRUPTED): "WorkInterrupted",
}

DEFAULT_EVENT = "PlanItemStateChanged"


class InvalidTransitionError(ValueError):
    """Raised for a transition not present in ALLOWED_TRANSITIONS."""


class ChangeReasonRequiredError(ValueError):
    """Raised when a replanning transition lacks an explicit change reason."""


@dataclass(frozen=True, slots=True)
class TransitionResult:
    item: PlanItem
    event: str


@dataclass(frozen=True, slots=True)
class PlanItem:
    """Placement of a Platform Work Object into a planning horizon (ADR-006 refs)."""

    tenant_id: str
    work_object_ref: str
    state: PlanItemState = PlanItemState.CANDIDATE

    def __post_init__(self) -> None:
        if not self.tenant_id.strip():
            raise ValueError("tenant_id must be non-blank")
        if not self.work_object_ref.strip():
            raise ValueError("work_object_ref must be non-blank")

    def transition(
        self,
        target: PlanItemState,
        ctx: TenantContext,
        change_reason: str | None = None,
    ) -> TransitionResult:
        assert_same_tenant(ctx, self.tenant_id)
        if target not in ALLOWED_TRANSITIONS[self.state]:
            raise InvalidTransitionError(
                f"transition {self.state.value} -> {target.value} is not allowed"
            )
        needs_reason = (
            target in REASON_REQUIRED_TARGETS
            or (self.state, target) in REASON_REQUIRED_DEMOTIONS
        )
        if needs_reason and not (change_reason or "").strip():
            raise ChangeReasonRequiredError(
                f"transition {self.state.value} -> {target.value} requires a change reason"
            )
        event = EVENT_BY_TRANSITION.get((self.state, target), DEFAULT_EVENT)
        return TransitionResult(item=replace(self, state=target), event=event)
