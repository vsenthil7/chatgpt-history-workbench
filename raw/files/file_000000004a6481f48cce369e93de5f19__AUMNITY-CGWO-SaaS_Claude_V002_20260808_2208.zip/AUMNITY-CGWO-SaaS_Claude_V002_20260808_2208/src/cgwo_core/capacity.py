"""Availability declarations and capacity windows (ADR-002 capacity types)."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from enum import Enum

from cgwo_core.tenancy import TenantContext, assert_same_tenant


class CapacityType(str, Enum):
    """Generalised capacity kinds per ADR-002. Tenants may extend by policy later."""

    EXECUTION = "EXECUTION"
    SUPERVISORY = "SUPERVISORY"


class CapacityInvariantError(ValueError):
    """Raised when a capacity value object violates a domain invariant."""


@dataclass(frozen=True, slots=True)
class CapacityWindow:
    """Realistic effort available for one resource, period and capacity type."""

    tenant_id: str
    resource_ref: str
    period_start: date
    period_end: date
    available_minutes: int
    capacity_type: CapacityType = CapacityType.EXECUTION

    def __post_init__(self) -> None:
        if not self.tenant_id.strip():
            raise CapacityInvariantError("tenant_id must be non-blank")
        if not self.resource_ref.strip():
            raise CapacityInvariantError("resource_ref must be non-blank")
        if self.period_end < self.period_start:
            raise CapacityInvariantError("period_end must not precede period_start")
        if self.available_minutes < 0:
            raise CapacityInvariantError("available_minutes must be >= 0")

    def overlaps(self, other: CapacityWindow) -> bool:
        """True when two windows compete for the same resource capacity."""
        if self.tenant_id != other.tenant_id:
            return False
        if self.resource_ref != other.resource_ref:
            return False
        if self.capacity_type is not other.capacity_type:
            return False
        return (
            self.period_start <= other.period_end
            and other.period_start <= self.period_end
        )


@dataclass(frozen=True, slots=True)
class AvailabilityDeclaration:
    """A resource's statement of expected contribution for a window."""

    tenant_id: str
    resource_ref: str
    window: CapacityWindow
    declared_on: date

    def __post_init__(self) -> None:
        if self.tenant_id != self.window.tenant_id:
            raise CapacityInvariantError("declaration tenant must match window tenant")
        if self.resource_ref != self.window.resource_ref:
            raise CapacityInvariantError("declaration resource must match window resource")

    def guarded_window(self, ctx: TenantContext) -> CapacityWindow:
        """Return the window only for the owning tenant (SaaS-002)."""
        assert_same_tenant(ctx, self.tenant_id)
        return self.window
