"""CGWO domain core — capacity/availability and planning state transitions.

Pure standard-library reference implementation per ADR-003 (Status: PROPOSED).
All Platform primitives are consumed as opaque references per ADR-006.
Capacity types generalise supervisory/review capacity per ADR-002.
Execution/tracker ownership per ADR-001.
"""
from cgwo_core.allocation import AllocationState, CapacityAllocation
from cgwo_core.capacity import AvailabilityDeclaration, CapacityType, CapacityWindow
from cgwo_core.plan_item import (
    ChangeReasonRequiredError,
    InvalidTransitionError,
    PlanItem,
    PlanItemState,
)
from cgwo_core.tenancy import (
    CrossTenantAccessError,
    MissingTenantContextError,
    TenantContext,
    TenantIsolationError,
    assert_same_tenant,
)

__all__ = [
    "AllocationState",
    "AvailabilityDeclaration",
    "CapacityAllocation",
    "CapacityType",
    "CapacityWindow",
    "ChangeReasonRequiredError",
    "CrossTenantAccessError",
    "InvalidTransitionError",
    "MissingTenantContextError",
    "PlanItem",
    "PlanItemState",
    "TenantContext",
    "TenantIsolationError",
    "assert_same_tenant",
]
