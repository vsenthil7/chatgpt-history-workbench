"""Explicit tenant context for every protected operation (SaaS-002, ADR-006)."""
from __future__ import annotations

from dataclasses import dataclass


class TenantIsolationError(Exception):
    """Base class for tenant-isolation failures."""


class MissingTenantContextError(TenantIsolationError):
    """Raised when a protected operation lacks a usable tenant context."""


class CrossTenantAccessError(TenantIsolationError):
    """Raised when a tenant context touches another tenant's aggregate."""


@dataclass(frozen=True, slots=True)
class TenantContext:
    """Opaque Platform tenancy references; CGWO validates presence, not shape."""

    tenant_id: str
    organisation_id: str | None = None

    def __post_init__(self) -> None:
        if not self.tenant_id.strip():
            raise MissingTenantContextError("tenant_id is required and must be non-blank")


def assert_same_tenant(ctx: TenantContext, owner_tenant_id: str) -> None:
    """Deny cross-tenant access to an aggregate owned by ``owner_tenant_id``."""
    if ctx.tenant_id != owner_tenant_id:
        raise CrossTenantAccessError(
            "tenant context does not match aggregate owner tenant"
        )
