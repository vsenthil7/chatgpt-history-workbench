"""Capacity allocation state machine including overrun detection (ADR-001/002)."""
from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum

from cgwo_core.capacity import CapacityWindow
from cgwo_core.plan_item import InvalidTransitionError
from cgwo_core.tenancy import TenantContext, assert_same_tenant


class AllocationState(str, Enum):
    PROPOSED = "PROPOSED"
    RESERVED = "RESERVED"
    CONSUMING = "CONSUMING"
    PARTIALLY_CONSUMED = "PARTIALLY_CONSUMED"
    CONSUMED = "CONSUMED"
    RELEASED = "RELEASED"
    OVERRUN = "OVERRUN"


A = AllocationState

ALLOWED_TRANSITIONS: dict[AllocationState, frozenset[AllocationState]] = {
    A.PROPOSED: frozenset({A.RESERVED, A.RELEASED}),
    A.RESERVED: frozenset({A.CONSUMING, A.RELEASED}),
    A.CONSUMING: frozenset({A.PARTIALLY_CONSUMED, A.CONSUMED, A.OVERRUN, A.RELEASED}),
    A.PARTIALLY_CONSUMED: frozenset({A.CONSUMING, A.CONSUMED, A.OVERRUN, A.RELEASED}),
    A.CONSUMED: frozenset(),
    A.RELEASED: frozenset(),
    A.OVERRUN: frozenset({A.CONSUMED, A.RELEASED}),
}

EVENT_BY_TARGET: dict[AllocationState, str] = {
    A.RESERVED: "CapacityReserved",
    A.OVERRUN: "CapacityOverrunDetected",
}

DEFAULT_EVENT = "CapacityAllocationChanged"

#: States from which recorded consumption is legal.
CONSUMABLE_STATES: frozenset[AllocationState] = frozenset(
    {A.RESERVED, A.CONSUMING, A.PARTIALLY_CONSUMED}
)


class AllocationInvariantError(ValueError):
    """Raised when an allocation violates a domain invariant."""


@dataclass(frozen=True, slots=True)
class AllocationChange:
    allocation: CapacityAllocation
    event: str


@dataclass(frozen=True, slots=True)
class CapacityAllocation:
    """Reservation of part of a CapacityWindow for a Plan Item."""

    tenant_id: str
    window: CapacityWindow
    plan_item_ref: str
    allocated_minutes: int
    consumed_minutes: int = 0
    state: AllocationState = AllocationState.PROPOSED

    def __post_init__(self) -> None:
        if self.tenant_id != self.window.tenant_id:
            raise AllocationInvariantError("allocation tenant must match window tenant")
        if not self.plan_item_ref.strip():
            raise AllocationInvariantError("plan_item_ref must be non-blank")
        if self.allocated_minutes <= 0:
            raise AllocationInvariantError("allocated_minutes must be > 0")
        if self.consumed_minutes < 0:
            raise AllocationInvariantError("consumed_minutes must be >= 0")

    def transition(self, target: AllocationState, ctx: TenantContext) -> AllocationChange:
        assert_same_tenant(ctx, self.tenant_id)
        if target not in ALLOWED_TRANSITIONS[self.state]:
            raise InvalidTransitionError(
                f"transition {self.state.value} -> {target.value} is not allowed"
            )
        event = EVENT_BY_TARGET.get(target, DEFAULT_EVENT)
        return AllocationChange(allocation=replace(self, state=target), event=event)

    def consume(self, minutes: int, ctx: TenantContext) -> AllocationChange:
        """Record actual consumption; derives PARTIALLY_CONSUMED/CONSUMED/OVERRUN."""
        assert_same_tenant(ctx, self.tenant_id)
        if self.state not in CONSUMABLE_STATES:
            raise InvalidTransitionError(
                f"cannot record consumption from state {self.state.value}"
            )
        if minutes <= 0:
            raise AllocationInvariantError("consumed minutes must be > 0")
        total = self.consumed_minutes + minutes
        if total > self.allocated_minutes:
            target = A.OVERRUN
        elif total == self.allocated_minutes:
            target = A.CONSUMED
        else:
            target = A.PARTIALLY_CONSUMED
        event = EVENT_BY_TARGET.get(target, "TimeRecorded")
        return AllocationChange(
            allocation=replace(self, consumed_minutes=total, state=target),
            event=event,
        )
