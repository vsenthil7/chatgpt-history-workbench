"""RTM: SLICE-005, SLICE-006, SLICE-007 — human confirmation, end-to-end slice,
lineage chain, atomic commit with compensation."""
from datetime import datetime, timezone

import pytest

from uraiflow.adapters.contract import CommitReceipt, standard_validate
from uraiflow.adapters.inmemory import InMemoryTargetAdapter
from uraiflow.confirmation.service import ConfirmationService
from uraiflow.core.clock import FixedClock
from uraiflow.core.errors import CommitError, InvalidTransitionError, TenantIsolationError
from uraiflow.core.tenancy import TenantContext
from uraiflow.extraction.extractor import RuleBasedExtractor
from uraiflow.lineage.store import LineageStore
from uraiflow.pipeline.orchestrator import ConversationToActionPipeline
from uraiflow.proposal.model import ItemDecision, ProposalStatus
from uraiflow.routing.registry import AdapterRegistry
from uraiflow.transcription.provider import DeterministicEchoProvider
from uraiflow.transcription.selector import ProviderSelector

T0 = datetime(2026, 8, 8, 12, 0, tzinfo=timezone.utc)
CTX_A = TenantContext(tenant_id="tenant-a", actor_id="user-1")
CTX_B = TenantContext(tenant_id="tenant-b", actor_id="user-2")
SAMPLE = (
    "I spoke to Auditor for 20 minutes, follow up on Monday, "
    "and tomorrow I am available ten to one."
)

REQUIRED = {
    "time_entry": ("contact", "minutes"),
    "follow_up": ("note",),
    "availability": ("window",),
}


class FailingAdapter(InMemoryTargetAdapter):
    """Test double: accepts follow_up but always fails commit (SLICE-007)."""

    def commit(self, ctx, record, idempotency_key):  # noqa: D102
        raise CommitError(f"{self.descriptor().name}: simulated outage")


def _pipeline(fail_follow_up: bool = False):
    lineage = LineageStore()
    clock = FixedClock(T0)
    registry = AdapterRegistry()
    main = InMemoryTargetAdapter(
        name="target-main",
        schema_version="1.0",
        required_fields={k: REQUIRED[k] for k in ("time_entry", "availability")},
    )
    follow_cls = FailingAdapter if fail_follow_up else InMemoryTargetAdapter
    follow = follow_cls(
        name="target-follow",
        schema_version="1.0",
        required_fields={"follow_up": REQUIRED["follow_up"]},
    )
    registry.register(main)
    registry.register(follow)
    selector = ProviderSelector(
        providers={"echo": DeterministicEchoProvider("echo")},
        tenant_policy={},
        default_provider="echo",
    )
    pipeline = ConversationToActionPipeline(
        selector=selector,
        extractor=RuleBasedExtractor(),
        registry=registry,
        lineage=lineage,
        clock=clock,
    )
    return pipeline, lineage, main, follow


def test_ingest_produces_awaiting_confirmation_proposal():
    pipeline, lineage, _, _ = _pipeline()
    proposal = pipeline.ingest(CTX_A, source_ref="call-1", content=SAMPLE)
    assert proposal.status is ProposalStatus.AWAITING_CONFIRMATION
    assert sorted(i.record_type for i in proposal.items) == [
        "availability",
        "follow_up",
        "time_entry",
    ]
    kinds = [e.kind for e in lineage.for_subject(CTX_A, proposal.proposal_id)]
    assert kinds == ["proposal.created", "proposal.routed", "proposal.validated"]


def test_ingest_without_candidates_goes_to_needs_clarification():
    pipeline, lineage, _, _ = _pipeline()
    proposal = pipeline.ingest(CTX_A, source_ref="call-2", content="nice weather today")
    assert proposal.status is ProposalStatus.NEEDS_CLARIFICATION
    kinds = [e.kind for e in lineage.for_subject(CTX_A, proposal.proposal_id)]
    assert kinds == ["proposal.created", "proposal.needs_clarification"]


def test_ingest_with_invalid_candidate_goes_to_needs_clarification():
    pipeline, _, _, _ = _pipeline()
    # 'spoke to X for N minutes' missing => only follow_up matched but note present;
    # force invalid by registering adapter that requires a field extraction never sets.
    registry = AdapterRegistry()
    registry.register(
        InMemoryTargetAdapter(
            name="strict",
            schema_version="1.0",
            required_fields={"follow_up": ("note", "owner")},
        )
    )
    pipeline._registry = registry  # test seam: swap routing table
    proposal = pipeline.ingest(CTX_A, source_ref="call-3", content="please follow up")
    assert proposal.status is ProposalStatus.NEEDS_CLARIFICATION
    assert proposal.items[0].validation_errors != ()


def test_confirmation_confirm_all_and_commit_end_to_end():
    pipeline, lineage, main, follow = _pipeline()
    confirmation = ConfirmationService(lineage=lineage, clock=pipeline.clock)
    proposal = pipeline.ingest(CTX_A, source_ref="call-4", content=SAMPLE)
    confirmation.confirm_all(CTX_A, proposal)
    assert proposal.status is ProposalStatus.CONFIRMED
    outcome = pipeline.commit(CTX_A, proposal)
    assert proposal.status is ProposalStatus.COMMITTED
    assert len(outcome.receipts) == 3
    assert main.committed_count(CTX_A) == 2
    assert follow.committed_count(CTX_A) == 1
    kinds = [e.kind for e in lineage.for_subject(CTX_A, proposal.proposal_id)]
    assert kinds[-1] == "proposal.committed"
    assert kinds.count("record.committed") == 3


def test_confirm_selected_leads_to_partial_and_commits_only_selected():
    pipeline, lineage, main, follow = _pipeline()
    confirmation = ConfirmationService(lineage=lineage, clock=pipeline.clock)
    proposal = pipeline.ingest(CTX_A, source_ref="call-5", content=SAMPLE)
    keep = [i.record_id for i in proposal.items if i.record_type == "time_entry"]
    confirmation.confirm_selected(CTX_A, proposal, keep)
    assert proposal.status is ProposalStatus.PARTIALLY_CONFIRMED
    outcome = pipeline.commit(CTX_A, proposal)
    assert len(outcome.receipts) == 1
    assert follow.committed_count(CTX_A) == 0


def test_reject_all_is_terminal_and_uncommittable():
    pipeline, lineage, _, _ = _pipeline()
    confirmation = ConfirmationService(lineage=lineage, clock=pipeline.clock)
    proposal = pipeline.ingest(CTX_A, source_ref="call-6", content=SAMPLE)
    confirmation.reject_all(CTX_A, proposal)
    assert proposal.status is ProposalStatus.REJECTED
    with pytest.raises(InvalidTransitionError):
        pipeline.commit(CTX_A, proposal)


def test_edit_then_confirm_uses_edited_fields():
    pipeline, lineage, main, _ = _pipeline()
    confirmation = ConfirmationService(lineage=lineage, clock=pipeline.clock)
    proposal = pipeline.ingest(CTX_A, source_ref="call-7", content=SAMPLE)
    target = next(i for i in proposal.items if i.record_type == "time_entry")
    confirmation.edit(CTX_A, proposal, target.record_id, {"contact": "Auditor", "minutes": 25})
    confirmation.confirm_selected(CTX_A, proposal, [target.record_id])
    pipeline.commit(CTX_A, proposal)
    stored = main.stored_record(CTX_A, f"{proposal.proposal_id}:{target.record_id}")
    assert stored.fields["minutes"] == 25


def test_confirmation_denies_foreign_tenant():
    pipeline, lineage, _, _ = _pipeline()
    confirmation = ConfirmationService(lineage=lineage, clock=pipeline.clock)
    proposal = pipeline.ingest(CTX_A, source_ref="call-8", content=SAMPLE)
    with pytest.raises(TenantIsolationError):
        confirmation.confirm_all(CTX_B, proposal)


def test_commit_denies_foreign_tenant():
    pipeline, lineage, _, _ = _pipeline()
    confirmation = ConfirmationService(lineage=lineage, clock=pipeline.clock)
    proposal = pipeline.ingest(CTX_A, source_ref="call-9", content=SAMPLE)
    confirmation.confirm_all(CTX_A, proposal)
    with pytest.raises(TenantIsolationError):
        pipeline.commit(CTX_B, proposal)


def test_commit_failure_compensates_and_rolls_back():
    pipeline, lineage, main, follow = _pipeline(fail_follow_up=True)
    confirmation = ConfirmationService(lineage=lineage, clock=pipeline.clock)
    proposal = pipeline.ingest(CTX_A, source_ref="call-10", content=SAMPLE)
    confirmation.confirm_all(CTX_A, proposal)
    outcome = pipeline.commit(CTX_A, proposal)
    assert proposal.status is ProposalStatus.ROLLED_BACK
    assert outcome.receipts == ()
    assert "simulated outage" in outcome.failure
    assert main.committed_count(CTX_A) == 0  # compensated
    kinds = [e.kind for e in lineage.for_subject(CTX_A, proposal.proposal_id)]
    assert "proposal.commit_failed" in kinds and kinds[-1] == "proposal.rolled_back"


def test_lineage_chain_links_capture_transcript_proposal():
    pipeline, lineage, _, _ = _pipeline()
    proposal = pipeline.ingest(CTX_A, source_ref="call-11", content=SAMPLE)
    created = lineage.for_subject(CTX_A, proposal.proposal_id)[0]
    assert created.payload["capture_id"] == proposal.capture_id
    assert created.payload["transcript_id"] == proposal.transcript_id
    cap_events = lineage.for_subject(CTX_A, proposal.capture_id)
    tr_events = lineage.for_subject(CTX_A, proposal.transcript_id)
    assert cap_events and tr_events
