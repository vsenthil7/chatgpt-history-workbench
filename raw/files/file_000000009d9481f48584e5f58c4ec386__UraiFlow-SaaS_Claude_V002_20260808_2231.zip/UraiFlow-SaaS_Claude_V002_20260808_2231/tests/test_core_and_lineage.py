"""RTM: SaaS-002, SLICE-006 — tenant context, ids, clock, lineage store."""
from datetime import datetime, timedelta, timezone

import pytest

from uraiflow.core.clock import FixedClock, SystemClock
from uraiflow.core.errors import TenantIsolationError
from uraiflow.core.ids import new_id
from uraiflow.core.tenancy import TenantContext, require_same_tenant
from uraiflow.lineage.model import LineageEvent
from uraiflow.lineage.store import LineageStore

T0 = datetime(2026, 8, 8, 12, 0, tzinfo=timezone.utc)
CTX_A = TenantContext(tenant_id="tenant-a", actor_id="user-1")
CTX_B = TenantContext(tenant_id="tenant-b", actor_id="user-2")


def _event(tenant: str, subject: str, kind: str = "test.kind") -> LineageEvent:
    return LineageEvent(
        event_id=new_id("evt"),
        tenant_id=tenant,
        subject_id=subject,
        kind=kind,
        payload={"k": "v"},
        occurred_at=T0,
    )


def test_tenant_context_requires_tenant_id():
    with pytest.raises(ValueError):
        TenantContext(tenant_id="  ", actor_id="user-1")


def test_tenant_context_requires_actor_id():
    with pytest.raises(ValueError):
        TenantContext(tenant_id="tenant-a", actor_id="")


def test_require_same_tenant_allows_match():
    require_same_tenant(CTX_A, "tenant-a", "thing")  # no raise


def test_require_same_tenant_denies_mismatch():
    with pytest.raises(TenantIsolationError):
        require_same_tenant(CTX_A, "tenant-b", "thing")


def test_new_id_prefix_and_uniqueness():
    a, b = new_id("cap"), new_id("cap")
    assert a.startswith("cap-") and b.startswith("cap-") and a != b


def test_fixed_clock_is_deterministic_and_ticks():
    clock = FixedClock(T0)
    assert clock.now() == T0
    assert clock.tick(5) == T0 + timedelta(seconds=5)
    assert clock.now() == T0 + timedelta(seconds=5)


def test_system_clock_returns_aware_utc():
    now = SystemClock().now()
    assert now.tzinfo is timezone.utc


def test_lineage_append_and_read_scoped_to_tenant():
    store = LineageStore()
    e1 = store.append(CTX_A, _event("tenant-a", "subj-1"))
    store.append(CTX_B, _event("tenant-b", "subj-1"))
    assert store.for_subject(CTX_A, "subj-1") == (e1,)
    assert [e.tenant_id for e in store.all_for_tenant(CTX_B)] == ["tenant-b"]


def test_lineage_append_denies_cross_tenant_event():
    store = LineageStore()
    with pytest.raises(TenantIsolationError):
        store.append(CTX_A, _event("tenant-b", "subj-1"))
    assert store.all_for_tenant(CTX_B) == ()
