"""RTM: SLICE-003 — rule-based extraction and the ADR-0001 proposal state machine."""
import pytest

from uraiflow.core.errors import InvalidTransitionError
from uraiflow.extraction.extractor import RuleBasedExtractor
from uraiflow.proposal.model import (
    ItemDecision,
    Proposal,
    ProposalItem,
    ProposalStatus,
)

SAMPLE = (
    "I spoke to the auditor for twenty minutes, follow up on Monday, "
    "and tomorrow I am available ten to one."
)


def test_extractor_finds_all_three_record_types_in_sample():
    records = RuleBasedExtractor().extract(SAMPLE)
    types = sorted(r.record_type for r in records)
    assert types == ["availability", "follow_up", "time_entry"]


def test_extractor_time_entry_fields():
    records = RuleBasedExtractor().extract("I spoke to Priya for 15 minutes.")
    (rec,) = records
    assert rec.record_type == "time_entry"
    assert rec.fields == {"contact": "Priya", "minutes": 15}
    assert rec.confidence >= 0.9
    assert "Priya" in rec.source_text


def test_extractor_spelled_number_minutes():
    (rec,) = RuleBasedExtractor().extract("spoke to Sam for twenty minutes")
    assert rec.fields["minutes"] == 20


def test_extractor_skips_time_entry_when_minutes_unresolvable():
    records = RuleBasedExtractor().extract("spoke to Sam for seven minutes")
    assert all(r.record_type != "time_entry" for r in records)


def test_extractor_returns_empty_for_unrelated_text():
    assert RuleBasedExtractor().extract("the weather is nice") == ()


def _proposal(n_items: int = 2) -> Proposal:
    items = [
        ProposalItem(
            record_id=f"rec-{i}",
            record_type="time_entry",
            fields={"contact": "A", "minutes": 5},
            confidence=0.9,
            source_text="s",
        )
        for i in range(n_items)
    ]
    return Proposal(
        proposal_id="prop-1",
        tenant_id="tenant-a",
        capture_id="cap-1",
        transcript_id="tr-1",
        items=items,
    )


def test_proposal_happy_path_transitions():
    p = _proposal()
    assert p.status is ProposalStatus.PROPOSED
    for status in (
        ProposalStatus.ROUTED,
        ProposalStatus.VALIDATED,
        ProposalStatus.AWAITING_CONFIRMATION,
        ProposalStatus.CONFIRMED,
        ProposalStatus.COMMITTING,
        ProposalStatus.COMMITTED,
    ):
        p.advance(status)
    assert p.status is ProposalStatus.COMMITTED


def test_proposal_failure_and_rollback_path():
    p = _proposal()
    for status in (
        ProposalStatus.ROUTED,
        ProposalStatus.VALIDATED,
        ProposalStatus.AWAITING_CONFIRMATION,
        ProposalStatus.PARTIALLY_CONFIRMED,
        ProposalStatus.COMMITTING,
        ProposalStatus.COMMIT_FAILED,
        ProposalStatus.ROLLED_BACK,
    ):
        p.advance(status)
    assert p.status is ProposalStatus.ROLLED_BACK


def test_proposal_needs_clarification_is_terminal():
    p = _proposal()
    p.advance(ProposalStatus.ROUTED)
    p.advance(ProposalStatus.NEEDS_CLARIFICATION)
    with pytest.raises(InvalidTransitionError):
        p.advance(ProposalStatus.VALIDATED)


def test_proposal_rejects_invalid_transition():
    p = _proposal()
    with pytest.raises(InvalidTransitionError):
        p.advance(ProposalStatus.COMMITTED)


def test_item_decisions_and_confirmed_items():
    p = _proposal(3)
    p.decide("rec-0", ItemDecision.CONFIRMED)
    p.decide("rec-1", ItemDecision.REJECTED)
    assert [i.record_id for i in p.confirmed_items()] == ["rec-0"]
    assert p.items[2].decision is ItemDecision.PENDING


def test_decide_unknown_item_raises():
    p = _proposal(1)
    with pytest.raises(KeyError):
        p.decide("rec-404", ItemDecision.CONFIRMED)


def test_edit_item_replaces_fields():
    p = _proposal(1)
    p.edit_item("rec-0", {"contact": "B", "minutes": 30})
    assert p.items[0].fields == {"contact": "B", "minutes": 30}


def test_edit_unknown_item_raises():
    p = _proposal(1)
    with pytest.raises(KeyError):
        p.edit_item("rec-404", {"x": 1})
