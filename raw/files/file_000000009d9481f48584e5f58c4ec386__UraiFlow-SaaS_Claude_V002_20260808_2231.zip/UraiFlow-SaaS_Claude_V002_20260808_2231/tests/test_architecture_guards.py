"""RTM: ARC-001, ARC-002, SaaS-001 — machine-enforced architecture and
tenant-neutrality guards over the reusable source tree."""
import ast
import re
from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "src" / "uraiflow"

# Layering: module -> uraiflow sub-packages it may import from (besides itself).
ALLOWED_IMPORTS = {
    "core": set(),
    "lineage": {"core"},
    "capture": {"core", "lineage"},
    "transcription": {"core", "lineage", "capture"},  # downstream of capture
    "extraction": {"core"},
    "proposal": {"core", "extraction"},
    "confirmation": {"core", "lineage", "proposal"},
    "routing": {"core", "adapters"},
    "adapters": {"core", "extraction"},
    "pipeline": {
        "core",
        "lineage",
        "capture",
        "transcription",
        "extraction",
        "proposal",
        "routing",
        "adapters",
    },
}

FORBIDDEN_TENANT_TOKENS = re.compile(r"ipbs|cgwo", re.IGNORECASE)


def _modules():
    for path in sorted(SRC.rglob("*.py")):
        top = path.relative_to(SRC).parts[0]
        if top.endswith(".py"):
            top = "core"  # package __init__ at root counts as neutral
        yield top, path


def _uraiflow_imports(path: Path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            parts = node.module.split(".")
            if parts[0] == "uraiflow" and len(parts) > 1:
                yield parts[1]
        elif isinstance(node, ast.Import):
            for alias in node.names:
                parts = alias.name.split(".")
                if parts[0] == "uraiflow" and len(parts) > 1:
                    yield parts[1]


def test_source_tree_exists_and_is_nonempty():
    assert SRC.is_dir()
    assert any(SRC.rglob("*.py"))


def test_dependency_direction_respects_declared_layering():
    violations = []
    for top, path in _modules():
        allowed = ALLOWED_IMPORTS.get(top, set()) | {top}
        for target in _uraiflow_imports(path):
            if target not in allowed:
                violations.append(f"{path.relative_to(SRC)}: {top} -> {target}")
    assert violations == [], f"forbidden imports: {violations}"


def test_no_customer_or_sibling_product_tokens_in_reusable_source():
    offenders = [
        str(path.relative_to(SRC))
        for _, path in _modules()
        if FORBIDDEN_TENANT_TOKENS.search(path.read_text(encoding="utf-8"))
    ]
    assert offenders == [], f"tenant/product leakage in: {offenders}"


def test_no_hardcoded_tenant_identifiers_in_source():
    pattern = re.compile(r"tenant_id\s*=\s*[\"'](?!\s*[\"'])")
    offenders = []
    for _, path in _modules():
        for line in path.read_text(encoding="utf-8").splitlines():
            if pattern.search(line) and "self." not in line.split("=")[0]:
                offenders.append(f"{path.relative_to(SRC)}: {line.strip()}")
    assert offenders == [], f"hard-coded tenant ids: {offenders}"


def test_no_third_party_runtime_dependencies_in_domain_source():
    stdlib_ok = {
        "dataclasses", "datetime", "enum", "re", "typing", "uuid",
        "collections", "abc", "__future__",
    }
    offenders = []
    for _, path in _modules():
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            names = []
            if isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module.split(".")[0]]
            elif isinstance(node, ast.Import):
                names = [a.name.split(".")[0] for a in node.names]
            for name in names:
                if name != "uraiflow" and name not in stdlib_ok:
                    offenders.append(f"{path.relative_to(SRC)}: {name}")
    assert offenders == [], f"non-stdlib runtime imports: {offenders}"
