"""Immutable lineage/audit events — the cross-aggregate evidence chain."""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Mapping


@dataclass(frozen=True)
class LineageEvent:
    """One append-only fact about a subject, scoped to a tenant."""

    event_id: str
    tenant_id: str
    subject_id: str
    kind: str
    payload: Mapping[str, Any]
    occurred_at: datetime
    parent_event_id: str | None = field(default=None)
