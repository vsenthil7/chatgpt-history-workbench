"""Proposal aggregate and state machine (ADR-0001)."""
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping

from uraiflow.core.errors import InvalidTransitionError
from uraiflow.extraction.model import CandidateRecord


class ProposalStatus(Enum):
    PROPOSED = "PROPOSED"
    ROUTED = "ROUTED"
    VALIDATED = "VALIDATED"
    NEEDS_CLARIFICATION = "NEEDS_CLARIFICATION"
    AWAITING_CONFIRMATION = "AWAITING_CONFIRMATION"
    CONFIRMED = "CONFIRMED"
    PARTIALLY_CONFIRMED = "PARTIALLY_CONFIRMED"
    REJECTED = "REJECTED"
    COMMITTING = "COMMITTING"
    COMMITTED = "COMMITTED"
    COMMIT_FAILED = "COMMIT_FAILED"
    ROLLED_BACK = "ROLLED_BACK"


_TRANSITIONS: dict[ProposalStatus, frozenset[ProposalStatus]] = {
    ProposalStatus.PROPOSED: frozenset({ProposalStatus.ROUTED}),
    ProposalStatus.ROUTED: frozenset(
        {ProposalStatus.VALIDATED, ProposalStatus.NEEDS_CLARIFICATION}
    ),
    ProposalStatus.VALIDATED: frozenset({ProposalStatus.AWAITING_CONFIRMATION}),
    ProposalStatus.NEEDS_CLARIFICATION: frozenset(),
    ProposalStatus.AWAITING_CONFIRMATION: frozenset(
        {
            ProposalStatus.CONFIRMED,
            ProposalStatus.PARTIALLY_CONFIRMED,
            ProposalStatus.REJECTED,
        }
    ),
    ProposalStatus.CONFIRMED: frozenset({ProposalStatus.COMMITTING}),
    ProposalStatus.PARTIALLY_CONFIRMED: frozenset({ProposalStatus.COMMITTING}),
    ProposalStatus.REJECTED: frozenset(),
    ProposalStatus.COMMITTING: frozenset(
        {ProposalStatus.COMMITTED, ProposalStatus.COMMIT_FAILED}
    ),
    ProposalStatus.COMMITTED: frozenset(),
    ProposalStatus.COMMIT_FAILED: frozenset({ProposalStatus.ROLLED_BACK}),
    ProposalStatus.ROLLED_BACK: frozenset(),
}


class ItemDecision(Enum):
    PENDING = "PENDING"
    CONFIRMED = "CONFIRMED"
    REJECTED = "REJECTED"


@dataclass
class ProposalItem:
    """One candidate record inside a proposal plus its human decision state."""

    record_id: str
    record_type: str
    fields: dict[str, Any]
    confidence: float
    source_text: str
    decision: ItemDecision = field(default=ItemDecision.PENDING)
    validation_errors: tuple[str, ...] = field(default=())

    @classmethod
    def from_candidate(cls, candidate: CandidateRecord) -> "ProposalItem":
        return cls(
            record_id=candidate.record_id,
            record_type=candidate.record_type,
            fields=dict(candidate.fields),
            confidence=candidate.confidence,
            source_text=candidate.source_text,
        )

    def as_candidate(self) -> CandidateRecord:
        return CandidateRecord(
            record_id=self.record_id,
            record_type=self.record_type,
            fields=dict(self.fields),
            confidence=self.confidence,
            source_text=self.source_text,
        )


@dataclass
class Proposal:
    """The reviewable unit UraiFlow offers to the human before any commit."""

    proposal_id: str
    tenant_id: str
    capture_id: str
    transcript_id: str
    items: list[ProposalItem]
    status: ProposalStatus = field(default=ProposalStatus.PROPOSED)

    def advance(self, to: ProposalStatus) -> None:
        if to not in _TRANSITIONS[self.status]:
            raise InvalidTransitionError(
                f"proposal {self.proposal_id}: {self.status.value} -> {to.value} not allowed"
            )
        self.status = to

    def _item(self, record_id: str) -> ProposalItem:
        for item in self.items:
            if item.record_id == record_id:
                return item
        raise KeyError(f"proposal {self.proposal_id} has no item '{record_id}'")

    def decide(self, record_id: str, decision: ItemDecision) -> None:
        self._item(record_id).decision = decision

    def edit_item(self, record_id: str, fields: Mapping[str, Any]) -> None:
        self._item(record_id).fields = dict(fields)

    def confirmed_items(self) -> tuple[ProposalItem, ...]:
        return tuple(i for i in self.items if i.decision is ItemDecision.CONFIRMED)
