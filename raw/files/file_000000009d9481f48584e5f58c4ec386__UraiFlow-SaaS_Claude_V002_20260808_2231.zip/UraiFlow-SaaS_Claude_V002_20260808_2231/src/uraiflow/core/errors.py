"""Domain error taxonomy shared across UraiFlow modules."""


class UraiFlowError(Exception):
    """Base class for all UraiFlow domain errors."""


class TenantIsolationError(UraiFlowError):
    """An operation attempted to cross a tenant boundary."""


class InvalidTransitionError(UraiFlowError):
    """A state machine transition was not permitted."""


class RoutingError(UraiFlowError):
    """No (or ambiguous) route/provider exists for a request."""


class AdapterContractError(UraiFlowError):
    """A target-system adapter was used outside its declared contract."""


class CommitError(UraiFlowError):
    """A target-system commit failed at the adapter."""
