"""Per-tenant provider selection policy — tenant configuration as data, not code."""
from typing import Mapping

from uraiflow.core.errors import RoutingError
from uraiflow.core.tenancy import TenantContext
from uraiflow.transcription.provider import TranscriptionProvider


class ProviderSelector:
    """Selects a provider per tenant from configuration; never branches on a tenant."""

    def __init__(
        self,
        providers: Mapping[str, TranscriptionProvider],
        tenant_policy: Mapping[str, str],
        default_provider: str,
    ) -> None:
        self._providers = dict(providers)
        self._tenant_policy = dict(tenant_policy)
        self._default = default_provider

    def select(self, ctx: TenantContext) -> TranscriptionProvider:
        name = self._tenant_policy.get(ctx.tenant_id, self._default)
        if name not in self._providers:
            raise RoutingError(f"no transcription provider registered as '{name}'")
        return self._providers[name]
