"""Target-system adapter contract (baseline doc 51, formalised; ADR-0002).

Each adapter declares accepted record types, schema version, required fields,
idempotency behaviour and rollback capability. Receiving domains own business
validation and final commit semantics; UraiFlow only speaks this contract.
"""
from dataclasses import dataclass
from typing import Any, Mapping, Protocol

from uraiflow.core.tenancy import TenantContext
from uraiflow.extraction.model import CandidateRecord


@dataclass(frozen=True)
class AdapterDescriptor:
    """Machine-readable declaration of an adapter's contract surface."""

    name: str
    schema_version: str
    accepted_record_types: tuple[str, ...]
    required_fields: Mapping[str, tuple[str, ...]]
    supports_rollback: bool


@dataclass(frozen=True)
class ValidationResult:
    ok: bool
    errors: tuple[str, ...]


@dataclass(frozen=True)
class CommitReceipt:
    """Evidence of a committed record in the target system."""

    receipt_id: str
    adapter_name: str
    tenant_id: str
    record_id: str
    idempotency_key: str
    target_ref: str


class TargetSystemAdapter(Protocol):
    """Contract every target-system integration must satisfy."""

    def descriptor(self) -> AdapterDescriptor:  # pragma: no cover - protocol signature
        ...

    def validate(self, record: CandidateRecord) -> ValidationResult:  # pragma: no cover - protocol signature
        ...

    def preview(self, ctx: TenantContext, record: CandidateRecord) -> Mapping[str, Any]:  # pragma: no cover - protocol signature
        ...

    def commit(
        self, ctx: TenantContext, record: CandidateRecord, idempotency_key: str
    ) -> CommitReceipt:  # pragma: no cover - protocol signature
        ...

    def rollback(self, ctx: TenantContext, receipt: CommitReceipt) -> None:  # pragma: no cover - protocol signature
        ...


def standard_validate(
    descriptor: AdapterDescriptor, record: CandidateRecord
) -> ValidationResult:
    """Contract-level validation: accepted type + required fields present/non-empty.

    Domain/business validation beyond this belongs to the receiving system.
    """
    if record.record_type not in descriptor.accepted_record_types:
        return ValidationResult(
            ok=False,
            errors=(
                f"record type '{record.record_type}' not accepted by "
                f"adapter '{descriptor.name}'",
            ),
        )
    errors: list[str] = []
    for field_name in descriptor.required_fields[record.record_type]:
        value = record.fields.get(field_name)
        if value is None or value == "":
            errors.append(
                f"required field '{field_name}' missing/empty for "
                f"record type '{record.record_type}'"
            )
    return ValidationResult(ok=not errors, errors=tuple(errors))


def assert_adapter_contract(adapter: TargetSystemAdapter) -> None:
    """Compliance harness usable against any adapter implementation."""
    descriptor = adapter.descriptor()
    assert descriptor.name.strip(), "adapter must declare a name"
    assert descriptor.schema_version.strip(), "adapter must declare a schema version"
    assert descriptor.accepted_record_types, "adapter must accept at least one type"
    for record_type in descriptor.accepted_record_types:
        assert record_type in descriptor.required_fields, (
            f"required_fields must cover accepted type '{record_type}'"
        )
