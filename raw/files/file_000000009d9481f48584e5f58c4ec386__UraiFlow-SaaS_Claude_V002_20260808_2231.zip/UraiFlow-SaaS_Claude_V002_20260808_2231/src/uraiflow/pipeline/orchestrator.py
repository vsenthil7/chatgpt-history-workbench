"""Vertical-slice orchestrator: capture -> transcript -> proposal -> commit.

UraiFlow proposes; confirmation is human; commit goes through adapter contracts
with compensation on partial failure. Full lineage at every step.
"""
from dataclasses import dataclass
from typing import Any, Mapping

from uraiflow.adapters.contract import CommitReceipt
from uraiflow.capture.service import CaptureService
from uraiflow.core.clock import Clock
from uraiflow.core.errors import CommitError, InvalidTransitionError, UraiFlowError
from uraiflow.core.ids import new_id
from uraiflow.core.tenancy import TenantContext, require_same_tenant
from uraiflow.extraction.extractor import Extractor
from uraiflow.lineage.model import LineageEvent
from uraiflow.lineage.store import LineageStore
from uraiflow.proposal.model import Proposal, ProposalItem, ProposalStatus
from uraiflow.routing.registry import AdapterRegistry
from uraiflow.transcription.selector import ProviderSelector
from uraiflow.transcription.service import TranscriptionService


@dataclass(frozen=True)
class CommitOutcome:
    """Result of an atomic commit attempt across adapters."""

    receipts: tuple[CommitReceipt, ...]
    failure: str | None


class ConversationToActionPipeline:
    """Wires the first production-grade slice behind one orchestration surface."""

    def __init__(
        self,
        selector: ProviderSelector,
        extractor: Extractor,
        registry: AdapterRegistry,
        lineage: LineageStore,
        clock: Clock,
    ) -> None:
        self.clock = clock
        self._lineage = lineage
        self._capture = CaptureService(lineage=lineage, clock=clock)
        self._transcription = TranscriptionService(
            selector=selector, lineage=lineage, clock=clock
        )
        self._extractor = extractor
        self._registry = registry

    # -- ingest: capture -> transcript -> extraction -> routed/validated proposal --

    def ingest(self, ctx: TenantContext, source_ref: str, content: str) -> Proposal:
        capture = self._capture.capture(ctx, source_ref=source_ref, content=content)
        transcript = self._transcription.transcribe(ctx, capture)
        candidates = self._extractor.extract(transcript.text)
        proposal = Proposal(
            proposal_id=new_id("prop"),
            tenant_id=ctx.tenant_id,
            capture_id=capture.capture_id,
            transcript_id=transcript.transcript_id,
            items=[ProposalItem.from_candidate(c) for c in candidates],
        )
        self._event(
            ctx,
            proposal,
            "proposal.created",
            {
                "capture_id": capture.capture_id,
                "transcript_id": transcript.transcript_id,
                "item_count": len(proposal.items),
            },
        )
        proposal.advance(ProposalStatus.ROUTED)
        if not proposal.items:
            proposal.advance(ProposalStatus.NEEDS_CLARIFICATION)
            self._event(
                ctx, proposal, "proposal.needs_clarification", {"reason": "no candidates"}
            )
            return proposal
        self._event(
            ctx,
            proposal,
            "proposal.routed",
            {"record_types": sorted({i.record_type for i in proposal.items})},
        )
        invalid = 0
        for item in proposal.items:
            adapter = self._registry.resolve(item.record_type)
            result = adapter.validate(item.as_candidate())
            item.validation_errors = result.errors
            if not result.ok:
                invalid += 1
        if invalid:
            proposal.advance(ProposalStatus.NEEDS_CLARIFICATION)
            self._event(
                ctx,
                proposal,
                "proposal.needs_clarification",
                {"reason": "validation errors", "invalid_items": invalid},
            )
            return proposal
        proposal.advance(ProposalStatus.VALIDATED)
        self._event(ctx, proposal, "proposal.validated", {"item_count": len(proposal.items)})
        proposal.advance(ProposalStatus.AWAITING_CONFIRMATION)
        return proposal

    # -- commit: confirmed items -> adapters, atomically with compensation --

    def commit(self, ctx: TenantContext, proposal: Proposal) -> CommitOutcome:
        require_same_tenant(ctx, proposal.tenant_id, "proposal")
        if proposal.status not in (
            ProposalStatus.CONFIRMED,
            ProposalStatus.PARTIALLY_CONFIRMED,
        ):
            raise InvalidTransitionError(
                f"proposal {proposal.proposal_id} is {proposal.status.value}; "
                "only confirmed proposals can be committed"
            )
        proposal.advance(ProposalStatus.COMMITTING)
        committed: list[CommitReceipt] = []
        try:
            for item in proposal.confirmed_items():
                adapter = self._registry.resolve(item.record_type)
                receipt = adapter.commit(
                    ctx,
                    item.as_candidate(),
                    idempotency_key=f"{proposal.proposal_id}:{item.record_id}",
                )
                committed.append(receipt)
                self._event(
                    ctx,
                    proposal,
                    "record.committed",
                    {
                        "record_id": item.record_id,
                        "adapter": receipt.adapter_name,
                        "target_ref": receipt.target_ref,
                    },
                )
        except UraiFlowError as error:
            proposal.advance(ProposalStatus.COMMIT_FAILED)
            self._event(ctx, proposal, "proposal.commit_failed", {"error": str(error)})
            self._compensate(ctx, proposal, committed)
            proposal.advance(ProposalStatus.ROLLED_BACK)
            self._event(
                ctx, proposal, "proposal.rolled_back", {"compensated": len(committed)}
            )
            return CommitOutcome(receipts=(), failure=str(error))
        proposal.advance(ProposalStatus.COMMITTED)
        self._event(ctx, proposal, "proposal.committed", {"receipts": len(committed)})
        return CommitOutcome(receipts=tuple(committed), failure=None)

    def _compensate(
        self, ctx: TenantContext, proposal: Proposal, receipts: list[CommitReceipt]
    ) -> None:
        for receipt in reversed(receipts):
            adapter = self._registry.resolve_by_name(receipt.adapter_name)
            adapter.rollback(ctx, receipt)
            self._event(
                ctx,
                proposal,
                "record.rolled_back",
                {"record_id": receipt.record_id, "adapter": receipt.adapter_name},
            )

    def _event(
        self,
        ctx: TenantContext,
        proposal: Proposal,
        kind: str,
        payload: Mapping[str, Any],
    ) -> None:
        self._lineage.append(
            ctx,
            LineageEvent(
                event_id=new_id("evt"),
                tenant_id=ctx.tenant_id,
                subject_id=proposal.proposal_id,
                kind=kind,
                payload=payload,
                occurred_at=self.clock.now(),
            ),
        )
