"""Deterministic rule-based extractor for the first slice.

LLM-backed extractors are later provider adapters behind the same protocol.
"""
import re
from typing import Protocol

from uraiflow.core.ids import new_id
from uraiflow.extraction.model import CandidateRecord

_SPELLED = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "ten": 10,
    "fifteen": 15, "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50,
    "sixty": 60, "ninety": 90,
}
_TIME_RE = re.compile(
    r"spoke to (?:the )?(?P<contact>[A-Za-z]+) for (?P<minutes>\w+) minutes",
    re.IGNORECASE,
)


class Extractor(Protocol):
    """Contract for extraction implementations."""

    def extract(self, text: str) -> tuple[CandidateRecord, ...]:  # pragma: no cover - protocol signature
        ...


class RuleBasedExtractor:
    """Small deterministic rules sufficient for the slice's acceptance sample."""

    def extract(self, text: str) -> tuple[CandidateRecord, ...]:
        records: list[CandidateRecord] = []
        match = _TIME_RE.search(text)
        if match:
            raw = match.group("minutes").lower()
            minutes = int(raw) if raw.isdigit() else _SPELLED.get(raw)
            if minutes is not None:
                records.append(
                    CandidateRecord(
                        record_id=new_id("rec"),
                        record_type="time_entry",
                        fields={
                            "contact": match.group("contact").capitalize(),
                            "minutes": minutes,
                        },
                        confidence=0.92,
                        source_text=match.group(0),
                    )
                )
        lowered = text.lower()
        if "follow up" in lowered:
            records.append(
                CandidateRecord(
                    record_id=new_id("rec"),
                    record_type="follow_up",
                    fields={"note": text.strip()},
                    confidence=0.75,
                    source_text=text.strip(),
                )
            )
        if "available" in lowered:
            records.append(
                CandidateRecord(
                    record_id=new_id("rec"),
                    record_type="availability",
                    fields={"window": text.strip()},
                    confidence=0.70,
                    source_text=text.strip(),
                )
            )
        return tuple(records)
