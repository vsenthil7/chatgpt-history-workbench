"""Human confirmation: confirm all/selected, edit, reject — never auto-commit."""
from typing import Any, Iterable, Mapping

from uraiflow.core.clock import Clock
from uraiflow.core.ids import new_id
from uraiflow.core.tenancy import TenantContext, require_same_tenant
from uraiflow.lineage.model import LineageEvent
from uraiflow.lineage.store import LineageStore
from uraiflow.proposal.model import ItemDecision, Proposal, ProposalStatus


class ConfirmationService:
    """Applies human decisions to a proposal and finalises its confirmation state."""

    def __init__(self, lineage: LineageStore, clock: Clock) -> None:
        self._lineage = lineage
        self._clock = clock

    def confirm_all(self, ctx: TenantContext, proposal: Proposal) -> None:
        require_same_tenant(ctx, proposal.tenant_id, "proposal")
        for item in proposal.items:
            item.decision = ItemDecision.CONFIRMED
        self._finalize(ctx, proposal)

    def confirm_selected(
        self, ctx: TenantContext, proposal: Proposal, record_ids: Iterable[str]
    ) -> None:
        require_same_tenant(ctx, proposal.tenant_id, "proposal")
        selected = set(record_ids)
        for item in proposal.items:
            item.decision = (
                ItemDecision.CONFIRMED
                if item.record_id in selected
                else ItemDecision.REJECTED
            )
        self._finalize(ctx, proposal)

    def reject_all(self, ctx: TenantContext, proposal: Proposal) -> None:
        require_same_tenant(ctx, proposal.tenant_id, "proposal")
        for item in proposal.items:
            item.decision = ItemDecision.REJECTED
        self._finalize(ctx, proposal)

    def edit(
        self,
        ctx: TenantContext,
        proposal: Proposal,
        record_id: str,
        fields: Mapping[str, Any],
    ) -> None:
        require_same_tenant(ctx, proposal.tenant_id, "proposal")
        proposal.edit_item(record_id, fields)
        self._event(ctx, proposal, "proposal.item_edited", {"record_id": record_id})

    def _finalize(self, ctx: TenantContext, proposal: Proposal) -> None:
        confirmed = len(proposal.confirmed_items())
        if confirmed == len(proposal.items):
            target = ProposalStatus.CONFIRMED
        elif confirmed > 0:
            target = ProposalStatus.PARTIALLY_CONFIRMED
        else:
            target = ProposalStatus.REJECTED
        proposal.advance(target)
        self._event(
            ctx,
            proposal,
            f"proposal.{target.value.lower()}",
            {"confirmed": confirmed, "total": len(proposal.items), "actor": ctx.actor_id},
        )

    def _event(
        self, ctx: TenantContext, proposal: Proposal, kind: str, payload: Mapping[str, Any]
    ) -> None:
        self._lineage.append(
            ctx,
            LineageEvent(
                event_id=new_id("evt"),
                tenant_id=ctx.tenant_id,
                subject_id=proposal.proposal_id,
                kind=kind,
                payload=payload,
                occurred_at=self._clock.now(),
            ),
        )
