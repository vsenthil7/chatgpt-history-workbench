# First Build Backlog

## B001 — Baseline acceptance
- Read all starter documents and the complete preserved baseline.
- Inventory contradictions/duplicates/stale names before deleting anything.
- Record architecture decisions rather than silently normalising history.

## B002 — Declare the first implementation slice
Preserve the proposal/confirmation boundary and build the first production-grade vertical slice: input → transcript/provider abstraction → structured proposal → confirmation → adapter contract, with full lineage.

## B003 — Tests first as contracts
Declare RTM rows, contract tests and architecture/tenant guards before implementation. Establish red evidence, then implement to green.

## B004 — Evidence-producing CI
Make test counts, coverage, mutation, package inventory and docs consistency machine-readable so narrative docs do not drift.

## B005 — Review package
Create the next `<Product>_Claude_VNNN_YYYYMMDD_HHMM.zip` with complete source/tests/docs/evidence for independent ChatGPT review.

---

## Status after V002 (Claude build, 2026-08-08)
- **B001 — DONE.** `00-control/B001-BASELINE-ACCEPTANCE.md` (inventory I-01…I-05); nothing deleted from baseline.
- **B002 — DONE.** Slice declared via ADR-0001…0004 + RTM-V002 SLICE-001…007, then implemented in `src/uraiflow/`.
- **B003 — DONE.** Red state recorded (`evidence/B003-red-state.txt`) before implementation; green + coverage evidence in `evidence/B003-green-tests-coverage.txt`.
- **B004 — PARTIAL.** Test/coverage/manifest evidence machine-generated; mutation gate deferred (EX-001); no CI pipeline definition yet.
- **B005 — DONE for V002.** This ZIP is the review package.

## V003 backlog (next)
1. Mutation testing gate (QA-002/G07): wire mutmut or equivalent, set threshold, triage survivors. **← exact next item**
2. NEEDS_CLARIFICATION re-clarification loop (currently terminal per ADR-0001).
3. Persistence adapter behind LineageStore/proposal repository protocols (still in-memory).
4. CI pipeline definition executing gates G01–G11.
5. First real transcription provider adapter behind `TranscriptionProvider` (benchmark plan in baseline doc 34).
