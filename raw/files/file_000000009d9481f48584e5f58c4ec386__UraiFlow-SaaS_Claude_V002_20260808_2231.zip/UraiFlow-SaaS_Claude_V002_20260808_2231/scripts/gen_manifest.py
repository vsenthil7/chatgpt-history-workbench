#!/usr/bin/env python3
"""Generate or verify the authoritative root PACKAGE-MANIFEST.json (ADR-0003).

Usage:
  python3 scripts/gen_manifest.py           # regenerate
  python3 scripts/gen_manifest.py --check   # verify: fail on any drift
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "PACKAGE-MANIFEST.json"
EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".git"}
EXCLUDE_FILES = {".coverage", "G01-manifest-check.txt"}  # check evidence is self-referential


def _files():
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if any(part in EXCLUDE_DIRS for part in rel.parts):
            continue
        if rel.name in EXCLUDE_FILES or rel == Path("PACKAGE-MANIFEST.json"):
            continue
        yield rel, path


def build():
    entries = []
    for rel, path in _files():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        entries.append(
            {"path": rel.as_posix(), "sha256": digest, "bytes": path.stat().st_size}
        )
    return {
        "schema": "uraiflow-package-manifest/2",
        "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "project": "UraiFlow SaaS",
        "product_version": "0.9.0-dev",
        "file_count": len(entries),
        "files": entries,
    }


def main(argv):
    manifest = build()
    if "--check" in argv:
        if not MANIFEST.is_file():
            print("MANIFEST MISSING")
            return 1
        recorded = json.loads(MANIFEST.read_text(encoding="utf-8"))
        drift = [
            (a.get("path"), b.get("path"))
            for a, b in zip(recorded.get("files", []), manifest["files"])
            if a.get("path") != b.get("path") or a.get("sha256") != b.get("sha256")
        ]
        extra = abs(len(recorded.get("files", [])) - len(manifest["files"]))
        if drift or extra:
            print(f"MANIFEST DRIFT: {len(drift)} changed, {extra} added/removed")
            for a, b in drift[:20]:
                print(f" - {a} != {b}")
            return 1
        print(f"manifest check: PASS ({manifest['file_count']} files)")
        return 0
    MANIFEST.write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
    print(f"manifest written: {manifest['file_count']} files")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
