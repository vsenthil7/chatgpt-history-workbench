# ORVIA website

One-page launch site for ORVIA: *Turn chaos into flow.*

Plain HTML, CSS and JavaScript. No framework, no build step, no dependencies to install.

## Folder structure

```
orvia-website/
├── index.html        All page content (10 sections, in order)
├── css/
│   └── styles.css    All styles; colours and fonts are tokens at the top (:root)
├── js/
│   └── main.js       Mobile menu, footer year, placeholder form handling
├── assets/
│   └── logo.svg      PLACEHOLDER logo mark (replace with the official logo)
└── README.md
```

## Run locally

Any static server works. Pick one:

```bash
# Python (already on most machines)
cd orvia-website
python3 -m http.server 8080
# open http://localhost:8080

# or Node
npx serve .
```

You can also double-click `index.html`, which works in most browsers.

**Dependencies:** none to install. The page loads three Google Fonts (Sora, Instrument Sans, IBM Plex Mono) over the internet. It falls back to system fonts if they can't load.

## Deploy

Upload the folder as-is to any static host: Netlify, Vercel, Cloudflare Pages, GitHub Pages, Azure Static Web Apps or S3.

## Placeholders to replace before launch

Search the code for `PLACEHOLDER` to find each one.

| Item | Where | What to do |
|---|---|---|
| Logo | `assets/logo.svg` | Replace the file with the official logo (keep the name, or update the 3 `<img src>` paths in `index.html`). If your logo includes the wordmark, delete the `<span>ORVIA</span>` next to the header and footer `<img>`. |
| Contact form | `index.html` (`#review-form`), `js/main.js` | Not connected. See below. |
| Contact email | Footer in `index.html` | Replace `[Contact email to be added]` with a real address, e.g. `<a href="mailto:you@domain">you@domain</a>`. |
| Privacy policy / Terms | Footer in `index.html` | Point the two `href="#"` links at real pages, then remove `data-placeholder` and the "(placeholder)" label. |
| Copyright name | Footer in `index.html` | Change "ORVIA" to the registered legal entity if required. |
| Social preview | `<head>` in `index.html` | Add `og:url` and `og:image` once the domain and image exist. |
| Placeholder note | Under the form | Delete the `<p class="placeholder-note">` once the form is connected. |

## Connecting the contact form

The form validates input but sends nothing. Choose one option:

**Option A: form service (simplest).** Create a form at Formspree, Basin or similar, then edit the `<form>` tag:

```html
<form class="form-card" id="review-form" action="https://formspree.io/f/YOUR_ID" method="POST">
```

Remove `data-placeholder="true"` and `novalidate` so the placeholder JS handler stops intercepting it.

**Option B: booking tool.** Replace the whole `<form>…</form>` block with your scheduler's embed or a button linking to your booking page (Calendly, Cal.com, Microsoft Bookings).

**Option C: Netlify.** Add `name="workflow-review" data-netlify="true"` to the `<form>` and remove `data-placeholder`.

## Changing colours or fonts

Edit the tokens at the top of `css/styles.css`:

- `--ink`, `--btn-bg`, `--band-bg`: navy
- `--teal`, `--teal-soft`: accent
- `--bg`, `--surface`: backgrounds
- `--font-display`, `--font-body`, `--font-mono`: typefaces (update the Google Fonts link in `index.html` to match)

Dark-mode values are in the two blocks directly below `:root`.

## Content rules followed

- No customers, testimonials, statistics, logos, certifications or savings figures are claimed.
- The hero workflow record and the use-case flows are labelled as illustrative examples.
- No address, phone number, email or social accounts are invented.

## Quality notes

- Semantic landmarks (`header`, `nav`, `main`, `section`, `footer`), one `h1`, ordered headings
- Skip link, keyboard-operable menu (Escape closes it), visible focus rings
- Respects `prefers-reduced-motion` and `prefers-color-scheme`
- Responsive from 320px phones to wide desktops
