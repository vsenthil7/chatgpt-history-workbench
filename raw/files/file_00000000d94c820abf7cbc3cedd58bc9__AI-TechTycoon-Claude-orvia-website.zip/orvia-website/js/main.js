/* ORVIA — small progressive enhancements. The page works without this file. */
(function () {
  "use strict";

  // ---- Mobile navigation ----
  var toggle = document.querySelector(".nav-toggle");
  var menu = document.getElementById("nav-menu");

  function setMenu(open) {
    if (!toggle || !menu) return;
    menu.classList.toggle("is-open", open);
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    var use = toggle.querySelector("use");
    if (use) use.setAttribute("href", open ? "#i-close" : "#i-menu");
  }

  if (toggle && menu) {
    toggle.addEventListener("click", function () {
      setMenu(toggle.getAttribute("aria-expanded") !== "true");
    });
    menu.addEventListener("click", function (e) {
      if (e.target.closest("a")) setMenu(false);
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && toggle.getAttribute("aria-expanded") === "true") {
        setMenu(false);
        toggle.focus();
      }
    });
  }

  // ---- Footer year ----
  var year = document.getElementById("year");
  if (year) year.textContent = String(new Date().getFullYear());

  // ---- Contact form (PLACEHOLDER) ----
  // Not connected to any service. See README.md > "Connecting the contact form".
  var form = document.getElementById("review-form");
  var status = document.getElementById("form-status");

  if (form && form.dataset.placeholder === "true") {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!form.checkValidity()) {
        var firstInvalid = form.querySelector(":invalid");
        status.textContent = "Please fill in your name, business name and a valid email address.";
        status.hidden = false;
        if (firstInvalid) firstInvalid.focus();
        return;
      }
      status.textContent =
        "Thanks. This form isn't connected yet, so nothing was sent. " +
        "Once a contact method is set up, requests will go straight to the ORVIA team.";
      status.hidden = false;
    });
  }

  // ---- Placeholder legal links ----
  document.querySelectorAll('a[data-placeholder]').forEach(function (a) {
    a.addEventListener("click", function (e) { e.preventDefault(); });
  });
})();
