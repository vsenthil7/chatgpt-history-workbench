# Portfolio guard kit

Four self-contained modules, no dependencies and no imports between them, that catch
classes of defect which passed review in DocMerge Pro and are very likely present in the
sibling products. Drop them in, wire the tests into CI, and fix what they find.

They exist because of a specific, repeated pattern: **DocMerge sat at 100% test coverage
across two clean internal review passes, and a verification sweep then found six findings
in six checks — three of them live-blocking.** Coverage proved every unit executed. It
could not prove the units were wired together, that callers were entitled to what they
asked for, or that the platform would honour what we promised.

## What each module catches

### `tenantGate.ts` — authorisation, not authentication

Scans source for methods that accept an entity id and act on it with **no tenant
parameter**. Configure the tenant parameter names and id suffixes for your product.

Caught in DocMerge (all of it after a clean review):

| Finding | What it was |
| --- | --- |
| DM-F16 | Template lookups took a `templateId` and nothing else, and the HTTP route read that id **from the request body** — so any authenticated user could render another tenant's template. |
| DM-F17 | Same shape on signature requests, exposing signer names and emails. |
| DM-F21 | `pause`/`resume` on requests, triggers and jobs took only an entity id — one tenant could halt another's work with a guessed id. |

The distinction worth internalising: **session authentication establishes *who* is asking.
Nothing in it establishes *what they may ask for*.** Having the first made the second look
done.

The gate also supports **exemptions with reasons** and a meta-gate,
`unverifiedExemptions()`, that fails the build when an exemption is added without a test
naming it. That matters: in DocMerge one exemption was *right about its outcome and wrong
about its reason* (DM-F22), which is the version that survives a security review
unchallenged.

### `ledger.ts` — unbounded growth

A FIFO-bounded append store that **counts evictions rather than dropping silently**.
DocMerge had eleven append-only arrays — telemetry, audit entries, captured errors,
invoices, surveys. Each is fine on day one and each ends with a process dying at an
inconvenient hour.

One subtlety worth copying: if a **hash-chained** audit log is bounded, the chain can no
longer verify from genesis. The digest of the last evicted entry becomes the anchor, and
verification reports truncation rather than failing — an audit log that silently forgot
entries would be worse than one that admits it.

### `purge.ts` — deletion that actually deletes

A registry enumerating every store holding account data, with `verifyRegistration()`
failing the build when a known store has no purge target. Receipts carry **per-store row
counts** as evidence, and a partial purge is reported as **incomplete** rather than
claimed as success.

DocMerge's `executeDue(deleter)` took a callback that no production code supplied — the
published 30-day deletion policy had nothing behind it. Memory shows this exact defect
breached the published policy in five sibling products, which is why it is in this kit.

Pair it with `ON DELETE CASCADE` in the schema, so completeness is a property of the
database rather than of code someone must remember to update.

### `platformQuotas.ts` — promises the platform will not keep

Records verified quotas **with their sources**, refuses to guess an unrecorded one, and
fails when an internal promise exceeds an external limit. `QuotaGovernor` paces per
account and gives an honest completion estimate.

In DocMerge the Docs API allows **60 writes per minute per user**, while the SLO promised
a document every 1500ms and the load test drove 100/min and reported PASS — because it
drove an injected worker and never touched the ceiling. A 500-row batch for one customer
cannot finish in under eight minutes, a fact absent from every estimate written before the
check.

**The mechanism ports; the numbers do not.** Pass your platform's verified table:

```ts
const zohoQuotas = [
  { api: 'crm', operation: 'write', perMinutePerUser: 10, perMinutePerProject: 100, source: 'Zoho API limits' },
];
checkFeasibility([{ name: 'Bulk sync', api: 'crm', operation: 'write', impliedPerMinutePerUser: 50 }], zohoQuotas);
```

## Wiring it in

1. Copy `src/*.ts` into the product. They have no imports, so nothing else comes with them.
2. Copy `tests/tenantGate.test.ts` and point `repoSources()` at that product's `src`.
3. Add to CI as its own step so a failure is legible:

```yaml
- run: npx jest tests/tenantGate.test.ts
```

4. Run it once and **triage before exempting**. In DocMerge the first run flagged 28
   methods: five clusters were genuine, the rest legitimately scoped by construction.
   Exempting without triage converts the gate into decoration.

## The honest limits

- `tenantGate` is a **source-text check, not a type check**. Unusual formatting can fool
  it. It is a net for the common shape, not a proof.
- A passing gate means the shape is absent, not that authorisation is correct. It finds
  the mistake nobody meant to make, not a deliberate mistake.
- The quota numbers in `platformQuotas.ts` were verified on 13 September 2026 against
  Google's published limits. **Re-verify before launch** — Google republishes them, and
  the whole point of the module is not trusting a remembered figure.
