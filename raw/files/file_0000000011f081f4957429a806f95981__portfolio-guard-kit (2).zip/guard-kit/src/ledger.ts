/**
 * Bounded ledger (cold-review fix DM-F08).
 *
 * The review found eleven append-only arrays — telemetry samples, audit entries,
 * captured errors, invoices, surveys, incidents — that only ever grew. Every one is
 * fine in a test that pushes five records and fine on day one; each is a slow leak
 * that ends in a process dying at whatever hour it happens to fill memory.
 *
 * Eviction is counted rather than silent. A metric that quietly started sampling only
 * the recent past would misreport trends without anyone noticing, and an audit log
 * that silently forgot entries would be worse than one that admits it.
 */

export interface LedgerStats {
  size: number;
  capacity: number;
  /** How many records have been dropped to stay inside the cap. */
  evicted: number;
}

export class Ledger<T> {
  private readonly items: T[] = [];
  private evictedCount = 0;

  constructor(public readonly capacity: number) {
    if (!Number.isInteger(capacity) || capacity < 1) {
      throw new Error('Ledger capacity must be a positive whole number');
    }
  }

  /** Appends, evicting the oldest record when full. Returns the evicted record, if any. */
  push(item: T): T | undefined {
    this.items.push(item);
    if (this.items.length > this.capacity) {
      this.evictedCount += 1;
      return this.items.shift();
    }
    return undefined;
  }

  /** Read-only view, oldest first. */
  all(): readonly T[] {
    return this.items;
  }

  filter(predicate: (item: T) => boolean): T[] {
    return this.items.filter(predicate);
  }

  get size(): number {
    return this.items.length;
  }

  get evicted(): number {
    return this.evictedCount;
  }

  /** True once anything has been dropped — callers should caveat any total derived from this. */
  get isTruncated(): boolean {
    return this.evictedCount > 0;
  }

  stats(): LedgerStats {
    return { size: this.items.length, capacity: this.capacity, evicted: this.evictedCount };
  }

  last(): T | undefined {
    return this.items[this.items.length - 1];
  }

  clear(): void {
    this.items.length = 0;
  }
}

/** Default caps. Telemetry is sampled generously; audit is kept longer because it is evidence. */
export const LEDGER_CAPACITY = {
  telemetry: 50_000,
  audit: 100_000,
  errors: 10_000,
  documents: 10_000,
} as const;
