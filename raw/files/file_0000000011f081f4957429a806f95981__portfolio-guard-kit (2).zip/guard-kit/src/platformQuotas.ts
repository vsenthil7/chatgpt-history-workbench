/**
 * Platform quotas (verification finding VER-DM6).
 *
 * VERIFIED against live Google documentation, 13 Sep 2026. The Docs API allows 60 write
 * requests per minute per user per project, and 600 per minute across the project. Our
 * ST-087 p95 budget promises a generated document every 1500ms and the ST-088 load test
 * drives 100 requests per minute at a single surface and reports PASS.
 *
 * Both are promises the platform will not honour. One user cannot exceed one document
 * per second however fast our code is; past 60 in a minute they receive 429s and our own
 * backoff makes the p95 worse, not better. The load test was measuring an injected worker,
 * so it never touched the ceiling it was supposed to prove we could reach.
 *
 * This module holds the verified numbers and a feasibility check that fails the build
 * when an internal target exceeds an external quota — so an SLO cannot quietly promise
 * something the platform forbids.
 */

export interface PlatformQuota {
  api: string;
  operation: 'read' | 'write';
  perMinutePerUser: number;
  perMinutePerProject: number;
  source: string;
  /**
   * Set when the published figure is not stable — for example an API mid-migration
   * between quota models. A quota we cannot rely on is worse than one we know is tight,
   * because it invites planning against a number that may not apply to our project.
   */
  caveat?: string;
}

/** Verified 13 Sep 2026. Re-check before launch; Google republishes these. */
export const PLATFORM_QUOTAS: PlatformQuota[] = [
  {
    api: 'docs',
    operation: 'write',
    perMinutePerUser: 60,
    perMinutePerProject: 600,
    source: 'Docs API usage limits',
  },
  {
    api: 'docs',
    operation: 'read',
    perMinutePerUser: 300,
    perMinutePerProject: 3000,
    source: 'Docs API usage limits',
  },
  {
    /**
     * VER-DM7: Drive is mid-transition between two quota models. One published page gives
     * 12,000 queries per 60 seconds per user; another describes a quota-unit model
     * (1,000,000 units per minute per project, 325,000 per user); and projects that used
     * the API before May 2026 reportedly retain legacy request counts until the rollout
     * completes. The conservative published figure is recorded, with the ambiguity
     * attached rather than resolved by picking whichever number suits us.
     *
     * The practical conclusion is the useful part: on any of these models Drive is FAR
     * above the Docs ceiling of 60 writes per minute per user, so filing is not the
     * binding constraint on a batch — document creation is. A test asserts that, so a
     * future quota change which reverses it surfaces rather than silently slowing runs.
     */
    api: 'drive',
    operation: 'write',
    perMinutePerUser: 12_000,
    perMinutePerProject: 12_000,
    source: 'Drive API usage limits',
    caveat:
      'Drive is migrating to a quota-unit model; legacy projects keep request counts. Re-verify for the actual project before relying on this.',
  },
  {
    api: 'sheets',
    operation: 'read',
    perMinutePerUser: 60,
    perMinutePerProject: 300,
    source: 'Sheets API usage limits',
  },
];

/** Apps Script limits that bound the form forwarder shipped for VER-DM2. */
export const APPS_SCRIPT_LIMITS = {
  urlFetchPerDayConsumer: 20_000,
  urlFetchPerDayWorkspace: 100_000,
} as const;

/**
 * The MECHANISM here is portable across products; the NUMBERS are not. A sibling on
 * Zoho, Xero or Stripe passes its own verified table rather than inheriting Google's.
 */
export function quotaFor(
  api: string,
  operation: 'read' | 'write',
  quotas: PlatformQuota[] = PLATFORM_QUOTAS
): PlatformQuota {
  const quota = quotas.find((q) => q.api === api && q.operation === operation);
  if (quota === undefined) {
    throw new Error(`No verified quota recorded for ${api} ${operation} — check before assuming one`);
  }
  return quota;
}

export interface Promise_ {
  /** What we tell customers or assert in a test. */
  name: string;
  api: string;
  operation: 'read' | 'write';
  /** Operations per minute the promise implies, for one user. */
  impliedPerMinutePerUser: number;
}

export interface FeasibilityFinding {
  promise: string;
  implied: number;
  allowed: number;
  message: string;
}

/**
 * Fails when an internal promise implies more throughput than the platform permits.
 * Deliberately compares against the PER-USER quota: a batch belongs to one customer, and
 * the project-wide ceiling does not help a single user going too fast.
 */
export function checkFeasibility(
  promises: Promise_[],
  quotas: PlatformQuota[] = PLATFORM_QUOTAS
): { ok: boolean; findings: FeasibilityFinding[] } {
  const findings: FeasibilityFinding[] = [];
  for (const p of promises) {
    const quota = quotaFor(p.api, p.operation, quotas);
    if (p.impliedPerMinutePerUser > quota.perMinutePerUser) {
      findings.push({
        promise: p.name,
        implied: p.impliedPerMinutePerUser,
        allowed: quota.perMinutePerUser,
        message:
          `${p.name} implies ${p.impliedPerMinutePerUser} ${p.api} ${p.operation}s per minute for one user, ` +
          `but the platform allows ${quota.perMinutePerUser}. The promise cannot be kept.`,
      });
    }
  }
  return { ok: findings.length === 0, findings };
}

/**
 * Paces work to stay inside a per-user quota. Being throttled by Google costs a round
 * trip and a backoff; pacing ourselves costs only the wait, and keeps the customer's
 * remaining quota available for their other tools.
 */
export class QuotaGovernor {
  private readonly timestamps = new Map<string, number[]>();

  constructor(
    private readonly perMinutePerUser: number,
    private readonly now: () => number = Date.now
  ) {}

  /** Milliseconds to wait before the next operation for this user; 0 when clear. */
  delayFor(accountId: string): number {
    const nowTs = this.now();
    const windowStart = nowTs - 60_000;
    const recent = (this.timestamps.get(accountId) ?? []).filter((t) => t > windowStart);
    this.timestamps.set(accountId, recent);
    if (recent.length < this.perMinutePerUser) {
      return 0;
    }
    // The oldest call in the window frees a slot 60s after it happened.
    return Math.max(0, recent[0] + 60_000 - nowTs);
  }

  /** Record an operation against the user's budget. */
  record(accountId: string): void {
    const list = this.timestamps.get(accountId) ?? [];
    list.push(this.now());
    this.timestamps.set(accountId, list);
  }

  usedInWindow(accountId: string): number {
    const windowStart = this.now() - 60_000;
    return (this.timestamps.get(accountId) ?? []).filter((t) => t > windowStart).length;
  }

  /** Honest completion estimate for a batch of a given size, in milliseconds. */
  estimateCompletionMs(rows: number): number {
    if (rows <= this.perMinutePerUser) {
      return 0;
    }
    const fullMinutes = Math.floor((rows - 1) / this.perMinutePerUser);
    return fullMinutes * 60_000;
  }
}


/**
 * Which API throttles a batch first. Generation touches Docs (write), Sheets (read) and
 * Drive (write) per row, so the slowest per-user ceiling governs the whole run.
 */
export function bindingConstraint(quotas: PlatformQuota[] = PLATFORM_QUOTAS): PlatformQuota {
  return quotas.reduce((tightest, q) => (q.perMinutePerUser < tightest.perMinutePerUser ? q : tightest));
}

/** Quotas whose published value we cannot currently rely on. */
export function unstableQuotas(quotas: PlatformQuota[] = PLATFORM_QUOTAS): PlatformQuota[] {
  return quotas.filter((q) => q.caveat !== undefined);
}
