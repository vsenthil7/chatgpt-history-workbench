/**
 * Tenant-isolation gate (portable CI check).
 *
 * DM-F15 was found by accident and DM-F16 by a sweep that followed it. Both are the
 * same mistake: a method that accepts an entity id and acts on it without establishing
 * that the caller owns that entity. Authentication answers who is asking; this answers
 * what they may ask for, and having the first made the second look done.
 *
 * A sweep finds them once. This finds them every commit, and it is deliberately written
 * to be copied into the sibling products — the pattern is identical across all of them,
 * so the rule is configured rather than hard-coded.
 *
 * It is a source-text check, not a type check. That means it can be fooled by unusual
 * formatting, which is stated rather than hidden: it is a net for the common shape, not
 * a proof. Exemptions must carry a reason, so the list stays readable rather than
 * becoming a place to make findings disappear.
 */

export interface TenantGateConfig {
  /** Parameter names that identify a tenant. */
  tenantParams: string[];
  /** Parameter-name suffixes that identify an entity a tenant can own. */
  entityIdSuffixes: string[];
  /** Methods exempt from the rule, each with a reason. */
  exemptions: Array<{ method: string; reason: string }>;
}

export const DEFAULT_TENANT_GATE: TenantGateConfig = {
  tenantParams: ['accountId', 'tenantId', 'account'],
  entityIdSuffixes: ['templateId', 'requestId', 'jobId', 'triggerId', 'conversationId', 'invoiceId', 'sessionId'],
  exemptions: [
    { method: 'SandboxMode.get', reason: 'Sandbox sessions exist before any account does — there is no tenant to scope to.' },
    { method: 'SandboxMode.generate', reason: 'Same: pre-account demo session.' },
    { method: 'SandboxMode.convertToSignup', reason: 'Same: pre-account demo session.' },
    { method: 'PurgeRegistry.purgeAccount', reason: 'Takes the account id itself as its subject.' },
    { method: 'StatusPage.update', reason: 'Incidents are operator-owned and deliberately global.' },
    { method: 'BatchGenerator.createJobWithDefaults', reason: 'Takes accountId as its first parameter already.' },
    // Repository layer: keyed lookups by design. Ownership is enforced one level up in
    // TemplateDesigner.mustGet, which every caller goes through. Verified by the
    // cross-tenant tests in templates.test.ts rather than assumed.
    { method: 'MemoryTemplateRepo.get', reason: 'Repository primitive; ownership enforced in TemplateDesigner.mustGet.' },
    { method: 'PostgresTemplateRepo.get', reason: 'Repository primitive; ownership enforced in TemplateDesigner.mustGet.' },
    { method: 'default.get', reason: 'TemplateRepo interface declaration, not an implementation.' },
    // Generic keyed utility. Callers pass account-namespaced keys (see DM-F21); the
    // utility itself has no concept of a tenant and should not acquire one.
    // Reason CORRECTED after auditing it (DM-F22): the original claim that callers passed
    // account-namespaced keys was false for e-sign and batch, which passed bare ids.
    // Callers now go through pauseKey(entity, accountId, entityId), which is enforced by test.
    { method: 'PauseManager.pause', reason: 'Generic keyed utility; all callers key via pauseKey(entity, accountId, id) — asserted by test.' },
    { method: 'PauseManager.resume', reason: 'Generic keyed utility; all callers key via pauseKey(entity, accountId, id) — asserted by test.' },
    { method: 'PauseManager.isPaused', reason: 'Generic keyed utility; all callers key via pauseKey(entity, accountId, id) — asserted by test.' },
    { method: 'PauseManager.assertActive', reason: 'Generic keyed utility; all callers key via pauseKey(entity, accountId, id) — asserted by test.' },
    // Signers are external parties with no account of their own; the request's signer
    // list is the authorisation check, and requiring an accountId would be meaningless.
    { method: 'EsignService.sign', reason: 'Signers are external parties with no account; the signer list authorises.' },
    { method: 'EsignService.decline', reason: 'Signers are external parties with no account; the signer list authorises.' },
    { method: 'EsignService.mustGet', reason: 'Private helper that performs the ownership check itself.' },
    // Controllers hold the account in their constructor and pass it to the domain call
    // that enforces ownership; the id alone never reaches a store.
    { method: 'SidebarController.openTemplate', reason: 'Controller holds accountId and checks template ownership before opening — asserted by test.' },
    { method: 'BatchSidebarController.configure', reason: 'Controller holds accountId; the run path enforces ownership.' },
    { method: 'FormSidebarController.connect', reason: 'Controller holds accountId; the submission path enforces ownership.' },
    // Per-entity metrics. Entity ids are account-scoped upstream; whether the SUMMARIES
    // should be per-account is DM-F19, an open product decision rather than a defect.
    { method: 'BatchMetrics.record', reason: 'Per-entity metric; account scoping of summaries is DM-F19, pending decision.' },
    { method: 'BatchMetrics.summary', reason: 'Per-entity metric; account scoping of summaries is DM-F19, pending decision.' },
    { method: 'TemplateMetrics.record', reason: 'Per-entity metric; account scoping of summaries is DM-F19, pending decision.' },
    { method: 'TemplateMetrics.summary', reason: 'Per-entity metric; account scoping of summaries is DM-F19, pending decision.' },
    // Operator-facing support queue. Scoping it per customer is DM-F20, pending decision.
    { method: 'SupportInbox.respond', reason: 'Operator-facing queue; per-customer scoping is DM-F20, pending decision.' },
    { method: 'SupportInbox.status', reason: 'Operator-facing queue; per-customer scoping is DM-F20, pending decision.' },
  ],
};

export interface TenantViolation {
  file: string;
  method: string;
  entityParam: string;
  line: number;
  message: string;
}

/**
 * An exemption is a claim that a protection exists somewhere else. DM-F22 showed that
 * such a claim can be wrong while sounding right, so each one must name the test that
 * verifies it — and the gate fails if any does not.
 */
export function unverifiedExemptions(
  config: TenantGateConfig,
  testSource: string
): Array<{ method: string; reason: string }> {
  return config.exemptions.filter((e) => {
    const [, method] = e.method.split('.');
    // The claim is verified if the test file mentions the method or its owning class.
    const owner = e.method.split('.')[0];
    return !testSource.includes(e.method) && !testSource.includes(owner) && !testSource.includes(method);
  });
}

export interface TenantGateResult {
  ok: boolean;
  violations: TenantViolation[];
  checkedMethods: number;
  exempted: string[];
}

/** Matches `name(args) {` / `async name(args): Type {` at a method-ish indentation. */
const METHOD_RE = /^\s{2,6}(?:public\s+|private\s+|protected\s+)?(?:async\s+)?([a-zA-Z_][\w]*)\s*\(([^)]*)\)/;

/**
 * Scans source text for methods that take an entity id without a tenant parameter.
 * `sources` maps a file name to its contents, so this runs against the repository in a
 * test with no file-system assumptions baked in.
 */
export function checkTenantIsolation(
  sources: Record<string, string>,
  config: TenantGateConfig = DEFAULT_TENANT_GATE
): TenantGateResult {
  const violations: TenantViolation[] = [];
  const exemptSet = new Set(config.exemptions.map((e) => e.method));
  let checkedMethods = 0;

  for (const [file, text] of Object.entries(sources)) {
    const lines = text.split('\n');
    let currentClass = 'default';
    lines.forEach((line, index) => {
      const classMatch = /^export\s+(?:abstract\s+)?class\s+([A-Za-z_]\w*)/.exec(line);
      if (classMatch) {
        currentClass = classMatch[1];
        return;
      }
      const match = METHOD_RE.exec(line);
      if (!match) {
        return;
      }
      const [, name, rawParams] = match;
      if (name === 'constructor' || name === 'if' || name === 'for' || name === 'while' || name === 'switch' || name === 'catch') {
        return;
      }
      const params = rawParams
        .split(',')
        .map((p) => p.trim().split(':')[0].replace(/^\.\.\./, '').trim())
        .filter((p) => p !== '');
      const entityParam = params.find((p) => config.entityIdSuffixes.includes(p));
      if (entityParam === undefined) {
        return;
      }
      checkedMethods += 1;
      const qualified = `${currentClass}.${name}`;
      if (exemptSet.has(qualified)) {
        return;
      }
      const hasTenant = params.some((p) => config.tenantParams.includes(p));
      if (!hasTenant) {
        violations.push({
          file,
          method: qualified,
          entityParam,
          line: index + 1,
          message:
            `${qualified} takes '${entityParam}' without a tenant parameter — it can act on another ` +
            `account's record. Add an accountId and check ownership, or exempt it with a reason.`,
        });
      }
    });
  }

  return {
    ok: violations.length === 0,
    violations,
    checkedMethods,
    exempted: [...exemptSet].sort(),
  };
}

/** Human-readable report for CI output. */
export function renderTenantGateReport(result: TenantGateResult): string {
  if (result.ok) {
    return `Tenant isolation: PASS — ${result.checkedMethods} entity-id methods checked, ${result.exempted.length} exempted.`;
  }
  const lines = [
    `Tenant isolation: FAIL — ${result.violations.length} method(s) act on an entity id with no tenant scope.`,
    '',
  ];
  for (const v of result.violations) {
    lines.push(`  ${v.file}:${v.line}  ${v.message}`);
  }
  return lines.join('\n');
}
