# Triaging the first run

The first run against a mature codebase will flag more than you expect. DocMerge flagged
28 methods; five clusters were genuine and the rest were legitimately scoped. Working
through them took about an hour and produced two real defects nobody had noticed.

Ask these in order.

**1. Can a caller reach this method with an id they did not obtain legitimately?**
If the id arrives in a request body, a URL, or a webhook payload — yes. Those are the
dangerous ones. DM-F16 was exactly this: the HTTP route took a `templateId` from the body.

**2. Is the protection real, or does it merely exist somewhere nearby?**
A repository primitive is fine *if* every caller goes through a layer that checks
ownership. Verify that claim by listing the callers — do not assume it. In DocMerge one
caller had been bypassing the check.

**3. Does the exemption reason describe what is actually true?**
DM-F22 was an exemption that was right about its outcome and wrong about its reason: it
claimed callers passed namespaced keys, and two did not. The protection came from
somewhere else entirely. A reason that sounds plausible survives review indefinitely.

**4. Is this a defect or a product decision?**
Metrics that aggregate across tenants are a defect if surfaced per-customer and correct if
internal. Log those as open decisions rather than fixing them blind — and add a test
asserting they are not currently reachable from any route, which is what keeps the
decision a decision.

**5. Control operations count.**
The manual sweep that preceded the gate checked reads and missed `pause`/`resume`. Halting
another tenant's work is a denial of service that needs nothing but a guessed id.

## What to do with the output

- Fix anything reachable from an external input first.
- Namespace keyed utilities centrally rather than at each call site, so a new caller
  cannot forget.
- Report cross-tenant access as **not found**, not as **forbidden** — otherwise the id
  space can be probed for what exists.
- Write the exemption, then write the test that proves it, then move on.
