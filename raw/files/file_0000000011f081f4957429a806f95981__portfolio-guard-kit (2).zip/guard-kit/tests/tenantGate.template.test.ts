/**
 * Tenant-isolation gate — TEMPLATE.
 *
 * Copy into the product's tests folder, rename to tenantGate.test.ts, and adjust the
 * config for that product's naming. Deliberately free of product-specific imports: the
 * version this was extracted from was full of DocMerge's own modules and would not have
 * compiled anywhere else.
 *
 * Add a `describe` block per exemption verifying its CLAIM. The meta-gate below fails if
 * an exemption is added without one — which is the part that keeps the list honest.
 */
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import {
  TenantGateConfig,
  checkTenantIsolation,
  renderTenantGateReport,
  unverifiedExemptions,
} from '../src/tenantGate';

/** Per-product configuration. Start here. */
const CONFIG: TenantGateConfig = {
  tenantParams: ['accountId', 'tenantId', 'orgId'],
  entityIdSuffixes: ['templateId', 'requestId', 'jobId', 'recordId', 'invoiceId'],
  exemptions: [
    // { method: 'Class.method', reason: 'Why this is safe — and add a test below proving it.' },
  ],
};

function repoSources(): Record<string, string> {
  const dir = join(__dirname, '..', 'src');
  const out: Record<string, string> = {};
  for (const file of readdirSync(dir).filter((f) => f.endsWith('.ts'))) {
    out[file] = readFileSync(join(dir, file), 'utf8');
  }
  return out;
}

describe('Tenant isolation', () => {
  it('no method acts on an entity id without a tenant scope', () => {
    const result = checkTenantIsolation(repoSources(), CONFIG);
    if (!result.ok) {
      // eslint-disable-next-line no-console
      console.error(renderTenantGateReport(result));
    }
    expect(result.violations).toEqual([]);
  });

  it('inspects a meaningful number of methods rather than passing vacuously', () => {
    // Guards against a config whose suffixes match nothing in this product.
    expect(checkTenantIsolation(repoSources(), CONFIG).checkedMethods).toBeGreaterThan(0);
  });

  it('every exemption carries a reason', () => {
    for (const exemption of CONFIG.exemptions) {
      expect(exemption.reason.length).toBeGreaterThan(25);
    }
  });

  it('no exemption exists without a test in this file verifying its claim', () => {
    const testSource = readFileSync(join(__dirname, __filename.split('/').pop() as string), 'utf8');
    expect(unverifiedExemptions(CONFIG, testSource).map((e) => e.method)).toEqual([]);
  });
});
