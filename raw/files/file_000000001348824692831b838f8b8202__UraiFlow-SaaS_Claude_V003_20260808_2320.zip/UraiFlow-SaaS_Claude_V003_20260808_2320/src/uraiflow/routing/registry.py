"""Record-type -> adapter routing table (baseline doc 49, step 8 of the pipeline)."""
from uraiflow.adapters.contract import TargetSystemAdapter, validate_descriptor
from uraiflow.core.errors import RoutingError


class AdapterRegistry:
    """Maps record types to exactly one owning target-system adapter."""

    def __init__(self) -> None:
        self._routes: dict[str, TargetSystemAdapter] = {}

    def register(self, adapter: TargetSystemAdapter) -> None:
        descriptor = adapter.descriptor()
        validate_descriptor(descriptor)
        for record_type in descriptor.accepted_record_types:
            if record_type in self._routes:
                raise RoutingError(
                    f"record type '{record_type}' already routed to "
                    f"'{self._routes[record_type].descriptor().name}'"
                )
            self._routes[record_type] = adapter

    def resolve(self, record_type: str) -> TargetSystemAdapter:
        if record_type not in self._routes:
            raise RoutingError(f"no adapter accepts record type '{record_type}'")
        return self._routes[record_type]

    def resolve_by_name(self, adapter_name: str) -> TargetSystemAdapter:
        for adapter in self._routes.values():
            if adapter.descriptor().name == adapter_name:
                return adapter
        raise RoutingError(f"no registered adapter named '{adapter_name}'")
