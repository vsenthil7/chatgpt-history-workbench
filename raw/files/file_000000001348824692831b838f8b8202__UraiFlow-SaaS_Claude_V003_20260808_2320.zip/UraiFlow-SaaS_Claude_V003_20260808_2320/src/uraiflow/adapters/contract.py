"""Target-system adapter contract (baseline doc 51, formalised; ADR-0002).

Each adapter declares accepted record types, schema version, required fields,
idempotency behaviour and rollback capability. Receiving domains own business
validation and final commit semantics; UraiFlow only speaks this contract.
"""
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Protocol

from uraiflow.core.errors import AdapterContractError
from uraiflow.core.tenancy import TenantContext
from uraiflow.extraction.model import CandidateRecord


@dataclass(frozen=True)
class AdapterDescriptor:
    """Machine-readable declaration of an adapter's contract surface."""

    name: str
    schema_version: str
    accepted_record_types: tuple[str, ...]
    required_fields: Mapping[str, tuple[str, ...]]
    supports_rollback: bool


@dataclass(frozen=True)
class ValidationResult:
    ok: bool
    errors: tuple[str, ...]


@dataclass(frozen=True)
class CommitReceipt:
    """Evidence of a committed record in the target system."""

    receipt_id: str
    adapter_name: str
    tenant_id: str
    record_id: str
    idempotency_key: str
    target_ref: str


class TargetSystemAdapter(Protocol):
    """Contract every target-system integration must satisfy."""

    def descriptor(self) -> AdapterDescriptor:  # pragma: no cover - protocol signature
        ...

    def validate(self, record: CandidateRecord) -> ValidationResult:  # pragma: no cover - protocol signature
        ...

    def preview(self, ctx: TenantContext, record: CandidateRecord) -> Mapping[str, Any]:  # pragma: no cover - protocol signature
        ...

    def commit(
        self, ctx: TenantContext, record: CandidateRecord, idempotency_key: str
    ) -> CommitReceipt:  # pragma: no cover - protocol signature
        ...

    def rollback(self, ctx: TenantContext, receipt: CommitReceipt) -> None:  # pragma: no cover - protocol signature
        ...


def standard_validate(
    descriptor: AdapterDescriptor, record: CandidateRecord
) -> ValidationResult:
    """Contract-level validation: accepted type + required fields present/non-empty.

    Domain/business validation beyond this belongs to the receiving system.
    """
    if record.record_type not in descriptor.accepted_record_types:
        return ValidationResult(
            ok=False,
            errors=(
                (
                    f"record type '{record.record_type}' not accepted by "
                    f"adapter '{descriptor.name}'"
                ),
            ),
        )
    errors: list[str] = []
    for field_name in descriptor.required_fields[record.record_type]:
        value = record.fields.get(field_name)
        if value is None or value == "":
            errors.append(
                f"required field '{field_name}' missing/empty for "
                f"record type '{record.record_type}'"
            )
    return ValidationResult(ok=not errors, errors=tuple(errors))


def validate_descriptor(descriptor: AdapterDescriptor) -> None:
    """Descriptor invariants enforced at the runtime registration boundary
    (ADR-0007 §4) and by the compliance harness."""
    if not descriptor.name.strip():
        raise AdapterContractError("adapter must declare a name")
    if not descriptor.schema_version.strip():
        raise AdapterContractError(
            f"adapter '{descriptor.name}' must declare a schema version"
        )
    if not descriptor.accepted_record_types:
        raise AdapterContractError(
            f"adapter '{descriptor.name}' must accept at least one record type"
        )
    for record_type in descriptor.accepted_record_types:
        if record_type not in descriptor.required_fields:
            raise AdapterContractError(
                f"adapter '{descriptor.name}': required_fields must cover "
                f"accepted type '{record_type}'"
            )


def assert_adapter_contract(adapter: TargetSystemAdapter) -> None:
    """Compliance harness usable against any adapter implementation."""
    validate_descriptor(adapter.descriptor())
