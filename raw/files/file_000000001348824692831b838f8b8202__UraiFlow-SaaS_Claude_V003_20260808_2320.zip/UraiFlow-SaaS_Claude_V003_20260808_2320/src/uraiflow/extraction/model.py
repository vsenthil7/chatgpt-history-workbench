"""Candidate records: UraiFlow's generic proposal payload (ADR-0002)."""
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class CandidateRecord:
    """A domain-neutral candidate record extracted from a transcript.

    ``record_type`` is an opaque string; UraiFlow ships no domain taxonomy.
    """

    record_id: str
    record_type: str
    fields: Mapping[str, Any]
    confidence: float
    source_text: str
