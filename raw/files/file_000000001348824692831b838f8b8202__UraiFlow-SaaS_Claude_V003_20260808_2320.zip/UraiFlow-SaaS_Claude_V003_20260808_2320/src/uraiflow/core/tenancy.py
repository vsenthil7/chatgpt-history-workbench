"""Explicit tenant/organisation context for protected operations (SaaS-002)."""
from dataclasses import dataclass

from uraiflow.core.errors import TenantIsolationError


@dataclass(frozen=True)
class TenantContext:
    """Identifies the tenant and acting principal for a protected operation."""

    tenant_id: str
    actor_id: str

    def __post_init__(self) -> None:
        if not self.tenant_id.strip():
            raise ValueError("tenant_id must be a non-empty identifier")
        if not self.actor_id.strip():
            raise ValueError("actor_id must be a non-empty identifier")


def require_same_tenant(ctx: TenantContext, tenant_id: str, subject: str) -> None:
    """Deny any cross-tenant access to *subject* (raises TenantIsolationError)."""
    if ctx.tenant_id != tenant_id:
        raise TenantIsolationError(
            f"tenant '{ctx.tenant_id}' may not access {subject} of another tenant"
        )
