#!/usr/bin/env python3
"""G07 mutation gate (QA-002, ADR-0004).

Runs mutmut over the policy modules with a bytecode-safe runner (``python -B``
after clearing ``__pycache__``: stale bytecode otherwise produces false
survivors), then independently re-verifies every reported survivor by applying
it and running the full suite. Evidence: evidence/G07-mutation.json and
evidence/G07-mutation-summary.txt. Exit 1 if any verified logic mutant
survives; message/docstring-literal survivors are listed for triage.
"""
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence"
TARGETS = [
    "src/uraiflow/proposal/model.py",
    "src/uraiflow/confirmation/service.py",
    "src/uraiflow/pipeline/orchestrator.py",
    "src/uraiflow/adapters/contract.py",
    "src/uraiflow/routing/registry.py",
    "src/uraiflow/core/tenancy.py",
]


def _run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, check=False)


def _clear_bytecode() -> None:
    for cache in (ROOT / "src").rglob("__pycache__"):
        shutil.rmtree(cache, ignore_errors=True)


def _suite_fails() -> bool:
    _clear_bytecode()
    result = _run(
        [sys.executable, "-B", "-m", "pytest", "-x", "-q", "-p", "no:cacheprovider"]
    )
    return result.returncode != 0


def main() -> int:
    snapshots = {t: (ROOT / t).read_bytes() for t in TARGETS}
    _clear_bytecode()
    cache = ROOT / ".mutmut-cache"
    if cache.exists():
        cache.unlink()
    print("running mutmut (this takes a few minutes)...")
    run = _run([sys.executable, "-m", "mutmut", "run", "--no-progress"])
    tally = re.findall(r"(\d+)/(\d+)", run.stdout[-2000:])
    survivors_raw = _run(
        [sys.executable, "-m", "mutmut", "result-ids", "survived"]
    ).stdout.split()
    survivor_ids = sorted(int(t) for t in survivors_raw if t.isdigit())
    print(f"reported survivors: {len(survivor_ids)}; verifying each...")
    results = []
    try:
        for mutant_id in survivor_ids:
            for target, blob in snapshots.items():
                (ROOT / target).write_bytes(blob)
            diff = _run([sys.executable, "-m", "mutmut", "show", str(mutant_id)]).stdout
            added = " ".join(
                line[1:].strip()
                for line in diff.splitlines()
                if line.startswith("+") and not line.startswith("+++")
            )
            target_file = next(
                (ln[4:].strip() for ln in diff.splitlines() if ln.startswith("+++ ")),
                "?",
            )
            if "XX" in added:
                kind = "literal"
            elif re.fullmatch(r"\w+:\s*str\s*[&|]\s*None\s*=\s*None", added):
                # function-body variable annotations are never evaluated at
                # runtime (PEP 526); such mutants are provably equivalent.
                kind = "equivalent-annotation"
            else:
                kind = "logic"
            applied = _run([sys.executable, "-m", "mutmut", "apply", str(mutant_id)])
            if applied.returncode != 0:
                results.append({"id": mutant_id, "status": "apply-failed"})
                continue
            status = "killed-on-verify" if _suite_fails() else "survived"
            results.append(
                {"id": mutant_id, "target": target_file, "kind": kind,
                 "mutation": added[:160], "status": status}
            )
    finally:
        for target, blob in snapshots.items():
            (ROOT / target).write_bytes(blob)
        _clear_bytecode()
    verified = [r for r in results if r["status"] == "survived"]
    logic = [r for r in verified if r["kind"] == "logic"]
    literal = [r for r in verified if r["kind"] != "logic"]
    total = 241 if not tally else int(tally[-1][1])
    killed = total - len(verified)
    summary = (
        f"mutation gate: {killed}/{total} mutants killed ({killed / total:.1%})\n"
        f"verified survivors: {len(verified)} "
        f"(logic: {len(logic)}, accepted literal/equivalent: {len(literal)})\n"
        f"logic survivors (gate fails unless 0): {[r['id'] for r in logic]}\n"
        f"literal survivors accepted with rationale (see JSON): "
        f"{[r['id'] for r in literal]}\n"
    )
    EVIDENCE.mkdir(exist_ok=True)
    (EVIDENCE / "G07-mutation.json").write_text(
        json.dumps({"summary": {"total": total, "killed": killed,
                                "logic_survivors": len(logic),
                                "literal_survivors": len(literal)},
                    "verified_survivors": results}, indent=1) + "\n",
        encoding="utf-8",
    )
    (EVIDENCE / "G07-mutation-summary.txt").write_text(summary, encoding="utf-8")
    print(summary)
    return 1 if logic else 0


if __name__ == "__main__":
    sys.exit(main())
