# Release Procedure (ADR-0009)

Order is mandatory; tracked files must not change after step 3.

1. **Gates + evidence:** `python scripts/run_gates.py` (starter validator, tests,
   100% line+branch coverage, ruff, mypy) and `python scripts/run_mutation_gate.py`
   (0 logic survivors; survivors verified and dispositioned). All evidence is
   machine-written to `evidence/`.
2. **Final docs:** RTM/backlog/change-rationale/build-report updated. Narrative docs
   reference evidence files and never embed manifest/test counts by hand.
3. **Manifest:** `python scripts/gen_manifest.py` then
   `python scripts/gen_manifest.py --check` (its own evidence file is excluded from
   manifest scope as self-referential).
4. **Package:** copy the tree (excluding `__pycache__`, `.pytest_cache`,
   `.coverage`, `.mutmut-cache`, egg-info) to
   `UraiFlow-SaaS_Claude_VNNN_YYYYMMDD_HHMM/` (actual Europe/London generation
   timestamp), re-run the manifest check inside the copy, zip.
5. **Extracted-ZIP smoke test (G11):** unzip into a fresh temporary directory,
   create a fresh venv, `pip install -e .[dev]` from the artifact, then run the
   starter validator, manifest check and `python scripts/run_gates.py`. No reliance
   on the builder workspace or inherited environment. Record the result in the
   build report (it is generated after packaging, so it lives in the report, not
   inside the ZIP).
