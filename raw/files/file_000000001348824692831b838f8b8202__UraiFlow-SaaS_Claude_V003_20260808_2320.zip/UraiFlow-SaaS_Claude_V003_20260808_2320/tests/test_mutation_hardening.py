"""RTM: QA-002 — mutation-hardening contracts.

These tests pin behaviour that ordinary flow tests leave unobserved (enum wire
values, dataclass immutability, lineage payload contents, error-message
contracts) so that mutants in policy code cannot survive silently.
"""
from dataclasses import FrozenInstanceError
from datetime import UTC, datetime

import pytest
from fixtures.workforce_rules import REQUIRED_FIELDS, build_extractor

from uraiflow.adapters.contract import AdapterDescriptor, CommitReceipt, ValidationResult
from uraiflow.adapters.inmemory import InMemoryTargetAdapter
from uraiflow.confirmation.service import ConfirmationService
from uraiflow.core.clock import FixedClock
from uraiflow.core.errors import (
    AdapterContractError,
    InvalidTransitionError,
    RevalidationRequiredError,
    TenantIsolationError,
)
from uraiflow.core.tenancy import TenantContext, require_same_tenant
from uraiflow.extraction.model import CandidateRecord
from uraiflow.lineage.model import LineageEvent
from uraiflow.lineage.store import LineageStore
from uraiflow.pipeline.orchestrator import CommitOutcome, ConversationToActionPipeline
from uraiflow.proposal.model import ItemDecision, Proposal, ProposalItem, ProposalStatus
from uraiflow.routing.registry import AdapterRegistry
from uraiflow.transcription.provider import (
    DeterministicEchoProvider,
    TranscriptionRequest,
)
from uraiflow.transcription.selector import ProviderSelector

T0 = datetime(2026, 8, 8, 12, 0, tzinfo=UTC)
CTX_A = TenantContext(tenant_id="tenant-a", actor_id="user-1")
SAMPLE = (
    "I spoke to Auditor for 20 minutes, follow up on Monday, "
    "and tomorrow I am available ten to one."
)


def test_proposal_status_wire_values_match_names():
    for status in ProposalStatus:
        assert status.value == status.name
    assert len({s.value for s in ProposalStatus}) == len(list(ProposalStatus))


def test_item_decision_wire_values_match_names():
    for decision in ItemDecision:
        assert decision.value == decision.name
    assert len({d.value for d in ItemDecision}) == 3


def test_value_objects_are_immutable():
    receipt = CommitReceipt(
        receipt_id="r", adapter_name="a", tenant_id="t",
        record_id="rec", idempotency_key="k", target_ref="x",
    )
    outcome = CommitOutcome(receipts=(receipt,), failure=None)
    event = LineageEvent(
        event_id="e", tenant_id="t", subject_id="s", kind="k",
        payload={}, occurred_at=T0,
    )
    record = CandidateRecord(
        record_id="rec", record_type="t", fields={}, confidence=0.5, source_text="s"
    )
    descriptor = AdapterDescriptor(
        name="a", schema_version="1", accepted_record_types=("t",),
        required_fields={"t": ()}, supports_rollback=True,
    )
    validation = ValidationResult(ok=True, errors=())
    ctx = TenantContext(tenant_id="t", actor_id="u")
    for obj, attr in [
        (receipt, "receipt_id"), (outcome, "failure"), (event, "kind"),
        (record, "record_type"), (descriptor, "name"), (validation, "ok"),
        (ctx, "tenant_id"),
    ]:
        with pytest.raises(FrozenInstanceError):
            setattr(obj, attr, "changed")


def test_default_commit_outcome_has_no_compensation_failures():
    assert CommitOutcome(receipts=(), failure=None).compensation_failures == ()


def test_fixed_clock_tick_default_is_one_second():
    clock = FixedClock(T0)
    clock.tick()
    assert (clock.now() - T0).total_seconds() == 1


def test_echo_provider_reports_high_confidence_and_name():
    result = DeterministicEchoProvider("echo").transcribe(
        TranscriptionRequest(tenant_id="t", capture_id="c", content="x")
    )
    assert result.confidence == 0.99
    assert result.provider_name == "echo"


def test_error_message_contracts():
    with pytest.raises(TenantIsolationError, match="tenant-a.*may not access"):
        require_same_tenant(CTX_A, "tenant-b", "thing")
    registry = AdapterRegistry()
    with pytest.raises(AdapterContractError, match="must declare a name"):
        registry.register(
            InMemoryTargetAdapter(name=" ", schema_version="1", required_fields={"t": ()})
        )
    p = Proposal(
        proposal_id="prop-9", tenant_id="tenant-a", capture_id="c",
        transcript_id="t",
        items=[ProposalItem("rec-0", "t", {}, 0.5, "s")],
    )
    with pytest.raises(InvalidTransitionError, match="PROPOSED -> COMMITTED"):
        p.advance(ProposalStatus.COMMITTED)
    with pytest.raises(InvalidTransitionError, match="confirm_all not allowed.*PROPOSED"):
        p.confirm_all()
    p.status = ProposalStatus.AWAITING_CONFIRMATION
    p.edit_item("rec-0", {"a": 1})
    with pytest.raises(RevalidationRequiredError, match="prop-9.*revalidated"):
        p.confirm_all()


def _pipeline():
    lineage = LineageStore()
    registry = AdapterRegistry()
    registry.register(
        InMemoryTargetAdapter(
            name="target-main", schema_version="1.0", required_fields=dict(REQUIRED_FIELDS)
        )
    )
    pipeline = ConversationToActionPipeline(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={},
            default_provider="echo",
        ),
        extractor=build_extractor(),
        registry=registry,
        lineage=lineage,
        clock=FixedClock(T0),
    )
    return pipeline, lineage


def test_lineage_payload_contents_are_pinned():
    pipeline, lineage = _pipeline()
    confirmation = ConfirmationService(lineage=lineage, clock=pipeline.clock)
    proposal = pipeline.ingest(CTX_A, source_ref="call-p", content=SAMPLE)
    events = {e.kind: e for e in lineage.for_subject(CTX_A, proposal.proposal_id)}
    assert events["proposal.created"].payload["item_count"] == 3
    assert events["proposal.routed"].payload["record_types"] == [
        "availability", "follow_up", "time_entry",
    ]
    assert events["proposal.validated"].payload["item_count"] == 3
    confirmation.confirm_all(CTX_A, proposal)
    confirmed = next(
        e for e in lineage.for_subject(CTX_A, proposal.proposal_id)
        if e.kind == "proposal.confirmed"
    )
    assert confirmed.payload == {"confirmed": 3, "total": 3, "actor": "user-1"}
    outcome = pipeline.commit(CTX_A, proposal)
    events = [e.kind for e in lineage.for_subject(CTX_A, proposal.proposal_id)]
    committed = next(
        e for e in lineage.for_subject(CTX_A, proposal.proposal_id)
        if e.kind == "proposal.committed"
    )
    assert committed.payload == {"receipts": 3}
    assert len(outcome.receipts) == 3
    for receipt in outcome.receipts:
        assert receipt.adapter_name == "target-main"
        assert receipt.target_ref.startswith("target-main/")
        assert receipt.idempotency_key.startswith(f"{proposal.proposal_id}:")
    edit_free = [k for k in events if k == "proposal.item_edited"]
    assert edit_free == []


def test_capture_and_transcript_event_payloads_pinned():
    pipeline, lineage = _pipeline()
    proposal = pipeline.ingest(CTX_A, source_ref="src-77", content=SAMPLE)
    cap_event = lineage.for_subject(CTX_A, proposal.capture_id)[0]
    assert cap_event.kind == "capture.recorded"
    assert cap_event.payload == {"source_ref": "src-77", "media_type": "audio/opus"}
    tr_event = lineage.for_subject(CTX_A, proposal.transcript_id)[0]
    assert tr_event.payload["provider"] == "echo"
    assert tr_event.payload["confidence"] == 0.99


# ---- targeted kills for verified logic survivors of the first G07 run ----

def test_fresh_proposal_needs_no_revalidation():
    p = Proposal(
        proposal_id="p", tenant_id="t", capture_id="c", transcript_id="tr", items=[]
    )
    assert p.needs_revalidation is False  # mutant 45: default None


def test_unknown_item_error_message_names_the_proposal():
    p = Proposal(
        proposal_id="prop-z", tenant_id="t", capture_id="c", transcript_id="tr",
        items=[ProposalItem("rec-0", "t", {}, 0.5, "s")],
    )
    p.status = ProposalStatus.AWAITING_CONFIRMATION
    with pytest.raises(KeyError, match="prop-z has no items"):
        p.confirm_selected(["rec-404"])  # mutant 60: fail-fast list dropped


def test_reject_all_marks_every_item_rejected():
    p = Proposal(
        proposal_id="p", tenant_id="t", capture_id="c", transcript_id="tr",
        items=[ProposalItem(f"rec-{i}", "t", {"a": 1}, 0.5, "s") for i in range(2)],
    )
    p.status = ProposalStatus.AWAITING_CONFIRMATION
    p.reject_all()
    assert [i.decision for i in p.items] == [ItemDecision.REJECTED] * 2  # mutant 71


def test_invalid_item_count_is_exact_in_needs_clarification_payload():
    lineage = LineageStore()
    registry = AdapterRegistry()
    registry.register(
        InMemoryTargetAdapter(
            name="strict", schema_version="1.0",
            required_fields={
                "time_entry": ("contact", "minutes", "project"),   # never extracted
                "follow_up": ("note", "owner"),                    # never extracted
                "availability": ("window",),
            },
        )
    )
    pipeline = ConversationToActionPipeline(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={}, default_provider="echo",
        ),
        extractor=build_extractor(),
        registry=registry,
        lineage=lineage,
        clock=FixedClock(T0),
    )
    proposal = pipeline.ingest(CTX_A, source_ref="s", content=SAMPLE)
    assert proposal.status is ProposalStatus.NEEDS_CLARIFICATION
    event = next(
        e for e in lineage.for_subject(CTX_A, proposal.proposal_id)
        if e.kind == "proposal.needs_clarification"
    )
    assert event.payload["invalid_items"] == 2  # mutants 142/143/144: exact count


def test_preflight_applies_to_exactly_two_records():
    lineage = LineageStore()
    registry = AdapterRegistry()
    no_rb = InMemoryTargetAdapter(
        name="no-rb", schema_version="1.0",
        required_fields={
            "time_entry": REQUIRED_FIELDS["time_entry"],
            "availability": REQUIRED_FIELDS["availability"],
        },
        supports_rollback=False,
    )
    registry.register(no_rb)
    registry.register(
        InMemoryTargetAdapter(
            name="f", schema_version="1.0",
            required_fields={"follow_up": REQUIRED_FIELDS["follow_up"]},
        )
    )
    pipeline = ConversationToActionPipeline(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={}, default_provider="echo",
        ),
        extractor=build_extractor(),
        registry=registry,
        lineage=lineage,
        clock=FixedClock(T0),
    )
    confirmation = ConfirmationService(lineage=lineage, clock=pipeline.clock)
    proposal = pipeline.ingest(
        CTX_A, source_ref="s",
        content="I spoke to Priya for 15 minutes and tomorrow I am available.",
    )
    assert len(proposal.items) == 2
    confirmation.confirm_all(CTX_A, proposal)
    with pytest.raises(AdapterContractError):  # mutant 173: <=1 boundary
        pipeline.commit(CTX_A, proposal)
    assert no_rb.committed_count(CTX_A) == 0


class _RollbackFailingFollow(InMemoryTargetAdapter):
    def rollback(self, ctx, receipt):
        raise ConnectionError("rollback reset")


class _CommitFailingAvail(InMemoryTargetAdapter):
    def commit(self, ctx, record, idempotency_key):
        raise TimeoutError("down")


def test_compensation_attempts_every_rollback_after_a_failure():
    lineage = LineageStore()
    registry = AdapterRegistry()
    main = InMemoryTargetAdapter(
        name="a", schema_version="1.0",
        required_fields={"time_entry": REQUIRED_FIELDS["time_entry"]},
    )
    follow = _RollbackFailingFollow(
        name="b", schema_version="1.0",
        required_fields={"follow_up": REQUIRED_FIELDS["follow_up"]},
    )
    avail = _CommitFailingAvail(
        name="c", schema_version="1.0",
        required_fields={"availability": REQUIRED_FIELDS["availability"]},
    )
    for adapter in (main, follow, avail):
        registry.register(adapter)
    pipeline = ConversationToActionPipeline(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={}, default_provider="echo",
        ),
        extractor=build_extractor(),
        registry=registry,
        lineage=lineage,
        clock=FixedClock(T0),
    )
    confirmation = ConfirmationService(lineage=lineage, clock=pipeline.clock)
    proposal = pipeline.ingest(CTX_A, source_ref="s", content=SAMPLE)
    confirmation.confirm_all(CTX_A, proposal)
    outcome = pipeline.commit(CTX_A, proposal)
    # commit order: time_entry(a) ok, follow_up(b) ok, availability(c) fails.
    # compensation reversed: b rollback FAILS, then a MUST still be attempted.
    assert proposal.status is ProposalStatus.COMPENSATION_FAILED
    assert len(outcome.compensation_failures) == 1
    assert main.committed_count(CTX_A) == 0  # mutant 190: break would strand this
    assert follow.committed_count(CTX_A) == 1
