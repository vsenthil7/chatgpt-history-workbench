"""The converter has already hidden a whole backlog once. These tests are why it will not again."""
import json, os, subprocess, sys, tempfile, unittest
from openpyxl import Workbook

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPT = os.path.join(HERE, '..', 'bin', 'workbook-to-text.py')


class WorkbookConverter(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.book = os.path.join(self.dir, 'product.xlsx')
        wb = Workbook()
        wb.remove(wb.active)
        for title, rows in [
            ('Full_Backlog', [['ST-001', 'As a shop owner, I can reply from one inbox']]),
            ('Product_Spec', [['Feature', 'You can send broadcasts']]),
            ('Version_Control', [['v001', 'released']]),
            ('Sprint_Tracker_Log', [['E001', 'did a thing']]),
            ('Traceability_Matrix', [['ST-001', 'Done']]),
            ('Empty_Sheet', []),
        ]:
            ws = wb.create_sheet(title)
            for r in rows:
                ws.append(r)
        wb.save(self.book)
        self.out = os.path.join(self.dir, 'out')

    def convert(self):
        subprocess.run([sys.executable, SCRIPT, self.book, self.out], check=True,
                       capture_output=True)
        return sorted(os.listdir(self.out))

    def test_backlog_is_never_skipped(self):
        """A bare 'log' pattern once matched 'Backlog' and silently dropped the hundred user
        stories while reporting success. That is the failure this test exists for."""
        self.assertIn('Full_Backlog.md', self.convert())

    def test_logs_and_trackers_are_skipped_even_with_underscores(self):
        files = self.convert()
        self.assertNotIn('Version_Control.md', files)
        self.assertNotIn('Sprint_Tracker_Log.md', files)
        self.assertNotIn('Traceability_Matrix.md', files)

    def test_empty_sheets_produce_no_file(self):
        self.assertNotIn('Empty_Sheet.md', self.convert())

    def test_cell_text_survives_the_conversion(self):
        self.convert()
        with open(os.path.join(self.out, 'Full_Backlog.md'), encoding='utf-8') as fh:
            self.assertIn('As a shop owner, I can reply from one inbox', fh.read())


if __name__ == '__main__':
    unittest.main(verbosity=2)
