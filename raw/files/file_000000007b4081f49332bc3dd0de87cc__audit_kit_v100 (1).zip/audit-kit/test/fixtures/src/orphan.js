module.exports = { neverCalled: () => 'nothing imports this' };
