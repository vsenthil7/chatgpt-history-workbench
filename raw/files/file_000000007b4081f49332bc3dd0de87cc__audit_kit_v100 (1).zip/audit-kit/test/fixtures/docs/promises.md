# Product

You can export your data at any time, and we never charge for it.

As a shop owner, I can reply to a customer from one shared inbox.

This section is pending and will be written before launch.

# Table
| Plan | Price |
|---|---|
