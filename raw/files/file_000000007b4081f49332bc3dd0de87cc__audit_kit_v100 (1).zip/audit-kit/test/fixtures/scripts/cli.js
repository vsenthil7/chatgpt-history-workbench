require('../src/wired');
