/** The kit enforces quality on other products, so it needs its own. It has already shipped three
 *  bugs — a false positive, a silently skipped backlog, and undetected user stories — and each
 *  was the kind that makes a team stop trusting tooling. */
const { test } = require('node:test');
const assert = require('node:assert');
const path = require('path');
const { execFileSync } = require('child_process');

const FIX = path.join(__dirname, 'fixtures');
const reach = require('../bin/reachability');
const claims = require('../bin/claims');
const findings = require('../bin/findings');
const extract = require('../bin/extract-claims');

test('reachability finds the orphan and only the orphan', () => {
  // scripts/ holds the consumer of wired.js; without it the tool would correctly report wired
  // as unreferenced too, which is the false positive that prompted consumer scanning.
  const res = reach.run(path.join(FIX, 'src'), [], [path.join(FIX, 'scripts')]);
  assert.strictEqual(res.scanned, 3);
  assert.deepStrictEqual(res.unreferenced.map(f => path.basename(f)), ['orphan.js']);
});

test('reachability honours entry hints', () => {
  const res = reach.run(path.join(FIX, 'src'), ['orphan', 'wired'], []);
  assert.deepStrictEqual(res.unreferenced, []);
});

test('consumers outside the scanned tree are searched — the false positive it once had', () => {
  const withoutScripts = reach.run(path.join(FIX, 'src'), [], []);
  assert.deepStrictEqual(
    withoutScripts.unreferenced.map(f => path.basename(f)).sort(), ['orphan.js', 'wired.js'],
    'without the consumer directory, an entry module looks dead'
  );
  const withScripts = reach.run(path.join(FIX, 'src'), [], [path.join(FIX, 'scripts')]);
  assert.deepStrictEqual(withScripts.unreferenced.map(f => path.basename(f)), ['orphan.js']);
});

test('claims reports the promise with nothing behind it, and passes the one that is kept', () => {
  const res = claims.run(path.join(FIX, 'claims.json'), path.join(FIX, 'src'));
  assert.strictEqual(res.total, 2);
  assert.deepStrictEqual(res.broken.map(b => b.claim), ['broken promise']);
});

test('findings reports a fix that was removed and a file that vanished', () => {
  const res = findings.run(path.join(FIX, 'findings.json'), FIX);
  assert.strictEqual(res.total, 3);
  assert.deepStrictEqual(res.missing.map(m => m.id), ['F-002', 'F-003']);
});

test('extract drafts real promises, including first-person stories, and skips plans and tables', () => {
  const drafted = extract.run(path.join(FIX, 'docs'));
  const text = drafted.map(d => d.claim).join(' | ');
  assert.ok(/export your data/.test(text), 'should draft a "you can" promise');
  assert.ok(/As a shop owner, I can reply/.test(text), 'should draft a first-person user story');
  assert.ok(!/pending and will be written/.test(text), 'should skip anything explicitly unbuilt');
  assert.ok(drafted.every(d => d.markers.length === 0), 'markers are left for a human');
});

test('every tool exits non-zero on failure, which is what makes CI useful', () => {
  const run = (script, args) => {
    try {
      execFileSync('node', [path.join(__dirname, '..', 'bin', script), ...args], { stdio: 'pipe' });
      return 0;
    } catch (e) { return e.status; }
  };
  assert.strictEqual(run('claims.js', [path.join(FIX, 'claims.json'), path.join(FIX, 'src')]), 1);
  assert.strictEqual(run('findings.js', [path.join(FIX, 'findings.json'), FIX]), 1);
  assert.strictEqual(run('reachability.js', [path.join(FIX, 'src'), 'none', 'none']), 1);
});
