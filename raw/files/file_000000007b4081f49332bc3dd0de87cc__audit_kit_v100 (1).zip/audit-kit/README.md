# Audit kit — three checks that find what tests cannot

Built on EngageOS after 38 releases in which 100% statement, branch, function and line coverage
was in place throughout and did not prevent: a product with no way to use it, four modules
nothing called, eleven documents promising things the product did not do, and thirteen wrong
assumptions about the platform.

The three techniques that did find those share one property — they start from **outside the
code**. These scripts make them portable. They are deliberately crude: the value is in forcing
the question, not in the cleverness of the matching.

## 1. `bin/reachability.js <srcDir> [entryHints]`
Lists modules imported by nothing else in the source tree. Each result is either dead code or a
promise the product does not keep — you decide which, and both answers are useful.

```
node bin/reachability.js src "index,app.ts,server" "scripts,worker"
```
The fourth argument lists directories where consumers may live outside the scanned tree — CLI
scripts, workers, a separate web root. Omitting it produces false positives, which is the fastest
way to teach a team to ignore a tool.
On its first run against EngageOS — a codebase that had already had three cold reviews, a
reachability sweep and a claims audit — it found two: a Postgres store the setup guide told
operators to enable via an environment variable nothing read, and an SEO tool a previous finding
had claimed was wired.

## 2. `bin/claims.js <claims.json> <srcDir>`
Checks that each promise made in a customer- or operator-facing document has something in the
code behind it. You write `claims.json` once per product — see `claims.example.json`. Start with
the listing copy and the help centre; they are written from the customer's point of view, which
is why they find what code review cannot.

## 2b. `bin/workbook-to-text.py <product.xlsx> <out-dir>`
Specifications live in spreadsheets as often as in markdown. On EngageOS the screen inventory and
the stated differentiation were both sheets, and both described things the product did not have.
This converts the readable sheets into markdown the extractor can consume, skipping logs and
trackers — a version history records what happened, it does not promise anything.

```
python3 bin/workbook-to-text.py product.xlsx /tmp/wb && node bin/extract-claims.js /tmp/wb MyProduct
```

**If the workbook has a backlog sheet**, the user stories will dominate the draft. That is
correct — a backlog is the largest specification most products have — but a traceability matrix
is usually the better gate for stories, since it tracks status per story rather than presence in
code. Use claims.js for prose documents and the matrix for the backlog; do not duplicate.

## 3. `bin/findings.js <findings.json> <root>`
One probe per closed defect, so a fix cannot be refactored away while the record still claims it
closed. EngageOS needed this because a fix was once built and never wired, and the record read
as closed for four versions.

## Running them in CI
All three exit non-zero on failure. Add them after the test step; they take under a second.

## Two bugs this kit found in itself
Worth stating, because both are the failure mode that makes teams ignore tooling. The reachability
sweep reported a module as unreachable when its only consumer lived in `scripts/`, and the workbook
converter silently skipped `Full_Backlog` because a bare `log` pattern matched "Backlog" — hiding
the single most important specification in the file. A tool that cries wolf gets ignored; a tool
that quietly omits the main artifact is worse, because it reports success.

## The kit has its own tests
`npm test` — seven node tests and four python tests, including one named for each bug the kit has
shipped: the reachability false positive, the silently skipped backlog, and the undetected
first-person user stories. A tool that enforces quality without being tested itself is not an
argument anyone should accept, least of all from the person who wrote it.

## What they will not do
None of these prove correctness. They find the specific blind spot that a test suite has by
construction: a test checks the code against itself, and all three of these check it against
something outside it.
