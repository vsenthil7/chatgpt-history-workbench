# Changelog — AUMNITY Work Platform (product code)

## 0.6.0 — 2026-08-09 (Claude build V007, hardening release after independent V006 deep review)
Fixes for the three V006 findings (`11-issues/REVIEW-FINDINGS-V006.md`).
- BREAKING (ADR-019): `InMemoryUnitOfWork` and `InMemoryTenantProvisioner`
  require a shared `TransactionMutex`; transactions are serialised per store
  composition; a failed transaction can never erase a committed concurrent
  one; nesting raises `ValidationError`.
- ADR-020: whole-aggregate reference integrity — embedded principal
  references and evidence submitters proven members before disclosure or
  completion counting.
- ADR-018 amended: mutation scope now includes `workobject/service.py` and
  `adapters/memory.py`; no integrity-bearing module excluded.

## 0.5.0 — 2026-08-09 (Claude build V006, hardening release after independent V005 deeper review)
Fixes for the seven adversarially executed findings
(`11-issues/REVIEW-FINDINGS-V005.md`).
- BREAKING (ADR-016): `WorkObjectRegistry` requires a `UnitOfWork`; every
  mutating command commits domain and audit writes atomically.
- BREAKING (ADR-017): `WorkObjectRepository.save` replaced by `create` +
  `update(..., expected_version=)`; duplicate ids rejected on all repository
  create/add paths; new published `ConcurrencyError` (contracts).
- BREAKING (DEF-023): `CompletionPolicy.violations(work_object,
  verified_evidence)` — policies judge registry-verified evidence records.
- ADR-002 addendum: `guards` module revalidates every repository-returned
  aggregate (identity/tenancy/linkage); defective adapters fail closed;
  membership errors normalised (no existence oracle).
- ADR-018: mutation-critical scope expanded to guards/audit/organisation.

## 0.4.0 — 2026-08-09 (Claude build V005, hardening release after independent V004 review)
Fixes for independently reproduced V004 defects (`11-issues/REVIEW-FINDINGS-V004.md`).
- BREAKING (ADR-013): `OrganisationRegistry` removed. Published
  `OrganisationDirectory.get_organisation(context)` returns only the caller's
  own organisation (no arbitrary-id lookup); `create_principal` and
  `require_member` unchanged in semantics. Trusted, UNPUBLISHED
  `PlatformProvisioning.create_organisation(...)` owns tenant creation.
  A machine-checked public-boundary inventory contract classifies every
  kernel export and enforces context-first methods on protected services.
- ADR-011 hardened: in-memory tenant provisioning is atomic for ALL failure
  shapes via snapshot/restore of both stores (explicit adapter transaction
  API); no orphan organisation or principal can survive.
- BREAKING (ADR-014): `AuditLog.record` requires the event actor to equal the
  bound acting principal; same-tenant impersonation raises `ValidationError`.
  Delegated recording declared (AUD-004), not overloaded onto one field.
- ADR-015: G10 C7 v2 gate-enforces current-doc version labels against
  ARTIFACT-VERSION; stale V003/V002 headings corrected.

## 0.3.0 — 2026-08-08 (Claude build V004, hardening release after independent V003 review)
Fixes for independently reproduced V003 defects (see
`11-issues/REVIEW-FINDINGS-V003.md`); breaking changes acceptable, no external
consumer of 0.2.0 exists.
- BREAKING (ADR-010): `AuditLog` is a protected boundary — constructor takes a
  `PrincipalDirectory`; `record(context, event)` binds the context, requires
  the event organisation to match it and proves the event actor is a member;
  `entries_for(context)` binds the acting principal. `AuditSink` remains
  infrastructure-trusted and unexported.
- BREAKING (ADR-011): tenant bootstrap atomicity moved to the
  `TenantProvisioner` port; `OrganisationRegistry` makes one all-or-nothing
  provision call; in-memory adapter implements compensating rollback.
- Release validation is non-mutating and idempotent (ADR-012): release-mode
  gate output goes to an external evidence directory; G11 proves double-ladder
  idempotence on the extracted final ZIP with tree-digest comparison.
- Defect log reconciled into one chronological record (DEF-013); G10 gains
  C5–C7 (stale gate-script references, defect-ID consistency, stale slice
  labels); stale "V002 slice" labels removed from product descriptions.

## 0.2.0 — 2026-08-08 (Claude build V003, corrective release after independent review)
Fixes for independently reproduced V002 defects (see
`11-issues/REVIEW-FINDINGS-V002.md`); breaking changes were acceptable because
no external consumer of 0.1.0 exists.
- BREAKING (ADR-007): `OrganisationRegistry.create_organisation(name,
  founder_display_name, founder_kind)` now atomically returns `(Organisation,
  Principal)`; `require_principal` replaced by `require_member`, which raises
  `TenantIsolationError` for unknown AND foreign principals alike.
- BREAKING (ADR-007): `WorkObjectRegistry` requires a `PrincipalDirectory`;
  every protected operation binds the acting principal to the context
  organisation, and owner/assignee references are validated as members.
- BREAKING (ADR-008): `EventEnvelope.payload` is a read-only
  `Mapping[str, str]` (defensive copy); mutation attempts raise `TypeError`.
- Toolchain contract (ADR-009): pinned `requirements-dev.txt` + dev extras;
  `run_gates.py` gains build/release modes with incoming-manifest verification;
  single canonical release gate `g11_release.py` with clean-venv full-ladder
  validation, deterministic double build and extracted-final-ZIP validation;
  artifact version read from root `ARTIFACT-VERSION`.
- G07 distinguishes dependency-unavailable / formatter-execution-error /
  baseline-not-formatted; G09 requires specific test node ids for high-risk
  tenancy rows (DW-FR-013, SaaS-002, TEN-001).

## 0.1.0 — 2026-08-08 (Claude build V002)
First implementation slice (ADR-003):
- `aumnity_contracts`: typed IDs, TenantContext, EventEnvelope, error taxonomy,
  deterministic clock/id providers, standardised source-system constants.
- `aumnity_kernel`: Organisation registry, Principal identity, Work Object
  registry with the baseline lifecycle state machine, versioning, recursive
  decomposition, minimal assignment, immutable evidence with completion policy,
  append-only tenant-scoped audit.
- In-memory adapters for all kernel ports.
- Quality gates G01–G10 as runnable evidence-producing scripts.
No public contract existed before this version; nothing is breaking.
