"""V004 P0-3 regressions (ADR-0011): the G07 mutation gate is FAIL-CLOSED.

Simulates mutmut tool failure, malformed output, apply failure and
non-terminal mutant statuses through an injected command runner; every such
condition must raise GateFailure (exit 1 in main()).
"""
import importlib.util
import subprocess
from pathlib import Path

import pytest

_SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "run_mutation_gate.py"
_spec = importlib.util.spec_from_file_location("run_mutation_gate", _SCRIPT)
gate = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(gate)


@pytest.fixture(autouse=True)
def _isolate_gate_side_effects(tmp_path, monkeypatch):
    """The gate's real side-effect paths must never be touched from tests.

    These tests execute INSIDE mutmut's own baseline pytest run when the real
    gate runs; deleting the live .mutmut-cache under mutmut's open connection
    corrupts that run (V004 root-caused: pony 'attempt to write a readonly
    database'). Evidence writes are likewise redirected.
    """
    monkeypatch.setattr(gate, "CACHE", tmp_path / "mutmut-cache")
    monkeypatch.setattr(gate, "EVIDENCE", tmp_path / "evidence")


class FakeRunner:
    """Scriptable stand-in for subprocess execution inside the gate."""

    def __init__(self) -> None:
        self.responses: dict[str, tuple[int, str, str]] = {}

    def set(self, key: str, returncode: int, stdout: str = "", stderr: str = "") -> None:
        self.responses[key] = (returncode, stdout, stderr)

    def __call__(self, cmd: list[str]) -> subprocess.CompletedProcess:
        joined = " ".join(cmd)
        for key, (code, out, err) in self.responses.items():
            if key in joined:
                return subprocess.CompletedProcess(cmd, code, out, err)
        return subprocess.CompletedProcess(cmd, 0, "", "")


def _healthy_runner(survivors: str = "") -> FakeRunner:
    runner = FakeRunner()
    runner.set("mutmut run", 1 if survivors else 0)
    runner.set("result-ids survived", 0, survivors)
    for status in ("timeout", "suspicious", "skipped", "untested"):
        runner.set(f"result-ids {status}", 0, "")
    runner.set("mutmut results", 0, "1 2 3")
    return runner


def test_mutmut_tool_crash_fails_gate() -> None:
    runner = _healthy_runner()
    runner.set("mutmut run", 137, "", "Killed")  # e.g. OOM-killed tool
    with pytest.raises(gate.GateFailure, match="failed as a tool"):
        gate.execute(run=runner)


def test_result_ids_command_failure_fails_gate() -> None:
    runner = _healthy_runner()
    runner.set("result-ids survived", 3, "", "boom")
    with pytest.raises(gate.GateFailure, match="result-ids survived failed"):
        gate.execute(run=runner)


def test_malformed_result_ids_output_fails_gate() -> None:
    runner = _healthy_runner()
    runner.set("result-ids survived", 0, "12 garbage 14")
    with pytest.raises(gate.GateFailure, match="unparseable mutant id"):
        gate.execute(run=runner)


def test_results_parse_failure_fails_gate_no_fallback_total() -> None:
    """The hard-coded 241 fallback is gone: an unparseable total FAILS."""
    runner = _healthy_runner()
    runner.set("mutmut results", 0, "no numbers here")
    with pytest.raises(gate.GateFailure, match="no parseable mutant ids"):
        gate.execute(run=runner)


def test_results_command_failure_fails_gate() -> None:
    runner = _healthy_runner()
    runner.set("mutmut results", 2, "", "cache corrupt")
    with pytest.raises(gate.GateFailure, match="mutmut results failed"):
        gate.execute(run=runner)


@pytest.mark.parametrize("status", ["timeout", "suspicious", "skipped", "untested"])
def test_non_terminal_mutant_statuses_fail_gate(status: str) -> None:
    runner = _healthy_runner()
    runner.set(f"result-ids {status}", 0, "7 8")
    with pytest.raises(gate.GateFailure, match=f"non-terminal status '{status}'"):
        gate.execute(run=runner)


def test_apply_failed_survivor_fails_gate() -> None:
    """An unverifiable survivor must fail G07, never be silently accepted."""
    runner = _healthy_runner(survivors="5")
    runner.set("mutmut show 5", 0, "+++ src/x.py\n+    mutated line\n")
    runner.set("mutmut apply 5", 1, "", "could not apply")
    with pytest.raises(gate.GateFailure, match="could not be applied"):
        gate.execute(run=runner)


def test_show_failure_fails_gate() -> None:
    runner = _healthy_runner(survivors="5")
    runner.set("mutmut show 5", 1, "", "unknown mutant")
    with pytest.raises(gate.GateFailure, match="mutmut show 5 failed"):
        gate.execute(run=runner)


def test_no_hardcoded_total_remains_in_script() -> None:
    """Regression pin on the exact V003 defect: the invented 241 total."""
    source = _SCRIPT.read_text(encoding="utf-8")
    assert "241" not in source


def test_main_translates_gate_failure_to_exit_1(monkeypatch, tmp_path) -> None:
    def _boom(run=None):
        raise gate.GateFailure("simulated")

    monkeypatch.setattr(gate, "execute", _boom)
    monkeypatch.setattr(gate, "EVIDENCE", tmp_path)  # never stomp real evidence
    assert gate.main() == 1
    assert "G07 FAIL" in (tmp_path / "G07-mutation-summary.txt").read_text()
