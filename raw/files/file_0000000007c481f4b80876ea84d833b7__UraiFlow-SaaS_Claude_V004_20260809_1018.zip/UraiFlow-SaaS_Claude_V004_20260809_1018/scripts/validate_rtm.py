#!/usr/bin/env python3
"""G09 — machine RTM completeness validator (ADR-0012 §5; V003 review P1-1).

Validates the current RTM (06-traceability/RTM-V004.md):
 * requirement IDs are unique;
 * statuses come from the governed vocabulary;
 * every ENFORCED row references at least one existing test/gate/evidence
   artifact;
 * every referenced test file exists, and every ``::test_name`` reference
   resolves to a real test function in the test suite;
 * every referenced ``evidence/`` artifact exists;
 * every referenced ADR exists in 02-architecture/adr;
 * ACTIVE/ENFORCED statuses do not contradict (one status per row).

Evidence: evidence/G09-rtm.txt (and exit code).
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RTM = ROOT / "06-traceability" / "RTM-V004.md"
ADR_DIR = ROOT / "02-architecture" / "adr"
EVIDENCE = ROOT / "evidence"
VALID_STATUSES = {"ENFORCED", "ACTIVE", "PLANNED", "SUPERSEDED"}
# Evidence artifacts produced later within the same release-gate run
# (scripts/run_release_gates.py ordering) are legal references even on the
# first pass, because the orchestrator guarantees their generation.
SAME_RUN_OUTPUTS = {
    "evidence/G01-manifest-check.txt",
    "evidence/G09-rtm.txt",
    "evidence/G10-docs-consistency.txt",
    "evidence/release-gates-summary.json",
}

_ROW = re.compile(r"^\|\s*(?P<id>[A-Z]{2,5}-[0-9.]+[a-z]?(?:\s*\[[^\]]+\])?)\s*\|")


def _test_functions() -> dict[str, set[str]]:
    functions: dict[str, set[str]] = {}
    for test_file in sorted((ROOT / "tests").glob("test_*.py")):
        names = set(re.findall(r"^def (test_\w+)", test_file.read_text(), re.MULTILINE))
        names |= set(re.findall(r"^    def (test_\w+)", test_file.read_text(), re.MULTILINE))
        functions[f"tests/{test_file.name}"] = names
    return functions


def validate() -> list[str]:
    problems: list[str] = []
    if not RTM.is_file():
        return [f"RTM file missing: {RTM.relative_to(ROOT)}"]
    text = RTM.read_text(encoding="utf-8")
    functions = _test_functions()
    all_test_names = set().union(*functions.values()) if functions else set()

    rows = []
    for line in text.splitlines():
        match = _ROW.match(line)
        if match and not match.group("id").startswith("ID"):
            rows.append((match.group("id").split("[")[0].strip(), line))
    if not rows:
        return ["no requirement rows found in RTM"]

    seen: set[str] = set()
    for row_id, line in rows:
        if row_id in seen:
            problems.append(f"duplicate requirement ID: {row_id}")
        seen.add(row_id)
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        status = cells[-1]
        if status not in VALID_STATUSES:
            problems.append(f"{row_id}: invalid status {status!r}")
        # references in the row
        test_files = set(re.findall(r"tests/test_\w+\.py", line))
        test_names = set(re.findall(r"::(test_\w+)", line))
        evidence_refs = set(
            re.findall(r"evidence/[A-Za-z0-9._-]+\.(?:txt|json|md)", line)
        )
        adr_refs = set(re.findall(r"ADR-\d{4}", line))
        for test_file in test_files:
            if test_file not in functions:
                problems.append(f"{row_id}: referenced test file missing: {test_file}")
        for test_name in test_names:
            if test_name not in all_test_names:
                problems.append(
                    f"{row_id}: referenced test does not exist: ::{test_name}"
                )
        for ref in evidence_refs:
            if ref in SAME_RUN_OUTPUTS:
                continue
            if not (ROOT / ref.rstrip(".,;")).is_file():
                problems.append(f"{row_id}: referenced evidence missing: {ref}")
        for adr in adr_refs:
            if not list(ADR_DIR.glob(f"{adr}-*.md")):
                problems.append(f"{row_id}: referenced ADR does not exist: {adr}")
        if status == "ENFORCED" and not (
            test_files or test_names or evidence_refs
            or "scripts/" in line or "pyproject" in line
        ):
            problems.append(
                f"{row_id}: ENFORCED but references no test/gate/evidence artifact"
            )
    return problems


def main() -> int:
    problems = validate()
    EVIDENCE.mkdir(exist_ok=True)
    if problems:
        report = "G09 RTM FAIL:\n" + "\n".join(f" - {p}" for p in problems) + "\n"
        (EVIDENCE / "G09-rtm.txt").write_text(report, encoding="utf-8")
        print(report, file=sys.stderr)
        return 1
    text = RTM.read_text(encoding="utf-8")
    row_count = len(re.findall(_ROW, text))
    report = (
        f"G09 RTM PASS: {RTM.relative_to(ROOT)} — all requirement rows have "
        f"unique IDs, governed statuses, and resolvable test/evidence/ADR "
        f"references ({row_count} data rows checked)\n"
    )
    (EVIDENCE / "G09-rtm.txt").write_text(report, encoding="utf-8")
    print(report.strip())
    return 0


if __name__ == "__main__":
    sys.exit(main())
