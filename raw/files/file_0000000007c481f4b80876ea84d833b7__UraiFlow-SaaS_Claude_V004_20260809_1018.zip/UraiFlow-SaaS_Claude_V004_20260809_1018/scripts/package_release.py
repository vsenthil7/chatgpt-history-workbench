#!/usr/bin/env python3
"""Deterministic release packager + external attestation (ADR-0012; V003
review P0-4/P0-5/P0-6). Packaging is executable policy, not prose.

Pipeline (single controlled operation):
 1. construct the payload from an explicit governed allowlist policy;
 2. reject any excluded/unexpected material (fail-closed);
 3. regenerate the manifest over the exact frozen payload;
 4. validate the complete manifest contract (scripts/gen_manifest.py --check);
 5. build a deterministic ZIP (sorted entries, fixed timestamps/permissions);
 6. rebuild from the same frozen payload and prove byte-identical output;
 7. compute the final ZIP SHA-256 — the ZIP is never modified afterwards;
 8. extract that exact ZIP into a fresh location and run the smoke suite;
 9. emit UraiFlow-SaaS_Claude_<version>_ATTESTATION.md OUTSIDE the ZIP,
    binding every verification result to the final ZIP SHA-256.

Usage: python scripts/package_release.py --version V004 [--out DIR]
"""
import argparse
import hashlib
import json
import platform
import shutil
import subprocess
import sys
import zipfile
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# ---- governed payload policy (ADR-0012 §2) ----------------------------------
# Explicit allowlist of top-level payload entries. Anything else at top level
# is unexpected and fails packaging.
ALLOWED_TOP_LEVEL = {
    "00-control", "01-product", "02-architecture", "03-engineering",
    "04-testing", "05-quality", "06-traceability", "07-planning", "08-ai",
    "09-governance", "10-baseline", "evidence", "scripts", "src", "tests",
    "BUILD-REPORT-V002.md", "BUILD-REPORT-V003.md", "BUILD-REPORT-V004.md",
    "CLAUDE.md", "PACKAGE-MANIFEST.json", "pyproject.toml", "setup.cfg",
}
# Generated/build/test material that must never enter a release payload.
EXCLUDED_NAMES = {
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".coverage",
    ".mutmut-cache", ".venv", "venv", ".git", ".hypothesis", ".DS_Store",
}
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}


def _is_excluded(rel: Path) -> bool:
    if any(part in EXCLUDED_NAMES for part in rel.parts):
        return True
    if rel.suffix in EXCLUDED_SUFFIXES:
        return True
    # egg-info directories are build products at ANY depth (pip install -e
    # places src/<pkg>.egg-info; the V004 packager originally checked only the
    # first path component and shipped it untracked — the exact P0-4 shape)
    return any(part.endswith(".egg-info") for part in rel.parts)


def _run(cmd, cwd, env=None):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True,
                          check=False, env=env)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_payload(source: Path, payload: Path) -> list[Path]:
    """Copy the governed payload; fail on unexpected top-level material."""
    unexpected = sorted(
        entry.name for entry in source.iterdir()
        if entry.name not in ALLOWED_TOP_LEVEL
        and entry.name not in EXCLUDED_NAMES
        and not entry.name.endswith(".egg-info")
        and not (entry.name.startswith("UraiFlow-SaaS_Claude_")  # prior artifacts
                 and (entry.suffix == ".zip" or "ATTESTATION" in entry.name))
        and entry.name != "dist"
    )
    if unexpected:
        raise SystemExit(
            f"packaging policy violation: unexpected top-level entries "
            f"{unexpected} (extend ALLOWED_TOP_LEVEL deliberately or remove)"
        )
    files: list[Path] = []
    for entry in sorted(source.rglob("*")):
        rel = entry.relative_to(source)
        if rel.parts[0] not in ALLOWED_TOP_LEVEL:
            continue
        if _is_excluded(rel):
            continue
        if entry.is_file():
            destination = payload / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(entry, destination)
            files.append(rel)
    return files


def verify_payload_clean(payload: Path) -> None:
    """Fail-closed proof that no excluded material entered the payload."""
    dirty = sorted(
        str(p.relative_to(payload))
        for p in payload.rglob("*")
        if _is_excluded(p.relative_to(payload))
    )
    if dirty:
        raise SystemExit(f"payload contains excluded material: {dirty[:20]}")


def deterministic_zip(payload: Path, zip_path: Path, arcroot: str) -> str:
    """Deterministic ZIP: sorted entries, fixed timestamp, fixed permissions."""
    fixed_time = (2026, 1, 1, 0, 0, 0)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(payload.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(payload)
            info = zipfile.ZipInfo(f"{arcroot}/{rel.as_posix()}", date_time=fixed_time)
            info.external_attr = 0o644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
    return _sha256(zip_path)


def smoke_extracted(zip_path: Path, workdir: Path) -> dict:
    """Extract the EXACT final ZIP into a fresh location and smoke it."""
    extract_dir = workdir / "smoke-extract"
    if extract_dir.exists():
        shutil.rmtree(extract_dir)
    extract_dir.mkdir(parents=True)
    with zipfile.ZipFile(zip_path) as archive:
        archive.extractall(extract_dir)
    (tree,) = [p for p in extract_dir.iterdir() if p.is_dir()]
    env = {"PYTHONPATH": str(tree / "src"), "PATH": "/usr/bin:/bin:/usr/local/bin",
           "HOME": str(workdir)}
    steps = {}
    for name, cmd in (
        ("pytest", [sys.executable, "-m", "pytest", "-p", "no:cacheprovider"]),
        ("starter_validator", [sys.executable, "scripts/validate_starter.py"]),
        ("manifest_check", [sys.executable, "scripts/gen_manifest.py", "--check"]),
    ):
        result = _run(cmd, cwd=tree, env=env)
        steps[name] = {
            "command": " ".join(cmd),
            "exit_code": result.returncode,
            "tail": (result.stdout + result.stderr).strip().splitlines()[-1:]
        }
        if result.returncode != 0:
            raise SystemExit(
                f"extracted-ZIP smoke step '{name}' failed "
                f"(exit {result.returncode}):\n{(result.stdout + result.stderr)[-2000:]}"
            )
    # smoke must not have mutated the extracted payload
    shutil.rmtree(extract_dir)
    return steps


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", required=True, help="e.g. V004")
    parser.add_argument("--out", default=str(ROOT / "dist"))
    args = parser.parse_args()

    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M")
    base = f"UraiFlow-SaaS_Claude_{args.version}_{stamp}"
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    workdir = out / "work"
    if workdir.exists():
        shutil.rmtree(workdir)
    payload = workdir / "payload" / base
    payload.mkdir(parents=True)

    print("1/9 constructing governed payload...")
    build_payload(ROOT, payload)
    print("2/9 verifying payload cleanliness (fail-closed)...")
    verify_payload_clean(payload)

    print("3/9 regenerating manifest over the exact payload...")
    gen = _run([sys.executable, "scripts/gen_manifest.py"], cwd=payload)
    if gen.returncode != 0:
        raise SystemExit(f"manifest generation failed: {gen.stderr}")
    print("4/9 validating complete manifest contract...")
    chk = _run([sys.executable, "scripts/gen_manifest.py", "--check"], cwd=payload)
    if chk.returncode != 0:
        raise SystemExit(f"manifest contract check failed:\n{chk.stdout}{chk.stderr}")
    manifest = json.loads((payload / "PACKAGE-MANIFEST.json").read_text())

    print("5/9 building deterministic ZIP...")
    zip_path = out / f"{base}.zip"
    sha_first = deterministic_zip(payload, zip_path, base)
    print("6/9 rebuilding from frozen payload; proving byte-identical output...")
    rebuild_path = workdir / f"{base}.rebuild.zip"
    sha_second = deterministic_zip(payload, rebuild_path, base)
    if sha_first != sha_second:
        raise SystemExit(
            f"non-deterministic build: {sha_first} != {sha_second}"
        )
    rebuild_path.unlink()

    print(f"7/9 final ZIP SHA-256: {sha_first} (ZIP is now frozen)")
    print("8/9 extracting the exact final ZIP and running smoke...")
    smoke = smoke_extracted(zip_path, workdir)
    sha_after_smoke = _sha256(zip_path)
    if sha_after_smoke != sha_first:
        raise SystemExit("ZIP was modified after its hash was calculated")

    print("9/9 writing external attestation...")
    payload_count = sum(1 for p in payload.rglob("*") if p.is_file())
    if payload_count != manifest["file_count"] + 1:  # +1 = the manifest itself
        on_disk = {str(p.relative_to(payload))
                   for p in payload.rglob("*") if p.is_file()}
        covered = {e["path"] for e in manifest["files"]} | {"PACKAGE-MANIFEST.json"}
        raise SystemExit(
            "packaging integrity violation: payload/manifest count mismatch; "
            f"untracked in payload: {sorted(on_disk - covered)[:20]}; "
            f"missing from payload: {sorted(covered - on_disk)[:20]}"
        )
    tool_versions = {}
    for tool in ("pytest", "ruff", "mypy"):
        result = _run([sys.executable, "-m", tool, "--version"], cwd=ROOT)
        tool_versions[tool] = (result.stdout + result.stderr).strip().splitlines()[0]
    # mutmut has no --version flag; read installed metadata instead
    from importlib.metadata import version as _pkg_version
    tool_versions["mutmut"] = f"mutmut {_pkg_version('mutmut')}"
    attestation_path = out / f"{base}_ATTESTATION.md"
    now = datetime.now(UTC).isoformat(timespec="seconds")
    smoke_lines = "\n".join(
        f"| {name} | `{info['command']}` | {info['exit_code']} | "
        f"{' '.join(info['tail'])} |"
        for name, info in smoke.items()
    )
    attestation_path.write_text(f"""# UraiFlow Release Attestation — {base}

This attestation is generated by `scripts/package_release.py` (ADR-0012) and
lives OUTSIDE the ZIP so the complete final artifact is hash-attested without
self-reference. **All results below were executed over the artifact whose
SHA-256 is stated, not a candidate/build tree.**

## Artifact identity
| Field | Value |
|---|---|
| ZIP filename | `{base}.zip` |
| **Final ZIP SHA-256** | `{sha_first}` |
| Product version | `{manifest["product_version"]}` |
| Build timestamp (UTC) | `{now}` |
| Payload file count (on disk) | {payload_count} |
| Manifest-covered file count | {manifest["file_count"]} + PACKAGE-MANIFEST.json itself |
| Unexpected/excluded payload files | 0 (fail-closed policy verified) |

## Deterministic rebuild
| Build | SHA-256 |
|---|---|
| First build | `{sha_first}` |
| Second build (same frozen payload) | `{sha_second}` |
| Byte-identical | {"YES" if sha_first == sha_second else "NO"} |
| ZIP unmodified after hashing | YES (re-hashed post-smoke: `{sha_after_smoke}`) |

## Exact packaging command
```
python scripts/package_release.py --version {args.version}
```

## Clean-extraction smoke over the final ZIP (SHA-256 `{sha_first[:16]}…`)
| Step | Command | Exit | Result tail |
|---|---|---|---|
{smoke_lines}

## Environment
| Component | Version |
|---|---|
| Python | {platform.python_version()} ({platform.system()} {platform.machine()}) |
| pytest | {tool_versions["pytest"]} |
| ruff | {tool_versions["ruff"]} |
| mypy | {tool_versions["mypy"]} |
| mutmut | {tool_versions["mutmut"]} |

## Gate evidence references (inside the ZIP, manifest-protected)
- Manifest contract: `evidence/G01-manifest-check.txt` + full-contract check above
- Tests/coverage: `evidence/G03-tests.txt`, `evidence/G04-coverage.txt`
- Static: `evidence/G02-ruff.txt`, `evidence/G02-mypy.txt`
- Contracts/architecture/tenant: `evidence/G05-contracts.txt`, `evidence/G06-architecture.txt`, `evidence/G08-tenant-security.txt`
- Mutation (fail-closed): `evidence/G07-mutation.json`, `evidence/G07-mutation-summary.txt`
- RTM: `evidence/G09-rtm.txt` · Docs consistency: `evidence/G10-docs-consistency.txt`
- Packaging/smoke (this document): `G11` — the attestation itself is the G11 evidence
""", encoding="utf-8")
    shutil.rmtree(workdir)
    print(f"DONE\n  zip:         {zip_path}\n  attestation: {attestation_path}\n"
          f"  sha256:      {sha_first}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
