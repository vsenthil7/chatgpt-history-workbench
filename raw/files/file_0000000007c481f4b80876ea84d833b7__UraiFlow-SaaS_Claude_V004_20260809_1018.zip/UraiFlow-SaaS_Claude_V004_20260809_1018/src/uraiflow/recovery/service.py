"""COMPENSATION_FAILED operator recovery (ADR-0013 §3).

Two authorised operations exist for a proposal stuck in COMPENSATION_FAILED:

* ``retry_rollback`` — re-attempt rollback of every unrecovered receipt through
  the exact adapter machine identity that produced it. Full success reaches
  ROLLED_BACK; partial success stays COMPENSATION_FAILED with the remaining
  receipts recorded for further recovery.
* ``resolve_manually`` — an authorised operator attests, with mandatory
  free-text evidence, that the remaining records were resolved outside
  UraiFlow. This reaches the terminal MANUALLY_RESOLVED state.

Both are tenant-isolated, authorisation-checked, and append-only in lineage:
the original commit/rollback failure history is never erased or rewritten.
"""
from dataclasses import dataclass

from uraiflow.adapters.contract import CommitReceipt
from uraiflow.core.clock import Clock
from uraiflow.core.errors import AuthorizationError, InvalidTransitionError
from uraiflow.core.ids import new_id
from uraiflow.core.tenancy import TenantContext, require_same_tenant
from uraiflow.lineage.model import LineageEvent
from uraiflow.lineage.store import LineageStore
from uraiflow.proposal.model import Proposal, ProposalStatus
from uraiflow.routing.registry import AdapterRegistry


@dataclass(frozen=True)
class RecoveryResult:
    """Structured outcome of one recovery operation."""

    compensated_receipts: tuple[CommitReceipt, ...]
    unrecovered_receipts: tuple[CommitReceipt, ...]
    rollback_failures: tuple[str, ...]


class RecoveryService:
    """Authorised operator workflow over COMPENSATION_FAILED proposals."""

    def __init__(
        self,
        registry: AdapterRegistry,
        lineage: LineageStore,
        clock: Clock,
        authorized_operators: frozenset[str],
    ) -> None:
        self._registry = registry
        self._lineage = lineage
        self._clock = clock
        self._operators = authorized_operators

    # -- operations --

    def retry_rollback(self, ctx: TenantContext, proposal: Proposal) -> RecoveryResult:
        self._authorise(ctx, proposal, "retry_rollback")
        self._event(
            ctx,
            proposal,
            "recovery.retry_started",
            {
                "operator_id": ctx.actor_id,
                "receipts": [r.receipt_id for r in proposal.unrecovered_receipts],
            },
        )
        compensated: list[CommitReceipt] = []
        remaining: list[CommitReceipt] = []
        failures: list[str] = []
        for receipt in proposal.unrecovered_receipts:
            adapter = self._registry.resolve_by_id(receipt.adapter_id)
            try:
                adapter.rollback(ctx, receipt)
            except Exception as error:  # noqa: BLE001 - ADR-0007 §2 adapter boundary
                failure = f"{receipt.adapter_id}: {type(error).__name__}: {error}"
                failures.append(failure)
                remaining.append(receipt)
                self._event(
                    ctx,
                    proposal,
                    "record.rollback_failed",
                    {"record_id": receipt.record_id, "error": failure},
                )
                continue
            compensated.append(receipt)
            self._event(
                ctx,
                proposal,
                "record.rolled_back",
                {"record_id": receipt.record_id, "adapter": receipt.adapter_id},
            )
        if remaining:
            # stays COMPENSATION_FAILED; record the reduced working set
            proposal.record_unrecovered(tuple(remaining))
            self._event(
                ctx,
                proposal,
                "recovery.retry_failed",
                {"operator_id": ctx.actor_id, "unrecovered": len(remaining)},
            )
        else:
            # clear through the guarded aggregate method (legal: status is
            # still COMPENSATION_FAILED here), then advance
            proposal.record_unrecovered(())
            proposal.advance(ProposalStatus.ROLLED_BACK)
            self._event(
                ctx,
                proposal,
                "recovery.retry_succeeded",
                {"operator_id": ctx.actor_id, "compensated": len(compensated)},
            )
        return RecoveryResult(
            compensated_receipts=tuple(compensated),
            unrecovered_receipts=tuple(remaining),
            rollback_failures=tuple(failures),
        )

    def resolve_manually(
        self, ctx: TenantContext, proposal: Proposal, evidence: str
    ) -> None:
        self._authorise(ctx, proposal, "resolve_manually")
        if not evidence.strip():
            raise ValueError(
                "manual resolution requires non-empty evidence describing how "
                "the unrecovered records were resolved"
            )
        # Unrecovered receipts stay recorded on the aggregate as evidence of
        # what remained outstanding at the moment of manual resolution.
        proposal.advance(ProposalStatus.MANUALLY_RESOLVED)
        self._event(
            ctx,
            proposal,
            "recovery.manually_resolved",
            {
                "operator_id": ctx.actor_id,
                "evidence": evidence.strip(),
                "unrecovered_receipt_ids": [
                    r.receipt_id for r in proposal.unrecovered_receipts
                ],
            },
        )

    # -- guards --

    def _authorise(
        self, ctx: TenantContext, proposal: Proposal, operation: str
    ) -> None:
        if ctx.actor_id not in self._operators:
            raise AuthorizationError(
                f"actor '{ctx.actor_id}' is not authorised for {operation}"
            )
        require_same_tenant(ctx, proposal.tenant_id, "proposal recovery")
        if proposal.status is not ProposalStatus.COMPENSATION_FAILED:
            raise InvalidTransitionError(
                f"proposal {proposal.proposal_id}: {operation} only applies to "
                f"COMPENSATION_FAILED, not {proposal.status.value}"
            )

    def _event(
        self, ctx: TenantContext, proposal: Proposal, kind: str, payload: dict
    ) -> None:
        self._lineage.append(
            ctx,
            LineageEvent(
                event_id=new_id("evt"),
                tenant_id=ctx.tenant_id,
                subject_id=proposal.proposal_id,
                kind=kind,
                payload=payload,
                occurred_at=self._clock.now(),
            ),
        )
