"""Record-type -> adapter routing table (baseline doc 49, step 8 of the pipeline).

ADR-0010: adapter machine identity (``adapter_id``) is globally unambiguous
within a registry; registration is atomic; compensation resolution binds to
exact machine identity only. Display names never affect routing or rollback.
"""
from uraiflow.adapters.contract import TargetSystemAdapter, validate_descriptor
from uraiflow.core.errors import RoutingError


class AdapterRegistry:
    """Maps record types and machine identities to registered adapters."""

    def __init__(self) -> None:
        self._routes: dict[str, TargetSystemAdapter] = {}
        self._by_id: dict[str, TargetSystemAdapter] = {}

    def register(self, adapter: TargetSystemAdapter) -> None:
        """Atomically register *adapter*: all invariants are checked before any
        state is mutated, so a rejected adapter leaves the registry untouched."""
        descriptor = adapter.descriptor()
        validate_descriptor(descriptor)
        if descriptor.adapter_id in self._by_id:
            raise RoutingError(
                f"adapter identity '{descriptor.adapter_id}' is already registered"
            )
        for record_type in descriptor.accepted_record_types:
            if record_type in self._routes:
                raise RoutingError(
                    f"record type '{record_type}' already routed to adapter "
                    f"'{self._routes[record_type].descriptor().adapter_id}'"
                )
        self._by_id[descriptor.adapter_id] = adapter
        for record_type in descriptor.accepted_record_types:
            self._routes[record_type] = adapter

    def resolve(self, record_type: str) -> TargetSystemAdapter:
        if record_type not in self._routes:
            raise RoutingError(f"no adapter accepts record type '{record_type}'")
        return self._routes[record_type]

    def resolve_by_id(self, adapter_id: str) -> TargetSystemAdapter:
        """Resolve by exact machine identity (the only identity compensation
        may use; ADR-0010)."""
        if adapter_id not in self._by_id:
            raise RoutingError(f"no registered adapter with identity '{adapter_id}'")
        return self._by_id[adapter_id]
