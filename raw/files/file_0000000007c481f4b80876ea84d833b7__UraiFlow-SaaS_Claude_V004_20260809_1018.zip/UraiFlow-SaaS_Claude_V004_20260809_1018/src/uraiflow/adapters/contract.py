"""Target-system adapter contract (baseline doc 51, formalised; ADR-0002).

Each adapter declares accepted record types, schema version, required fields,
idempotency behaviour and rollback capability. Receiving domains own business
validation and final commit semantics; UraiFlow only speaks this contract.

ADR-0010: every adapter carries an immutable machine identity (``adapter_id``)
separate from its display name, and every CommitReceipt an adapter returns is
untrusted until :func:`validate_commit_receipt` binds it to the invoked
adapter, tenant, record and idempotency key.
"""
import re
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Protocol

from uraiflow.core.errors import AdapterContractError
from uraiflow.core.tenancy import TenantContext
from uraiflow.extraction.model import CandidateRecord

_ADAPTER_ID_PATTERN = re.compile(r"[a-z0-9][a-z0-9._-]*\Z")


@dataclass(frozen=True)
class AdapterDescriptor:
    """Machine-readable declaration of an adapter's contract surface.

    ``adapter_id`` is the immutable machine identity used for routing-independent
    resolution (compensation binds to it); ``name`` is display-only and MUST
    never affect routing or rollback (ADR-0010).
    """

    adapter_id: str
    name: str
    schema_version: str
    accepted_record_types: tuple[str, ...]
    required_fields: Mapping[str, tuple[str, ...]]
    supports_rollback: bool


@dataclass(frozen=True)
class ValidationResult:
    ok: bool
    errors: tuple[str, ...]


@dataclass(frozen=True)
class CommitReceipt:
    """Evidence of a committed record in the target system."""

    receipt_id: str
    adapter_id: str
    adapter_name: str
    tenant_id: str
    record_id: str
    idempotency_key: str
    target_ref: str


class TargetSystemAdapter(Protocol):
    """Contract every target-system integration must satisfy."""

    def descriptor(self) -> AdapterDescriptor:  # pragma: no cover - protocol signature
        ...

    def validate(self, record: CandidateRecord) -> ValidationResult:  # pragma: no cover - protocol signature
        ...

    def preview(self, ctx: TenantContext, record: CandidateRecord) -> Mapping[str, Any]:  # pragma: no cover - protocol signature
        ...

    def commit(
        self, ctx: TenantContext, record: CandidateRecord, idempotency_key: str
    ) -> CommitReceipt:  # pragma: no cover - protocol signature
        ...

    def rollback(self, ctx: TenantContext, receipt: CommitReceipt) -> None:  # pragma: no cover - protocol signature
        ...


def standard_validate(
    descriptor: AdapterDescriptor, record: CandidateRecord
) -> ValidationResult:
    """Contract-level validation: accepted type + required fields present/non-empty.

    Domain/business validation beyond this belongs to the receiving system.
    """
    if record.record_type not in descriptor.accepted_record_types:
        return ValidationResult(
            ok=False,
            errors=(
                (
                    f"record type '{record.record_type}' not accepted by "
                    f"adapter '{descriptor.name}'"
                ),
            ),
        )
    errors: list[str] = []
    for field_name in descriptor.required_fields[record.record_type]:
        value = record.fields.get(field_name)
        if value is None or value == "":
            errors.append(
                f"required field '{field_name}' missing/empty for "
                f"record type '{record.record_type}'"
            )
    return ValidationResult(ok=not errors, errors=tuple(errors))


def validate_descriptor(descriptor: AdapterDescriptor) -> None:
    """Descriptor invariants enforced at the runtime registration boundary
    (ADR-0007 §4, ADR-0010) and by the compliance harness."""
    if not _ADAPTER_ID_PATTERN.fullmatch(descriptor.adapter_id):
        raise AdapterContractError(
            "adapter must declare a machine identity (adapter_id) matching "
            f"'{_ADAPTER_ID_PATTERN.pattern}'; got {descriptor.adapter_id!r}"
        )
    if not descriptor.name.strip():
        raise AdapterContractError("adapter must declare a name")
    if not descriptor.schema_version.strip():
        raise AdapterContractError(
            f"adapter '{descriptor.name}' must declare a schema version"
        )
    if not descriptor.accepted_record_types:
        raise AdapterContractError(
            f"adapter '{descriptor.name}' must accept at least one record type"
        )
    seen_types: set[str] = set()
    for record_type in descriptor.accepted_record_types:
        if record_type in seen_types:
            raise AdapterContractError(
                f"adapter '{descriptor.adapter_id}': duplicate accepted record "
                f"type '{record_type}'"
            )
        seen_types.add(record_type)
        if record_type not in descriptor.required_fields:
            raise AdapterContractError(
                f"adapter '{descriptor.name}': required_fields must cover "
                f"accepted type '{record_type}'"
            )
    for key, fields in descriptor.required_fields.items():
        if key not in seen_types:
            raise AdapterContractError(
                f"adapter '{descriptor.adapter_id}': required_fields key "
                f"'{key}' is not an accepted record type"
            )
        seen_fields: set[str] = set()
        for field_name in fields:
            if field_name in seen_fields:
                raise AdapterContractError(
                    f"adapter '{descriptor.adapter_id}': duplicate required "
                    f"field '{field_name}' for record type '{key}'"
                )
            seen_fields.add(field_name)


def validate_commit_receipt(
    descriptor: AdapterDescriptor,
    ctx: TenantContext,
    record: CandidateRecord,
    idempotency_key: str,
    receipt: CommitReceipt,
) -> None:
    """ADR-0010 §3: a receipt is untrusted evidence until it is bound to the
    invoked adapter, tenant, record and idempotency operation.

    Raises :class:`AdapterContractError` on any mismatch; the caller must treat
    that as an adapter contract failure and enter governed compensation.
    """
    if receipt.adapter_id != descriptor.adapter_id:
        raise AdapterContractError(
            f"receipt adapter identity '{receipt.adapter_id}' does not match "
            f"invoked adapter '{descriptor.adapter_id}'"
        )
    if receipt.tenant_id != ctx.tenant_id:
        raise AdapterContractError(
            f"receipt tenant '{receipt.tenant_id}' does not match operation "
            f"tenant '{ctx.tenant_id}'"
        )
    if receipt.record_id != record.record_id:
        raise AdapterContractError(
            f"receipt record '{receipt.record_id}' does not match committed "
            f"record '{record.record_id}'"
        )
    if receipt.idempotency_key != idempotency_key:
        raise AdapterContractError(
            f"receipt idempotency key '{receipt.idempotency_key}' does not "
            f"match supplied key '{idempotency_key}'"
        )
    if not receipt.receipt_id.strip():
        raise AdapterContractError("receipt receipt_id must be non-empty")
    if not receipt.target_ref.strip():
        raise AdapterContractError("receipt target_ref must be non-empty")


def assert_adapter_contract(adapter: TargetSystemAdapter) -> None:
    """Compliance harness usable against any adapter implementation."""
    validate_descriptor(adapter.descriptor())
