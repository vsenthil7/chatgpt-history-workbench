"""Plan Item state machine — baseline state catalogue with change-reason rules.

Review finding F03/F04 (V002): the change reason and the transition facts are
preserved on the returned :class:`PlanItemChange` record, which is the typed,
framework-neutral domain-change representation (ADR-008). No messaging
infrastructure is implied; timestamps/actors/correlation need clock and
identity contracts and are explicitly deferred (kept deterministic).
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum

from cgwo_core.tenancy import TenantContext, assert_same_tenant


class PlanItemState(str, Enum):
    CANDIDATE = "CANDIDATE"
    WEEK_PLANNED = "WEEK_PLANNED"
    DAY_PLANNED = "DAY_PLANNED"
    STARTED = "STARTED"
    PAUSED = "PAUSED"
    BLOCKED = "BLOCKED"
    INTERRUPTED = "INTERRUPTED"
    DEFERRED = "DEFERRED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


S = PlanItemState

#: Allowed transitions. Terminal states have empty target sets.
ALLOWED_TRANSITIONS: dict[PlanItemState, frozenset[PlanItemState]] = {
    S.CANDIDATE: frozenset({S.WEEK_PLANNED, S.DEFERRED, S.CANCELLED}),
    S.WEEK_PLANNED: frozenset({S.DAY_PLANNED, S.CANDIDATE, S.DEFERRED, S.CANCELLED}),
    S.DAY_PLANNED: frozenset({S.STARTED, S.WEEK_PLANNED, S.DEFERRED, S.CANCELLED}),
    S.STARTED: frozenset({S.PAUSED, S.BLOCKED, S.INTERRUPTED, S.COMPLETED, S.CANCELLED}),
    S.PAUSED: frozenset({S.STARTED, S.INTERRUPTED, S.DEFERRED, S.CANCELLED}),
    S.BLOCKED: frozenset({S.STARTED, S.DEFERRED, S.CANCELLED}),
    S.INTERRUPTED: frozenset({S.DAY_PLANNED, S.WEEK_PLANNED, S.DEFERRED, S.CANCELLED}),
    S.DEFERRED: frozenset({S.CANDIDATE, S.WEEK_PLANNED, S.CANCELLED}),
    S.COMPLETED: frozenset(),
    S.CANCELLED: frozenset(),
}

#: Targets that always demand an explicit change reason (adaptive replanning).
REASON_REQUIRED_TARGETS: frozenset[PlanItemState] = frozenset(
    {S.BLOCKED, S.INTERRUPTED, S.DEFERRED, S.CANCELLED}
)

#: Demotions (plan rollbacks) that also demand a change reason.
REASON_REQUIRED_DEMOTIONS: frozenset[tuple[PlanItemState, PlanItemState]] = frozenset(
    {(S.WEEK_PLANNED, S.CANDIDATE), (S.DAY_PLANNED, S.WEEK_PLANNED)}
)

#: Domain event type emitted per transition (baseline event catalogue).
EVENT_BY_TRANSITION: dict[tuple[PlanItemState, PlanItemState], str] = {
    (S.CANDIDATE, S.WEEK_PLANNED): "WeeklyPlanChanged",
    (S.WEEK_PLANNED, S.CANDIDATE): "WeeklyPlanChanged",
    (S.DEFERRED, S.WEEK_PLANNED): "WeeklyPlanChanged",
    (S.INTERRUPTED, S.WEEK_PLANNED): "WeeklyPlanChanged",
    (S.WEEK_PLANNED, S.DAY_PLANNED): "DailyPlanChanged",
    (S.DAY_PLANNED, S.WEEK_PLANNED): "DailyPlanChanged",
    (S.INTERRUPTED, S.DAY_PLANNED): "DailyPlanChanged",
    (S.STARTED, S.INTERRUPTED): "WorkInterrupted",
    (S.PAUSED, S.INTERRUPTED): "WorkInterrupted",
}

DEFAULT_EVENT = "PlanItemStateChanged"


class InvalidTransitionError(ValueError):
    """Raised for a transition not present in ALLOWED_TRANSITIONS."""


class ChangeReasonRequiredError(ValueError):
    """Raised when a replanning transition lacks an explicit change reason."""


@dataclass(frozen=True, slots=True)
class PlanItemChange:
    """Typed domain-change record for one Plan Item transition (ADR-008)."""

    event_type: str
    tenant_id: str
    work_object_ref: str
    previous_state: PlanItemState
    new_state: PlanItemState
    change_reason: str | None
    item: PlanItem


def _validate_plan_item(tenant_id: str, work_object_ref: str) -> None:
    if not tenant_id.strip():
        raise ValueError("tenant_id must be non-blank")
    if not work_object_ref.strip():
        raise ValueError("work_object_ref must be non-blank")


def transition_plan_item(
    item: PlanItem,
    target: PlanItemState,
    ctx: TenantContext,
    change_reason: str | None = None,
) -> PlanItemChange:
    """Protected operation (ADR-009): apply one guarded state transition."""
    assert_same_tenant(ctx, item.tenant_id)
    if target not in ALLOWED_TRANSITIONS[item.state]:
        raise InvalidTransitionError(
            f"transition {item.state.value} -> {target.value} is not allowed"
        )
    needs_reason = (
        target in REASON_REQUIRED_TARGETS or (item.state, target) in REASON_REQUIRED_DEMOTIONS
    )
    normalised_reason = (change_reason or "").strip() or None
    if needs_reason and normalised_reason is None:
        raise ChangeReasonRequiredError(
            f"transition {item.state.value} -> {target.value} requires a change reason"
        )
    return PlanItemChange(
        event_type=EVENT_BY_TRANSITION.get((item.state, target), DEFAULT_EVENT),
        tenant_id=item.tenant_id,
        work_object_ref=item.work_object_ref,
        previous_state=item.state,
        new_state=target,
        change_reason=normalised_reason,
        item=replace(item, state=target),
    )


@dataclass(frozen=True, slots=True)
class PlanItem:
    """Placement of a Platform Work Object into a planning horizon (ADR-006 refs)."""

    tenant_id: str
    work_object_ref: str
    state: PlanItemState = PlanItemState.CANDIDATE

    def __post_init__(self) -> None:
        _validate_plan_item(self.tenant_id, self.work_object_ref)

    def transition(
        self,
        target: PlanItemState,
        ctx: TenantContext,
        change_reason: str | None = None,
    ) -> PlanItemChange:
        return transition_plan_item(self, target, ctx, change_reason)
