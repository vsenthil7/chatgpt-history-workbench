"""CGWO consumer-side boundary contracts (review finding F12; G05 partial).

These are CGWO's *expected* inbound boundary shapes, versioned and owned by
CGWO as consumer contracts. They do NOT duplicate Platform-owned entities:
every foreign concept remains an opaque reference (ADR-006). UraiFlow record
proposals are inbound suggestions and never mutate CGWO state without a
confirmation step (confirmation workflow is DECLARED, not implemented).
Provider-side compatibility testing attaches to these once the Platform and
UraiFlow publish their sides.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from cgwo_core.capacity import CapacityType, CapacityWindow

CONSUMER_CONTRACT_VERSION = "cgwo-consumer-v1"


class ContractViolationError(ValueError):
    """Raised when an inbound proposal violates the consumer contract."""


def _require_non_blank(value: str, field_name: str) -> None:
    if not value.strip():
        raise ContractViolationError(f"{field_name} must be non-blank")


@dataclass(frozen=True, slots=True)
class TimeRecordProposal:
    """Proposed time record (e.g. from UraiFlow) awaiting confirmation."""

    tenant_id: str
    resource_ref: str
    work_object_ref: str
    minutes: int
    narrative: str = ""
    source_system: str = "uraiflow"

    def __post_init__(self) -> None:
        _require_non_blank(self.tenant_id, "tenant_id")
        _require_non_blank(self.resource_ref, "resource_ref")
        _require_non_blank(self.work_object_ref, "work_object_ref")
        _require_non_blank(self.source_system, "source_system")
        if self.minutes <= 0:
            raise ContractViolationError("minutes must be > 0")


@dataclass(frozen=True, slots=True)
class AvailabilityProposal:
    """Proposed availability declaration awaiting confirmation."""

    tenant_id: str
    resource_ref: str
    period_start: date
    period_end: date
    available_minutes: int
    capacity_type: CapacityType = CapacityType.EXECUTION
    source_system: str = "uraiflow"

    def __post_init__(self) -> None:
        _require_non_blank(self.source_system, "source_system")
        # Delegate the remaining shape rules to the capacity invariants so the
        # proposal can never describe a window CGWO would reject.
        self.to_window()

    def to_window(self) -> CapacityWindow:
        """The CapacityWindow this proposal would create once confirmed."""
        return CapacityWindow(
            tenant_id=self.tenant_id,
            resource_ref=self.resource_ref,
            period_start=self.period_start,
            period_end=self.period_end,
            available_minutes=self.available_minutes,
            capacity_type=self.capacity_type,
        )
