"""Capacity allocation state machine with state-dependent data invariants.

Review findings F01/F02 (V002) are closed here (ADR-007):

* Every construction path — including direct dataclass construction and
  ``dataclasses.replace`` — enforces state-dependent invariants between
  ``allocated_minutes``, ``consumed_minutes`` and ``state``, so the state
  machine cannot be bypassed by building an impossible object.
* A single allocation can never claim more minutes than its capacity window
  offers. Aggregate/cross-allocation capacity governance (multiple
  allocations against one window/pool) is a DECLARED, unimplemented model —
  see RTM DOM-006 — and is deliberately NOT claimed by this module.

Quantity-bearing states (``PARTIALLY_CONSUMED``, ``CONSUMED``, ``OVERRUN``)
are reachable only through :func:`consume_allocation`; ``transition`` covers
pure lifecycle moves whose data remains consistent.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum

from cgwo_core.capacity import CapacityWindow
from cgwo_core.plan_item import InvalidTransitionError
from cgwo_core.tenancy import TenantContext, assert_same_tenant


class AllocationState(str, Enum):
    PROPOSED = "PROPOSED"
    RESERVED = "RESERVED"
    CONSUMING = "CONSUMING"
    PARTIALLY_CONSUMED = "PARTIALLY_CONSUMED"
    CONSUMED = "CONSUMED"
    RELEASED = "RELEASED"
    OVERRUN = "OVERRUN"


A = AllocationState

#: Lifecycle transitions whose data remains consistent (ADR-007).
#: CONSUMED and OVERRUN are reachable only via consume_allocation().
ALLOWED_TRANSITIONS: dict[AllocationState, frozenset[AllocationState]] = {
    A.PROPOSED: frozenset({A.RESERVED, A.RELEASED}),
    A.RESERVED: frozenset({A.CONSUMING, A.RELEASED}),
    A.CONSUMING: frozenset({A.PARTIALLY_CONSUMED, A.RELEASED}),
    A.PARTIALLY_CONSUMED: frozenset({A.CONSUMING, A.RELEASED}),
    A.CONSUMED: frozenset(),
    A.RELEASED: frozenset(),
    A.OVERRUN: frozenset({A.RELEASED}),
}

EVENT_BY_TARGET: dict[AllocationState, str] = {
    A.RESERVED: "CapacityReserved",
    A.OVERRUN: "CapacityOverrunDetected",
}

DEFAULT_EVENT = "CapacityAllocationChanged"
CONSUMPTION_EVENT = "TimeRecorded"

#: States from which recorded consumption is legal.
CONSUMABLE_STATES: frozenset[AllocationState] = frozenset(
    {A.RESERVED, A.CONSUMING, A.PARTIALLY_CONSUMED}
)


class AllocationInvariantError(ValueError):
    """Raised when an allocation violates a domain invariant."""


def _validate_allocation(
    tenant_id: str,
    window: CapacityWindow,
    plan_item_ref: str,
    allocated_minutes: int,
    consumed_minutes: int,
    state: AllocationState,
) -> None:
    if tenant_id != window.tenant_id:
        raise AllocationInvariantError("allocation tenant must match window tenant")
    if not plan_item_ref.strip():
        raise AllocationInvariantError("plan_item_ref must be non-blank")
    if allocated_minutes <= 0:
        raise AllocationInvariantError("allocated_minutes must be > 0")
    if consumed_minutes < 0:
        raise AllocationInvariantError("consumed_minutes must be >= 0")
    if allocated_minutes > window.available_minutes:
        raise AllocationInvariantError(
            "allocated_minutes must not exceed the capacity window's available_minutes"
        )
    # State-dependent invariants (ADR-007, review finding F01):
    if state in (A.PROPOSED, A.RESERVED) and consumed_minutes != 0:
        raise AllocationInvariantError(f"state {state.value} requires consumed_minutes == 0")
    if state is A.CONSUMING and consumed_minutes >= allocated_minutes:
        raise AllocationInvariantError(
            "state CONSUMING requires consumed_minutes < allocated_minutes"
        )
    if state is A.PARTIALLY_CONSUMED and not (0 < consumed_minutes < allocated_minutes):
        raise AllocationInvariantError(
            "state PARTIALLY_CONSUMED requires 0 < consumed_minutes < allocated_minutes"
        )
    if state is A.CONSUMED and consumed_minutes != allocated_minutes:
        raise AllocationInvariantError(
            "state CONSUMED requires consumed_minutes == allocated_minutes"
        )
    if state is A.OVERRUN and consumed_minutes <= allocated_minutes:
        raise AllocationInvariantError(
            "state OVERRUN requires consumed_minutes > allocated_minutes"
        )
    # RELEASED carries its final consumption history unchanged (including an
    # over-consumed history when released from OVERRUN); only the base
    # invariants above constrain it.


@dataclass(frozen=True, slots=True)
class AllocationChange:
    """Typed domain-change record for one allocation transition (ADR-008)."""

    event_type: str
    tenant_id: str
    plan_item_ref: str
    resource_ref: str
    previous_state: AllocationState
    new_state: AllocationState
    allocated_minutes: int
    consumed_minutes_before: int
    consumed_minutes_after: int
    allocation: CapacityAllocation


def transition_allocation(
    allocation: CapacityAllocation,
    target: AllocationState,
    ctx: TenantContext,
) -> AllocationChange:
    """Protected operation (ADR-009): apply one guarded lifecycle transition."""
    assert_same_tenant(ctx, allocation.tenant_id)
    if target not in ALLOWED_TRANSITIONS[allocation.state]:
        raise InvalidTransitionError(
            f"transition {allocation.state.value} -> {target.value} is not allowed"
        )
    moved = replace(allocation, state=target)
    return AllocationChange(
        event_type=EVENT_BY_TARGET.get(target, DEFAULT_EVENT),
        tenant_id=allocation.tenant_id,
        plan_item_ref=allocation.plan_item_ref,
        resource_ref=allocation.window.resource_ref,
        previous_state=allocation.state,
        new_state=target,
        allocated_minutes=allocation.allocated_minutes,
        consumed_minutes_before=allocation.consumed_minutes,
        consumed_minutes_after=moved.consumed_minutes,
        allocation=moved,
    )


def consume_allocation(
    allocation: CapacityAllocation,
    minutes: int,
    ctx: TenantContext,
) -> AllocationChange:
    """Protected operation: record consumption; derives the quantity state."""
    assert_same_tenant(ctx, allocation.tenant_id)
    if allocation.state not in CONSUMABLE_STATES:
        raise InvalidTransitionError(
            f"cannot record consumption from state {allocation.state.value}"
        )
    if minutes <= 0:
        raise AllocationInvariantError("consumed minutes must be > 0")
    total = allocation.consumed_minutes + minutes
    if total > allocation.allocated_minutes:
        target = A.OVERRUN
    elif total == allocation.allocated_minutes:
        target = A.CONSUMED
    else:
        target = A.PARTIALLY_CONSUMED
    consumed = replace(allocation, consumed_minutes=total, state=target)
    return AllocationChange(
        event_type=EVENT_BY_TARGET.get(target, CONSUMPTION_EVENT),
        tenant_id=allocation.tenant_id,
        plan_item_ref=allocation.plan_item_ref,
        resource_ref=allocation.window.resource_ref,
        previous_state=allocation.state,
        new_state=target,
        allocated_minutes=allocation.allocated_minutes,
        consumed_minutes_before=allocation.consumed_minutes,
        consumed_minutes_after=total,
        allocation=consumed,
    )


@dataclass(frozen=True, slots=True)
class CapacityAllocation:
    """Reservation of part of a CapacityWindow for a Plan Item."""

    tenant_id: str
    window: CapacityWindow
    plan_item_ref: str
    allocated_minutes: int
    consumed_minutes: int = 0
    state: AllocationState = AllocationState.PROPOSED

    def __post_init__(self) -> None:
        _validate_allocation(
            self.tenant_id,
            self.window,
            self.plan_item_ref,
            self.allocated_minutes,
            self.consumed_minutes,
            self.state,
        )

    def transition(self, target: AllocationState, ctx: TenantContext) -> AllocationChange:
        return transition_allocation(self, target, ctx)

    def consume(self, minutes: int, ctx: TenantContext) -> AllocationChange:
        return consume_allocation(self, minutes, ctx)
