"""Availability declarations and capacity windows (ADR-002 capacity types).

Protected operation vs pure value calculation (ADR-009): value-object
construction and pure comparisons such as :func:`windows_overlap` operate on
already-authorised objects and take no ``TenantContext``; operations that
*reveal or mutate* aggregate data across a boundary (e.g.
``AvailabilityDeclaration.guarded_window``) require an explicit context.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from enum import Enum

from cgwo_core.tenancy import TenantContext, assert_same_tenant


class CapacityType(str, Enum):
    """Generalised capacity kinds per ADR-002. Tenants may extend by policy later."""

    EXECUTION = "EXECUTION"
    SUPERVISORY = "SUPERVISORY"


class CapacityInvariantError(ValueError):
    """Raised when a capacity value object violates a domain invariant."""


def _validate_window(
    tenant_id: str,
    resource_ref: str,
    period_start: date,
    period_end: date,
    available_minutes: int,
) -> None:
    if not tenant_id.strip():
        raise CapacityInvariantError("tenant_id must be non-blank")
    if not resource_ref.strip():
        raise CapacityInvariantError("resource_ref must be non-blank")
    if period_end < period_start:
        raise CapacityInvariantError("period_end must not precede period_start")
    if available_minutes < 0:
        raise CapacityInvariantError("available_minutes must be >= 0")


def windows_overlap(one: CapacityWindow, other: CapacityWindow) -> bool:
    """Pure value comparison (ADR-009): do two windows compete for capacity?

    Windows in different tenants never compete; this is a domain fact about
    capacity pools, not an access-control decision.
    """
    if one.tenant_id != other.tenant_id:
        return False
    if one.resource_ref != other.resource_ref:
        return False
    if one.capacity_type is not other.capacity_type:
        return False
    return one.period_start <= other.period_end and other.period_start <= one.period_end


@dataclass(frozen=True, slots=True)
class CapacityWindow:
    """Realistic effort available for one resource, period and capacity type."""

    tenant_id: str
    resource_ref: str
    period_start: date
    period_end: date
    available_minutes: int
    capacity_type: CapacityType = CapacityType.EXECUTION

    def __post_init__(self) -> None:
        _validate_window(
            self.tenant_id,
            self.resource_ref,
            self.period_start,
            self.period_end,
            self.available_minutes,
        )

    def overlaps(self, other: CapacityWindow) -> bool:
        """Pure value comparison; see :func:`windows_overlap` (ADR-009)."""
        return windows_overlap(self, other)


def _validate_declaration(tenant_id: str, resource_ref: str, window: CapacityWindow) -> None:
    if tenant_id != window.tenant_id:
        raise CapacityInvariantError("declaration tenant must match window tenant")
    if resource_ref != window.resource_ref:
        raise CapacityInvariantError("declaration resource must match window resource")


@dataclass(frozen=True, slots=True)
class AvailabilityDeclaration:
    """A resource's statement of expected contribution for a window."""

    tenant_id: str
    resource_ref: str
    window: CapacityWindow
    declared_on: date

    def __post_init__(self) -> None:
        _validate_declaration(self.tenant_id, self.resource_ref, self.window)

    def guarded_window(self, ctx: TenantContext) -> CapacityWindow:
        """Protected operation (ADR-009): reveal the window only to its tenant."""
        assert_same_tenant(ctx, self.tenant_id)
        return self.window
