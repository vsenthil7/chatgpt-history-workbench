"""CGWO domain core — capacity/availability and planning state transitions.

Pure standard-library reference implementation per ADR-003 (Status: PROPOSED).
All Platform primitives are consumed as opaque references per ADR-006.
Capacity types generalise supervisory/review capacity per ADR-002.
Execution/tracker ownership per ADR-001. Allocation invariants per ADR-007.
Domain-change records per ADR-008. Isolation boundary per ADR-009.
"""

from cgwo_core.allocation import AllocationChange, AllocationState, CapacityAllocation
from cgwo_core.capacity import (
    AvailabilityDeclaration,
    CapacityType,
    CapacityWindow,
    windows_overlap,
)
from cgwo_core.contracts import (
    CONSUMER_CONTRACT_VERSION,
    AvailabilityProposal,
    ContractViolationError,
    TimeRecordProposal,
)
from cgwo_core.plan_item import (
    ChangeReasonRequiredError,
    InvalidTransitionError,
    PlanItem,
    PlanItemChange,
    PlanItemState,
)
from cgwo_core.tenancy import (
    CrossTenantAccessError,
    MissingTenantContextError,
    TenantContext,
    TenantIsolationError,
    assert_same_tenant,
)

__all__ = [
    "CONSUMER_CONTRACT_VERSION",
    "AllocationChange",
    "AllocationState",
    "AvailabilityDeclaration",
    "AvailabilityProposal",
    "CapacityAllocation",
    "CapacityType",
    "CapacityWindow",
    "ChangeReasonRequiredError",
    "ContractViolationError",
    "CrossTenantAccessError",
    "InvalidTransitionError",
    "MissingTenantContextError",
    "PlanItem",
    "PlanItemChange",
    "PlanItemState",
    "TenantContext",
    "TenantIsolationError",
    "TimeRecordProposal",
    "assert_same_tenant",
    "windows_overlap",
]
