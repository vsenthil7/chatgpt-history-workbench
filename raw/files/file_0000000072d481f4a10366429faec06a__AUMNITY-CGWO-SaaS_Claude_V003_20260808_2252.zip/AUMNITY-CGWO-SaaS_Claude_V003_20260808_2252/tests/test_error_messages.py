"""Anchored error-message assertions.

These exist for two reasons: error messages are part of the operator-facing
contract, and anchoring them (^...$) kills the string-literal mutants that
would otherwise survive mutation testing as noise (G07)."""

from datetime import date

import pytest
from tests.test_allocation import allocation
from tests.test_capacity import window

from cgwo_core.allocation import AllocationInvariantError
from cgwo_core.allocation import AllocationState as A
from cgwo_core.capacity import (
    AvailabilityDeclaration,
    CapacityInvariantError,
)
from cgwo_core.contracts import ContractViolationError, TimeRecordProposal
from cgwo_core.plan_item import (
    ChangeReasonRequiredError,
    InvalidTransitionError,
    PlanItem,
)
from cgwo_core.plan_item import (
    PlanItemState as S,
)
from cgwo_core.tenancy import (
    CrossTenantAccessError,
    MissingTenantContextError,
    TenantContext,
    assert_same_tenant,
)

CTX = TenantContext(tenant_id="t1")


def raises(exc, pattern):
    return pytest.raises(exc, match=f"^{pattern}$")


def test_tenancy_messages():
    with raises(MissingTenantContextError, "tenant_id is required and must be non-blank"):
        TenantContext(tenant_id=" ")
    with raises(MissingTenantContextError, "organisation_id, when provided, must be non-blank"):
        TenantContext(tenant_id="t1", organisation_id=" ")
    with raises(CrossTenantAccessError, "tenant context does not match aggregate owner tenant"):
        assert_same_tenant(CTX, "t2")


def test_capacity_window_messages():
    with raises(CapacityInvariantError, "tenant_id must be non-blank"):
        window(tenant_id=" ")
    with raises(CapacityInvariantError, "resource_ref must be non-blank"):
        window(resource_ref=" ")
    with raises(CapacityInvariantError, "period_end must not precede period_start"):
        window(period_end=date(2026, 7, 31))
    with raises(CapacityInvariantError, "available_minutes must be >= 0"):
        window(available_minutes=-1)


def test_availability_declaration_messages():
    with raises(CapacityInvariantError, "declaration tenant must match window tenant"):
        AvailabilityDeclaration(
            tenant_id="t2",
            resource_ref="actor-1",
            window=window(),
            declared_on=date(2026, 8, 1),
        )
    with raises(CapacityInvariantError, "declaration resource must match window resource"):
        AvailabilityDeclaration(
            tenant_id="t1",
            resource_ref="actor-2",
            window=window(),
            declared_on=date(2026, 8, 1),
        )


def test_plan_item_messages():
    with raises(ValueError, "tenant_id must be non-blank"):
        PlanItem(tenant_id=" ", work_object_ref="wo-1")
    with raises(ValueError, "work_object_ref must be non-blank"):
        PlanItem(tenant_id="t1", work_object_ref=" ")
    with raises(InvalidTransitionError, r"transition CANDIDATE -> STARTED is not allowed"):
        PlanItem(tenant_id="t1", work_object_ref="wo-1").transition(S.STARTED, CTX)
    with raises(
        ChangeReasonRequiredError,
        r"transition CANDIDATE -> DEFERRED requires a change reason",
    ):
        PlanItem(tenant_id="t1", work_object_ref="wo-1").transition(S.DEFERRED, CTX)


def test_allocation_messages():
    with raises(AllocationInvariantError, "allocation tenant must match window tenant"):
        allocation(tenant_id="t2")
    with raises(AllocationInvariantError, "plan_item_ref must be non-blank"):
        allocation(plan_item_ref=" ")
    with raises(AllocationInvariantError, "allocated_minutes must be > 0"):
        allocation(allocated=0)
    with raises(AllocationInvariantError, "consumed_minutes must be >= 0"):
        allocation(consumed=-1)
    with raises(
        AllocationInvariantError,
        "allocated_minutes must not exceed the capacity window's available_minutes",
    ):
        allocation(allocated=601)
    with raises(AllocationInvariantError, "state PROPOSED requires consumed_minutes == 0"):
        allocation(A.PROPOSED, consumed=5)
    with raises(AllocationInvariantError, "state RESERVED requires consumed_minutes == 0"):
        allocation(A.RESERVED, consumed=5)
    with raises(
        AllocationInvariantError,
        "state CONSUMING requires consumed_minutes < allocated_minutes",
    ):
        allocation(A.CONSUMING, consumed=120)
    with raises(
        AllocationInvariantError,
        "state PARTIALLY_CONSUMED requires 0 < consumed_minutes < allocated_minutes",
    ):
        allocation(A.PARTIALLY_CONSUMED, consumed=0)
    with raises(
        AllocationInvariantError,
        "state CONSUMED requires consumed_minutes == allocated_minutes",
    ):
        allocation(A.CONSUMED, consumed=119)
    with raises(
        AllocationInvariantError,
        "state OVERRUN requires consumed_minutes > allocated_minutes",
    ):
        allocation(A.OVERRUN, consumed=120)
    with raises(InvalidTransitionError, r"transition PROPOSED -> CONSUMING is not allowed"):
        allocation().transition(A.CONSUMING, CTX)
    with raises(InvalidTransitionError, "cannot record consumption from state PROPOSED"):
        allocation().consume(10, CTX)
    with raises(AllocationInvariantError, "consumed minutes must be > 0"):
        allocation(A.RESERVED).consume(0, CTX)


def test_contract_messages():
    with raises(ContractViolationError, "tenant_id must be non-blank"):
        TimeRecordProposal(tenant_id=" ", resource_ref="a", work_object_ref="w", minutes=1)
    with raises(ContractViolationError, "minutes must be > 0"):
        TimeRecordProposal(tenant_id="t1", resource_ref="a", work_object_ref="w", minutes=0)
