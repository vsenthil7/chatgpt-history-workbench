from datetime import date

import pytest

from cgwo_core.capacity import CapacityInvariantError, CapacityType
from cgwo_core.contracts import (
    CONSUMER_CONTRACT_VERSION,
    AvailabilityProposal,
    ContractViolationError,
    TimeRecordProposal,
)


def time_proposal(**kw):
    base = {
        "tenant_id": "t1",
        "resource_ref": "actor-1",
        "work_object_ref": "wo-1",
        "minutes": 30,
    }
    base.update(kw)
    return TimeRecordProposal(**base)


def test_contract_is_versioned():
    assert CONSUMER_CONTRACT_VERSION == "cgwo-consumer-v1"


def test_valid_time_record_proposal():
    proposal = time_proposal(narrative="stand-up follow-up work")
    assert proposal.minutes == 30
    assert proposal.source_system == "uraiflow"


@pytest.mark.parametrize(
    "kw",
    [
        {"tenant_id": " "},
        {"resource_ref": ""},
        {"work_object_ref": "  "},
        {"source_system": " "},
        {"minutes": 0},
        {"minutes": -10},
    ],
)
def test_time_record_proposal_violations_rejected(kw):
    with pytest.raises(ContractViolationError):
        time_proposal(**kw)


def availability_proposal(**kw):
    base = {
        "tenant_id": "t1",
        "resource_ref": "actor-1",
        "period_start": date(2026, 8, 1),
        "period_end": date(2026, 8, 5),
        "available_minutes": 300,
    }
    base.update(kw)
    return AvailabilityProposal(**base)


def test_valid_availability_proposal_converts_to_window():
    window = availability_proposal(capacity_type=CapacityType.SUPERVISORY).to_window()
    assert window.available_minutes == 300
    assert window.capacity_type is CapacityType.SUPERVISORY


def test_availability_proposal_rejects_windows_cgwo_would_reject():
    with pytest.raises(CapacityInvariantError):
        availability_proposal(period_end=date(2026, 7, 31))
    with pytest.raises(CapacityInvariantError):
        availability_proposal(available_minutes=-1)
    with pytest.raises(CapacityInvariantError):
        availability_proposal(tenant_id=" ")


def test_availability_proposal_requires_source_system():
    with pytest.raises(ContractViolationError):
        availability_proposal(source_system="  ")
