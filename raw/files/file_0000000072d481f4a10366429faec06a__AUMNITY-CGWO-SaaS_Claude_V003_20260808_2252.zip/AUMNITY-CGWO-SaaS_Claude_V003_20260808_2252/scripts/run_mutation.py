#!/usr/bin/env python3
"""Run mutation testing reproducibly and generate machine-readable evidence.

Review finding F09: this script captures the exact tool version, command,
raw output and per-survivor classification. Survivors are only 'accepted'
when listed with justification in scripts/mutation_acceptance.json (a
human-reviewed file); anything else is UNRESOLVED and fails the gate.

Usage: python3 scripts/run_mutation.py
Writes: evidence/mutation-raw-output.txt, evidence/mutation-results.txt,
        evidence/mutation-summary.json
Exit:   0 when every survivor is accepted, 1 otherwise.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
from importlib.metadata import version
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence"
ACCEPTANCE_FILE = ROOT / "scripts" / "mutation_acceptance.json"
COMMAND = [sys.executable, "-m", "mutmut", "run"]

shutil.rmtree(ROOT / "mutants", ignore_errors=True)
run = subprocess.run(COMMAND, cwd=ROOT, capture_output=True, text=True, check=False)
(EVIDENCE / "mutation-raw-output.txt").write_text(
    f"$ {' '.join(COMMAND)}\n\n{run.stdout}\n{run.stderr}", encoding="utf-8"
)
results = subprocess.run(
    [sys.executable, "-m", "mutmut", "results"],
    cwd=ROOT,
    capture_output=True,
    text=True,
    check=False,
)
(EVIDENCE / "mutation-results.txt").write_text(results.stdout, encoding="utf-8")

acceptance: dict[str, str] = json.loads(ACCEPTANCE_FILE.read_text(encoding="utf-8"))
survivors = re.findall(r"^\s*(\S+): survived$", results.stdout, re.MULTILINE)
no_tests = re.findall(r"^\s*(\S+): no tests$", results.stdout, re.MULTILINE)
emoji_counts = re.findall(r"(🎉|🫥|⏰|🤔|🙁|🔇)\s*(\d+)", run.stdout + run.stderr)
tally: dict[str, int] = {}
for emoji, count in emoji_counts:  # later occurrences win: final progress line
    tally[emoji] = int(count)
accepted = {s: acceptance[s] for s in survivors if s in acceptance}
unresolved = [s for s in survivors if s not in acceptance]

summary = {
    "tool": "mutmut",
    "tool_version": version("mutmut"),
    "command": " ".join(COMMAND),
    "config": "setup.cfg [mutmut]",
    "regenerate_with": "python3 scripts/run_mutation.py",
    "raw_output": "evidence/mutation-raw-output.txt",
    "results_listing": "evidence/mutation-results.txt",
    "tally_from_run_output": {
        "killed": tally.get("🎉", 0),
        "survived": tally.get("🙁", 0),
        "timeout": tally.get("⏰", 0),
        "suspicious": tally.get("🤔", 0),
        "skipped": tally.get("🔇", 0),
        "no_tests_listed": len(no_tests),
    },
    "accepted_survivors": accepted,
    "unresolved_survivors": unresolved,
    "gate_rule": "G07 requires unresolved_survivors == [] AND methods delegated "
    "to module-level functions so domain logic is actually mutated",
}
(EVIDENCE / "mutation-summary.json").write_text(
    json.dumps(summary, indent=1) + "\n", encoding="utf-8"
)
print(json.dumps(summary["tally_from_run_output"], indent=1))
print(f"accepted survivors: {len(accepted)}; unresolved: {len(unresolved)}")
sys.exit(0 if not unresolved else 1)
