# AT-Life Operating System (AT-LOS) - V015

**Release:** `AT-LifeOperatingSystem_PlatformProductBoundaryAndAuthorityIntegrity_Claude_V015_20260807_2335`
**Prepared by:** Claude · **07-Aug-2026 23:35 BST**

## First: what is actually coded

Your question deserves a direct answer, and the package now carries it as a register (`11_WhatIsCoded`).

**Coding has started on the generic platform. The AT-LOS product has not started.**

| | |
|---|---|
| `at-ingest-core` (L0) | **Implemented** — generic event and provenance contracts |
| `at-ingest-whatsapp` (L1) | **Implemented** — WhatsApp text → generic events |
| `at-store` (L1) | **Partial** — provenance model, **in-memory**, not durable |
| `at-cli` (L5) | **Implemented** — acceptance report; the only adapter consumer |
| identity, consent, evidence, questions, commitments, timeline | **Planned** — no code |
| `apps/atlos-api` (AT-LOS product) | **Planned** — declared, no code |
| Network API (HTTP/REST) | **Not started** — nothing listens on a port |

**"The API" means three different things** and they are now separated everywhere: the Python package API (partial), the platform network API (not started), the AT-LOS product API (not started).

## You can now check it yourself, without writing Python

```bash
python -m at_cli acceptance <whatsapp-export.txt>
```

Against your real consultant export: **283 source lines, 283 consumed, 182 events, 0 issues, RESULT PASS** — with re-ingest idempotency, a second importer, event provenance and revocation all shown.

It **fails** when a source line cannot be parsed. That is the point.

## 12 findings. All verified. All real.

**Finding 1 was the important one.** `architecture.toml` declared eleven packages and **no product application at all**, while every document called `apps/atlos-api` the product leaf. The one rule that keeps this platform reusable — *a generic package never depends on a product* — lived only in sentences for fifteen versions.

**ADR-015** declares product applications with a product, a state and an explicit allowed set. Four tested invariants (RTM-40–43). `apps/ipbs-ceaas` is declared **Vision only** deliberately: declaring a second product is what makes the boundary testable *before* the first product exists.

**The authoritative architecture still spoke the V012 consent model** — `require_consent()` raising "if no owner has a grant". Rewritten to subject + purpose. An importer is not an authority over a third party.

**`Participant.is_owner` survived two releases about "owner".** Renamed `matches_declared_export_identity` — a string match inside one export, nothing more. RTM-45 keeps it inside the adapter.

**Four releases of regex chasing prose figures ended.** V011 too few patterns, V012 widened, V013 a `-1` sentinel, V014 the form `39 parser + 19 store` that matched nothing. **Documents no longer contain typed figures** — each carries a generated FACTS block, and regex is demoted to detecting forbidden drift.

Also: branch coverage enabled (two unreachable branches removed rather than tested), and **DQ-014** opened for the application/use-case layer, deferred until a second consumer exists.

## Gates

Current figures are generated, not typed — see the FACTS block in the repository README. Summary: **117 passed, 1 skipped · 385 statements and 80 branches at 100% · 29 guards · 13/13 mutants · 4/4 standalone · ruff and mypy clean · release integrity 0 failures · 500 events reproduced.**

RTM: **43 passing + 1 skipped + 2 not enforced = 46.**

## One thing worth saying

The sentinel mutant **survived again**. My test accepted either of two failure messages, so a mutant disabling sentinel detection still passed. Second release running that mutation testing caught what the full suite did not.

## Next

`at-ingest-llm-export`, `at-store` durability, then `at-identity`. **`at-consent` stays blocked** on DQ-012 and DQ-013. No product app until DQ-014.

**AT-056 remains Not started.**
