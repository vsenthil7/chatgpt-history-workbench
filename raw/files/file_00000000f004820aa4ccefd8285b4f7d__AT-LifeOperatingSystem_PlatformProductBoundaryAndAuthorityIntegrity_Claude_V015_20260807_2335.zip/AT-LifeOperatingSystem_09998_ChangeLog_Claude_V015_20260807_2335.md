# AT-LOS V015 Change Log

**Release type:** platform/product boundary and authority integrity. One new ADR (015), amending ADR-014.

## Verified

12 findings raised. All 12 verified against the code before acceptance. None rejected.
Cumulative across seven reviews: **82 raised, 82 confirmed, 0 rejected.**

## ADR-015

- **Product applications declared** in `architecture.toml`: `apps/atlos-api` (AT-LOS, Planned) and `apps/ipbs-ceaas` (IPBS, Vision only), each with product, state, allowed set and must_not. Four guards (RTM-40–43).
- **`Participant.is_owner` → `matches_declared_export_identity`**; parser argument `owner` → `declared_export_identity`. RTM-45 keeps it inside the adapter.
- **Generated FACTS blocks.** `tools/gen_facts_block.py` renders every figure; documents contain none. Regex demoted to forbidden-drift detection (RTM-44).
- **`at-cli` implemented**: `python -m at_cli acceptance <export>` produces the human-readable acceptance report. 12 tests; fails on an unparseable line (RTM-46).

## Corrected

`docs/ARCHITECTURE.md` consent flow rewritten to subject + purpose · three meanings of "API" separated (§A0) · `Participant` contract row · TEST_STRATEGY figures now generated · release_check claim narrowed to what it verifies.

## Added

Branch coverage (`branch = true`); two unreachable branches removed rather than tested. `at-cli` added to the coverage target. CI gains a FACTS-block freshness job. DQ-014 opened for the application/use-case layer.

## Gates

117 passed, 1 skipped · 385 statements, 80 branches, 100% line and branch · 29 guards · 13/13 mutants · 4/4 standalone · ruff and mypy clean · release integrity 0 failures.

## Decisions

D-057 product boundary declared and enforced · D-058 no typed figures in documents · D-059 adapter-local identity fact renamed · D-060 branch coverage

## Not done

No product application code. `at-identity`, `at-consent`, `at-evidence` not started. Network API not started. **AT-056 remains Not started.**
