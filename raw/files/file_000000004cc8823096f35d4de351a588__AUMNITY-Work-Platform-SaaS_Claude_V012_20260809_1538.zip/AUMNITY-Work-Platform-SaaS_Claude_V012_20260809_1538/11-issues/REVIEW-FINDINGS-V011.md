# Independent Review Findings — V011 (ChatGPT deep review, 2026-08-09 14:24) and dispositions in V012

Source: full-package review and adversarial probes against the extracted
`AUMNITY-Work-Platform-SaaS_Claude_V011_20260809_1415.zip`
(sha256 `f81a296f69991a814d39adbbc6f73d885f029f6f781c3d6bb2526000da99c267`).
Rule applied: no finding may silently disappear. Dispositions in this file
were verified against the verbatim review text (DEF-037 packaging rule).

The review independently confirmed the V009/V010 blocker genuinely fixed
(the exact caught-inner-provision probe rerun: org-new absent, seeded
principal unchanged, outer pre-join work survives), the V009/V010 ledger
repair real, ADR-024 savepoint semantics implemented, and OD-001 correctly
still OPEN. Freeze decision: NO — one transaction-scope blocker remained.

| # | Finding | Disposition | Where |
|---|---|---|---|
| F1 | BLOCKER: savepoint atomicity was not scoped to the nested UnitOfWork's declared stores. Mutation permission came from the AMBIENT writable transaction, so a nested UoW declaring only {Organisation} could directly mutate a Principal covered by the outer transaction; its savepoint held no Principal snapshot. Executed: outer {Organisation, Principal}, nested {Organisation}, nested writes an Organisation and a Principal then raises, outer catches and commits — Organisation correctly rolled back, **Principal survived**. The generic UnitOfWork contract ("if the operation raises, NOTHING it wrote remains visible") was therefore still false for joined operations writing beyond their declared savepoint set. | **FIXED (current-scope enforcement, scope stack)** | ADR-025: the serialisation domain tracks the CURRENT nested writable scope as a scope/savepoint stack; store mutators are authorised against the current scope only, so the reviewer's Principal mutation is rejected AT THE WRITE; joins enforce nested scope ⊆ IMMEDIATE parent scope (not merely outermost coverage), so a second child coordinator on stores outside its immediate parent is rejected even when an ancestor covers them; whole-outer-snapshot-per-join was considered and rejected (in the ADR, as the review also directed). The exact executed probe and the second-child-coordinator escape attempt are permanent regressions asserting the rejected write AND zero surviving nested state: `TestNestedScopeMutationBoundaryRegression`; DEF-039; RTM TXN-007. |
| F2 | HIGH evidence/reporting drift: the V011 release response claimed **188 tests**; the shipped package contained **168** collected tests (80 unit + 15 contract + 73 isolation), all passing — packaged coverage (684 statements / 94 branches, 100%) and mutation (94/94 killed) evidence was genuine, but the headline count was hand-typed and wrong. | **FIXED (machine-derived release summary; discrepancy recorded openly)** | DEF-040 records 188-vs-168 as a defect rather than silently changing the number. G11 now derives a `release_summary` block into the release-validation sidecar from the extracted final ZIP itself: per-suite pytest collection counts, coverage statement/branch totals and mutation counts from the run-1 ladder evidence, and the ZIP entry count — computed before the final tree-digest comparison so the derivation is proven read-only. Release headline numbers are quoted from that block; hand-typed totals are prohibited. |

Preserved as the review directed: V011's savepoint fix (ADR-024), the
repaired V009/V010 ledgers, the ADR-023 attribution correction, DEF-037
accountability, the DEF-038 snapshot-purity contract, baseline byte-identity,
and OD-001 OPEN. Freeze remains the reviewer's call; V012 does not
self-declare it.
