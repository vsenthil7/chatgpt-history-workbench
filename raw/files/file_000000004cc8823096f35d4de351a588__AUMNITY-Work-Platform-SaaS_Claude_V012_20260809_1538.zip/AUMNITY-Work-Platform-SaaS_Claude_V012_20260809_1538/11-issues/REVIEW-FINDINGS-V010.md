# Independent Review Findings — V010 (ChatGPT deep review, 2026-08-09 13:51) and dispositions in V011

Source: full-package review and adversarial probes against the extracted
`AUMNITY-Work-Platform-SaaS_Claude_V010_20260809_1342.zip`
(sha256 `cba4f49ab800dd29738e6092e5ee3cea1a7e780b3d470db1d1fbbadc2b0e670a`).
Rule applied: no finding may silently disappear — and this file exists partly
because V010 broke that rule.

| # | Finding | Disposition | Where |
|---|---|---|---|
| F1 | BLOCKER: the ACTUAL V009 joined-transaction atomicity defect remained reproducible in shipped V010 (rerun executed: `org survived? True`) — no savepoint, no rollback-only marker; the shipped joined-provision regression proved only the inner-succeeds/outer-fails direction | **FIXED (savepoint semantics, generic)** | ADR-024; savepoint at every covered join in the generic UoW and the provisioner; the reviewer's exact caught-inner-failure probe and the generic multi-write variant are permanent regressions; DEF-036; RTM TXN-006 |
| F2 | RELEASE TRACEABILITY BLOCKER: `REVIEW-FINDINGS-V009.md` did not contain the actual 13:31 review — the real blocker and the LOW snapshot-purity finding silently disappeared while different findings (torn reads, TOCTOU) were misattributed to ChatGPT; "scope: exactly the V009 review" was therefore false | **FIXED (ledger repaired; misattribution corrected openly, not silently)** | `REVIEW-FINDINGS-V009.md` rewritten to faithfully preserve the actual review with a prominent correction notice; the torn-read/TOCTOU work (ADR-023, DEF-034/DEF-035) is retained on the reviewer's instruction and re-recorded below as Claude-initiated V010 hardening; source columns of DEF-034/DEF-035 corrected with explicit correction markers; kernel code comments' attributions corrected; ADR-023 carries an attribution-correction addendum; process defect DEF-037 records the root cause (disposition packaged from a compacted-context summary without verbatim-source verification) and the new packaging rule |

## Honest re-recording of the V010 hardening (kept per reviewer instruction)
ADR-023's read-consistency and validate→write atomicity work was genuine
engineering but was NOT requested by the V009 review: `UnitOfWork.read`
consistent multi-store reads; writable-mode mutation guard; full
validate→write sequences inside single write transactions. DEF-034/DEF-035
and RTM RD-001/RD-002 remain in force with corrected attribution.

Preserved: every prior fix, baseline byte-identity, OD-001 OPEN. Freeze
remains the reviewer's call.
