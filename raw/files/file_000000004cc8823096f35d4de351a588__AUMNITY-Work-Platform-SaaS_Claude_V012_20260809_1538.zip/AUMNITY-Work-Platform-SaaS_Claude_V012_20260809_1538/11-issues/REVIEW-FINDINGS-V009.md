# Independent Review Findings — V009 (ChatGPT deep review, 2026-08-09 13:31) and dispositions

> **LEDGER CORRECTION (V011, DEF-037).** The version of this file shipped in
> V010 did NOT contain the actual 13:31 ChatGPT review. It attributed two
> different findings (torn-read consistency; validate→write TOCTOU) to that
> review; those were in fact Claude-initiated V010 hardening, now recorded
> honestly in `REVIEW-FINDINGS-V010.md` as such. The actual review below was
> not carried forward, its BLOCKER went unfixed in V010, and the packaged
> claim "no finding may silently disappear" was thereby false. Root cause:
> Claude resumed from a compacted-context summary that misdescribed the
> review, and packaged dispositions without re-verifying them against the
> reviewer's verbatim text. This file is the faithful record; the process
> rule added in DEF-037 requires verbatim-source verification before any
> disposition is packaged.

Source: adversarial probes against the extracted
`AUMNITY-Work-Platform-SaaS_Claude_V009_20260809_1326.zip`
(sha256 `2b17033740daf3a2367579a2b2da2b15aeb1191508f9c77879aad43f4b50a073`).

| # | Actual finding (13:31 review) | Disposition | Where |
|---|---|---|---|
| F1 | BLOCKER: a joined/nested UnitOfWork operation loses its own atomicity when the outer caller CATCHES its failure — executed: outer identity UoW, nested `provision(org-new, founder=prn-dup)` joins, org write lands, founder write raises duplicate-id, outer catches and returns, outer commits → orphan organisation survives. Required savepoint or rollback-only semantics for the GENERIC joined UoW, not just the provisioner. | **FIXED in V011 (savepoint semantics chosen; NOT fixed in V010 — see DEF-036/DEF-037)** | ADR-024: on every covered join, the joining coordinator (generic `InMemoryUnitOfWork.run` AND `InMemoryTenantProvisioner.provision`) takes a savepoint — a local snapshot of its stores at the join point — and on failure restores ONLY its own writes and re-raises; the outer transaction may catch and continue, outer work before the join survives, and the generic UoW contract ("if the operation raises, nothing it wrote remains visible") now holds identically when joined. The exact executed probe is the permanent regression (`org-new` absent, seeded principal unchanged, outer work kept), plus the generic multi-write caught-failure regression and a joined-success-still-commits guard; DEF-036; RTM TXN-006 |
| F2 | LOW: explicitly state that adapter `snapshot()` must be side-effect-free/non-mutating while snapshot/restore remains the transaction mechanism | **FIXED in V011** | Adapter transaction contract stated at the domain-member mixin and in the `UnitOfWork` port docstring: `snapshot()` pure/non-mutating, `restore()` non-raising wholesale replacement; DEF-038 |

Preserved: every prior fix, baseline byte-identity, OD-001 OPEN. Freeze
remains the reviewer's call.
