"""Organisation (tenant) primitive, tenant-protected directory and admin provisioning.

Trust boundaries (ADR-013, V004 review Finding 1):
- `Organisation` is a value object (safe to publish).
- `OrganisationDirectory` is the PUBLISHED, tenant-PROTECTED service: every
  operation takes a TenantContext, binds the acting principal, and can only
  ever disclose the caller's own organisation. There is deliberately NO
  published operation that looks up an arbitrary organisation id.
- `PlatformProvisioning` is the TRUSTED PLATFORM-ADMIN boundary: creating
  tenants is an operator action performed before any tenant context exists.
  It is intentionally NOT exported from `aumnity_kernel.__all__` and must not
  be handed to untrusted application code, exactly like `AuditSink` (ADR-010).
"""

from dataclasses import dataclass
from datetime import datetime

from aumnity_contracts import (
    Clock,
    IdGenerator,
    NotFoundError,
    OrganisationId,
    PrincipalId,
    TenantContext,
    TenantIsolationError,
    require_identifier,
)

from aumnity_kernel.guards import require_identity, require_tenant_match
from aumnity_kernel.identity import Principal, PrincipalKind
from aumnity_kernel.ports import (
    OrganisationRepository,
    PrincipalRepository,
    TenantProvisioner,
    UnitOfWork,
)


@dataclass(frozen=True, slots=True)
class Organisation:
    """A tenant boundary: company, team, NGO, partner or client."""

    organisation_id: OrganisationId
    name: str
    created_at: datetime

    def __post_init__(self) -> None:
        require_identifier(self.organisation_id, "organisation_id")
        require_identifier(self.name, "name")


class OrganisationDirectory:
    """Published tenant-protected organisation/principal service (ADR-013).

    Implements the `PrincipalDirectory` port for the rest of the kernel.
    """

    def __init__(
        self,
        organisations: OrganisationRepository,
        principals: PrincipalRepository,
        unit_of_work: UnitOfWork,
        clock: Clock,
        ids: IdGenerator,
    ) -> None:
        self._organisations = organisations
        self._principals = principals
        self._unit_of_work = unit_of_work
        self._clock = clock
        self._ids = ids

    def get_organisation(self, context: TenantContext) -> Organisation:
        """Return the CALLER'S OWN organisation after binding the acting principal.

        No arbitrary-id lookup exists on the published surface (V004 review
        Finding 1): cross-tenant organisation metadata reads are impossible by
        construction, not merely denied.
        """

        def read() -> Organisation:
            self._require_member_in_transaction(context, context.principal_id)
            found = self._organisations.get(context.organisation_id)
            if found is None:  # pragma: no cover - unreachable once a member is bound
                raise NotFoundError(f"organisation not found: {context.organisation_id}")
            # ADR-002 addendum (V005 review F2): revalidate the returned identity —
            # a defective adapter returning a different organisation fails closed.
            require_identity(found.organisation_id, context.organisation_id, "organisation")
            return found

        return self._unit_of_work.read(read)

    def create_principal(
        self, context: TenantContext, kind: PrincipalKind, display_name: str
    ) -> Principal:
        def command() -> Principal:
            # ADR-022 (V008 review F1): this published write participates in
            # the stores' transaction regime, so a concurrent provisioning
            # rollback can never erase it. ADR-023 (V010 hardening, DEF-035): the
            # membership validation runs INSIDE the same write transaction as
            # the write — no observable point exists where the check has
            # passed but the write has not yet begun (no TOCTOU window).
            self._require_member_in_transaction(context, context.principal_id)
            principal = Principal(
                principal_id=PrincipalId(self._ids.new_id("prn")),
                organisation_id=context.organisation_id,
                kind=kind,
                display_name=display_name,
            )
            self._principals.add(principal)
            return principal

        return self._unit_of_work.run(command)

    def require_member(self, context: TenantContext, principal_id: PrincipalId) -> Principal:
        """Load a principal and prove it belongs to the context organisation.

        ADR-023: executes as a consistent read; joins any active transaction
        on this thread (registry commands bind membership inside their own
        write transactions).

        Unknown and foreign principals both raise TenantIsolationError so that
        probing another tenant's principal space is indistinguishable from
        referencing a principal that does not exist (ADR-002/ADR-006/ADR-007).
        """
        return self._unit_of_work.read(
            lambda: self._require_member_in_transaction(context, principal_id)
        )

    def _require_member_in_transaction(
        self, context: TenantContext, principal_id: PrincipalId
    ) -> Principal:
        found = self._principals.get(principal_id)
        if found is None:
            raise TenantIsolationError(f"principal not accessible: {principal_id}")
        # ADR-002 addendum (V005 review F3): membership proof requires BOTH the
        # returned identity to be the requested one AND tenancy to match; a
        # repository returning some other member for an arbitrary id must not
        # count as proof that the requested principal exists. The guard errors
        # are normalised to the single "not accessible" message so unknown,
        # foreign and wrong-row outcomes stay indistinguishable (no existence
        # oracle across tenants — ADR-007).
        try:
            require_identity(found.principal_id, principal_id, "principal")
            require_tenant_match(found.organisation_id, context, "principal")
        except TenantIsolationError as error:
            raise TenantIsolationError(f"principal not accessible: {principal_id}") from error
        return found


class PlatformProvisioning:
    """TRUSTED platform-operator boundary: tenant creation (ADR-011/ADR-013).

    Not part of the published kernel API. Provisioning happens before a tenant
    context can exist, so these operations are unscoped by nature and must be
    reachable only by platform composition code.
    """

    def __init__(self, provisioner: TenantProvisioner, clock: Clock, ids: IdGenerator) -> None:
        self._provisioner = provisioner
        self._clock = clock
        self._ids = ids

    def create_organisation(
        self, name: str, founder_display_name: str, founder_kind: PrincipalKind
    ) -> tuple[Organisation, Principal]:
        """Create a tenant and its founding principal as one all-or-nothing unit.

        Atomicity is the TenantProvisioner adapter's contract (ADR-011): both
        aggregates go through ONE port call; the registry never sequences
        independent repository writes for bootstrap.
        """
        organisation = Organisation(
            organisation_id=OrganisationId(self._ids.new_id("org")),
            name=name,
            created_at=self._clock.now(),
        )
        founder = Principal(
            principal_id=PrincipalId(self._ids.new_id("prn")),
            organisation_id=organisation.organisation_id,
            kind=founder_kind,
            display_name=founder_display_name,
        )
        self._provisioner.provision(organisation, founder)
        return organisation, founder
