"""Work Object registry: the tenant-scoped application service of the kernel.

Every protected operation takes TenantContext first (ADR-002). Every state
change increments the aggregate version, appends to its history, emits a
baseline-named domain event and records it in the audit trail (baseline
doc 09: "Every transition is policy-validated, audit-recorded and versioned").
"""

from collections.abc import Callable
from dataclasses import replace

from aumnity_contracts import (
    EventEnvelope,
    EvidenceId,
    InvalidTransitionError,
    NotFoundError,
    PolicyViolationError,
    PrincipalId,
    TenantContext,
    ValidationError,
    WorkObjectId,
)
from aumnity_contracts.providers import Clock, IdGenerator

from aumnity_kernel.audit import AuditLog
from aumnity_kernel.evidence import EvidenceKind, EvidenceRecord
from aumnity_kernel.guards import require_identity, require_tenant_match
from aumnity_kernel.policy import CompletionPolicy
from aumnity_kernel.ports import (
    EvidenceRepository,
    PrincipalDirectory,
    UnitOfWork,
    WorkObjectRepository,
)
from aumnity_kernel.workobject.model import Priority, RiskLevel, WorkObject
from aumnity_kernel.workobject.state import (
    BLOCKABLE_STATES,
    EVIDENCE_OPEN_STATES,
    WorkObjectState,
    assert_transition,
)

# Transition -> baseline event name (doc 09). Events not yet emitted by this
# slice (AssignmentRequested, ActorMatched, SLAAtRisk, capacity/knowledge
# events) belong to deferred modules and are declared in the RTM.
_TRANSITION_EVENTS: dict[WorkObjectState, str] = {
    WorkObjectState.READY: "WorkObjectReady",
    WorkObjectState.ASSIGNED: "WorkObjectAssigned",
    WorkObjectState.IN_PROGRESS: "WorkStarted",
    WorkObjectState.OUTPUT_SUBMITTED: "OutputSubmitted",
    WorkObjectState.REVIEW: "ReviewRequested",
    WorkObjectState.APPROVED: "ApprovalGranted",
    WorkObjectState.REJECTED: "ReviewCompleted",
    WorkObjectState.REWORK: "ReworkRequested",
    WorkObjectState.COMPLETED: "WorkCompleted",
    WorkObjectState.BLOCKED: "WorkBlocked",
    WorkObjectState.CANCELLED: "WorkCancelled",
    WorkObjectState.PAUSED: "WorkPaused",
    WorkObjectState.ASSIGNABLE: "WorkObjectAssignable",
    WorkObjectState.ARCHIVED: "WorkObjectArchived",
}


TransitionMutation = Callable[[WorkObject], WorkObject]


class WorkObjectRegistry:
    """Tenant-scoped operations over Work Objects.

    ADR-007: every protected operation first binds the context — proving the
    acting principal belongs to the context organisation — and every principal
    reference an operation accepts (owner, assignee) is proven to be a member
    of the same organisation. Foreign or unknown principals raise
    TenantIsolationError (V002 review Findings 1 and 2).
    """

    def __init__(
        self,
        work_objects: WorkObjectRepository,
        evidence: EvidenceRepository,
        audit: AuditLog,
        completion_policy: CompletionPolicy,
        principals: PrincipalDirectory,
        unit_of_work: UnitOfWork,
        clock: Clock,
        ids: IdGenerator,
    ) -> None:
        self._work_objects = work_objects
        self._evidence = evidence
        self._audit = audit
        self._completion_policy = completion_policy
        self._principals = principals
        self._unit_of_work = unit_of_work
        self._clock = clock
        self._ids = ids

    def _bind(self, context: TenantContext) -> None:
        """Prove the acting principal is a member of the context organisation."""
        self._principals.require_member(context, context.principal_id)

    def _require_reference_integrity(self, context: TenantContext, work_object: WorkObject) -> None:
        """ADR-020 (V006 review F3): the defective-adapter invariant covers the
        WHOLE aggregate, not just its shell — every embedded principal
        reference must be a proven member of the context organisation before
        the aggregate is disclosed or acted on, so a hostile repository cannot
        launder foreign requester/owner/assignee references through a
        correctly-keyed row."""
        self._principals.require_member(context, work_object.requester_id)
        self._principals.require_member(context, work_object.owner_id)
        if work_object.assignee_id is not None:
            self._principals.require_member(context, work_object.assignee_id)

    # -- retrieval ---------------------------------------------------------

    def get(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        """Load a work object, revalidating identity AND tenancy in the kernel.

        ADR-002 addendum (V005 review F2/F3): every repository-returned
        aggregate is revalidated — a defective adapter returning a foreign or
        wrong-id aggregate fails closed instead of leaking. ADR-023 (V010 hardening): the load
        (aggregate + reference-integrity lookups) is one consistent read.
        """
        return self._unit_of_work.read(lambda: self._get_in_transaction(context, work_object_id))

    def _get_in_transaction(
        self, context: TenantContext, work_object_id: WorkObjectId
    ) -> WorkObject:
        self._bind(context)
        found = self._work_objects.get(work_object_id)
        if found is None:
            raise NotFoundError(f"work object not found: {work_object_id}")
        require_identity(found.work_object_id, work_object_id, "work object")
        require_tenant_match(found.organisation_id, context, "work object")
        self._require_reference_integrity(context, found)
        return found

    def children(self, context: TenantContext, parent_id: WorkObjectId) -> tuple[WorkObject, ...]:
        """List children; EVERY returned aggregate is revalidated (V005 F2).
        The parent load and every child load form ONE consistent read (ADR-023)."""

        def read() -> tuple[WorkObject, ...]:
            parent = self._get_in_transaction(context, parent_id)
            children = tuple(self._work_objects.children_of(parent.work_object_id))
            for child in children:
                require_tenant_match(child.organisation_id, context, "child work object")
                require_identity(
                    str(child.parent_id), parent.work_object_id, "child work object parentage"
                )
                self._require_reference_integrity(context, child)
            return children

        return self._unit_of_work.read(read)

    def evidence_for(
        self, context: TenantContext, work_object_id: WorkObjectId
    ) -> tuple[EvidenceRecord, ...]:
        """Load evidence; each record's tenancy and linkage is revalidated
        (V005 F2). ADR-023 (V010 hardening, DEF-034): the parent load and every record
        load execute inside ONE read transaction, so a concurrent
        attach_evidence commit can never land in between — the executed torn
        cross-store view is impossible.
        """

        def read() -> tuple[EvidenceRecord, ...]:
            work_object = self._get_in_transaction(context, work_object_id)
            records: list[EvidenceRecord] = []
            for evidence_id in work_object.evidence_ids:
                record = self._evidence.get(evidence_id)
                if record is None:
                    raise NotFoundError(f"evidence not found: {evidence_id}")
                require_identity(record.evidence_id, evidence_id, "evidence record")
                require_tenant_match(record.organisation_id, context, "evidence record")
                require_identity(
                    record.work_object_id, work_object.work_object_id, "evidence linkage"
                )
                self._principals.require_member(context, record.submitted_by)
                records.append(record)
            return tuple(records)

        return self._unit_of_work.read(read)

    # -- creation ----------------------------------------------------------

    def create(
        self,
        context: TenantContext,
        *,
        title: str,
        purpose: str,
        work_type: str,
        priority: Priority,
        risk_level: RiskLevel,
        owner_id: PrincipalId,
        parent_id: WorkObjectId | None = None,
    ) -> WorkObject:
        """Create a Work Object in DRAFT; with parent_id, this is decomposition.

        ADR-023 (V010 hardening, DEF-035): the ENTIRE validate→write sequence — context
        binding, owner membership, parent load, persistence and audit — runs
        inside one write transaction, so no concurrent commit or rollback can
        interleave between validation and write (no TOCTOU window).
        """

        def command() -> WorkObject:
            self._bind(context)
            self._principals.require_member(context, owner_id)
            parent: WorkObject | None = None
            if parent_id is not None:
                parent = self._get_in_transaction(context, parent_id)
            now = self._clock.now()
            work_object = WorkObject(
                work_object_id=WorkObjectId(self._ids.new_id("wob")),
                organisation_id=context.organisation_id,
                title=title,
                purpose=purpose,
                work_type=work_type,
                state=WorkObjectState.DRAFT,
                priority=priority,
                risk_level=risk_level,
                requester_id=context.principal_id,
                owner_id=owner_id,
                created_at=now,
                updated_at=now,
                parent_id=parent.work_object_id if parent is not None else None,
            )
            work_object.history = ((1, "WorkObjectCreated", now),)
            self._work_objects.create(work_object)
            self._emit(context, work_object, "WorkObjectCreated", {})
            if parent is not None:
                self._emit(
                    context,
                    parent,
                    "WorkObjectDecomposed",
                    {"child_work_object_id": work_object.work_object_id},
                )
            return work_object

        return self._unit_of_work.run(command)

    # -- lifecycle ---------------------------------------------------------

    def mark_ready(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.READY)

    def mark_assignable(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.ASSIGNABLE)

    def assign(
        self,
        context: TenantContext,
        work_object_id: WorkObjectId,
        assignee_id: PrincipalId,
    ) -> WorkObject:
        """Minimal direct assignment to a principal (capability matching: deferred D02/D03)."""
        self._principals.require_member(context, assignee_id)
        return self._transition(
            context,
            work_object_id,
            WorkObjectState.ASSIGNED,
            mutate=lambda wo: replace(wo, assignee_id=assignee_id),
            payload={"assignee_id": assignee_id},
        )

    def start_work(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.IN_PROGRESS)

    def pause(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.PAUSED)

    def resume(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        work_object = self.get(context, work_object_id)
        if work_object.state is not WorkObjectState.PAUSED:
            raise InvalidTransitionError("resume is only permitted from PAUSED")
        return self._transition(context, work_object_id, WorkObjectState.IN_PROGRESS)

    def block(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        work_object = self.get(context, work_object_id)
        if work_object.state not in BLOCKABLE_STATES:
            raise InvalidTransitionError(f"block is not permitted from {work_object.state.value}")
        return self._transition(
            context,
            work_object_id,
            WorkObjectState.BLOCKED,
            mutate=lambda wo: replace(wo, blocked_from=work_object.state),
        )

    def unblock(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        work_object = self.get(context, work_object_id)
        if work_object.blocked_from is None:
            raise InvalidTransitionError("work object is not blocked")
        return self._transition(
            context,
            work_object_id,
            work_object.blocked_from,
            mutate=lambda wo: replace(wo, blocked_from=None),
            event_override="WorkObjectUnblocked",
        )

    def submit_output(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.OUTPUT_SUBMITTED)

    def request_review(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.REVIEW)

    def approve(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.APPROVED)

    def reject(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.REJECTED)

    def request_rework(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.REWORK)

    def restart_after_rework(
        self, context: TenantContext, work_object_id: WorkObjectId
    ) -> WorkObject:
        work_object = self.get(context, work_object_id)
        if work_object.state is not WorkObjectState.REWORK:
            raise InvalidTransitionError("restart_after_rework is only permitted from REWORK")
        return self._transition(context, work_object_id, WorkObjectState.IN_PROGRESS)

    def complete(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        """Complete approved work; the completion policy gates this transition.

        ADR-016/DEF-023 (V005 review F4): the policy receives VERIFIED evidence
        records resolved by the registry — a dangling id, a foreign record or a
        record linked to a different work object blocks completion instead of
        counting as evidence.
        """

        def command() -> WorkObject:
            work_object = self._get_in_transaction(context, work_object_id)
            assert_transition(work_object.state, WorkObjectState.COMPLETED)
            verified = self._verified_evidence(context, work_object)
            violations = self._completion_policy.violations(work_object, verified)
            if violations:
                raise PolicyViolationError("; ".join(violations))
            return self._transition(
                context,
                work_object_id,
                WorkObjectState.COMPLETED,
                mutate=lambda wo: replace(wo, completed_at=self._clock.now()),
            )

        return self._unit_of_work.run(command)

    def cancel(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.CANCELLED)

    def archive(self, context: TenantContext, work_object_id: WorkObjectId) -> WorkObject:
        return self._transition(context, work_object_id, WorkObjectState.ARCHIVED)

    # -- evidence ----------------------------------------------------------

    def attach_evidence(
        self,
        context: TenantContext,
        work_object_id: WorkObjectId,
        *,
        kind: EvidenceKind,
        uri: str,
        content_sha256: str,
        source_system: str,
        source_reference: str,
    ) -> EvidenceRecord:
        """Attach an immutable evidence record while the work object is open.

        ADR-023 (V010 hardening, DEF-035): load, state validation, record
        construction, persistence and audit run inside ONE write transaction.
        """

        def command() -> EvidenceRecord:
            work_object = self._get_in_transaction(context, work_object_id)
            if work_object.state not in EVIDENCE_OPEN_STATES:
                raise ValidationError(
                    f"evidence cannot be attached in state {work_object.state.value}"
                )
            record = EvidenceRecord(
                evidence_id=EvidenceId(self._ids.new_id("evd")),
                organisation_id=context.organisation_id,
                work_object_id=work_object.work_object_id,
                kind=kind,
                uri=uri,
                content_sha256=content_sha256,
                submitted_by=context.principal_id,
                submitted_at=self._clock.now(),
                source_system=source_system,
                source_reference=source_reference,
            )
            updated = replace(
                work_object,
                evidence_ids=work_object.evidence_ids + (record.evidence_id,),
            )
            self._evidence.add(record)
            self._bump_and_save(updated, "EvidenceAdded")
            self._emit(context, updated, "EvidenceAdded", {"evidence_id": record.evidence_id})
            return record

        return self._unit_of_work.run(command)

    # -- internals ---------------------------------------------------------

    def _transition(
        self,
        context: TenantContext,
        work_object_id: WorkObjectId,
        target: WorkObjectState,
        *,
        mutate: TransitionMutation | None = None,
        payload: dict[str, str] | None = None,
        event_override: str | None = None,
    ) -> WorkObject:
        def command() -> WorkObject:
            # ADR-023: read, validate and write are ONE transaction — no
            # concurrent commit can interleave between the load and the save.
            work_object = self._get_in_transaction(context, work_object_id)
            assert_transition(work_object.state, target)
            updated = replace(work_object, state=target)
            if mutate is not None:
                updated = mutate(updated)
            event_type = (
                event_override if event_override is not None else _TRANSITION_EVENTS[target]
            )
            self._bump_and_save(updated, event_type)
            self._emit(context, updated, event_type, payload if payload is not None else {})
            return updated

        return self._unit_of_work.run(command)

    def _bump_and_save(self, work_object: WorkObject, event_type: str) -> None:
        now = self._clock.now()
        expected_version = work_object.version  # the version this command read
        work_object.version = work_object.version + 1
        work_object.updated_at = now
        work_object.history = work_object.history + ((work_object.version, event_type, now),)
        # ADR-017: expected-version update — a concurrent writer between this
        # command's read and write surfaces as ConcurrencyError, never as a
        # silent lost update.
        self._work_objects.update(work_object, expected_version=expected_version)

    def _verified_evidence(
        self, context: TenantContext, work_object: WorkObject
    ) -> tuple[EvidenceRecord, ...]:
        """Resolve every referenced evidence id to a verified record (DEF-023)."""
        records: list[EvidenceRecord] = []
        for evidence_id in work_object.evidence_ids:
            record = self._evidence.get(evidence_id)
            if record is None:
                raise PolicyViolationError(f"evidence reference cannot be verified: {evidence_id}")
            require_identity(record.evidence_id, evidence_id, "evidence record")
            require_tenant_match(record.organisation_id, context, "evidence record")
            if record.work_object_id != work_object.work_object_id:
                raise PolicyViolationError("evidence record does not belong to this work object")
            self._principals.require_member(context, record.submitted_by)
            records.append(record)
        return tuple(records)

    def _emit(
        self,
        context: TenantContext,
        work_object: WorkObject,
        event_type: str,
        payload: dict[str, str],
    ) -> None:
        self._audit.record(
            context,
            EventEnvelope(
                event_type=event_type,
                organisation_id=context.organisation_id,
                actor_principal_id=context.principal_id,
                subject_id=work_object.work_object_id,
                subject_version=work_object.version,
                occurred_at=self._clock.now(),
                payload=payload,
            ),
        )
