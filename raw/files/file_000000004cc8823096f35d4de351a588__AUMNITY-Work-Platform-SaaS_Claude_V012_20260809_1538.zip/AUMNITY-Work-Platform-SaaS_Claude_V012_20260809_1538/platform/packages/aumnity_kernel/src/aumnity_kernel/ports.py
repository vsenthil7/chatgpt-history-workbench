"""Kernel ports (ADR-002). Adapters implement these; the kernel owns semantics.

Annotations are deferred (PEP 563) and domain types imported only for type
checking to keep ports free of import cycles with the aggregates they store.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Protocol, TypeVar

if TYPE_CHECKING:
    from collections.abc import Iterable

    from aumnity_contracts import (
        EventEnvelope,
        EvidenceId,
        OrganisationId,
        PrincipalId,
        TenantContext,
        WorkObjectId,
    )

    from aumnity_kernel.evidence import EvidenceRecord
    from aumnity_kernel.identity import Principal
    from aumnity_kernel.organisation import Organisation
    from aumnity_kernel.workobject.model import WorkObject


class TenantProvisioner(Protocol):
    """Atomic tenant bootstrap (ADR-011, V003 review Finding 3).

    Contract: persist the organisation AND its founding principal as one
    all-or-nothing unit. If either write fails, NEITHER may remain visible.
    Atomicity lives here — at the adapter, where transactions actually exist —
    not in registry-level sequencing over independent repositories. The future
    PostgreSQL adapter implements this as a single database transaction; the
    in-memory adapter implements compensating rollback.
    """

    def provision(self, organisation: Organisation, founder: Principal) -> None: ...


_T = TypeVar("_T")


class OrganisationRepository(Protocol):
    def add(self, organisation: Organisation) -> None: ...
    def get(self, organisation_id: OrganisationId) -> Organisation | None: ...


class PrincipalRepository(Protocol):
    def add(self, principal: Principal) -> None: ...
    def get(self, principal_id: PrincipalId) -> Principal | None: ...


class PrincipalDirectory(Protocol):
    """Membership proof for principal references (ADR-007, DW-FR-013/TEN-001).

    Implementations must raise TenantIsolationError when the principal does not
    exist or belongs to a different organisation than the context.
    """

    def require_member(self, context: TenantContext, principal_id: PrincipalId) -> Principal: ...


class WorkObjectRepository(Protocol):
    def create(self, work_object: WorkObject) -> None:
        """Persist a NEW aggregate; an existing id must be rejected (ADR-017)."""
        ...

    def update(self, work_object: WorkObject, *, expected_version: int) -> None:
        """Replace iff the stored version equals expected_version, else raise
        ConcurrencyError (optimistic concurrency, ADR-017)."""
        ...

    def get(self, work_object_id: WorkObjectId) -> WorkObject | None: ...
    def children_of(self, parent_id: WorkObjectId) -> Iterable[WorkObject]: ...


class EvidenceRepository(Protocol):
    def add(self, record: EvidenceRecord) -> None: ...
    def get(self, evidence_id: EvidenceId) -> EvidenceRecord | None: ...


class UnitOfWork(Protocol):
    """Command transaction boundary (ADR-016, V005 review F1).

    Contract: run the operation such that ALL persistence it performs
    commits atomically; if the operation raises, NOTHING it wrote remains
    visible, and the original exception propagates. This holds EQUALLY when
    the operation joins an enclosing transaction: a joined failure rolls back
    to its join point (savepoint semantics, ADR-024), so an outer caller may
    catch the failure and continue without ever observing partial nested
    writes. For that promise to be MECHANICAL rather than a caller
    convention, the declared participating stores are themselves the write
    scope (ADR-025): while the operation runs — joined or not — a mutation
    of any store the unit of work did not declare is rejected at the write,
    because no savepoint of this unit of work could protect it; and a nested
    unit of work may declare only a subset of its immediate parent's stores.
    Adapter obligations: snapshot acquisition must be pure and
    non-mutating; restore must be non-raising (DEF-038). Transactional
    persistence adapters implement this with a database transaction; the
    in-memory adapter implements snapshot/restore over the participating
    stores.
    """

    def run(self, operation: Callable[[], _T]) -> _T: ...

    def read(self, operation: Callable[[], _T]) -> _T:
        """Execute a consistent multi-store read: no concurrent commit may land
        between the operation's constituent loads (ADR-023); mutation inside is
        rejected. Joins an already-active transaction on this thread."""
        ...


class AuditSink(Protocol):
    def append(self, event: EventEnvelope) -> None: ...
    def all_events(self) -> Iterable[EventEnvelope]: ...
