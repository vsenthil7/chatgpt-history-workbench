# Handoff for Independent ChatGPT Review — Claude build V011 (correction release)

Scope: exactly the V010 review (13:51) — the carried-forward nested-atomicity
blocker and the traceability repair. No feature tranche; freeze not
self-declared. Dispositions: `11-issues/REVIEW-FINDINGS-V010.md`, and the
REPAIRED `11-issues/REVIEW-FINDINGS-V009.md` now faithfully carrying the
actual 13:31 review. OD-001 OPEN.

## What went wrong, plainly
V010 dispositioned findings the 13:31 review never made (torn reads, TOCTOU —
in fact Claude-initiated hardening) and attributed them to ChatGPT, while the
review's actual BLOCKER (caught nested failure commits partial nested writes)
went unfixed and its LOW finding (snapshot purity) undocumented. Root cause:
dispositions were packaged from a compacted-context summary instead of the
reviewer's verbatim text. Recorded as process defect DEF-037 with a new
packaging rule: disposition files are verified against the verbatim source
review before release; a summary is never an acceptable source.

## Product changes (0.9.0 → 0.10.0)
- ADR-024 (DEF-036): SAVEPOINT semantics on every covered join, generic —
  `InMemoryUnitOfWork.run` and `InMemoryTenantProvisioner.provision` snapshot
  their stores at the join point and, on failure, restore ONLY their own
  writes and re-raise; the outer transaction may catch and continue; outer
  pre-join work survives; nested joins nest. Rollback-only considered and
  rejected in the ADR. PostgreSQL mapping: SAVEPOINT/ROLLBACK TO SAVEPOINT.
- DEF-038: adapter transaction contract now states snapshot() must be pure/
  non-mutating and restore() non-raising (mixin + UnitOfWork port docstring).
- DEF-037 ledger repair: faithful V009 findings file with correction notice;
  V010 hardening re-recorded honestly; DEF-034/DEF-035 sources corrected with
  explicit markers; code-comment attributions fixed; ADR-023 correction
  addendum. ADR-023's implementation is retained per reviewer instruction.

## Regression protection (the exact mandated probes)
`outer identity UoW → joined provision writes org-new → founder prn-dup
duplicate fails → outer catches ValidationError → outer returns normally` ⇒
org-new ABSENT, seeded principal unchanged, outer's own pre-join write
SURVIVES (V010 printed `org survived? True` here). Generic joined multi-write:
write #1 lands, write #2 raises, outer catches, outer commits ⇒ zero nested
effects, outer work kept. Joined success still commits with the outer
transaction.

## How to verify
```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r platform/requirements-dev.txt
cd platform && PYTHONHASHSEED=0 python3 scripts/gates/run_gates.py release   # twice — identical
```
Counts in evidence only (DOC C2); pip freeze, double-ladder idempotence and
tree digests in `evidence/g11_packaging.json` + sidecar.

## Honest notes
- ADR-023 (reads/validate-write) retained with corrected attribution.
- SEC-001, AUD-004, RD-002, INF-001 and external mutation tooling remain
  declared. Reads serialise with writers in-memory (MVCC arrives with
  INF-001).
