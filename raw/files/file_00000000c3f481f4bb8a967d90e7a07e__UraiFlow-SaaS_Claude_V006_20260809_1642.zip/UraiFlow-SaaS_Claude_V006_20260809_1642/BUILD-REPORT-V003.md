# Build Report — UraiFlow SaaS V003 (Claude corrective build)

**Input:** `UraiFlow-SaaS_Claude_V002_20260808_2231.zip` + ChatGPT deep review (2026-08-08 22:38)
**Product version:** 0.9.0.dev0 · **Python:** ≥3.11 (built on 3.12) · **Runtime deps in `src/`:** none (guard-enforced)

V003 is the architecture/invariant-hardening release requested by the review — not a
mutation-only release. All exact counts below come from machine-generated evidence in
`evidence/`; the packaged narrative quotes no manifest counts (PKG-003).

## Review findings — dispositions

| Finding | Disposition | Where |
|---|---|---|
| P0-1 domain semantics in reusable extractor | **FIXED** — generic `ConfigurableRuleExtractor` (no default rules) in core; workforce rules are an acceptance fixture (`tests/fixtures/workforce_rules.py`); structural guards + domain-token tripwire | ADR-0005; RTM DOM-001 |
| P0-2 mutation before transition validation | **FIXED** — aggregate-owned atomic commands; eligibility checked pre-mutation; snapshot-equality regressions incl. the reviewer's REJECTED+confirm_all repro | ADR-0006; RTM INV-001 |
| P0-3 terminal proposals editable | **FIXED** — exhaustive eligibility matrix across all statuses | ADR-0006; RTM INV-002 |
| P0-4 unknown confirm_selected ids silently ignored | **FIXED** — ids validated before any change; KeyError names unknown ids | ADR-0006; RTM INV-003 |
| P0-5 edits skip revalidation | **FIXED** — edit ⇒ `needs_revalidation`; confirmation blocked (`RevalidationRequiredError`) until `Pipeline.revalidate`; invalid items unconfirmable | ADR-0006; RTM INV-004 |
| P0-6 only UraiFlowError compensated | **FIXED** — adapter boundary catches `Exception` (never BaseException), normalises `"<adapter>: <Type>: <msg>"`, preserved in outcome + lineage; TimeoutError scenario tested | ADR-0007 §1; RTM CMP-001 |
| P0-7 rollback failure ungoverned | **FIXED** — `COMMIT_FAILED → COMPENSATING → {ROLLED_BACK, COMPENSATION_FAILED}`; all rollbacks attempted; failures collected in `CommitOutcome.compensation_failures` + `record.rollback_failed` lineage; ROLLED_BACK only when all compensations succeed; commit-fails + rollback-fails scenario tested | ADR-0007 §2; RTM CMP-002 |
| P0-8 supports_rollback unenforced | **FIXED** — preflight before COMMITTING for >1 record; refusal leaves proposal unchanged with `proposal.commit_preflight_failed` lineage; single-record exemption documented + tested; boundary (exactly 2 records) mutation-tested | ADR-0007 §3; RTM CMP-003 |
| P0-9 registry accepts malformed adapters | **FIXED** — shared `validate_descriptor` at registration and in the harness; 4 malformed-descriptor tests | ADR-0007 §4; RTM ADP-001 |
| P1-1 packaging not self-contained | **FIXED** — `pyproject.toml` (setuptools src layout, dev extras); `pip install -e .[dev]`; plain `python -m pytest` passes; canonical `python scripts/run_gates.py` (no Unix `PYTHONPATH`) | ADR-0009; RTM PKG-001 |
| P1-2 G11 extracted-ZIP verification | **FIXED** — release procedure §5 executed for this artifact; result in §Smoke below | RTM PKG-002 |
| P1-3 evidence drift (175 vs 176) | **FIXED** — ADR-0009 sequencing (evidence → docs → manifest → check → package); check evidence excluded from manifest scope; narrative docs quote no counts | RTM PKG-003 |
| P1-4 parent_event_id unused | **FIXED** — payload-reference model canonical and test-pinned; field removed | ADR-0008; RTM LIN-001 |
| P1-5 mutation gate | **FIXED** — see §Mutation; policy: 0 logic survivors, every survivor individually verified and dispositioned | RTM QA-002 |
| P1-6 lint/type gates | **FIXED** — ruff + mypy in `run_gates.py`, both clean; two governed `# noqa: BLE001` at the ADR-0007 adapter boundary only | evidence/G02-*.txt |

## Files added/changed vs V002
Added: `pyproject.toml`, `setup.cfg` ([mutmut]), `src/uraiflow/extraction/rules.py`,
`tests/fixtures/` (workforce rules), `tests/test_mutation_hardening.py`,
`scripts/run_gates.py`, `scripts/run_mutation_gate.py`,
`02-architecture/adr/ADR-0005..0009`, `06-traceability/RTM-V003.md`,
`09-governance/RELEASE-PROCEDURE.md`, `09-governance/CHANGE-RATIONALE-V003.md`,
`BUILD-REPORT-V003.md`, `evidence/V003-red-state.txt` + regenerated gate evidence.
Changed: `src/uraiflow/proposal/model.py` (rewritten), `confirmation/service.py`
(thinned), `pipeline/orchestrator.py` (rewritten), `adapters/contract.py`,
`adapters/inmemory.py`, `routing/registry.py`, `core/errors.py`, `lineage/model.py`,
`tests/test_extraction_and_proposal.py` (rewritten),
`tests/test_confirmation_and_pipeline.py` (rewritten), `tests/test_adapter_contract.py`,
`tests/test_architecture_guards.py`, `07-planning/FIRST-BUILD-BACKLOG.md`.
Removed: `src/uraiflow/extraction/extractor.py` (P0-1), `pytest.ini`, `.coveragerc`
(superseded by pyproject). Untouched: `10-baseline/**`, `scripts/validate_starter.py`.

## ADRs
ADR-0005 extraction semantic ownership · ADR-0006 command eligibility/edit-revalidation
lifecycle · ADR-0007 adapter-boundary errors, compensation states, rollback preflight,
registration validation (amends ADR-0001 state machine) · ADR-0008 lineage
payload-reference model · ADR-0009 packaging, canonical gates, release sequencing.

## Evidence — actual results (machine-generated files in `evidence/`)
- **Red state:** `V003-red-state.txt` — declared V003 test contracts failing before
  implementation (collection errors on the not-yet-existing `extraction.rules`).
- **Tests/coverage (G03/G04):** `G03-G04-tests-coverage.txt` — 109 passed, 0 failed;
  100% line and 100% branch coverage, enforced with `--cov-fail-under=100`.
- **Lint/type (G02):** `G02-ruff.txt` (all checks passed), `G02-mypy.txt`
  (no issues in 31 source files).
- **Mutation (G07):** `G07-mutation.json` / `G07-mutation-summary.txt` —
  241 mutants over the six policy modules; **178 killed (73.9%)**;
  **0 logic survivors** (gate fails otherwise); 63 accepted survivors, each
  individually re-verified by applying the mutant and running the full suite:
  62 mutate human-readable message/docstring literals only, 1 mutates a PEP 526
  function-body annotation that Python never evaluates (provably equivalent).
  Tooling finding: `mutmut run`'s own kill detection produced false survivors via
  stale `__pycache__`; the gate runs bytecode-safe (`python -B`, cache-cleared) and
  re-verifies every reported survivor independently.
- **Manifest (G01):** `G01-starter-validate.txt`, `G01-manifest-check.txt`.

## Smoke test (extracted ZIP, fresh environment)
Recorded after packaging (see final build response for the transcript): unzip into a
fresh temporary directory, fresh venv, `pip install -e .[dev]` from the artifact,
then starter validator + manifest check + `python scripts/run_gates.py`. The release
is only handed over if this passes.

## Known failures / deferred
No failing tests or gates. Deferred to V004 (see backlog): COMPENSATION_FAILED
operator recovery (terminal in V003), NEEDS_CLARIFICATION recovery loop, persistence,
CI automation of the full gate chain, real transcription provider + tenant-facing
extraction-schema configuration surface.

## For the independent reviewer
From the extracted repo root: `pip install -e .[dev]`, then
`python scripts/run_gates.py` and `python scripts/run_mutation_gate.py`, and
`python scripts/gen_manifest.py --check`. Treat this report as claims to verify.
