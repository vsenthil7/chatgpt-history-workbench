#!/usr/bin/env python3
"""Generate or verify the authoritative root PACKAGE-MANIFEST.json (ADR-0003,
strengthened per ADR-0012 / V003 review P1-3).

Usage:
  python3 scripts/gen_manifest.py           # regenerate
  python3 scripts/gen_manifest.py --check   # verify the COMPLETE contract

``--check`` validates the complete canonical manifest structure — schema,
project, product_version, file_count, path uniqueness and sort order, byte
counts, SHA-256 digests, and exact payload<->manifest bijection (no payload
file missing from the manifest, no manifest entry missing from the payload,
no excluded material in the payload inventory). Only the ``created``
timestamp is explicitly variable and excluded from equality comparison.
"""
import hashlib
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "PACKAGE-MANIFEST.json"
SCHEMA = "uraiflow-package-manifest/2"
PROJECT = "UraiFlow SaaS"
PRODUCT_VERSION = "0.12.0.dev0"
EXCLUDE_DIRS = {
    "__pycache__", ".pytest_cache", ".git", "uraiflow.egg-info", ".venv",
    "venv", ".mypy_cache", ".ruff_cache", ".mutmut-cache", ".hypothesis",
}
# Everything that ships is tracked (V003 review P0-4/P1-4). The authoritative
# exact-payload check runs inside the packager and is recorded in the external
# attestation, so no shipped evidence needs manifest exclusion.
EXCLUDE_FILES = {".coverage", ".mutmut-cache"}
# Post-manifest, self-referential evidence: these record the RESULT of checking
# the manifest (or summarise the gate run that ends with manifest generation),
# so they cannot be inside the manifest they attest without a circular checksum
# dependency. They are covered instead by the external release attestation
# (ADR-0012 §3 / P1-4) which hashes the complete final ZIP. (V006 P1-2.)
EXCLUDE_SELF_REFERENTIAL = {
    Path("evidence/G01-manifest-check.txt"),
    Path("evidence/release-gates-summary.json"),
}
# Explicitly variable fields excluded from canonical equality (ADR-0012 §4):
VARIABLE_FIELDS = {"created"}


def _files():
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if any(part in EXCLUDE_DIRS for part in rel.parts):
            continue
        if (rel.name in EXCLUDE_FILES or rel == Path("PACKAGE-MANIFEST.json")
                or rel in EXCLUDE_SELF_REFERENTIAL):
            continue
        yield rel, path


def build():
    entries = []
    for rel, path in _files():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        entries.append(
            {"path": rel.as_posix(), "sha256": digest, "bytes": path.stat().st_size}
        )
    return {
        "schema": SCHEMA,
        "created": datetime.now(UTC).isoformat(timespec="seconds"),
        "project": PROJECT,
        "product_version": PRODUCT_VERSION,
        "file_count": len(entries),
        "files": entries,
    }


def check(recorded: dict, actual: dict) -> list[str]:
    """Complete canonical contract comparison; returns human-readable failures."""
    problems: list[str] = []
    # 1. structural/metadata invariants of the RECORDED manifest itself
    for key, expected in (("schema", SCHEMA), ("project", PROJECT),
                          ("product_version", PRODUCT_VERSION)):
        if recorded.get(key) != expected:
            problems.append(
                f"{key}: recorded {recorded.get(key)!r} != expected {expected!r}"
            )
    files = recorded.get("files")
    if not isinstance(files, list):
        return problems + ["files: missing or not a list"]
    if recorded.get("file_count") != len(files):
        problems.append(
            f"file_count: recorded {recorded.get('file_count')} != "
            f"len(files) {len(files)} (file_count is an independent invariant)"
        )
    paths = [entry.get("path") for entry in files]
    if len(set(paths)) != len(paths):
        dupes = sorted({p for p in paths if paths.count(p) > 1})
        problems.append(f"duplicate paths in manifest: {dupes}")
    if paths != sorted(paths):
        problems.append("manifest inventory is not in canonical sorted order")
    # 2. exact payload <-> manifest bijection with per-entry hash/byte equality
    actual_by_path = {e["path"]: e for e in actual["files"]}
    recorded_by_path = {e.get("path"): e for e in files}
    missing_from_manifest = sorted(set(actual_by_path) - set(recorded_by_path))
    missing_from_payload = sorted(set(recorded_by_path) - set(actual_by_path))
    if missing_from_manifest:
        problems.append(f"payload files missing from manifest: {missing_from_manifest}")
    if missing_from_payload:
        problems.append(f"manifest entries missing from payload: {missing_from_payload}")
    for path in sorted(set(actual_by_path) & set(recorded_by_path)):
        rec, act = recorded_by_path[path], actual_by_path[path]
        if rec.get("sha256") != act["sha256"]:
            problems.append(f"sha256 drift: {path}")
        if rec.get("bytes") != act["bytes"]:
            problems.append(f"byte-count drift: {path}")
    # 3. nothing unexpected: recorded manifest must not inventory excluded material
    for path in paths:
        parts = Path(str(path)).parts
        if (any(part in EXCLUDE_DIRS for part in parts)
                or (parts and parts[-1] in EXCLUDE_FILES)
                or Path(str(path)) in EXCLUDE_SELF_REFERENTIAL):
            problems.append(f"manifest inventories excluded material: {path}")
    # 4. no unknown top-level fields beyond the canonical + variable set
    canonical_keys = {"schema", "project", "product_version", "file_count", "files"}
    unknown = set(recorded) - canonical_keys - VARIABLE_FIELDS
    if unknown:
        problems.append(f"unknown manifest fields: {sorted(unknown)}")
    return problems


def main(argv):
    actual = build()
    if "--check" in argv:
        if not MANIFEST.is_file():
            print("MANIFEST MISSING")
            return 1
        recorded = json.loads(MANIFEST.read_text(encoding="utf-8"))
        problems = check(recorded, actual)
        if problems:
            print(f"MANIFEST CONTRACT FAIL: {len(problems)} problem(s)")
            for problem in problems[:40]:
                print(f" - {problem}")
            return 1
        print(f"manifest check: PASS ({actual['file_count']} files, full contract)")
        return 0
    MANIFEST.write_text(json.dumps(actual, indent=1) + "\n", encoding="utf-8")
    print(f"manifest written: {actual['file_count']} files")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
