#!/usr/bin/env python3
"""Canonical cross-platform gate runner (ADR-0009).

Usage: python scripts/run_gates.py [--with-manifest-check]

Runs: starter validator, full test suite with 100% line+branch coverage
enforcement, ruff, mypy. Writes machine evidence to evidence/. The mutation
gate (scripts/run_mutation_gate.py) is run separately because of its runtime.
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence"

GATES = [
    ("G01-starter-validate", [sys.executable, "scripts/validate_starter.py"]),
    (
        "G03-G04-tests-coverage",
        [
            sys.executable, "-m", "pytest",
            "--cov=uraiflow", "--cov-branch", "--cov-report=term",
            "--cov-fail-under=100", "-q",
        ],
    ),
    ("G02-ruff", [sys.executable, "-m", "ruff", "check", "src", "tests", "scripts"]),
    ("G02-mypy", [sys.executable, "-m", "mypy", "src/uraiflow"]),
]


def main(argv: list[str]) -> int:
    gates = list(GATES)
    if "--with-manifest-check" in argv:
        gates.append(
            ("G01-manifest-check",
             [sys.executable, "scripts/gen_manifest.py", "--check"])
        )
    EVIDENCE.mkdir(exist_ok=True)
    failed = []
    for name, cmd in gates:
        result = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, check=False)
        output = result.stdout + result.stderr
        (EVIDENCE / f"{name}.txt").write_text(output, encoding="utf-8")
        status = "PASS" if result.returncode == 0 else "FAIL"
        print(f"{name}: {status}")
        if result.returncode != 0:
            failed.append(name)
            print(output[-1500:])
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
