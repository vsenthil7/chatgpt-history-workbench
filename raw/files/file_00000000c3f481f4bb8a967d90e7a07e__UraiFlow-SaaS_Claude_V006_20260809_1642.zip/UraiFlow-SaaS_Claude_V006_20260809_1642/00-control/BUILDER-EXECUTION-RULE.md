# Builder Execution Rule (permanent)

Baseline ingestion is not an iteration deliverable. Reading and validating the starter
package is step 0.

Every builder iteration must:

1. modify the working repository, and
2. produce the next independently reviewable versioned ZIP
   (`<Product>_<AIName>_VNNN_YYYYMMDD_HHMM.zip`),

unless blocked by a technically impossible step or a genuinely destructive/irreversible
business decision.

Normal engineering decisions are resolved by the builder through ADRs with preserved
traceability, never by pausing to ask the owner to choose implementation details.
Reversible architecture decisions are made, documented, implemented, tested and packaged
in the same iteration; the independent review loop (ChatGPT) is the correction mechanism.
