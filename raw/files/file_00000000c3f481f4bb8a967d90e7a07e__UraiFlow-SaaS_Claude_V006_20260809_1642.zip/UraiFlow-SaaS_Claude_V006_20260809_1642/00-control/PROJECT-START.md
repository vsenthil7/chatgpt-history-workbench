# Project Start

**Project name:** UraiFlow SaaS  
**First page name:** 00001-UraiFlow-SaaS-Build-Baseline  
**Starter artifact:** UraiFlow-SaaS_ChatGPT_V001_20260808_1318.zip  
**Created:** 08/08/2026 13:18 Europe/London

## SaaS ownership rule
This is a reusable SaaS product. IPBS may be a tenant/user and may sell/support it, but IPBS owns no generic product code.

## Product/pilot boundary
Own reusable conversation/audio capture, transcript lineage, provider abstraction, extraction, candidate record graph/proposal, human confirmation, routing and target-system adapters.

## Explicitly not owned
Planning, capacity, HR, payroll, timesheet, CRM or tenant business rules. UraiFlow proposes records; owning domain services validate and commit them.

## First build objective
Preserve the proposal/confirmation boundary and build the first production-grade vertical slice: input → transcript/provider abstraction → structured proposal → confirmation → adapter contract, with full lineage.

## Working pattern
Claude Code = implementation. ChatGPT = independent complete-ZIP review. Repeat version-by-version using evidence, not narrative confidence.

## Baseline preservation
The supplied pre-rebuild artifact is preserved under `10-baseline/`. It is historical/input evidence, not automatically authoritative when it conflicts with this starter contract or a later approved ADR.
