# B001 — Baseline Acceptance and Contradiction/Stale-Name Inventory

**Iteration:** V002 (Claude build)
**Input artifact:** `UraiFlow-SaaS_ChatGPT_V001_20260808_1318.zip`
**Baseline preserved unchanged under:** `10-baseline/UraiFlow-Planning-v0.8.0/`

## Acceptance statement
All starter documents (00–09) and the complete preserved baseline were read. The starter
contract is accepted as authoritative. Where the baseline conflicts with the starter
contract, the starter contract wins and the conflict is resolved by ADR, not by silently
rewriting baseline history. Baseline files are treated as read-only historical evidence.

## Contradiction / stale-name inventory

| # | Item | Location | Conflict | Resolution |
|---|------|----------|----------|------------|
| I-01 | Proposal state machine overlaps upstream aggregate states (`CAPTURED`, `TRANSCRIBED`, `EXTRACTED` appear as proposal states) | `10-baseline/.../docs/architecture/50-Record-Proposal-State-Machine.md` vs `13-State-Machine-Specification.md` | One lifecycle mixes pipeline-stage states of capture/transcription aggregates into the proposal aggregate | **ADR-0001**: proposal aggregate begins at `PROPOSED`; upstream stages are separate aggregates linked by lineage references |
| I-02 | Work Object Bridge defines the parent platform's work-object taxonomy (Interview / Transcript-Review / Follow-up / Export work objects and their required fields) inside UraiFlow docs; stale name "DWOS" | `10-baseline/.../docs/product/19-DWOS-Work-Object-Bridge.md` | Starter contract: receiving domains own their taxonomy and validation; UraiFlow proposes only | **ADR-0002**: taxonomy ownership moves to the receiving domain; UraiFlow emits contracted proposals through the target-system adapter contract; "DWOS" is a stale name, retained only in preserved history |
| I-03 | Multiple historical package manifests (`PACKAGE-MANIFEST-v0.3..v0.7.json`) alongside an active top-level manifest | `10-baseline/.../PACKAGE-MANIFEST*.json` vs `/PACKAGE-MANIFEST.json` | Ambiguity over which manifest the docs-consistency gate binds against | **ADR-0003**: only the repository-root `PACKAGE-MANIFEST.json` is authoritative; baseline manifests are frozen historical evidence and excluded from gate authority |
| I-04 | Baseline names a concrete provider ("Whisper") in benchmark plan | `10-baseline/.../docs/operations/34-Whisper-and-Provider-Benchmark-Plan.md` | Acceptable as benchmark subject, not as a hard-coded provider | No ADR needed; reusable code keeps providers behind `TranscriptionProvider` with per-tenant selection policy (enforced by tests + architecture guard) |
| I-05 | Baseline v0.8.0 planning SemVer vs new implementation | `10-baseline/.../README-v0.8.0.md` | Planning-pack versions are not product code versions | **ADR-0004**: implementation starts at product version `0.9.0-dev` (incubating 0.x per governance doc); AI artifact sequence (VNNN) is independent |

## Deletions
None. Nothing was deleted or renamed in `10-baseline/`.

## Builder execution rule (adopted into control set)
See `00-control/BUILDER-EXECUTION-RULE.md` — baseline ingestion is step 0, not an
iteration deliverable.
