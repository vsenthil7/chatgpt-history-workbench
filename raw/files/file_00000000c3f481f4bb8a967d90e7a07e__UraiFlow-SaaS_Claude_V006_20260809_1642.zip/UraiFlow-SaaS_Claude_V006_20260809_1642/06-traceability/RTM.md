# Requirement Traceability Matrix — starter

| ID | Requirement | Owner | Enforcement | Evidence/Test | Status |
|---|---|---|---|---|---|
| ARC-001 | Product code remains within declared bounded ownership | Architecture | architecture guard | TBD | DECLARED |
| ARC-002 | Cross-product reuse occurs through published contracts, not copied logic | Architecture | review + dependency guard | TBD | DECLARED |
| SaaS-001 | Reusable product code is tenant-neutral | Platform/Product | tenant-leak guard + tests | TBD | DECLARED |
| SaaS-002 | Tenant/org context is explicit at protected boundaries | Platform/Product | authz/isolation tests | TBD | DECLARED |
| QA-001 | New executable packages meet line+branch coverage policy | Engineering | coverage gate | TBD | DECLARED |
| QA-002 | Critical domain/policy behavior is mutation tested | Engineering | mutation gate | TBD | DECLARED |
| QA-003 | Escaped defects receive regression tests | Engineering | review/CI | TBD | DECLARED |
| DOC-001 | Version, package, test-count and ADR references are consistency checked | Governance | docs gate | scripts/validate_starter.py | ACTIVE |
| AI-001 | Claude build → independent ChatGPT ZIP review loop is used for releases | Governance | release checklist | handoff evidence | ACTIVE |
