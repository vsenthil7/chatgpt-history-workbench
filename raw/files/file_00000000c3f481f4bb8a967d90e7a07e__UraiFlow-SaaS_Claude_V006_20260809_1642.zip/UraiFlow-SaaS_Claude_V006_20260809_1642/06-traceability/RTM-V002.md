# Requirement Traceability Matrix — V002

Starter rows retained with updated status; SLICE rows added for the first vertical
slice. Test file references are the enforcement evidence; run evidence lives in
`evidence/B003-green-tests-coverage.txt` (59 passed, 100% line + branch).

| ID | Requirement | Owner | Enforcement | Evidence/Test | Status |
|---|---|---|---|---|---|
| ARC-001 | Product code remains within declared bounded ownership | Architecture | architecture guard | `tests/test_architecture_guards.py::test_dependency_direction_respects_declared_layering` | ENFORCED |
| ARC-002 | Cross-product reuse occurs through published contracts, not copied logic | Architecture | adapter contract + harness | `tests/test_adapter_contract.py` (contract harness, descriptor surface) | ENFORCED |
| SaaS-001 | Reusable product code is tenant-neutral | Platform/Product | tenant-leak guard + tests | `tests/test_architecture_guards.py::test_no_customer_or_sibling_product_tokens_in_reusable_source`, `::test_no_hardcoded_tenant_identifiers_in_source` | ENFORCED |
| SaaS-002 | Tenant/org context is explicit at protected boundaries | Platform/Product | authz/isolation tests | cross-tenant denial tests in `tests/test_core_and_lineage.py`, `tests/test_capture_and_transcription.py`, `tests/test_adapter_contract.py`, `tests/test_confirmation_and_pipeline.py` | ENFORCED |
| QA-001 | New executable packages meet line+branch coverage policy | Engineering | coverage gate (`--cov-branch --cov-fail-under=100`) | `evidence/B003-green-tests-coverage.txt` | ENFORCED |
| QA-002 | Critical domain/policy behavior is mutation tested | Engineering | mutation gate | deferred to V003 — exception EX-001 (build report) | DECLARED |
| QA-003 | Escaped defects receive regression tests | Engineering | review/CI | no escaped defects yet this iteration | DECLARED |
| DOC-001 | Version, package, test-count and ADR references are consistency checked | Governance | docs gate | `scripts/validate_starter.py`, `scripts/gen_manifest.py --check` (`evidence/G01-manifest-check.txt`) | ACTIVE |
| AI-001 | Claude build → independent ChatGPT ZIP review loop is used for releases | Governance | release checklist | `BUILD-REPORT-V002.md` handoff | ACTIVE |
| SLICE-001 | Conversation capture produces a tenant-owned Capture aggregate with lineage | Capture | unit tests | `tests/test_capture_and_transcription.py::test_capture_creates_record_and_lineage` | ENFORCED |
| SLICE-002 | Transcription runs only through the replaceable provider abstraction with per-tenant provider policy | Transcription | unit tests + guard | `::test_provider_selection_uses_default_then_tenant_policy`, `::test_selector_rejects_unknown_provider_name` | ENFORCED |
| SLICE-003 | Proposal aggregate enforces the ADR-0001 state machine incl. invalid-transition rejection | Proposal | unit tests | `tests/test_extraction_and_proposal.py` (transition tests) | ENFORCED |
| SLICE-004 | Every target-system adapter declares types/schema/required fields/idempotency/rollback and passes the compliance harness | Adapters | contract tests | `tests/test_adapter_contract.py` | ENFORCED |
| SLICE-005 | Human confirmation (all/selected/edit/reject) gates every commit; UraiFlow never auto-commits | Confirmation | unit + e2e tests | `tests/test_confirmation_and_pipeline.py` (confirm/reject/edit paths; `test_reject_all_is_terminal_and_uncommittable`) | ENFORCED |
| SLICE-006 | Full lineage chain links capture → transcript → proposal → per-record commit outcome | Lineage | e2e tests | `::test_lineage_chain_links_capture_transcript_proposal`, `::test_confirmation_confirm_all_and_commit_end_to_end` | ENFORCED |
| SLICE-007 | Commit is atomic across adapters: partial failure compensates committed records and rolls back | Pipeline | e2e failure-injection test | `::test_commit_failure_compensates_and_rolls_back` | ENFORCED |
