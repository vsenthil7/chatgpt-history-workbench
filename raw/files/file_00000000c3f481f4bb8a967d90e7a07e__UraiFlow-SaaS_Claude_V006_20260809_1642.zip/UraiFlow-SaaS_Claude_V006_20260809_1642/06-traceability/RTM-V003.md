# Requirement Traceability Matrix — V003

Supersedes RTM-V002 (retained as history). Run evidence is machine-generated under
`evidence/` (`G03-G04-tests-coverage.txt`, `G02-ruff.txt`, `G02-mypy.txt`,
`G07-mutation.json`/`-summary.txt`, `G01-*.txt`); narrative docs quote no counts.

## Carried rows (status after V003)

| ID | Requirement | Enforcement | Evidence/Test | Status |
|---|---|---|---|---|
| ARC-001 | Product code remains within declared bounded ownership | architecture guard | `tests/test_architecture_guards.py::test_dependency_direction_respects_declared_layering` | ENFORCED |
| ARC-002 | Cross-product reuse occurs through published contracts | adapter contract + harness | `tests/test_adapter_contract.py` | ENFORCED |
| SaaS-001 | Reusable product code is tenant-neutral | tenant-token guard + tests | `::test_no_customer_or_sibling_product_tokens_in_reusable_source`, `::test_no_hardcoded_tenant_identifiers_in_source` | ENFORCED |
| SaaS-002 | Tenant/org context explicit at protected boundaries | cross-tenant denial tests (lineage, transcription, confirmation, revalidate, commit, adapter rollback) | `tests/test_core_and_lineage.py`, `tests/test_capture_and_transcription.py`, `tests/test_adapter_contract.py`, `tests/test_confirmation_and_pipeline.py` | ENFORCED |
| QA-001 | 100% line+branch coverage on executable packages | `--cov-branch --cov-fail-under=100` via `scripts/run_gates.py` | `evidence/G03-G04-tests-coverage.txt` | ENFORCED |
| QA-002 | Critical policy behavior is mutation tested | `scripts/run_mutation_gate.py` (0 logic survivors required; survivors individually verified and dispositioned) | `evidence/G07-mutation.json`, `evidence/G07-mutation-summary.txt` | ENFORCED |
| QA-003 | Escaped defects receive regression tests | review findings → named regressions (see INV/CMP rows) | this iteration | ENFORCED |
| DOC-001 | Version/package/evidence consistency checked | `scripts/gen_manifest.py --check`, release sequencing (ADR-0009) | `evidence/G01-manifest-check.txt`, `09-governance/RELEASE-PROCEDURE.md` | ENFORCED |
| AI-001 | Claude build → independent ChatGPT ZIP review loop | this package + `BUILD-REPORT-V003.md` | — | ACTIVE |
| SLICE-001..007 | V002 vertical slice behaviors | retained tests (updated for V003 contracts) | `tests/` | ENFORCED |

## New rows (V003 corrective iteration; review findings in brackets)

| ID | Requirement | Evidence/Test | Status |
|---|---|---|---|
| DOM-001 [P0-1] | Reusable extraction is domain-taxonomy-neutral: engine takes rules as constructor data with no defaults; no domain vocabulary or module-level rules in `src/uraiflow` | `tests/test_architecture_guards.py::test_no_receiving_domain_vocabulary_in_reusable_source`, `::test_extraction_engine_has_no_default_rules_and_no_module_level_rules`; workforce rules live in `tests/fixtures/workforce_rules.py` | ENFORCED |
| INV-001 [P0-2] | Failed aggregate commands leave the proposal logically unchanged (no mutation before eligibility) | `tests/test_extraction_and_proposal.py::test_confirm_all_on_rejected_fails_without_mutation`, `::test_command_eligibility_matrix_blocks_all_other_states`, `tests/test_confirmation_and_pipeline.py::test_service_confirm_on_rejected_proposal_fails_without_mutation` | ENFORCED |
| INV-002 [P0-3] | Terminal/non-commandable proposals cannot be confirmed, rejected or edited (exhaustive state matrix) | `::test_command_eligibility_matrix_blocks_all_other_states` | ENFORCED |
| INV-003 [P0-4] | Unknown selected/edited record ids are rejected atomically before any change | `::test_confirm_selected_unknown_ids_fail_fast_atomically`, `::test_edit_unknown_id_fails_fast_atomically`, `tests/test_mutation_hardening.py::test_unknown_item_error_message_names_the_proposal` | ENFORCED |
| INV-004 [P0-5] | Edit ⇒ revalidation: confirmation blocked until `Pipeline.revalidate`; invalid items cannot be confirmed | `::test_edit_sets_revalidation_flag_and_blocks_confirmation`, `::test_apply_validation_clears_flag_and_blocks_invalid_confirmation`, `tests/test_confirmation_and_pipeline.py::test_edit_blocks_confirmation_until_revalidated`, `::test_invalid_edit_cannot_be_confirmed_after_revalidation` | ENFORCED |
| CMP-001 [P0-6] | Any adapter `Exception` during commit is normalised and triggers governed compensation | `::test_infrastructure_exception_is_normalised_and_compensated`, `::test_domain_failure_compensates_and_rolls_back` | ENFORCED |
| CMP-002 [P0-7] | Compensation failure is represented honestly: COMPENSATING → COMPENSATION_FAILED, all rollbacks attempted, failures in outcome + lineage; ROLLED_BACK only when all compensations succeeded | `::test_rollback_failure_yields_compensation_failed_with_evidence`, `tests/test_mutation_hardening.py::test_compensation_attempts_every_rollback_after_a_failure` | ENFORCED |
| CMP-003 [P0-8] | Rollback capability preflighted before multi-record commit; proposal unchanged on refusal; single-record exempt | `::test_preflight_refuses_multi_record_commit_without_rollback_support`, `::test_single_record_commit_allowed_without_rollback_support`, `tests/test_mutation_hardening.py::test_preflight_applies_to_exactly_two_records` | ENFORCED |
| ADP-001 [P0-9] | Malformed adapter descriptors cannot enter the runtime registry | `tests/test_adapter_contract.py::test_registry_rejects_malformed_descriptor_at_registration`, `::test_harness_raises_adapter_contract_error_on_malformed` | ENFORCED |
| ADP-002 | Adapters may declare `supports_rollback=False` and refuse rollback calls | `::test_adapter_can_declare_no_rollback_and_refuses_rollback_calls` | ENFORCED |
| LIN-001 [P1-4] | Payload ID references are the canonical lineage graph (`parent_event_id` removed) | `tests/test_confirmation_and_pipeline.py::test_lineage_payload_references_link_capture_transcript_proposal`, `tests/test_mutation_hardening.py::test_lineage_payload_contents_are_pinned`, `::test_capture_and_transcript_event_payloads_pinned` | ENFORCED |
| PKG-001 [P1-1] | Artifact is installable/self-contained; plain `python -m pytest` passes after `pip install -e .[dev]`; one canonical gate command | `pyproject.toml`, `scripts/run_gates.py`, extracted-ZIP smoke evidence (build report) | ENFORCED |
| PKG-002 [P1-2] | Extracted-ZIP smoke test: fresh directory + venv, install from artifact, validator + manifest + full gates | release procedure §4; smoke result in `BUILD-REPORT-V003.md` | ENFORCED |
| PKG-003 [P1-3] | Evidence/manifest counts cannot drift within a release | ADR-0009 sequencing; `gen_manifest.py --check`; no counts in narrative docs | ENFORCED |
