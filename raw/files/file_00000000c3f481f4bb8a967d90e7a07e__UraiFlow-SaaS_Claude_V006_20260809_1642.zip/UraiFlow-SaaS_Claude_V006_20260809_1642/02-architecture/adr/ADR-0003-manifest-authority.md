# ADR-0003 — Manifest authority: root manifest active, baseline manifests historical

**Status:** ACCEPTED (V002) · **Reversible:** yes

## Context
The preserved baseline contains `PACKAGE-MANIFEST-v0.3.json` … `-v0.7.json` and its own
`PACKAGE-MANIFEST.json`. The repository root also carries `PACKAGE-MANIFEST.json`. The
docs-consistency gate (G01/G10) needs exactly one binding manifest.

## Decision
1. Only the repository-root `/PACKAGE-MANIFEST.json` is authoritative. It is
   **generated**, never hand-edited, by `scripts/gen_manifest.py`, which records a
   SHA-256 hash for every file in the package.
2. `scripts/gen_manifest.py --check` recomputes hashes and fails on any drift; this is
   gate G01 evidence.
3. Everything under `10-baseline/` (including its manifests) is frozen historical
   evidence: hashed *by* the root manifest, but never itself an authority, and never
   modified by builder iterations.

## Consequences
- G01 becomes machine-checkable and is run in every iteration (evidence under
  `evidence/`).
- Counts/versions quoted in narrative docs must reference generated evidence
  (Engineering OS "one source of truth" rule).
