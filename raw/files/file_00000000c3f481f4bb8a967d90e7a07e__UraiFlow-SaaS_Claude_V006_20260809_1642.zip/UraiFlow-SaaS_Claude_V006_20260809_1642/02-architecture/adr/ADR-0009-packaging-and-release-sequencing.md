# ADR-0009 — Installable package, canonical gate runner, release sequencing

**Status:** ACCEPTED (V003) · Findings P1-1, P1-2, P1-3

## Decision
1. **Installable project.** `pyproject.toml` (setuptools, src layout, `uraiflow`
   0.9.0.dev0, Python ≥3.11, zero runtime dependencies, dev extras for
   pytest/coverage/ruff/mypy/mutmut). Supported setup: `pip install -e .[dev]`.
2. **One canonical, cross-platform gate command:** `python scripts/run_gates.py`
   (no shell-specific `PYTHONPATH`). It runs the starter validator, full test suite
   with 100% line+branch enforcement, and static gates, writing machine evidence to
   `evidence/`.
3. **Release sequencing (fixes intra-release evidence drift):**
   evidence → final docs → regenerate authoritative manifest → manifest check
   (its own evidence file is excluded from manifest scope) → package ZIP →
   **extracted-ZIP smoke test** in a fresh directory + venv: install from the artifact,
   run starter validator, manifest check, full gates. Tracked files must not change
   after manifest generation. Narrative docs never embed manifest file counts; they
   reference evidence files (see `09-governance/RELEASE-PROCEDURE.md`).
