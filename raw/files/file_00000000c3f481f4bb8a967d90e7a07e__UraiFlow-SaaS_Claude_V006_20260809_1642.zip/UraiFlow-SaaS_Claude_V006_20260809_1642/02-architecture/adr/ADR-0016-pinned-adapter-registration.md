# ADR-0016 — Pinned adapter registration descriptor

Status: ACCEPTED (V006) · Amends: ADR-0010 · Drives: P0-2 of the V005 review

## Context
V005's registry validated `adapter.descriptor()` at registration but stored the
ADAPTER OBJECT, then re-read `adapter.descriptor()` again at commit time to bind
the receipt. An adapter could therefore advertise `adapter_id = adp.registered`
at registration and `adapter_id = adp.drifted` at commit time, producing a
TRUSTED `COMMITTED` receipt whose machine identity was not in the registry at
all — breaking ADR-0010's invariant that compensation can always bind a receipt
back to the exact registered identity. It also risked `resolve_by_id` throwing
inside compensation.

## Decision
Registration produces an immutable `RegisteredAdapter` record:

```
RegisteredAdapter(adapter, descriptor)   # descriptor validated + PINNED
```

The registry stores and returns `RegisteredAdapter` from `resolve` and
`resolve_by_id`. Every later operation — receipt validation, rollback-capability
preflight, commit binding, compensation resolution — uses the PINNED
`descriptor`, never a re-read `adapter.descriptor()`. The adapter object is used
only to invoke `commit`/`rollback`.

## Consequences
* Descriptor drift after registration can no longer produce a trusted receipt
  for an unregistered identity: the drifted receipt fails to bind against the
  pinned descriptor and enters governed compensation / uncertain-commit
  handling (ADR-0017). Pinned as
  `tests/test_v006_review_reproductions.py::TestP02DescriptorDriftPinned`.
* Compensation's `resolve_by_id` is additionally moved inside the rollback
  exception handler so any resolution failure is captured as a rollback
  failure rather than crashing recovery accounting.
