# ADR-0008 — Payload ID references are the canonical lineage graph

**Status:** ACCEPTED (V003) · Finding P1-4

## Context
`LineageEvent.parent_event_id` existed but was never populated; aggregates are linked by
ids inside event payloads. A field implying stronger semantics than implemented is
misleading evidence.

## Decision
Option A: **payload references are canonical.** Contract: `proposal.created` events
carry `capture_id` and `transcript_id`; `record.*` events carry `record_id` and
`adapter`; `transcript.created` carries `capture_id`. This linkage contract is
test-enforced. `parent_event_id` is removed until an explicit event-graph requirement
is scheduled (if reintroduced, it comes with population + traversal semantics + tests).
