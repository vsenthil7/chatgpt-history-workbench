# ADR-0013 — Structured compensation results and operator recovery

Status: ACCEPTED (V004) · Drives: P1-5, P1-6 of the V003 independent review

## Context
On compensation failure V003 returned `receipts=()` with string-only failure
data, so an operator-recovery workflow would have had to reconstruct the
unrecovered working set by parsing lineage text.

## Decision
1. **Structured results (§2).** Every failed commit produces a
   `CompensationReport` on the `CommitOutcome`: `original_failure`,
   `committed_receipts`, `compensated_receipts`, `unrecovered_receipts`,
   `rollback_failures`, `contract_violations`. The aggregate stores
   `unrecovered_receipts` (only enterable in COMPENSATION_FAILED via
   `record_unrecovered`), giving recovery a typed working set.
2. **State model.** COMPENSATION_FAILED is no longer terminal: it may reach
   `ROLLED_BACK` (successful rollback retry) or the new terminal
   `MANUALLY_RESOLVED` (authorised attestation). No other transition exists;
   `MANUALLY_RESOLVED` is immutable like all terminal states.
3. **Operator recovery (§3).** `uraiflow.recovery.RecoveryService` provides:
   * `retry_rollback(ctx, proposal)` — re-attempts every unrecovered receipt
     through `resolve_by_id` (exact machine identity, ADR-0010); full success
     advances to ROLLED_BACK and clears the working set; partial success stays
     COMPENSATION_FAILED with the reduced set recorded; every attempt is
     idempotent over the recorded set and appends lineage events.
   * `resolve_manually(ctx, proposal, evidence)` — requires non-empty free-text
     evidence describing the out-of-band resolution; advances to
     MANUALLY_RESOLVED; unrecovered receipts remain recorded on the aggregate
     as evidence of what was outstanding at resolution time.
   * **Authorisation:** both operations require `ctx.actor_id` in the
     service's `authorized_operators` allowlist (AuthorizationError otherwise)
     and tenant identity (`require_same_tenant`), and are only legal in
     COMPENSATION_FAILED.
   * **Immutability:** lineage is append-only; original commit/rollback failure
     events are never erased or rewritten; repeated retry failures append
     further `record.rollback_failed` / `recovery.retry_failed` events.
4. **Layering.** `recovery` is an orchestration-level module beside `pipeline`
   (may import core/lineage/proposal/routing/adapters; nothing imports it).
