# ADR-0010 — Adapter machine identity and the receipt trust boundary

Status: ACCEPTED (V004) · Drives: P0-1, P0-2 of the V003 independent review

## Context
V003 resolved adapters for compensation by `descriptor.name`. Names were not
unique, so a `CommitReceipt` produced by adapter B could be rolled back through
a different, same-named adapter A — a compensation-integrity defect. Separately,
the pipeline trusted whatever object `adapter.commit()` returned, letting a
buggy or hostile adapter inject receipts describing another tenant, record,
adapter or idempotency operation into lineage and later compensation.

## Decision
1. **Machine identity.** `AdapterDescriptor.adapter_id` is an immutable machine
   identity, syntax `[a-z0-9][a-z0-9._-]*`, distinct from the display `name`.
   Display names are presentation-only and MUST never affect routing or
   rollback; duplicate display names are permitted.
2. **Registry.** `AdapterRegistry` enforces global `adapter_id` uniqueness and
   registers atomically: all invariants (descriptor validity, identity
   uniqueness, record-type ownership) are checked before any state mutates, so
   a rejected adapter leaves the registry untouched. Name-based resolution
   (`resolve_by_name`) is removed; the only identity resolution is
   `resolve_by_id`.
3. **Receipt trust boundary.** `CommitReceipt` carries `adapter_id`. A receipt
   returned by `commit()` is untrusted evidence until
   `validate_commit_receipt(descriptor, ctx, record, idempotency_key, receipt)`
   binds it to the invoked adapter identity, the operation tenant, the
   committed record, the supplied idempotency key, and non-empty
   receipt/target identifiers. Any mismatch is an `AdapterContractError`; the
   pipeline treats it exactly like a failed commit and enters governed
   compensation of earlier validated receipts. The offending receipt is never
   admitted to lineage as trusted evidence and is reported in
   `CompensationReport.contract_violations`.
4. **Compensation binding.** Compensation resolves receipts exclusively via
   `resolve_by_id(receipt.adapter_id)`.
5. **Reference adapter convenience.** `InMemoryTargetAdapter` defaults
   `adapter_id` to its name; because registry uniqueness is enforced on
   `adapter_id`, two default-identity adapters sharing a name are rejected
   (fail-safe). Production adapters must declare `adapter_id` explicitly.

## Consequences
The exact duplicate-name reproduction from the review is a pinned regression
(`tests/test_adapter_identity_and_receipts.py`), including hostile-adapter
receipt tests for every mismatch class.
