# ADR-0017 — Uncertain external commit (no false ROLLED_BACK)

Status: ACCEPTED (V006) · Amends: ADR-0010 §3, ADR-0013 · Drives: P0-1 of the
V005 independent review

## Context
The commit ordering is unavoidable: `adapter.commit()` runs (and may already
modify the external system) BEFORE its receipt can be validated. V005 only
appended a receipt to the trusted `committed` set AFTER validation succeeded.
So when an external commit SUCCEEDED but returned an INVALID receipt, the
operation was silently dropped: it was never in `committed`, so compensation
never attempted it, and if the earlier receipts rolled back cleanly the
aggregate advanced to `ROLLED_BACK` — a FALSE recovery claim while a committed
external side effect still existed. The reviewer reproduced exactly this.

## Decision
Introduce an explicit `UncertainCommit` record built ENTIRELY from trusted
request-side data — the invoked (pinned) adapter identity, the operation
tenant, the record id and the idempotency key — NEVER from the untrusted
receipt:

```
UncertainCommit(adapter_id, adapter_name, tenant_id, record_id,
                idempotency_key, reason)
```

When `validate_commit_receipt` rejects a receipt, the orchestrator records an
`UncertainCommit` (the external effect MAY have happened) and:

1. it is NOT added to trusted `committed` receipts (that would defeat receipt
   validation);
2. its presence BLOCKS the clean `ROLLED_BACK` state exactly like a rollback
   failure does — the aggregate advances to `COMPENSATION_FAILED`;
3. it is recorded on the aggregate (`record_uncertain`, valid only in
   `COMPENSATION_FAILED`) and surfaced in `CompensationReport.uncertain_commits`
   and lineage so an operator can reconcile the possibly-committed effect;
4. the manual-resolution audit records the uncertain commit ids the operator
   reconciled.

`ROLLED_BACK` therefore means what it says: no committed external effect
remains unaccounted for.

## Consequences
* An invalid receipt after a real side effect now yields `COMPENSATION_FAILED`
  with a recorded `UncertainCommit`, never a false `ROLLED_BACK`. Pinned as
  `tests/test_v006_review_reproductions.py::TestP01UncertainCommitNoFalseRollback`
  with an adapter that performs a real in-memory side effect.
* Existing hostile-receipt tests were updated from the old (buggy) `ROLLED_BACK`
  expectation to the correct `COMPENSATION_FAILED` + uncertain-commit invariant.
