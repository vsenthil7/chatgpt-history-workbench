# ADR-0007 — Adapter-boundary error policy, compensation states, rollback preflight

**Status:** ACCEPTED (V003) · Amends ADR-0001 state machine · Findings P0-6, P0-7, P0-8, P0-9

## Context
V002 compensated only `UraiFlowError`, assumed rollback always succeeds, never enforced
`supports_rollback`, and never validated descriptors at runtime registration.

## Decision
1. **Error normalisation at the adapter boundary.** During commit and rollback the
   pipeline catches `Exception` (never `BaseException`: `KeyboardInterrupt`/`SystemExit`
   propagate) from adapter calls and normalises it to
   `"<adapter>: <ExceptionType>: <message>"` in outcome + lineage. Programming errors
   are therefore *not hidden*: they surface verbatim in `CommitOutcome.failure` /
   `compensation_failures` and lineage evidence, but they cannot leave a partial
   multi-adapter commit uncompensated.
2. **Compensation is a governed phase.** State machine (amending ADR-0001):
   `COMMITTING → {COMMITTED, COMMIT_FAILED}`; `COMMIT_FAILED → COMPENSATING`;
   `COMPENSATING → {ROLLED_BACK, COMPENSATION_FAILED}`. Every rollback is attempted
   even after one fails; failures are collected. `ROLLED_BACK` is claimed only when all
   required compensations succeeded; otherwise `COMPENSATION_FAILED` (terminal in V003;
   operator recovery workflow is future work). Each success/failure is a lineage event.
3. **Rollback preflight.** Before entering `COMMITTING`, when more than one confirmed
   record participates, every participating adapter must declare
   `supports_rollback=True`; otherwise the commit is refused (`AdapterContractError`)
   with the proposal unchanged and a `proposal.commit_preflight_failed` lineage event.
   A single-record commit needs no compensation and is exempt.
4. **Runtime descriptor validation.** `AdapterRegistry.register` validates the
   descriptor (non-empty name/schema version, ≥1 accepted type, `required_fields`
   covering every accepted type) via the same `validate_descriptor` the compliance
   harness uses; malformed adapters cannot enter the runtime registry.
