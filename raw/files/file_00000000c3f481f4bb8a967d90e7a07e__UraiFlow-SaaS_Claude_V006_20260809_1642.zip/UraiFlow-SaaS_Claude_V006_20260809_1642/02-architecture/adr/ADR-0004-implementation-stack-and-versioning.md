# ADR-0004 — Implementation stack, reference infrastructure and version numbering

**Status:** ACCEPTED (V002) · **Reversible:** yes

## Context
The starter contract mandates a first production-grade vertical slice but does not fix
a language. The baseline's only code sketch (`WorkObjectGateway` Protocol) is Python,
and the governance/testing docs (coverage, mutation, guards) map directly onto the
Python toolchain available to the build loop.

## Decision
1. **Language:** Python ≥ 3.11, standard library only for the domain (no runtime
   third-party dependencies in `src/`); `pytest` + `pytest-cov` for the test/gate
   toolchain.
2. **Reference infrastructure:** V002 ships deterministic in-memory implementations
   (lineage store, echo transcription provider, in-memory target adapter) behind the
   published protocols. Real providers/persistence are adapter work for later
   iterations and must not change the contracts.
3. **Determinism:** domain code takes a `Clock` dependency; the default test suite uses
   a fixed clock, fixed inputs and no network, per the testing strategy.
4. **Versioning:** product code starts at `0.9.0-dev` (incubating 0.x per
   `09-governance/VERSIONING-AND-PACKAGING.md`), independent of the AI artifact
   sequence (`V002`), and independent of the baseline planning-pack `v0.8.0`.

## Consequences
- 100% line+branch coverage is enforced on `src/uraiflow` via
  `--cov-branch --cov-fail-under=100` (gate G04).
- Mutation testing (G07/QA-002) is **deferred to V003** as an explicit exception
  EX-001 (see build report): the toolchain is not yet wired and the gate table permits
  a documented exception; surviving-mutant triage is scheduled work, not skipped work.
