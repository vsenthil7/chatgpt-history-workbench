# ADR-0014 — Canonical exact-type primitives at trust boundaries

Status: ACCEPTED (V005) · Drives: P0-1, P0-2, P0-3 of the V004 independent
review · Amends: ADR-0010 (receipt/identity trust), SaaS-002 (tenant isolation)

## Context
The V004 independent review demonstrated, with executed exploits against the
shipped code, that every identifier comparison at a trust boundary could be
spoofed by a hostile ``str`` subclass overriding ``__eq__`` / ``__ne__`` /
``__hash__`` / ``strip``:

* `require_same_tenant` compared `ctx.tenant_id != tenant_id` — a hostile
  subtype made a foreign tenant compare equal (`TENANT_BYPASS: yes`).
* `validate_commit_receipt` performed ordinary equality on all four
  security-relevant fields — a receipt whose adapter/tenant/record/idempotency
  values were all wrong but were hostile subclasses was accepted
  (`RECEIPT_BINDING_BYPASS: yes`).
* Recovery operator authorisation used set membership on `ctx.actor_id` — a
  subtype whose hash/equality masqueraded as an authorised operator obtained
  operator rights (`membership spoof: True`).

The root cause is a single class of defect: **identifiers crossing a trust
boundary were trusted as arbitrary ``str``**, so attacker-controlled methods
participated in security decisions.

## Decision
1. **Canonical primitive.** `uraiflow.core.primitives.canonical_identifier`
   returns a value as a canonical plain ``str`` and raises
   `TrustBoundaryViolation` unless `type(value) is str` (exact type — never
   `isinstance`, which admits subclasses). The exact-type check runs BEFORE any
   method of the incoming object is invoked, so a hostile object gets no code
   execution on the comparison path. The result is stripped and required
   non-empty.
2. **Exact structure admission.** `require_exact_type` rejects duck-typed
   impostors of security-bearing structures (`TenantContext`, `CommitReceipt`,
   `AdapterDescriptor`) where the genuine canonicalising type is required.
3. **Canonicalise at construction.** `TenantContext`, `AdapterDescriptor`,
   `CommitReceipt` and `CandidateRecord` canonicalise every identity field in
   `__post_init__`. A hostile subclass therefore cannot be *retained* inside a
   domain object; an attacker-controlled receipt is rejected at construction,
   which is strictly stronger than rejecting it at validation time.
4. **Compare only canonical primitives.** `require_same_tenant` admits an exact
   `TenantContext` (via `require_context`) and canonicalises the comparand
   before comparing; `RecoveryService` canonicalises its operator allowlist at
   construction so membership compares exact plain strings; the registry
   canonicalises the lookup key; lineage reads require an exact context and
   canonicalise the subject key. No attacker-controlled ``__eq__``/``__hash__``
   participates in any tenant, identity, routing or authorisation decision.
5. **Fail-closed error type.** `TrustBoundaryViolation(UraiFlowError,
   ValueError)` reports a non-canonical value at a boundary; being a
   `ValueError` keeps construction-time validation semantics honest.

## §2 Exact type, not isinstance
Trust-boundary checks use `type(value) is str` / `type(value) is Expected`.
`isinstance` is deliberately avoided: a subclass *is* an instance, and the
whole exploit class is subclasses. "Benign subclass" cannot be established from
inside the type, so all subclasses are rejected.

## Consequences
* Every reproduced exploit now fails closed and is pinned as an executed-attack
  regression in `tests/test_trust_boundary_primitives.py` (hostile tenant,
  all-fields-wrong hostile receipt, operator-allowlist spoof, plus impostor
  objects for context/receipt/descriptor).
* Empty-identifier rejection moves to construction time; a handful of legacy
  emptiness checks in `validate_descriptor`/`validate_commit_receipt` became
  dead and were removed, their tests re-pointed to the construction boundary.
* Scope note (deferred to review): this ADR hardens the identity primitives and
  every reproduced boundary plus the adjacent security/identity comparisons
  (tenant, adapter, receipt, operator, lineage subject). A future iteration may
  extend exact-type canonicalisation to any additional value later introduced
  at a protected boundary.
