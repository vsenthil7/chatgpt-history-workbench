# ADR-0005 — Reusable core owns the extraction mechanism, never domain vocabulary

**Status:** ACCEPTED (V003) · **Supersedes behaviour shipped in V002** · Review finding P0-1

## Context
V002's `RuleBasedExtractor` hard-coded workforce vocabulary (`time_entry`, `follow_up`,
`availability`, field names, trigger phrases) into `src/uraiflow`. Tenant-neutral is not
domain-neutral: reusable UraiFlow must not know what a timesheet entry is.

## Decision
1. `src/uraiflow/extraction` ships only the **generic mechanism**: `CandidateRecord`
   (opaque `record_type`), the `Extractor` protocol, and `ConfigurableRuleExtractor`,
   a rule engine whose `ExtractionRule`/`FieldSpec` definitions and number-word maps
   are **constructor data with no defaults**. The engine contains no record types,
   field names, phrases or language vocabulary.
2. Concrete schemas/rules are supplied from outside reusable core: tenant/product
   configuration, receiving-product plugins, or fixtures. The workforce rules used by
   the acceptance sample now live in `tests/fixtures/workforce_rules.py` as an
   acceptance fixture and example integration — explicitly not product code.
3. Enforcement is structural plus a tripwire:
   - guard test asserts `ConfigurableRuleExtractor` has no default rules and that no
     `ExtractionRule` is instantiated at module level anywhere in `src/uraiflow`;
   - guard test forbids the known receiving-domain vocabulary tokens in `src/uraiflow`
     as a tripwire (secondary layer only — placement is the real control);
   - the existing stdlib-only import guard prevents core from importing fixtures.

## Consequences
LLM/provider-backed extractors later implement `Extractor` and receive their
schema/prompt configuration the same way: from outside the core.
