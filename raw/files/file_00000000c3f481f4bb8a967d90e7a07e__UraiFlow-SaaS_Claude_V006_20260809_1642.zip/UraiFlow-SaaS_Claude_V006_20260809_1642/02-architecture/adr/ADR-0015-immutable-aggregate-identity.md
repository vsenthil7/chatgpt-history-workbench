# ADR-0015 — Immutable aggregate identity vs mutable aggregate state

Status: ACCEPTED (V006) · Drives: P0-3 of the V005 independent review

## Context
V005 hardened `TenantContext` comparison against hostile `str` subclasses, but
`Proposal` remained a plain mutable dataclass. The reviewer reassigned
ownership with a single field write — ingest as tenant A, confirm, then
`proposal.tenant_id = "tenant-b"` and commit as tenant B — and the work
committed under tenant B. The tenant CHECK was correct; the thing being checked
was mutable. That is the difference between "compare tenant values securely" and
"securely bind object ownership to a tenant".

## Decision
Separate immutable aggregate IDENTITY from mutable aggregate STATE.

`Proposal` identity fields — `proposal_id`, `tenant_id`, `capture_id`,
`transcript_id` — are:
1. canonicalised to exact built-in `str` at construction (ADR-0014); and
2. WRITE-ONCE: a custom `__setattr__` rejects any reassignment of an identity
   field after construction with `TrustBoundaryViolation`.

Business state (`items`, `status`, `needs_revalidation`, decisions, and the
recovery bookkeeping fields) remains mutable, because the aggregate legitimately
changes state through its governed commands.

## Consequences
* The reviewer's exact reassign-then-commit sequence now fails closed at the
  reassignment step; pinned as a regression
  (`tests/test_v006_review_reproductions.py::TestP03ImmutableTenantOwnership`).
* Every identity field is covered by a parametrized write-once test.
* The same immutable-identity treatment is applied to `LineageEvent`
  (ADR-0014/P1-1) and is the model for future aggregates.
