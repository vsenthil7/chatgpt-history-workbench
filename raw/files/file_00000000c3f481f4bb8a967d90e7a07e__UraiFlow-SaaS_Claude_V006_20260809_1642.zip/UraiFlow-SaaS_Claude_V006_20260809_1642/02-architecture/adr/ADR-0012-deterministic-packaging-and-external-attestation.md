# ADR-0012 — Deterministic packaging, machine gates G09–G11, external attestation

Status: ACCEPTED (V004) · Amends: ADR-0009 · Drives: P0-4, P0-5, P0-6, P1-1,
P1-2, P1-3, P1-4 of the V003 independent review

## Context
The V003 ZIP physically shipped `.mypy_cache`/`.ruff_cache` bytes that the
manifest deliberately excluded — untracked content inside the integrity
boundary — because packaging was prose (ADR-0009) executed by hand. G09/G10
were declared but had no machine checkers, the manifest check compared only
paths/hashes/length, and the smoke result was not cryptographically tied to
the shipped ZIP.

## Decision
1. **Packaging is executable policy.** `scripts/package_release.py` is the only
   release path. It builds the payload from an explicit top-level allowlist,
   fails closed on unexpected or excluded material (`__pycache__`,
   `.pytest_cache`, `.mypy_cache`, `.ruff_cache`, `.coverage`,
   `.mutmut-cache`, `.venv`, `venv`, egg-info, `.pyc/.pyo`, VCS/tool caches),
   regenerates and fully validates the manifest over the exact frozen payload,
   builds a deterministic ZIP (sorted entries, fixed timestamps/permissions),
   rebuilds and proves byte-identical output, computes the final SHA-256, and
   never modifies the ZIP afterwards.
2. **Exact-artifact smoke.** The smoke suite runs against a fresh extraction of
   the final hashed ZIP itself — never a candidate tree — and the ZIP is
   re-hashed afterwards to prove it was untouched.
3. **External attestation.** Each release ships
   `UraiFlow-SaaS_Claude_VNNN_YYYYMMDD_HHMM_ATTESTATION.md` OUTSIDE the ZIP,
   stating the exact ZIP filename and SHA-256, product version, build
   timestamp, payload/manifest inventory, deterministic rebuild hashes, exact
   packaging command, clean-extraction smoke commands/results bound to that
   SHA-256, and tool/runtime versions. This resolves the G01 self-reference:
   the internal manifest protects the payload; the external attestation
   attests the complete final ZIP. No claim of "all shipped bytes are
   integrity-covered" is made by the manifest alone.
4. **Full manifest contract (P1-3).** `gen_manifest.py --check` validates the
   complete canonical structure: schema, project, product_version,
   `file_count` as an independent invariant, path uniqueness and canonical
   sort order, per-file bytes and SHA-256, exact payload↔manifest bijection,
   and absence of excluded material. Only `created` is declared variable.
5. **Machine gates (P1-1/P1-2).** `scripts/validate_rtm.py` (G09) proves every
   RTM row has a unique ID, governed status and resolvable test/evidence/ADR
   references. `scripts/validate_docs_consistency.py` (G10) proves version and
   product-name consistency, resolvable ADR references, absence of manually
   quoted volatile counts in current narrative docs, and that the build
   report's facts section regenerates byte-identically from machine evidence.
6. **Generated build report.** `BUILD-REPORT-V004.md` embeds a machine-generated
   facts section produced by `scripts/gen_build_report.py` from `evidence/`;
   volatile counts appear only there. Historical documents are frozen history
   and exempt from re-validation.
7. **Gate orchestration.** `scripts/run_release_gates.py` produces a distinct
   machine result and evidence file per gate G01–G10 plus a JSON summary; G11
   is the packager itself; G12 remains the independent ChatGPT review.
