# ADR-0002 — Work-object/domain taxonomy is owned by the receiving domain

**Status:** ACCEPTED (V002) · **Reversible:** yes

## Context
Baseline doc 19 ("DWOS Work Object Bridge", stale name) defines the parent work
platform's work-object taxonomy (Interview, Transcript-Review, Follow-up, Export work
objects) with required fields, inside UraiFlow documentation. The starter contract is
explicit: UraiFlow proposes; the owning domain validates and commits. A receiving
system's record taxonomy is that system's domain model.

## Decision
1. UraiFlow's reusable core knows only **generic candidate record types as strings**
   plus fields, confidence and source lineage. It ships no work-object taxonomy.
2. All delivery to receiving systems goes through the **target-system adapter
   contract** (`uraiflow.adapters.contract`): each adapter declares accepted record
   types, schema version, required fields, idempotency behaviour and rollback
   capability. The receiving domain (e.g. the parent work platform, or an IPBS pilot
   workbook adapter) owns validation semantics and final commit.
3. The `WorkObjectGateway` interface idea from doc 19 survives *as* the adapter
   contract; the taxonomy and required-field list in doc 19 are the receiving
   platform's documentation, not UraiFlow's. Doc 19 is superseded for the reusable
   product and preserved as history.
4. "DWOS" is recorded as a stale name (B001 inventory I-02) and not used in any new
   artifact.

## Consequences
- Adapter contract compliance is test-harnessed (`tests/test_adapter_contract.py`)
  so any adapter implementation can be verified without UraiFlow knowing its domain.
- Pilot-specific mappings (e.g. workbook columns) live in adapter configuration/data,
  never in reusable domain code (enforced by tenant-neutrality guard tests).
