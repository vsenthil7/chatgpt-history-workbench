# ADR-0001 — Proposal aggregate and state-machine ownership

**Status:** ACCEPTED (V002) · **Reversible:** yes (state model is internal until a public
contract exposes it)

## Context
Baseline doc 50 defines one proposal lifecycle starting at `CAPTURED → TRANSCRIBED →
EXTRACTED → …`, while baseline doc 13 defines separate state machines for Interview,
Recording, Audio segment, Transcription job and Transcript version. `CAPTURED`,
`TRANSCRIBED` and `EXTRACTED` are lifecycle states of *other* aggregates, not of a
record proposal. Mixing them into the proposal aggregate couples the proposal to
upstream persistence models, violating the modularity contract.

## Decision
1. **Aggregates:** `Capture`, `Transcript` and `Proposal` are separate aggregates.
   Upstream progress is represented by the existence of the upstream aggregate plus
   lineage events, not by proposal states.
2. **Proposal state machine (owned by the proposal module):**
   `PROPOSED → ROUTED → VALIDATED → AWAITING_CONFIRMATION →
   {CONFIRMED | PARTIALLY_CONFIRMED | REJECTED}`;
   `{CONFIRMED, PARTIALLY_CONFIRMED} → COMMITTING → {COMMITTED | COMMIT_FAILED}`;
   `COMMIT_FAILED → ROLLED_BACK`.
   `ROUTED → NEEDS_CLARIFICATION` when extraction yields no routable/valid candidates.
   Terminal states: `COMMITTED, REJECTED, ROLLED_BACK, NEEDS_CLARIFICATION`.
3. **Linkage:** every proposal carries `tenant_id`, `transcript_id` and `capture_id`;
   lineage events form the cross-aggregate audit chain.
4. Baseline doc 50 is superseded for the proposal aggregate; its intent (alternative
   states) is preserved in the model above.

## Consequences
- Transitions are enforced in code (`uraiflow.proposal.model`) and covered by
  transition tests including invalid-transition rejection (RTM SLICE-003).
- `NEEDS_CLARIFICATION` is terminal in V002; a re-clarification loop is deferred and
  listed as V003 backlog.
