# ADR-0006 — Proposal command eligibility, edit and revalidation lifecycle

**Status:** ACCEPTED (V003) · Review findings P0-2, P0-3, P0-4, P0-5

## Context
V002 allowed services to mutate proposal items before transition validation (a REJECTED
proposal could acquire CONFIRMED item decisions), allowed edits in terminal states, and
silently ignored unknown record ids in `confirm_selected`.

## Decision
1. **Aggregate-owned atomic commands.** `confirm_all`, `confirm_selected`, `reject_all`
   and `edit_item` are commands on the `Proposal` aggregate. Every command validates
   state eligibility and argument validity **before any mutation**; a failed command
   leaves the aggregate logically unchanged.
2. **Eligibility table.** Confirmation commands and edits are permitted only in
   `AWAITING_CONFIRMATION`. Every other state — including all terminal states
   (`COMMITTED`, `REJECTED`, `ROLLED_BACK`, `COMPENSATION_FAILED`,
   `NEEDS_CLARIFICATION`) — rejects them with `InvalidTransitionError`.
3. **Unknown ids fail fast.** `confirm_selected`/`edit_item` verify ids against the
   proposal's items first and raise `KeyError` naming the unknown ids, before mutating.
4. **Edit ⇒ revalidation.** An edit clears the item's stored validation result and sets
   `needs_revalidation`. While `needs_revalidation` is set, confirmation commands are
   refused. `Pipeline.revalidate` re-runs adapter contract validation synchronously and
   clears the flag; items whose revalidation produced errors cannot be confirmed.
5. Services (`ConfirmationService`) keep only tenant checks, delegation and lineage.

## Consequences
Regression tests assert failed commands leave decisions/fields unchanged, terminal
proposals are immutable, and edited proposals cannot be confirmed until revalidated.
