# Quality Gates — mandatory release ladder

A release is not review-ready until all applicable gates are green and evidence is attached.

| Gate | Minimum evidence |
|---|---|
| G01 Repository/manifest | package validator + manifest checksum pass |
| G02 Formatting/lint/type | project-standard static gates pass |
| G03 Unit/domain | all tests pass |
| G04 Coverage | 100% line + branch target or approved exception |
| G05 Contract/integration | all bounded-context contracts pass |
| G06 Architecture | dependency/ownership/tenant guards pass |
| G07 Mutation | FAIL-CLOSED (ADR-0011): every mutant machine-dispositioned; 0 logic survivors; no fallback counts; tool/parse/apply failures fail the gate |
| G08 Security | authz + tenant-isolation tests pass |
| G09 RTM | machine validator `scripts/validate_rtm.py` passes (unique IDs, governed statuses, resolvable references) |
| G10 Docs consistency | machine validator `scripts/validate_docs_consistency.py` passes (versions, names, ADR refs, no manual volatile counts, build report regenerates from evidence) |
| G11 Packaging | `scripts/package_release.py`: governed payload, deterministic byte-identical build, exact-final-ZIP smoke, external attestation (ADR-0012) |
| G12 Independent review | ChatGPT review findings resolved or explicitly accepted |

Never update quoted test counts manually in narrative documents. Volatile facts
live in machine evidence or in the machine-generated section of the build
report (`scripts/gen_build_report.py`); G10 enforces this mechanically for
current-release documents. Historical documents are frozen history.

Gate results are produced individually by `scripts/run_release_gates.py`
(evidence file per gate + `evidence/release-gates-summary.json`); G11 by
`scripts/package_release.py`; G12 remains the independent ChatGPT review.
