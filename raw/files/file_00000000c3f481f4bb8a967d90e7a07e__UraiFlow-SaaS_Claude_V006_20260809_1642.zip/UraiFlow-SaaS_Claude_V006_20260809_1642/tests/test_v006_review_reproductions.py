"""V006 review reproductions (executed-exploit regressions).

Each test is the reviewer's exact probe from the V005 deep review, asserting the
invariant now holds — not merely that the probe fails. Findings:

  P0-1  invalid receipt after a real side effect must not yield ROLLED_BACK
  P0-2  adapter descriptor drift after registration must not produce a trusted
        receipt for an unregistered identity
  P0-3  proposal tenant ownership is immutable (no reassignment)
  P1-1  lineage subject identifiers are canonical at storage
"""
from datetime import UTC, datetime

import pytest

from uraiflow.adapters.contract import AdapterDescriptor, CommitReceipt
from uraiflow.adapters.inmemory import InMemoryTargetAdapter
from uraiflow.core.clock import FixedClock
from uraiflow.core.errors import (
    InvalidTransitionError,
    RoutingError,
    TrustBoundaryViolation,
)
from uraiflow.core.tenancy import TenantContext
from uraiflow.extraction.rules import ConfigurableRuleExtractor, ExtractionRule, FieldSpec
from uraiflow.lineage.model import LineageEvent
from uraiflow.lineage.store import LineageStore
from uraiflow.pipeline.orchestrator import ConversationToActionPipeline, ProposalStatus
from uraiflow.proposal.model import Proposal, ProposalItem
from uraiflow.routing.registry import AdapterRegistry
from uraiflow.transcription.provider import DeterministicEchoProvider
from uraiflow.transcription.selector import ProviderSelector

T0 = datetime(2026, 1, 1, tzinfo=UTC)
CTX = TenantContext(tenant_id="tenant-a", actor_id="actor")


def _extractor(*pairs: tuple[str, str]) -> ConfigurableRuleExtractor:
    return ConfigurableRuleExtractor(rules=tuple(
        ExtractionRule(
            record_type=rt, pattern=rf"{kw}:\s*(?P<title>\S+)", confidence=0.9,
            fields=(FieldSpec(name="title", source="group:title"),),
        )
        for rt, kw in pairs
    ))


def _pipeline(registry: AdapterRegistry) -> ConversationToActionPipeline:
    return ConversationToActionPipeline(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={}, default_provider="echo",
        ),
        extractor=_extractor(("task", "task"), ("note", "note")),
        registry=registry,
        lineage=LineageStore(),
        clock=FixedClock(T0),
    )


# ------------------------------------------------------------- P0-1


class _SideEffectThenBadReceiptAdapter(InMemoryTargetAdapter):
    """Performs a REAL (in-memory) external side effect, then returns a receipt
    with the wrong tenant — the reviewer's P0-1 model."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.external_effects: list[str] = []

    def commit(self, ctx, record, idempotency_key):
        self.external_effects.append(record.record_id)  # side effect happens
        return CommitReceipt(
            receipt_id="rcpt-x",
            adapter_id=self.descriptor().adapter_id,
            adapter_name=self.descriptor().name,
            tenant_id="WRONG-TENANT",  # invalid binding
            record_id=record.record_id,
            idempotency_key=idempotency_key,
            target_ref="ext/row",
        )


class TestP01UncertainCommitNoFalseRollback:
    def test_side_effect_with_invalid_receipt_does_not_claim_rolled_back(self) -> None:
        registry = AdapterRegistry()
        adapter = _SideEffectThenBadReceiptAdapter(
            adapter_id="adp.effect", name="effect", schema_version="1.0",
            required_fields={"task": ("title",)},
        )
        registry.register(adapter)
        pipeline = ConversationToActionPipeline(
            selector=ProviderSelector(
                providers={"echo": DeterministicEchoProvider("echo")},
                tenant_policy={}, default_provider="echo",
            ),
            extractor=_extractor(("task", "task")),
            registry=registry, lineage=LineageStore(), clock=FixedClock(T0),
        )
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
        proposal.confirm_all()
        outcome = pipeline.commit(CTX, proposal)
        # the external effect DID happen
        assert adapter.external_effects == [proposal.items[0].record_id]
        # ...so the system must NOT claim a clean rollback
        assert proposal.status is not ProposalStatus.ROLLED_BACK
        assert proposal.status is ProposalStatus.COMPENSATION_FAILED
        # the uncertain commit is recorded from TRUSTED request-side data
        assert outcome.recovery is not None
        assert len(outcome.recovery.uncertain_commits) == 1
        uc = outcome.recovery.uncertain_commits[0]
        assert uc.adapter_id == "adp.effect"
        assert uc.tenant_id == "tenant-a"          # the real operation tenant
        assert uc.record_id == proposal.items[0].record_id
        assert proposal.uncertain_commits == outcome.recovery.uncertain_commits


# ------------------------------------------------------------- P0-2


class _DriftingAdapter(InMemoryTargetAdapter):
    """Advertises one identity at registration, another at commit time."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._drifted = False

    def descriptor(self) -> AdapterDescriptor:
        base = super().descriptor()
        if not self._drifted:
            return base
        return AdapterDescriptor(
            adapter_id="adp.drifted",  # not registered!
            name=base.name, schema_version=base.schema_version,
            accepted_record_types=base.accepted_record_types,
            required_fields=base.required_fields,
            supports_rollback=base.supports_rollback,
        )

    def commit(self, ctx, record, idempotency_key):
        self._drifted = True  # drift AFTER registration, before commit binding
        return CommitReceipt(
            receipt_id="rcpt-d", adapter_id="adp.drifted", adapter_name="d",
            tenant_id=ctx.tenant_id, record_id=record.record_id,
            idempotency_key=idempotency_key, target_ref="ext/row",
        )


class TestP02DescriptorDriftPinned:
    def test_drift_after_registration_cannot_produce_trusted_receipt(self) -> None:
        registry = AdapterRegistry()
        adapter = _DriftingAdapter(
            adapter_id="adp.registered", name="d", schema_version="1.0",
            required_fields={"task": ("title",)},
        )
        registry.register(adapter)
        pipeline = ConversationToActionPipeline(
            selector=ProviderSelector(
                providers={"echo": DeterministicEchoProvider("echo")},
                tenant_policy={}, default_provider="echo",
            ),
            extractor=_extractor(("task", "task")),
            registry=registry, lineage=LineageStore(), clock=FixedClock(T0),
        )
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
        proposal.confirm_all()
        outcome = pipeline.commit(CTX, proposal)
        # receipt validation uses the PINNED descriptor (adp.registered), so the
        # drifted receipt (adp.drifted) fails to bind → NOT committed.
        assert proposal.status is not ProposalStatus.COMMITTED
        assert outcome.failure is not None
        assert "adapter identity" in outcome.failure

    def test_pinned_descriptor_survives_adapter_mutation(self) -> None:
        registry = AdapterRegistry()
        adapter = _DriftingAdapter(
            adapter_id="adp.pinned", name="d", schema_version="1.0",
            required_fields={"task": ("title",)},
        )
        registry.register(adapter)
        adapter._drifted = True  # force drift
        registered = registry.resolve_by_id("adp.pinned")
        # the registry still knows the registration identity, not the drift
        assert registered.descriptor.adapter_id == "adp.pinned"
        with pytest.raises(RoutingError):
            registry.resolve_by_id("adp.drifted")


# ------------------------------------------------------------- P0-3


class TestP03ImmutableTenantOwnership:
    def test_tenant_id_cannot_be_reassigned(self) -> None:
        proposal = Proposal(
            proposal_id="prop-1", tenant_id="tenant-a", capture_id="cap-1",
            transcript_id="tr-1",
            items=[ProposalItem("rec-0", "task", {"title": "x"}, 0.9, "s")],
        )
        with pytest.raises(TrustBoundaryViolation, match="immutable"):
            proposal.tenant_id = "tenant-b"

    @pytest.mark.parametrize(
        "field", ["proposal_id", "tenant_id", "capture_id", "transcript_id"]
    )
    def test_all_identity_fields_are_write_once(self, field: str) -> None:
        proposal = Proposal(
            proposal_id="prop-1", tenant_id="tenant-a", capture_id="cap-1",
            transcript_id="tr-1",
            items=[ProposalItem("rec-0", "task", {"title": "x"}, 0.9, "s")],
        )
        with pytest.raises(TrustBoundaryViolation, match="immutable"):
            setattr(proposal, field, "hijacked")

    def test_business_state_remains_mutable(self) -> None:
        proposal = Proposal(
            proposal_id="prop-1", tenant_id="tenant-a", capture_id="cap-1",
            transcript_id="tr-1",
            items=[ProposalItem("rec-0", "task", {"title": "x"}, 0.9, "s")],
        )
        proposal.status = ProposalStatus.ROUTED  # allowed
        assert proposal.status is ProposalStatus.ROUTED

    def test_reassignment_then_foreign_commit_is_impossible(self) -> None:
        """The reviewer's full sequence: ingest as A, confirm, try to reassign
        to B, commit as B. Reassignment must be impossible at step 3."""
        registry = AdapterRegistry()
        registry.register(InMemoryTargetAdapter(
            adapter_id="adp.t", name="t", schema_version="1.0",
            required_fields={"task": ("title",)},
        ))
        pipeline = ConversationToActionPipeline(
            selector=ProviderSelector(
                providers={"echo": DeterministicEchoProvider("echo")},
                tenant_policy={}, default_provider="echo",
            ),
            extractor=_extractor(("task", "task")),
            registry=registry, lineage=LineageStore(), clock=FixedClock(T0),
        )
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
        proposal.confirm_all()
        with pytest.raises(TrustBoundaryViolation):
            proposal.tenant_id = "tenant-b"  # step 3 fails closed
        assert proposal.tenant_id == "tenant-a"

    def test_identity_fields_are_canonicalised(self) -> None:
        proposal = Proposal(
            proposal_id="  prop-1  ", tenant_id="  tenant-a  ",
            capture_id="  cap-1  ", transcript_id="  tr-1  ",
            items=[ProposalItem("rec-0", "task", {"title": "x"}, 0.9, "s")],
        )
        assert proposal.tenant_id == "tenant-a"
        assert proposal.proposal_id == "prop-1"


# ------------------------------------------------------------- P1-1


class _EvilStr(str):
    def __eq__(self, o): return True
    def __ne__(self, o): return False
    __hash__ = str.__hash__


class TestP11LineageSubjectCanonical:
    def test_hostile_subject_event_rejected_at_construction(self) -> None:
        with pytest.raises(TrustBoundaryViolation, match="subject_id"):
            LineageEvent(
                event_id="evt-1", tenant_id="tenant-a",
                subject_id=_EvilStr("secret-subject"), kind="k",
                payload={}, occurred_at=T0,
            )

    def test_store_rejects_non_exact_event(self) -> None:
        class FakeEvent:
            event_id = "evt-1"
            tenant_id = "tenant-a"
            subject_id = "s"
            kind = "k"
            payload: dict = {}  # noqa: RUF012 - test impostor
            occurred_at = T0

        store = LineageStore()
        with pytest.raises(TrustBoundaryViolation, match="exact LineageEvent"):
            store.append(CTX, FakeEvent())

    def test_cross_subject_leak_is_prevented(self) -> None:
        """The reviewer's probe: a same-tenant event with a hostile subject
        must not appear in an UNRELATED subject's audit history."""
        store = LineageStore()
        # the hostile event cannot even be constructed now, so it can never be
        # stored to leak across subjects.
        with pytest.raises(TrustBoundaryViolation):
            LineageEvent(
                event_id="evt-1", tenant_id="tenant-a",
                subject_id=_EvilStr("secret-subject"), kind="k",
                payload={}, occurred_at=T0,
            )
        # a genuine event is scoped to exactly its subject
        store.append(CTX, LineageEvent(
            event_id="evt-2", tenant_id="tenant-a", subject_id="subject-A",
            kind="k", payload={}, occurred_at=T0,
        ))
        assert store.for_subject(CTX, "subject-B") == ()
        assert len(store.for_subject(CTX, "subject-A")) == 1

    def test_non_datetime_timestamp_rejected(self) -> None:
        with pytest.raises(TypeError, match="datetime"):
            LineageEvent(
                event_id="evt-1", tenant_id="tenant-a", subject_id="s",
                kind="k", payload={}, occurred_at="2026-01-01",  # type: ignore[arg-type]
            )


# ---------------------------------------------- record_uncertain state guard


def test_record_uncertain_rejected_outside_compensation_failed() -> None:
    proposal = Proposal(
        proposal_id="prop-1", tenant_id="tenant-a", capture_id="cap-1",
        transcript_id="tr-1",
        items=[ProposalItem("rec-0", "task", {"title": "x"}, 0.9, "s")],
    )
    with pytest.raises(InvalidTransitionError, match="uncertain commits only apply"):
        proposal.record_uncertain(())
