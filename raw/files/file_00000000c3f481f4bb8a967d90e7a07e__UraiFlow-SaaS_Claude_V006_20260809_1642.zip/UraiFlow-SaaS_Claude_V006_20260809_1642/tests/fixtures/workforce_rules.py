"""Workforce extraction rules — acceptance fixture / example integration (ADR-0005).

This vocabulary belongs to a receiving workforce/timesheet domain. It is test
fixture data, deliberately outside reusable `src/uraiflow` product code.
"""
from uraiflow.extraction.rules import ExtractionRule, FieldSpec

NUMBER_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "ten": 10,
    "fifteen": 15, "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50,
    "sixty": 60, "ninety": 90,
}

WORKFORCE_RULES = (
    ExtractionRule(
        record_type="time_entry",
        pattern=r"spoke to (?:the )?(?P<contact>[A-Za-z]+) for (?P<minutes>\w+) minutes",
        confidence=0.92,
        fields=(
            FieldSpec(name="contact", source="group:contact", transform="str"),
            FieldSpec(name="minutes", source="group:minutes", transform="int"),
        ),
    ),
    ExtractionRule(
        record_type="follow_up",
        pattern=r"follow up",
        confidence=0.75,
        fields=(FieldSpec(name="note", source="text", transform="str"),),
    ),
    ExtractionRule(
        record_type="availability",
        pattern=r"available",
        confidence=0.70,
        fields=(FieldSpec(name="window", source="text", transform="str"),),
    ),
)

REQUIRED_FIELDS = {
    "time_entry": ("contact", "minutes"),
    "follow_up": ("note",),
    "availability": ("window",),
}


def build_extractor():
    from uraiflow.extraction.rules import ConfigurableRuleExtractor

    return ConfigurableRuleExtractor(rules=WORKFORCE_RULES, number_words=NUMBER_WORDS)
