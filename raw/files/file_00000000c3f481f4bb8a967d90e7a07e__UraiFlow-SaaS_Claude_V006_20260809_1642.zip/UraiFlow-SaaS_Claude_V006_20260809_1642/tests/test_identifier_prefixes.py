"""Machine-identifier prefix pins (V004 review P1-2, ADR-0011 §3).

Prefix-tagged IDs are opaque but *observable*: ``new_id("prop")`` yields
``prop-<uuid>``. The mutation gate now treats these prefixes as behavioural, so
each one needs a test that fails if the prefix changes. These assertions are
that safety net — a mutant flipping ``"prop"`` to anything else is killed here.
"""
import re
from datetime import UTC, datetime

from tests.fixtures.workforce_rules import build_extractor
from uraiflow.adapters.inmemory import InMemoryTargetAdapter
from uraiflow.capture.service import CaptureService
from uraiflow.confirmation.service import ConfirmationService
from uraiflow.core.clock import FixedClock
from uraiflow.core.tenancy import TenantContext
from uraiflow.extraction.model import CandidateRecord
from uraiflow.lineage.store import LineageStore
from uraiflow.pipeline.orchestrator import ConversationToActionPipeline
from uraiflow.routing.registry import AdapterRegistry
from uraiflow.transcription.provider import DeterministicEchoProvider
from uraiflow.transcription.selector import ProviderSelector
from uraiflow.transcription.service import TranscriptionService

T0 = datetime(2026, 1, 1, tzinfo=UTC)
CTX = TenantContext(tenant_id="tenant-a", actor_id="actor")


def _pipeline():
    registry = AdapterRegistry()
    registry.register(
        InMemoryTargetAdapter(
            adapter_id="adp.time",
            name="time",
            schema_version="1.0",
            required_fields={"time_entry": ("contact", "minutes")},
        )
    )
    lineage = LineageStore()
    return ConversationToActionPipeline(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={},
            default_provider="echo",
        ),
        extractor=build_extractor(),
        registry=registry,
        lineage=lineage,
        clock=FixedClock(T0),
    ), lineage


def test_capture_id_prefix() -> None:
    lineage = LineageStore()
    service = CaptureService(lineage=lineage, clock=FixedClock(T0))
    capture = service.capture(CTX, source_ref="s", content="c")
    assert capture.capture_id.startswith("cap-")


def test_transcript_id_prefix() -> None:
    lineage = LineageStore()
    capture = CaptureService(lineage=lineage, clock=FixedClock(T0)).capture(
        CTX, source_ref="s", content="c"
    )
    transcript = TranscriptionService(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={},
            default_provider="echo",
        ),
        lineage=lineage,
        clock=FixedClock(T0),
    ).transcribe(CTX, capture)
    assert transcript.transcript_id.startswith("tr-")


def test_proposal_and_record_id_prefixes() -> None:
    pipeline, _ = _pipeline()
    proposal = pipeline.ingest(
        CTX, source_ref="s", content="I spoke to Priya for 15 minutes."
    )
    assert proposal.proposal_id.startswith("prop-")
    assert all(item.record_id.startswith("rec-") for item in proposal.items)


def test_receipt_id_prefix() -> None:
    adapter = InMemoryTargetAdapter(
        adapter_id="adp.x", name="x", schema_version="1.0",
        required_fields={"t": ("title",)},
    )
    record = CandidateRecord(
        record_id="rec-1", record_type="t", fields={"title": "v"},
        confidence=1.0, source_text="s",
    )
    receipt = adapter.commit(CTX, record, "prop-1:rec-1")
    assert receipt.receipt_id.startswith("rcpt-")


def test_lineage_event_id_prefix() -> None:
    pipeline, lineage = _pipeline()
    proposal = pipeline.ingest(
        CTX, source_ref="s", content="I spoke to Priya for 15 minutes."
    )
    events = lineage.for_subject(CTX, proposal.proposal_id)
    assert events
    assert all(e.event_id.startswith("evt-") for e in events)


def test_confirmation_event_id_prefix() -> None:
    pipeline, lineage = _pipeline()
    proposal = pipeline.ingest(
        CTX, source_ref="s", content="I spoke to Priya for 15 minutes."
    )
    ConfirmationService(lineage=lineage, clock=FixedClock(T0)).confirm_all(
        CTX, proposal
    )
    decision_events = [
        e for e in lineage.for_subject(CTX, proposal.proposal_id)
        if e.kind.startswith("proposal.")
    ]
    assert decision_events
    assert all(re.match(r"evt-", e.event_id) for e in decision_events)


def test_recovery_event_id_prefix() -> None:
    """Recovery-service lineage events use the 'evt-' prefix (kills the
    new_id("evt") prefix mutation in recovery/service.py)."""
    from uraiflow.recovery.service import RecoveryService

    registry = AdapterRegistry()

    class _FlakyRollback(InMemoryTargetAdapter):
        def __init__(self, *a, **k) -> None:
            super().__init__(*a, **k)
            self._healed = False

        def rollback(self, ctx, receipt) -> None:
            if not self._healed:
                raise ConnectionError("down")
            super().rollback(ctx, receipt)

    flaky = _FlakyRollback(
        adapter_id="adp.f1", name="f1", schema_version="1.0",
        required_fields={"task": ("title",)},
    )

    class _FailCommit(InMemoryTargetAdapter):
        def commit(self, ctx, record, idempotency_key):
            raise TimeoutError("down")

    failing = _FailCommit(
        adapter_id="adp.d", name="d", schema_version="1.0",
        required_fields={"note": ("title",)},
    )
    registry.register(flaky)
    registry.register(failing)
    from uraiflow.extraction.rules import ConfigurableRuleExtractor, ExtractionRule, FieldSpec

    rules = tuple(
        ExtractionRule(
            record_type=rt, pattern=rf"{kw}:\s*(?P<title>\S+)", confidence=0.9,
            fields=(FieldSpec(name="title", source="group:title"),),
        )
        for rt, kw in (("task", "task"), ("note", "note"))
    )
    lineage = LineageStore()
    pipeline = ConversationToActionPipeline(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={}, default_provider="echo",
        ),
        extractor=ConfigurableRuleExtractor(rules=rules),
        registry=registry, lineage=lineage, clock=FixedClock(T0),
    )
    proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
    proposal.confirm_all()
    pipeline.commit(CTX, proposal)  # -> COMPENSATION_FAILED
    service = RecoveryService(
        registry=registry, lineage=lineage, clock=FixedClock(T0),
        authorized_operators=frozenset({"actor"}),
    )
    service.retry_rollback(CTX, proposal)
    recovery_events = [
        e for e in lineage.for_subject(CTX, proposal.proposal_id)
        if e.kind.startswith("recovery.")
    ]
    assert recovery_events
    assert all(e.event_id.startswith("evt-") for e in recovery_events)
