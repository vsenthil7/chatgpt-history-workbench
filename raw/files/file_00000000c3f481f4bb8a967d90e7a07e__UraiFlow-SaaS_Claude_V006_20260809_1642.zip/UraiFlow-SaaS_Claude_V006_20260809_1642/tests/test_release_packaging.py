"""V004 P0-4/P0-5 regressions (ADR-0012): packaging is executable, fail-closed
policy. Deliberately inserted cache/untracked material must never enter the
final payload, and the ZIP build must be deterministic.
"""
import importlib.util
from pathlib import Path

import pytest

_SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "package_release.py"
_spec = importlib.util.spec_from_file_location("package_release", _SCRIPT)
packager = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(packager)


def _seed_source(source: Path) -> None:
    (source / "src").mkdir(parents=True)
    (source / "src" / "module.py").write_text("x = 1\n")
    (source / "tests").mkdir()
    (source / "tests" / "test_module.py").write_text("def test_x():\n    pass\n")
    (source / "pyproject.toml").write_text("[project]\nname='x'\n")
    (source / "CLAUDE.md").write_text("guide\n")


class TestGovernedPayload:
    def test_inserted_caches_cannot_enter_payload(self, tmp_path: Path) -> None:
        """The exact V003 defect: .mypy_cache/.ruff_cache shipped in the ZIP."""
        source, payload = tmp_path / "source", tmp_path / "payload"
        _seed_source(source)
        for junk_dir in (".mypy_cache", ".ruff_cache", "__pycache__",
                         ".pytest_cache", ".venv"):
            (source / junk_dir).mkdir()
            (source / junk_dir / "junk.txt").write_text("junk")
        (source / "src" / "uraiflow.egg-info").mkdir()
        (source / "src" / "uraiflow.egg-info" / "PKG-INFO").write_text("meta")
        (source / "src" / "__pycache__").mkdir()
        (source / "src" / "__pycache__" / "module.cpython-312.pyc").write_bytes(b"\x00")
        (source / ".coverage").write_text("cov")
        (source / "src" / "stale.pyc").write_bytes(b"\x00")
        payload.mkdir()
        packager.build_payload(source, payload)
        shipped = sorted(str(p.relative_to(payload)) for p in payload.rglob("*"))
        assert not any(".mypy_cache" in p for p in shipped)
        assert not any(".ruff_cache" in p for p in shipped)
        assert not any("__pycache__" in p for p in shipped)
        assert not any(".egg-info" in p for p in shipped)  # nested build products
        assert not any(p.endswith(".pyc") for p in shipped)
        assert not any(".coverage" in p for p in shipped)
        packager.verify_payload_clean(payload)  # and it proves itself clean

    def test_unexpected_top_level_material_fails_packaging(self, tmp_path: Path) -> None:
        source, payload = tmp_path / "source", tmp_path / "payload"
        _seed_source(source)
        (source / "random-notes.txt").write_text("not governed")
        payload.mkdir()
        with pytest.raises(SystemExit, match="unexpected top-level"):
            packager.build_payload(source, payload)

    def test_verify_payload_clean_fails_closed_on_injected_junk(
        self, tmp_path: Path
    ) -> None:
        payload = tmp_path / "payload"
        (payload / "src").mkdir(parents=True)
        (payload / "src" / "ok.py").write_text("x=1\n")
        (payload / "src" / ".mypy_cache").mkdir()
        (payload / "src" / ".mypy_cache" / "sneak.json").write_text("{}")
        (payload / "src" / "pkg.egg-info").mkdir()
        (payload / "src" / "pkg.egg-info" / "PKG-INFO").write_text("meta")
        with pytest.raises(SystemExit, match="excluded material"):
            packager.verify_payload_clean(payload)


class TestDeterministicZip:
    def test_two_builds_from_frozen_payload_are_byte_identical(
        self, tmp_path: Path
    ) -> None:
        payload = tmp_path / "payload"
        (payload / "src").mkdir(parents=True)
        (payload / "src" / "a.py").write_text("a = 1\n")
        (payload / "b.md").write_text("# b\n")
        first = packager.deterministic_zip(payload, tmp_path / "one.zip", "root")
        second = packager.deterministic_zip(payload, tmp_path / "two.zip", "root")
        assert first == second
        assert (tmp_path / "one.zip").read_bytes() == (tmp_path / "two.zip").read_bytes()
