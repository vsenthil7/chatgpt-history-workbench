"""V004 P1-5 / P1-6 regressions (ADR-0013).

P1-5: on compensation failure the caller receives structured recovery data
(committed / compensated / unrecovered receipts, rollback failures, original
failure) instead of an empty receipts tuple and opaque strings.

P1-6: COMPENSATION_FAILED operator recovery — authorised retry of rollback and
authorised manual resolution with mandatory evidence, tenant-isolated,
idempotency-guarded, with immutable original failure history in lineage.
"""
from dataclasses import FrozenInstanceError
from datetime import UTC, datetime

import pytest

from uraiflow.adapters.inmemory import InMemoryTargetAdapter
from uraiflow.core.clock import FixedClock
from uraiflow.core.errors import (
    AuthorizationError,
    InvalidTransitionError,
    TenantIsolationError,
)
from uraiflow.core.tenancy import TenantContext
from uraiflow.extraction.rules import (
    ConfigurableRuleExtractor,
    ExtractionRule,
    FieldSpec,
)
from uraiflow.lineage.store import LineageStore
from uraiflow.pipeline.orchestrator import (
    CompensationReport,
    ConversationToActionPipeline,
)
from uraiflow.proposal.model import ProposalStatus
from uraiflow.recovery.service import RecoveryResult, RecoveryService
from uraiflow.routing.registry import AdapterRegistry
from uraiflow.transcription.provider import DeterministicEchoProvider
from uraiflow.transcription.selector import ProviderSelector

T0 = datetime(2026, 8, 9, 8, 0, tzinfo=UTC)
CTX = TenantContext(tenant_id="t1", actor_id="op-1")
CTX_OTHER_TENANT = TenantContext(tenant_id="t2", actor_id="op-1")
CTX_UNAUTHORISED = TenantContext(tenant_id="t1", actor_id="intruder")


class FlakyRollbackAdapter(InMemoryTargetAdapter):
    """Rollback fails until ``heal()`` is called; commit works normally."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.healed = False
        self.rollback_attempts = 0

    def rollback(self, ctx, receipt) -> None:
        self.rollback_attempts += 1
        if not self.healed:
            raise ConnectionError("rollback connection reset")
        super().rollback(ctx, receipt)

    def heal(self) -> None:
        self.healed = True


class FailingCommitAdapter(InMemoryTargetAdapter):
    def commit(self, ctx, record, idempotency_key):
        raise TimeoutError("target down")


def _build():
    lineage = LineageStore()
    registry = AdapterRegistry()
    flaky = FlakyRollbackAdapter(
        adapter_id="adp.flaky",
        name="flaky",
        schema_version="1.0",
        required_fields={"task": ("title",)},
    )
    failing = FailingCommitAdapter(
        adapter_id="adp.down",
        name="down",
        schema_version="1.0",
        required_fields={"note": ("title",)},
    )
    registry.register(flaky)
    registry.register(failing)
    rules = tuple(
        ExtractionRule(
            record_type=rt,
            pattern=rf"{kw}:\s*(?P<title>\S+)",
            confidence=0.9,
            fields=(FieldSpec(name="title", source="group:title"),),
        )
        for rt, kw in (("task", "task"), ("note", "note"))
    )
    pipeline = ConversationToActionPipeline(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={},
            default_provider="echo",
        ),
        extractor=ConfigurableRuleExtractor(rules=rules),
        registry=registry,
        lineage=lineage,
        clock=FixedClock(T0),
    )
    return pipeline, registry, lineage, flaky


def _fail_into_compensation_failed(pipeline, flaky):
    proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
    proposal.confirm_all()
    outcome = pipeline.commit(CTX, proposal)
    assert proposal.status is ProposalStatus.COMPENSATION_FAILED
    return proposal, outcome


def _recovery(pipeline, registry, lineage):
    return RecoveryService(
        registry=registry,
        lineage=lineage,
        clock=pipeline.clock,
        authorized_operators=frozenset({"op-1"}),
    )


# ------------------------------------------------------ P1-5: structured result


class TestStructuredRecoveryData:
    def test_outcome_carries_structured_recovery_report(self) -> None:
        pipeline, _registry, _lineage, flaky = _build()
        proposal, outcome = _fail_into_compensation_failed(pipeline, flaky)
        report = outcome.recovery
        assert report is not None
        assert report.original_failure == outcome.failure
        assert len(report.committed_receipts) == 1
        assert report.compensated_receipts == ()
        assert len(report.unrecovered_receipts) == 1
        assert report.unrecovered_receipts[0].adapter_id == "adp.flaky"
        assert len(report.rollback_failures) == 1
        assert proposal.unrecovered_receipts == report.unrecovered_receipts

    def test_successful_compensation_reports_compensated(self) -> None:
        pipeline, _registry, _lineage, flaky = _build()
        flaky.heal()
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
        proposal.confirm_all()
        outcome = pipeline.commit(CTX, proposal)
        assert proposal.status is ProposalStatus.ROLLED_BACK
        report = outcome.recovery
        assert report is not None
        assert len(report.compensated_receipts) == 1
        assert report.unrecovered_receipts == ()
        assert proposal.unrecovered_receipts == ()


# ---------------------------------------------------- P1-6: operator recovery


class TestOperatorRecovery:
    def test_retry_rollback_recovers_and_terminates(self) -> None:
        pipeline, registry, lineage, flaky = _build()
        proposal, _ = _fail_into_compensation_failed(pipeline, flaky)
        flaky.heal()
        recovery = _recovery(pipeline, registry, lineage)
        result = recovery.retry_rollback(CTX, proposal)
        assert result.unrecovered_receipts == ()
        assert proposal.status is ProposalStatus.ROLLED_BACK
        assert proposal.unrecovered_receipts == ()
        assert flaky.committed_count(CTX) == 0

    def test_retry_rollback_partial_failure_stays_recoverable(self) -> None:
        pipeline, registry, lineage, flaky = _build()
        proposal, _ = _fail_into_compensation_failed(pipeline, flaky)
        recovery = _recovery(pipeline, registry, lineage)
        result = recovery.retry_rollback(CTX, proposal)  # still failing
        assert len(result.unrecovered_receipts) == 1
        assert proposal.status is ProposalStatus.COMPENSATION_FAILED
        # audit: both the original and the retry failure are in lineage
        kinds = [e.kind for e in lineage.for_subject(CTX, proposal.proposal_id)]
        assert kinds.count("record.rollback_failed") >= 2

    def test_retry_requires_compensation_failed_state(self) -> None:
        pipeline, registry, lineage, flaky = _build()
        flaky.heal()
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
        proposal.confirm_all()
        pipeline.commit(CTX, proposal)
        recovery = _recovery(pipeline, registry, lineage)
        with pytest.raises(InvalidTransitionError):
            recovery.retry_rollback(CTX, proposal)

    def test_recovery_is_tenant_isolated(self) -> None:
        pipeline, registry, lineage, flaky = _build()
        proposal, _ = _fail_into_compensation_failed(pipeline, flaky)
        recovery = _recovery(pipeline, registry, lineage)
        with pytest.raises(TenantIsolationError):
            recovery.retry_rollback(CTX_OTHER_TENANT, proposal)

    def test_recovery_requires_authorised_operator(self) -> None:
        pipeline, registry, lineage, flaky = _build()
        proposal, _ = _fail_into_compensation_failed(pipeline, flaky)
        recovery = _recovery(pipeline, registry, lineage)
        with pytest.raises(AuthorizationError):
            recovery.retry_rollback(CTX_UNAUTHORISED, proposal)
        with pytest.raises(AuthorizationError):
            recovery.resolve_manually(CTX_UNAUTHORISED, proposal, "note")

    def test_manual_resolution_requires_evidence(self) -> None:
        pipeline, registry, lineage, flaky = _build()
        proposal, _ = _fail_into_compensation_failed(pipeline, flaky)
        recovery = _recovery(pipeline, registry, lineage)
        with pytest.raises(ValueError, match="evidence"):
            recovery.resolve_manually(CTX, proposal, "   ")

    def test_manual_resolution_terminates_with_audit(self) -> None:
        pipeline, registry, lineage, flaky = _build()
        proposal, _ = _fail_into_compensation_failed(pipeline, flaky)
        recovery = _recovery(pipeline, registry, lineage)
        recovery.resolve_manually(
            CTX, proposal, "manually deleted row flaky/… in target console"
        )
        assert proposal.status is ProposalStatus.MANUALLY_RESOLVED
        events = lineage.for_subject(CTX, proposal.proposal_id)
        kinds = [e.kind for e in events]
        # every recovery-emitted lineage event carries the "evt-" machine
        # prefix (G07: kills the new_id("evt") prefix mutation in the recovery
        # service, which no other test reaches on this path).
        recovery_events = [e for e in events if e.kind.startswith("recovery.")]
        assert recovery_events
        assert all(e.event_id.startswith("evt-") for e in recovery_events)
        # original failure history is preserved, resolution appended
        assert "proposal.compensation_failed" in kinds
        assert kinds[-1] == "recovery.manually_resolved"
        assert events[-1].payload["operator_id"] == "op-1"
        # terminal: no further recovery operations
        with pytest.raises(InvalidTransitionError):
            recovery.resolve_manually(CTX, proposal, "again")
        with pytest.raises(InvalidTransitionError):
            recovery.retry_rollback(CTX, proposal)

    def test_manual_resolution_keeps_unrecovered_evidence(self) -> None:
        pipeline, registry, lineage, flaky = _build()
        proposal, _ = _fail_into_compensation_failed(pipeline, flaky)
        recovery = _recovery(pipeline, registry, lineage)
        recovery.resolve_manually(CTX, proposal, "resolved in target console")
        # unrecovered receipts remain recorded on the aggregate as evidence
        assert len(proposal.unrecovered_receipts) == 1


class TestAggregateRecoveryGuards:
    def test_record_unrecovered_rejected_outside_compensation_failed(self) -> None:
        """The aggregate refuses recovery bookkeeping outside COMPENSATION_FAILED."""
        pipeline, _registry, _lineage, flaky = _build()
        flaky.heal()
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
        proposal.confirm_all()
        pipeline.commit(CTX, proposal)  # COMMITTED
        with pytest.raises(InvalidTransitionError, match="only apply"):
            proposal.record_unrecovered(())


def _build_two_flaky():
    """Pipeline with TWO flaky-rollback adapters plus a failing committer,
    yielding two unrecovered receipts (G07 mutants 318/322 kills)."""
    lineage = LineageStore()
    registry = AdapterRegistry()
    flaky_one = FlakyRollbackAdapter(
        adapter_id="adp.flaky1",
        name="flaky1",
        schema_version="1.0",
        required_fields={"task": ("title",)},
    )
    flaky_two = FlakyRollbackAdapter(
        adapter_id="adp.flaky2",
        name="flaky2",
        schema_version="1.0",
        required_fields={"memo": ("title",)},
    )
    failing = FailingCommitAdapter(
        adapter_id="adp.down",
        name="down",
        schema_version="1.0",
        required_fields={"note": ("title",)},
    )
    for adapter in (flaky_one, flaky_two, failing):
        registry.register(adapter)
    rules = tuple(
        ExtractionRule(
            record_type=rt,
            pattern=rf"{kw}:\s*(?P<title>\S+)",
            confidence=0.9,
            fields=(FieldSpec(name="title", source="group:title"),),
        )
        for rt, kw in (("task", "task"), ("memo", "memo"), ("note", "note"))
    )
    pipeline = ConversationToActionPipeline(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={},
            default_provider="echo",
        ),
        extractor=ConfigurableRuleExtractor(rules=rules),
        registry=registry,
        lineage=lineage,
        clock=FixedClock(T0),
    )
    return pipeline, registry, lineage, flaky_one, flaky_two


class TestRetryAttemptsEveryReceipt:
    def test_retry_continues_past_a_failed_rollback(self) -> None:
        """All-rollbacks-attempted applies to RECOVERY retries too: a failure on
        the first unrecovered receipt must not abandon the rest.
        Pins mutant 322 (continue→break in the retry loop)."""
        pipeline, registry, lineage, flaky_one, _flaky_two = _build_two_flaky()
        proposal = pipeline.ingest(
            CTX, source_ref="s", content="task: a\nmemo: m\nnote: b"
        )
        proposal.confirm_all()
        pipeline.commit(CTX, proposal)
        assert proposal.status is ProposalStatus.COMPENSATION_FAILED
        # compensation runs in reverse commit order (LIFO)
        assert [r.adapter_id for r in proposal.unrecovered_receipts] == [
            "adp.flaky2",
            "adp.flaky1",
        ]
        # heal the SECOND receipt in retry order: the first must fail and the
        # loop must still reach the second (kills continue→break)
        flaky_one.heal()
        service = RecoveryService(
            registry=registry,
            lineage=lineage,
            clock=FixedClock(T0),
            authorized_operators=frozenset({"op-1"}),
        )
        result = service.retry_rollback(CTX, proposal)
        assert [r.adapter_id for r in result.compensated_receipts] == ["adp.flaky1"]
        assert [r.adapter_id for r in result.unrecovered_receipts] == ["adp.flaky2"]
        assert proposal.status is ProposalStatus.COMPENSATION_FAILED
        assert [r.adapter_id for r in proposal.unrecovered_receipts] == ["adp.flaky2"]

    def test_retry_failure_evidence_names_adapter_and_error(self) -> None:
        """Rollback-failure strings are real evidence: adapter machine identity
        plus the normalised error, in the result AND in lineage.
        Pins mutant 318 (failure string replaced with None)."""
        pipeline, registry, lineage, _flaky_one, _flaky_two = _build_two_flaky()
        proposal = pipeline.ingest(
            CTX, source_ref="s", content="task: a\nmemo: m\nnote: b"
        )
        proposal.confirm_all()
        pipeline.commit(CTX, proposal)
        service = RecoveryService(
            registry=registry,
            lineage=lineage,
            clock=FixedClock(T0),
            authorized_operators=frozenset({"op-1"}),
        )
        result = service.retry_rollback(CTX, proposal)
        assert result.rollback_failures != ()
        for failure in result.rollback_failures:
            assert isinstance(failure, str)
            assert "adp.flaky" in failure
            assert "ConnectionError" in failure
            assert "rollback connection reset" in failure
        failed_events = [
            e for e in lineage.for_subject(CTX, proposal.proposal_id)
            if e.kind == "record.rollback_failed"
        ]
        assert failed_events
        assert all(
            isinstance(e.payload["error"], str) and "ConnectionError" in e.payload["error"]
            for e in failed_events
        )


class TestStructuredResultImmutability:
    def test_compensation_report_is_immutable(self) -> None:
        """Recovery evidence cannot be rewritten in place (ADR-0013 §2).
        Pins mutant 106 (CompensationReport frozen=True→False)."""
        report = CompensationReport(
            original_failure="f",
            committed_receipts=(),
            compensated_receipts=(),
            unrecovered_receipts=(),
            rollback_failures=(),
            contract_violations=(),
        )
        with pytest.raises(FrozenInstanceError):
            report.original_failure = "rewritten"  # type: ignore[misc]

    def test_recovery_result_is_immutable(self) -> None:
        """Pins mutant 303 (RecoveryResult frozen=True→False)."""
        result = RecoveryResult(
            compensated_receipts=(),
            unrecovered_receipts=(),
            rollback_failures=(),
        )
        with pytest.raises(FrozenInstanceError):
            result.rollback_failures = ("x",)  # type: ignore[misc]


class TestSuccessfulCommitHasNoRecoveryReport:
    def test_successful_commit_reports_no_recovery(self) -> None:
        """A clean commit carries NO recovery report: ``recovery`` is exactly
        ``None`` (not another falsy sentinel), no failure, no compensation.
        Pins mutant 112 (recovery default None→'')."""
        pipeline, _registry, _lineage, flaky = _build()
        flaky.heal()
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
        proposal.confirm_all()
        outcome = pipeline.commit(CTX, proposal)
        assert proposal.status is ProposalStatus.COMMITTED
        assert outcome.failure is None
        assert outcome.compensation_failures == ()
        assert outcome.recovery is None
