"""RTM: SLICE-003, DOM-001, INV-001..004 — generic extraction engine (ADR-0005)
and aggregate-owned proposal commands with pre-mutation eligibility (ADR-0006)."""
import copy

import pytest
from fixtures.workforce_rules import build_extractor

from uraiflow.core.errors import InvalidTransitionError, RevalidationRequiredError
from uraiflow.extraction.rules import (
    ConfigurableRuleExtractor,
    ExtractionRule,
    FieldSpec,
)
from uraiflow.proposal.model import (
    ItemDecision,
    Proposal,
    ProposalItem,
    ProposalStatus,
)

SAMPLE = (
    "I spoke to the auditor for twenty minutes, follow up on Monday, "
    "and tomorrow I am available ten to one."
)


# ---------------- generic extraction engine (fixture-supplied rules) ----------------

def test_engine_requires_rules_no_defaults():
    with pytest.raises(TypeError):
        ConfigurableRuleExtractor()  # type: ignore[call-arg]


def test_fixture_rules_find_all_three_record_types_in_sample():
    records = build_extractor().extract(SAMPLE)
    assert sorted(r.record_type for r in records) == [
        "availability",
        "follow_up",
        "time_entry",
    ]


def test_group_and_int_transforms():
    records = build_extractor().extract("I spoke to Priya for 15 minutes.")
    (rec,) = records
    assert rec.fields == {"contact": "Priya", "minutes": 15}
    assert rec.confidence >= 0.9
    assert "Priya" in rec.source_text


def test_number_words_transform():
    (rec,) = build_extractor().extract("spoke to Sam for twenty minutes")
    assert rec.fields["minutes"] == 20


def test_rule_skipped_when_int_unresolvable():
    records = build_extractor().extract("spoke to Sam for seven minutes")
    assert all(r.record_type != "time_entry" for r in records)


def test_engine_without_number_words_resolves_digits_only():
    engine = ConfigurableRuleExtractor(
        rules=(
            ExtractionRule(
                record_type="t",
                pattern=r"(?P<n>\w+) units",
                confidence=0.5,
                fields=(FieldSpec(name="n", source="group:n", transform="int"),),
            ),
        )
    )
    assert engine.extract("5 units")[0].fields["n"] == 5
    assert engine.extract("many units") == ()


def test_engine_rejects_malformed_field_source():
    engine = ConfigurableRuleExtractor(
        rules=(
            ExtractionRule(
                record_type="t",
                pattern=r"x",
                confidence=0.5,
                fields=(FieldSpec(name="n", source="header:n", transform="str"),),
            ),
        )
    )
    with pytest.raises(ValueError):
        engine.extract("x")


def test_extract_empty_for_unrelated_text():
    assert build_extractor().extract("the weather is nice") == ()


# ---------------- proposal aggregate commands (ADR-0006) ----------------

def _proposal(n_items: int = 2, status: ProposalStatus = ProposalStatus.PROPOSED) -> Proposal:
    items = [
        ProposalItem(
            record_id=f"rec-{i}",
            record_type="time_entry",
            fields={"contact": "A", "minutes": 5},
            confidence=0.9,
            source_text="s",
        )
        for i in range(n_items)
    ]
    p = Proposal(
        proposal_id="prop-1",
        tenant_id="tenant-a",
        capture_id="cap-1",
        transcript_id="tr-1",
        items=items,
    )
    p.status = status
    return p


def _snapshot(p: Proposal):
    return (p.status, p.needs_revalidation, copy.deepcopy(
        [(i.record_id, i.decision, dict(i.fields), tuple(i.validation_errors)) for i in p.items]
    ))


def test_happy_path_transitions():
    p = _proposal()
    for status in (
        ProposalStatus.ROUTED,
        ProposalStatus.VALIDATED,
        ProposalStatus.AWAITING_CONFIRMATION,
    ):
        p.advance(status)
    p.confirm_all()
    assert p.status is ProposalStatus.CONFIRMED
    p.advance(ProposalStatus.COMMITTING)
    p.advance(ProposalStatus.COMMITTED)


def test_compensation_states_path():
    p = _proposal(status=ProposalStatus.COMMITTING)
    p.advance(ProposalStatus.COMMIT_FAILED)
    p.advance(ProposalStatus.COMPENSATING)
    p.advance(ProposalStatus.COMPENSATION_FAILED)
    # ADR-0013: COMPENSATION_FAILED is operator-recoverable — it may reach
    # ROLLED_BACK (successful retry) or MANUALLY_RESOLVED (attested), nothing else.
    with pytest.raises(InvalidTransitionError):
        p.advance(ProposalStatus.COMMITTED)
    with pytest.raises(InvalidTransitionError):
        p.advance(ProposalStatus.COMMITTING)
    p.advance(ProposalStatus.MANUALLY_RESOLVED)
    # MANUALLY_RESOLVED is terminal
    with pytest.raises(InvalidTransitionError):
        p.advance(ProposalStatus.ROLLED_BACK)


def test_compensation_failed_can_reach_rolled_back_via_recovery():
    p = _proposal(status=ProposalStatus.COMPENSATION_FAILED)
    p.advance(ProposalStatus.ROLLED_BACK)


def test_compensating_can_reach_rolled_back():
    p = _proposal(status=ProposalStatus.COMPENSATING)
    p.advance(ProposalStatus.ROLLED_BACK)


def test_invalid_transition_rejected():
    with pytest.raises(InvalidTransitionError):
        _proposal().advance(ProposalStatus.COMMITTED)


def test_confirm_all_on_rejected_fails_without_mutation():
    p = _proposal(status=ProposalStatus.REJECTED)
    before = _snapshot(p)
    with pytest.raises(InvalidTransitionError):
        p.confirm_all()
    assert _snapshot(p) == before
    assert p.items[0].decision is ItemDecision.PENDING


@pytest.mark.parametrize(
    "status",
    [s for s in ProposalStatus if s is not ProposalStatus.AWAITING_CONFIRMATION],
)
def test_command_eligibility_matrix_blocks_all_other_states(status):
    for command in (
        lambda p: p.confirm_all(),
        lambda p: p.confirm_selected(["rec-0"]),
        lambda p: p.reject_all(),
        lambda p: p.edit_item("rec-0", {"contact": "B", "minutes": 9}),
    ):
        p = _proposal(status=status)
        before = _snapshot(p)
        with pytest.raises(InvalidTransitionError):
            command(p)
        assert _snapshot(p) == before


def test_confirm_selected_unknown_ids_fail_fast_atomically():
    p = _proposal(3, status=ProposalStatus.AWAITING_CONFIRMATION)
    before = _snapshot(p)
    with pytest.raises(KeyError) as excinfo:
        p.confirm_selected(["rec-0", "rec-404"])
    assert "rec-404" in str(excinfo.value)
    assert _snapshot(p) == before


def test_edit_unknown_id_fails_fast_atomically():
    p = _proposal(1, status=ProposalStatus.AWAITING_CONFIRMATION)
    before = _snapshot(p)
    with pytest.raises(KeyError):
        p.edit_item("rec-404", {"x": 1})
    assert _snapshot(p) == before


def test_confirm_selected_partitions_decisions():
    p = _proposal(3, status=ProposalStatus.AWAITING_CONFIRMATION)
    p.confirm_selected(["rec-1"])
    assert p.status is ProposalStatus.PARTIALLY_CONFIRMED
    assert [i.decision for i in p.items] == [
        ItemDecision.REJECTED,
        ItemDecision.CONFIRMED,
        ItemDecision.REJECTED,
    ]


def test_confirm_selected_all_items_is_confirmed_and_none_is_rejected():
    p = _proposal(2, status=ProposalStatus.AWAITING_CONFIRMATION)
    p.confirm_selected(["rec-0", "rec-1"])
    assert p.status is ProposalStatus.CONFIRMED
    q = _proposal(2, status=ProposalStatus.AWAITING_CONFIRMATION)
    q.confirm_selected([])
    assert q.status is ProposalStatus.REJECTED


def test_edit_sets_revalidation_flag_and_blocks_confirmation():
    p = _proposal(1, status=ProposalStatus.AWAITING_CONFIRMATION)
    p.edit_item("rec-0", {"contact": "B", "minutes": 9})
    assert p.needs_revalidation is True
    assert p.items[0].validation_errors == ()
    with pytest.raises(RevalidationRequiredError):
        p.confirm_all()
    assert p.status is ProposalStatus.AWAITING_CONFIRMATION


def test_apply_validation_clears_flag_and_blocks_invalid_confirmation():
    p = _proposal(2, status=ProposalStatus.AWAITING_CONFIRMATION)
    p.edit_item("rec-0", {"contact": "", "minutes": 9})
    p.apply_validation({"rec-0": ("missing contact",), "rec-1": ()})
    assert p.needs_revalidation is False
    with pytest.raises(InvalidTransitionError):
        p.confirm_all()  # would confirm an invalid item
    p.confirm_selected(["rec-1"])  # confirming only the valid item is fine
    assert p.status is ProposalStatus.PARTIALLY_CONFIRMED


def test_apply_validation_only_in_routed_or_awaiting():
    p = _proposal(1, status=ProposalStatus.COMMITTED)
    with pytest.raises(InvalidTransitionError):
        p.apply_validation({"rec-0": ()})
