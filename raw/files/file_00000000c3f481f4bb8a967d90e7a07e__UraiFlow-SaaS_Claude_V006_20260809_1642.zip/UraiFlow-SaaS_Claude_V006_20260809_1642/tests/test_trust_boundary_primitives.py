"""Adversarial trust-boundary regressions (ADR-0014).

These pin the exact hostile-subclass and impostor-object probes from the V004
independent review. Each proves that a security-relevant identity value cannot
smuggle attacker-controlled ``__eq__``/``__ne__``/``__hash__``/``strip`` past a
protected boundary. They are deliberately written as *executed exploits*: the
body is the attack, and the assertion is that the attack fails closed.
"""
import pytest

from uraiflow.adapters.contract import (
    AdapterContractError,
    AdapterDescriptor,
    CommitReceipt,
    validate_commit_receipt,
    validate_descriptor,
)
from uraiflow.core.clock import FixedClock
from uraiflow.core.errors import TrustBoundaryViolation
from uraiflow.core.primitives import (
    canonical_identifier,
    require_exact_type,
)
from uraiflow.core.tenancy import (
    TenantContext,
    require_context,
    require_same_tenant,
)
from uraiflow.extraction.model import CandidateRecord
from uraiflow.lineage.store import LineageStore
from uraiflow.recovery.service import RecoveryService
from uraiflow.routing.registry import AdapterRegistry


class EvilStr(str):
    """A hostile str subtype: lies on comparison, hashing and strip()."""

    def __new__(cls, actual: str, *, masquerade_as: str = "") -> "EvilStr":  # noqa: PYI034
        obj = super().__new__(cls, actual)
        obj._masquerade_as = masquerade_as or actual
        return obj

    def strip(self, *args, **kwargs):
        return "x"

    def __eq__(self, other):
        return True

    def __ne__(self, other):
        return False

    def __hash__(self):
        return hash(self._masquerade_as)




# --------------------------------------------------------- P0-1 tenant isolation


class TestTenantIsolationCannotBeBypassed:
    def test_reviewers_exact_probe_fails_closed(self) -> None:
        """The literal reproduction from the review: constructing a context
        from hostile strings must be rejected before any comparison."""
        with pytest.raises(TrustBoundaryViolation, match="tenant_id"):
            TenantContext(EvilStr("tenant-A"), EvilStr("actor"))

    def test_hostile_tenant_argument_to_require_same_tenant_is_rejected(
        self,
    ) -> None:
        ctx = TenantContext("tenant-A", "actor")
        with pytest.raises(TrustBoundaryViolation, match="tenant_id"):
            require_same_tenant(ctx, EvilStr("tenant-B"), "secret")

    def test_genuine_cross_tenant_still_denied(self) -> None:
        ctx = TenantContext("tenant-A", "actor")
        from uraiflow.core.errors import TenantIsolationError

        with pytest.raises(TenantIsolationError, match="may not access"):
            require_same_tenant(ctx, "tenant-B", "secret")

    def test_duck_typed_context_impostor_rejected(self) -> None:
        class FakeCtx:
            tenant_id = "tenant-A"
            actor_id = "actor"

        with pytest.raises(TrustBoundaryViolation, match="exact TenantContext"):
            require_context(FakeCtx())


# ------------------------------------------------------ P0-2 receipt binding


def _descriptor() -> AdapterDescriptor:
    return AdapterDescriptor(
        adapter_id="adp.real",
        name="real",
        schema_version="1.0",
        accepted_record_types=("task",),
        required_fields={"task": ("title",)},
        supports_rollback=True,
    )


def _record() -> CandidateRecord:
    return CandidateRecord(
        record_id="rec-1", record_type="task",
        fields={"title": "t"}, confidence=1.0, source_text="s",
    )


class TestReceiptBindingCannotBeBypassed:
    def test_hostile_receipt_rejected_at_construction(self) -> None:
        """The review's probe: every security value is actually wrong AND
        supplied as a hostile str. Canonicalisation at CommitReceipt
        construction rejects the subclass outright — the hostile receipt can
        never even be built, which is stronger than rejecting it at validation
        time."""
        with pytest.raises(TrustBoundaryViolation, match="receipt adapter_id"):
            CommitReceipt(
                receipt_id="r-1",
                adapter_id=EvilStr("adp.WRONG"),
                adapter_name="real",
                tenant_id=EvilStr("tenant-WRONG"),
                record_id=EvilStr("rec-WRONG"),
                idempotency_key=EvilStr("idem-WRONG"),
                target_ref="ref",
            )

    def test_wrong_but_canonical_receipt_rejected_by_validation(self) -> None:
        """A receipt built from plain (canonical) strings whose values are
        simply wrong is caught by validate_commit_receipt — the ordinary
        binding contract, now operating only on trustworthy primitives."""
        ctx = TenantContext("tenant-A", "actor")
        wrong = CommitReceipt(
            receipt_id="r-1", adapter_id="adp.WRONG", adapter_name="real",
            tenant_id="tenant-A", record_id="rec-1",
            idempotency_key="prop:rec-1", target_ref="ref",
        )
        with pytest.raises(AdapterContractError, match="adapter identity"):
            validate_commit_receipt(
                _descriptor(), ctx, _record(), "prop:rec-1", wrong
            )

    def test_receipt_fields_are_plain_str_after_construction(self) -> None:
        # a genuine receipt built from plain strings exposes only exact str
        receipt = CommitReceipt(
            receipt_id="r-1", adapter_id="adp.real",
            adapter_name="real", tenant_id="tenant-A", record_id="rec-1",
            idempotency_key="prop:rec-1", target_ref="ref",
        )
        assert all(
            type(getattr(receipt, f)) is str
            for f in ("receipt_id", "adapter_id", "tenant_id", "record_id",
                      "idempotency_key", "target_ref")
        )

    def test_hostile_receipt_id_rejected_at_construction(self) -> None:
        with pytest.raises(TrustBoundaryViolation, match="receipt receipt_id"):
            CommitReceipt(
                receipt_id=EvilStr("r-1"), adapter_id="adp.real",
                adapter_name="real", tenant_id="tenant-A", record_id="rec-1",
                idempotency_key="prop:rec-1", target_ref="ref",
            )

    def test_duck_typed_receipt_impostor_rejected(self) -> None:
        class FakeReceipt:
            adapter_id = "adp.real"
            tenant_id = "tenant-A"
            record_id = "rec-1"
            idempotency_key = "prop:rec-1"
            receipt_id = "r-1"
            target_ref = "ref"

        ctx = TenantContext("tenant-A", "actor")
        with pytest.raises(AdapterContractError, match="non-canonical receipt"):
            validate_commit_receipt(
                _descriptor(), ctx, _record(), "prop:rec-1", FakeReceipt()
            )

    def test_descriptor_impostor_rejected(self) -> None:
        class FakeDescriptor:
            adapter_id = "adp.real"
            name = "real"
            schema_version = "1.0"
            accepted_record_types = ("task",)
            required_fields = {"task": ("title",)}  # noqa: RUF012 - test impostor
            supports_rollback = True

        with pytest.raises(AdapterContractError, match="exact AdapterDescriptor"):
            validate_descriptor(FakeDescriptor())


# ------------------------------------------------- P0-3 recovery authorisation


class TestRecoveryAuthorisationCannotBeSpoofed:
    def test_hostile_actor_cannot_join_operator_allowlist(self) -> None:
        """An actor whose real value is 'attacker' but whose hash/eq
        masquerade as 'admin' must NOT gain operator rights: the allowlist is
        canonicalised to plain strings at construction, so membership compares
        'attacker' (the real value) against the set."""
        service = RecoveryService(
            registry=AdapterRegistry(),
            lineage=LineageStore(),
            clock=FixedClock(_now()),
            authorized_operators=frozenset({"admin"}),
        )
        # the canonical allowlist contains exactly 'admin'
        assert service._operators == frozenset({"admin"})
        # a hostile actor value cannot even be canonicalised: the exact-type
        # gate fires before any of its methods run
        attacker = EvilStr("attacker", masquerade_as="admin")
        with pytest.raises(TrustBoundaryViolation, match="exact built-in str"):
            canonical_identifier(attacker, field="actor_id")

    def test_hostile_operator_cannot_be_seeded_into_allowlist(self) -> None:
        with pytest.raises(TrustBoundaryViolation, match="authorized operator"):
            RecoveryService(
                registry=AdapterRegistry(),
                lineage=LineageStore(),
                clock=FixedClock(_now()),
                authorized_operators=frozenset({EvilStr("admin")}),
            )


# --------------------------------------------------------- primitives directly


class TestCanonicalPrimitives:
    def test_canonical_identifier_rejects_subclass(self) -> None:
        with pytest.raises(TrustBoundaryViolation, match="exact built-in str"):
            canonical_identifier(EvilStr("x"), field="thing")

    def test_subclass_rejection_message_names_the_boundary(self) -> None:
        """Pin the full rejection message (G07: kills the "boundaries)" message
        tail mutation in primitives.canonical_identifier)."""
        with pytest.raises(TrustBoundaryViolation) as exc:
            canonical_identifier(EvilStr("x"), field="thing")
        assert "rejected at trust boundaries)" in str(exc.value)

    def test_subclass_rejection_message_is_complete(self) -> None:
        """Pin the full rejection message (kills the trailing "boundaries)"
        message-fragment mutation in primitives.py)."""
        with pytest.raises(TrustBoundaryViolation) as excinfo:
            canonical_identifier(EvilStr("x"), field="thing")
        message = str(excinfo.value)
        assert "must be an exact built-in str" in message
        assert "str subclasses are rejected at trust boundaries)" in message

    def test_canonical_identifier_rejects_empty(self) -> None:
        with pytest.raises(TrustBoundaryViolation, match="non-empty"):
            canonical_identifier("   ", field="thing")

    def test_canonical_identifier_rejects_non_str(self) -> None:
        with pytest.raises(TrustBoundaryViolation, match="exact built-in str"):
            canonical_identifier(123, field="thing")

    def test_canonical_identifier_accepts_and_strips_plain_str(self) -> None:
        assert canonical_identifier("  ok  ", field="thing") == "ok"

    def test_require_exact_type_accepts_exact(self) -> None:
        ctx = TenantContext("t", "a")
        require_exact_type(ctx, TenantContext, boundary="x")  # no raise

    def test_require_exact_type_rejects_other(self) -> None:
        with pytest.raises(TrustBoundaryViolation, match="exact TenantContext"):
            require_exact_type(object(), TenantContext, boundary="x")


def _now():
    from datetime import UTC, datetime

    return datetime(2026, 1, 1, tzinfo=UTC)


class TestCanonicalisationWritesCorrectFields:
    """Kill setattr-field-name mutations (G07): a mutated field name in
    ``object.__setattr__(self, "<field>", canonical)`` would write the
    canonical value to the WRONG attribute, leaving the real identity field
    un-canonicalised (proven: it retains un-stripped/hostile input). Each
    assertion checks that the NAMED field is actually canonicalised.
    """

    def test_descriptor_fields_are_individually_canonicalised(self) -> None:
        d = AdapterDescriptor(
            adapter_id="adp.x  ", name="  disp  ", schema_version="  1.0  ",
            accepted_record_types=("  task  ",),
            required_fields={"  task  ": ("  title  ",)},
            supports_rollback=True,
        )
        # each field stripped/canonical → proves setattr targeted that field
        assert d.adapter_id == "adp.x"
        assert d.name == "disp"
        assert d.schema_version == "1.0"
        assert d.accepted_record_types == ("task",)
        assert list(d.required_fields) == ["task"]
        assert d.required_fields["task"] == ("title",)
        assert type(d.adapter_id) is str and type(d.name) is str

    def test_tenant_context_fields_are_individually_canonicalised(self) -> None:
        ctx = TenantContext("  tenant-a  ", "  actor-1  ")
        assert ctx.tenant_id == "tenant-a"   # tenant_id field canonicalised
        assert ctx.actor_id == "actor-1"     # actor_id field canonicalised
        assert type(ctx.tenant_id) is str and type(ctx.actor_id) is str

    def test_receipt_fields_are_individually_canonicalised(self) -> None:
        r = CommitReceipt(
            receipt_id="  r  ", adapter_id="  adp  ", adapter_name="  n  ",
            tenant_id="  t  ", record_id="  rec  ", idempotency_key="  k  ",
            target_ref="  ref  ",
        )
        assert (r.receipt_id, r.adapter_id, r.adapter_name, r.tenant_id,
                r.record_id, r.idempotency_key, r.target_ref) == (
            "r", "adp", "n", "t", "rec", "k", "ref")
