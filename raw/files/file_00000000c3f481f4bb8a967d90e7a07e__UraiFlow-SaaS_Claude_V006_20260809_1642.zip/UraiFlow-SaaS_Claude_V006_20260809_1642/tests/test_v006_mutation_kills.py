"""V006 mutation-kill tests.

The V006 AST mutation classifier (ADR-0011 amendment) treats every string not
in a docstring or a ``raise`` as behavioural. That correctly flags message
labels, canonicalisation field names, dataclass options and default values as
logic that must be killed by a real test asserting the observable behaviour or
exact message. Each test below kills one or more such mutants.
"""
from dataclasses import FrozenInstanceError

import pytest

from uraiflow.adapters.contract import AdapterDescriptor
from uraiflow.adapters.inmemory import InMemoryTargetAdapter
from uraiflow.core.errors import (
    AuthorizationError,
    InvalidTransitionError,
    TenantIsolationError,
    TrustBoundaryViolation,
)
from uraiflow.core.primitives import canonical_identifier, require_exact_type
from uraiflow.core.tenancy import TenantContext
from uraiflow.pipeline.orchestrator import (
    CompensationReport,
    UncertainCommit,
    _describe,
)
from uraiflow.proposal.model import Proposal, ProposalItem, ProposalStatus
from uraiflow.routing.registry import RegisteredAdapter


def _proposal(tenant="tenant-a"):
    return Proposal(
        proposal_id="prop-1", tenant_id=tenant, capture_id="cap-1",
        transcript_id="tr-1",
        items=[ProposalItem("rec-0", "task", {"title": "x"}, 0.9, "s")],
    )


# ---- frozen dataclasses (kills @dataclass(frozen=False) mutants) ----

class TestFrozenDataclasses:
    def test_uncertain_commit_is_frozen(self) -> None:
        uc = UncertainCommit(
            adapter_id="a", adapter_name="n", tenant_id="t", record_id="r",
            idempotency_key="k", reason="why",
        )
        with pytest.raises(FrozenInstanceError):
            uc.tenant_id = "other"  # type: ignore[misc]

    def test_registered_adapter_is_frozen(self) -> None:
        adapter = InMemoryTargetAdapter(
            adapter_id="adp.x", name="n", schema_version="1.0",
            required_fields={"task": ("title",)},
        )
        reg = RegisteredAdapter(adapter=adapter, descriptor=adapter.descriptor())
        with pytest.raises(FrozenInstanceError):
            reg.descriptor = adapter.descriptor()  # type: ignore[misc]


# ---- tuple default = () (kills `= None` default mutants) ----

class TestTupleDefaults:
    def test_proposal_uncertain_commits_defaults_to_empty_tuple(self) -> None:
        p = _proposal()
        assert p.uncertain_commits == ()
        assert isinstance(p.uncertain_commits, tuple)

    def test_proposal_unrecovered_defaults_to_empty_tuple(self) -> None:
        p = _proposal()
        assert p.unrecovered_receipts == ()
        assert isinstance(p.unrecovered_receipts, tuple)

    def test_compensation_report_uncertain_defaults_to_empty_tuple(self) -> None:
        r = CompensationReport(
            original_failure="f", committed_receipts=(), compensated_receipts=(),
            unrecovered_receipts=(), rollback_failures=(), contract_violations=(),
        )
        assert r.uncertain_commits == ()


# ---- _describe format (kills the return f"..." mutant) ----

class TestDescribeFormat:
    def test_describe_preserves_adapter_and_error(self) -> None:
        msg = _describe("adp-name", ValueError("boom"))
        assert msg == "adp-name: ValueError: boom"


# ---- canonicalisation field labels surface in the message ----

class TestCanonicalisationFieldLabels:
    @pytest.mark.parametrize("field_name", ["adapter_id", "custom label"])
    def test_field_label_appears_in_rejection_message(self, field_name) -> None:
        class Evil(str):
            def strip(self, *a, **k): return "x"
            __hash__ = str.__hash__
        with pytest.raises(TrustBoundaryViolation) as exc:
            canonical_identifier(Evil("x"), field=field_name)
        # anchored so a wrapped "XX{field}XX must be" mutant does not pass
        assert f"{field_name} must be an exact" in str(exc.value)

    def test_descriptor_field_labels_are_distinct(self) -> None:
        # empty schema_version → the message must name schema_version, proving
        # the field= label is wired to the right field.
        with pytest.raises(TrustBoundaryViolation) as exc:
            AdapterDescriptor(
                adapter_id="adp.x", name="n", schema_version="   ",
                accepted_record_types=("task",),
                required_fields={"task": ("title",)}, supports_rollback=True,
            )
        assert "schema_version must be" in str(exc.value)

    def test_tenant_context_field_labels(self) -> None:
        with pytest.raises(TrustBoundaryViolation) as exc:
            TenantContext("   ", "actor")
        assert "tenant_id must be" in str(exc.value)
        with pytest.raises(TrustBoundaryViolation) as exc:
            TenantContext("tenant-a", "   ")
        assert "actor_id must be" in str(exc.value)


# ---- require_exact_type boundary label ----

class TestExactTypeBoundaryLabel:
    def test_boundary_label_appears_in_message(self) -> None:
        class NotCtx:
            pass
        with pytest.raises(TrustBoundaryViolation) as exc:
            require_exact_type(NotCtx(), TenantContext, boundary="protected operation")
        assert "protected operation requires an exact" in str(exc.value)


# ---- tenant-guard subject labels surface in denial messages ----

class TestTenantGuardSubjectLabels:
    def test_commit_tenant_mismatch_names_proposal_subject(self) -> None:
        from uraiflow.core.tenancy import require_same_tenant
        ctx = TenantContext("tenant-a", "actor")
        with pytest.raises(TenantIsolationError) as exc:
            require_same_tenant(ctx, "tenant-b", "proposal")
        assert "access proposal of another tenant" in str(exc.value)


# ---- command eligibility labels (kills _require_commandable label mutants) ----

class TestCommandEligibilityLabels:
    def _confirmed_proposal(self):
        p = _proposal()
        p.status = ProposalStatus.COMMITTED  # a state where commands are invalid
        return p

    def test_confirm_selected_label_in_error(self) -> None:
        p = self._confirmed_proposal()
        with pytest.raises(InvalidTransitionError) as exc:
            p.confirm_selected(["rec-0"])
        # exact boundary: the wrapped mutant "XXconfirm_selectedXX" breaks this
        assert ": confirm_selected not allowed" in str(exc.value)

    def test_reject_all_label_in_error(self) -> None:
        p = self._confirmed_proposal()
        with pytest.raises(InvalidTransitionError) as exc:
            p.reject_all()
        assert ": reject_all not allowed" in str(exc.value)

    def test_edit_item_label_in_error(self) -> None:
        p = self._confirmed_proposal()
        with pytest.raises(InvalidTransitionError) as exc:
            p.edit_item("rec-0", {"title": "y"})
        assert ": edit_item not allowed" in str(exc.value)


# ---- standard_validate error messages (kills errors-tuple f-string mutants) ----

class TestValidationErrorMessages:
    def _descriptor(self):
        return InMemoryTargetAdapter(
            adapter_id="adp.v", name="vname", schema_version="1.0",
            required_fields={"task": ("title",)},
        ).descriptor()

    def test_unaccepted_record_type_message(self) -> None:
        from uraiflow.adapters.contract import standard_validate
        from uraiflow.extraction.model import CandidateRecord
        rec = CandidateRecord(record_id="r", record_type="unknown",
                              fields={"title": "x"}, confidence=0.9, source_text="s")
        result = standard_validate(self._descriptor(), rec)
        assert not result.ok
        assert "record type 'unknown' not accepted by adapter 'vname'" in result.errors[0]

    def test_missing_required_field_message(self) -> None:
        from uraiflow.adapters.contract import standard_validate
        from uraiflow.extraction.model import CandidateRecord
        rec = CandidateRecord(record_id="r", record_type="task",
                              fields={"title": ""}, confidence=0.9, source_text="s")
        result = standard_validate(self._descriptor(), rec)
        assert not result.ok
        assert "required field 'title' missing/empty for" in result.errors[0]
        assert "record type 'task'" in result.errors[0]


# ---- descriptor validation field labels for collections ----

class TestDescriptorCollectionFieldLabels:
    def test_accepted_record_type_canonicalised(self) -> None:
        d = InMemoryTargetAdapter(
            adapter_id="adp.x", name="n", schema_version="1.0",
            required_fields={"  task  ": ("title",)},
        ).descriptor()
        assert d.accepted_record_types == ("task",)  # field label wired correctly

    def test_required_field_name_canonicalised(self) -> None:
        d = InMemoryTargetAdapter(
            adapter_id="adp.x", name="n", schema_version="1.0",
            required_fields={"task": ("  title  ",)},
        ).descriptor()
        assert d.required_fields["task"] == ("title",)


# ---- receipt validation binds each field (kills receipt {field} label) ----

class TestReceiptFieldBinding:
    def test_receipt_identity_mismatch_is_rejected(self) -> None:
        from uraiflow.adapters.contract import CommitReceipt, validate_commit_receipt
        from uraiflow.core.errors import AdapterContractError
        from uraiflow.extraction.model import CandidateRecord
        adapter = InMemoryTargetAdapter(
            adapter_id="adp.r", name="r", schema_version="1.0",
            required_fields={"task": ("title",)},
        )
        ctx = TenantContext("tenant-a", "actor")
        rec = CandidateRecord(record_id="rec-0", record_type="task",
                              fields={"title": "x"}, confidence=0.9, source_text="s")
        bad = CommitReceipt(
            receipt_id="rc", adapter_id="adp.OTHER", adapter_name="r",
            tenant_id="tenant-a", record_id="rec-0", idempotency_key="k",
            target_ref="ref",
        )
        with pytest.raises(AdapterContractError) as exc:
            validate_commit_receipt(adapter.descriptor(), ctx, rec, "k", bad)
        assert "adapter" in str(exc.value)


# ---- recovery authorisation labels ----

class TestRecoveryAuthLabels:
    def test_unauthorised_operator_names_operation(self) -> None:
        from datetime import UTC, datetime

        from uraiflow.core.clock import FixedClock
        from uraiflow.lineage.store import LineageStore
        from uraiflow.recovery.service import RecoveryService
        svc = RecoveryService(registry=None, lineage=LineageStore(),
                              clock=FixedClock(datetime(2026, 1, 1, tzinfo=UTC)),
                              authorized_operators=frozenset())
        p = _proposal()
        p.status = ProposalStatus.COMPENSATION_FAILED
        ctx = TenantContext("tenant-a", "not-an-operator")
        with pytest.raises(AuthorizationError) as exc:
            svc.retry_rollback(ctx, p)
        assert "not authorised for retry_rollback" in str(exc.value)

    def test_manual_resolution_authorisation_label(self) -> None:
        from datetime import UTC, datetime

        from uraiflow.core.clock import FixedClock
        from uraiflow.lineage.store import LineageStore
        from uraiflow.recovery.service import RecoveryService
        svc = RecoveryService(registry=None, lineage=LineageStore(),
                              clock=FixedClock(datetime(2026, 1, 1, tzinfo=UTC)),
                              authorized_operators=frozenset())
        p = _proposal()
        p.status = ProposalStatus.COMPENSATION_FAILED
        ctx = TenantContext("tenant-a", "not-an-operator")
        with pytest.raises(AuthorizationError) as exc:
            svc.resolve_manually(ctx, p, evidence="x")
        assert "not authorised for resolve_manually" in str(exc.value)


# ---- rolled_back event payload key (kills "compensated" key mutant) ----

class TestEventPayloadKeys:
    def test_rolled_back_payload_uses_compensated_key(self) -> None:
        from datetime import UTC, datetime

        from uraiflow.adapters.inmemory import InMemoryTargetAdapter
        from uraiflow.core.clock import FixedClock
        from uraiflow.extraction.rules import (
            ConfigurableRuleExtractor,
            ExtractionRule,
            FieldSpec,
        )
        from uraiflow.lineage.store import LineageStore
        from uraiflow.pipeline.orchestrator import ConversationToActionPipeline
        from uraiflow.routing.registry import AdapterRegistry
        from uraiflow.transcription.provider import DeterministicEchoProvider
        from uraiflow.transcription.selector import ProviderSelector

        class _Boom(InMemoryTargetAdapter):
            def commit(self, ctx, record, idempotency_key):
                raise RuntimeError("down")

        registry = AdapterRegistry()
        registry.register(InMemoryTargetAdapter(
            adapter_id="adp.ok", name="ok", schema_version="1.0",
            required_fields={"task": ("title",)}))
        registry.register(_Boom(
            adapter_id="adp.boom", name="boom", schema_version="1.0",
            required_fields={"note": ("title",)}))
        extractor = ConfigurableRuleExtractor(rules=(
            ExtractionRule(record_type="task", pattern=r"task:\s*(?P<title>\S+)",
                           confidence=0.9, fields=(FieldSpec(name="title", source="group:title"),)),
            ExtractionRule(record_type="note", pattern=r"note:\s*(?P<title>\S+)",
                           confidence=0.9, fields=(FieldSpec(name="title", source="group:title"),)),
        ))
        pipeline = ConversationToActionPipeline(
            selector=ProviderSelector(
                providers={"echo": DeterministicEchoProvider("echo")},
                tenant_policy={}, default_provider="echo"),
            extractor=extractor, registry=registry, lineage=(lin := LineageStore()),
            clock=FixedClock(datetime(2026, 1, 1, tzinfo=UTC)))
        ctx = TenantContext("tenant-a", "actor")
        proposal = pipeline.ingest(ctx, source_ref="s", content="task: a\nnote: b")
        proposal.confirm_all()
        pipeline.commit(ctx, proposal)
        payloads = {e.kind: e.payload for e in lin.for_subject(ctx, proposal.proposal_id)}
        assert "compensated" in payloads["proposal.rolled_back"]


# ---- cross-tenant subject labels at every guard site (kills "proposal" subj) --

class TestCrossTenantSubjectLabels:
    """Every require_same_tenant(..., "proposal") guard surfaces the subject in
    its denial message. A foreign-tenant call at each site kills the subject
    label mutant (wrapped "XXproposalXX" breaks 'access proposal of ...')."""

    def _foreign(self):
        # a proposal owned by tenant-a, accessed with a tenant-b context
        owner = TenantContext("tenant-a", "actor")
        intruder = TenantContext("tenant-b", "actor")
        return owner, intruder

    def _proposal_a(self):
        return Proposal(
            proposal_id="prop-1", tenant_id="tenant-a", capture_id="cap-1",
            transcript_id="tr-1",
            items=[ProposalItem("rec-0", "task", {"title": "x"}, 0.9, "s")],
        )

    def _confirmation(self):
        from datetime import UTC, datetime

        from uraiflow.confirmation.service import ConfirmationService
        from uraiflow.core.clock import FixedClock
        from uraiflow.lineage.store import LineageStore
        return ConfirmationService(
            lineage=LineageStore(), clock=FixedClock(datetime(2026, 1, 1, tzinfo=UTC))
        )

    @pytest.mark.parametrize("method", ["confirm_all", "reject_all"])
    def test_confirmation_noarg_methods_reject_foreign_tenant(self, method) -> None:
        svc = self._confirmation()
        _, intruder = self._foreign()
        with pytest.raises(TenantIsolationError) as exc:
            getattr(svc, method)(intruder, self._proposal_a())
        assert "access proposal of another tenant" in str(exc.value)

    def test_confirm_selected_rejects_foreign_tenant(self) -> None:
        svc = self._confirmation()
        _, intruder = self._foreign()
        with pytest.raises(TenantIsolationError) as exc:
            svc.confirm_selected(intruder, self._proposal_a(), ["rec-0"])
        assert "access proposal of another tenant" in str(exc.value)

    def test_edit_rejects_foreign_tenant(self) -> None:
        svc = self._confirmation()
        _, intruder = self._foreign()
        with pytest.raises(TenantIsolationError) as exc:
            svc.edit(intruder, self._proposal_a(), "rec-0", {"title": "y"})
        assert "access proposal of another tenant" in str(exc.value)

    def _pipeline(self):
        from datetime import UTC, datetime

        from uraiflow.core.clock import FixedClock
        from uraiflow.extraction.rules import (
            ConfigurableRuleExtractor,
            ExtractionRule,
            FieldSpec,
        )
        from uraiflow.lineage.store import LineageStore
        from uraiflow.pipeline.orchestrator import ConversationToActionPipeline
        from uraiflow.routing.registry import AdapterRegistry
        from uraiflow.transcription.provider import DeterministicEchoProvider
        from uraiflow.transcription.selector import ProviderSelector
        registry = AdapterRegistry()
        registry.register(InMemoryTargetAdapter(
            adapter_id="adp.t", name="t", schema_version="1.0",
            required_fields={"task": ("title",)}))
        extractor = ConfigurableRuleExtractor(rules=(
            ExtractionRule(record_type="task", pattern=r"task:\s*(?P<title>\S+)",
                           confidence=0.9,
                           fields=(FieldSpec(name="title", source="group:title"),)),
        ))
        return ConversationToActionPipeline(
            selector=ProviderSelector(
                providers={"echo": DeterministicEchoProvider("echo")},
                tenant_policy={}, default_provider="echo"),
            extractor=extractor, registry=registry, lineage=LineageStore(),
            clock=FixedClock(datetime(2026, 1, 1, tzinfo=UTC)))

    def test_commit_rejects_foreign_tenant(self) -> None:
        pipeline = self._pipeline()
        _, intruder = self._foreign()
        with pytest.raises(TenantIsolationError) as exc:
            pipeline.commit(intruder, self._proposal_a())
        assert "access proposal of another tenant" in str(exc.value)

    def test_revalidate_rejects_foreign_tenant(self) -> None:
        pipeline = self._pipeline()
        _, intruder = self._foreign()
        with pytest.raises(TenantIsolationError) as exc:
            pipeline.revalidate(intruder, self._proposal_a())
        assert "access proposal of another tenant" in str(exc.value)

    def test_recovery_rejects_foreign_tenant(self) -> None:
        from datetime import UTC, datetime

        from uraiflow.core.clock import FixedClock
        from uraiflow.lineage.store import LineageStore
        from uraiflow.recovery.service import RecoveryService
        svc = RecoveryService(
            registry=None, lineage=LineageStore(),
            clock=FixedClock(datetime(2026, 1, 1, tzinfo=UTC)),
            authorized_operators=frozenset({"actor"}))
        p = self._proposal_a()
        p.status = ProposalStatus.COMPENSATION_FAILED
        intruder = TenantContext("tenant-b", "actor")
        with pytest.raises(TenantIsolationError) as exc:
            svc.retry_rollback(intruder, p)
        assert "access proposal recovery of another tenant" in str(exc.value)


# ---- collection & remaining field labels + type-name messages ----

class _Hostile(str):
    def strip(self, *a, **k): return "x"
    __hash__ = str.__hash__


class TestRemainingFieldLabelsAndTypeNames:
    def test_accepted_record_type_label(self) -> None:
        # empty record type → message names "accepted record type"
        with pytest.raises(TrustBoundaryViolation) as exc:
            AdapterDescriptor(
                adapter_id="adp.x", name="n", schema_version="1.0",
                accepted_record_types=("   ",),
                required_fields={"   ": ("title",)}, supports_rollback=True)
        assert "accepted record type must be" in str(exc.value)

    def test_required_fields_key_label(self) -> None:
        with pytest.raises(TrustBoundaryViolation) as exc:
            AdapterDescriptor(
                adapter_id="adp.x", name="n", schema_version="1.0",
                accepted_record_types=("task",),
                required_fields={"task": ("   ",)}, supports_rollback=True)
        assert "required field name must be" in str(exc.value)

    def test_receipt_field_label(self) -> None:
        from uraiflow.adapters.contract import CommitReceipt
        with pytest.raises(TrustBoundaryViolation) as exc:
            CommitReceipt(
                receipt_id="   ", adapter_id="a", adapter_name="n",
                tenant_id="t", record_id="r", idempotency_key="k", target_ref="ref")
        assert "receipt receipt_id must be" in str(exc.value)

    def test_registry_resolve_by_id_field_label(self) -> None:
        from uraiflow.routing.registry import AdapterRegistry
        registry = AdapterRegistry()
        with pytest.raises(TrustBoundaryViolation) as exc:
            registry.resolve_by_id("   ")
        assert "adapter_id must be" in str(exc.value)

    def test_require_context_tenant_label(self) -> None:
        # require_context path canonicalises tenant_id with its own label
        from uraiflow.core.tenancy import require_same_tenant
        ctx = TenantContext("tenant-a", "actor")
        with pytest.raises(TrustBoundaryViolation) as exc:
            require_same_tenant(ctx, "   ", "subject")
        assert "tenant_id must be" in str(exc.value)

    def test_operator_field_label(self) -> None:
        from datetime import UTC, datetime

        from uraiflow.core.clock import FixedClock
        from uraiflow.lineage.store import LineageStore
        from uraiflow.recovery.service import RecoveryService
        with pytest.raises(TrustBoundaryViolation) as exc:
            RecoveryService(
                registry=None, lineage=LineageStore(),
                clock=FixedClock(datetime(2026, 1, 1, tzinfo=UTC)),
                authorized_operators=frozenset({"   "}))
        assert "authorized operator must be" in str(exc.value)

    def test_lineage_field_label(self) -> None:
        from datetime import UTC, datetime

        from uraiflow.lineage.model import LineageEvent
        with pytest.raises(TrustBoundaryViolation) as exc:
            LineageEvent(event_id="   ", tenant_id="t", subject_id="s",
                         kind="k", payload={}, occurred_at=datetime(2026, 1, 1, tzinfo=UTC))
        assert "lineage event_id must be" in str(exc.value)

    def test_subclass_rejection_names_type(self) -> None:
        # {type(value).__name__} must appear unwrapped in the message
        with pytest.raises(TrustBoundaryViolation) as exc:
            canonical_identifier(_Hostile("x"), field="f")
        msg = str(exc.value)
        assert "got _Hostile" in msg  # wrapped "XX_HostileXX" would break this

    def test_require_exact_type_names_type(self) -> None:
        class Weird:
            pass
        with pytest.raises(TrustBoundaryViolation) as exc:
            require_exact_type(Weird(), TenantContext, boundary="b")
        assert "got Weird" in str(exc.value)

    def test_lineage_timestamp_type_named(self) -> None:
        from uraiflow.lineage.model import LineageEvent
        with pytest.raises(TypeError) as exc:
            LineageEvent(event_id="e", tenant_id="t", subject_id="s",
                         kind="k", payload={}, occurred_at="nope")  # type: ignore[arg-type]
        assert "got str" in str(exc.value)


# ---- recovery failure format (kills failure = f"..." mutant) ----

class TestRecoveryFailureFormat:
    def test_retry_rollback_failure_string_format(self) -> None:
        from datetime import UTC, datetime

        from uraiflow.adapters.contract import CommitReceipt
        from uraiflow.adapters.inmemory import InMemoryTargetAdapter
        from uraiflow.core.clock import FixedClock
        from uraiflow.lineage.store import LineageStore
        from uraiflow.recovery.service import RecoveryService
        from uraiflow.routing.registry import AdapterRegistry

        class _StickyRollback(InMemoryTargetAdapter):
            def rollback(self, ctx, receipt) -> None:
                raise ConnectionError("still down")

        registry = AdapterRegistry()
        registry.register(_StickyRollback(
            adapter_id="adp.sticky", name="sticky", schema_version="1.0",
            required_fields={"task": ("title",)}))
        ctx = TenantContext("tenant-a", "op")
        p = _proposal()
        p.status = ProposalStatus.COMPENSATION_FAILED
        receipt = CommitReceipt(
            receipt_id="rc", adapter_id="adp.sticky", adapter_name="sticky",
            tenant_id="tenant-a", record_id="rec-0", idempotency_key="k",
            target_ref="ref")
        p.record_unrecovered((receipt,))
        svc = RecoveryService(
            registry=registry, lineage=LineageStore(),
            clock=FixedClock(datetime(2026, 1, 1, tzinfo=UTC)),
            authorized_operators=frozenset({"op"}))
        result = svc.retry_rollback(ctx, p)
        # failure string format: "adp.sticky: ConnectionError: still down"
        assert result.rollback_failures
        assert result.rollback_failures[0] == "adp.sticky: ConnectionError: still down"


# ---- final 7: precise descriptor/validation/type messages ----

class TestFinalPreciseMessages:
    def test_descriptor_adapter_id_label(self) -> None:
        with pytest.raises(TrustBoundaryViolation) as exc:
            AdapterDescriptor(
                adapter_id="   ", name="n", schema_version="1.0",
                accepted_record_types=("task",),
                required_fields={"task": ("t",)}, supports_rollback=True)
        assert str(exc.value).startswith("adapter_id must be")

    def test_descriptor_name_label(self) -> None:
        with pytest.raises(TrustBoundaryViolation) as exc:
            AdapterDescriptor(
                adapter_id="adp.x", name="   ", schema_version="1.0",
                accepted_record_types=("task",),
                required_fields={"task": ("t",)}, supports_rollback=True)
        assert str(exc.value).startswith("adapter name must be")

    def test_descriptor_required_fields_key_label(self) -> None:
        with pytest.raises(TrustBoundaryViolation) as exc:
            AdapterDescriptor(
                adapter_id="adp.x", name="n", schema_version="1.0",
                accepted_record_types=("task",),
                required_fields={"   ": ("t",)}, supports_rollback=True)
        assert str(exc.value).startswith("required_fields key must be")

    def test_validation_missing_field_message_exact(self) -> None:
        from uraiflow.adapters.contract import standard_validate
        from uraiflow.extraction.model import CandidateRecord
        d = InMemoryTargetAdapter(
            adapter_id="adp.v", name="vname", schema_version="1.0",
            required_fields={"task": ("title",)}).descriptor()
        rec = CandidateRecord(record_id="r", record_type="task",
                              fields={"title": ""}, confidence=0.9, source_text="s")
        res = standard_validate(d, rec)
        # exact full message kills BOTH fragment mutants (284 and 285)
        assert res.errors[0] == (
            "required field 'title' missing/empty for record type 'task'"
        )

    def test_non_exact_descriptor_names_type(self) -> None:
        from uraiflow.adapters.contract import validate_descriptor
        from uraiflow.core.errors import AdapterContractError

        class FakeDesc:
            adapter_id = "a"; name = "n"; schema_version = "1"
            accepted_record_types = ("t",); required_fields = {"t": ("f",)}  # noqa: RUF012
            supports_rollback = True

        with pytest.raises(AdapterContractError) as exc:
            validate_descriptor(FakeDesc())
        assert "got FakeDesc" in str(exc.value)  # {type().__name__} unwrapped

    def test_require_exact_type_boundary_via_guard(self) -> None:
        from uraiflow.core.tenancy import require_same_tenant

        class FakeCtx:
            tenant_id = "t"; actor_id = "a"

        with pytest.raises(TrustBoundaryViolation) as exc:
            require_same_tenant(FakeCtx(), "t", "subj")
        # boundary label "protected operation" appears in the message
        assert "protected operation requires an exact" in str(exc.value)
