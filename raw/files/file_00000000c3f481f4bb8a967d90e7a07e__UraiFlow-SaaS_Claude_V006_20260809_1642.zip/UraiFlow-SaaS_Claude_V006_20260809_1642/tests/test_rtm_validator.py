"""Regressions for the G09 RTM validator (V004 review P0-4 and P1-1).

These pin the two exact probes the reviewer ran against scripts/validate_rtm.py:
a wrong-file ``file.py::test`` reference must FAIL, and a populated RTM must
never report "0 data rows checked".
"""
import importlib.util
from pathlib import Path

_SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "validate_rtm.py"
_spec = importlib.util.spec_from_file_location("validate_rtm", _SCRIPT)
rtm = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(rtm)


def _write_rtm(tmp_path: Path, monkeypatch, body: str) -> None:
    rtm_file = tmp_path / "RTM-V004.md"
    rtm_file.write_text(body, encoding="utf-8")
    monkeypatch.setattr(rtm, "RTM", rtm_file)
    monkeypatch.setattr(rtm, "EVIDENCE", tmp_path / "evidence")


def _functions(monkeypatch, mapping: dict[str, set[str]]) -> None:
    monkeypatch.setattr(rtm, "_test_functions", lambda: mapping)


HEADER = "| ID | Req | Evidence/Test | Status |\n|---|---|---|---|\n"


def test_wrong_file_test_reference_fails(tmp_path, monkeypatch) -> None:
    """The reviewer's P0-4 probe: a real test name attached to the WRONG file
    must be reported as unresolvable."""
    _functions(monkeypatch, {
        "tests/test_adapter_contract.py": {"test_something_else"},
        "tests/test_identity.py": {"test_duplicate_display_names_with_distinct_ids"},
    })
    _write_rtm(tmp_path, monkeypatch, HEADER + (
        "| ADP-1 | x | "
        "`tests/test_adapter_contract.py::"
        "test_duplicate_display_names_with_distinct_ids` | ENFORCED |\n"
    ))
    problems, rows = rtm.validate()
    assert rows == 1
    assert any("does not exist in tests/test_adapter_contract.py" in p
               for p in problems)


def test_correct_file_test_reference_passes(tmp_path, monkeypatch) -> None:
    _functions(monkeypatch, {
        "tests/test_identity.py": {"test_duplicate_display_names_with_distinct_ids"},
    })
    _write_rtm(tmp_path, monkeypatch, HEADER + (
        "| ADP-1 | x | "
        "`tests/test_identity.py::"
        "test_duplicate_display_names_with_distinct_ids` | ENFORCED |\n"
    ))
    problems, rows = rtm.validate()
    assert problems == []
    assert rows == 1


def test_bare_unqualified_test_reference_rejected(tmp_path, monkeypatch) -> None:
    _functions(monkeypatch, {"tests/test_x.py": {"test_a", "test_b"}})
    _write_rtm(tmp_path, monkeypatch, HEADER + (
        "| ADP-1 | x | `tests/test_x.py::test_a`, `::test_b` | ENFORCED |\n"
    ))
    problems, _ = rtm.validate()
    assert any("under-specified test reference '::test_b'" in p for p in problems)


def test_populated_rtm_never_reports_zero_rows(tmp_path, monkeypatch) -> None:
    """The reviewer's P1-1 probe: evidence must not claim PASS with 0 rows for
    a populated RTM. The count equals the rows actually validated."""
    _functions(monkeypatch, {"tests/test_x.py": {"test_a", "test_b", "test_c"}})
    _write_rtm(tmp_path, monkeypatch, HEADER + (
        "| RQ-1 | a | `tests/test_x.py::test_a` | ENFORCED |\n"
        "| RQ-2 | b | `tests/test_x.py::test_b` | ENFORCED |\n"
        "| RQ-3 | c | `tests/test_x.py::test_c` | ENFORCED |\n"
    ))
    exit_code = rtm.main()
    assert exit_code == 0
    evidence = (tmp_path / "evidence" / "G09-rtm.txt").read_text()
    assert "0 data rows checked" not in evidence
    assert "3 data rows checked" in evidence


def test_duplicate_ids_reported(tmp_path, monkeypatch) -> None:
    _functions(monkeypatch, {"tests/test_x.py": {"test_a"}})
    _write_rtm(tmp_path, monkeypatch, HEADER + (
        "| RQ-1 | a | `tests/test_x.py::test_a` | ENFORCED |\n"
        "| RQ-1 | a | `tests/test_x.py::test_a` | ENFORCED |\n"
    ))
    problems, rows = rtm.validate()
    assert rows == 2
    assert any("duplicate requirement ID: RQ-1" in p for p in problems)


def test_invalid_status_reported(tmp_path, monkeypatch) -> None:
    _functions(monkeypatch, {"tests/test_x.py": {"test_a"}})
    _write_rtm(tmp_path, monkeypatch, HEADER + (
        "| RQ-1 | a | `tests/test_x.py::test_a` | LGTM |\n"
    ))
    problems, _ = rtm.validate()
    assert any("invalid status" in p for p in problems)


def test_missing_rtm_file_reported(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr(rtm, "RTM", tmp_path / "does-not-exist.md")
    problems, rows = rtm.validate()
    assert rows == 0
    assert any("RTM file missing" in p for p in problems)


def test_empty_rtm_reported(tmp_path, monkeypatch) -> None:
    _functions(monkeypatch, {"tests/test_x.py": {"test_a"}})
    _write_rtm(tmp_path, monkeypatch, HEADER)
    problems, rows = rtm.validate()
    assert rows == 0
    assert any("no requirement rows" in p for p in problems)


def test_enforced_without_artifact_reported(tmp_path, monkeypatch) -> None:
    _functions(monkeypatch, {"tests/test_x.py": {"test_a"}})
    _write_rtm(tmp_path, monkeypatch, HEADER + (
        "| RQ-1 | a | just prose, no references | ENFORCED |\n"
    ))
    problems, _ = rtm.validate()
    assert any("references no test/gate/evidence" in p for p in problems)
