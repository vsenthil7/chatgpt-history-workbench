"""RTM: SLICE-001, SLICE-002, SaaS-002 — capture stub, provider abstraction,
per-tenant provider policy, transcription lineage."""
from datetime import UTC, datetime

import pytest

from uraiflow.capture.service import CaptureService
from uraiflow.core.clock import FixedClock
from uraiflow.core.errors import RoutingError, TenantIsolationError
from uraiflow.core.tenancy import TenantContext
from uraiflow.lineage.store import LineageStore
from uraiflow.transcription.provider import (
    DeterministicEchoProvider,
    TranscriptionRequest,
)
from uraiflow.transcription.selector import ProviderSelector
from uraiflow.transcription.service import TranscriptionService

T0 = datetime(2026, 8, 8, 12, 0, tzinfo=UTC)
CTX_A = TenantContext(tenant_id="tenant-a", actor_id="user-1")
CTX_B = TenantContext(tenant_id="tenant-b", actor_id="user-2")


def _services():
    lineage = LineageStore()
    clock = FixedClock(T0)
    capture = CaptureService(lineage=lineage, clock=clock)
    providers = {
        "echo-primary": DeterministicEchoProvider("echo-primary"),
        "echo-alt": DeterministicEchoProvider("echo-alt"),
    }
    selector = ProviderSelector(
        providers=providers,
        tenant_policy={"tenant-b": "echo-alt"},
        default_provider="echo-primary",
    )
    transcription = TranscriptionService(selector=selector, lineage=lineage, clock=clock)
    return lineage, capture, transcription


def test_capture_creates_record_and_lineage():
    lineage, capture, _ = _services()
    cap = capture.capture(CTX_A, source_ref="call-77", content="hello world")
    assert cap.tenant_id == "tenant-a"
    assert cap.media_type == "audio/opus"
    events = lineage.for_subject(CTX_A, cap.capture_id)
    assert [e.kind for e in events] == ["capture.recorded"]
    assert events[0].payload["source_ref"] == "call-77"


def test_capture_rejects_empty_content():
    _, capture, _ = _services()
    with pytest.raises(ValueError):
        capture.capture(CTX_A, source_ref="call-77", content="   ")


def test_provider_selection_uses_default_then_tenant_policy():
    _, capture, transcription = _services()
    cap_a = capture.capture(CTX_A, source_ref="s", content="text a")
    cap_b = capture.capture(CTX_B, source_ref="s", content="text b")
    t_a = transcription.transcribe(CTX_A, cap_a)
    t_b = transcription.transcribe(CTX_B, cap_b)
    assert t_a.provider_name == "echo-primary"
    assert t_b.provider_name == "echo-alt"


def test_selector_rejects_unknown_provider_name():
    selector = ProviderSelector(
        providers={"echo": DeterministicEchoProvider("echo")},
        tenant_policy={"tenant-a": "missing"},
        default_provider="echo",
    )
    with pytest.raises(RoutingError):
        selector.select(CTX_A)


def test_echo_provider_language_hint_default_and_override():
    provider = DeterministicEchoProvider("echo")
    r1 = provider.transcribe(
        TranscriptionRequest(tenant_id="t", capture_id="c", content="x")
    )
    r2 = provider.transcribe(
        TranscriptionRequest(tenant_id="t", capture_id="c", content="x", language_hint="cy")
    )
    assert (r1.language, r2.language) == ("en", "cy")


def test_transcription_links_capture_and_writes_lineage():
    lineage, capture, transcription = _services()
    cap = capture.capture(CTX_A, source_ref="s", content="the words")
    transcript = transcription.transcribe(CTX_A, cap)
    assert transcript.capture_id == cap.capture_id
    assert transcript.text == "the words"
    kinds = [e.kind for e in lineage.for_subject(CTX_A, transcript.transcript_id)]
    assert kinds == ["transcript.created"]


def test_transcription_denies_foreign_capture():
    _, capture, transcription = _services()
    cap_b = capture.capture(CTX_B, source_ref="s", content="secret")
    with pytest.raises(TenantIsolationError):
        transcription.transcribe(CTX_A, cap_b)
