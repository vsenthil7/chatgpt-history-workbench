# Release Procedure (ADR-0009 as amended by ADR-0012)

Packaging and verification are executable policy. Manual tree copying is
prohibited; the only release path is the deterministic packager.

1. **Gates + evidence:** `python scripts/run_release_gates.py` — distinct
   machine result and evidence file per gate G01–G10 (repository/manifest,
   lint/type, tests, coverage, contracts, architecture, fail-closed mutation,
   tenant/security, RTM, docs consistency) plus
   `evidence/release-gates-summary.json`. A release run must include G07.
2. **Final docs:** RTM/backlog/ADRs updated. `python scripts/gen_build_report.py`
   regenerates the machine-generated facts section of the build report from
   evidence; volatile counts never appear in prose (G10 enforces this
   mechanically for current-release docs).
3. **Manifest:** `python scripts/gen_manifest.py` then
   `python scripts/gen_manifest.py --check` (complete canonical contract per
   ADR-0012 §4).
4. **Package + attest (G11):** `python scripts/package_release.py --version VNNN`
   — governed allowlist payload, fail-closed exclusion of all generated
   caches/build material, manifest regeneration + full validation inside the
   payload, deterministic ZIP, byte-identical double build, final SHA-256
   freeze, clean extraction of the exact final ZIP, smoke suite over the
   extracted artifact, and generation of
   `UraiFlow-SaaS_Claude_VNNN_YYYYMMDD_HHMM_ATTESTATION.md` outside the ZIP
   binding every result to the final ZIP SHA-256. The ZIP is never modified
   after its hash is calculated.
5. **Hand-off (G12):** deliver BOTH the ZIP and the external attestation for
   independent ChatGPT review; the reviewer verifies the SHA-256 of the
   received ZIP against the attestation.
