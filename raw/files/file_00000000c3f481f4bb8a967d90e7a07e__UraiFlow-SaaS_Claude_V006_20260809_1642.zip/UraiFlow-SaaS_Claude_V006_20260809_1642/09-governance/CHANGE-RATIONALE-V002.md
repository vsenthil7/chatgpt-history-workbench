# V002 Change Rationale (Claude build)

**Input:** `UraiFlow-SaaS_ChatGPT_V001_20260808_1318.zip` · **Product version:** 0.9.0-dev

## What changed and why
- **B001 executed:** baseline accepted; contradiction/stale-name inventory recorded
  (`00-control/B001-BASELINE-ACCEPTANCE.md`). Baseline untouched under `10-baseline/`.
- **ADR-0001..0004 created:** proposal state ownership, work-object taxonomy ownership,
  manifest authority, stack/versioning. All reversible; all traceable to inventory items.
- **First vertical slice implemented** (`src/uraiflow/`): capture stub → transcript via
  replaceable provider abstraction with per-tenant policy → rule-based extraction →
  proposal (ADR-0001 state machine) → human confirmation → routing → target-system
  adapter contract with idempotent commit and compensation, full lineage throughout.
- **Test suite as contracts** (`tests/`): declared before implementation; red state and
  green/coverage evidence preserved under `evidence/`.
- **Governance tooling:** `scripts/gen_manifest.py` (generate/verify root manifest,
  ADR-0003); builder execution rule added to `00-control/`.

## Explicitly not done (honest deferrals)
- Mutation testing (EX-001, V003 item 1).
- Real audio ingestion, real providers, persistence, CI definition (V003 backlog).
