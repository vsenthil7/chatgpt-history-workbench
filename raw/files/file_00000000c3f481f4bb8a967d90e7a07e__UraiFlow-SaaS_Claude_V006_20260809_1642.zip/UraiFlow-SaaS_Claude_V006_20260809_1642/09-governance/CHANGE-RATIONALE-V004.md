# Change Rationale — V004

Driver: independent ChatGPT deep review of the actual
`UraiFlow-SaaS_Claude_V003_20260808_2320.zip` (received 09/08/2026). Direction
accepted verbatim: V003 stays as the base; V004 hardens adapter identity,
receipt integrity, mutation-gate correctness and release/evidence machinery
BEFORE persistence/real providers.

## Contract changes (deliberate, ADR-governed)
1. **ADR-0010** — `AdapterDescriptor.adapter_id` machine identity added;
   `CommitReceipt.adapter_id` added; `AdapterRegistry.resolve_by_name` removed
   in favour of `resolve_by_id`; registration made atomic; receipts validated
   at the adapter boundary. Existing tests referencing name-resolution were
   updated to the identity contract — this is the reviewed P0-1/P0-2 fix, not
   test-patching.
2. **ADR-0011** — G07 mutation gate rewritten fail-closed; the previous
   fail-open behaviours are pinned out by dedicated gate-script tests.
3. **ADR-0012** — packaging/attestation/manifest/G09/G10 machinery made
   executable; ADR-0009's prose sequencing superseded by
   `scripts/package_release.py` + `scripts/run_release_gates.py`.
4. **ADR-0013** — COMPENSATION_FAILED becomes operator-recoverable
   (ROLLED_BACK via retry, or terminal MANUALLY_RESOLVED via attested manual
   resolution); structured `CompensationReport` added to commit outcomes; the
   V003 state-machine test asserting COMPENSATION_FAILED terminality was
   updated to the new governed transition set.

## Version
Product version advanced to `0.10.0.dev0` (pyproject + manifest generator,
cross-checked by G10).
