# V003 Change Rationale (Claude corrective build)

**Input:** `UraiFlow-SaaS_Claude_V002_20260808_2231.zip` + ChatGPT deep review
(2026-08-08 22:38). **Product version:** 0.9.0.dev0.

V003 is the architecture/invariant-hardening release. Every review finding is
dispositioned in `BUILD-REPORT-V003.md`. Summary of what changed and why:

- **Boundary repair (P0-1, ADR-0005):** V002 leaked workforce vocabulary into core.
  `extraction/extractor.py` deleted; replaced by `extraction/rules.py` — a generic,
  configuration-driven engine with no default rules. Workforce rules moved to
  `tests/fixtures/workforce_rules.py`. Guards enforce placement structurally plus a
  domain-token tripwire.
- **Aggregate invariants (P0-2..P0-5, ADR-0006):** commands moved into the Proposal
  aggregate; eligibility and argument validation precede any mutation; terminal
  proposals immutable; unknown ids fail fast; edit ⇒ revalidation lifecycle with
  `Pipeline.revalidate`.
- **Commit/compensation hardening (P0-6..P0-9, ADR-0007):** adapter-boundary
  exception normalisation, COMPENSATING/COMPENSATION_FAILED states, attempt-all
  rollback with collected failures, rollback-capability preflight, runtime
  descriptor validation at registration.
- **Lineage semantics (P1-4, ADR-0008):** payload-reference model canonical;
  unused `parent_event_id` removed.
- **Packaging/gates (P1-1..P1-3, P1-6, ADR-0009):** pyproject packaging, canonical
  `python scripts/run_gates.py`, ruff+mypy, release sequencing, extracted-ZIP smoke.
- **Mutation gate (P1-5):** `scripts/run_mutation_gate.py`. Notable tool finding:
  `mutmut run` reported false survivors due to stale bytecode; the gate runs
  bytecode-safe and independently re-verifies every reported survivor by applying
  it and running the full suite. Gate policy: zero logic survivors; literal/
  equivalent survivors individually dispositioned in `evidence/G07-mutation.json`.

Red-state evidence for the declared V003 contracts: `evidence/V003-red-state.txt`.
