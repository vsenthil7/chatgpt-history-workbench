# Change Rationale — V006

Driver: the independent ChatGPT deep review of
`UraiFlow-SaaS_Claude_V005_20260809_1304.zip`, which confirmed the V005
trust-primitive fixes held and identified six deeper architectural defects
(P0-1, P0-2, P0-3, P1-1, P1-2, P1-3). This iteration is hardening-only: no new
persistence, providers, or features.

## What changed and why

1. **Uncertain external commit (P0-1, ADR-0017).** The commit path could report
   ROLLED_BACK after a real external side effect whose receipt was invalid. We
   introduced an explicit `UncertainCommit`, recorded from trusted request-side
   data, that blocks the clean rollback state and routes to COMPENSATION_FAILED
   for operator reconciliation. Recovery/audit surfaces the uncertain commits.

2. **Pinned adapter registration (P0-2, ADR-0016).** The registry now stores an
   immutable `RegisteredAdapter(adapter, descriptor)` and every operation uses
   the descriptor validated at registration, never a re-read one, so an adapter
   cannot drift its identity to obtain a trusted receipt.

3. **Immutable aggregate identity (P0-3, ADR-0015).** Proposal identity fields
   are canonical and write-once; aggregate ownership can no longer be reassigned
   by mutating a field. Business state remains mutable.

4. **Canonical lineage identity (P1-1, ADR-0014 extension).** LineageEvent
   canonicalises its identity fields at construction and the store admits only
   exact LineageEvent objects, preventing a hostile subject from leaking across
   subjects.

5. **Gate/manifest sequencing (P1-2).** All gate evidence and the run summary
   are written before a single final manifest generation; the two
   self-referential evidence files are excluded from manifest scope. An
   immediate post-run manifest check now stays green.

6. **AST mutation classification (P1-3, ADR-0011 amendment).** The whitespace
   prose heuristic is replaced with an AST source-location classifier; only
   docstrings and raise-messages are prose, everything else (including
   space-containing machine values) is behavioural, and ambiguity fails closed.

## Version
0.11.0.dev0 → 0.12.0.dev0.

## Governance
All six findings are pinned as executed-probe regressions in
`tests/test_v006_review_reproductions.py` and recorded in RTM-V006
(SEC-005..008, GTE-008/009, RCP-005). No prior-version corrections were rolled
back. V006 is handed back for independent review; it is not self-certified.
