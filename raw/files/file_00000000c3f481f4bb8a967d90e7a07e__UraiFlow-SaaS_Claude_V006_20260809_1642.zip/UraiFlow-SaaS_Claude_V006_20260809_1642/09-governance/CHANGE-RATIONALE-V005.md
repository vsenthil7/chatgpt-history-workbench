# Change Rationale — V005

Driver: independent ChatGPT deep review of the actual
`UraiFlow-SaaS_Claude_V004_20260809_1018.zip` (received 09/08/2026, 12:07). The
review accepted the deterministic packaging / coverage / attestation model as
sound and reproduced new release-blocking trust-machinery defects. Direction
accepted verbatim: V005 is a hardening-only corrective iteration; no
persistence, providers, NEEDS_CLARIFICATION or feature work.

## Security changes (deliberate, ADR-governed)
1. **ADR-0014 — canonical exact-type primitives.** New
   `uraiflow.core.primitives` with `canonical_identifier` (rejects non-exact
   `str`, empties) and `require_exact_type` (rejects duck-typed impostors), plus
   `TrustBoundaryViolation`. `TenantContext`, `AdapterDescriptor`,
   `CommitReceipt` and `CandidateRecord` canonicalise identity fields at
   construction; `require_same_tenant`, the registry, `RecoveryService` and the
   lineage store compare only canonical primitives. Fixes the reproduced
   P0-1/P0-2/P0-3 hostile-subclass bypasses at the root, not per-site.
2. Empty-identifier rejection moved to construction time; dead
   post-construction emptiness checks removed; their tests re-pointed to the
   construction boundary (behaviour-preserving for legitimate inputs).

## Gate/evidence changes
3. **G09 (`validate_rtm.py`)** resolves exact `file.py::test_name` pairs and
   reports the true validated row count (fixes review P0-4 and P1-1).
4. **Mutation gate (`run_mutation_gate.py`, ADR-0011 §3 amended)** classifies
   literals default-deny: identifier prefixes / event kinds / keys / record
   types are LOGIC; only prose is accepted (fixes review P1-2). Machine
   identifier prefixes newly pinned by `tests/test_identifier_prefixes.py`.
5. **Attestation (`package_release.py`)** records `PYTHONPATH=src` and the
   extraction-root working directory for every smoke step (fixes review P1-3).

## Version
Product version advanced to `0.11.0.dev0` (pyproject + manifest generator,
cross-checked by G10).
