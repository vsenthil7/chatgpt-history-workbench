# UraiFlow Planning v0.8.0

v0.8.0 adds a human-confirmed structured-record bridge. UraiFlow remains responsible for capture, transcript lineage, extraction and confirmation—not for owning planning, HR, timesheet or capacity domains.
