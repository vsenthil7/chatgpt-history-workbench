# UraiFlow Sprint-to-Code-Test-Evidence Master Index

| Sprint | Context pack | Main module planners | Primary code areas | Mandatory test layers | Release/evidence |
|---|---|---|---|---|---|
| MS-00 | `docs/planning/sprint-context/MS-00.md` | 01, 12, 15 | infrastructure/api core | static/integration/security | baseline evidence |
| MS-01 | `docs/planning/sprint-context/MS-01.md` | 02, 03 | Flutter interview/questionnaire | unit/widget/local DB | Capture 0.1 |
| MS-02 | `docs/planning/sprint-context/MS-02.md` | 02, 05 | Flutter recording/media | unit/emulator/lifecycle | Capture 0.1 |
| MS-03 | `docs/planning/sprint-context/MS-03.md` | 11 | mobile history/recovery | widget/emulator | Capture 0.2 |
| MS-04 | `docs/planning/sprint-context/MS-04.md` | 04, 12 | API/repos/sync | unit/integration/contract | Capture 0.2 |
| MS-05 | `docs/planning/sprint-context/MS-05.md` | 05, 06, 10 | segment/transcription core | unit/contract/integration | Assist 0.1 |
| MS-06 | `docs/planning/sprint-context/MS-06.md` | 06, 07 | provider adapters/admin | contract/Playwright/security | Assist 0.2 |
| MS-07 | `docs/planning/sprint-context/MS-07.md` | 02, 06, 11 | transcript UI/correction | Flutter/E2E/integration | Assist 0.2 |
| MS-08 | `docs/planning/sprint-context/MS-08.md` | 11, 12 | review/aggregate/language | Playwright/lineage | Assist 0.3 |
| MS-09 | `docs/planning/sprint-context/MS-09.md` | 08, 13 | export/connectors | golden/contract/Playwright | Assist 0.3 |
| MS-10 | `docs/planning/sprint-context/MS-10.md` | parent work-platform bridge | gateway/events | contract/integration | Server 0.3 |
| MS-11 | `docs/planning/sprint-context/MS-11.md` | 09, 14, 15 | release/hardening | all layers | RC |
| MS-12 | `docs/planning/sprint-context/MS-12.md` | 03, 07 | question admin | unit/Playwright | Lab |
