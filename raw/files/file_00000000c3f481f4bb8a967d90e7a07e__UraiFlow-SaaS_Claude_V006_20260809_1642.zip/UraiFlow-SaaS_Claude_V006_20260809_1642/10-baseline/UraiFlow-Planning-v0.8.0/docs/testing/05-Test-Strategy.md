# UraiFlow Automated Test Strategy v0.1

## Objective

Codex owns automated verification. Human testing is final usability and look-and-feel acceptance only.

## Test layers

### Static

- Python formatting, lint and type checking
- Flutter analysis
- architecture boundary checks
- dependency and secret scanning
- migration validation

### Unit

- domain policies
- state machines
- provider routing
- retry/fallback
- consent
- completion
- idempotency
- ordering
- transcript versions
- exporters
- mobile controllers

### Integration

Disposable Docker/Testcontainer environment:

- FastAPI + PostgreSQL
- migrations from zero
- repositories
- sync
- file/object storage
- background jobs
- backup/restore

### Provider contract

One common suite runs against:

- Sarvam adapter
- OpenAI adapter
- Gemini adapter
- local Whisper adapter
- fake adapter

Default CI uses fixtures/fakes. Paid live tests are opt-in, tagged and budget-capped.

### Flutter

- unit tests
- widget tests
- golden tests
- SQLite migration tests
- recorder state tests
- offline/recovery tests
- Android emulator integration

### Playwright

Mandatory admin/browser scenarios:

1. login
2. seeded questions visible
3. create/edit/deactivate question
4. provider configuration
5. fake provider health check
6. review synced interview
7. inspect transcript versions
8. export Markdown/JSON/CSV
9. inspect audit timeline
10. provider failure message

### End-to-end system

```text
Create offline interview
→ restart app
→ resume
→ record segment
→ sync
→ fake provider transcribes
→ transcript returns
→ correct transcript
→ export
→ repeat sync without duplicates
```

## Coverage gates

- 80% overall backend line coverage
- 90% domain/application
- 100% branch for consent
- 100% branch for completion
- 100% branch for provider fallback/routing
- 100% branch for sync idempotency
- 90% critical Flutter controllers

## Audio fixtures

Use consented synthetic/developer fixtures:

- English
- Tamil
- Tamil-English code-mixed
- quiet/noisy
- short/long
- interrupted
- two-speaker

Do not reuse event-participant audio without explicit permission.

## Resilience tests

- network unavailable
- backend unavailable
- PostgreSQL restart
- provider timeout
- HTTP 429
- HTTP 5xx
- malformed response
- interrupted upload
- duplicate sync
- app terminated while recording
- server restart while job is active

## Security tests

- admin auth
- secrets absent from APK/web bundle
- path traversal
- file size/type validation
- cross-interview access
- SQL injection
- malicious transcript safely rendered
- audit events on sensitive changes

## Evidence

Codex must save commands, reports, failure screenshots/videos, coverage, APK hashes, build logs, known failures and updated RTM.

A statement saying “tests passed” without artefacts is not evidence.

## Release blockers

- lost audio
- consent bypass
- data leakage
- duplicate sync
- exposed secret
- false transcription success
- failed resume
- failed migration
- mandatory Playwright/Flutter E2E failure
