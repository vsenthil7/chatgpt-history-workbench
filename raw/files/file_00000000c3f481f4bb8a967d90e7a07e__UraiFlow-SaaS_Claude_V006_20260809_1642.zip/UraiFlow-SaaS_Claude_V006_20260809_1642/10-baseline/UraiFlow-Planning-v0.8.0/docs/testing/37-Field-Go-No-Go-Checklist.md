# Field Go/No-Go Checklist

## Device

- Capture and Assist both installed
- versions visible
- microphone permission tested
- storage available
- charger/power bank available
- date/time correct

## Capture

- create interview
- consent gate
- record 2 minutes
- pause/resume
- kill/reopen
- audio playback
- history visible

## Sync/server

- health green
- backup successful
- test interview syncs
- duplicate sync safe
- diagnostics accessible

## Transcription

- approved sample succeeds
- failure fallback/manual mode works
- Tamil visible
- English layer labelled derived

## Operations

- Subha knows which app is stable
- rollback instruction available
- consent introduction available
- support contact/process agreed
- no blocker/critical defect open

A failed blocker item means **NO-GO**.
