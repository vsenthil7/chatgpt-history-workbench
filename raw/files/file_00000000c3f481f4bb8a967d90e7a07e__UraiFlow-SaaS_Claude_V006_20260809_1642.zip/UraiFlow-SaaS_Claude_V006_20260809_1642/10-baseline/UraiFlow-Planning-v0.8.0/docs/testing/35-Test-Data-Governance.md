# Test Data Governance

Each fixture records:

- fixture ID
- origin
- consent/provenance
- language
- duration
- speakers
- noise condition
- expected transcript
- permitted use
- retention
- checksum

## Classes

- synthetic generated audio
- developer-recorded consented audio
- public benchmark audio with licence
- provider response fixtures

Real event audio is excluded from routine automated tests unless separately approved and anonymised.

## Golden transcript review

Expected transcripts must be reviewed by a Tamil-capable human for the core acceptance corpus.
