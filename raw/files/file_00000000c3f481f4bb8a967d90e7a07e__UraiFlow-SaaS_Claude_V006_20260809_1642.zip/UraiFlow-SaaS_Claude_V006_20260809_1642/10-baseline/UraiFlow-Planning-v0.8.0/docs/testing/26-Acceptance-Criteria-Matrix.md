# UraiFlow Acceptance Criteria Matrix

| Area | Positive acceptance | Negative acceptance | Persisted evidence | Automated proof |
|---|---|---|---|---|
| Consent | recording enables after consent | cannot record without consent | consent status/version/time | Flutter + API tests |
| Interview creation | local record created before audio | duplicate tap does not duplicate | local ID/idempotency key | unit/E2E |
| Recording | start/pause/resume/stop works | interruption does not silently lose file | recording metadata/hash | emulator integration |
| Recovery | unfinished session reopens | corrupt file is flagged | recovery event | lifecycle E2E |
| Questions | fixed order displayed | historical text does not change | snapshot/hash | integration |
| Ad-hoc question | inserted after current | does not modify master automatically | local/server ad-hoc row | Flutter/API |
| Segmentation | ordered segments created | gaps/overlaps visible | timing/sequence/hash | media tests |
| Transcription | transcript linked to segment | provider failure not shown as success | job + raw response + version | contract/E2E |
| Correction | corrected text saved separately | raw text never overwritten | parent-child version | integration |
| English layer | traceable derived version | absent capability not fabricated | language/profile lineage | language pipeline tests |
| Sync | retry succeeds | repeated request creates no duplicates | operation/idempotency row | 100% branch integration |
| Review history | all evidence visible later | no runtime-only data | timeline DTO | Playwright/Flutter |
| Export | deterministic versioned output | incomplete output flagged | checksum/version/destination | golden tests |
| Parallel apps | Capture and Assist coexist | storage does not collide | release metadata | install test |
| Security | secrets server-side | APK/web scan finds no key | scan reports | CI security |
