# Structured Record Bridge Acceptance Criteria

- One utterance can propose multiple linked records.
- No record is committed before explicit confirmation in the initial release.
- Duplicate detection is tested.
- Uncertain dates and actor names trigger clarification.
- Partial confirmation commits only selected records with valid links.
- Every committed field retains transcript provenance.
- Failure in a multi-record transaction is visible and recoverable.
