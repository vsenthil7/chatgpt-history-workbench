# Client–Server Compatibility Matrix

| Client | Minimum API | Maximum tested API | Local schema | Status |
|---|---|---|---|---|
| Capture 0.1 | v1 | v1 | 1 | Planned |
| Capture 0.2 | v1 | v1 | 2 | Planned |
| Assist 0.1 | v1 | v1 | 2 | Planned |
| Assist 0.2 | v1 | v1 | 3 | Planned |
| Assist 0.3 | v1 | v1 | 3 | Planned |

## Rules

- server supports current and previous field client during pilot
- unsupported client receives clear upgrade message
- sync payload includes schema and client version
- migration tests cover upgrades from every released local schema
- release is blocked if Capture fallback cannot connect
