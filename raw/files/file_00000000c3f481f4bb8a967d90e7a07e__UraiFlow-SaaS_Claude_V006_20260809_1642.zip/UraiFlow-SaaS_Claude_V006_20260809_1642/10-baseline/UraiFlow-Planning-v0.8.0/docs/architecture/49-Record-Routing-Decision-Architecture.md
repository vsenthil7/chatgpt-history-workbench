# Record Routing Decision Architecture

Transcript segments may map to zero, one or many records.

## Pipeline
1. Segment and classify intent.
2. Extract entities and temporal expressions.
3. Resolve actor, work object and organisation context.
4. Generate candidate record graph.
5. Validate against target schemas and policies.
6. Detect duplicate or conflicting records.
7. Present confirmation plan.
8. Commit atomically through adapters.
9. Store lineage and outcome.

## Candidate record graph
A single utterance may create links among ExecutionSession, TimeEntry, FollowUpWorkObject and AvailabilityDeclaration. The graph is reviewed before commit.
