# UraiFlow Domain Glossary

| Term | Definition |
|---|---|
| Interview | One complete business conversation session with one or more participants. |
| Interview Session | Runtime occurrence of an interview, including timing, state, participants and evidence. |
| Question Set | Versioned template containing ordered sections and questions. |
| Question Snapshot | Immutable copy of the exact question shown or asked during an interview. |
| Section | Logical grouping of questions. |
| Question | Reusable master prompt stored in PostgreSQL. |
| Ad-hoc Question | Question introduced during an interview and attached to that interview. |
| Participant | Person being interviewed. |
| Interviewer | User conducting the interview. |
| Recording | Complete original audio evidence for an interview or recording interval. |
| Audio Segment | Ordered sub-part of a recording used for upload, transcription or retry. |
| Micro-transcription | Transcript created from one audio segment or short utterance. |
| Transcript Aggregate | Ordered combination of micro-transcriptions for an interview or question. |
| Raw Transcript | Direct provider output without human correction. |
| Normalised Transcript | Mechanically cleaned transcript preserving meaning. |
| Corrected Transcript | Human-reviewed transcript. |
| English Standardised Transcript | English translation or normalised English representation derived from native-language transcript. |
| Structured Answer | Field-level answer extracted or confirmed for one question. |
| Observation | Interviewer’s own note that is not attributed to the participant. |
| Summary | Derived overview generated from transcript and answers. |
| Insight | Interpreted finding produced during analysis. |
| Follow-up | Additional question or action resulting from an interview. |
| Transcription Job | Processing request for one audio segment or recording. |
| Provider | External or local AI system that performs a declared capability. |
| Provider Profile | Versioned configuration selecting provider, model and settings. |
| Processing Run | One execution of transcription, translation, summary or extraction. |
| Export | Generated external representation such as JSON, Markdown, CSV or Google Sheet. |
| Review | Human or authorised AI activity validating transcript, answer or summary. |
| Audit Event | Immutable record of a significant change or action. |
| Work Object | AUMNITY Work Platform unit representing actionable, reviewable or trackable work. |
| Release Channel | APK identity/install track such as Stable Capture, Assisted Capture or Experimental. |
| Release Version | Immutable build identifier and semantic version. |

## Non-interchangeable terms

- A **recording** is not a transcript.
- A **micro-transcription** is not the final transcript.
- A **transcript** is not automatically a structured answer.
- A **summary** is not source evidence.
- A **question** is not a question snapshot.
- A **provider response** is not a human-approved result.
