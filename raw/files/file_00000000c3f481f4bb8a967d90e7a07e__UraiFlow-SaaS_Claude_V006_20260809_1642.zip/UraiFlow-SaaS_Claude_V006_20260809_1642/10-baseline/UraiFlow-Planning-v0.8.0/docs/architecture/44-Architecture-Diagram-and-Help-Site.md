# Architecture Diagram and Help Site

## Architecture

Open:

`docs/architecture/index.html`

It contains a numbered system architecture diagram and a matching explanation for every number.

## Help centre

Open:

`docs/help/index.html`

The help site documents interviewer, review/history, administrator and recovery flows. Every screen flow states the expected action and next page.

## Documentation rule

Any user-facing screen added to the product must update:

- help navigation,
- screen flow,
- expected result,
- next action,
- failure/recovery guidance,
- and release version.
