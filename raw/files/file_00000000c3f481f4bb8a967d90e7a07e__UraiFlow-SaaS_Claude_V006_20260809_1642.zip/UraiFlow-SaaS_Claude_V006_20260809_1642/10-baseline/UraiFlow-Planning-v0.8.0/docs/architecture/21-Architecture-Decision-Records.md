# UraiFlow Architecture Decision Records

## ADR-001 — Modular monolith first

**Decision:** One deployable backend with internal modules.  
**Reason:** Speed, consistency and simpler testing.  
**Revisit when:** independent scaling or ownership is proven.

## ADR-002 — PostgreSQL is runtime system of record

**Decision:** Questions, interviews, transcript lineage, audit and exports are stored in PostgreSQL metadata tables.  
**Reason:** integrity, querying, traceability and versioning.

## ADR-003 — Audio outside relational database

**Decision:** Audio goes to file/object storage; metadata and checksum stay in PostgreSQL.  
**Reason:** media efficiency and future storage portability.

## ADR-004 — JSON is seed/import/export only

**Reason:** Git history plus editable runtime database.

## ADR-005 — Provider ports/adapters

**Reason:** providers differ and may change.

## ADR-006 — Offline-first mobile

**Reason:** event connectivity cannot be trusted.

## ADR-007 — Original evidence is immutable

**Reason:** correction and AI processing must never destroy source evidence.

## ADR-008 — Micro-transcription plus aggregate

**Reason:** short audio is faster to process and easier to retry, while complete context remains available.

## ADR-009 — One codebase, multiple release channels

**Reason:** fallback installs without duplicated implementation.

## ADR-010 — Playwright for web, Flutter integration for mobile

**Reason:** Playwright does not replace native mobile testing.

## ADR-011 — Derived artefacts are versioned

**Applies to:** transcript, translation, summary, insight and export.

## ADR-012 — Google Workspace is downstream

**Reason:** collaboration convenience must not replace transactional source of truth.

## ADR-013 — parent work-platform bridge through interface/events

**Reason:** reusable boundary and future service extraction.
