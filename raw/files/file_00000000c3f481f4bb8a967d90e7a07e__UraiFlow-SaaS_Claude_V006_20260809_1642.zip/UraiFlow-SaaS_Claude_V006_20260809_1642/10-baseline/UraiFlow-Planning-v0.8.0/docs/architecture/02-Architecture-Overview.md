# UraiFlow Architecture Overview v0.1

## Architecture decision

Use a **modular monolith** initially with strict ports/adapters. Do not begin with microservices.

## Stack

### Mobile

- Flutter Android
- SQLite via Drift or equivalent
- local audio storage
- background sync queue

### Admin

Flutter web is acceptable for speed. A small React/TypeScript admin is allowed only after recording the decision; business logic remains server-side.

### Backend

- Python 3.12
- FastAPI
- SQLAlchemy 2.x
- Alembic
- Pydantic
- PostgreSQL
- asynchronous job abstraction

### Infrastructure

- Docker
- Docker Compose
- reverse proxy
- PostgreSQL volume
- backend
- optional worker
- file/object-storage volume
- local Whisper-compatible service

## Context

```text
Flutter Android
 ├─ SQLite
 ├─ Local audio
 └─ Sync API
      ↓
FastAPI modular monolith
 ├─ Questionnaire
 ├─ Interview
 ├─ Audio
 ├─ Transcription orchestration
 ├─ Provider adapters
 ├─ Review
 ├─ Export
 ├─ Administration
 └─ Audit
      ├─ PostgreSQL
      ├─ File/object storage
      └─ Sarvam/OpenAI/Gemini/Local Whisper
```

## Domain modules

1. identity/admin
2. questionnaire
3. interview
4. conversation/audio
5. transcription
6. translation/normalisation
7. transcript review
8. sync
9. export
10. audit/observability

## Core entities

`User`, `Organisation`, `QuestionSet`, `QuestionSection`, `Question`, `QuestionVersion`, `Interview`, `Participant`, `InterviewQuestionSnapshot`, `AdHocQuestion`, `AudioRecording`, `AudioSegment`, `TranscriptionJob`, `TranscriptVersion`, `ProviderConfiguration`, `SyncOperation`, `ExportJob`, `AuditEvent`.

## Provider interface

```python
class TranscriptionProvider(Protocol):
    provider_code: str

    async def health_check(self) -> ProviderHealth: ...

    async def transcribe(
        self,
        audio: AudioInput,
        options: TranscriptionOptions,
    ) -> TranscriptionResult: ...
```

Domain/application classes must not import provider SDK types.

## Audio segmentation

- Keep complete original audio.
- Segment by question boundary and/or configurable duration.
- Preserve order, timestamp and hash.
- Allow one segment to be reprocessed.
- Do not hardcode one duration; initial target may be 30–90 seconds after testing.

## Offline flow

```text
Create locally
→ snapshot questions
→ record locally
→ save segment metadata
→ continue without network
→ explicit sync
→ idempotency check
→ upload missing items
→ backend processing
→ pull transcript/summary
```

## Security

Provider calls run through backend. Credentials never go into APK or browser static bundle.

## Questions

```text
Git JSON seed
→ validation/import
→ PostgreSQL
→ API
→ mobile/admin
```

Historical interviews retain immutable question snapshots.

## Future extraction candidates

- transcription gateway,
- media worker,
- work-object engine,
- analytics,
- provider billing,
- and dialler integration.

Extract only when evidence requires it.
