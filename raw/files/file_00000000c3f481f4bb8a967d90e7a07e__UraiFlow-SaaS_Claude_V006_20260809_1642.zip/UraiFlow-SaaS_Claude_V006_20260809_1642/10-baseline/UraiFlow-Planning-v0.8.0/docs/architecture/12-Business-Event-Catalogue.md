# UraiFlow Business Event Catalogue

## Interview lifecycle events

- InterviewCreated
- InterviewProfileUpdated
- RecordingConsentGranted
- RecordingConsentDeclined
- QuestionSetSelected
- QuestionSnapshotsCreated
- InterviewStarted
- InterviewPaused
- InterviewResumed
- InterviewCompleted
- InterviewReopened
- InterviewArchived

## Question events

- QuestionDisplayed
- QuestionAnswered
- QuestionSkipped
- QuestionMarkedNotApplicable
- AdHocQuestionAdded
- AdHocQuestionPromotedForReview
- AnswerCorrected

## Audio events

- RecordingStarted
- RecordingPaused
- RecordingResumed
- RecordingStopped
- RecordingPersistedLocally
- AudioSegmentCreated
- AudioSegmentHashed
- AudioSegmentQueuedForSync
- AudioSegmentUploaded
- AudioSegmentUploadFailed
- RecordingRecoveredAfterRestart

## Transcription events

- TranscriptionRequested
- ProviderSelected
- TranscriptionStarted
- PartialTranscriptReceived
- MicroTranscriptCompleted
- TranscriptionRetryScheduled
- ProviderFallbackActivated
- TranscriptionFailed
- TranscriptAggregateBuilt
- TranscriptCorrected
- EnglishTranscriptGenerated

## Review and analysis events

- InterviewReviewOpened
- TranscriptReviewed
- StructuredAnswerConfirmed
- SummaryGenerated
- SummaryApproved
- InsightCreated
- FollowUpCreated

## Export events

- ExportRequested
- MarkdownExportGenerated
- JsonExportGenerated
- CsvExportGenerated
- GoogleSheetExportQueued
- GoogleSheetExportCompleted
- ExportFailed

## Administration events

- QuestionCreated
- QuestionUpdated
- QuestionDeactivated
- QuestionSetVersionPublished
- ProviderEnabled
- ProviderDisabled
- ProviderProfileChanged
- ProviderHealthCheckCompleted

## parent work-platform bridge events

- InterviewWorkObjectCreated
- ReviewWorkObjectCreated
- FollowUpWorkObjectCreated
- ExportWorkObjectCreated
- WorkObjectCompleted

## Event envelope

Every event should contain:

```text
event_id
event_type
occurred_at_utc
organisation_id
interview_id
question_id_or_snapshot_id
recording_id
segment_id
transcription_job_id
actor_id
correlation_id
causation_id
release_version
metadata
```
