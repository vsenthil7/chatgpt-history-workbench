# UraiFlow Sequence Flows

## 1. Normal interview with segmented transcription

```text
Interviewer → Mobile: Create interview
Mobile → SQLite: Save interview
Mobile → Mobile: Capture consent
Interviewer → Mobile: Start recording
Mobile → Local storage: Persist complete audio stream
Mobile → Segmenter: Create micro segment
Segmenter → SQLite: Save segment metadata
Mobile → Backend: Sync segment
Backend → Provider Router: Select provider
Provider Router → Provider: Transcribe
Provider → Backend: Raw micro-transcript
Backend → PostgreSQL: Save job, provider response and transcript version
Backend → Mobile: Return micro-transcript
Mobile → Interviewer: Display provisional transcript
Interviewer → Mobile: Correct/accept
Mobile → Backend: Save corrected version
```

## 2. Offline interview

```text
Mobile creates interview locally
Mobile records and segments locally
Sync attempts fail
Mobile continues questions without blocking
Interview is completed locally
Later network returns
Sync queue uploads interview, snapshots, answers and media
Backend idempotency keys prevent duplicates
Processing begins
Results return to mobile
```

## 3. Provider failure

```text
Backend calls primary provider
Primary returns timeout/429/5xx
Retry policy evaluates
If retry allowed → retry
If fallback allowed → select next capable provider
If all fail → mark failed honestly
Mobile shows transcription unavailable
Audio and manual workflow remain usable
```

## 4. End-of-interview review

```text
User opens interview history
System shows:
- profile
- participants
- question timeline
- original recordings
- audio segments
- raw micro-transcripts
- aggregated transcript
- corrected transcript
- English transcript
- notes
- answers
- summary
- provider metadata
- follow-ups
- export status
```

## 5. Google Sheets export

```text
Reviewer approves interview
Export requested
Backend creates canonical export DTO
Google Sheets connector creates/updates workbook
One interview summary row added
Question-answer detail rows added
Transcript and audio links written
Export version recorded
Audit event emitted
```

## 6. DWOS work-object conversion

```text
Interview completed
Analysis identifies follow-up
UraiFlow emits FollowUpCreated
parent work-platform bridge creates Work Object
Work Object links back to interview evidence
Review and completion happen in DWOS
```
