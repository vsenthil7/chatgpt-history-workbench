# UraiFlow Relational Data Model v0.2

## Core administration

### organisations
- id
- name
- status
- created_at

### users
- id
- organisation_id
- display_name
- email
- role
- status

## Questionnaire

### question_sets
- id
- organisation_id
- code
- name
- semantic_version
- status
- published_at

### question_sections
- id
- question_set_id
- code
- name
- display_order
- status

### questions
- id
- section_id
- code
- current_version_id
- display_order
- status

### question_versions
- id
- question_id
- version_number
- question_text
- helper_text
- question_type
- required
- allow_audio
- allow_follow_up
- created_by
- created_at

## Interview

### interviews
- id
- organisation_id
- question_set_id
- interviewer_id
- status
- company_name
- participant_name
- participant_role
- industry
- location
- contact_details_json
- consent_status
- started_at
- completed_at
- created_at
- updated_at

### interview_question_snapshots
- id
- interview_id
- source_question_id
- source_question_version_id
- section_name
- question_text
- display_order
- required
- snapshot_hash

### interview_answers
- id
- interview_id
- question_snapshot_id
- answer_status
- structured_answer_json
- interviewer_note
- participant_declined
- confirmed_at

### ad_hoc_questions
- id
- interview_id
- parent_snapshot_id
- question_text
- display_order
- reusable_candidate
- review_status

## Audio

### recordings
- id
- interview_id
- storage_uri
- local_reference
- sha256
- duration_ms
- mime_type
- state
- started_at
- stopped_at

### audio_segments
- id
- recording_id
- question_snapshot_id
- sequence_number
- start_ms
- end_ms
- storage_uri
- sha256
- sync_state
- transcription_state

## Transcription

### provider_profiles
- id
- organisation_id
- provider_code
- profile_version
- model_name
- enabled
- priority
- fallback_group
- capability_json
- settings_json
- credential_reference
- status

### transcription_jobs
- id
- interview_id
- audio_segment_id
- provider_profile_id
- state
- requested_language
- requested_capability
- attempt_number
- correlation_id
- started_at
- completed_at
- latency_ms
- estimated_cost
- error_code
- error_message

### provider_raw_responses
- id
- transcription_job_id
- encrypted_or_redacted_payload
- response_hash
- created_at

### transcript_versions
- id
- interview_id
- audio_segment_id
- question_snapshot_id
- parent_version_id
- transcript_type
- language_code
- text
- provider_profile_id
- processing_run_id
- approved_by
- approved_at
- created_at

### transcript_aggregates
- id
- interview_id
- aggregate_type
- language_code
- version_number
- text
- source_version_ids_json
- created_at

## Review and analysis

### interview_summaries
- id
- interview_id
- version_number
- source_transcript_version
- prompt_version
- model_profile
- summary_text
- status

### insights
- id
- interview_id
- category
- evidence_reference
- insight_text
- confidence
- status

### follow_ups
- id
- interview_id
- source_question_snapshot_id
- title
- description
- status
- dwos_work_object_id

## Export and audit

### exports
- id
- interview_id
- export_type
- export_version
- state
- destination_uri
- generated_at
- checksum

### sync_operations
- id
- client_operation_id
- interview_id
- entity_type
- entity_id
- operation_type
- state
- payload_hash

### audit_events
- id
- event_type
- actor_id
- interview_id
- correlation_id
- causation_id
- payload_json
- occurred_at

## Key integrity rules

- Question snapshots are immutable.
- Raw transcript versions are never overwritten.
- Corrected transcript is a child version.
- Every micro-transcript links to its audio segment.
- Aggregated transcript stores exact source version IDs.
- Export records checksum and source version.
- Sync uses client-generated idempotency keys.
- Audio is stored outside PostgreSQL; metadata and hashes remain inside.
