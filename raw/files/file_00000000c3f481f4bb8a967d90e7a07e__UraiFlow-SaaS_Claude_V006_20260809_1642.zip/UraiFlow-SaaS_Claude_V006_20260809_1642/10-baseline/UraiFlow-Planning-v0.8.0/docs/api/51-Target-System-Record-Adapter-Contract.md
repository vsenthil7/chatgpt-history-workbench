# Target-System Record Adapter Contract

Each adapter declares accepted record types, schema version, required fields, idempotency key, validation endpoint, preview endpoint, commit endpoint and rollback/compensation capability.

UraiFlow must not hard-code IPBS spreadsheet columns. The IPBS pilot implements an adapter mapping proposals to workbook tables.
