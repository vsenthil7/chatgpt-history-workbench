# UraiFlow API Contract Catalogue

## Versioning

Base path:

```text
/api/v1
```

Breaking changes require `/api/v2` or an explicit compatibility plan.

## Common headers

- `Authorization`
- `X-Correlation-ID`
- `Idempotency-Key`
- `X-Client-Version`
- `X-Release-Channel`

## Common error

```json
{
  "error_code": "STRING",
  "message": "Safe user message",
  "correlation_id": "uuid",
  "details": {}
}
```

## Core endpoints

### Interviews

- `POST /interviews`
- `GET /interviews`
- `GET /interviews/{id}`
- `PATCH /interviews/{id}`
- `POST /interviews/{id}/complete`
- `POST /interviews/{id}/reopen`

### Question snapshots and answers

- `GET /interviews/{id}/questions`
- `PATCH /interviews/{id}/answers/{snapshot_id}`
- `POST /interviews/{id}/ad-hoc-questions`

### Recordings/media

- `POST /interviews/{id}/recordings`
- `POST /recordings/{id}/segments`
- `PUT /segments/{id}/content`
- `GET /segments/{id}/content`
- `POST /segments/{id}/retry`

### Transcription

- `POST /segments/{id}/transcriptions`
- `GET /transcription-jobs/{id}`
- `GET /interviews/{id}/transcripts`
- `POST /transcripts/{id}/corrections`
- `POST /interviews/{id}/aggregate-transcript`

### Administration

- `GET /question-sets`
- `POST /question-sets`
- `PATCH /questions/{id}`
- `GET /provider-profiles`
- `POST /provider-profiles`
- `POST /provider-profiles/{id}/health-check`

### Export

- `POST /interviews/{id}/exports`
- `GET /exports/{id}`
- `POST /exports/{id}/retry`

## Idempotency

Create/upload/export endpoints must support idempotency keys. The same key and same payload returns the same result. Same key with different payload returns conflict.

## Contract artefacts

Implementation must generate and commit:

- OpenAPI JSON,
- example payloads,
- error catalogue,
- and consumer contract tests.
