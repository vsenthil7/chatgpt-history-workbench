# Module Plan — Google Workspace Export

Create canonical export DTO, Markdown/JSON/CSV generators, Google Sheets connector, Drive folder strategy, retry/idempotency, checksums and audit. Default tests use fake connector; sandbox is opt-in.
