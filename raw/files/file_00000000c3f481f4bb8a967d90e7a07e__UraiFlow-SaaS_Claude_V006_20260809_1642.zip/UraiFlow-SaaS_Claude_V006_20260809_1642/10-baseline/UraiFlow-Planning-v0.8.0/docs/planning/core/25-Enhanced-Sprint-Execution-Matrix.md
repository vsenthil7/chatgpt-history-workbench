# UraiFlow Enhanced Sprint Execution Matrix

| Sprint | Entry criteria | Build scope | Explicitly do not build | Automated exit criteria | Release |
|---|---|---|---|---|---|
| MS-00 | Docs v0.3 approved | Repo, Docker, CI, migrations, evidence tree | UI features | clean clone, Compose, migration, lint/type/secret tests | Server baseline |
| MS-01 | MS-00 green | profile, consent, question snapshots, local DB | transcription, sync | Flutter units/widgets, consent 100% branches, restart persistence | Capture 0.1 |
| MS-02 | MS-01 green | recording, pause/resume, local evidence, recovery | provider calls | emulator lifecycle tests, interrupted recording recovery | Capture 0.1 |
| MS-03 | MS-02 green | interview history, reopen/resume, local detail | server analytics | history/reopen Flutter E2E | Capture 0.2 |
| MS-04 | backend baseline | APIs, PostgreSQL, upload, idempotent sync | Google export | integration tests, duplicate sync 100% branches | Capture 0.2 |
| MS-05 | audio sync green | segmentation, fake/local transcription adapter | paid providers | contract tests, aggregate lineage, visible failure | Assist 0.1 |
| MS-06 | provider contract stable | Sarvam/OpenAI/Gemini adapters, admin configuration | auto-switch without policy | provider fixture suite, secret scans, health checks | Assist 0.2 |
| MS-07 | transcription stable | provisional UI, correction, native aggregate | summary analytics | Flutter E2E, raw/corrected preservation | Assist 0.2 |
| MS-08 | transcript lifecycle green | English layer, review page, timeline | AUMNITY Work Platform workflow | review Playwright and lineage tests | Assist 0.3 |
| MS-09 | review approved | canonical exports, Google connector | dashboards | golden exports, fake connector, idempotency | Assist 0.3 |
| MS-10 | bridge contract approved | follow-up Work Object gateway | full DWOS engine | fake gateway contract and audit | Server 0.3 |
| MS-11 | all prior green | hardening, security, performance, compatibility | new features | all gates and field checklist | RC |
| MS-12 | field feedback | question admin/reordering/spoken drafts | dialler | regression suite | Lab 0.4 |
| MS-13 | separately approved | dialler adapter prototype | production telephony | dedicated legal/provider plan | Future |
