# Module Plan — Backend API and Sync

## Components
`InterviewService`, `InterviewRepository`, `InterviewCompletionPolicy`, `SyncService`, `IdempotencyService`, routers and schemas.

## APIs
Interviews, snapshots, answers, media, sync, transcripts, completion and exports.

## Tests
Validation, PostgreSQL, duplicate requests, conflicts, completion and isolation.
