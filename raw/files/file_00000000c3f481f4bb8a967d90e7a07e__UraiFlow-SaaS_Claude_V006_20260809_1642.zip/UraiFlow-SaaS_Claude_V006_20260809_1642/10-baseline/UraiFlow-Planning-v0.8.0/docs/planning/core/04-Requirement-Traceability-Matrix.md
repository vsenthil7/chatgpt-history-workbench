# UraiFlow Requirement Traceability Matrix v0.1

## Traceability chain

```text
Requirement
→ Design component
→ Planned class/module
→ Unit test
→ Integration/contract test
→ Playwright/Flutter E2E
→ Evidence
→ Release gate
```

No requirement is complete until evidence is linked.

| Requirement | Design | Planned code | Unit test | Integration/contract | E2E | Evidence | Status |
|---|---|---|---|---|---|---|---|
| FR-001 | Interview module | `InterviewService` | creation rules | API + DB | create interview | Pending | NOT STARTED |
| FR-002 | Interview profile | `InterviewProfile` | validation | round trip | enter/reopen | Pending | NOT STARTED |
| FR-003/098 | Consent policy | `ConsentPolicy` | 100% branches | recording rejected | disabled until consent | Pending | NOT STARTED |
| FR-004 | Questionnaire | `QuestionSetService` | active set | seeded retrieval | select set | Pending | NOT STARTED |
| FR-005/070 | Offline store | `LocalInterviewRepository` | CRUD | local migration | close/reopen | Pending | NOT STARTED |
| FR-010–012 | Flow state machine | `InterviewFlowController` | transitions | snapshot API | next/previous/progress | Pending | NOT STARTED |
| FR-013 | Answer state | `AnswerStatus` | state rules | persistence | skip/N/A | Pending | NOT STARTED |
| FR-014–015 | Follow-up | `AdHocQuestionService` | insertion/status | API + DB | add follow-up | Pending | NOT STARTED |
| FR-016 | Immutable snapshot | `QuestionSnapshotFactory` | immutability | master edit test | old wording retained | Pending | NOT STARTED |
| FR-020 | Recorder | `AudioRecorderController` | state machine | file fixture | start/pause/resume/stop | Pending | NOT STARTED |
| FR-021 | Evidence storage | `AudioEvidenceService` | path/hash | upload/download | replay after restart | Pending | NOT STARTED |
| FR-022 | Segmentation | `AudioSegmenter` | boundaries | media fixture | ordered segments | Pending | NOT STARTED |
| FR-023 | Association | `AudioSegment` | relation | DB FK/idempotency | timeline | Pending | NOT STARTED |
| FR-024 | Recovery | `RecoveryService` | crash states | restart fixture | kill/reopen | Pending | NOT STARTED |
| FR-025 | Manual resilience | `TranscriptionOptionalPolicy` | provider-down | outage | complete offline | Pending | NOT STARTED |
| FR-030 | Provider routing | `ProviderRouter` | routing matrix | fake providers | selected provider | Pending | NOT STARTED |
| FR-031 | Sarvam adapter | `SarvamTranscriptionAdapter` | mocked schema | contract fixture/live opt-in | provider label | Pending | NOT STARTED |
| FR-032 | OpenAI adapter | `OpenAITranscriptionAdapter` | mocked schema | contract fixture/live opt-in | provider label | Pending | NOT STARTED |
| FR-033 | Gemini adapter | `GeminiAudioAdapter` | mocked schema | contract fixture/live opt-in | provider label | Pending | NOT STARTED |
| FR-034 | Local adapter | `WhisperServerAdapter` | mocked schema | local container | provider label | Pending | NOT STARTED |
| FR-035 | Extension | `ProviderRegistry` | plugin registration | common contract suite | provider list | Pending | NOT STARTED |
| FR-036 | Transcript view | `TranscriptViewModel` | UI states | job completion | transcript appears | Pending | NOT STARTED |
| FR-037–038 | Transcript versions | `TranscriptService` | version rules | DB audit | edit retains raw | Pending | NOT STARTED |
| FR-039–040 | Language layers | `LanguagePipeline` | branch tests | language fixtures | Tamil/English tabs | Pending | NOT STARTED |
| FR-041 | Telemetry | `ProviderCallRecord` | serialisation | DB persistence | diagnostics | Pending | NOT STARTED |
| FR-042 | Retry | `RetryPolicy` | all branches | forced 429/503 | retry status | Pending | NOT STARTED |
| FR-043 | Fallback | `FallbackPolicy` | 100% branches | A fails/B succeeds | path shown | Pending | NOT STARTED |
| FR-044 | Honest failure | `TranscriptionJobState` | failure states | all fail | visible failure | Pending | NOT STARTED |
| FR-050–051 | DB/seed | models/importer | schema validation | clean DB import | seeded list | Pending | NOT STARTED |
| FR-052–054 | Admin CRUD/audit | services/endpoints/UI | service tests | API + DB audit | edit/deactivate | Pending | NOT STARTED |
| FR-055 | Ordering | `QuestionOrderService` | duplicate/order | persistence | fixed ordered flow | Pending | NOT STARTED |
| FR-056 | Spoken draft | `QuestionDraftService` | draft parsing | transcript fixture | feature flagged | Pending | PLANNED |
| FR-060–066 | Provider admin | config/health services | validation | health/secret tests | configure/test | Pending | NOT STARTED |
| FR-071 | PostgreSQL | repositories | repository units | Testcontainers | persistence | Pending | NOT STARTED |
| FR-072–073 | Sync/idempotency | `SyncService`, `IdempotencyService` | 100% critical branches | repeat upload | repeat sync | Pending | NOT STARTED |
| FR-074–075 | Metadata/object split | storage ports | storage rules | volume tests | replay | Pending | NOT STARTED |
| FR-076 | Google connector | `ExportConnector` | registration | fake connector | deferred | Pending | PLANNED |
| FR-077–078 | Export | MD/JSON/CSV exporters | golden files | API download | export UI | Pending | NOT STARTED |
| FR-080–081 | Review timeline | `InterviewTimelineService` | ordering/view model | composed retrieval | timeline | Pending | NOT STARTED |
| FR-082 | Completion | `InterviewCompletionPolicy` | 100% branches | reject/accept | completion feedback | Pending | NOT STARTED |
| FR-083 | Correction | `TranscriptCorrectionService` | versioning | audit persistence | edit flow | Pending | NOT STARTED |
| FR-084 | Audit | `AuditService` | event rules | append-only | audit page | Pending | NOT STARTED |
| FR-085 | Summary | `SummaryService` | derived-label rules | fake provider | labelled output | Pending | NOT STARTED |
| FR-090–097 | Security/ops | auth/health/backup | security units | container/restore | admin auth | Pending | NOT STARTED |
| NFR-001–018 | Cross-cutting | all modules | coverage/static | resilience/performance | device/browser matrix | Pending | NOT STARTED |

## Evidence names

- `TEST-UNIT-<module>-<timestamp>.xml`
- `TEST-INTEGRATION-<module>-<timestamp>.xml`
- `TEST-PLAYWRIGHT-<suite>-<timestamp>/`
- `TEST-FLUTTER-<suite>-<timestamp>/`
- `COVERAGE-BACKEND-<timestamp>/`
- `COVERAGE-FLUTTER-<timestamp>.info`
- `BUILD-APK-A-<commit>.sha256`
- `BUILD-APK-B-<commit>.sha256`

Any added requirement must enter this matrix before coding. Removed work remains visible as `DEFERRED` or `REJECTED` with reason.


## v0.2 additional traceability

| Requirement/Control | Design artefact | Planned implementation | Automated verification | Evidence | Status |
|---|---|---|---|---|---|
| DOM-001 Controlled terminology | `11-Domain-Glossary.md` | shared schema/domain names | architecture naming test/review | Pending | NOT STARTED |
| EVT-001 Domain events | `12-Business-Event-Catalogue.md` | event publisher/audit mapper | unit event assertions + integration audit | Pending | NOT STARTED |
| STM-001 Interview state machine | `13-State-Machine-Specification.md` | `InterviewStateMachine` | 100% transition branches | Pending | NOT STARTED |
| STM-002 Recording state machine | State spec | `RecordingStateMachine` | transition/property tests | Pending | NOT STARTED |
| STM-003 Transcription job state | State spec | `TranscriptionJobStateMachine` | retry/fallback/all-fail tests | Pending | NOT STARTED |
| SEQ-001 Offline sequence | `14-Sequence-Flows.md` | mobile sync orchestration | emulator offline/reconnect E2E | Pending | NOT STARTED |
| DATA-001 Relational model | `15-Relational-Data-Model.md` | SQLAlchemy/Alembic | clean migration + constraints | Pending | NOT STARTED |
| REV-001 Interview history | `16-Interview-Review-and-History-Module.md` | list/detail/timeline services and UI | Flutter + Playwright review flows | Pending | NOT STARTED |
| TRN-001 Micro-transcript lineage | `17-Transcript-Lifecycle-and-Microprocessing.md` | segment/version/aggregate services | reprocess-one-segment integration | Pending | NOT STARTED |
| EXP-001 Canonical export DTO | `18-Export-and-Google-Workspace-Plan.md` | export assembler | golden DTO/export tests | Pending | NOT STARTED |
| EXP-002 Google Sheets export | Export plan | Google connector | fake connector + opt-in sandbox | Pending | NOT STARTED |
| DWO-001 Work Object bridge | `19-DWOS-Work-Object-Bridge.md` | `WorkObjectGateway` | fake gateway contract | Pending | NOT STARTED |
| REL-001 Parallel install | `20-Release-Versioning-and-Parallel-Install-Plan.md` | Flutter flavours/app IDs | install both APKs on emulator/device | Pending | NOT STARTED |
| ADR-001 Decisions retained | `21-Architecture-Decision-Records.md` | docs + boundary tests | ADR presence/check | Pending | NOT STARTED |
| OBS-001 Trace correlation | `22-Observability-and-Diagnostics.md` | middleware/telemetry | correlation propagation integration | Pending | NOT STARTED |
| VER-001 Planning version history | `10-Version-History-and-Change-Rationale.md` | Git tags/releases | package manifest test | Pending | NOT STARTED |


## v0.3 control traceability

| Control | Document | Required implementation/evidence | Status |
|---|---|---|---|
| CTRL-001 Session/Git handoff | 24, 33 | session folders, commits, handoff files | NOT STARTED |
| CTRL-002 Sprint entry/exit | 25 | per-sprint checklists/evidence | NOT STARTED |
| ACC-001 Acceptance matrix | 26 | linked test IDs and results | NOT STARTED |
| API-001 Versioned contracts | 27 | OpenAPI, examples, contract tests | NOT STARTED |
| AND-001 Android lifecycle | 28 | device/emulator lifecycle evidence | NOT STARTED |
| PRIV-001 Consent/retention | 29 | role, deletion, retention tests | NOT STARTED |
| INC-001 Defect/rollback | 30 | defect template, rollback drill | NOT STARTED |
| ENV-001 Environment separation | 31 | environment configs and labels | NOT STARTED |
| AI-001 Prompt/model lineage | 32 | registry and processing-run lineage | NOT STARTED |
| BENCH-001 Provider benchmark | 34 | benchmark report | NOT STARTED |
| DATA-TEST-001 Fixture governance | 35 | fixture manifest | NOT STARTED |
| COMP-001 Client/API compatibility | 36 | compatibility test matrix | NOT STARTED |
| FIELD-001 Go/no-go | 37 | signed checklist/evidence | NOT STARTED |
