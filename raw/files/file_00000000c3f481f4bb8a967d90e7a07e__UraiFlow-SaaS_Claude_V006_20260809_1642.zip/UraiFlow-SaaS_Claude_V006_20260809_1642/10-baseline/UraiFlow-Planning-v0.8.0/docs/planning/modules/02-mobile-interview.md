# Module Plan — Flutter Mobile Interview

## Components
`InterviewListPage`, `InterviewSetupPage`, `ConsentPage`, `QuestionFlowPage`, `RecordingControls`, `TranscriptPanel`, `InterviewSummaryPage`, `InterviewFlowController`, `LocalInterviewRepository`, `RecoveryService`, `SyncQueue`.

## Builds
`reliable` flavour → APK-A.  
`speech_assisted` flavour → APK-B.

## Tests
State, widgets, golden screens, offline persistence, restart, permission denial, interrupted recording and emulator E2E.
