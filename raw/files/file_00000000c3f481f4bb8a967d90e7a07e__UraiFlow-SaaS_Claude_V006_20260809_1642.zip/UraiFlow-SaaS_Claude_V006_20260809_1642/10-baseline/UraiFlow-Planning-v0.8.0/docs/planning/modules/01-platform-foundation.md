# Module Plan — Platform Foundation

## Components
`Settings`, `DatabaseSessionFactory`, `HealthService`, `CorrelationIdMiddleware`, `AuditLogger`, migrations, Docker and CI.

## Deliverables
Repository skeleton, Compose, PostgreSQL, FastAPI health, config validation, lint/type/test commands and clean migration test.

## Tests
Container startup, migration from zero, readiness, invalid configuration and secret scan.
