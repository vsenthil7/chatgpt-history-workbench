# Module Plan — Questionnaire

## Components
`QuestionSet`, `QuestionSection`, `Question`, `QuestionVersion`, `QuestionOrderService`, `QuestionSeedImporter`, `QuestionSnapshotFactory`, `AdHocQuestionService`.

## Rules
PostgreSQL runtime, JSON seed, immutable interview snapshots, version/status history and future ordering support.

## Tests
Seed validation, order, duplicate codes, versions, historical snapshots and ad-hoc insertion.
