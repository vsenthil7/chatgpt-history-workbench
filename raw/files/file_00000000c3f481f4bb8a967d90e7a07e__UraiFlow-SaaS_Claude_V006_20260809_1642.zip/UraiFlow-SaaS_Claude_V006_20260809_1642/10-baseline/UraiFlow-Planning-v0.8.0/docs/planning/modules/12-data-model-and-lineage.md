# Module Plan — Data Model and Lineage

Implement v0.2 relational model, constraints, migrations, transcript parent-child lineage, aggregate source references, provider profile versions, export versions and immutable snapshots. Test from empty database and migration upgrade path.
