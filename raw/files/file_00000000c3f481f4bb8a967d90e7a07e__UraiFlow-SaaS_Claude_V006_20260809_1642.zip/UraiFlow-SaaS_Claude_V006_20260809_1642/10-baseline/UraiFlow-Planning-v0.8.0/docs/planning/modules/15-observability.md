# Module Plan — Observability

Implement structured logging, correlation and causation IDs, provider/job/export diagnostics, health endpoints, pending/failed counters and user-visible interview diagnostics. Test propagation and redaction.
