# Module Plan — Transcription

## Components
`TranscriptionProvider`, `ProviderRegistry`, `ProviderRouter`, `TranscriptionOrchestrator`, `RetryPolicy`, `FallbackPolicy`, Sarvam/OpenAI/Gemini/Whisper adapters, `LanguagePipeline`, `TranscriptService`.

## Tests
Shared adapter contract, capability routing, retry/fallback, total failure, transcript version preservation, Tamil Unicode and English layer.
