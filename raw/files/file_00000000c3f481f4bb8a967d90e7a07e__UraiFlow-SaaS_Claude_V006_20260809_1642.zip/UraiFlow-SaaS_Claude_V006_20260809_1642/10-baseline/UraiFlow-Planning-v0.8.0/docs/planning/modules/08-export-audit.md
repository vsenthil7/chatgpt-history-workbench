# Module Plan — Export, Review and Audit

## Components
`InterviewTimelineService`, `TranscriptCorrectionService`, `MarkdownExporter`, `JsonExporter`, `CsvExporter`, `AuditService`, `BackupService`, `RestoreService`.

## Tests
Golden files, Unicode, transcript layers, append-only audit, backup/restore and download authorisation.
