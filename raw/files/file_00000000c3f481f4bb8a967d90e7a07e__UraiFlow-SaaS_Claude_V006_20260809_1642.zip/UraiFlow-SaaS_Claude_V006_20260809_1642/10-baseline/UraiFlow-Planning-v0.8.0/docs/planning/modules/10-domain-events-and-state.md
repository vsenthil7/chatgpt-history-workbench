# Module Plan — Domain Events and State Machines

Implement explicit interview, recording, segment, transcription, transcript, export and release state machines. Emit domain events only after valid transitions. Persist audit mapping. Tests must cover every valid and invalid transition.
