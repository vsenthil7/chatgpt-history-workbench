# Module Plan — Administration Web

## Pages
Login, question sets, question editor, providers, provider health, interview review, audit and exports.

## Security
Server-side credentials, masked references, authorisation and safe transcript rendering.

## Playwright
Every page and critical action uses deterministic fake providers.
