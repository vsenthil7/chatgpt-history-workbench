# Module Plan — Release

## Outputs
APK-A, APK-B, SHA-256 hashes, images, Compose, Ubuntu runbook, environment template, backup/restore, smoke test and evidence index.

## Gate
All Definition of Done conditions pass before human UAT.
