# Module Plan — Release Channels

Configure Capture, Assist and Lab Flutter flavours with unique package IDs, labels, storage and feature flags. Produce semantic versions, hashes and release notes. Test parallel installation and rollback.
