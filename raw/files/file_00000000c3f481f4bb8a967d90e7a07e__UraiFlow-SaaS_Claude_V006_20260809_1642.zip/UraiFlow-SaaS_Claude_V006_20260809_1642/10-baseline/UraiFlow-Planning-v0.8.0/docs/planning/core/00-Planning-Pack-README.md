# DWOS UraiFlow — Planning Pack v0.4

**Working module name:** UraiFlow  
**Parent platform:** Distributed Work Operating System (DWOS)  
**Status:** Documentation baseline before Codex implementation  
**Name status:** Provisional internal name; commercial naming and trademark clearance are pending.

## Product

UraiFlow is a reusable conversation-capture, transcription and structured-interview module inside AUMNITY Work Platform.

First use case: Subha conducts guided SME market-discovery interviews using an Android APK.

Future reuse:

- client discovery,
- recruitment interviews,
- customer support,
- outbound sales,
- employee reviews,
- client onboarding,
- quality audits,
- and dialler-connected conversations.

```text
Question
→ Conversation
→ Audio
→ Segments
→ Transcript
→ Translation/normalisation
→ Human correction
→ Structured answer
→ Summary
→ Follow-up work
```

## Delivery principle

Codex must create, test and package the product. The user performs only final human acceptance for look, feel and visible glitches.

## Documents

1. `01-Product-Charter.md`
2. `02-Architecture-Overview.md`
3. `03-Sprint-Tracker.md`
4. `04-Requirement-Traceability-Matrix.md`
5. `05-Test-Strategy.md`
6. `06-AI-Provider-Abstraction.md`
7. `07-Risk-Assumption-Decision-Register.md`
8. `08-Codex-Execution-Prompt.md`
9. `09-Definition-of-Done.md`
10. `docs/planning/modules/*`
11. `seed/sme-discovery-v1.json`

## Non-negotiables

- Runtime questions in PostgreSQL; JSON only for seed/import/export.
- Original audio preserved.
- Provider-neutral transcription architecture.
- Offline-first Android interview.
- No provider secrets in APK or browser bundle.
- Docker for server components.
- Unit, integration, contract, Flutter and Playwright tests.
- RTM updated from requirement through evidence.
- Two APK profiles from one codebase, not duplicated applications.


## v0.2 domain-completeness additions

- version history and rationale
- domain glossary
- business events
- state machines
- sequence flows
- relational data model
- interview review/history specification
- micro-transcription lifecycle
- Google Workspace export model
- parent work-platform Work Object bridge
- parallel APK release strategy
- ADRs
- observability


## v0.3 implementation-control additions

See documents 23–37 for execution, acceptance, API, Android lifecycle, privacy, incidents, environments, AI lineage, Git/session workflow, benchmarking, test-data governance, compatibility and field release control.

## v0.4 freeze additions

Documents 38–43 and `docs/planning/sprint-context/` establish the final reading map, decision authority, stop rule and per-sprint context packs.
