# UraiFlow Brutal Gap Audit v0.3

## Verdict

The v0.2 package is a strong planning baseline, but it was still not implementation-safe enough for multiple AI coding agents to produce the same product without interpretation drift.

**Readiness before v0.3:** 7.8/10  
**Readiness target after v0.3:** 9.2/10

It is not honest to claim 10/10 because several facts still require physical verification:

- target Android device behaviour,
- actual server specification,
- actual API credentials,
- actual provider performance on Tamil and code-mixed audio,
- actual event network conditions,
- actual user interaction speed,
- and legal/privacy expectations for recorded business conversations.

## What was still missing

### 1. No implementation control plane

The package explained what to build, but not sufficiently how Codex must manage:

- branch naming,
- commit boundaries,
- session notes,
- evidence directories,
- defect lifecycle,
- scope-change requests,
- and release promotion.

### 2. Sprint tracker was still too outcome-level

It did not define:

- entry criteria,
- exit criteria,
- code ownership path,
- test command,
- evidence file,
- rollback artefact,
- or dependency gate per sprint.

### 3. No explicit acceptance matrix

Functional requirements existed, but there was no compact table stating:

- expected behaviour,
- negative behaviour,
- data persisted,
- UI evidence,
- and pass/fail decision.

### 4. No API contract catalogue

The architecture named APIs but did not freeze request/response contracts, errors, idempotency headers and versioning rules.

### 5. No mobile permission and lifecycle specification

Recording applications fail in practical use because of:

- microphone permissions,
- Android background restrictions,
- screen lock,
- incoming calls,
- battery optimisation,
- app termination,
- and low storage.

These were mentioned as risks but not specified as product behaviour.

### 6. No privacy and retention operating model

Consent was included, but not:

- consent text version,
- withdrawal,
- deletion,
- retention duration,
- redaction,
- access role,
- export sharing,
- and provider data-transfer policy.

### 7. No defect and incident workflow

If Subha reports “audio disappeared,” the package did not specify:

- incident record,
- evidence collection,
- severity,
- rollback,
- reproduction,
- fix verification,
- and release re-promotion.

### 8. No environment matrix

Local development, test, staging, field pilot and production were not separated strongly enough.

### 9. No explicit prompt/model lineage for AI-derived outputs

Provider profile versioning existed, but summary and extraction prompts needed a proper registry and reproducibility rule.

### 10. No exact session-to-Git operating method

The user specifically needs local project/session folders plus Git. That operational method was absent.

### 11. No “do not build” list per sprint

Without this, AI agents may opportunistically add features and alter the product.

### 12. No performance benchmark procedure

Local Whisper model selection cannot be decided from assumption. It needs a repeatable benchmark harness.

### 13. No test-data management plan

Audio and transcript fixtures need:

- provenance,
- consent,
- language labels,
- expected text,
- noise conditions,
- and storage rules.

### 14. No migration and compatibility test matrix across APK channels

Parallel installation was specified, but server/client compatibility and schema upgrade paths needed stronger controls.

### 15. No formal go/no-go checklist for field use

A build could pass tests but still be unsafe to hand to Subha.

## What v0.3 adds

- implementation control model,
- enhanced sprint execution matrix,
- acceptance criteria matrix,
- API contract catalogue,
- Android lifecycle specification,
- privacy/consent/retention model,
- defect and incident workflow,
- environment and deployment matrix,
- AI prompt/model lineage,
- local session and Git workflow,
- benchmark plan,
- test-data governance,
- compatibility matrix,
- field go/no-go checklist,
- and updated RTM/Definition of Done.

## Remaining unavoidable unknowns

These must be verified during implementation, not guessed:

1. exact Android phone model and OS build,
2. exact server CPU/RAM/GPU/storage,
3. whether local Whisper runs acceptably,
4. Sarvam/OpenAI/Gemini credentials and quotas,
5. actual Tamil interview audio quality,
6. participant consent wording,
7. network performance at the venue,
8. and real user feedback from Subha.
