# UraiFlow Monorepo Structure

```text
uraiflow/
├── apps/
│   ├── mobile_flutter/          # Capture, Assist and Lab flavours
│   └── admin_web/               # Administration and review web UI
├── services/
│   ├── api_fastapi/             # REST/domain application
│   ├── worker/                  # media/transcription/export jobs
│   └── local_stt/               # local Whisper-compatible service
├── packages/
│   ├── domain/                  # provider-independent domain model
│   ├── contracts/               # schemas/events/API contracts
│   ├── provider_adapters/       # Sarvam/OpenAI/Gemini/local
│   └── shared_testkit/
├── infrastructure/
│   ├── docker/
│   ├── migrations/
│   ├── deployment/
│   └── observability/
├── docs/
│   ├── architecture/
│   ├── help/
│   ├── planning/
│   ├── api/
│   └── adr/
├── sprints/
├── sessions/
├── tests/
│   ├── integration/
│   ├── contract/
│   ├── e2e/
│   └── performance/
└── evidence/
```

## One repository now

Use one monorepo during early development because contracts and releases are changing together.

## Future split triggers

Split only when one or more are proven:

- independent release cadence,
- separate accountable team,
- security/isolation boundary,
- very different scaling,
- reusable service adopted by another product,
- or repository/test time becomes materially harmful.

Probable future repositories:

- `uraiflow-mobile`
- `uraiflow-platform`
- `uraiflow-ai-gateway`
- `uraiflow-docs`

Do not split merely because different developers touch different folders. Use CODEOWNERS and path-based CI first.
