# UraiFlow Product Charter v0.1

## 1. Problem

SME conversations can lose information through inconsistent questions, incomplete notes, weak transcription, unavailable internet and no structured evidence.

## 2. Objective

Create an Android-first guided-interview application and backend that:

- displays approved questions,
- records complete conversations,
- saves safely offline,
- segments audio,
- transcribes through selectable AI providers,
- shows transcript on screen,
- supports Tamil and English layers,
- allows correction,
- preserves raw evidence,
- and exports structured interview records.

## 3. Users

**Primary:** Subha, interviewer.  
**Secondary:** administrator, transcript reviewer, analyst, future BPO agent and DWOS services.

## 4. Functional requirements

### Interview setup

- **FR-001** Create interview.
- **FR-002** Capture company, participant, role, industry, location and contact.
- **FR-003** Capture explicit recording consent.
- **FR-004** Select active question set.
- **FR-005** Save locally before recording begins.

### Guided questions

- **FR-010** Show one question at a time with section and progress.
- **FR-011** Use fixed approved order in event release.
- **FR-012** Previous/next navigation.
- **FR-013** Skip and not-applicable states.
- **FR-014** Add ad-hoc follow-up.
- **FR-015** Mark follow-up interview-only or reusable candidate.
- **FR-016** Preserve exact question snapshot asked.

### Audio

- **FR-020** Start, pause, resume and stop.
- **FR-021** Preserve original audio.
- **FR-022** Split into ordered manageable segments.
- **FR-023** Link segment to interview/question.
- **FR-024** Recover after interruption or restart.
- **FR-025** Continue manually when transcription is unavailable.

### Transcription

- **FR-030** Select active provider through configuration.
- **FR-031** Sarvam adapter.
- **FR-032** OpenAI adapter.
- **FR-033** Gemini adapter.
- **FR-034** Local Whisper-compatible adapter.
- **FR-035** Extension contract for later providers.
- **FR-036** Display transcript when available.
- **FR-037** Preserve raw provider transcript.
- **FR-038** Save human-corrected transcript separately.
- **FR-039** Native/Tamil transcript where supported.
- **FR-040** English translation/standardised layer where configured.
- **FR-041** Record provider/model/latency/status/cost/confidence metadata where available.
- **FR-042** Retry transient failures.
- **FR-043** Explicit fallback policy.
- **FR-044** Never report failed transcription as success.

### Question administration

- **FR-050** Questions, sections and sets in PostgreSQL.
- **FR-051** Initial seed from Git-controlled JSON.
- **FR-052** Admin view of question sets.
- **FR-053** Create/edit/deactivate questions.
- **FR-054** Version and audit history.
- **FR-055** Schema/API support display order; event UI may keep order fixed.
- **FR-056** Future spoken-question drafting reuses transcription module.

### Provider administration

- **FR-060** Provider configuration page.
- **FR-061** Enable/disable.
- **FR-062** Priority and fallback order.
- **FR-063** Model/profile configuration.
- **FR-064** Connectivity test.
- **FR-065** Secure credential reference.
- **FR-066** Health and last-test result.

### Storage, sync and export

- **FR-070** Mobile local persistence.
- **FR-071** PostgreSQL backend.
- **FR-072** Explicit retryable sync.
- **FR-073** Idempotency: no duplicate interview or audio.
- **FR-074** Metadata in PostgreSQL.
- **FR-075** Audio in file/object storage.
- **FR-076** Google Drive/Sheets connector later; not source of truth.
- **FR-077** Per-interview Markdown and JSON export.
- **FR-078** Consolidated CSV export.

### Review

- **FR-080** Interview timeline.
- **FR-081** Audio, raw transcript and corrected transcript clearly distinct.
- **FR-082** Completion rules include consent and required fields.
- **FR-083** Post-interview corrections.
- **FR-084** Immutable audit events.
- **FR-085** Summary labelled as derived AI output.

### Security/operations

- **FR-090** Admin authentication.
- **FR-091** TLS outside local development.
- **FR-092** No API key in APK/web static code.
- **FR-093** Safe structured logging.
- **FR-094** Docker Compose deployment.
- **FR-095** Health endpoints.
- **FR-096** Backup and restore scripts.
- **FR-097** Retention configuration.
- **FR-098** Recording blocked until consent.

## 5. Non-functional requirements

- **NFR-001** Android-first and responsive admin.
- **NFR-002** Offline-first interview.
- **NFR-003** Accepted audio survives restart.
- **NFR-004** Provider-neutral.
- **NFR-005** Modular classes and interfaces.
- **NFR-006** 80% overall line coverage, 90% domain/application, 100% branch for consent, completion, fallback and sync idempotency.
- **NFR-007** API, integration and Playwright automation.
- **NFR-008** Deterministic Docker test environment.
- **NFR-009** Correlation IDs and structured logs.
- **NFR-010** Repeatable migrations.
- **NFR-011** Large controls, readable text and minimal typing.
- **NFR-012** Tamil Unicode end to end.
- **NFR-013** UI responsive while transcription runs.
- **NFR-014** No cross-interview leakage.
- **NFR-015** UTC storage.
- **NFR-016** Graceful network/provider failures.
- **NFR-017** Reproducible build.
- **NFR-018** Future dialler integration boundary.

## 6. Exclusions from initial release

- Google Play publishing,
- full DWOS engine,
- production multi-tenant billing,
- live dialler integration,
- guaranteed speaker diarisation,
- complex dashboards,
- and automatic final transcript approval.

## 7. Two builds

### APK-A Reliable Capture

Manual-first, offline, audio, notes, questions, follow-ups, resume, export and sync.

### APK-B Speech Assisted

APK-A plus provider selection, segmentation, transcription display, Tamil/English layers and provider diagnostics.

Both builds use one codebase with flavours or feature flags.
