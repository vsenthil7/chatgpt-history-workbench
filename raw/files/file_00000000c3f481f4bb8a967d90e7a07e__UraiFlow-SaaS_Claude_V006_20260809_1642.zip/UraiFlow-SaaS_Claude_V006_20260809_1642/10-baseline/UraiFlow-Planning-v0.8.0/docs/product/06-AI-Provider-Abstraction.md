# UraiFlow AI Provider Abstraction v0.1

## Principle

“AI provider” does not mean every vendor supports speech-to-text, streaming, diarisation, translation and analysis. Capabilities must be explicit.

## Initial provider roles

| Provider | Planned role |
|---|---|
| Sarvam AI | Primary candidate for Indic/Tamil STT, translation and diarisation where supported |
| OpenAI | STT and optional transcript processing |
| Google Gemini | Audio transcription/understanding and optional analysis |
| Local Whisper-compatible service | Private/local batch STT |
| Perplexity | Research/analysis only unless direct official audio support is separately verified |
| Anthropic Claude | Transcript analysis/structuring only unless official audio input is separately verified |

## Planning verification as of 17 July 2026

- OpenAI officially documents audio transcription and translation endpoints.
- Gemini officially documents audio understanding/transcription/translation and Live API audio transcription.
- Sarvam officially documents Indian-language/English STT, streaming WebSocket STT, translation and diarisation offerings.
- Perplexity’s official API overview centres on Agent, Search, Sonar and Embeddings; direct STT must not be inferred from third-party/showcase apps.
- Whisper family profiles are normally named `tiny`, `base`, `small`, `medium`, `large` or implementation-specific equivalents—not simply low/medium/high.

Capabilities, prices and model names must be rechecked against official documentation during implementation.

## Capability enum

```text
TRANSCRIBE_BATCH
TRANSCRIBE_STREAM
TRANSLATE_SPEECH_TO_ENGLISH
TRANSLATE_TEXT
DIARISE
TIMESTAMPS
CONFIDENCE
LANGUAGE_DETECTION
SUMMARISE
STRUCTURE_OUTPUT
REALTIME_PARTIALS
```

## Provider configuration

- code
- enabled
- endpoint/base URL
- credential reference
- model/profile
- capabilities
- languages
- timeout
- maximum segment duration
- concurrency
- retry
- priority
- fallback group
- cost metadata
- health
- last verification

## Routing

Request states:

- required capability
- language
- live or batch
- privacy requirement
- latency target
- cost ceiling
- fallback permission

Only capable providers are selectable.

## Example fallback

```text
Primary: Sarvam
Fallback 1: Local Whisper
Fallback 2: OpenAI
```

Fallback must consider consent, data residency, language, cost and outage. It is not automatically permitted for every interview.

## Local Whisper service

Expose a normal adapter contract:

- `POST /v1/transcriptions`
- `GET /health`
- `GET /models`

Possible profiles:

- fast: tiny/base equivalent
- balanced: small equivalent
- accurate: medium/large equivalent

Do not freeze mapping before benchmarking the actual Ubuntu host.

## Transcript layers

1. provider raw response
2. raw transcript
3. normalised transcript
4. human-corrected transcript
5. English translation/standardisation
6. summary
7. structured answers

Never overwrite an earlier layer.

## Live display honesty

Partial transcript is marked provisional. If the system uploads short segments and returns each result, call it segmented near-real-time transcription—not true streaming unless the provider connection actually streams partial results.

## Admin

- enable/disable
- priority/fallback
- model profile
- language mode
- capability display
- connection test
- approved sample test
- latency/error display
- masked credential reference

## Telemetry

Capture audio seconds, requests, model, latency, status, retries, estimated cost and fallback path where available.
