# UraiFlow to parent work-platform Work Object Bridge

## Mapping

### Interview Work Object

Represents conducting and completing an interview.

### Transcript Review Work Object

Created when:

- confidence is low,
- provider fails,
- important corrections are required,
- or interview is marked review-required.

### Follow-up Work Object

Created from:

- customer pain point,
- promised callback,
- missing information,
- possible service opportunity,
- or validation task.

### Export Work Object

Created for failed or pending external delivery.

## Required linkage

Every Work Object created from UraiFlow contains:

- source interview ID
- source event ID
- evidence URI
- company/participant
- trigger
- priority
- required output
- status
- owner
- due date if any

## Reuse

The bridge must be event-driven through an internal interface, even if v0.2 uses an in-process implementation.

```python
class WorkObjectGateway(Protocol):
    async def create_work_object(self, request: WorkObjectRequest) -> WorkObjectReference:
        ...
```

## Boundary

UraiFlow owns conversation evidence.  
The parent work platform owns broader assignment, ownership, SLA, review and completion workflow.
