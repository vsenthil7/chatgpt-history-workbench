# Interview Review and History Module

## Purpose

The application must not only capture an interview. It must make every completed or incomplete interview retrievable, reviewable, analysable and exportable.

## Interview list page

Columns/cards:

- company
- participant
- date/time
- status
- recording status
- transcription status
- review status
- export status
- current app release
- last sync time

Filters:

- date
- company
- industry
- interviewer
- completed/incomplete
- transcription failed
- review pending
- export pending

## Interview detail page

### Header

- interview ID
- company/participant
- question-set version
- app release
- provider profile
- consent
- start/end/duration
- sync state

### Timeline

Ordered timeline of:

- questions shown
- recordings
- segments
- micro-transcriptions
- corrections
- notes
- follow-ups
- processing failures
- exports

### Transcript views

- by question
- by segment
- complete native-language transcript
- complete English transcript
- raw versus corrected comparison
- audio playback with timestamp jump

### Analysis

- structured answers
- pain points
- software inventory
- outsourcing inventory
- follow-up opportunities
- confidence and source evidence

### Actions

- resume interview
- reopen
- correct transcript
- approve transcript
- regenerate derived summary
- export
- create follow-up work object
- delete according to retention/authority

## Mobile history

Mobile must show a simplified history and allow:

- reopen/resume
- view status
- listen to audio
- read transcript
- correct text
- retry sync/transcription
- export/share approved artefact

## Audit requirement

Every edit must show:

- original value
- new value
- actor
- time
- reason where required
- linked release and processing run
