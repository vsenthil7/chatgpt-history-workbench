# Transcript Lifecycle and Microprocessing

## Capture model

The application records a complete interview and may also create logical or physical micro-segments.

### Complete recording

- retained as primary evidence
- one or more files permitted after pause/resume
- linked to the interview

### Micro-segments

Created by:

- question boundary,
- pause boundary,
- configured duration,
- or explicit interviewer action.

## Processing chain

```text
Audio segment
→ provider request
→ provider raw response
→ raw micro-transcript
→ normalised micro-transcript
→ optional corrected micro-transcript
→ ordered transcript aggregate
→ optional English aggregate
→ structured answers
→ summary/insights
```

## Accumulation rules

- sequence number defines ordering.
- timestamps resolve overlap.
- aggregate stores all contributing transcript-version IDs.
- reprocessing one segment creates a new version and a new aggregate version.
- prior aggregates remain available.
- missing segment produces a visible gap marker, never silent omission.

## Validation

Each micro-transcript can be:

- pending
- accepted
- corrected
- rejected
- needs replay

Validation may happen:

- during interview,
- immediately after interview,
- or centrally later.

## Speaker labels

Speaker diarisation is optional capability, not guaranteed.

Fallback speaker model:

- Interviewer
- Participant
- Unknown

Manual correction must be possible.

## Data shown on screen

During interview:

- current question
- recording state
- provisional segment transcript
- accepted/corrected text
- previous micro-transcripts for current question

After interview:

- complete ordered timeline
- full audio
- segment transcript list
- native aggregate
- English aggregate
- gaps/errors/retries
