# Structured Record Proposal Bridge

## Example employee speech
“I spoke to the auditor for twenty minutes, follow up on Monday, and tomorrow I am available ten to one.”

## Candidate outputs
- Execution session or Daily Tracker entry
- Time entry
- Follow-up Work Object or plan item
- Availability window

## Boundary
UraiFlow proposes records through target-system contracts. The receiving module owns validation and business rules.

## User interaction
For each proposal show: extracted value, target record type, target field, confidence, source transcript segment and why it was routed there. Employee can confirm all, confirm selected, edit, reject or save as draft.
