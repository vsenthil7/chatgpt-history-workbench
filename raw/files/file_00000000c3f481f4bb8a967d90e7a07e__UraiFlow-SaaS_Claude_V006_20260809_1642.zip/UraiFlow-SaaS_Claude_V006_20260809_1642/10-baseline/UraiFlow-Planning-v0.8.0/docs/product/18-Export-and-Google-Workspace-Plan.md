# Export and Google Workspace Plan

## Principle

PostgreSQL and object storage are the system of record. Google Sheets/Drive are downstream collaboration destinations.

## Canonical export model

Every export is built from a versioned canonical interview DTO containing:

- interview metadata
- company and participant
- consent
- question-set version
- question snapshots
- answers
- notes
- audio references
- micro-transcripts
- final native transcript
- final English transcript
- summary
- insights
- follow-ups
- provider lineage
- app release
- export version

## Google Sheet design

### Sheet 1 — Interview Index

One row per interview:

- interview ID
- date
- company
- participant
- industry
- status
- top pain point
- software used
- outsourced work
- follow-up required
- transcript link
- audio link
- review status

### Sheet 2 — Question Answers

One row per interview/question:

- interview ID
- section
- question order
- question snapshot
- answer status
- structured answer
- corrected transcript excerpt
- confidence
- evidence link

### Sheet 3 — Pain Points

- interview ID
- category
- pain point
- severity
- frequency
- current workaround
- estimated spend
- evidence

### Sheet 4 — Software and Outsourcing Inventory

- interview ID
- software/service
- provider
- function
- monthly/annual spend
- satisfaction
- replacement interest

### Sheet 5 — Follow-ups

- interview ID
- company
- follow-up action
- owner
- priority
- target date
- parent work-platform Work Object ID

## Export timing

- on-demand per interview
- batch end-of-day
- scheduled later
- retryable and idempotent

## Drive structure

```text
/UraiFlow/
  /Interviews/YYYY/MM/DD/<Interview-ID>/
    interview.json
    transcript-native.md
    transcript-en.md
    summary.md
    audio-links.txt
```

## Security

- use service account/OAuth server-side
- no Google credential in APK
- share only approved folders
- retain export audit and checksum
