# AI Prompt and Model Lineage

## Registry

Store every processing definition:

- task code
- prompt version
- system instruction
- output schema version
- provider
- model
- temperature/settings
- language
- effective date
- status

## Applies to

- transcription post-processing
- translation
- normalisation
- structured-answer extraction
- summary
- insight generation
- follow-up generation

## Reproducibility

Every derived artefact stores:

- source transcript version IDs
- prompt version
- model profile
- processing run ID
- output schema version
- created time

Changing a prompt creates a new version. Never silently regenerate and overwrite prior output.
