# Environment and Deployment Matrix

| Environment | Purpose | Data | Providers | Deployment |
|---|---|---|---|---|
| Local Dev | coding | synthetic | fake/local | Docker Compose |
| CI Test | automated tests | fixtures | fake | ephemeral containers |
| Integration | full system | synthetic | fake + optional sandbox | dedicated Compose |
| Staging | release candidate | approved sample | sandbox/limited live | Ubuntu host |
| Field Pilot | Subha use | real consented interviews | approved providers | secured server |
| Production | later | governed real data | production profiles | hardened deployment |

## Rules

- no real participant data in local dev/CI
- secrets differ by environment
- environment name visible in UI
- staging and field builds clearly labelled
- database backups verified before release
- production promotion requires signed go/no-go checklist
