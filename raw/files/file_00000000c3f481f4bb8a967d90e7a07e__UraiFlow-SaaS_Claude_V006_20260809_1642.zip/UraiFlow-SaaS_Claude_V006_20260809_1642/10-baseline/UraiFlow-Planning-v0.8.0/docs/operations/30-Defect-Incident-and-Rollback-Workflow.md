# Defect, Incident and Rollback Workflow

## Incident trigger

Examples:

- audio missing
- interview inaccessible
- transcript attached to wrong interview
- duplicate data
- secret exposure
- app crash
- provider cost spike

## Flow

```text
Incident reported
→ capture release/interview/correlation IDs
→ preserve logs/evidence
→ classify severity
→ decide continue/stop field use
→ reproduce
→ identify root cause
→ create regression test
→ fix
→ execute full affected suite
→ issue release
→ verify
→ close with report
```

## Field rollback

Subha must always retain the stable Capture app.

If Assist fails:

- stop using Assist
- continue in Capture
- preserve failed interview evidence
- sync later
- do not uninstall until evidence is collected

## Severity

- BLOCKER: field capture impossible or evidence loss
- CRITICAL: consent/security/data corruption
- MAJOR: important function unusable with workaround
- MINOR: cosmetic or low-impact issue
