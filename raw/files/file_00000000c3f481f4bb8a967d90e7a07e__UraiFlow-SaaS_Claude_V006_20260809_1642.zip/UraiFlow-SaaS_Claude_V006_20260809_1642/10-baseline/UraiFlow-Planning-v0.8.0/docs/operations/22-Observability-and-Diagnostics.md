# Observability and Diagnostics

## Correlation identifiers

- request ID
- correlation ID
- causation ID
- interview ID
- recording ID
- segment ID
- transcription job ID
- provider profile ID
- export ID
- app release

## Logs

Structured JSON logs for:

- API request
- sync
- upload
- segmentation
- provider selection
- retry/fallback
- transcript save
- correction
- export
- errors

Never log secrets. Sensitive transcript/audio content should be excluded or redacted by default.

## Diagnostics page

Show:

- backend health
- database health
- storage health
- provider health
- pending sync count
- pending transcription count
- failed jobs
- average latency
- last successful export
- app/server versions

## User-visible diagnostics

For every interview:

- local save state
- sync state
- recording status
- transcription status
- provider used
- retry/fallback path
- last error
- corrective action

## Metrics

- interviews created/completed
- audio minutes
- segments processed
- provider success/failure
- latency
- fallback rate
- correction rate
- transcript gap count
- sync retries
- export success/failure
