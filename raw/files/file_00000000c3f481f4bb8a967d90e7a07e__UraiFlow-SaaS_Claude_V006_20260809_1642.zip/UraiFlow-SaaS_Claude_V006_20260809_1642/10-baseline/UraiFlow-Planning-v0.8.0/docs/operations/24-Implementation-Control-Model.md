# UraiFlow Implementation Control Model

## Repository branches

```text
main
develop
feature/MS-xx-short-name
fix/DEF-xxxx-short-name
release/x.y.z
hotfix/x.y.z
```

## Commit rule

One logical change per commit.

Examples:

```text
feat(interview): add consent-gated recording
test(sync): add duplicate upload integration coverage
docs(rtm): link FR-073 evidence
fix(audio): recover interrupted recording metadata
```

## Session folders

Each coding session creates:

```text
/sessions/YYYY-MM-DD-HHMM-agent-name/
  SESSION-PLAN.md
  COMMANDS.log
  DECISIONS.md
  FAILURES.md
  TEST-RESULTS.md
  CONTEXT-HANDOFF.md
```

Do not commit raw secrets or huge generated logs. Commit summarised session evidence and reference external artefacts.

## Sprint execution folder

```text
/sprints/MS-xx/
  PLAN.md
  ENTRY-CHECKLIST.md
  TASKS.md
  TEST-MAP.md
  EVIDENCE-INDEX.md
  EXIT-REPORT.md
```

## Change control

Any new feature discovered during implementation becomes:

```text
CR-xxxx
```

The change request records:

- origin,
- reason,
- requirement impact,
- architecture impact,
- test impact,
- sprint impact,
- release impact,
- decision,
- and approver.

No AI agent may silently implement a change request.

## Defect model

```text
DEF-xxxx
Severity: BLOCKER / CRITICAL / MAJOR / MINOR
Found in release:
Requirement:
Reproduction:
Expected:
Actual:
Evidence:
Root cause:
Fix commit:
Verification:
Regression test:
```

## Evidence structure

```text
/evidence/
  /builds/
  /coverage/
  /unit/
  /integration/
  /flutter/
  /playwright/
  /security/
  /performance/
  /releases/
```

## Completion rule

A sprint is not complete until:

- code merged,
- tests passed,
- evidence indexed,
- RTM updated,
- release note updated,
- rollback identified,
- and known limitations recorded.
