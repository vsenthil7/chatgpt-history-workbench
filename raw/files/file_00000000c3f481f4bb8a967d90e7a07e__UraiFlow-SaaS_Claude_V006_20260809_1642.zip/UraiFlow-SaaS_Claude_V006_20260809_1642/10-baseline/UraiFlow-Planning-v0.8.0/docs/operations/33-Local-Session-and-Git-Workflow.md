# Local Session and Git Workflow

## Recommended local structure

```text
/UraiFlow-Workspace/
  /repo/                 # Git repository
  /sessions/             # AI/human session records
  /incoming/             # files received from other agents
  /outgoing/             # review packages
  /evidence-local/       # large local test evidence
  /secrets-local/        # never committed
```

## Session start

1. Pull Git.
2. Read current sprint `PLAN.md`.
3. Read RTM rows for the sprint.
4. Create session folder.
5. Record intended files/tests.
6. Confirm working tree clean.

## Session end

1. Run tests.
2. Update RTM.
3. Update sprint evidence.
4. Record failures and open questions.
5. Commit logical changes.
6. Push branch.
7. Create `CONTEXT-HANDOFF.md`.

## Cross-agent handoff

Every handoff contains:

- branch/commit
- sprint
- completed
- incomplete
- decisions
- failures
- exact commands
- next task
- files not to modify
- evidence paths

This prevents the chat page from being the only project memory.
