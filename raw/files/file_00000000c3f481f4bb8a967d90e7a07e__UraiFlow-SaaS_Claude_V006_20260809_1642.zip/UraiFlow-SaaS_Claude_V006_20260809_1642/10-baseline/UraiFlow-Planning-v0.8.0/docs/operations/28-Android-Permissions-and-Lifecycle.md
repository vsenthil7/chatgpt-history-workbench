# Android Permissions and Lifecycle Specification

## Permissions

- microphone permission requested contextually
- storage strategy compatible with scoped storage
- notification permission only if background processing requires it
- network state observed but not required for capture

## Required behaviours

### Permission denied

- explain why microphone is needed
- allow manual notes
- permit retry
- never crash

### Screen lock/background

- recording continuation behaviour must be tested on target device
- persistent notification used if required by Android foreground-service rules
- visible recording indicator maintained

### Incoming call/audio interruption

- pause or safely stop according to platform event
- persist current file
- show recovery message
- never silently continue with invalid audio source

### App termination

- flush metadata frequently
- recover incomplete recording
- mark interruption event

### Low storage

- warn before recording when threshold crossed
- stop safely before corruption
- retain prior evidence

### Battery optimisation

- document device setting if necessary
- do not require disabling protections unless proven essential

### Upgrade

- preserve local interviews across same-channel upgrades
- separate storage by release channel
- migration test for every schema change
