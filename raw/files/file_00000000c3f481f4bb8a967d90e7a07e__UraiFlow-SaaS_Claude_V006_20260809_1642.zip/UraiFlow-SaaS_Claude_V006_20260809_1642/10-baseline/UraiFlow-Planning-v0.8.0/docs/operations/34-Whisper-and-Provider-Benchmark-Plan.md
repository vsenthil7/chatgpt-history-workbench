# Whisper and Provider Benchmark Plan

## Test corpus

- Tamil
- English
- Tamil-English code-mixed
- female/male voices
- quiet/noisy
- short segments
- 10-minute continuous sample
- business names and numbers

## Metrics

- word/character error rate where reference exists
- Tamil preservation
- English translation quality
- latency
- real-time factor
- CPU/RAM/GPU
- cost
- failure rate
- diarisation quality
- timestamp quality

## Local profiles

Benchmark actual available models such as:

- tiny
- base
- small
- medium
- large/equivalent

Do not map “fast/balanced/accurate” until measurements exist.

## Output

A versioned benchmark report decides:

- default provider
- fallback order
- segment duration
- local model
- concurrency
- timeout
