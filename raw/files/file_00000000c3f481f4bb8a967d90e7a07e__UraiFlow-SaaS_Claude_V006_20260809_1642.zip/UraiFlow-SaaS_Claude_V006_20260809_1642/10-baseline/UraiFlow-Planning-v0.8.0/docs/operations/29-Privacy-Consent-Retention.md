# Privacy, Consent and Retention Model

## Consent record

Store:

- consent status
- consent text version
- language
- date/time
- interviewer
- participant acknowledgement method
- withdrawal status

## Consent behaviour

- recording cannot begin without consent
- declined consent permits manual notes only
- withdrawal stops future processing
- deletion request follows authorised workflow

## Data classes

- business identity/contact
- audio
- transcript
- translation
- notes
- derived summary/insight
- provider telemetry

## Access roles

- interviewer
- reviewer
- administrator
- analyst
- auditor

Each role receives minimum required access.

## Retention

Retention must be configurable by data class and organisation policy.

Default planning values are not legal advice and must be approved before field release.

## Provider transfer

For every provider profile record:

- provider
- region/data handling notes
- permitted data classes
- participant consent compatibility
- retention/deletion setting
- fallback eligibility

## Redaction

Support later redaction of:

- phone
- email
- personal identifiers
- confidential commercial data

## Export sharing

Exports inherit approval status. Unreviewed raw audio/transcripts must not be broadly shared by default.
