# v0.6 Repository Restructure and Naming Correction

## Why v0.5 was changed

v0.5 left planning documents, module plans and sprint contexts outside the `docs/` hierarchy. That could make Codex treat some documents as execution artefacts rather than controlled documentation.

It also standardised “AUMNITY WorkCore” without checking the exact standalone WorkCore name deeply enough.

## Corrections

- Every document moved under `docs/`.
- Module plans moved to `docs/planning/modules/`.
- Sprint context packs moved to `docs/planning/sprint-context/`.
- Architecture documents and HTML diagram aligned under `docs/architecture/`.
- Help documentation retained under `docs/help/`.
- API, testing, operations and governance separated.
- AUMNITY defined only as the umbrella identity.
- WorkCore withdrawn because it is already heavily used.
- Parent product name marked pending.
- UraiFlow retained as provisional pending formal trademark clearance.

## No code movement

The code folders shown in the repository map are planned locations. This package remains documentation-only.
