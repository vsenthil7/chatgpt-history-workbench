# Name Standardisation and Preliminary Search Record

## Former working name

KuralFlow

## Standardised name

**UraiFlow**

## Reason

The exact KuralFlow phrase was not prominent in the preliminary search, but the KURAL root is crowded across active software and app businesses. UraiFlow better describes conversation/discourse and showed no exact software match in the performed search.

## Parent platform

**AUMNITY Work Platform**

Former working name: DWOS — Distributed Work Operating System.

DWOS is already used by Dental Wings software, while WorkOS is an active enterprise software company and common product category. AUMNITY Work Platform provides a more distinctive parent identity.

## Limitation

This is a preliminary internet conflict search only. Before incorporation, domain purchase, public launch or significant branding spend, perform:

- UK IPO trademark search,
- India IP trademark search,
- EUIPO/WIPO search as relevant,
- Companies House/MCA company-name checks,
- domain/social handle checks,
- and professional legal clearance.
