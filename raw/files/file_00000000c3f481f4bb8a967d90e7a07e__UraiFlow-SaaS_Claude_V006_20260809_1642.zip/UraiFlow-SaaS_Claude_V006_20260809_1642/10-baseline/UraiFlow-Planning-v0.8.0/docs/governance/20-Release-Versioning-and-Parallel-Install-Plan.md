# Release Versioning and Parallel Install Plan

## Requirement

Subha may need multiple application versions installed simultaneously so she can fall back immediately.

## Release channels

### UraiFlow Capture

- package ID: `com.dwos.kuralflow.capture`
- stable manual/offline-focused build
- label: `UraiFlow Capture`

### UraiFlow Assist

- package ID: `com.dwos.kuralflow.assist`
- speech-assisted build
- label: `UraiFlow Assist`

### UraiFlow Lab

- package ID: `com.dwos.kuralflow.lab`
- experimental provider/features
- label: `UraiFlow Lab`

These may share most source code but use separate application IDs and visible labels.

## Version format

```text
MAJOR.MINOR.PATCH+BUILD
```

Example:

```text
0.2.0+2026071701
```

## Release metadata

Every APK must expose:

- semantic version
- Git commit
- build timestamp
- channel
- database schema version
- questionnaire seed version
- enabled feature flags

## Compatibility

- local database migrations must be forward-tested.
- multiple channels should use separate local application storage.
- server API must support at least the current and immediately previous client version during event use.
- interview exports include app release identity.

## Rollout micro-releases

1. Capture 0.1 — profile, consent, questions, audio, local save.
2. Capture 0.2 — history, resume, DB sync.
3. Assist 0.1 — segmented transcription and on-screen text.
4. Assist 0.2 — provider selection, Tamil/English layers.
5. Assist 0.3 — review, export and diagnostics.

## Rollback

Do not overwrite APK files in Drive.

Naming:

```text
UraiFlow-Capture-0.1.0+build.apk
UraiFlow-Capture-0.2.0+build.apk
UraiFlow-Assist-0.1.0+build.apk
```

Record SHA-256 and release notes for each.
