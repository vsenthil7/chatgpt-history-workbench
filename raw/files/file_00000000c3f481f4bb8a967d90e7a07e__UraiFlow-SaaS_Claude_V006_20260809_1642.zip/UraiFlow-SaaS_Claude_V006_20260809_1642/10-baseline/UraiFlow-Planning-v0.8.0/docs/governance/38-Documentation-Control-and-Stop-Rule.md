# UraiFlow Documentation Control and Stop Rule v0.4

## Purpose

Prevent endless planning while also preventing Codex from inventing missing decisions.

## Baseline decision

UraiFlow planning is frozen after v0.4 for implementation start.

Further planning changes are allowed only when one of these occurs:

1. an implementation constraint contradicts a documented decision,
2. a test exposes an unhandled requirement,
3. a provider/device/server fact is verified and changes the design,
4. field feedback creates an approved change request,
5. a legal/privacy requirement is confirmed,
6. or a release-blocking defect requires architectural correction.

A request to “be brutal” by itself must not trigger unlimited document expansion after this baseline.

## Codex authority

Codex may decide:

- internal variable names,
- private helper functions,
- test fixture implementation,
- code formatting,
- non-public refactoring that preserves contracts,
- and equivalent library usage already permitted by the architecture.

Codex may not decide:

- product scope,
- new features,
- data retention,
- provider fallback policy,
- user-facing workflow,
- package IDs,
- database ownership boundaries,
- state transitions,
- API breaking changes,
- consent wording,
- release promotion,
- or removal/deferment of requirements.

Unknown items become `OPEN-DECISION` records and block only the affected task.

## Completion of planning

Planning is considered complete when:

- each sprint has a context pack,
- each context pack links requirements, architecture, modules, APIs, tests and evidence,
- every unresolved business choice is listed,
- Codex authority is bounded,
- and formal change control exists.

v0.4 satisfies this condition.
