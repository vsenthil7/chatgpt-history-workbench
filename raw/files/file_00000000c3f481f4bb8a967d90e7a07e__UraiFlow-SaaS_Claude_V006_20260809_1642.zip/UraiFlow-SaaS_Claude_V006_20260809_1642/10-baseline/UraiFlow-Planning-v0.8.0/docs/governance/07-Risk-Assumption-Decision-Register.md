# UraiFlow Risk, Assumption and Decision Register v0.1

## Decisions

| ID | Decision | Reason |
|---|---|---|
| D-001 | Working name UraiFlow under DWOS | Separates reusable module from parent platform |
| D-002 | Modular monolith first | Fast, testable and extractable later |
| D-003 | FastAPI + PostgreSQL | Python ecosystem and future scale |
| D-004 | Flutter Android | Direct APK and mobile workflow |
| D-005 | PostgreSQL runtime questions; JSON seed | Editability plus Git traceability |
| D-006 | Two APK flavours from one codebase | Reliable fallback without divergence |
| D-007 | Preserve original audio | Evidence and correction |
| D-008 | Offline-first | Event resilience |
| D-009 | Provider abstraction from day one | Avoid lock-in |
| D-010 | Docker server components | Repeatability |
| D-011 | Automated testing before human UAT | User performs final visual review |
| D-012 | Fixed event question order | Minimise release risk |

## Assumptions to verify

| ID | Assumption | Verification |
|---|---|---|
| A-001 | Target Android permits sideloading | Install test APK |
| A-002 | Ubuntu host specification is sufficient | Capture CPU/RAM/disk/GPU |
| A-003 | Host is securely reachable | Network/TLS test |
| A-004 | Sarvam access exists | Credential/sample call |
| A-005 | OpenAI/Gemini credentials may exist | Inventory |
| A-006 | Local Whisper is fast enough | Tamil/code-mixed benchmark |
| A-007 | Participants may consent | Consent script and interviewer confirmation |
| A-008 | Recorder works on target phone | Device test |
| A-009 | Event internet may fail | Offline E2E |
| A-010 | Initial usage is one interviewer | Confirm before simplifying roles |

## Risks

| ID | Risk | Mitigation |
|---|---|---|
| R-001 | Scope drifts and final product changes | RTM-first change control |
| R-002 | Live transcript is poor | Keep audio, provisional label, correction |
| R-003 | Network unavailable | Offline capture/deferred processing |
| R-004 | Provider outage/rate limit | Retry/fallback/manual workflow |
| R-005 | Secret exposed | Backend-only provider calls |
| R-006 | Consent unclear | Mandatory consent gate and visible recording state |
| R-007 | Audio lost | Durable local writes and crash tests |
| R-008 | Local Whisper too slow | Segments, queue and cloud fallback |
| R-009 | Provider capability assumed | Official-doc plus contract verification |
| R-010 | APK variants diverge | One source tree and feature flags |
| R-011 | Host identity/spec unclear | Infrastructure inventory |
| R-012 | Tests falsely green | Real assertions and evidence review |
| R-013 | Playwright misses mobile | Flutter emulator/integration tests |
| R-014 | Question edits alter history | Immutable snapshots |
| R-015 | Sensitive audio retained too long | Retention/deletion controls |

## Open decisions

- commercial name,
- Flutter web versus separate admin,
- background-job implementation,
- object-storage implementation,
- local Whisper engine/model,
- provider fallback order,
- server network/TLS,
- retention duration.
