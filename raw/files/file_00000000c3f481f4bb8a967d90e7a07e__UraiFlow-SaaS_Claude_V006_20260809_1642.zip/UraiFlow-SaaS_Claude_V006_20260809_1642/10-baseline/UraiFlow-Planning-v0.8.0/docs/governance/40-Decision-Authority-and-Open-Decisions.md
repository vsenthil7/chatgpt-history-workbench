# UraiFlow Decision Authority and Open Decisions

## Frozen product decisions

- Product module: UraiFlow inside AUMNITY Work Platform.
- Android-first.
- Flutter client.
- FastAPI backend.
- PostgreSQL metadata.
- Audio outside PostgreSQL.
- Offline-first.
- Full recording plus micro-segments.
- Immutable raw evidence.
- Provider-neutral adapters.
- Capture, Assist and Lab parallel channels.
- Runtime questions in PostgreSQL.
- JSON seed/import/export.
- Playwright for web and Flutter integration for mobile.
- Google Workspace is downstream, not source of truth.
- Codex performs automated verification before human UAT.

## Open decisions that require evidence

| ID | Decision | Required evidence | Blocks |
|---|---|---|---|
| OD-001 | Exact target Android device | device inventory | field release only |
| OD-002 | Local host CPU/RAM/GPU | server inventory | local model choice |
| OD-003 | Default Whisper model | benchmark report | local provider production profile |
| OD-004 | Default provider/fallback | benchmark, cost, privacy | Assist field profile |
| OD-005 | Consent wording | owner/legal approval | real recording |
| OD-006 | Retention duration | policy approval | field production |
| OD-007 | Flutter web or React admin | first admin spike | admin implementation |
| OD-008 | Worker engine | load/reliability spike | production async processing |
| OD-009 | Object storage implementation | deployment environment | production storage |
| OD-010 | Exact Google auth model | account/environment decision | Google export |

## Stop behaviour

Codex must proceed with fake/test implementations where allowed. It must not fabricate evidence-dependent decisions.
