# Open Decision and Change Request Templates

## Open decision

```text
ID:
Sprint:
Question:
Why unresolved:
Options:
Evidence required:
Affected requirements:
Affected architecture:
Temporary test/fake approach:
Blocking scope:
Owner:
Decision date:
Decision:
```

## Change request

```text
ID:
Origin:
Requested change:
Reason:
Current documented behaviour:
Proposed behaviour:
Requirement impact:
Data impact:
API impact:
Security/privacy impact:
Test impact:
Sprint/release impact:
Decision: APPROVE / REJECT / DEFER
Approved by:
Documents updated:
```

## Rule

No conversation message alone changes the baseline. The change must be recorded and linked to the version history.
