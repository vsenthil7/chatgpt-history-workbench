# Build Report — UraiFlow SaaS V002 (Claude build)

**Input artifact:** `UraiFlow-SaaS_ChatGPT_V001_20260808_1318.zip`
**Product version:** 0.9.0-dev · **Python:** 3.12 (target ≥3.11) · **Runtime deps in `src/`:** none (stdlib only, guard-enforced)

## Backlog items
- B001 baseline acceptance + inventory: **completed** (`00-control/B001-BASELINE-ACCEPTANCE.md`).
- B002 slice declaration: **completed** (ADR-0001..0004, RTM-V002 SLICE-001..007).
- B003 tests-first, red→green: **completed** (evidence below).
- B004 evidence-producing CI: **partial** — evidence machine-generated; no CI pipeline definition yet; mutation deferred.
- B005 review package: **this ZIP**.

## Files added/changed (relative to V001 starter)
Added: `00-control/B001-BASELINE-ACCEPTANCE.md`, `00-control/BUILDER-EXECUTION-RULE.md`,
`02-architecture/adr/ADR-0001..0004`, `06-traceability/RTM-V002.md`,
`09-governance/CHANGE-RATIONALE-V002.md`, `src/uraiflow/**` (21 modules),
`tests/**` (6 test files), `scripts/gen_manifest.py`, `evidence/**`,
`pytest.ini`, `.coveragerc`, `BUILD-REPORT-V002.md`.
Changed: `07-planning/FIRST-BUILD-BACKLOG.md` (status appendix), `PACKAGE-MANIFEST.json` (regenerated, ADR-0003).
Untouched: everything under `10-baseline/`, all other starter docs, `scripts/validate_starter.py`.

## ADRs created
ADR-0001 proposal aggregate/state ownership · ADR-0002 work-object taxonomy owned by
receiving domain · ADR-0003 root manifest authority · ADR-0004 stack, reference
infrastructure, versioning.

## Gates executed — actual results
| Gate | Result | Evidence |
|---|---|---|
| G01 repository/manifest | PASS — starter validator PASS; `gen_manifest.py --check` PASS (175 files) | `evidence/G01-starter-validate.txt`, `evidence/G01-manifest-check.txt` |
| G02 formatting/lint/type | PARTIAL — `compileall` clean; no lint/type toolchain configured yet (V003/B004) | run log |
| G03 unit/domain | PASS — **59 passed, 0 failed** | `evidence/B003-green-tests-coverage.txt` |
| G04 coverage | PASS — **100% line + 100% branch**, enforced via `--cov-branch --cov-fail-under=100` | same file |
| G05 contract/integration | PASS — adapter contract harness + routing + provider-selection tests within the 59 | same file |
| G06 architecture | PASS — dependency-direction, tenant-token, hard-coded-tenant and stdlib-only guards | `tests/test_architecture_guards.py` |
| G07 mutation | **NOT-YET-IMPLEMENTED** — exception **EX-001**, deferred to V003 item 1 | this report |
| G08 security/tenant isolation | PASS — 7 cross-tenant denial tests (lineage, transcription, confirmation, commit, adapter rollback) | test files per RTM-V002 |
| G09 RTM | PASS — every ENFORCED row maps to named tests | `06-traceability/RTM-V002.md` |
| G10 docs consistency | PASS — counts in narrative docs reference generated evidence; manifests per ADR-0003 | evidence files |
| G11 packaging | PASS — zip built from clean tree; manifest verified before packaging | this ZIP |
| G12 independent review | PENDING — that is this handoff | — |

Red-state evidence (declared tests before implementation): `evidence/B003-red-state.txt`
(5 collection errors — `uraiflow` package absent, as declared).

## Assumptions and governed exclusions
- `# pragma: no cover - protocol signature` appears only on `Protocol` method bodies
  (`...`), which are structurally unexecutable; each is annotated in-source. No other
  coverage exclusions exist.
- Layering table in the architecture guard declares `transcription -> capture` as an
  allowed downstream dependency (the guard initially failed on it; declared, not
  bypassed — visible in the run history).
- The rule-based extractor is a deterministic stand-in scoped to the acceptance sample;
  LLM extraction is a future provider behind the same `Extractor` protocol.
- `FailingAdapter` and the registry swap in one test are test doubles/seams, not product code.

## Known failures / deferred
No failing tests. Deferred: mutation gate (EX-001); lint/type toolchain; persistence;
real providers; NEEDS_CLARIFICATION recovery loop; CI definition. See V003 backlog in
`07-planning/FIRST-BUILD-BACKLOG.md`.

## Exact next backlog item for V003
**V003-1: wire the mutation-testing gate (QA-002/G07), define its threshold, and triage
survivors on `proposal/model.py`, `confirmation/service.py`, `pipeline/orchestrator.py`
and `adapters/contract.py`.**

## For the independent reviewer (per `08-ai/CHATGPT-REVIEW-HANDOFF.md`)
Reproduce with: `pip install pytest pytest-cov` then, from repo root:
`PYTHONPATH=src python3 -m pytest --cov=src/uraiflow --cov-branch --cov-fail-under=100`
and `python3 scripts/validate_starter.py && python3 scripts/gen_manifest.py --check`.
Treat this report as claims to verify, not evidence to trust.
