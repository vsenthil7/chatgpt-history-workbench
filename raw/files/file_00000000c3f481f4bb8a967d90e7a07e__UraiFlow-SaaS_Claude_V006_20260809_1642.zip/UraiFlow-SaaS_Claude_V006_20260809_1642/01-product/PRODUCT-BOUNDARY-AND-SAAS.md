# Product Boundary and SaaS Model

## Boundary
Own reusable conversation/audio capture, transcript lineage, provider abstraction, extraction, candidate record graph/proposal, human confirmation, routing and target-system adapters.

## Not owned
Planning, capacity, HR, payroll, timesheet, CRM or tenant business rules. UraiFlow proposes records; owning domain services validate and commit them.

## Commercial/operating model
Products are reusable SaaS. IPBS is currently one tenant/user and may sell, support or implement the product. Other AT/WE companies and external customers may later become tenants, operators, implementation partners or channels. Product ownership and domain code therefore cannot be tied to IPBS.

## Tenant-neutral design
Use organisation/tenant configuration, policy, adapters and feature entitlements instead of customer-specific branches. A customer name may appear in pilot fixtures/docs, never as a reusable domain assumption.
