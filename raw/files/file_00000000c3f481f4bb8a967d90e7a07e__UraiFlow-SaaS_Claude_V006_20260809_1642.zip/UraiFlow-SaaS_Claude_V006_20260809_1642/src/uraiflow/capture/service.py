"""Capture stub for the first vertical slice (real audio ingestion is adapter work)."""
from uraiflow.capture.model import Capture
from uraiflow.core.clock import Clock
from uraiflow.core.ids import new_id
from uraiflow.core.tenancy import TenantContext
from uraiflow.lineage.model import LineageEvent
from uraiflow.lineage.store import LineageStore


class CaptureService:
    """Records a capture aggregate plus its lineage event."""

    def __init__(self, lineage: LineageStore, clock: Clock) -> None:
        self._lineage = lineage
        self._clock = clock

    def capture(
        self,
        ctx: TenantContext,
        source_ref: str,
        content: str,
        media_type: str = "audio/opus",
    ) -> Capture:
        if not content.strip():
            raise ValueError("capture content must be non-empty")
        cap = Capture(
            capture_id=new_id("cap"),
            tenant_id=ctx.tenant_id,
            source_ref=source_ref,
            media_type=media_type,
            content=content,
            captured_at=self._clock.now(),
        )
        self._lineage.append(
            ctx,
            LineageEvent(
                event_id=new_id("evt"),
                tenant_id=ctx.tenant_id,
                subject_id=cap.capture_id,
                kind="capture.recorded",
                payload={"source_ref": source_ref, "media_type": media_type},
                occurred_at=cap.captured_at,
            ),
        )
        return cap
