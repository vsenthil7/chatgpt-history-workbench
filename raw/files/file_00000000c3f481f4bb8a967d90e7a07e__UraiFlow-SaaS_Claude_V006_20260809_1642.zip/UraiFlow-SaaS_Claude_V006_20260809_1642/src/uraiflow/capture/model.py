"""Capture aggregate — the recorded conversation evidence."""
from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class Capture:
    """A captured conversation/audio artifact owned by a tenant."""

    capture_id: str
    tenant_id: str
    source_ref: str
    media_type: str
    content: str
    captured_at: datetime
