"""UraiFlow — reusable conversation-to-structured-action SaaS core.

Boundary: UraiFlow proposes; the owning domain validates and commits.
"""
__version__ = "0.9.0-dev"
