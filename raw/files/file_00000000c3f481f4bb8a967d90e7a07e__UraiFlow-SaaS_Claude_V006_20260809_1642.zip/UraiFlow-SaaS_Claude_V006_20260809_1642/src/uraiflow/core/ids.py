"""Opaque, prefix-tagged identifiers."""
import uuid


def new_id(prefix: str) -> str:
    """Return a new globally unique id such as ``cap-3f2a…``."""
    return f"{prefix}-{uuid.uuid4().hex}"
