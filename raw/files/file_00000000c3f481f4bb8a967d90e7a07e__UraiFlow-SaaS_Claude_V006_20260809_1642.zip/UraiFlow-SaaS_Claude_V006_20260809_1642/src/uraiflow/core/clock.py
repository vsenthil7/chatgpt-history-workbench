"""Injectable clock so domain code never depends on the real wall clock in tests."""
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol


class Clock(Protocol):
    """Time source contract."""

    def now(self) -> datetime:  # pragma: no cover - protocol signature
        ...


class SystemClock:
    """Production clock: timezone-aware UTC now."""

    def now(self) -> datetime:
        return datetime.now(UTC)


@dataclass
class FixedClock:
    """Deterministic clock for tests; advances only via :meth:`tick`."""

    current: datetime

    def now(self) -> datetime:
        return self.current

    def tick(self, seconds: int = 1) -> datetime:
        self.current = self.current + timedelta(seconds=seconds)
        return self.current
