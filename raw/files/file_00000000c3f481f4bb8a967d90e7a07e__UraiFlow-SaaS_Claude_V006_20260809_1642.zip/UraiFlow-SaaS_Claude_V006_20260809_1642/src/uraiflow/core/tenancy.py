"""Explicit tenant/organisation context for protected operations (SaaS-002).

ADR-0014: ``TenantContext`` is a security principal. Its identifiers are
canonicalised to exact built-in ``str`` at construction (hostile subclasses
rejected before any of their methods run), and every protected operation must
receive an exact ``TenantContext`` — duck-typed impostors are rejected.
"""
from dataclasses import dataclass

from uraiflow.core.errors import TenantIsolationError
from uraiflow.core.primitives import canonical_identifier, require_exact_type


@dataclass(frozen=True)
class TenantContext:
    """Identifies the tenant and acting principal for a protected operation."""

    tenant_id: str
    actor_id: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "tenant_id",
            canonical_identifier(self.tenant_id, field="tenant_id"),
        )
        object.__setattr__(
            self, "actor_id",
            canonical_identifier(self.actor_id, field="actor_id"),
        )


def require_context(ctx: object) -> TenantContext:
    """Admit only an exact ``TenantContext`` at a protected boundary."""
    require_exact_type(ctx, TenantContext, boundary="protected operation")
    assert isinstance(ctx, TenantContext)  # for the type checker; proven above
    return ctx


def require_same_tenant(ctx: TenantContext, tenant_id: str, subject: str) -> None:
    """Deny any cross-tenant access to *subject* (raises TenantIsolationError).

    Both sides of the comparison are canonical exact strings: ``ctx`` is
    admitted via :func:`require_context` (its fields were canonicalised at
    construction) and *tenant_id* is canonicalised here, so no
    attacker-controlled ``__eq__``/``__ne__`` participates in the decision.
    """
    require_context(ctx)
    tenant = canonical_identifier(tenant_id, field="tenant_id")
    if ctx.tenant_id != tenant:
        raise TenantIsolationError(
            f"tenant '{ctx.tenant_id}' may not access {subject} of another tenant"
        )
