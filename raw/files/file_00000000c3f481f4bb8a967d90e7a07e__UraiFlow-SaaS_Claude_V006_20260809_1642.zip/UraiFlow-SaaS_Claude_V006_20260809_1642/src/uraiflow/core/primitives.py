"""Canonical exact-type primitives at trust boundaries (ADR-0014).

The V004 independent review demonstrated that identifier comparison, hashing
and set membership can be spoofed by hostile ``str`` subclasses overriding
``__eq__``/``__ne__``/``__hash__``/``strip``. Every identity value that
participates in a security-relevant decision (tenant isolation, adapter
resolution, receipt binding, operator authorisation, lineage scoping) must
therefore be canonicalised to an EXACT built-in ``str`` before it is stored or
compared — subclasses are rejected outright, benign or not, because
"benign" cannot be established from inside the type.

The exact-type test uses ``type(value) is str`` and runs BEFORE any method of
the incoming object is invoked, so a hostile object gets no code execution on
the comparison path.
"""
from uraiflow.core.errors import TrustBoundaryViolation


def canonical_identifier(value: object, *, field: str) -> str:
    """Return *value* as a canonical plain ``str`` identifier.

    Raises :class:`TrustBoundaryViolation` when *value* is not an exact
    built-in ``str`` (subclasses included) or is empty/whitespace-only.
    The returned value is whitespace-stripped and guaranteed to be of exact
    type ``str``, safe for ``==``, ``hash()`` and dict/set membership.
    """
    if type(value) is not str:  # exact type; NEVER isinstance (ADR-0014 §2)
        raise TrustBoundaryViolation(
            f"{field} must be an exact built-in str; got "
            f"{type(value).__name__} (str subclasses are rejected at trust "
            f"boundaries)"
        )
    cleaned = value.strip()
    if not cleaned:
        raise TrustBoundaryViolation(f"{field} must be a non-empty identifier")
    return cleaned


def require_exact_type(value: object, expected: type, *, boundary: str) -> None:
    """Reject objects that are not exactly *expected* at a trust boundary.

    Duck-typed impostors (and subclasses) of security-bearing structures such
    as ``TenantContext`` or ``CommitReceipt`` must not be accepted where the
    genuine, canonicalising type is required.
    """
    if type(value) is not expected:
        raise TrustBoundaryViolation(
            f"{boundary} requires an exact {expected.__name__}; got "
            f"{type(value).__name__}"
        )
