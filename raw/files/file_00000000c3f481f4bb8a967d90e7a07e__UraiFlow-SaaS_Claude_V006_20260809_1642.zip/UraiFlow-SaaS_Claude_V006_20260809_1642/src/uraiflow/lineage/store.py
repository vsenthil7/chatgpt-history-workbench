"""Append-only, tenant-scoped lineage store (in-memory reference, ADR-0004)."""
from uraiflow.core.primitives import canonical_identifier, require_exact_type
from uraiflow.core.tenancy import TenantContext, require_context, require_same_tenant
from uraiflow.lineage.model import LineageEvent


class LineageStore:
    """Reference lineage store; every read/write carries explicit tenant context."""

    def __init__(self) -> None:
        self._events: list[LineageEvent] = []

    def append(self, ctx: TenantContext, event: LineageEvent) -> LineageEvent:
        # ADR-0014 (P1-1): only an exact LineageEvent (whose identity fields
        # were canonicalised at construction) may be stored — a duck-typed
        # impostor with a hostile subject_id cannot be appended.
        require_exact_type(event, LineageEvent, boundary="lineage append")
        require_same_tenant(ctx, event.tenant_id, "lineage event")
        self._events.append(event)
        return event

    def for_subject(self, ctx: TenantContext, subject_id: str) -> tuple[LineageEvent, ...]:
        require_context(ctx)  # ADR-0014: reads are protected operations too
        subject_id = canonical_identifier(subject_id, field="subject_id")
        return tuple(
            e
            for e in self._events
            if e.tenant_id == ctx.tenant_id and e.subject_id == subject_id
        )

    def all_for_tenant(self, ctx: TenantContext) -> tuple[LineageEvent, ...]:
        require_context(ctx)  # ADR-0014
        return tuple(e for e in self._events if e.tenant_id == ctx.tenant_id)
