"""Human confirmation: thin service — tenant checks, delegation to aggregate
commands (ADR-0006), lineage evidence. Never auto-commits."""
from collections.abc import Iterable, Mapping
from typing import Any

from uraiflow.core.clock import Clock
from uraiflow.core.ids import new_id
from uraiflow.core.tenancy import TenantContext, require_same_tenant
from uraiflow.lineage.model import LineageEvent
from uraiflow.lineage.store import LineageStore
from uraiflow.proposal.model import Proposal


class ConfirmationService:
    """Applies human decisions via aggregate commands and records lineage."""

    def __init__(self, lineage: LineageStore, clock: Clock) -> None:
        self._lineage = lineage
        self._clock = clock

    def confirm_all(self, ctx: TenantContext, proposal: Proposal) -> None:
        require_same_tenant(ctx, proposal.tenant_id, "proposal")
        proposal.confirm_all()
        self._decision_event(ctx, proposal)

    def confirm_selected(
        self, ctx: TenantContext, proposal: Proposal, record_ids: Iterable[str]
    ) -> None:
        require_same_tenant(ctx, proposal.tenant_id, "proposal")
        proposal.confirm_selected(record_ids)
        self._decision_event(ctx, proposal)

    def reject_all(self, ctx: TenantContext, proposal: Proposal) -> None:
        require_same_tenant(ctx, proposal.tenant_id, "proposal")
        proposal.reject_all()
        self._decision_event(ctx, proposal)

    def edit(
        self,
        ctx: TenantContext,
        proposal: Proposal,
        record_id: str,
        fields: Mapping[str, Any],
    ) -> None:
        require_same_tenant(ctx, proposal.tenant_id, "proposal")
        proposal.edit_item(record_id, fields)
        self._event(ctx, proposal, "proposal.item_edited", {"record_id": record_id})

    def _decision_event(self, ctx: TenantContext, proposal: Proposal) -> None:
        confirmed = len(proposal.confirmed_items())
        self._event(
            ctx,
            proposal,
            f"proposal.{proposal.status.value.lower()}",
            {"confirmed": confirmed, "total": len(proposal.items), "actor": ctx.actor_id},
        )

    def _event(
        self, ctx: TenantContext, proposal: Proposal, kind: str, payload: Mapping[str, Any]
    ) -> None:
        self._lineage.append(
            ctx,
            LineageEvent(
                event_id=new_id("evt"),
                tenant_id=ctx.tenant_id,
                subject_id=proposal.proposal_id,
                kind=kind,
                payload=payload,
                occurred_at=self._clock.now(),
            ),
        )
