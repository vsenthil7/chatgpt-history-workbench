"""Reference in-memory target adapter (ADR-0004): tenant-isolated, idempotent."""
from collections.abc import Mapping
from typing import Any

from uraiflow.adapters.contract import (
    AdapterDescriptor,
    CommitReceipt,
    ValidationResult,
    standard_validate,
)
from uraiflow.core.errors import AdapterContractError, TenantIsolationError
from uraiflow.core.ids import new_id
from uraiflow.core.tenancy import TenantContext
from uraiflow.extraction.model import CandidateRecord


class InMemoryTargetAdapter:
    """Deterministic reference implementation of the target-system contract."""

    def __init__(
        self,
        name: str,
        schema_version: str,
        required_fields: Mapping[str, tuple[str, ...]],
        supports_rollback: bool = True,
        adapter_id: str | None = None,
    ) -> None:
        # Reference-adapter convenience only: the machine identity defaults to
        # the display name. Registry uniqueness is enforced on adapter_id, so
        # two default-identity adapters with the same name are rejected
        # (fail-safe); production adapters must set adapter_id explicitly
        # (ADR-0010).
        self._descriptor = AdapterDescriptor(
            adapter_id=adapter_id if adapter_id is not None else name,
            name=name,
            schema_version=schema_version,
            accepted_record_types=tuple(required_fields),
            required_fields=dict(required_fields),
            supports_rollback=supports_rollback,
        )
        self._committed: dict[tuple[str, str], tuple[CommitReceipt, CandidateRecord]] = {}

    def descriptor(self) -> AdapterDescriptor:
        return self._descriptor

    def validate(self, record: CandidateRecord) -> ValidationResult:
        return standard_validate(self._descriptor, record)

    def preview(self, ctx: TenantContext, record: CandidateRecord) -> Mapping[str, Any]:
        return {
            "adapter": self._descriptor.name,
            "tenant_id": ctx.tenant_id,
            "record_type": record.record_type,
            "fields": dict(record.fields),
        }

    def commit(
        self, ctx: TenantContext, record: CandidateRecord, idempotency_key: str
    ) -> CommitReceipt:
        key = (ctx.tenant_id, idempotency_key)
        if key in self._committed:
            return self._committed[key][0]
        result = self.validate(record)
        if not result.ok:
            raise AdapterContractError(
                f"adapter '{self._descriptor.name}' rejected record "
                f"'{record.record_id}': {'; '.join(result.errors)}"
            )
        receipt = CommitReceipt(
            receipt_id=new_id("rcpt"),
            adapter_id=self._descriptor.adapter_id,
            adapter_name=self._descriptor.name,
            tenant_id=ctx.tenant_id,
            record_id=record.record_id,
            idempotency_key=idempotency_key,
            target_ref=f"{self._descriptor.name}/{new_id('row')}",
        )
        self._committed[key] = (receipt, record)
        return receipt

    def rollback(self, ctx: TenantContext, receipt: CommitReceipt) -> None:
        if not self._descriptor.supports_rollback:
            raise AdapterContractError(
                f"adapter '{self._descriptor.name}' does not support rollback"
            )
        if receipt.tenant_id != ctx.tenant_id:
            raise TenantIsolationError(
                f"tenant '{ctx.tenant_id}' may not roll back another tenant's commit"
            )
        key = (ctx.tenant_id, receipt.idempotency_key)
        if key not in self._committed:
            raise AdapterContractError(
                f"no committed record for idempotency key '{receipt.idempotency_key}'"
            )
        del self._committed[key]

    # Inspection helpers for tests/evidence (not part of the adapter contract).
    def committed_count(self, ctx: TenantContext) -> int:
        return sum(1 for (tenant, _) in self._committed if tenant == ctx.tenant_id)

    def stored_record(self, ctx: TenantContext, idempotency_key: str) -> CandidateRecord:
        return self._committed[(ctx.tenant_id, idempotency_key)][1]
