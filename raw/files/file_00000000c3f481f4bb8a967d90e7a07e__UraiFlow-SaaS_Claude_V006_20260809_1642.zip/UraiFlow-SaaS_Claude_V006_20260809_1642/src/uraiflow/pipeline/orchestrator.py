"""Vertical-slice orchestrator: capture -> transcript -> proposal -> commit.

UraiFlow proposes; confirmation is human; commit goes through adapter contracts.
ADR-0007 hardening: rollback-capability preflight before multi-record commits,
adapter-boundary exception normalisation (any ``Exception`` is compensated, never
hidden — it is preserved verbatim in outcome and lineage), and compensation as a
governed phase that only claims ROLLED_BACK when every rollback succeeded.
"""
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from uraiflow.adapters.contract import (
    CommitReceipt,
    validate_commit_receipt,
)
from uraiflow.capture.service import CaptureService
from uraiflow.core.clock import Clock
from uraiflow.core.errors import AdapterContractError, InvalidTransitionError
from uraiflow.core.ids import new_id
from uraiflow.core.tenancy import TenantContext, require_context, require_same_tenant
from uraiflow.extraction.rules import Extractor
from uraiflow.lineage.model import LineageEvent
from uraiflow.lineage.store import LineageStore
from uraiflow.proposal.model import Proposal, ProposalItem, ProposalStatus
from uraiflow.routing.registry import AdapterRegistry
from uraiflow.transcription.selector import ProviderSelector
from uraiflow.transcription.service import TranscriptionService


@dataclass(frozen=True)
class UncertainCommit:
    """ADR-0017 (V006 P0-1): an operation whose external side effect MAY have
    occurred but whose receipt could not be trusted (invalid receipt).

    Built entirely from TRUSTED request-side data — never from the untrusted
    receipt — so recovery has a reliable working set. Its presence blocks the
    clean ROLLED_BACK state: the possibly-committed external effect must be
    reconciled by an operator.
    """

    adapter_id: str
    adapter_name: str
    tenant_id: str
    record_id: str
    idempotency_key: str
    reason: str


@dataclass(frozen=True)
class CompensationReport:
    """ADR-0013 §2: structured record of a compensation phase.

    Operator recovery consumes ``unrecovered_receipts`` and
    ``uncertain_commits`` directly; it never reconstructs the working set from
    lineage text.
    """

    original_failure: str
    committed_receipts: tuple[CommitReceipt, ...]
    compensated_receipts: tuple[CommitReceipt, ...]
    unrecovered_receipts: tuple[CommitReceipt, ...]
    rollback_failures: tuple[str, ...]
    contract_violations: tuple[str, ...]
    uncertain_commits: tuple[UncertainCommit, ...] = ()


@dataclass(frozen=True)
class CommitOutcome:
    """Result of an atomic commit attempt across adapters."""

    receipts: tuple[CommitReceipt, ...]
    failure: str | None
    compensation_failures: tuple[str, ...] = ()
    recovery: CompensationReport | None = None


def _describe(adapter_name: str, error: Exception) -> str:
    """ADR-0007 §1 normalisation: preserve the original error verbatim."""
    return f"{adapter_name}: {type(error).__name__}: {error}"


class ConversationToActionPipeline:
    """Wires the first production-grade slice behind one orchestration surface."""

    def __init__(
        self,
        selector: ProviderSelector,
        extractor: Extractor,
        registry: AdapterRegistry,
        lineage: LineageStore,
        clock: Clock,
    ) -> None:
        self.clock = clock
        self._lineage = lineage
        self._capture = CaptureService(lineage=lineage, clock=clock)
        self._transcription = TranscriptionService(
            selector=selector, lineage=lineage, clock=clock
        )
        self._extractor = extractor
        self._registry = registry

    # -- ingest: capture -> transcript -> extraction -> routed/validated proposal --

    def ingest(self, ctx: TenantContext, source_ref: str, content: str) -> Proposal:
        require_context(ctx)  # ADR-0014: no tenant comparison happens here
        capture = self._capture.capture(ctx, source_ref=source_ref, content=content)
        transcript = self._transcription.transcribe(ctx, capture)
        candidates = self._extractor.extract(transcript.text)
        proposal = Proposal(
            proposal_id=new_id("prop"),
            tenant_id=ctx.tenant_id,
            capture_id=capture.capture_id,
            transcript_id=transcript.transcript_id,
            items=[ProposalItem.from_candidate(c) for c in candidates],
        )
        self._event(
            ctx,
            proposal,
            "proposal.created",
            {
                "capture_id": capture.capture_id,
                "transcript_id": transcript.transcript_id,
                "item_count": len(proposal.items),
            },
        )
        proposal.advance(ProposalStatus.ROUTED)
        if not proposal.items:
            proposal.advance(ProposalStatus.NEEDS_CLARIFICATION)
            self._event(
                ctx, proposal, "proposal.needs_clarification", {"reason": "no candidates"}
            )
            return proposal
        self._event(
            ctx,
            proposal,
            "proposal.routed",
            {"record_types": sorted({i.record_type for i in proposal.items})},
        )
        invalid = self._validate_items(proposal)
        if invalid:
            proposal.advance(ProposalStatus.NEEDS_CLARIFICATION)
            self._event(
                ctx,
                proposal,
                "proposal.needs_clarification",
                {"reason": "validation errors", "invalid_items": invalid},
            )
            return proposal
        proposal.advance(ProposalStatus.VALIDATED)
        self._event(ctx, proposal, "proposal.validated", {"item_count": len(proposal.items)})
        proposal.advance(ProposalStatus.AWAITING_CONFIRMATION)
        return proposal

    # -- revalidation after human edits (ADR-0006 §4) --

    def revalidate(self, ctx: TenantContext, proposal: Proposal) -> None:
        require_same_tenant(ctx, proposal.tenant_id, "proposal")
        invalid = self._validate_items(proposal)
        self._event(
            ctx, proposal, "proposal.revalidated", {"invalid_items": invalid}
        )

    def _validate_items(self, proposal: Proposal) -> int:
        results: dict[str, tuple[str, ...]] = {}
        invalid = 0
        for item in proposal.items:
            adapter = self._registry.resolve(item.record_type)
            result = adapter.adapter.validate(item.as_candidate())
            results[item.record_id] = result.errors
            if not result.ok:
                invalid += 1
        proposal.apply_validation(results)
        return invalid

    # -- commit: confirmed items -> adapters, atomically with governed compensation --

    def commit(self, ctx: TenantContext, proposal: Proposal) -> CommitOutcome:
        require_same_tenant(ctx, proposal.tenant_id, "proposal")
        if proposal.status not in (
            ProposalStatus.CONFIRMED,
            ProposalStatus.PARTIALLY_CONFIRMED,
        ):
            raise InvalidTransitionError(
                f"proposal {proposal.proposal_id} is {proposal.status.value}; "
                "only confirmed proposals can be committed"
            )
        items = proposal.confirmed_items()
        self._preflight_rollback_capability(ctx, proposal, items)
        proposal.advance(ProposalStatus.COMMITTING)
        committed: list[CommitReceipt] = []
        contract_violations: list[str] = []
        uncertain: list[UncertainCommit] = []
        failure: str | None = None
        for item in items:
            registered = self._registry.resolve(item.record_type)
            adapter = registered.adapter
            descriptor = registered.descriptor  # PINNED at registration (ADR-0016)
            candidate = item.as_candidate()
            idempotency_key = f"{proposal.proposal_id}:{item.record_id}"
            try:
                receipt = adapter.commit(
                    ctx, candidate, idempotency_key=idempotency_key
                )
            except Exception as error:  # noqa: BLE001 - ADR-0007 §1 adapter boundary
                failure = _describe(descriptor.name, error)
                break
            try:
                # ADR-0010 §3: the returned receipt is untrusted until bound to
                # the invoked adapter, tenant, record and idempotency key. A
                # mismatch is an adapter contract failure entering the same
                # governed compensation path as a failed commit.
                validate_commit_receipt(
                    descriptor, ctx, candidate, idempotency_key, receipt
                )
            except AdapterContractError as error:
                failure = _describe(descriptor.name, error)
                contract_violations.append(failure)
                # ADR-0017 (V006 P0-1): the adapter.commit() call already
                # returned, so the external side effect MAY have occurred, but
                # the receipt cannot be trusted to drive rollback. Record an
                # UncertainCommit from TRUSTED request-side data (the invoked
                # adapter identity, tenant, record and idempotency key) so the
                # aggregate can never falsely claim ROLLED_BACK: an unreconciled
                # uncertain commit forces COMPENSATION_FAILED / recovery.
                uncertain.append(
                    UncertainCommit(
                        adapter_id=descriptor.adapter_id,
                        adapter_name=descriptor.name,
                        tenant_id=ctx.tenant_id,
                        record_id=item.record_id,
                        idempotency_key=idempotency_key,
                        reason=failure,
                    )
                )
                self._event(
                    ctx,
                    proposal,
                    "record.commit_receipt_invalid",
                    {"record_id": item.record_id, "error": failure,
                     "external_effect": "uncertain"},
                )
                break
            committed.append(receipt)
            self._event(
                ctx,
                proposal,
                "record.committed",
                {
                    "record_id": item.record_id,
                    "adapter": receipt.adapter_name,
                    "target_ref": receipt.target_ref,
                },
            )
        if failure is None:
            proposal.advance(ProposalStatus.COMMITTED)
            self._event(ctx, proposal, "proposal.committed", {"receipts": len(committed)})
            return CommitOutcome(receipts=tuple(committed), failure=None)
        proposal.advance(ProposalStatus.COMMIT_FAILED)
        self._event(ctx, proposal, "proposal.commit_failed", {"error": failure})
        compensated, unrecovered, rollback_failures = self._compensate(
            ctx, proposal, committed
        )
        report = CompensationReport(
            original_failure=failure,
            committed_receipts=tuple(committed),
            compensated_receipts=compensated,
            unrecovered_receipts=unrecovered,
            rollback_failures=rollback_failures,
            contract_violations=tuple(contract_violations),
            uncertain_commits=tuple(uncertain),
        )
        # ADR-0017: an uncertain commit (invalid receipt after a possible side
        # effect) is unreconciled evidence; like a rollback failure it BLOCKS
        # the clean ROLLED_BACK state and routes to COMPENSATION_FAILED so an
        # operator must reconcile the possibly-committed external effect.
        if rollback_failures or uncertain:
            proposal.advance(ProposalStatus.COMPENSATION_FAILED)
            proposal.record_unrecovered(unrecovered)
            proposal.record_uncertain(tuple(uncertain))
            self._event(
                ctx,
                proposal,
                "proposal.compensation_failed",
                {
                    "unrecovered": len(unrecovered),
                    "unrecovered_receipt_ids": [r.receipt_id for r in unrecovered],
                    "uncertain_commits": [u.record_id for u in uncertain],
                },
            )
        else:
            proposal.advance(ProposalStatus.ROLLED_BACK)
            self._event(
                ctx, proposal, "proposal.rolled_back", {"compensated": len(committed)}
            )
        return CommitOutcome(
            receipts=(),
            failure=failure,
            compensation_failures=rollback_failures,
            recovery=report,
        )

    def _preflight_rollback_capability(
        self,
        ctx: TenantContext,
        proposal: Proposal,
        items: tuple[ProposalItem, ...],
    ) -> None:
        """ADR-0007 §3: multi-record atomicity requires compensable adapters."""
        if len(items) <= 1:
            return
        # Use PINNED descriptors (ADR-0016): rollback-capability is decided from
        # the registration-time descriptor, not a re-read one.
        registered_by_name: dict[str, bool] = {}
        for item in items:
            registered = self._registry.resolve(item.record_type)
            registered_by_name[registered.descriptor.name] = (
                registered.descriptor.supports_rollback
            )
        incapable = sorted(
            name for name, supports in registered_by_name.items() if not supports
        )
        if incapable:
            self._event(
                ctx,
                proposal,
                "proposal.commit_preflight_failed",
                {"adapters_without_rollback": incapable},
            )
            raise AdapterContractError(
                f"atomic multi-record commit requires rollback support; "
                f"adapters without it: {incapable}"
            )

    def _compensate(
        self, ctx: TenantContext, proposal: Proposal, receipts: list[CommitReceipt]
    ) -> tuple[
        tuple[CommitReceipt, ...], tuple[CommitReceipt, ...], tuple[str, ...]
    ]:
        """ADR-0007 §2 / ADR-0013: attempt every rollback; return structured
        (compensated, unrecovered, failures). ADR-0010: each receipt resolves
        back to the exact adapter machine identity that produced it."""
        proposal.advance(ProposalStatus.COMPENSATING)
        self._event(ctx, proposal, "proposal.compensating", {"to_compensate": len(receipts)})
        failures: list[str] = []
        compensated: list[CommitReceipt] = []
        unrecovered: list[CommitReceipt] = []
        for receipt in reversed(receipts):
            try:
                registered = self._registry.resolve_by_id(receipt.adapter_id)
                registered.adapter.rollback(ctx, receipt)
            except Exception as error:  # noqa: BLE001 - ADR-0007 §2 adapter boundary
                failures.append(_describe(receipt.adapter_name, error))
                unrecovered.append(receipt)
                self._event(
                    ctx,
                    proposal,
                    "record.rollback_failed",
                    {"record_id": receipt.record_id, "error": _describe(receipt.adapter_name, error)},
                )
                continue
            compensated.append(receipt)
            self._event(
                ctx,
                proposal,
                "record.rolled_back",
                {"record_id": receipt.record_id, "adapter": receipt.adapter_id},
            )
        return tuple(compensated), tuple(unrecovered), tuple(failures)

    def _event(
        self,
        ctx: TenantContext,
        proposal: Proposal,
        kind: str,
        payload: Mapping[str, Any],
    ) -> None:
        self._lineage.append(
            ctx,
            LineageEvent(
                event_id=new_id("evt"),
                tenant_id=ctx.tenant_id,
                subject_id=proposal.proposal_id,
                kind=kind,
                payload=payload,
                occurred_at=self.clock.now(),
            ),
        )
