"""Generic, configuration-driven extraction engine (ADR-0005).

The engine ships no record types, field names, phrases or vocabulary; rules and
number-word maps are constructor data supplied from outside reusable core
(tenant/product configuration, plugins or fixtures).
"""
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Protocol

from uraiflow.core.ids import new_id
from uraiflow.extraction.model import CandidateRecord

_GROUP_PREFIX = "group:"


@dataclass(frozen=True)
class FieldSpec:
    """Maps a value source onto a candidate-record field.

    ``source`` is ``"text"`` (whole matched text, stripped) or ``"group:<name>"``
    (a named regex group). ``transform`` is ``"str"`` or ``"int"``.
    """

    name: str
    source: str
    transform: str = field(default="str")


@dataclass(frozen=True)
class ExtractionRule:
    """One configurable rule: pattern -> candidate record of an opaque type."""

    record_type: str
    pattern: str
    confidence: float
    fields: tuple[FieldSpec, ...]


class Extractor(Protocol):
    """Contract for extraction implementations."""

    def extract(self, text: str) -> tuple[CandidateRecord, ...]:  # pragma: no cover - protocol signature
        ...


class ConfigurableRuleExtractor:
    """Deterministic rule engine; all semantics come from the supplied rules."""

    def __init__(
        self,
        rules: Sequence[ExtractionRule],
        number_words: Mapping[str, int] | None = None,
    ) -> None:
        self._rules = tuple(
            (rule, re.compile(rule.pattern, re.IGNORECASE)) for rule in rules
        )
        self._number_words = dict(number_words) if number_words is not None else {}

    def extract(self, text: str) -> tuple[CandidateRecord, ...]:
        records: list[CandidateRecord] = []
        for rule, pattern in self._rules:
            match = pattern.search(text)
            if not match:
                continue
            fields = self._build_fields(rule, match, text)
            if fields is None:
                continue
            records.append(
                CandidateRecord(
                    record_id=new_id("rec"),
                    record_type=rule.record_type,
                    fields=fields,
                    confidence=rule.confidence,
                    source_text=match.group(0) if rule.fields and all(
                        spec.source != "text" for spec in rule.fields
                    ) else text.strip(),
                )
            )
        return tuple(records)

    def _build_fields(
        self, rule: ExtractionRule, match: re.Match[str], text: str
    ) -> dict[str, object] | None:
        fields: dict[str, object] = {}
        for spec in rule.fields:
            if spec.source == "text":
                raw = text.strip()
            elif spec.source.startswith(_GROUP_PREFIX):
                raw = match.group(spec.source[len(_GROUP_PREFIX):])
            else:
                raise ValueError(
                    f"field '{spec.name}': unknown source '{spec.source}'"
                )
            if spec.transform == "int":
                value = self._to_int(raw)
                if value is None:
                    return None  # rule unresolvable for this text
                fields[spec.name] = value
            else:
                fields[spec.name] = raw
        return fields

    def _to_int(self, raw: str) -> int | None:
        lowered = raw.lower()
        if lowered.isdigit():
            return int(lowered)
        return self._number_words.get(lowered)
