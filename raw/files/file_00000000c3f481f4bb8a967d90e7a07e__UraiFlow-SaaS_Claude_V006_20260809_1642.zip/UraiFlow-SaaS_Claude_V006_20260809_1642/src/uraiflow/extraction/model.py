"""Candidate records: UraiFlow's generic proposal payload (ADR-0002)."""
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from uraiflow.core.primitives import canonical_identifier


@dataclass(frozen=True)
class CandidateRecord:
    """A domain-neutral candidate record extracted from a transcript.

    ``record_type`` is an opaque string; UraiFlow ships no domain taxonomy.
    """

    record_id: str
    record_type: str
    fields: Mapping[str, Any]
    confidence: float
    source_text: str

    def __post_init__(self) -> None:
        """ADR-0014: routing identities are canonical exact strings."""
        object.__setattr__(
            self, "record_id",
            canonical_identifier(self.record_id, field="record_id"),
        )
        object.__setattr__(
            self, "record_type",
            canonical_identifier(self.record_type, field="record_type"),
        )
