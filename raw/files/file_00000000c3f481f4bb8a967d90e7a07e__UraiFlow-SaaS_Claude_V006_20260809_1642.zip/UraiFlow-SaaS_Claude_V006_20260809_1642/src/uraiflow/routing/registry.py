"""Record-type -> adapter routing table (baseline doc 49, step 8 of the pipeline).

ADR-0010: adapter machine identity (``adapter_id``) is globally unambiguous
within a registry; registration is atomic; compensation resolution binds to
exact machine identity only. Display names never affect routing or rollback.

ADR-0016 (V006): the descriptor validated at registration is PINNED. Every
later operation uses the pinned descriptor, never a freshly re-read
``adapter.descriptor()``, so an adapter cannot drift its identity/capabilities
after registration to obtain a trusted receipt for an unregistered identity.
"""
from dataclasses import dataclass

from uraiflow.adapters.contract import (
    AdapterDescriptor,
    TargetSystemAdapter,
    validate_descriptor,
)
from uraiflow.core.errors import RoutingError
from uraiflow.core.primitives import canonical_identifier


@dataclass(frozen=True)
class RegisteredAdapter:
    """An adapter plus the immutable descriptor validated at registration.

    Callers MUST use ``descriptor`` (pinned) for identity, routing, receipt
    binding and rollback-capability decisions, and ``adapter`` only to invoke
    ``commit``/``rollback``. The adapter object's own ``descriptor()`` is never
    trusted again after registration (ADR-0016).
    """

    adapter: TargetSystemAdapter
    descriptor: AdapterDescriptor


class AdapterRegistry:
    """Maps record types and machine identities to registered adapters."""

    def __init__(self) -> None:
        self._routes: dict[str, RegisteredAdapter] = {}
        self._by_id: dict[str, RegisteredAdapter] = {}

    def register(self, adapter: TargetSystemAdapter) -> None:
        """Atomically register *adapter*: all invariants are checked before any
        state is mutated, so a rejected adapter leaves the registry untouched.
        The descriptor read here is validated and PINNED (ADR-0016)."""
        descriptor = adapter.descriptor()
        validate_descriptor(descriptor)
        if descriptor.adapter_id in self._by_id:
            raise RoutingError(
                f"adapter identity '{descriptor.adapter_id}' is already registered"
            )
        for record_type in descriptor.accepted_record_types:
            if record_type in self._routes:
                raise RoutingError(
                    f"record type '{record_type}' already routed to adapter "
                    f"'{self._routes[record_type].descriptor.adapter_id}'"
                )
        registered = RegisteredAdapter(adapter=adapter, descriptor=descriptor)
        self._by_id[descriptor.adapter_id] = registered
        for record_type in descriptor.accepted_record_types:
            self._routes[record_type] = registered

    def resolve(self, record_type: str) -> RegisteredAdapter:
        if record_type not in self._routes:
            raise RoutingError(f"no adapter accepts record type '{record_type}'")
        return self._routes[record_type]

    def resolve_by_id(self, adapter_id: str) -> RegisteredAdapter:
        """Resolve by exact machine identity (the only identity compensation
        may use; ADR-0010). Returns the pinned registration record."""
        adapter_id = canonical_identifier(adapter_id, field="adapter_id")  # ADR-0014
        if adapter_id not in self._by_id:
            raise RoutingError(f"no registered adapter with identity '{adapter_id}'")
        return self._by_id[adapter_id]
