"""Operator recovery for failed compensation (ADR-0013)."""
