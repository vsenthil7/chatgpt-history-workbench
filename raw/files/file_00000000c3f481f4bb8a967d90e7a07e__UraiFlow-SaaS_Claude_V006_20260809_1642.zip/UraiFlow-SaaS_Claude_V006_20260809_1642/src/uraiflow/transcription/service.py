"""Transcription service: capture -> transcript through the provider abstraction."""
from uraiflow.capture.model import Capture
from uraiflow.core.clock import Clock
from uraiflow.core.ids import new_id
from uraiflow.core.tenancy import TenantContext, require_same_tenant
from uraiflow.lineage.model import LineageEvent
from uraiflow.lineage.store import LineageStore
from uraiflow.transcription.model import Transcript
from uraiflow.transcription.provider import TranscriptionRequest
from uraiflow.transcription.selector import ProviderSelector


class TranscriptionService:
    """Produces a Transcript for a Capture and records provider lineage."""

    def __init__(self, selector: ProviderSelector, lineage: LineageStore, clock: Clock) -> None:
        self._selector = selector
        self._lineage = lineage
        self._clock = clock

    def transcribe(self, ctx: TenantContext, capture: Capture) -> Transcript:
        require_same_tenant(ctx, capture.tenant_id, "capture")
        provider = self._selector.select(ctx)
        result = provider.transcribe(
            TranscriptionRequest(
                tenant_id=ctx.tenant_id,
                capture_id=capture.capture_id,
                content=capture.content,
            )
        )
        transcript = Transcript(
            transcript_id=new_id("tr"),
            tenant_id=ctx.tenant_id,
            capture_id=capture.capture_id,
            text=result.text,
            language=result.language,
            confidence=result.confidence,
            provider_name=result.provider_name,
            created_at=self._clock.now(),
        )
        self._lineage.append(
            ctx,
            LineageEvent(
                event_id=new_id("evt"),
                tenant_id=ctx.tenant_id,
                subject_id=transcript.transcript_id,
                kind="transcript.created",
                payload={
                    "capture_id": capture.capture_id,
                    "provider": result.provider_name,
                    "confidence": result.confidence,
                },
                occurred_at=transcript.created_at,
            ),
        )
        return transcript
