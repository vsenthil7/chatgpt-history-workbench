"""Transcript aggregate."""
from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class Transcript:
    """A transcript derived from exactly one capture."""

    transcript_id: str
    tenant_id: str
    capture_id: str
    text: str
    language: str
    confidence: float
    provider_name: str
    created_at: datetime
