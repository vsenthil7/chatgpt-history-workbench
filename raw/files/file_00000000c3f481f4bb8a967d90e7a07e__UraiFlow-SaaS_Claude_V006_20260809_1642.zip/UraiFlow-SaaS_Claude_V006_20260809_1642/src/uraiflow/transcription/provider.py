"""Replaceable transcription provider abstraction (starter contract requirement)."""
from dataclasses import dataclass, field
from typing import Protocol


@dataclass(frozen=True)
class TranscriptionRequest:
    """Provider-neutral transcription input."""

    tenant_id: str
    capture_id: str
    content: str
    language_hint: str | None = field(default=None)


@dataclass(frozen=True)
class TranscriptionResult:
    """Provider-neutral transcription output."""

    text: str
    language: str
    confidence: float
    provider_name: str


class TranscriptionProvider(Protocol):
    """Contract every concrete provider implementation must satisfy."""

    name: str

    def transcribe(self, request: TranscriptionRequest) -> TranscriptionResult:  # pragma: no cover - protocol signature
        ...


class DeterministicEchoProvider:
    """Reference provider: echoes captured text; deterministic for tests/fixtures."""

    def __init__(self, name: str) -> None:
        self.name = name

    def transcribe(self, request: TranscriptionRequest) -> TranscriptionResult:
        language = request.language_hint if request.language_hint is not None else "en"
        return TranscriptionResult(
            text=request.content,
            language=language,
            confidence=0.99,
            provider_name=self.name,
        )
