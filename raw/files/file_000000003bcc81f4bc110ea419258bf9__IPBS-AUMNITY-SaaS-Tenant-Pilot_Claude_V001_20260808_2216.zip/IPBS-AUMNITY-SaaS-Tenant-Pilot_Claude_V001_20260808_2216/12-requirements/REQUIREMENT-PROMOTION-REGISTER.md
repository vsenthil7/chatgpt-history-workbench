# Requirement Promotion Register — V001

**Source of truth:** `promotion-register.csv` (machine-readable; this narrative is cross-checked against it by `scripts/validate_register.py` — do not edit counts here manually).

**Pipeline:** IPBS observation → generic requirement → owning SaaS product/module → status → implementation version → validation evidence.

**Status vocabulary:**
`OBSERVED` (raw evidence recorded) → `CLASSIFIED` (ownership assigned per the five-way rule) → `PROPOSED` (requires ADR/new-module approval) → `PROMOTED` (accepted into owning product backlog) → `IMPLEMENTED` (version recorded) → `VALIDATED` (IPBS tenant evidence attached).

**Ownership codes:** PLATFORM = AUMNITY Work Platform SaaS · CGWO = AUMNITY CGWO SaaS · URAIFLOW = UraiFlow SaaS · TENANT-IPBS = IPBS tenant configuration · NEW-MODULE = proposed bounded SaaS module.

## V001 position

| Owner | Entries | IDs |
|---|---|---|
| PLATFORM | 8 | RPR-001…008 |
| CGWO | 12 | RPR-010…021 |
| URAIFLOW | 4 | RPR-030…033 |
| TENANT-IPBS | 4 | RPR-040…043 |
| NEW-MODULE (proposed) | 1 | RPR-050 |
| **Total** | **29** | |

All entries are at `CLASSIFIED` except RPR-050 (`PROPOSED`, gated on ADR-0002). No entry has an implementation version: **no generic code has been, or may be, written inside this pilot**. Implementation happens in the owning product repositories; this register then records version and validation evidence per entry.

## Classification rationale highlights

- **Work item vs planning split (RPR-002 vs RPR-013/014):** the canonical single-ID work record is a Platform primitive because every product (CGWO planning, UraiFlow commits, future modules) references it; the *selection* of that work into weekly/daily plans is CGWO orchestration behaviour.
- **Confirmation vs reconfirmation (RPR-006 vs RPR-014):** generic attest/approve/reject-with-correction is a reusable Platform primitive; the *previous-day availability reconfirmation gate* is planning-domain behaviour and sits in CGWO, consuming the Platform primitive.
- **Cross-midnight defect (RPR-016):** a concrete edge case discovered from a baseline formula defect (F-02). It is registered as a CGWO domain rule (correct duration semantics), not as a spreadsheet fix — the workbook is evidence, not the product.
- **Skills (RPR-050):** capability taxonomy/verification/training/recruitment signals span identity (Platform-ish), planning input (CGWO-ish) and proposal targets (UraiFlow-ish) — the placement test fails to yield a single owner, so per rule 5 a new bounded module is proposed before any implementation (ADR-0002). CGWO's skill check (RPR-012) is deliberately written to *consume a capability contract*, keeping it valid whichever ownership decision is approved.
- **Billing (RPR-042):** only the IPBS mapping is classified now (tenant config). Whether a generic billing/invoicing capability is warranted is explicitly deferred (ADR-0003) rather than smuggled into CGWO via the timesheet.
- **Tenant leakage found in the baseline (RPR-040/041):** `TEE_Capacity_Note`, the founder-specific review question and "Overall Planner" are IPBS vocabulary embedded in what looks like product structure. They are classified to tenant configuration precisely so they never reach product schemas.

## Register maintenance rules

1. New observations enter as `OBSERVED` with workbook/operational evidence before classification.
2. Classification uses the five-way rule; an unclear owner requires an ADR before any code (Modularity placement test).
3. `PROMOTED` requires a backlog reference in the owning product; `IMPLEMENTED` requires that product's version; `VALIDATED` requires IPBS tenant evidence (acceptance test, usage record or signed-off finding).
4. The CSV is the single source of truth; totals in narrative documents are validated, never hand-maintained (Quality Gate G10).
