#!/usr/bin/env python3
"""G10 consistency check: promotion-register.csv vs narrative register vs RTM.
The CSV is the single source of truth; narrative counts must match it."""
from pathlib import Path
import csv, re, sys

ROOT = Path(__file__).resolve().parents[1]
csv_path = ROOT / '12-requirements/promotion-register.csv'
md_path = ROOT / '12-requirements/REQUIREMENT-PROMOTION-REGISTER.md'

VALID_OWNERS = {'PLATFORM', 'CGWO', 'URAIFLOW', 'TENANT-IPBS', 'NEW-MODULE'}
VALID_STATUS = {'OBSERVED', 'CLASSIFIED', 'PROPOSED', 'PROMOTED', 'IMPLEMENTED', 'VALIDATED'}
VALID_CLASS = {'1', '2', '3', '4', '5'}
errors = []

with csv_path.open(encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

ids = [r['id'] for r in rows]
if len(ids) != len(set(ids)):
    errors.append('duplicate register IDs')
by_owner = {}
for r in rows:
    if r['owner'] not in VALID_OWNERS: errors.append(f"{r['id']}: invalid owner {r['owner']}")
    if r['status'] not in VALID_STATUS: errors.append(f"{r['id']}: invalid status {r['status']}")
    if r['classification'] not in VALID_CLASS: errors.append(f"{r['id']}: invalid classification {r['classification']}")
    if not r['validation_evidence'].strip(): errors.append(f"{r['id']}: missing evidence")
    if r['implementation_version'].strip():
        errors.append(f"{r['id']}: implementation_version set — implementation is not permitted inside the pilot")
    if r['owner'] == 'NEW-MODULE' and r['status'] not in {'PROPOSED', 'PROMOTED'}:
        errors.append(f"{r['id']}: NEW-MODULE entries require PROPOSED/PROMOTED status")
    by_owner[r['owner']] = by_owner.get(r['owner'], 0) + 1

md = md_path.read_text(encoding='utf-8')
m = re.search(r'\*\*Total\*\* \| \*\*(\d+)\*\*', md)
if not m:
    errors.append('narrative total not found')
elif int(m.group(1)) != len(rows):
    errors.append(f'narrative total {m.group(1)} != CSV rows {len(rows)}')
for owner, n in by_owner.items():
    label = owner if owner != 'NEW-MODULE' else r'NEW-MODULE \(proposed\)'
    if not re.search(rf'\| {label} \| {n} \|', md):
        errors.append(f'narrative count for {owner} does not match CSV ({n})')

rtm = (ROOT / '06-traceability/RTM.md').read_text(encoding='utf-8')
if f'({len(rows)} entries)' not in rtm:
    errors.append(f'RTM REG-001 entry count does not match CSV ({len(rows)})')

if errors:
    print('REGISTER CONSISTENCY: FAIL'); [print(' -', e) for e in errors]; sys.exit(1)
print(f'REGISTER CONSISTENCY: PASS ({len(rows)} entries; owners: '
      + ', '.join(f'{k}={v}' for k, v in sorted(by_owner.items())) + ')')
