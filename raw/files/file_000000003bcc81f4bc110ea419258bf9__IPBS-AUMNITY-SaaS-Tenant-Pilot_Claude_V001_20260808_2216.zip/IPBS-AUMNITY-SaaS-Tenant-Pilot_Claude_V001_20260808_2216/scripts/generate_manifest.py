#!/usr/bin/env python3
"""Regenerate PACKAGE-MANIFEST.json with SHA-256 hashes for every packaged file (G01)."""
from pathlib import Path
import hashlib, json, sys
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
files = sorted(p for p in ROOT.rglob('*') if p.is_file() and p.name != 'PACKAGE-MANIFEST.json')
entries = []
for p in files:
    data = p.read_bytes()
    entries.append({'path': p.relative_to(ROOT).as_posix(), 'bytes': len(data),
                    'sha256': hashlib.sha256(data).hexdigest()})
manifest = {'schema': 'aumnity-starter-manifest/v1',
            'created': datetime.now().astimezone().isoformat(timespec='seconds'),
            'project': 'IPBS AUMNITY SaaS Tenant Pilot',
            'first_page': '00001-IPBS-Tenant-Validation-Baseline',
            'ai_artifact': 'IPBS-AUMNITY-SaaS-Tenant-Pilot_Claude_V001_20260808_2216.zip',
            'files': entries}
(ROOT / 'PACKAGE-MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(f'manifest regenerated: {len(entries)} files')
