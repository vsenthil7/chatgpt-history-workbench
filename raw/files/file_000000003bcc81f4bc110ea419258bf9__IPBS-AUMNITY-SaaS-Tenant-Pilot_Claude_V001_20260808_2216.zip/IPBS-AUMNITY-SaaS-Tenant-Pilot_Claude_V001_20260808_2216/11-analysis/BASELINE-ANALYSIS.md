# Baseline Analysis — IPBS-Adaptive-Work-and-Resource-Pilot-v0.1.0.xlsx

**Analysed:** 08/08/2026 (Claude V001)
**Source:** `10-baseline/IPBS-Adaptive-Work-and-Resource-Pilot-v0.1.0.xlsx` (SHA-256 `8687e391…74f7`, preserved unchanged)
**Standing rule applied:** the workbook is a REAL-WORLD INPUT for requirement discovery, not a target architecture. Nothing here mandates implementation inside the IPBS pilot.

---

## 1. Workbook inventory

| Sheet | Purpose (as evidenced) | Data rows populated | Pre-seeded formulas |
|---|---|---|---|
| 00_Start_Here | Operating instructions, 7-step weekly cadence + one governance rule | n/a (instructional) | — |
| 99_Lists | Central controlled vocabularies (8 taxonomies) | n/a (reference) | — |
| 01_Resource_Master | People/resources, role, manager, skills, verification, training/recruitment need | 0 | — |
| 02_Task_Master | Single-capture work item register with triage decision | 0 | — |
| 03_Availability | Availability declarations across 4 horizons with status + confidence | 0 | — |
| 04_Weekly_Plan | Weekly selection with skill check and capacity check | 0 | Capacity_Result: `=IF(H≤G,"Within capacity","Over capacity")` ×500 |
| 05_Daily_Plan | Daily plan with previous-day confirmation and availability re-check | 0 | — |
| 06_Daily_Tracker | Execution events (start/pause/resume/end), interruptions, evidence, confirmation | 0 | Actual_Minutes: `=ROUND((End−Start)*1440,0)` ×500 |
| 07_Timesheet | Consolidated actuals per Task_ID with billable flag and approval ladder | 0 | Actual_Hours: `=Minutes/60` ×500 |
| 08_UraiFlow_Proposals | Transcript segment → proposed record → human decision → committed record | 0 | — |
| 09_Weekly_Review | COUNTA/COUNTIF/SUM metrics + 7 standing review questions | n/a (dashboard) | 7 metric formulas |

The workbook is an **empty operating template**: structure, vocabularies, validations and formulas are defined; no operational data has been entered yet. Evidence value is therefore in the *designed workflow*, not in transactions.

## 2. Designed workflow (from 00_Start_Here + sheet linkage)

1. Capture every new work thought **once** in Task_Master (unique Task_ID).
2. Check skill requirement and resource availability **before** selecting work.
3. Select realistic work into Weekly_Plan (capacity check against declared weekly hours).
4. On the previous day, reconfirm availability and prepare Daily_Plan.
5. Record actual start/pause/resume/end in Daily_Tracker.
6. Timesheet consolidates actual effort linked back to Task_ID.
7. Weekly review of plan changes, interruptions and rollover.

Governance rule stated in the workbook itself: **"Do not copy a task as a new master task when moving between planning horizons"** — i.e. one canonical work item flows through monthly→weekly→daily→execution→timesheet by reference, never by duplication.

## 3. Identifier and linkage model (implicit)

Free-text IDs link sheets: `Task_ID` (02→04,05,06,07), `Resource_ID` (01→03,04,05,06,07,08), `Weekly_Plan_ID` (04→05), `Daily_Plan_ID` (05→06), `Execution_ID` (06→07), `Proposal_ID`/`UraiFlow_Proposal_ID` (08↔06), `Committed_Record_ID` (08→any). **No referential integrity is enforced anywhere** — Excel accepts any value. This is the single largest structural weakness of the baseline and a direct product requirement (see RPR-003).

## 4. Controlled vocabularies

Central (99_Lists): Task Status (7), Priority (4), Plan Status (7), Availability Status (4), Skill Level (6: Awareness→Expert), Change Reason (7), Activity Type (7), Confirmation (4).

Inline (embedded in data validations, NOT in 99_Lists):
- Resource Active: Yes/No
- Need_Now?: Yes/No/Unknown
- Triage Decision: Do now / Prototype / Configure existing / Research / Train-recruit first / Hold / Stop
- Availability Horizon: Monthly / Weekly / Previous Day / Same Day
- Resource_Skill_Check: Suitable / Suitable with support / Training needed / Not suitable / Not checked
- Previous_Day_Confirmed: Yes/No/Changed; Availability_Check: Available/Partially available/Unavailable/Not checked
- Execution_Status: Started/Paused/Resumed/Blocked/Interrupted/Completed
- Follow_Up_Required: Yes/No; Billable: Yes/No/Not applicable
- Approval_Status: Draft/Submitted/Approved/Rejected/Corrected
- Employee_Decision: Pending/Confirm/Edit and confirm/Reject/Defer

## 5. Findings, gaps and contradictions (B001 inventory — nothing deleted)

| # | Finding | Type | Consequence |
|---|---|---|---|
| F-01 | No referential integrity between sheets; all links are free text | Structural gap | Promoted as RPR-003 (Platform) |
| F-02 | `Actual_Minutes = (End−Start)*1440` yields **negative minutes for cross-midnight work** | Formula defect / edge case | Promoted as RPR-016 (CGWO duration rules) |
| F-03 | Vocabulary governance is split: some lists central in 99_Lists, some inline in validations; `Execution_Status` overlaps `Plan Status` semantics but is a different inline list | Inconsistency | Promoted as RPR-008 (managed reference data) |
| F-04 | `Skill Level` taxonomy (Awareness→Expert) is defined in 99_Lists but **referenced by no validation and no column** — an orphan taxonomy | Orphan | Feeds RPR-050 (capability module proposal) |
| F-05 | `Current_Skills` / `Required_Skills` are free text; skill matching (Resource_Skill_Check) is a manual human judgement with no data basis | Manual step | RPR-012 + RPR-050 |
| F-06 | All transaction sheets hard-capped at 500 rows; Weekly_Review formulas hard-code the same ranges | Scale limit | RPR-021 (NFR: no fixed record limits) |
| F-07 | No tenancy, no user identity, no access control, no edit history — single-file, single-user model | SaaS gap | Already covered by starter RTM SaaS-001/002; register cross-references |
| F-08 | Availability confirmation ladder exists (Forecast→Confirmed→Changed→Unavailable + Confidence_%) but nothing forces the previous-day reconfirmation step | Unenforced policy | RPR-014 |
| F-09 | Supervision is captured (`Supervision_Hours`, review Q4 "founder/manager supervision bottleneck") but never checked against any supervision capacity | Missing check | RPR-018 |
| F-10 | Timesheet approval ladder (Draft→Submitted→Approved→Rejected→Corrected) and `Correction_Reason` exist with no approver routing or audit mechanics | Manual workflow | RPR-006/RPR-007/RPR-017 |
| F-11 | `TEE_Capacity_Note`, `Overall Planner` (review Q6), founder-specific review question Q4 are IPBS-specific vocabulary embedded in structure | Tenant leakage in template | RPR-040/041 — must become tenant configuration, never product schema |
| F-12 | 08_UraiFlow_Proposals defines a complete propose→decide→commit→audit contract including `Corrected_Value` and `Committed_Record_ID`, and 06 links back via `UraiFlow_Proposal_ID` | Integration contract evidence | RPR-030…033 |
| F-13 | Weekly_Review counts "Pending" proposals — human-decision latency is already a first-class operational metric | Metric evidence | RPR-020/RPR-031 |
| F-14 | No calendar/time-zone model; times are naked Excel times (contributes to F-02) | Gap | RPR-016 |

## 6. Starter-document consistency check

- All 16 manifest entries verified present; `scripts/validate_starter.py` → PASS (evidence in `13-evidence/`).
- No contradictions found between starter documents. One naming observation: PROJECT-START names classification targets "AUMNITY Platform, CGWO, UraiFlow"; the user brief names them "AUMNITY Work Platform SaaS / AUMNITY CGWO SaaS / UraiFlow SaaS". Treated as the same three products; canonical short names used in the register: **PLATFORM / CGWO / URAIFLOW / TENANT-IPBS / NEW-MODULE**.
