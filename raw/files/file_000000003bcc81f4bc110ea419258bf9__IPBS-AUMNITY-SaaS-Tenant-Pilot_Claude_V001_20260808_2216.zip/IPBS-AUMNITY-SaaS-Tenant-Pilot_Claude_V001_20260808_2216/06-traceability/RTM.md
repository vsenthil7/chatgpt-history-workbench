# Requirement Traceability Matrix — starter

| ID | Requirement | Owner | Enforcement | Evidence/Test | Status |
|---|---|---|---|---|---|
| ARC-001 | Product code remains within declared bounded ownership | Architecture | architecture guard | TBD | DECLARED |
| ARC-002 | Cross-product reuse occurs through published contracts, not copied logic | Architecture | review + dependency guard | TBD | DECLARED |
| SaaS-001 | Reusable product code is tenant-neutral | Platform/Product | tenant-leak guard + tests | TBD | DECLARED |
| SaaS-002 | Tenant/org context is explicit at protected boundaries | Platform/Product | authz/isolation tests | TBD | DECLARED |
| QA-001 | New executable packages meet line+branch coverage policy | Engineering | coverage gate | TBD | DECLARED |
| QA-002 | Critical domain/policy behavior is mutation tested | Engineering | mutation gate | TBD | DECLARED |
| QA-003 | Escaped defects receive regression tests | Engineering | review/CI | TBD | DECLARED |
| DOC-001 | Version, package, test-count and ADR references are consistency checked | Governance | docs gate | scripts/validate_starter.py | ACTIVE |
| AI-001 | Claude build → independent ChatGPT ZIP review loop is used for releases | Governance | release checklist | handoff evidence | ACTIVE |

## V001 additions — register discipline (Claude V001, 2026-08-08)

| ID | Requirement | Owner | Enforcement | Evidence/Test | Status |
|---|---|---|---|---|---|
| REG-001 | Every pilot-discovered requirement is classified via the five-way ownership rule before any implementation | Governance | Requirement Promotion Register + ADR gate | 12-requirements/promotion-register.csv (29 entries) | ACTIVE |
| REG-002 | Register narrative counts/IDs stay consistent with the machine-readable CSV | Governance | scripts/validate_register.py | 13-evidence/validate_register.txt | ACTIVE |
| REG-003 | No generic product implementation exists inside the pilot package | Architecture | package inspection (no src/ of product code) + independent review | 08-ai/HANDOFF-CLAUDE-V001.md | ACTIVE |
| REG-004 | Unclear ownership requires an ADR before code (placement test) | Architecture | ADR record | ADR-0002, ADR-0003 (PROPOSED) | ACTIVE |

Starter rows ARC/SaaS/QA remain DECLARED: they bind future product implementation, which has not begun. DOC-001 and AI-001 remain ACTIVE with V001 evidence in `13-evidence/`.
