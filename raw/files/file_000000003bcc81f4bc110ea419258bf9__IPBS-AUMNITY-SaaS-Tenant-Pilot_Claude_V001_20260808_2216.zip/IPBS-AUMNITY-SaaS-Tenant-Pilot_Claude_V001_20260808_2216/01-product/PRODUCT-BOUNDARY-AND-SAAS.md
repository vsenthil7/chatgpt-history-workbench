# Product Boundary and SaaS Model

## Boundary
Validate AUMNITY SaaS products using IPBS operational reality. Store tenant configuration, pilot workbook/data mappings, acceptance evidence, usability findings and product-gap proposals.

## Not owned
NO product/domain source code. Any reusable requirement discovered here must be promoted to AUMNITY Platform, CGWO, UraiFlow or another explicitly bounded SaaS product.

## Commercial/operating model
Products are reusable SaaS. IPBS is currently one tenant/user and may sell, support or implement the product. Other AT/WE companies and external customers may later become tenants, operators, implementation partners or channels. Product ownership and domain code therefore cannot be tied to IPBS.

## Tenant-neutral design
Use organisation/tenant configuration, policy, adapters and feature entitlements instead of customer-specific branches. A customer name may appear in pilot fixtures/docs, never as a reusable domain assumption.
