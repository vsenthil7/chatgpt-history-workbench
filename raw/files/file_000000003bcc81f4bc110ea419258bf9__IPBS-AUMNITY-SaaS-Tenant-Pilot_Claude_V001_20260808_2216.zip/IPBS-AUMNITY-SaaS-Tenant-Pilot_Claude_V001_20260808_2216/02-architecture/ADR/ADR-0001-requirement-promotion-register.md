# ADR-0001 — Requirement Promotion Register as the pilot's primary artefact

**Status:** ACCEPTED · **Date:** 2026-08-08 · **Version:** Claude V001

## Context
The IPBS pilot owns no generic product code. It must still convert operational reality (the workbook, workflow, friction) into traceable product requirements for AUMNITY Platform, CGWO, UraiFlow, tenant configuration, or newly proposed modules.

## Decision
1. A Requirement Promotion Register is the pilot's primary output. Machine-readable source: `12-requirements/promotion-register.csv`; narrative view cross-checked by `scripts/validate_register.py`.
2. Register pipeline: OBSERVED → CLASSIFIED → PROPOSED (where ADR needed) → PROMOTED → IMPLEMENTED → VALIDATED, with owner codes PLATFORM / CGWO / URAIFLOW / TENANT-IPBS / NEW-MODULE.
3. No entry may move to IMPLEMENTED via code inside this pilot. Implementation versions always reference the owning product.
4. Every register entry cites concrete workbook/operational evidence (sheet, column, formula or finding ID from BASELINE-ANALYSIS.md).

## Consequences
- The pilot stays code-free until product contracts exist to exercise (acceptance tests/fixtures/adapters are then permitted per TENANT-PILOT-PROMOTION-RULE.md).
- RTM rows REG-001..003 enforce register discipline.
