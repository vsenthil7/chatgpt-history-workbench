# ADR-0003 — Timesheet consolidation, approval and billing ownership split

**Status:** PROPOSED · **Date:** 2026-08-08 · **Version:** Claude V001

## Context
07_Timesheet combines three concerns: (a) consolidation of actual effort from execution records per Task_ID; (b) an approval ladder (Draft→Submitted→Approved→Rejected→Corrected) with correction reasons; (c) billable flag and client/project mapping.

## Proposed split
- (a) Consolidation → CGWO (RPR-017): it is derived work/effort data inside the orchestration domain.
- (b) Approval/attestation mechanics → Platform primitive (RPR-006/007): the same approve/reject/correct-with-audit pattern already appears in Daily_Tracker employee confirmation and UraiFlow proposal decisions; three appearances earn a shared primitive.
- (c) Billable/client mapping → IPBS tenant configuration now (RPR-042). A generic billing/invoicing product is **not** proposed at this time — one tenant's flag is insufficient reuse evidence. Revisit when a second tenant or a concrete invoicing requirement appears.

## Required to proceed
Human approval of the split; then RPR-006/007/017/042 move to PROMOTED against their owners.
