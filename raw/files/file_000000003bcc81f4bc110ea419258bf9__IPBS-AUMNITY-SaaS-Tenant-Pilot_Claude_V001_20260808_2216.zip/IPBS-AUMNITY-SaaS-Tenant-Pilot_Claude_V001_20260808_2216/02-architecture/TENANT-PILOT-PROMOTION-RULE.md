# Tenant Pilot Promotion Rule

IPBS is validation evidence, not a product-code owner.

Every discovered change is classified before implementation:
- tenant configuration/data/mapping → this pilot package;
- generic work/capacity/planning behavior → CGWO;
- shared organisation/identity/work/evidence/audit primitive → AUMNITY Work Platform;
- voice/transcript/extraction/proposal behavior → UraiFlow;
- genuinely new reusable bounded capability → create/approve a separate SaaS module/product.

The IPBS package may contain acceptance tests, fixtures, adapters/configuration and evidence that exercise product contracts, but not duplicated generic domain implementation.
