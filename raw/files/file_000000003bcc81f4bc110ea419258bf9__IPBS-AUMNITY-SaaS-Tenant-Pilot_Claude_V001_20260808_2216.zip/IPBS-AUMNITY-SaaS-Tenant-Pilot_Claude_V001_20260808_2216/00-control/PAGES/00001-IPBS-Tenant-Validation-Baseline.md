# Page 00001 — IPBS-Tenant-Validation-Baseline

**Session:** 08/08/2026 22:16 Europe/London · **Builder:** Claude · **Output artifact:** IPBS-AUMNITY-SaaS-Tenant-Pilot_Claude_V001_20260808_2216.zip
**Input artifact:** IPBS-AUMNITY-SaaS-Tenant-Pilot_ChatGPT_V001_20260808_1318.zip (all 16 files read; workbook fully decomposed)

## Scope executed (B001 + first half of B002)
1. Read the complete starter package and the preserved workbook (sheets, headers, all 27 data-validation lists, all formulas).
2. Produced `11-analysis/BASELINE-ANALYSIS.md` — 14 findings inventoried, nothing deleted or normalised.
3. Produced the initial Requirement Promotion Register — 29 entries: 8 PLATFORM, 12 CGWO, 4 URAIFLOW, 4 TENANT-IPBS, 1 NEW-MODULE (proposed).
4. Raised ADR-0001 (accepted: register discipline), ADR-0002 and ADR-0003 (proposed: capability-module and timesheet-split ownership — awaiting human approval).
5. Added RTM rows REG-001..004; ran validators; regenerated the package manifest.

## Deliberately NOT done
No product/domain source code, no schemas, no APIs, no workbook "fixes" — per the critical rule, the pilot owns no generic product code and the workbook is input evidence only.

## Open decisions for the human
- Approve/amend ADR-0002 (capability module) and ADR-0003 (timesheet split).
- Confirm the status vocabulary and owner codes in the register.
