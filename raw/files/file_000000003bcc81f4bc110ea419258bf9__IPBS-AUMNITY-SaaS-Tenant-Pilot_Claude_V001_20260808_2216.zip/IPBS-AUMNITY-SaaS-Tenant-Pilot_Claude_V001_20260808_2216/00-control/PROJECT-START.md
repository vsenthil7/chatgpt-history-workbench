# Project Start

**Project name:** IPBS AUMNITY SaaS Tenant Pilot  
**First page name:** 00001-IPBS-Tenant-Validation-Baseline  
**Starter artifact:** IPBS-AUMNITY-SaaS-Tenant-Pilot_ChatGPT_V001_20260808_1318.zip  
**Created:** 08/08/2026 13:18 Europe/London

## SaaS ownership rule
This is a tenant-validation package only. It owns no generic product code; reusable changes must be implemented in the owning SaaS product.

## Product/pilot boundary
Validate AUMNITY SaaS products using IPBS operational reality. Store tenant configuration, pilot workbook/data mappings, acceptance evidence, usability findings and product-gap proposals.

## Explicitly not owned
NO product/domain source code. Any reusable requirement discovered here must be promoted to AUMNITY Platform, CGWO, UraiFlow or another explicitly bounded SaaS product.

## First build objective
Run the workbook as a tenant validation harness, record friction/evidence, and raise traceable product requirements without implementing generic functionality inside the IPBS pilot.

## Working pattern
Claude Code = implementation. ChatGPT = independent complete-ZIP review. Repeat version-by-version using evidence, not narrative confidence.

## Baseline preservation
The supplied pre-rebuild artifact is preserved under `10-baseline/`. It is historical/input evidence, not automatically authoritative when it conflicts with this starter contract or a later approved ADR.
