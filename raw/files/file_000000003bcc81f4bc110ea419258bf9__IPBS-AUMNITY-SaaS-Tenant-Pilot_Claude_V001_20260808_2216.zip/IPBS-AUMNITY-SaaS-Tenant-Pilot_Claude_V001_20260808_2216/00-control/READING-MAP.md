# Reading Map

1. `00-control/PROJECT-START.md`
2. `01-product/PRODUCT-BOUNDARY-AND-SAAS.md`
3. `02-architecture/MODULARITY-AND-REUSE.md`
4. `03-engineering/ENGINEERING-OPERATING-SYSTEM.md`
5. `04-testing/TESTING-STRATEGY.md`
6. `05-quality/QUALITY-GATES.md`
7. `06-traceability/RTM.md`
8. `07-planning/FIRST-BUILD-BACKLOG.md`
9. `CLAUDE.md` when implementing
10. `08-ai/CHATGPT-REVIEW-HANDOFF.md` before packaging
11. `10-baseline/` for prior detailed product material
