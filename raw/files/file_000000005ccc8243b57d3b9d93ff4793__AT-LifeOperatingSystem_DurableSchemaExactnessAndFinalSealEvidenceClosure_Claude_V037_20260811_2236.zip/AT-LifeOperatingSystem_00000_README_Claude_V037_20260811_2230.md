# AT-Life Operating System (AT-LOS) - V037

**Release:** `AT-LifeOperatingSystem_DurableSchemaExactnessAndFinalSealEvidenceClosure_Claude_V037`
**Prepared by:** Claude · release stamp **2026-08-11T22:30:17+01:00** (the moment the release identity was written, after the pre-package gates; the seal completion time lives in the delivery attestation and names the delivery file - ADR-037 D-159) · Corrective release for your V036 deep review: **F01-F07, every finding reproduced before any code changed**, zero rejected, zero deferred. V037 is a **candidate for independent review**.

## Your central finding, accepted

> A name is not the thing: V036's "complete schema" recorded names and columns while defaults, uniqueness, predicates and trigger bodies stayed invisible - and its "complete seal" executed part of a gate list prose called whole.

**F01.** All four reproductions confirmed - the worst being your deletion trigger under which `put_events` reported `added=1` while the row was already gone: silent durable-data loss reported as success. The fingerprint now carries **complete SQLite semantics** (`table_xinfo` with defaults and generated kinds; full foreign-key actions; `index_list`/`index_xinfo` uniqueness, origin, partial predicates, collations, sort orders; whole normalised trigger bodies; normalised CREATE sql for UNIQUE/CHECK/STRICT/WITHOUT ROWID), and `schema_differences` compares **both directions over target-owned territory**: any index or trigger attached to a target-owned table that the store did not create refuses the open, while genuinely sibling-owned objects stay tolerated. Your four reproductions plus the fifth class (FK actions, trigger bodies and timing) are permanent non-mutating regressions, and a mutation reverting the ownership check must die.

**F02.** Confirmed. The sealer now holds **one canonical gate registry** - deterministic, integration, ruff, mypy --strict, standalone install, mutation - and **executes it**, pre-package and again **against the extracted final bytes**. Every gate records exact command, tool version, cwd, start/end timestamps, exit code, output SHA-256 and tail, parsed counts - and the mutation gate records the report's hash and its full source-hash set, because two numbers are a summary, not evidence. `SealRunEvidence` ships **inside the package, manifest-pinned, with no self-hash**; the external `delivery_attestation.json` binds the final ZIP's SHA-256 to the evidence identity, so neither can be substituted independently.

**F03.** Confirmed - 113 seconds between the declared seal and the last verification. `release_stamp_created_at` and `seal_completed_at` are now **distinct named facts**: completion exists only after the extracted-byte registry, CRC and manifest checks succeed, is strictly later than every gate timestamp, and **names the delivery** - the already-verified immutable ZIP is renamed to the completion minute, a rename that changes no bytes, which the attested SHA-256 proves.

**F04.** Your diagnostic confirmed: dropped `tests_passed` plus a bogus fact produced zero findings. The reader now requires **exact key-set equality** (each missing and each unexpected key is a finding) and **exact type equality** (`True` is not `1`, `670.0` is not `670`), with your probes as permanent negatives and a mutation removing the type check required killed.

**F05.** Confirmed - the one diff taken was discarded. Each generator now **declares its owned outputs**; those files are **hashed before and after every run**; "zero-diff" appears in evidence only when the hash sets are identical, and a release-validation run that changes an owned file **aborts the seal** with the changed list recorded.

**F06.** Confirmed against the shipped workbook - every row height `None` under 312-character wrapped cells. The gate now estimates wrapped lines per row at the declared width and requires a proportional **explicit row height**, wrap alignment, auto-filters and frozen headers; your exact clipped-final-row class is a permanent negative regression, the shipped V036 sheet **fails** the new gate, and this release's disposition sheet is built by a formatter that computes heights **from the same estimator the gate enforces**.

**F07.** Both confirmed. Compatibility, stated precisely: for every value the current release accepts, canonical bytes and ids are unchanged from V035; aware instants before year 1000, which V035 could derive ids for, are rejected before derivation - the derivable set narrowed, nothing was remapped. That no durable baseline holds such an id is a stated migration precondition (no independently accepted release ever wrote atid/3 ids durably), not a proven fact. That statement now appears at every source - README, metadata, changelog, ADR-036/037, `identity.toml`, code docstrings, project memory - and any unresolved template token in a current text artefact **fails the blocking audit**, with the missed-f-string class as a permanent negative.

<!-- FACTS:BEGIN -->
*Generated by `tools/gen_facts_block.py`. Do not edit — a test compares this
block to freshly derived facts, so a stale figure fails the build.*

| Measure | Value |
|---|---|
| Release | V037 |
| Platform version | 0.28.0 |
| Package versions | at-cli 0.28.0, at-durable 0.28.0, at-evidence 0.28.0, at-identity 0.28.0, at-ingest-core 0.28.0, at-ingest-llm-export 0.28.0, at-ingest-whatsapp 0.28.0, at-store 0.28.0 |
| Deterministic tests collected | 686 |
| Deterministic tests passed / skipped | 685 / 1 |
| Environment-dependent integration tests | 2 collected — outcomes vary by environment (reference CI runs them; an offline environment legitimately skips) |
| Parser tests | 43 |
| Store tests | 110 |
| Architecture guards | 69 |
| Statements / missed | 2257 / 0 |
| Branches / partial | 696 / 0 |
| Line + branch coverage | 100% |
| Mutation regressions | 71 |
| RTM rules (passing / skipped / not enforced) | 179 (175 / 1 / 3) |
| Modules declared | 12 |
| Product applications declared | 2 |
| ADRs | 37 |
| Test suites (built / planned) | 22 / 4 (3 internal, 1 external) |
| Documentation pages | 58 |
| CI jobs | 6 |

**Coverage scope.** These figures describe only the currently measured
production packages: at-cli, at-durable, at-evidence, at-identity, at-ingest-core, at-ingest-llm-export, at-ingest-whatsapp, at-store. Coverage of implemented code is not functional coverage, and every module
beyond these has no code to measure.
<!-- FACTS:END -->

## Scope

No feature work. The six-status evidence model, timeline, commitments, questions, at-consent, UI/API and AT-056 are untouched; ingestion stays FROZEN/MAINTENANCE and untouched this release. ADR-037 (D-156..D-160), RTM-175..179.

## Status

V037 is a **candidate for independent review**. It claims no acceptance; whether the six-status evidence model may begin is decided by that review, after independent V037 acceptance.
