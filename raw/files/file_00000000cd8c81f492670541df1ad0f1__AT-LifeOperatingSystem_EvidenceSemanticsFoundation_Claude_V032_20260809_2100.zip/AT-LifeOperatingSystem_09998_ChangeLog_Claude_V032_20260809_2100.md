# AT-LOS V032 Change Log

**Release type:** evidence substrate — the first feature tranche since V023, per the independent V031 acceptance instruction. ADR-032. New package `at-evidence` (Planned → Partial). **Ingestion untouched: FROZEN / MAINTENANCE.**

## at-evidence (new)

`EvidenceItem` — verbatim excerpt + ≥1 `EvidenceSourceRef` (event id + full `SourceRef` + event timestamp); unconstructible without an anchor (RTM-141). `EvidenceClaim` — authored statement, optional opaque `PersonRef` subject; immutable, statement-derived identity. `EvidenceRelationship` — supports/contradicts/contextualises with declared `EvidenceStrength`; non-direct strength requires a stated basis (RTM-144). Content-derived deduplicating 32-hex identity: idempotent identical re-record, refused conflicts, chosen-id mismatch unconstructible (RTM-142). Append-only `EvidenceRepository` port — no update/delete anywhere, structurally scanned (RTM-143). In-memory + SQLite engines, one contract suite against both, schema v1 refusing mismatches, every canonical field round-tripped, reopen preserves idempotency (RTM-145). Workspace boundaries enforced on anchors and subjects; relationship referential integrity; `evidence_for_event` lineage both ways. No interpretation API — normative in ADR-032, guarded by vocabulary scan (D-122-worded).

## Catalogue, RTM, tests, mutation

`architecture.toml`: at_evidence entry rewritten to the substrate contract (the "score confidence" phrase superseded by D-125); state Partial; deterministic=true (no clock, no randomness — timestamps from the caller). `testing.toml`: TST-INT-EVIDENCE registered (suites built 17 → 18). RTM-141..145; **145 rules: 141 + 1 + 3**. 34 new tests; **558 of 559 deterministic passing**, 100% on **1761 statements / 516 branches**; **53/53 mutants** including four ADR-032 mutants; ruff + mypy --strict clean via exact CI commands. READ_THIS_FIRST "specification only" paragraph corrected: at-evidence removed from the unbuilt list with an honest Partial description.

## Documents and workbooks

Standard V032: rules D-125..D-128. Project Memory: D-125..D-128; V032 history; V031 CURRENT COUNT demoted; V032 CURRENT COUNT (with the explicit "substrate only" caveat); **AT-004 → Frozen/Maintenance carrying the five-condition change rule; AT-012 → In Progress**; SprintTracker S2-01 honestly updated (substrate exists, six-status model does not). Test Strategy: derived sheets regenerated (145 RTM, 53 mutants, V032 facts); new `25_EvidenceSubstrate` register. Both workbook titles from the release source.

## Decisions

D-125 the substrate records, never interprets · D-126 derived identity, append-only forever · D-127 self-standing bidirectional lineage · D-128 storage discipline inherited from birth

## Open

DQ-004, DQ-012, DQ-013, DQ-014, DQ-016 · named gaps unchanged (real LLM corpora, Layer-D, strict-JSON) — none may generate ingestion work alone · six-status model + timeline/commitments/questions next, on the substrate · **AT-056 Not started**.
