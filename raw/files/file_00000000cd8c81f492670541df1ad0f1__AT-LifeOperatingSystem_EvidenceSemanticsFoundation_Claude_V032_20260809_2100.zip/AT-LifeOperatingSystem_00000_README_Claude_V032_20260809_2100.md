# AT-Life Operating System (AT-LOS) - V032

**Release:** `AT-LifeOperatingSystem_EvidenceSemanticsFoundation_Claude_V032_20260809_2100`
**Prepared by:** Claude · **09-Aug-2026 21:00 BST** · **The first feature tranche since V023** — begun the moment your V031 acceptance froze the ingestion contract. No review findings to close; this answers your next-tranche instruction. **No ingestion code was touched.**

## What was built

The evidence substrate, exactly to your list, holding exactly your boundary. Three attributable acts and nothing else:

**Observing** — `EvidenceItem`: a **verbatim** excerpt anchored to one or more Events through `EvidenceSourceRef`, which carries the event id, the event's **full `SourceRef`** and the event's own timestamp — evidence is self-standing, traceable without loading the event store, and `evidence_for_event()` walks the reverse direction. AT-012's founding done-when — *Observed cannot exist without a SourceRef* — is enforced at construction: an unanchored observation is **unconstructible**, not merely unstored.

**Claiming** — `EvidenceClaim`: an authored statement, optionally about a person as an **opaque `PersonRef`** — never a name. Claims are immutable: identity derives from the statement, so "editing" is authoring a new claim and the record of what was claimed, when, survives.

**Relating** — `EvidenceRelationship`: one authored judgement — `SUPPORTS` / `CONTRADICTS` / `CONTEXTUALISES` — with **declared** `EvidenceStrength` (`DIRECT` / `INDIRECT` / `CIRCUMSTANTIAL`). A non-direct strength **requires a stated basis**: the author's reasoning is part of the record, so a later reader weighs the judgement rather than inherits it. There is deliberately no number anywhere.

**The boundary you drew is structural.** No computed confidence, no scores, no patterns, no psychometrics, no "you are X" — normative in ADR-032, structural in the module catalogue's `must_not`, and cheaply guarded by an API-vocabulary scan worded per D-122 (it claims only what a syntax check proves). The old catalogue phrase "score confidence" for this package is explicitly **superseded**. Interpretive layers come later, on top, attributably — they never reach around the substrate.

**Identity, dedup, immutability.** Content-derived 32-hex identities (D-119 width from birth): same observation → same id → idempotent re-record; a chosen id that mismatches content is unconstructible; a re-record with divergent authorship metadata is a **refused integrity conflict**, never a silent choice. The port is **append-only by construction** — no update, delete, remove or purge exists in the contract or either engine, verified by structural scan. Corrections are new records.

**Storage and query contracts.** `EvidenceRepository` port; `InMemoryEvidenceStore` + `SqliteEvidenceStore`; **one contract suite against both**; evidence schema version 1 refuses a mismatched database from day one; every canonical field round-trips — multi-event anchors in order, unicode, `PersonRef` subjects, kind/strength/basis — and reopen preserves idempotency. Relationships enforce referential integrity: naming an absent claim or evidence record is a `LineageError`. Records never cross a workspace boundary.

## Gates (deterministic, this build; independent rerun required)

**558 passed** / 1 by-design skip of **559 deterministic tests** (34 new evidence tests) · 100% on **1761 statements / 516 branches**, `at_evidence` included at 100% from its first release · **53/53 mutants killed** (4 new: no-anchor evidence, swallowed conflict, basis-free indirect strength, SQLite dropping `basis`) · `ruff` + `mypy --strict` clean via exact CI commands · RTM **145 rules: 141 + 1 + 3** (RTM-141..145) · blocking package audit clean · integration 2/2 in this environment.

## Status honesty

`at-evidence` is **Partial**: the substrate exists; the six-status evidence model and every interpretive layer are **not built** and will sit on it. **AT-004 → Frozen/Maintenance** carrying your five-condition change rule verbatim. **AT-012 → In Progress.** Ingestion untouched: adapters, parsers, Events and id schemes are byte-for-byte V031's except the version stamps.

## Next on this substrate

The richer evidence statuses, then Timeline → Commitments → Questions, per your layering. `at-consent` still needs **DQ-012 and DQ-013**. **AT-056 remains Not started.**
