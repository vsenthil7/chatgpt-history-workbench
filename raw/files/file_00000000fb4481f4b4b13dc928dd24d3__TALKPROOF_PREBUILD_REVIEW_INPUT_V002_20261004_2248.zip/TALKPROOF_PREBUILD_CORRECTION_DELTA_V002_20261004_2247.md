# TalkProof — PREBUILD CORRECTION DELTA — V002

| Field | Value |
|---|---|
| **Created** | 2026-10-04 22:47 (Europe/London) |
| **Version** | V002 (first correction iteration; V001 package unchanged and retained) |
| **Status** | DOCS-ONLY CORRECTION RECORD — authorised by the PO 22:43 ("Go"); nothing coded; V6 unchanged; no V7; no FR/NFR/BR/CD/EV ID; no sprint; no scope change |
| **Source artifacts** | `reviews/TALKPROOF_PREBUILD_INDEPENDENT_REVIEW_CHATGPT_V001_20261004_2239.md`; V001 package; PO messages 22:02 and 22:43 |
| **Scope** | Every finding R-01..R-10 of the independent review, plus the two review instructions numbered 11 (offline status semantics) and 9 (WP-22) |
| **Explicit exclusions** | Recovery/V6 not reopened; D-06/D-18/D-21 not decided; unaffected V001 files not reissued |
| **Decisions consumed** | PO 22:43: V002 authorised; R-03 premise correction accepted (V6 records WhatsApp inbound at D3; V6 unchanged) |
| **Unresolved items** | Final independent gate on V001 + review V001 + this V002 delta; PO confirmation of the 22:02 authority; D-06, D-16 yes/no, D-18, D-21, PD-A, PD-B |
| **Change / provenance** | Produced by Claude (builder) in the V002 correction pass |

## 1. Finding → correction → file

| Review ID | Severity | Correction applied | Where (V002 file) | Status |
|---|---|---|---|---|
| R-01 | BLOCKER | The PO's 22:02 message reproduced verbatim as immutable provenance, with a line-by-line match check against the decision record (D-15, D-16 investigate, D-17, D-19, D-20, D-22 = 11/4/8/23, D-23, D-24, D-25, D-26; D-06/D-18/D-21 open). PO to confirm at the gate. | `TALKPROOF_PO_AUTHORITY_PROVENANCE_V001_20261004_2244.md` (new); `PO_DECISION_RECORD_V001` unchanged | DONE — PO confirmation pending |
| R-02 | MAJOR | CR-07 removed from the authorised analysis; its text quarantined as "Appendix Q — unauthorised post-D-16 draft"; CR-07 recorded as CONDITIONAL, condition NOT met; CR-12 kept (R-D performed). Counts 11/4/8 unchanged. | `CR_REQUIREMENTS_ANALYSIS_V002` | DONE |
| R-03 | MAJOR | **Premise corrected by agreement (PO 22:43):** V6 already records WhatsApp inbound at **D3** (V6-09), so no D-level changes. The evidence is now stated identically in all four artefacts: bare digest accepted (`routes/webhooks.py:57`), negative contract test missing, Meta GET `hub.verify_token` handshake absent, no Meta sample provenance. Primary D2; tally 25/20/0/1; D1 3 / D2 20 / D3 22 / D4 1; Config Resolver remains the single D4. V6 unchanged. | `TRACEABILITY_V002`, `ARCHITECTURE_RECONCILIATION_V002`, `SPRINT_TRACKER_RECONCILIATION_V002`, `BUILD_READINESS_GATE_V002` | DONE |
| R-04 | MAJOR | WP-10 rewritten against the full FR-080 contract: Redis token bucket; 100/min per authenticated user keyed per-tenant-per-user; 20/min per IP unauthenticated; `Retry-After`; health/metrics exempt; exact headers; admin CSRF double-submit; Flutter 429 backoff; negative test. The existing in-process IP fixed-window limiter is recorded as non-conformant and must not merely be wired. | `BUILD_READINESS_GATE_V002` (WP-10), `SPRINT_TRACKER_RECONCILIATION_V002` (category 2) | DONE |
| R-05 | MAJOR | HSTS conformance defect registered: code `max-age=31536000` (`core/security_middleware.py:24`) vs FR-080 `max-age=63072000; includeSubDomains`; added to S21 conformance (inside WP-10) with an exact-header test. | same two files | DONE |
| R-06 | MAJOR | WP-21 moved to NOT BUILD-READY, blocked on PD-A (BRD OOS-02 vs tracker BR-14); S34 authority noted as blocked in the sprint and architecture reconciliations; only the NFR-025 secret-default removal (WP-08) proceeds. | `BUILD_READINESS_GATE_V002`, `SPRINT_TRACKER_RECONCILIATION_V002`, `ARCHITECTURE_RECONCILIATION_V002` | DONE |
| R-07 | MAJOR | WP-23 removed from the coding batch; TC-1..TC-12 are preflight documentation reconciliation applied only after PO acceptance. | `BUILD_READINESS_GATE_V002`, `SPRINT_TRACKER_RECONCILIATION_V002` | DONE |
| R-08 | MAJOR | E-02 reworded as "structural compatibility hypothesis successfully prototyped; standards-conformant ERS encoding and real RFC 3161 verification remain unverified", with the explicit not-executed list (RFC 4998 ASN.1, RFC 6283, TSA transaction, `openssl ts -verify`, reduced hash tree artefact, timestamp renewal, hash-tree renewal, anchoring). Lifecycle §0 states T0/T1 is the proposed architecture, not demonstrated conformance. | `EVIDENCE_RESEARCH_PACK_V002`, `CERTIFICATE_LIFECYCLE_ARCHITECTURE_V002`, `CR_REQUIREMENTS_ANALYSIS_V002` (CR-07 note) | DONE |
| R-08 / instr. 11 | MAJOR | Offline status semantics corrected everywhere: a verifier proves status **as of the latest signed/anchored status artefact it holds**; it must say "current revocation status unknown without fresher status evidence"; verifier output split into integrity / TSA / anchor-or-unavailable / status-as-of / unknown-current. | `CERTIFICATE_LIFECYCLE_ARCHITECTURE_V002` (step 6), `EVIDENCE_RESEARCH_PACK_V002` (claim C6), `CR_REQUIREMENTS_ANALYSIS_V002` (CR-12) | DONE |
| R-09 | MINOR | Master Index reissued: inventory stated as 14 substantive files + 1 nested wrapper = 15 entries for V001; the V002 package inventory stated the same way with hashes; the V001 nested copies confirmed byte-identical by the reviewer. | `PREBUILD_MASTER_INDEX_V002` | DONE |
| R-10 | MINOR | One authoritative dependency statement and one corrected sequence in the build gate; batch-2 order declared to supersede any per-row order column where they differ. | `BUILD_READINESS_GATE_V002` | DONE |
| instr. 9 (WP-22) | — | NFR-057 = 80 % requirement floor; `fail_under=100` is the existing engineering policy and is **not** lowered; the action is to cover the 23 lines. | `BUILD_READINESS_GATE_V002`, `SPRINT_TRACKER_RECONCILIATION_V002` | DONE |

## 2. Corrected first coding batch (as agreed with the reviewer)

| Seq | WP | Sprint | Scope |
|---|---|---|---|
| 1 | WP-22 (corrected) | S24 policy | cover the 23 uncovered lines; 100 % engineering gate green; gate value unchanged |
| 2 | WP-13 | S02 | PostgreSQL RLS + dual-layer isolation tests |
| 3 | WP-01 | S03 | RS256 |
| 4 | WP-02 | S03/S10 | 30-min lockout; 120-min impersonation |
| 5 | WP-03 | S05 | audit-chain concurrency |
| 6 | WP-05 | S06 | vault read path / provider router |
| 7 | WP-08 | S21/S34 | remove development secret defaults |
| 8 | WP-09 | S21 | consent + DNC enforcement |
| 9 | WP-10 (corrected) | S21 | FR-080-conformant Redis token-bucket rate limiting + exact headers incl. HSTS 63072000 |

No D-06/D-16/D-18/D-21 work, no CR implementation, no new sprint, no new scope.

**Preflight (documentation):** PO confirms 22:02 authority → TC-1..TC-12 applied after PO acceptance → final independent gate V002 → PO build authorisation → coding.

## 3. Files in this package

| File | V001 / V002 | Why |
|---|---|---|
| TALKPROOF_PO_AUTHORITY_PROVENANCE_V001 | new | R-01 |
| TALKPROOF_PREBUILD_CORRECTION_DELTA_V002 | new | this record |
| TALKPROOF_CR_REQUIREMENTS_ANALYSIS_V002 | reissued | R-02, R-08 |
| TALKPROOF_EVIDENCE_RESEARCH_PACK_V002 | reissued | R-08, status semantics |
| TALKPROOF_CERTIFICATE_LIFECYCLE_ARCHITECTURE_V002 | reissued | R-08, status semantics |
| TALKPROOF_TRACEABILITY_V002 | reissued | R-03 |
| TALKPROOF_ARCHITECTURE_RECONCILIATION_V002 | reissued | R-03, R-06 |
| TALKPROOF_SPRINT_TRACKER_RECONCILIATION_V002 | reissued | R-03, R-04, R-05, R-06, R-07, WP-22 |
| TALKPROOF_BUILD_READINESS_GATE_V002 | reissued | R-04, R-05, R-06, R-07, R-10, WP-22 |
| TALKPROOF_PREBUILD_MASTER_INDEX_V002 | reissued | R-09 |
| TALKPROOF_PO_DECISION_RECORD_V001, BRD_REQUIREMENT_RECONCILIATION_V001, REMAINING_PO_DECISIONS_V001, REQUIREMENTS_RECONCILIATION_V001 | unchanged V001 | no finding touched them |
| e02_prototype.py, e02_output.txt | unchanged | retained evidence (its *interpretation* is corrected in the evidence pack) |
| reviews/TALKPROOF_PREBUILD_INDEPENDENT_REVIEW_CHATGPT_V001_20261004_2239.md | immutable input | review placed at the reviewer's recommended path `docs/92_planning/reviews/` |

## 4. Governance totals
V6 changed: NO · V7: NO · Code changed: NO · IDs issued: 0 · Sprints created: 0 · PO decisions applied: 0 (recorded/provenanced only) · Scope change: NONE · D-levels changed: NONE.
