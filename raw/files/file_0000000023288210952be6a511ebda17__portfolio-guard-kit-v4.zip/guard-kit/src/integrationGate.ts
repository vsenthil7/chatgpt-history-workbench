/**
 * Integration gate (external review PPLX V001 §6 S19 — P-DM-001 as a standing check).
 *
 * The review's central finding was not a defect in any module. It was a whole class
 * of module that did not exist: every boundary to the outside world — Drive, Docs,
 * Sheets, the OAuth token endpoint, e-sign delivery, the Apps Script host, Postgres —
 * was an exported interface with only test doubles behind it. Coverage cannot see a
 * file that was never written, and the more boundaries are injected the cleaner the
 * number gets. Four instruments reported green; none was pointed at the absence.
 *
 * This gate is pointed at the absence. For every exported BEHAVIOURAL interface (one
 * that declares at least one method) and every exported function-type alias, it
 * requires a non-test implementation somewhere in the runtime source: a class that
 * `implements` it, a value annotated with it, or a factory that returns it. An
 * interface with none is reported, unless an exemption names the file outside `src/`
 * that implements it (the Apps Script sidebar shim is the legitimate case) and that
 * file exists — the same rule RG-06 applies to coverage exemptions: a claim must point
 * at evidence that is there.
 *
 * Honest limit, as with the other gates: text heuristics over source, not a type
 * checker. It finds the P-DM-001 shape. Passing means every behavioural boundary has
 * SOMETHING production-shaped behind it, not that the implementation is correct — the
 * boot test, the contract suite and live verification cover that.
 */

export interface IntegrationGateInput {
  /** Runtime source path -> contents (src/**\/*.ts, excluding tests). */
  sourceFiles: Record<string, string>;
  /** Every repository-relative path that exists, to validate exemption targets. */
  repoFiles: string[];
  /**
   * Interface name -> where it is implemented outside the TypeScript source, and why.
   * `implementedIn` names a repository file; `implementedBy` names a declared runtime
   * dependency (e.g. `pg` implements `PoolLike`). Exactly one of the two.
   */
  exemptions?: Record<string, IntegrationExemption>;
  /** Declared runtime dependencies, to validate `implementedBy`. */
  dependencies?: string[];
}

export interface IntegrationExemption {
  reason: string;
  implementedIn?: string;
  implementedBy?: string;
}

export interface BoundaryDeclaration {
  name: string;
  kind: 'interface' | 'function_type';
  file: string;
  methods: string[];
}

export interface IntegrationFinding {
  id: 'IG-01' | 'IG-02';
  severity: 'CRITICAL' | 'HIGH';
  boundary: string;
  where: string;
  what: string;
  why: string;
}

export interface IntegrationReport {
  boundaries: BoundaryDeclaration[];
  /** boundary name -> files that implement it. */
  implementations: Record<string, string[]>;
  findings: IntegrationFinding[];
  ok: boolean;
}

const INTERFACE_RE = /export\s+interface\s+([A-Z][A-Za-z0-9_]*)\s*(?:<[^>]*>)?\s*(?:extends\s+[^{]+)?\{/g;
// `= (...) =>` only: a parenthesised union `= ('a' | 'b')[number]` is data, not a boundary.
const FUNCTION_TYPE_RE = /export\s+type\s+([A-Z][A-Za-z0-9_]*)\s*(?:<[^>]*>)?\s*=\s*\([^)]*\)\s*=>/g;
// The type-parameter list allows one level of nesting: `query<T = Record<string, unknown>>(`
// (SqlClient — the Postgres boundary the review named) was invisible to `<[^>]*>`.
const METHOD_RE = /^\s*(?:readonly\s+)?([a-zA-Z_$][\w$]*)\s*(?:<(?:[^<>]|<[^<>]*>)*>)?\s*\([^)]*\)\s*:/gm;

function stripComments(source: string): string {
  return source.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
}

/** The `{ … }` body starting at `openIndex`, brace-balanced. */
function bodyFrom(text: string, openIndex: number): string {
  let depth = 0;
  for (let i = openIndex; i < text.length; i++) {
    if (text[i] === '{') depth += 1;
    else if (text[i] === '}') {
      depth -= 1;
      if (depth === 0) return text.slice(openIndex + 1, i);
    }
  }
  return text.slice(openIndex + 1);
}

/** Exported interfaces with at least one method, plus exported function-type aliases. */
export function findBoundaries(sourceFiles: Record<string, string>): BoundaryDeclaration[] {
  const out: BoundaryDeclaration[] = [];
  for (const [file, raw] of Object.entries(sourceFiles)) {
    const text = stripComments(raw);
    for (const m of text.matchAll(INTERFACE_RE)) {
      const body = bodyFrom(text, m.index! + m[0].length - 1);
      const methods = [...body.matchAll(METHOD_RE)].map((mm) => mm[1]);
      if (methods.length > 0) {
        out.push({ name: m[1], kind: 'interface', file, methods });
      }
    }
    for (const m of text.matchAll(FUNCTION_TYPE_RE)) {
      out.push({ name: m[1], kind: 'function_type', file, methods: ['(call)'] });
    }
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}

/** Files in which `name` has an implementation-shaped use (not merely a type in a signature). */
export function findImplementations(name: string, sourceFiles: Record<string, string>): string[] {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const signals: RegExp[] = [
    // class Foo implements Name, class Foo implements A, Name
    new RegExp(`\\bimplements\\b[^{]*\\b${escaped}\\b`),
    // const x: Name = …  /  private readonly x: Name = …  (a value bound to the type)
    new RegExp(`:\\s*${escaped}(?:<[^>]*>)?\\s*=[^=>]`),
    // function make(...): Name {   /  (...): Name => {   (a factory that returns it)
    new RegExp(`\\)\\s*:\\s*${escaped}(?:<[^>]*>)?\\s*(?:\\{|=>)`),
    // as Name  (an object literal asserted to be one)
    new RegExp(`\\bas\\s+${escaped}\\b`),
    // satisfies Name
    new RegExp(`\\bsatisfies\\s+${escaped}\\b`),
  ];
  const files: string[] = [];
  for (const [file, raw] of Object.entries(sourceFiles)) {
    const text = stripComments(raw);
    if (signals.some((re) => re.test(text))) files.push(file);
  }
  return files.sort();
}

export function checkIntegrationCoverage(input: IntegrationGateInput): IntegrationReport {
  const boundaries = findBoundaries(input.sourceFiles);
  const present = new Set(input.repoFiles.map((f) => f.replace(/^\.\//, '')));
  const implementations: Record<string, string[]> = {};
  const findings: IntegrationFinding[] = [];
  const exemptions = input.exemptions ?? {};

  for (const boundary of boundaries) {
    const impls = findImplementations(boundary.name, input.sourceFiles);
    implementations[boundary.name] = impls;
    if (impls.length > 0) continue;
    const exemption = exemptions[boundary.name];
    if (exemption === undefined) {
      findings.push({
        id: 'IG-01',
        severity: 'CRITICAL',
        boundary: boundary.name,
        where: `${boundary.file} :: ${boundary.kind} ${boundary.name}`,
        what: `Exported ${boundary.kind === 'interface' ? 'interface' : 'function type'} with no non-test implementation in the runtime source.`,
        why:
          'Every caller of this boundary is fully tested against a double and nothing production-shaped ' +
          'stands behind it. Coverage cannot report this: a file that was never written has no lines to ' +
          'leave uncovered (P-DM-001). Implement it, or exempt it naming the file outside src/ that does.',
      });
    } else {
      const problem = exemptionProblem(exemption, present, new Set(input.dependencies ?? []));
      if (problem !== undefined) {
        findings.push({
          id: 'IG-02',
          severity: 'HIGH',
          boundary: boundary.name,
          where: `${boundary.file} :: exemption for ${boundary.name}`,
          what: `The exemption for ${boundary.name} ${problem}.`,
          why: 'An exemption is a claim; this one points at evidence that is not in the repository (the RG-06 rule).',
        });
      }
    }
  }
  for (const name of Object.keys(exemptions)) {
    if (!boundaries.some((b) => b.name === name)) {
      findings.push({
        id: 'IG-02',
        severity: 'HIGH',
        boundary: name,
        where: `exemptions :: ${name}`,
        what: 'An exemption names a boundary that is not an exported behavioural interface.',
        why: 'Stale exemptions accumulate into a list nobody reads; remove it or fix the name.',
      });
    }
  }
  return { boundaries, implementations, findings, ok: findings.length === 0 };
}

function exemptionProblem(
  exemption: IntegrationExemption,
  present: Set<string>,
  dependencies: Set<string>
): string | undefined {
  if (exemption.implementedIn !== undefined) {
    return present.has(exemption.implementedIn.replace(/^\.\//, ''))
      ? undefined
      : `names '${exemption.implementedIn}', which does not exist`;
  }
  if (exemption.implementedBy !== undefined) {
    return dependencies.has(exemption.implementedBy)
      ? undefined
      : `names package '${exemption.implementedBy}', which is not a declared runtime dependency`;
  }
  return 'names neither a file nor a package';
}

export function renderIntegrationReport(report: IntegrationReport): string {
  const lines = [
    `Integration gate: ${report.ok ? 'PASS' : 'FAIL'} — ${report.boundaries.length} behavioural boundaries, ${report.findings.length} finding(s).`,
  ];
  for (const b of report.boundaries) {
    const impls = report.implementations[b.name];
    lines.push(`  ${b.name.padEnd(28)} ${impls.length > 0 ? `<- ${impls.join(', ')}` : '(no implementation)'}`);
  }
  for (const f of report.findings) {
    lines.push(`  ${f.severity.padEnd(8)} ${f.id}  ${f.where}\n           ${f.what}\n           ${f.why}`);
  }
  return lines.join('\n');
}

/**
 * The boundaries this product implements outside TypeScript. Each names the file, and
 * the gate fails if that file is missing.
 */
export const DOCMERGE_INTEGRATION_EXEMPTIONS: Record<string, IntegrationExemption> = {
  SidebarHost: {
    implementedIn: 'apps-script/Code.gs',
    reason: 'The Apps Script sidebar shim (getActiveRowData over SpreadsheetApp) is the production SidebarHost; S15.',
  },
  PoolLike: { implementedBy: 'pg', reason: 'node-postgres Pool; constructed in main.productionAdapters().' },
  PoolClientLike: { implementedBy: 'pg', reason: 'node-postgres PoolClient, checked out by PgSqlClient.transaction().' },
  Handler: {
    implementedIn: 'src/app.ts',
    reason: 'Route handlers are inline closures registered through Router.add in buildApp(); every route is exercised by tests/app.test.ts and the boot test.',
  },
  LoadWorker: {
    implementedIn: 'scripts/synthetic-monitor.js',
    reason: 'The load harness drives an injected worker by design (R-D9); the deployed service is exercised by the synthetic monitor, and real load numbers are owed against staging (LC-1).',
  },
};
