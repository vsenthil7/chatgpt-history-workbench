/**
 * Release-integrity gate (external review findings CGPT-DM-002, CGPT-DM-004, CGPT-DM-012).
 *
 * The other four modules in this kit catch defects in the product. This one catches
 * defects in the evidence ABOUT the product, which is a different and quieter problem:
 * a CI pipeline can be wrong in ways that make every number it reports meaningless, and
 * nothing in the product's own tests will ever notice.
 *
 * Two real examples from DocMerge Pro, both found by an external reviewer after two
 * clean internal passes and a tenant sweep:
 *
 *   - Every CI job installed with `npm ci`, and the repository had no lockfile. `npm ci`
 *     refuses to run without one, so no job in that workflow had ever completed on a
 *     clean checkout. The "836 tests at 100% coverage" figure was true, and had only ever
 *     been produced on one developer's machine. Nothing was lying; nothing was verified
 *     either.
 *
 *   - The deploy job ran `echo "deploy step placeholder"` and exited zero. `main` showed
 *     a green deploy for five sprints that had deployed nothing. This is the same shape
 *     as a feature that is fully built, fully tested and called from nowhere — the thing
 *     exists, the signal is green, and the two facts are unrelated.
 *
 * Two more, from the second external review (PPLX V001, 16 Sep 2026), both found by
 * EXECUTING what the documents described rather than reading them:
 *
 *   - `npm start` ran `node dist/server.js`; that module exported `start()` and nothing
 *     called it. The process exited 0 with no port open (P-DM-002). RG-05 checks that a
 *     declared start script points at a module that actually invokes something.
 *
 *   - The one coverage exemption in the repository said "verified by booting the
 *     server", and the server had never been booted (P-DM-010). RG-06 requires every
 *     coverage-ignore pragma to name the test that is its compensating control, and
 *     requires that test to exist. Exemptions are claims; claims need evidence.
 *
 * The honest limit, same as `tenantGate`: this is a source-text check over workflow
 * files, not a simulation of the runner. It finds the common shapes. A passing gate means
 * those shapes are absent, not that the pipeline is correct.
 */

export type ReleaseSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';

export interface ReleaseFinding {
  id: string;
  severity: ReleaseSeverity;
  /** Workflow file, and job where one could be identified. */
  where: string;
  what: string;
  /** Why this matters — kept on the finding so a report is readable without this file. */
  why: string;
}

export interface ReleaseGateInput {
  /** Workflow filename -> file contents. */
  workflows: Record<string, string>;
  /** Repository-relative paths that actually exist. Used to test install claims. */
  repoFiles: string[];
  /**
   * Job name fragments that imply the job DOES something outside CI. A placeholder in one
   * of these is a false green; a placeholder in a scratch job is only untidy.
   */
  actionJobHints?: string[];
  /** Contents of package.json — enables RG-05 (a start script whose entrypoint invokes nothing). */
  packageJson?: string;
  /** Source path -> contents, for RG-05 (entrypoint) and RG-06 (coverage exemptions). */
  sourceFiles?: Record<string, string>;
}

/** `node dist/x.js` -> the source module it was compiled from. */
export function entrypointSourceFor(startScript: string): string | undefined {
  const m = /\bnode\s+(?:--[\w-]+(?:=\S+)?\s+)*(\S+\.[cm]?js)\b/.exec(startScript);
  if (m === null) return undefined;
  return m[1].replace(/^\.\//, '').replace(/^dist\//, 'src/').replace(/\.[cm]?js$/, '.ts');
}

/**
 * Does the module do anything when loaded? A column-0 call, `void call()`, or the
 * `require.main === module` guard all count. A file of exports and declarations does
 * not. Deliberately a text heuristic, consistent with the rest of this gate.
 */
export function moduleInvokesSomething(source: string): boolean {
  if (/require\.main\s*===\s*module/.test(source)) return true;
  const stripped = source.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  return /^(?:void\s+|await\s+)?[A-Za-z_$][\w$.]*\s*\(/m.test(stripped);
}

const COVERAGE_PRAGMA_RE = /\/\*\s*(?:istanbul|c8|v8)\s+ignore\b[^*]*\*\//g;
const VERIFIED_BY_RE = /verified-by:\s*([\w./-]+)/;

const DEFAULT_ACTION_HINTS = [
  'deploy', 'publish', 'release', 'promote', 'migrate', 'provision', 'upload', 'notify', 'rollout',
];

/** Install commands that REQUIRE a lockfile, and the file each one requires. */
const LOCKED_INSTALLS: Array<{ pattern: RegExp; lockfile: string; command: string }> = [
  { pattern: /\bnpm\s+ci\b/, lockfile: 'package-lock.json', command: 'npm ci' },
  { pattern: /\byarn\s+(?:install\s+)?--frozen-lockfile\b/, lockfile: 'yarn.lock', command: 'yarn --frozen-lockfile' },
  { pattern: /\bpnpm\s+(?:install|i)\b[^\n]*--frozen-lockfile\b/, lockfile: 'pnpm-lock.yaml', command: 'pnpm --frozen-lockfile' },
];

const SUPPLY_CHAIN_SIGNALS = [
  /\bnpm\s+audit\b/, /\byarn\s+audit\b/, /\bpnpm\s+audit\b/,
  /\bsbom\b/i, /\bcyclonedx\b/i, /\bsyft\b/,
  /\bcodeql\b/i, /\bsemgrep\b/, /\bsnyk\b/, /\btrivy\b/,
  /secret[-_ ]?scan/i, /\bgitleaks\b/i, /\btrufflehog\b/i,
];

interface Step {
  job: string;
  run: string;
  uses: string;
}

/**
 * Deliberately a small indentation-aware scan rather than a YAML parser: this kit has no
 * dependencies, and a workflow unusual enough to defeat this is unusual enough to read.
 */
function extractSteps(text: string): Step[] {
  const steps: Step[] = [];
  const lines = text.split('\n');
  let inJobs = false;
  let job = '(top level)';
  let pending: Step | undefined;
  let blockIndent: number | undefined;

  const flush = () => {
    if (pending !== undefined) steps.push(pending);
    pending = undefined;
    blockIndent = undefined;
  };

  for (const raw of lines) {
    const line = raw.replace(/\t/g, '  ');
    const indent = line.length - line.trimStart().length;
    const trimmed = line.trim();

    // Continuation of a `run: |` block.
    if (blockIndent !== undefined && pending !== undefined) {
      if (trimmed === '' || indent >= blockIndent) {
        pending.run += '\n' + trimmed;
        continue;
      }
      flush();
    }

    if (/^jobs:\s*$/.test(trimmed)) {
      inJobs = true;
      continue;
    }
    if (inJobs && indent === 2 && /^[A-Za-z0-9_-]+:\s*$/.test(trimmed)) {
      flush();
      job = trimmed.slice(0, -1);
      continue;
    }

    const runBlock = trimmed.match(/^-?\s*run:\s*[|>][-+]?\s*$/);
    if (runBlock !== null) {
      flush();
      pending = { job, run: '', uses: '' };
      blockIndent = indent + 2;
      continue;
    }
    const runInline = trimmed.match(/^-?\s*run:\s*(.+)$/);
    if (runInline !== null) {
      flush();
      steps.push({ job, run: runInline[1].trim(), uses: '' });
      continue;
    }
    const uses = trimmed.match(/^-?\s*uses:\s*(.+)$/);
    if (uses !== null) {
      flush();
      steps.push({ job, run: '', uses: uses[1].trim() });
      continue;
    }
  }
  flush();
  return steps;
}

/** True when every command in the step is an echo, a comment, or a no-op. */
function isPlaceholderRun(run: string): boolean {
  const commands = run
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l !== '' && !l.startsWith('#'));
  if (commands.length === 0) return false;
  return commands.every((c) => /^(echo\b|:$|true$)/.test(c));
}

/** True when the step, having only echoed, then fails on purpose. */
function failsDeliberately(run: string): boolean {
  return /\bexit\s+[1-9]\d*\b/.test(run) || /::error::/.test(run);
}

export function checkReleaseIntegrity(input: ReleaseGateInput): ReleaseFinding[] {
  const findings: ReleaseFinding[] = [];
  const hints = input.actionJobHints ?? DEFAULT_ACTION_HINTS;
  const present = new Set(input.repoFiles.map((f) => f.replace(/^\.\//, '')));
  let anySupplyChain = false;
  let anyCoverage = false;
  let anyArtifactUpload = false;

  for (const [file, text] of Object.entries(input.workflows)) {
    const steps = extractSteps(text);

    for (const step of steps) {
      const body = `${step.run}\n${step.uses}`;

      for (const install of LOCKED_INSTALLS) {
        if (install.pattern.test(step.run) && !present.has(install.lockfile)) {
          findings.push({
            id: 'RG-01',
            severity: 'CRITICAL',
            where: `${file} :: ${step.job}`,
            what: `\`${install.command}\` installs from ${install.lockfile}, and ${install.lockfile} is not in the repository.`,
            why:
              'This job cannot have completed on a clean checkout — the install step fails before anything ' +
              'is built or tested. Any coverage or test figure attributed to CI was produced somewhere else.',
          });
        }
      }

      if (
        step.run !== '' &&
        isPlaceholderRun(step.run) &&
        !failsDeliberately(step.run) &&
        hints.some((h) => step.job.toLowerCase().includes(h))
      ) {
        findings.push({
          id: 'RG-02',
          severity: 'HIGH',
          where: `${file} :: ${step.job}`,
          what: 'A job that implies an external action contains only an echo, and exits zero.',
          why:
            'The job reports success without doing anything, so the pipeline displays a green result for ' +
            'work that never happened. Either implement it or make it fail closed with the blocker named.',
        });
      }

      if (SUPPLY_CHAIN_SIGNALS.some((re) => re.test(body))) anySupplyChain = true;
      if (/--coverage\b|\bnyc\b|\bcoverage\b/.test(step.run)) anyCoverage = true;
      if (/upload-artifact|actions\/cache/.test(step.uses)) anyArtifactUpload = true;
    }
  }

  if (Object.keys(input.workflows).length > 0 && !anySupplyChain) {
    findings.push({
      id: 'RG-03',
      severity: 'MEDIUM',
      where: 'all workflows',
      what: 'No dependency audit, secret scan, SBOM or static-analysis step in any workflow.',
      why:
        'Nothing in the pipeline would notice a committed credential or a vulnerable transitive ' +
        'dependency. These are cheap to add and are asked for by every enterprise security review.',
    });
  }

  if (input.packageJson !== undefined) {
    let startScript: string | undefined;
    try {
      const pkg = JSON.parse(input.packageJson) as { scripts?: Record<string, string> };
      startScript = pkg.scripts?.start;
    } catch {
      startScript = undefined;
    }
    if (startScript !== undefined) {
      const entry = entrypointSourceFor(startScript);
      const source = entry === undefined ? undefined : input.sourceFiles?.[entry];
      if (entry === undefined || source === undefined) {
        findings.push({
          id: 'RG-05',
          severity: 'CRITICAL',
          where: `package.json :: scripts.start = "${startScript}"`,
          what: `The start script's entrypoint (${entry ?? 'unrecognised'}) is not among the supplied source files.`,
          why:
            'A start script that points at a module which is not in the repository, or is built from ' +
            'nowhere, cannot start the service. The documented way to run the product does not exist.',
        });
      } else if (!moduleInvokesSomething(source)) {
        findings.push({
          id: 'RG-05',
          severity: 'CRITICAL',
          where: `package.json :: scripts.start -> ${entry}`,
          what: 'The start script points at a module that exports functions and invokes none of them.',
          why:
            '`node` loads the module, finds nothing to run, and exits 0. The service reports a clean ' +
            'start to whatever launched it and serves nothing. This was P-DM-002: the fail-closed ' +
            'readiness check most relied on by the deployment documents lived inside a function nothing called.',
        });
      }
    }
  }

  for (const [path, source] of Object.entries(input.sourceFiles ?? {})) {
    for (const pragma of source.match(COVERAGE_PRAGMA_RE) ?? []) {
      const verifiedBy = VERIFIED_BY_RE.exec(pragma)?.[1];
      if (verifiedBy === undefined) {
        findings.push({
          id: 'RG-06',
          severity: 'HIGH',
          where: `${path} :: ${pragma.trim()}`,
          what: 'A coverage exemption that names no compensating control.',
          why:
            'An exemption is a claim that something else verifies this code. Without naming that something, ' +
            'the claim cannot be checked — and the one such claim in this repository ("verified by booting ' +
            'the server") described a verification that had never been performed (P-DM-010).',
        });
      } else if (!present.has(verifiedBy)) {
        findings.push({
          id: 'RG-06',
          severity: 'HIGH',
          where: `${path} :: ${pragma.trim()}`,
          what: `The named compensating control (${verifiedBy}) does not exist in the repository.`,
          why: 'The exemption points at evidence that is not there. Either add the test or remove the exemption.',
        });
      }
    }
  }

  if (anyCoverage && !anyArtifactUpload) {
    findings.push({
      id: 'RG-04',
      severity: 'LOW',
      where: 'all workflows',
      what: 'Coverage is computed in CI but never published as an artifact.',
      why:
        'A coverage number nobody outside the run can retrieve is a claim rather than evidence. ' +
        'Publishing it attaches the figure to a run instead of to a sentence in a document.',
    });
  }

  return findings;
}

export function renderReleaseReport(findings: ReleaseFinding[]): string {
  if (findings.length === 0) return 'Release-integrity gate: no findings.';
  const order: ReleaseSeverity[] = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
  const sorted = [...findings].sort((a, b) => order.indexOf(a.severity) - order.indexOf(b.severity));
  const lines = sorted.map((f) => `${f.severity.padEnd(8)} ${f.id}  ${f.where}\n         ${f.what}\n         ${f.why}`);
  return [`Release-integrity gate: ${findings.length} finding(s).`, ...lines].join('\n');
}
