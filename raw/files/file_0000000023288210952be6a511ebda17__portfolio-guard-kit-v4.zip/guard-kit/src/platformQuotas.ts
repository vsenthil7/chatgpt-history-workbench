/**
 * Platform quotas (verification finding VER-DM6).
 *
 * VERIFIED against live Google documentation, 13 Sep 2026. The Docs API allows 60 write
 * requests per minute per user per project, and 600 per minute across the project. Our
 * ST-087 p95 budget promises a generated document every 1500ms and the ST-088 load test
 * drives 100 requests per minute at a single surface and reports PASS.
 *
 * Both are promises the platform will not honour. One user cannot exceed one document
 * per second however fast our code is; past 60 in a minute they receive 429s and our own
 * backoff makes the p95 worse, not better. The load test was measuring an injected worker,
 * so it never touched the ceiling it was supposed to prove we could reach.
 *
 * This module holds the verified numbers and a feasibility check that fails the build
 * when an internal target exceeds an external quota — so an SLO cannot quietly promise
 * something the platform forbids.
 *
 * RE-VERIFIED 20 Sep 2026 (S17) against Google's own published usage-limits pages.
 * Docs read/write and Sheets read still match what was recorded on 13 Sep 2026, so only
 * their verifiedOn dates moved. DRIVE CHANGED: the migration recorded as VER-DM7 has
 * completed on the published page, which now states the quota-unit model outright
 * (1,000,000 units per minute per project, 325,000 per user per project, an edit costing
 * 50 units) and says projects that used the API between Nov 2025 and Apr 2026 keep their
 * previous quotas. The 12,000-queries figure is no longer what Google publishes, so it
 * has been replaced and `changeNote` records what moved and why.
 *
 * `verifiedOn` is per-quota and is only moved when the figure was actually re-read at a
 * primary source. A quota that could not be re-reached carries `unverified: true` with
 * the date of the attempt, because refreshing a date nobody checked is precisely the
 * class of defect this table exists to catch.
 */

export interface PlatformQuota {
  api: string;
  operation: 'read' | 'write';
  perMinutePerUser: number;
  perMinutePerProject: number;
  source: string;
  /** ISO date on which this figure was last read at a primary source. */
  verifiedOn: string;
  /**
   * True when the last attempt to reach the primary source failed. The figure is kept
   * (a stale verified number beats a guess) but nothing may present it as current.
   */
  unverified?: boolean;
  /** What changed at the last re-verification, when the published figure moved. */
  changeNote?: string;
  /**
   * Set when the published figure is not stable — for example an API mid-migration
   * between quota models. A quota we cannot rely on is worse than one we know is tight,
   * because it invites planning against a number that may not apply to our project.
   */
  caveat?: string;
}

/** The date of the most recent re-verification sweep across this table. */
export const QUOTA_REVERIFICATION_DATE = '2026-09-20';

/**
 * THE `verifiedOn` DATES BELOW ARE SELF-ASSERTED AND HAVE NO CACHED EVIDENCE BEHIND THEM.
 *
 * Read this before you cite a figure in this table to anyone outside the team. Each row
 * says it was read at a primary source on a date; nothing in this repository records that
 * the fetch happened. There is no cached page, no HTTP response, no retrieval timestamp,
 * no checksum — only `source`, which is a URL a human typed, and `verifiedOn`, which is a
 * date a human typed next to it. An auditor cannot distinguish this table from one where
 * the dates were simply advanced, and neither can the next engineer, and neither can I.
 * That is exactly the defect class the `unverified` flag above was added to catch, and it
 * applies to the dates themselves.
 *
 * This note is deliberately not backed up with evidence invented after the fact. Nothing
 * was re-fetched to write it.
 *
 * What a future re-verification should do instead: for every figure it touches, record
 * (1) the exact source URL fetched, (2) the figure as retrieved, verbatim, and (3) the
 * date — all three together, so the date is a claim about a fetch that left a trace
 * rather than a claim about someone's memory. Until that exists, treat `verifiedOn` as
 * "when someone says they last looked", not as evidence that they did.
 *
 * Re-check before launch regardless; Google republishes these.
 */
export const PLATFORM_QUOTAS: PlatformQuota[] = [
  {
    api: 'docs',
    operation: 'write',
    perMinutePerUser: 60,
    perMinutePerProject: 600,
    source: 'Docs API usage limits (developers.google.com/workspace/docs/api/limits)',
    verifiedOn: '2026-09-20',
  },
  {
    api: 'docs',
    operation: 'read',
    perMinutePerUser: 300,
    perMinutePerProject: 3000,
    source: 'Docs API usage limits (developers.google.com/workspace/docs/api/limits)',
    verifiedOn: '2026-09-20',
  },
  {
    /**
     * VER-DM7, UPDATED 20 Sep 2026. The ambiguity recorded on 13 Sep 2026 has resolved:
     * the published page now states the quota-unit model as the model, not as one of two.
     * It gives 1,000,000 quota units per minute per project and 325,000 per minute per
     * user per project, and prices an edit at 50 units. 325,000 / 50 = 6,500 edits per
     * minute for one user, and 1,000,000 / 50 = 20,000 for the project. Those are the
     * figures recorded here; the arithmetic is written down rather than rounded to
     * something comfortable, and DRIVE_QUOTA_UNITS below carries the published inputs so
     * the derivation can be re-checked without re-reading this comment.
     *
     * The caveat stays, and is now about a different thing: the page states that projects
     * which used the API between Nov 2025 and Apr 2026 keep their previous quotas, so the
     * figure that applies to OUR project depends on when it first called Drive.
     *
     * The practical conclusion is unchanged and is the useful part: on either model Drive
     * is FAR above the Docs ceiling of 60 writes per minute per user, so filing is not the
     * binding constraint on a batch — document creation is. A test asserts that, so a
     * future quota change which reverses it surfaces rather than silently slowing runs.
     */
    api: 'drive',
    operation: 'write',
    perMinutePerUser: 6_500,
    perMinutePerProject: 20_000,
    source:
      'Drive API usage limits, quota-unit model effective 1 May 2026 (developers.google.com/workspace/drive/api/guides/limits)',
    verifiedOn: '2026-09-20',
    changeNote:
      'Was 12,000 queries per 60s per user (recorded 13 Sep 2026 as the conservative figure of two competing models). Google now publishes the quota-unit model alone: 325,000 units/min/user at 50 units per edit = 6,500 edits/min/user, and 1,000,000 units/min/project = 20,000 edits/min/project.',
    caveat:
      'Projects that called the Drive API between Nov 2025 and Apr 2026 retain their previous quotas, so the figure that applies depends on the project. Re-verify for the actual project before relying on this.',
  },
  {
    api: 'sheets',
    operation: 'read',
    perMinutePerUser: 60,
    perMinutePerProject: 300,
    source: 'Sheets API usage limits (developers.google.com/workspace/sheets/api/limits)',
    verifiedOn: '2026-09-20',
  },
];

/**
 * The published Drive inputs the recorded request-equivalents are derived from, so the
 * division above can be re-checked rather than believed.
 */
export const DRIVE_QUOTA_UNITS = {
  perMinutePerProject: 1_000_000,
  perMinutePerUser: 325_000,
  /** Published per-method cost of an edit (a file create or update). */
  unitsPerEdit: 50,
  verifiedOn: '2026-09-20',
} as const;

/** Apps Script limits that bound the form forwarder shipped for VER-DM2. */
export const APPS_SCRIPT_LIMITS = {
  urlFetchPerDayConsumer: 20_000,
  urlFetchPerDayWorkspace: 100_000,
  /** Re-read at the primary source on this date; both figures unchanged. */
  verifiedOn: '2026-09-20',
} as const;

/**
 * The MECHANISM here is portable across products; the NUMBERS are not. A sibling on
 * Zoho, Xero or Stripe passes its own verified table rather than inheriting Google's.
 */
export function quotaFor(
  api: string,
  operation: 'read' | 'write',
  quotas: PlatformQuota[] = PLATFORM_QUOTAS
): PlatformQuota {
  const quota = quotas.find((q) => q.api === api && q.operation === operation);
  if (quota === undefined) {
    throw new Error(`No verified quota recorded for ${api} ${operation} — check before assuming one`);
  }
  return quota;
}

export interface Promise_ {
  /** What we tell customers or assert in a test. */
  name: string;
  api: string;
  operation: 'read' | 'write';
  /** Operations per minute the promise implies, for one user. */
  impliedPerMinutePerUser: number;
}

export interface FeasibilityFinding {
  promise: string;
  implied: number;
  allowed: number;
  message: string;
}

/**
 * Fails when an internal promise implies more throughput than the platform permits.
 * Deliberately compares against the PER-USER quota: a batch belongs to one customer, and
 * the project-wide ceiling does not help a single user going too fast.
 */
export function checkFeasibility(
  promises: Promise_[],
  quotas: PlatformQuota[] = PLATFORM_QUOTAS
): { ok: boolean; findings: FeasibilityFinding[] } {
  const findings: FeasibilityFinding[] = [];
  for (const p of promises) {
    const quota = quotaFor(p.api, p.operation, quotas);
    if (p.impliedPerMinutePerUser > quota.perMinutePerUser) {
      findings.push({
        promise: p.name,
        implied: p.impliedPerMinutePerUser,
        allowed: quota.perMinutePerUser,
        message:
          `${p.name} implies ${p.impliedPerMinutePerUser} ${p.api} ${p.operation}s per minute for one user, ` +
          `but the platform allows ${quota.perMinutePerUser}. The promise cannot be kept.`,
      });
    }
  }
  return { ok: findings.length === 0, findings };
}

/**
 * Paces work to stay inside a per-user quota. Being throttled by Google costs a round
 * trip and a backoff; pacing ourselves costs only the wait, and keeps the customer's
 * remaining quota available for their other tools.
 */
export class QuotaGovernor {
  private readonly timestamps = new Map<string, number[]>();

  constructor(
    private readonly perMinutePerUser: number,
    private readonly now: () => number = Date.now
  ) {}

  /** Milliseconds to wait before the next operation for this user; 0 when clear. */
  delayFor(accountId: string): number {
    const nowTs = this.now();
    const windowStart = nowTs - 60_000;
    const recent = (this.timestamps.get(accountId) ?? []).filter((t) => t > windowStart);
    this.timestamps.set(accountId, recent);
    if (recent.length < this.perMinutePerUser) {
      return 0;
    }
    // The oldest call in the window frees a slot 60s after it happened.
    return Math.max(0, recent[0] + 60_000 - nowTs);
  }

  /** Record an operation against the user's budget. */
  record(accountId: string): void {
    const list = this.timestamps.get(accountId) ?? [];
    list.push(this.now());
    this.timestamps.set(accountId, list);
  }

  usedInWindow(accountId: string): number {
    const windowStart = this.now() - 60_000;
    return (this.timestamps.get(accountId) ?? []).filter((t) => t > windowStart).length;
  }

  /** Honest completion estimate for a batch of a given size, in milliseconds. */
  estimateCompletionMs(rows: number): number {
    if (rows <= this.perMinutePerUser) {
      return 0;
    }
    const fullMinutes = Math.floor((rows - 1) / this.perMinutePerUser);
    return fullMinutes * 60_000;
  }
}


/**
 * Which API throttles a batch first. Generation touches Docs (write), Sheets (read) and
 * Drive (write) per row, so the slowest per-user ceiling governs the whole run.
 */
export function bindingConstraint(quotas: PlatformQuota[] = PLATFORM_QUOTAS): PlatformQuota {
  return quotas.reduce((tightest, q) => (q.perMinutePerUser < tightest.perMinutePerUser ? q : tightest));
}

/** Quotas whose published value we cannot currently rely on. */
export function unstableQuotas(quotas: PlatformQuota[] = PLATFORM_QUOTAS): PlatformQuota[] {
  return quotas.filter((q) => q.caveat !== undefined);
}

/** Quotas whose last re-verification attempt did not reach a primary source. */
export function unverifiedQuotas(quotas: PlatformQuota[] = PLATFORM_QUOTAS): PlatformQuota[] {
  return quotas.filter((q) => q.unverified === true);
}

/** Quotas whose published figure moved at the last re-verification. */
export function changedQuotas(quotas: PlatformQuota[] = PLATFORM_QUOTAS): PlatformQuota[] {
  return quotas.filter((q) => q.changeNote !== undefined);
}

/**
 * How a quota may be cited in customer-facing copy. A figure nobody could re-read is
 * still usable for planning, but it must not be presented as current — so the caller is
 * handed the wording rather than left to invent it.
 */
export function citationFor(quota: PlatformQuota): string {
  const base = `${quota.source}, verified ${quota.verifiedOn}`;
  return quota.unverified === true
    ? `${base} — LAST ATTEMPT FAILED, figure carried forward unverified`
    : base;
}
