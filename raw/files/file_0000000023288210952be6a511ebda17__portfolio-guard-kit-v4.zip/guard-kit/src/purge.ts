/**
 * Account purge (cold-review fix DM-F09).
 *
 * The review found `executeDue(deleter)` taking a callback that no production code
 * supplied. The published policy says account data is deleted 30 days after uninstall;
 * nothing deleted anything. This is the single most repeated defect across the
 * portfolio — five sibling products breached the same published promise, each because
 * deletion cleared the account row and left everything hanging off it.
 *
 * The fix is a registry rather than a function: every store that holds account data
 * registers itself, `verifyRegistration` fails the build when a known store is absent,
 * and a purge returns a per-store count so the deletion can be evidenced rather than
 * asserted.
 */

export interface PurgeTarget {
  /** Store name as it appears in the schema and the retention policy. */
  name: string;
  /** Removes every record for the account; returns how many rows went. */
  purge: (accountId: string) => Promise<number> | number;
}

export interface PurgeReceipt {
  accountId: string;
  at: number;
  /** Rows removed per store — the evidence a reviewer or regulator asks for. */
  removed: Record<string, number>;
  totalRemoved: number;
  /** Stores that threw; a partial purge must be visible, never silently "done". */
  failures: Array<{ store: string; error: string }>;
  complete: boolean;
}

/**
 * Every store that can hold account-scoped data. Keeping the list here — rather than
 * inferring it — means adding a store without adding it to the registry is a visible
 * omission rather than an invisible one.
 */
export const KNOWN_ACCOUNT_STORES = [
  'oauth_tokens',
  'accounts',
  'templates',
  'template_rules',
  'batch_jobs',
  'sign_requests',
  'filing_configs',
  'form_triggers',
  'subscriptions',
  'invoices',
  'audit_entries',
  'admin_audit_entries',
  'telemetry_events',
  'usage_counters',
  'support_conversations',
  'notification_mutes',
  // S16 (P-DM-009): the durable stores. A new table without a purge target fails here.
  'sign_request_signers',
  'webhook_deliveries',
  'ledger_entries',
  'ledger_anchors',
  'batch_job_checkpoints',
  'rate_limit_windows',
  'sessions',
  'deletion_jobs',
] as const;

export type KnownStore = (typeof KNOWN_ACCOUNT_STORES)[number];

export class PurgeRegistry {
  private readonly targets = new Map<string, PurgeTarget>();

  constructor(private readonly now: () => number = Date.now) {}

  register(target: PurgeTarget): void {
    if (this.targets.has(target.name)) {
      throw new Error(`Purge target '${target.name}' is already registered`);
    }
    this.targets.set(target.name, target);
  }

  registered(): string[] {
    return [...this.targets.keys()].sort();
  }

  /**
   * Fails when a known store has no purge target. Run as a test, so shipping a new
   * store without wiring its deletion breaks the build rather than the policy.
   */
  verifyRegistration(known: readonly string[] = KNOWN_ACCOUNT_STORES): { ok: boolean; missing: string[] } {
    const missing = known.filter((name) => !this.targets.has(name));
    return { ok: missing.length === 0, missing };
  }

  /**
   * Purges every registered store. A store that throws is recorded and the rest still
   * run — a failure in one table must not leave the other fifteen untouched — but the
   * receipt is marked incomplete so nobody can claim the deletion finished.
   */
  async purgeAccount(accountId: string): Promise<PurgeReceipt> {
    const removed: Record<string, number> = {};
    const failures: Array<{ store: string; error: string }> = [];
    for (const [name, target] of this.targets) {
      try {
        removed[name] = await target.purge(accountId);
      } catch (err) {
        failures.push({ store: name, error: (err as Error).message });
      }
    }
    return {
      accountId,
      at: this.now(),
      removed,
      totalRemoved: Object.values(removed).reduce((a, n) => a + n, 0),
      failures,
      complete: failures.length === 0,
    };
  }
}

/** Convenience: a purge target over any Map keyed by id with an accountId field. */
export function mapPurgeTarget<T>(
  name: string,
  map: Map<string, T>,
  /** Defaults to a value.accountId field; pass an accessor for stores keyed BY account id. */
  accountIdOf: (value: T, key: string) => string | undefined = (v) =>
    (v as { accountId?: string }).accountId
): PurgeTarget {
  return {
    name,
    purge: (accountId: string) => {
      let removed = 0;
      for (const [key, value] of [...map]) {
        if (accountIdOf(value, key) === accountId) {
          map.delete(key);
          removed += 1;
        }
      }
      return removed;
    },
  };
}
