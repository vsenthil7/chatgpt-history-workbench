/**
 * Signature-claims gate (external review P-DM-007, S16).
 *
 * The product was described as e-sign while producing no signature. The rename to
 * "Approval requests" fixes the copy that exists today; this gate keeps the next
 * sprint's copy honest. It scans the user-facing sources — help centre, listing,
 * launch surfaces, the hosted site and LISTING_PACK.md — for phrases that claim a
 * signature product, and a repository test asserts the count is zero.
 *
 * It is a text check with word boundaries, not a parser. `esign_requests` (a screen
 * id) and `designer` are not claims; "e-sign", "esign" as a word, "e-signature" and
 * "sent for signature" are. An allowlist exists for exactly one purpose: the sentence
 * that tells the user the feature is NOT e-sign, which necessarily names it.
 */

export interface SignatureClaim {
  file: string;
  line: number;
  phrase: string;
  text: string;
}

/** Phrases that assert an e-signature product. Case-insensitive, word-bounded. */
export const SIGNATURE_CLAIM_PATTERNS: ReadonlyArray<{ phrase: string; pattern: RegExp }> = [
  { phrase: 'e-sign', pattern: /\be-sign\b/i },
  { phrase: 'esign', pattern: /\besign\b/i },
  { phrase: 'e-signature', pattern: /\be-signatures?\b/i },
  { phrase: 'electronic signature', pattern: /\belectronic signatures?\b/i },
  { phrase: 'legally binding', pattern: /\blegally[- ]binding\b/i },
  { phrase: 'signed PDF', pattern: /\bsigned pdf\b/i },
  { phrase: 'certificate of completion', pattern: /\bcertificate of completion\b/i },
  { phrase: 'for signature', pattern: /\bfor (?:e-)?signature\b/i },
  { phrase: 'signature request', pattern: /\bsignature requests?\b/i },
  { phrase: 'signature tracking', pattern: /\bsignature tracking\b/i },
  { phrase: 'fully signed', pattern: /\bfully signed\b/i },
];

/**
 * The ONLY permitted exceptions: lines that disclaim e-sign. A line is allowed when it
 * contains one of these negations, which no marketing sentence would.
 */
export const DISCLAIMER_ALLOWLIST: ReadonlyArray<RegExp> = [
  /\bare not electronic signatures\b/i,
  /\bnot e-sign(?:atures?)?\b/i,
  /\bdoes not produce a signed document\b/i,
  /\buse a dedicated e-signature service\b/i,
];

/** Files the gate is expected to cover; the repository test asserts each is present. */
export const CLAIM_SCOPE_FILES = [
  'src/helpCenter.ts',
  'src/listing.ts',
  'src/launchSurfaces.ts',
  'src/site.ts',
  'LISTING_PACK.md',
  // S19 (DM-F34/DM-F36): these leave the building too. DATA_FLOW_AND_RETENTION.md is the
  // privacy/CASA pack and claims to be generated from src/security.ts; the pen-test
  // documents are sent to an external vendor. Both described a signature product for four
  // days after the feature was renamed, because the gate's scope was drawn around the
  // marketplace listing rather than around everything a third party reads.
  'DATA_FLOW_AND_RETENTION.md',
  'PENTEST_SCOPING_BRIEF.md',
  'PENTEST_OUTREACH.md',
] as const;

/**
 * A reference to the MODULE `src/esign.ts` is a code path, not a claim to a customer.
 * S16 kept the TypeScript identifiers deliberately — renaming every symbol would have
 * been churn with no honesty gained — so the file name survives in engineering documents
 * that list modules. Kept separate from `DISCLAIMER_ALLOWLIST`, which is only ever
 * negations: exempting a line because it DISCLAIMS a signature and exempting it because
 * it NAMES A FILE are different arguments, and merging them would let a future entry
 * excuse a real claim under cover of the disclaimer rule. Narrow on purpose — it matches
 * a path with its extension, never the bare word.
 */
export const CODE_REFERENCE_ALLOWLIST: ReadonlyArray<RegExp> = [/\besign(?:Ops|Provider)?\.(?:ts|test\.ts)\b/i];

/**
 * True when the only signature-ish token on the line is a module path. The line is
 * re-scanned with the paths removed, so a sentence that names a module AND makes a real
 * claim is still a claim.
 */
export function isCodeReference(line: string): boolean {
  if (!CODE_REFERENCE_ALLOWLIST.some((re) => re.test(line))) {
    return false;
  }
  const withoutPaths = line.replace(/\b[\w/.-]*esign[\w/.-]*\.(?:ts|test\.ts)\b/gi, '');
  return !SIGNATURE_CLAIM_PATTERNS.some(({ pattern }) => pattern.test(withoutPaths));
}

export function isDisclaimer(line: string): boolean {
  return DISCLAIMER_ALLOWLIST.some((re) => re.test(line));
}

/** Scans `files` (name -> contents) and returns every claim that is not a disclaimer. */
export function findSignatureClaims(files: Record<string, string>): SignatureClaim[] {
  const claims: SignatureClaim[] = [];
  for (const [file, contents] of Object.entries(files)) {
    contents.split('\n').forEach((text, index) => {
      // An import path (`from './esign'`) is a module name, not something a user reads.
      if (isDisclaimer(text) || isCodeReference(text) || /^\s*import\s/.test(text)) {
        return;
      }
      for (const { phrase, pattern } of SIGNATURE_CLAIM_PATTERNS) {
        if (pattern.test(text)) {
          claims.push({ file, line: index + 1, phrase, text: text.trim() });
        }
      }
    });
  }
  return claims;
}

/** Human-readable report for CI output. */
export function renderClaimsReport(claims: SignatureClaim[]): string {
  if (claims.length === 0) {
    return 'Signature claims: PASS — no e-sign claim in user-facing copy (P-DM-007).';
  }
  const lines = [`Signature claims: FAIL — ${claims.length} claim(s) in user-facing copy (P-DM-007).`, ''];
  for (const c of claims) {
    lines.push(`  ${c.file}:${c.line}  "${c.phrase}"  ${c.text}`);
  }
  return lines.join('\n');
}
