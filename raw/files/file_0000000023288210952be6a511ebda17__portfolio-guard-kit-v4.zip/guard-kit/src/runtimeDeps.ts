/**
 * Runtime-dependency gate (external review P-DM-003).
 *
 * `scripts/migrate.js` required `pg`. `package.json` had no `dependencies` block at all.
 * Nothing noticed, because the only path anyone ran returned before the `require`, and
 * because `npm ci` installs devDependencies too — so a module that was a devDependency
 * (or, here, not declared anywhere) resolves on every developer machine and in every
 * CI job, and fails only in the production image built with `npm ci --omit=dev`.
 *
 * This gate resolves every non-builtin, non-relative import in the runtime source
 * (`src/` and `scripts/`) against `dependencies` ONLY:
 *
 *   - imported and not declared anywhere            -> `undeclared`  (fails)
 *   - imported and declared only in devDependencies -> `dev_only`    (fails)
 *   - declared in dependencies and never imported   -> `unused`      (warns)
 *
 * Type-only imports are excluded: TypeScript erases them, so they are not runtime.
 * Test files are excluded by the caller: a test may import anything in devDependencies.
 */
import { builtinModules } from 'node:module';

export type RuntimeDepProblemKind = 'undeclared' | 'dev_only' | 'unused';

export interface RuntimeDepProblem {
  kind: RuntimeDepProblemKind;
  packageName: string;
  /** Files that import it (empty for `unused`). */
  files: string[];
  severity: 'fail' | 'warn';
  explanation: string;
}

export interface RuntimeDepsInput {
  /** Runtime source path -> contents. */
  files: Record<string, string>;
  packageJson: string;
}

export interface RuntimeDepsReport {
  ok: boolean;
  problems: RuntimeDepProblem[];
  /** package -> files, for the report and for the SBOM assertion (P-DM-004). */
  imports: Record<string, string[]>;
}

const BUILTINS: ReadonlySet<string> = new Set(builtinModules);

/**
 * Statement forms (`import … from`, `import '…'`, `export … from`) are anchored to a
 * statement start — line start or `;` — because `\bimport` alone also matches the WORD
 * inside a string literal: `keywords: ['import', 'migrate']` in `helpCenter.ts` read as a
 * side-effect import of a package named `, ` and failed the gate (DM-F25). Expression
 * forms (`require(…)`, `import(…)`) keep the bare word boundary.
 */
const IMPORT_RES: RegExp[] = [
  /(?:^|;)\s*import\s+(?!type\b)[^'"]*?\bfrom\s*['"]([^'"]+)['"]/gm,
  /(?:^|;)\s*import\s*['"]([^'"]+)['"]/gm,
  /(?:^|;)\s*export\s+(?:\*|\{[^}]*\})\s*from\s*['"]([^'"]+)['"]/gm,
  /\brequire\s*\(\s*['"]([^'"]+)['"]\s*\)/g,
  /\bimport\s*\(\s*['"]([^'"]+)['"]\s*\)/g,
];

/** `@scope/name/deep` -> `@scope/name`; `name/deep` -> `name`. */
export function packageNameOf(specifier: string): string {
  const parts = specifier.split('/');
  return specifier.startsWith('@') ? parts.slice(0, 2).join('/') : parts[0];
}

export function isExternalSpecifier(specifier: string): boolean {
  if (specifier.startsWith('.') || specifier.startsWith('/')) return false;
  if (specifier.startsWith('node:')) return false;
  return !BUILTINS.has(packageNameOf(specifier));
}

function stripComments(source: string): string {
  return source.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
}

/** All external package names a file imports at runtime. */
export function externalImportsOf(source: string): string[] {
  const text = stripComments(source);
  const names = new Set<string>();
  for (const re of IMPORT_RES) {
    for (const m of text.matchAll(re)) {
      if (isExternalSpecifier(m[1])) names.add(packageNameOf(m[1]));
    }
  }
  return [...names].sort();
}

export function checkRuntimeDeps(input: RuntimeDepsInput): RuntimeDepsReport {
  const pkg = JSON.parse(input.packageJson) as {
    dependencies?: Record<string, string>;
    devDependencies?: Record<string, string>;
  };
  const deps = new Set(Object.keys(pkg.dependencies ?? {}));
  const devDeps = new Set(Object.keys(pkg.devDependencies ?? {}));

  const imports: Record<string, string[]> = {};
  for (const [file, source] of Object.entries(input.files)) {
    for (const name of externalImportsOf(source)) {
      (imports[name] ??= []).push(file);
    }
  }

  const problems: RuntimeDepProblem[] = [];
  for (const [name, files] of Object.entries(imports).sort(([a], [b]) => a.localeCompare(b))) {
    if (deps.has(name)) continue;
    if (devDeps.has(name)) {
      problems.push({
        kind: 'dev_only',
        packageName: name,
        files,
        severity: 'fail',
        explanation:
          `'${name}' is imported by runtime code but declared only in devDependencies. It resolves in CI ` +
          'and fails in a production install (`npm ci --omit=dev`).',
      });
    } else {
      problems.push({
        kind: 'undeclared',
        packageName: name,
        files,
        severity: 'fail',
        explanation:
          `'${name}' is imported by runtime code and declared nowhere. It resolves only if something else ` +
          'happened to install it — which is how the migration path crashed on `Cannot find module` (P-DM-003).',
      });
    }
  }
  for (const name of [...deps].sort()) {
    if (imports[name] === undefined) {
      problems.push({
        kind: 'unused',
        packageName: name,
        files: [],
        severity: 'warn',
        explanation: `'${name}' is a declared runtime dependency that no runtime file imports. Remove it or use it.`,
      });
    }
  }
  return { ok: problems.every((p) => p.severity !== 'fail'), problems, imports };
}

export function renderRuntimeDepsReport(report: RuntimeDepsReport): string {
  const lines = [
    `Runtime-deps gate: ${report.ok ? 'PASS' : 'FAIL'} — ${Object.keys(report.imports).length} runtime package(s) imported.`,
  ];
  for (const [name, files] of Object.entries(report.imports)) {
    lines.push(`  uses ${name}  <- ${files.join(', ')}`);
  }
  for (const p of report.problems) {
    lines.push(`  ${p.severity.toUpperCase().padEnd(4)} ${p.kind.padEnd(10)} ${p.packageName}: ${p.explanation}`);
  }
  return lines.join('\n');
}
