# Portfolio guard kit — v4

**v4 (20 September 2026)** adds three modules and two rules, all from a second external
review of DocMerge Pro (PPLX V001) that executed the code instead of reading it. Its
central finding was not a defect in a module — it was a whole category of module that did
not exist. Every boundary to the outside world was an exported interface with only test
doubles behind it: no Google client of any kind, no HTTP client, no database driver, no
add-on manifest. `npm start` started nothing and exited 0. `npm run migrate` crashed on
`Cannot find module 'pg'`. The SBOM's 280 components were entirely devDependencies, so the
supply-chain evidence covered a runtime tree that was empty.

**Coverage was 100% throughout, and could not have found any of it.** A file that was
never written has no lines to leave uncovered — and the more boundaries you inject, the
cleaner the number gets. That is the sentence to carry to the sibling products.

Eight self-contained modules, each with its test,, no dependencies and no imports between them, that catch
classes of defect which passed review in DocMerge Pro and are very likely present in the
sibling products. Drop them in, wire the tests into CI, and fix what they find.

They exist because of a specific, repeated pattern: **DocMerge sat at 100% test coverage
across two clean internal review passes, and a verification sweep then found six findings
in six checks — three of them live-blocking.** Coverage proved every unit executed. It
could not prove the units were wired together, that callers were entitled to what they
asked for, or that the platform would honour what we promised.

## What each module catches

### `tenantGate.ts` — authorisation, not authentication

Scans source for methods that accept an entity id and act on it with **no tenant
parameter**. Configure the tenant parameter names and id suffixes for your product.

Caught in DocMerge (all of it after a clean review):

| Finding | What it was |
| --- | --- |
| DM-F16 | Template lookups took a `templateId` and nothing else, and the HTTP route read that id **from the request body** — so any authenticated user could render another tenant's template. |
| DM-F17 | Same shape on signature requests, exposing signer names and emails. |
| DM-F21 | `pause`/`resume` on requests, triggers and jobs took only an entity id — one tenant could halt another's work with a guessed id. |

The distinction worth internalising: **session authentication establishes *who* is asking.
Nothing in it establishes *what they may ask for*.** Having the first made the second look
done.

The gate also supports **exemptions with reasons** and a meta-gate,
`unverifiedExemptions()`, that fails the build when an exemption is added without a test
naming it. That matters: in DocMerge one exemption was *right about its outcome and wrong
about its reason* (DM-F22), which is the version that survives a security review
unchallenged.

### `ledger.ts` — unbounded growth

A FIFO-bounded append store that **counts evictions rather than dropping silently**.
DocMerge had eleven append-only arrays — telemetry, audit entries, captured errors,
invoices, surveys. Each is fine on day one and each ends with a process dying at an
inconvenient hour.

One subtlety worth copying: if a **hash-chained** audit log is bounded, the chain can no
longer verify from genesis. The digest of the last evicted entry becomes the anchor, and
verification reports truncation rather than failing — an audit log that silently forgot
entries would be worse than one that admits it.

### `purge.ts` — deletion that actually deletes

A registry enumerating every store holding account data, with `verifyRegistration()`
failing the build when a known store has no purge target. Receipts carry **per-store row
counts** as evidence, and a partial purge is reported as **incomplete** rather than
claimed as success.

DocMerge's `executeDue(deleter)` took a callback that no production code supplied — the
published 30-day deletion policy had nothing behind it. Memory shows this exact defect
breached the published policy in five sibling products, which is why it is in this kit.

Pair it with `ON DELETE CASCADE` in the schema, so completeness is a property of the
database rather than of code someone must remember to update.

### `platformQuotas.ts` — promises the platform will not keep

Records verified quotas **with their sources**, refuses to guess an unrecorded one, and
fails when an internal promise exceeds an external limit. `QuotaGovernor` paces per
account and gives an honest completion estimate.

In DocMerge the Docs API allows **60 writes per minute per user**, while the SLO promised
a document every 1500ms and the load test drove 100/min and reported PASS — because it
drove an injected worker and never touched the ceiling. A 500-row batch for one customer
cannot finish in under eight minutes, a fact absent from every estimate written before the
check.

**The mechanism ports; the numbers do not.** Pass your platform's verified table:

```ts
const zohoQuotas = [
  { api: 'crm', operation: 'write', perMinutePerUser: 10, perMinutePerProject: 100, source: 'Zoho API limits' },
];
checkFeasibility([{ name: 'Bulk sync', api: 'crm', operation: 'write', impliedPerMinutePerUser: 50 }], zohoQuotas);
```

### `releaseGate.ts` — evidence that was never produced

Added 13 September 2026 after an **external** review found three defects that four
internal passes, a tenant sweep and a platform verification sweep had all missed. The
other four modules check the product. This one checks the evidence *about* the product,
which fails more quietly.

| Finding | What it was |
| --- | --- |
| CGPT-DM-004 | Every CI job installed with `npm ci` and the repository had **no lockfile**. `npm ci` refuses to run without one, so no job in that workflow had ever completed on a clean checkout. The "836 tests at 100% coverage" figure was true and had only ever been produced on one laptop. |
| CGPT-DM-002 | The deploy job ran `echo "deploy step placeholder"` and **exited zero**. `main` showed a green deploy for five sprints that deployed nothing. |
| CGPT-DM-012 | No SBOM, audit, secret scan or static analysis anywhere. Nothing would have noticed a committed credential. |

The first is the one worth internalising. **A pipeline that cannot run is indistinguishable
from a pipeline that passes, if nobody reads the logs.** Coverage gates, tenant gates and
quota gates are all worth exactly nothing when the install step in front of them fails —
and the product's own tests will never tell you, because they run fine locally.

Four rules, over workflow text plus the list of files that actually exist:

- **RG-01** — an install command that requires a lockfile, and no lockfile in the repo. CRITICAL.
- **RG-02** — a job whose name implies an external action (`deploy`, `publish`, `release`, `migrate`…) whose steps are only `echo`, and which does not fail on purpose. HIGH. A placeholder that exits 1 with the blocker named is fine; a placeholder that exits 0 is a false green.
- **RG-03** — no audit, secret scan, SBOM or static analysis in any workflow. MEDIUM.
- **RG-04** — coverage computed and never uploaded. LOW: a number nobody can retrieve is a claim, not evidence.

`tests/releaseGate.test.ts` ships with the DocMerge pre-review workflow as a fixture, so
the gate is proved against the real defect rather than an invented one, and it also runs
against the host repository's own `.github/workflows` — which is the part that makes it a
standing check rather than something that was true once.

### `integrationGate.ts` — the boundary that never got an implementation

**The highest-value module in this kit, and the newest.** For every exported *behavioural*
interface (one that declares at least one method) and every exported function-type alias,
it requires a non-test implementation somewhere in the runtime source: a class that
`implements` it, a value annotated with it, a factory that returns it. An interface with
none is reported — unless an exemption names the file outside the TypeScript source that
implements it (an Apps Script shim), or the runtime dependency that does (`pg` implements
a `PoolLike`), *and that file or package actually exists*.

This is the C-01 class taken one level further. C-01 is a module nobody calls. This is a
module that was never written, while its interface stood in for it in every signature, and
every caller was tested against a double and passed.

What it found on its first run against DocMerge, after seven sprints of remediation had
already landed:

| Boundary | What was behind it |
| --- | --- |
| `PaymentGateway` | Injected since S6. `BILLING_PROVIDER` and `STRIPE_SECRET_KEY` in the environment contract. **No code had ever sent a request to Stripe.** |
| `LicenseProbe` | Created by VER-DM1 to detect uninstall, because the Marketplace pushes no webhook. Never implemented, so uninstall was undetectable. |
| `SqlClient` | Not even *recognised* as a boundary at first — see the self-defect below. |

Then it caught two stubs written **in the same hour as the fix**: `async () => undefined`
standing in for "where is this account's Stripe enrolment" and "what is its Marketplace
customer id". Those became a real module and a migration. Catching the class on the day it
is written, rather than three days later by an outsider, is the whole point of a gate over
a sweep.

It also found a defect in itself, which is worth copying verbatim as a warning: the method
regex `<[^>]*>` could not match `query<T = Record<string, unknown>>(`, so `SqlClient` — the
database boundary the review had explicitly named — was silently not a boundary at all. **A
gate with a blind spot reports PASS, not ERROR.** Test your gate against the defect it was
built for, and then against the awkward syntax in your own codebase.

### `runtimeDeps.ts` — the dependency that resolves everywhere except production

Resolves every non-builtin import in the runtime source against `dependencies` **only**:

- imported and declared nowhere → `undeclared` (fails)
- imported and declared only in `devDependencies` → `dev_only` (fails)
- declared and never imported → `unused` (warns)

DocMerge's `scripts/migrate.js` required `pg`; `package.json` had no `dependencies` block
at all. It went unnoticed for months for two compounding reasons: `npm ci` installs
devDependencies too, so the module resolves on every laptop and in every CI job and fails
only in an image built with `--omit=dev`; and the only code path anyone had ever run
returned *before* the `require`, because without `DATABASE_URL` the script prints its plan
and exits 0.

Pair it with the SBOM assertion that the **runtime** component count is greater than zero.
A supply-chain gate reporting "0 advisories across 280 components" is a statement about
Jest and TypeScript if every one of those components is development-time. Treat that zero
as *unmeasured*, not clean.

### `claimsGate.ts` — a published claim with no code behind it

Scans user-facing copy for phrases the product cannot back, with two separately-argued
exemption lists: disclaimers (which must be negations) and code references (a module path
is not a claim). Ships configured for the signature vocabulary because that is where it was
born, and the patterns are the part you replace per product.

DocMerge's "e-sign" feature was a well-built notification state machine that produced **no
signature artefact, no cryptographic binding of signer intent to a document hash, no signer
authentication and no consent capture** — and the marketplace listing, the help centre and
the public site all sold it as e-signature. Unlike most instances of this class, that one
has consequences outside the product: a customer relying on a "completed" signature in a
dispute has nothing to produce. The honest fix was a one-day rename to "approval requests"
across every surface; the gate is what stops it coming back.

Two things it taught in its first week, both worth having:

1. It failed a *new* sentence written by someone who had just read the whole codebase and
   still typed "signature request". Vocabulary drifts back without a mechanical check.
2. Its scope was originally drawn around the marketplace listing. Widening it to everything
   a third party reads caught the privacy/CASA data-flow pack and both pen-test documents
   still describing a signature product four days after the rename — two of which are sent
   to external parties. **Draw the scope around the reader, not around the artefact.**

### `releaseGate.ts` — two more rules (v4)

- **RG-05** — a declared `start` script whose entrypoint module invokes nothing. `node`
  loads it, finds nothing to run, exits 0, and whatever launched it records a clean start.
  DocMerge shipped this for five sprints; the fail-closed readiness check that every
  deployment document relied on lived inside a function nothing called.
- **RG-06** — a coverage-ignore pragma with no named compensating control, or one naming a
  test that does not exist. DocMerge's single exemption said "verified by booting the
  server". **The server had never been booted**, and that exemption was the one place the
  coverage gate was not looking — which is exactly where the defect was. This generalises
  the DM-F22 lesson from tenant-gate exemptions to every gate: an exemption is a claim, and
  a claim needs evidence that can be checked.

## Wiring it in

1. Copy `src/*.ts` into the product. They have no imports, so nothing else comes with them.
2. Copy `tests/tenantGate.test.ts` and point `repoSources()` at that product's `src`. Every
   module in `src/` now ships with its test — v3 shipped three modules without one, which
   was the kit quietly failing its own standard.
3. Add to CI as its own step so a failure is legible:

```yaml
- run: npx jest tests/tenantGate.test.ts
- run: npx jest tests/releaseGate.test.ts
- run: npx jest tests/integrationGate.test.ts
- run: npm run build && node scripts/runtime-deps.js
```

Run the integration gate **first** on an unfamiliar codebase. It is the cheapest way to
find out whether the product you are looking at is integrated or only tested, and on this
portfolio's evidence it should be expected to fire.

4. Point `releaseGate.test.ts` at that repo's `.github/workflows` and pass the paths that
   really exist. Expect RG-01 to fire somewhere: the missing-lockfile defect was found in
   the most reviewed codebase in the portfolio, by an outsider, on the first look.
5. Run it once and **triage before exempting**. In DocMerge the first run flagged 28
   methods: five clusters were genuine, the rest legitimately scoped by construction.
   Exempting without triage converts the gate into decoration.

## Before you port this: there are three of these

`PORTFOLIO_DEFECT_CLASSES.md`, added 15 September 2026, sets fifteen recurring defect
classes against the four products reviewed so far and maps which package catches which.
The finding it produces is worth reading before adopting anything here:

**Three portable gate packages now exist for one portfolio**, built independently within
days of each other — `at-review-gates v1.0.0` (RevRescue), the five gates in TeleField's
`docs/REVIEW_GATES.md`, and this kit. They overlap, **none is a superset**, and each
product is adopting a different subset. So a class caught in one product stays live in
another purely because the gate that finds it was packaged elsewhere.

v3 of this README named two classes the kit did not cover, both among the most common in
the portfolio: **orphan modules** (built, tested, called from nowhere) and **published
claims with no code behind them**. v4 closes the second outright with `claimsGate`, and
comes at the first from the other side: `integrationGate` finds the *interface with no
implementation* rather than the *implementation with no caller*. They are complements, not
substitutes — RevRescue's reachability gate is still the one that finds an orphan, and
merging the three packages is still the highest-value portfolio task available. It needs no
live environment, no decision and no budget.

## The honest limits

- `tenantGate` and `releaseGate` are **source-text checks, not type checks**. Unusual formatting can fool
  it. It is a net for the common shape, not a proof.
- A passing gate means the shape is absent, not that authorisation is correct. It finds
  the mistake nobody meant to make, not a deliberate mistake.
- `releaseGate` reads workflow files with a small indentation scan rather than a YAML
  parser, because this kit has no dependencies. A workflow unusual enough to defeat it is
  unusual enough to read by hand.
- The defect-class register is synthesised from session records, **not** from re-reading
  the sibling codebases. Every "probably also present" in it is a hypothesis, and the kit
  has still never been run against a sibling — which is what would turn the list into
  evidence either way.
- `integrationGate`, `runtimeDeps` and `claimsGate` are the same kind of check: **text over
  source, not a type checker or a linker**. `integrationGate` in particular cannot tell a
  real implementation from a convincing stub — it proves something production-shaped
  exists, not that it works. The boot test, the contract suite and live verification are
  what cover that, and on DocMerge the live half is still owed.
- `claimsGate`'s patterns are the signature vocabulary. They are the part that does not
  port: replace them with the claims **your** product makes and cannot back.
- **A gate is not proof, and an assertion is not necessarily a constraint.** An adversarial
  pass on 20 September — run against DocMerge after every external-review finding was closed
  and every gate here was green — found twelve more problems. Four mattered, and two are new
  classes for the register: a **published policy with no executor** (a durable deletion
  schedule, a complete purge registry, and nothing calling `due()`), and **assertions that
  constrain nothing** (`expect(url).toBe(\`${CONST}…\`)` compares the constant to itself, so
  changing `drive/v3` to `drive/v2` left 1486 tests green). Neither is catchable by anything
  in this kit. The first needs the question "what runs the loop?"; the second needs mutation
  testing. **Run a mutation pass on your security- and contract-critical constants before you
  trust any figure this kit reports.**
- **`integrationGate` asks whether a boundary HAS an implementation. It cannot ask whether
  anything INVOKES it.** That is the gap DM-F41 lived in, and it is why this kit still needs
  RevRescue's reachability gate rather than replacing it.
- The quota numbers in `platformQuotas.ts` were re-verified on **20 September 2026** against
  Google's published limits. Docs and Sheets matched exactly. The Drive write quota had
  **changed**: Google now publishes the quota-unit model alone (1,000,000 units/min/project,
  325,000/min/user, 50 units per edit), so the previously recorded 12,000 queries/60s/user
  is no longer a published figure and was replaced by the derived request-equivalents, with
  a test asserting the numbers equal the division rather than a hand-typed literal.
  **Re-verify before launch anyway** — the whole point of the module is not trusting a
  remembered figure, including one remembered from last week.
