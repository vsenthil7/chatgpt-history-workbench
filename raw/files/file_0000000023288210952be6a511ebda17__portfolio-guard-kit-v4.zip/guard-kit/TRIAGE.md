# Triaging the first run

The first run against a mature codebase will flag more than you expect. DocMerge flagged
28 methods; five clusters were genuine and the rest were legitimately scoped. Working
through them took about an hour and produced two real defects nobody had noticed.

Ask these in order.

**1. Can a caller reach this method with an id they did not obtain legitimately?**
If the id arrives in a request body, a URL, or a webhook payload — yes. Those are the
dangerous ones. DM-F16 was exactly this: the HTTP route took a `templateId` from the body.

**2. Is the protection real, or does it merely exist somewhere nearby?**
A repository primitive is fine *if* every caller goes through a layer that checks
ownership. Verify that claim by listing the callers — do not assume it. In DocMerge one
caller had been bypassing the check.

**3. Does the exemption reason describe what is actually true?**
DM-F22 was an exemption that was right about its outcome and wrong about its reason: it
claimed callers passed namespaced keys, and two did not. The protection came from
somewhere else entirely. A reason that sounds plausible survives review indefinitely.

**4. Is this a defect or a product decision?**
Metrics that aggregate across tenants are a defect if surfaced per-customer and correct if
internal. Log those as open decisions rather than fixing them blind — and add a test
asserting they are not currently reachable from any route, which is what keeps the
decision a decision.

**5. Control operations count.**
The manual sweep that preceded the gate checked reads and missed `pause`/`resume`. Halting
another tenant's work is a denial of service that needs nothing but a guessed id.

## What to do with the output

- Fix anything reachable from an external input first.
- Namespace keyed utilities centrally rather than at each call site, so a new caller
  cannot forget.
- Report cross-tenant access as **not found**, not as **forbidden** — otherwise the id
  space can be probed for what exists.
- Write the exemption, then write the test that proves it, then move on.

---

## Triaging `releaseGate` (added 13 Sep 2026)

Shorter than the tenant gate, because there are fewer legitimate reasons to be flagged.

**RG-01 — install requires a lockfile that is absent.** There is no triage. Either the
lockfile is gitignored, in which case remove it from the ignore list and commit it, or it
was never generated. Until it is committed, every green result that workflow has ever
shown came from somewhere other than the runner.

**RG-02 — an action job that only echoes.** One question: does anyone read this
pipeline's result as meaning the action happened? If yes it is a false green and must
either be implemented or made to fail with the blocker named in the message. A placeholder
that exits 1 is honest and is not flagged. Note that making it fail turns the branch red
until the real work lands — that is a tradeoff worth recording as a decision rather than
absorbing silently.

**RG-03 — no supply-chain step anywhere.** Cheapest finding in the kit to close. An audit
at `--audit-level=high`, a secret scanner and an SBOM step are an afternoon, and every
enterprise security questionnaire asks for all three.

**RG-04 — coverage never published.** Lowest severity and still worth doing: it moves the
coverage figure from a sentence in a document to an artifact attached to a run.

### The lesson underneath it

Three sweeps, two clean internal reviews and a platform verification pass all looked at
this codebase. None of them looked at whether the pipeline that produced the evidence
could run at all. **Check the thing that checks.** It is the one component whose failure
makes every other result meaningless, and the only one nobody is assigned to review.
