/**
 * Runtime-dependency gate tests (P-DM-003).
 *
 * Fixtures first — each classification and each import syntax — then the gate is run
 * against THIS repository's real `src/`, `scripts/` and `package.json`, so an undeclared
 * runtime import fails the unit suite, not the production image.
 */
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import {
  checkRuntimeDeps,
  externalImportsOf,
  isExternalSpecifier,
  packageNameOf,
  renderRuntimeDepsReport,
} from '../src/runtimeDeps';

const REPO_ROOT = join(__dirname, '..');

describe('packageNameOf', () => {
  it('handles unscoped, deep, scoped and scoped-deep specifiers', () => {
    expect(packageNameOf('pg')).toBe('pg');
    expect(packageNameOf('pg/lib/client')).toBe('pg');
    expect(packageNameOf('@electric-sql/pglite')).toBe('@electric-sql/pglite');
    expect(packageNameOf('@electric-sql/pglite/dist/x.js')).toBe('@electric-sql/pglite');
  });
});

describe('isExternalSpecifier', () => {
  it('excludes relative, absolute, node:-prefixed and bare builtin specifiers', () => {
    expect(isExternalSpecifier('./app')).toBe(false);
    expect(isExternalSpecifier('../src/app')).toBe(false);
    expect(isExternalSpecifier('/abs/path')).toBe(false);
    expect(isExternalSpecifier('node:fs')).toBe(false);
    expect(isExternalSpecifier('fs')).toBe(false);
    expect(isExternalSpecifier('path/posix')).toBe(false);
  });

  it('treats anything else as an external package', () => {
    expect(isExternalSpecifier('pg')).toBe(true);
    expect(isExternalSpecifier('@scope/pkg/deep')).toBe(true);
  });
});

describe('externalImportsOf', () => {
  it('finds every runtime import syntax and dedupes/sorts', () => {
    const source = `
      import pg from 'pg';
      import { Pool } from "pg";
      import * as z from 'zod/lib';
      import 'side-effect-pkg';
      import { local } from './local';
      import { fs } from 'node:fs';
      export * from 'reexported';
      export { a, b } from '@scope/named';
      const req = require('required-pkg');
      const dyn = await import('dynamic-pkg');
    `;
    expect(externalImportsOf(source)).toEqual([
      '@scope/named',
      'dynamic-pkg',
      'pg',
      'reexported',
      'required-pkg',
      'side-effect-pkg',
      'zod',
    ]);
  });

  it('EXCLUDES type-only imports, which TypeScript erases', () => {
    const source = `
      import type { PoolConfig } from 'pg';
      import type Foo from 'types-only';
      import { type Bar, realThing } from 'mixed-pkg';
    `;
    expect(externalImportsOf(source)).toEqual(['mixed-pkg']);
  });

  it('ignores imports inside block and line comments', () => {
    const source = `
      /* import legacy from 'legacy-pkg'; */
      // const x = require('commented-out');
      /**
       * import { doc } from 'doc-comment-pkg';
       */
      import real from 'real-pkg';
    `;
    expect(externalImportsOf(source)).toEqual(['real-pkg']);
  });

  it('does not mistake the word "import" inside a string literal for a side-effect import (DM-F25)', () => {
    // The shape from src/helpCenter.ts that made the gate report a package named ", ".
    const source = `
      export const article = {
        keywords: ['import', 'migrate', 'csv'],
        body: 'every valid row imports — a partial import is not a failed import.',
      };
      const prose = "you can import data from 'a spreadsheet' later";
    `;
    expect(externalImportsOf(source)).toEqual([]);
  });

  it('still finds statement-form imports that follow a semicolon on the same line', () => {
    expect(externalImportsOf(`const a = 1; import 'after-semicolon'; import b from 'also-after';`)).toEqual([
      'after-semicolon',
      'also-after',
    ]);
  });

  it('returns an empty list for a file with no external imports', () => {
    expect(externalImportsOf(`import { a } from './a';\nimport { readFileSync } from 'node:fs';`)).toEqual([]);
  });
});

describe('checkRuntimeDeps', () => {
  const pkg = (dependencies: Record<string, string>, devDependencies: Record<string, string>) =>
    JSON.stringify({ dependencies, devDependencies });

  it('FAILS on an import declared nowhere — the P-DM-003 shape', () => {
    const report = checkRuntimeDeps({
      files: { 'scripts/migrate.js': `const { Client } = require('pg');` },
      packageJson: JSON.stringify({ name: 'x' }),
    });
    expect(report.ok).toBe(false);
    expect(report.problems).toEqual([
      expect.objectContaining({ kind: 'undeclared', packageName: 'pg', files: ['scripts/migrate.js'], severity: 'fail' }),
    ]);
    expect(report.problems[0].explanation).toContain('declared nowhere');
    expect(report.imports).toEqual({ pg: ['scripts/migrate.js'] });
  });

  it('FAILS on an import declared only in devDependencies', () => {
    const report = checkRuntimeDeps({
      files: { 'src/a.ts': `import { PGlite } from '@electric-sql/pglite';`, 'src/b.ts': `import '@electric-sql/pglite';` },
      packageJson: pkg({}, { '@electric-sql/pglite': '^0.5.8' }),
    });
    expect(report.ok).toBe(false);
    expect(report.problems).toHaveLength(1);
    expect(report.problems[0]).toMatchObject({
      kind: 'dev_only',
      packageName: '@electric-sql/pglite',
      files: ['src/a.ts', 'src/b.ts'],
      severity: 'fail',
    });
    expect(report.problems[0].explanation).toContain('npm ci --omit=dev');
  });

  it('WARNS, without failing, on a declared dependency nothing imports', () => {
    const report = checkRuntimeDeps({
      files: { 'src/a.ts': `import pg from 'pg';` },
      packageJson: pkg({ pg: '^8', 'left-over': '1.0.0' }, {}),
    });
    expect(report.ok).toBe(true);
    expect(report.problems).toEqual([
      expect.objectContaining({ kind: 'unused', packageName: 'left-over', files: [], severity: 'warn' }),
    ]);
  });

  it('passes cleanly when every runtime import is declared and used', () => {
    const report = checkRuntimeDeps({
      files: { 'src/a.ts': `import pg from 'pg';\nimport { x } from './x';`, 'src/x.ts': `export const x = 1;` },
      packageJson: pkg({ pg: '^8' }, { jest: '^29' }),
    });
    expect(report).toEqual({ ok: true, problems: [], imports: { pg: ['src/a.ts'] } });
  });

  it('sorts problems by package name and reports mixed kinds together', () => {
    const report = checkRuntimeDeps({
      files: { 'src/a.ts': `import 'zeta';\nimport 'alpha';\nimport 'mid';` },
      packageJson: pkg({ mid: '1', unused: '1' }, { zeta: '1' }),
    });
    expect(report.ok).toBe(false);
    expect(report.problems.map((p) => `${p.kind}:${p.packageName}`)).toEqual(['undeclared:alpha', 'dev_only:zeta', 'unused:unused']);
  });
});

describe('renderRuntimeDepsReport', () => {
  it('prints the verdict, each import with its files, and each problem', () => {
    const report = checkRuntimeDeps({
      files: { 'src/a.ts': `import 'pg';\nimport 'ghost';` },
      packageJson: JSON.stringify({ dependencies: { pg: '1', spare: '1' } }),
    });
    const text = renderRuntimeDepsReport(report);
    expect(text).toContain('Runtime-deps gate: FAIL — 2 runtime package(s) imported.');
    expect(text).toContain('uses pg  <- src/a.ts');
    expect(text).toContain('uses ghost  <- src/a.ts');
    expect(text).toContain('FAIL undeclared ghost:');
    expect(text).toContain('WARN unused     spare:');
  });

  it('prints PASS for a clean report', () => {
    expect(renderRuntimeDepsReport({ ok: true, problems: [], imports: {} })).toBe('Runtime-deps gate: PASS — 0 runtime package(s) imported.');
  });
});

describe('this repository', () => {
  function walk(dir: string, ext: string[], out: Record<string, string>): void {
    for (const entry of readdirSync(dir)) {
      const full = join(dir, entry);
      if (statSync(full).isDirectory()) {
        walk(full, ext, out);
      } else if (ext.some((e) => entry.endsWith(e))) {
        out[relative(REPO_ROOT, full)] = readFileSync(full, 'utf8');
      }
    }
  }

  it('declares every runtime import of src/ and scripts/ in dependencies — pg included', () => {
    const files: Record<string, string> = {};
    walk(join(REPO_ROOT, 'src'), ['.ts'], files);
    walk(join(REPO_ROOT, 'scripts'), ['.js'], files);
    expect(Object.keys(files).length).toBeGreaterThan(50);
    const report = checkRuntimeDeps({ files, packageJson: readFileSync(join(REPO_ROOT, 'package.json'), 'utf8') });
    expect(renderRuntimeDepsReport(report)).not.toContain('FAIL');
    expect(report.ok).toBe(true);
    // The zero-third-party rule: pg is the only runtime package, and it is used.
    expect(Object.keys(report.imports)).toEqual(['pg']);
    expect(report.problems).toEqual([]);
  });
});
