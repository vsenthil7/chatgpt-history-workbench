import { LEDGER_CAPACITY, Ledger } from '../src/ledger';

describe('Ledger — DM-F08', () => {
  it('holds records in order until the cap', () => {
    const l = new Ledger<number>(3);
    expect(l.push(1)).toBeUndefined();
    l.push(2);
    expect(l.all()).toEqual([1, 2]);
    expect(l.stats()).toEqual({ size: 2, capacity: 3, evicted: 0 });
    expect(l.isTruncated).toBe(false);
    expect(l.last()).toBe(2);
  });

  it('evicts oldest-first once full, returning what it dropped', () => {
    const l = new Ledger<number>(3);
    [1, 2, 3].forEach((n) => l.push(n));
    expect(l.push(4)).toBe(1);
    expect(l.all()).toEqual([2, 3, 4]);
    expect(l.size).toBe(3);
  });

  it('counts evictions rather than dropping records silently', () => {
    const l = new Ledger<number>(2);
    for (let i = 0; i < 10; i++) l.push(i);
    expect(l.stats()).toEqual({ size: 2, capacity: 2, evicted: 8 });
    expect(l.evicted).toBe(8);
    expect(l.isTruncated).toBe(true);
  });

  it('filters over retained records only', () => {
    const l = new Ledger<number>(4);
    for (let i = 0; i < 8; i++) l.push(i);
    expect(l.filter((n) => n % 2 === 0)).toEqual([4, 6]);
  });

  it('clears, and reports an empty last()', () => {
    const l = new Ledger<string>(2);
    expect(l.last()).toBeUndefined();
    l.push('a');
    l.clear();
    expect(l.size).toBe(0);
    expect(l.all()).toEqual([]);
  });

  it('refuses a nonsensical capacity', () => {
    expect(() => new Ledger<number>(0)).toThrow('positive whole number');
    expect(() => new Ledger<number>(-1)).toThrow();
    expect(() => new Ledger<number>(1.5)).toThrow();
  });

  it('exposes sane default capacities', () => {
    expect(LEDGER_CAPACITY.telemetry).toBeGreaterThan(LEDGER_CAPACITY.errors);
    expect(LEDGER_CAPACITY.audit).toBeGreaterThanOrEqual(LEDGER_CAPACITY.telemetry);
    for (const cap of Object.values(LEDGER_CAPACITY)) {
      expect(Number.isInteger(cap)).toBe(true);
      expect(cap).toBeGreaterThan(1000);
    }
  });
});
