import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import {
  KNOWN_ACCOUNT_STORES,
  PurgeRegistry,
  mapPurgeTarget,
} from '../src/purge';

const NOW = 1_757_780_000_000;

function fullyRegistered(): PurgeRegistry {
  const registry = new PurgeRegistry(() => NOW);
  for (const name of KNOWN_ACCOUNT_STORES) {
    registry.register({ name, purge: () => 1 });
  }
  return registry;
}

describe('PurgeRegistry — DM-F09', () => {
  it('FAILS when a known store has no purge target — the original defect', () => {
    const registry = new PurgeRegistry(() => NOW);
    registry.register({ name: 'accounts', purge: () => 1 });
    const verdict = registry.verifyRegistration();
    expect(verdict.ok).toBe(false);
    expect(verdict.missing).toContain('oauth_tokens');
    expect(verdict.missing).toContain('templates');
    expect(verdict.missing).toContain('invoices');
  });

  it('passes only when every known store is wired', () => {
    expect(fullyRegistered().verifyRegistration()).toEqual({ ok: true, missing: [] });
  });

  it('refuses a duplicate registration', () => {
    const registry = new PurgeRegistry(() => NOW);
    registry.register({ name: 'accounts', purge: () => 0 });
    expect(() => registry.register({ name: 'accounts', purge: () => 0 })).toThrow('already registered');
  });

  it('lists registered targets', () => {
    const registry = fullyRegistered();
    expect(registry.registered()).toHaveLength(KNOWN_ACCOUNT_STORES.length);
    expect(registry.registered()).toEqual([...registry.registered()].sort());
  });

  it('purges every store and evidences the row counts', async () => {
    const registry = new PurgeRegistry(() => NOW);
    registry.register({ name: 'accounts', purge: () => 1 });
    registry.register({ name: 'templates', purge: async () => 4 });
    registry.register({ name: 'invoices', purge: () => 0 });
    const receipt = await registry.purgeAccount('acct-1');
    expect(receipt).toMatchObject({ accountId: 'acct-1', at: NOW, totalRemoved: 5, complete: true });
    expect(receipt.removed).toEqual({ accounts: 1, templates: 4, invoices: 0 });
    expect(receipt.failures).toEqual([]);
  });

  it('records a failing store, keeps purging the rest, and refuses to call it complete', async () => {
    const registry = new PurgeRegistry(() => NOW);
    registry.register({ name: 'accounts', purge: () => 1 });
    registry.register({
      name: 'telemetry_events',
      purge: () => {
        throw new Error('connection reset');
      },
    });
    registry.register({ name: 'templates', purge: () => 3 });
    const receipt = await registry.purgeAccount('acct-1');
    expect(receipt.complete).toBe(false);
    expect(receipt.failures).toEqual([{ store: 'telemetry_events', error: 'connection reset' }]);
    expect(receipt.removed).toEqual({ accounts: 1, templates: 3 }); // the rest still ran
  });

  it('uses Date.now by default', async () => {
    const registry = new PurgeRegistry();
    registry.register({ name: 'accounts', purge: () => 0 });
    expect((await registry.purgeAccount('a')).at).toBeGreaterThan(0);
  });
});

describe('mapPurgeTarget', () => {
  it('removes only the target account records from a keyed store', async () => {
    const map = new Map<string, { accountId: string; name: string }>([
      ['t1', { accountId: 'acct-1', name: 'a' }],
      ['t2', { accountId: 'acct-2', name: 'b' }],
      ['t3', { accountId: 'acct-1', name: 'c' }],
    ]);
    const target = mapPurgeTarget('templates', map);
    expect(await target.purge('acct-1')).toBe(2);
    expect([...map.keys()]).toEqual(['t2']);
    expect(await target.purge('acct-1')).toBe(0);
  });

  it('supports stores keyed by account id itself', async () => {
    const map = new Map<string, { expiresAt: number }>([
      ['acct-1', { expiresAt: 1 }],
      ['acct-2', { expiresAt: 2 }],
    ]);
    const target = mapPurgeTarget('oauth_tokens', map, (_v, key) => key);
    expect(await target.purge('acct-1')).toBe(1);
    expect([...map.keys()]).toEqual(['acct-2']);
  });
});

describe('Schema gate — every purgeable store must have a table that cascades', () => {
  const dir = join(__dirname, '..', 'migrations');
  const sql = readdirSync(dir)
    .filter((f) => f.endsWith('.sql'))
    .sort()
    .map((f) => readFileSync(join(dir, f), 'utf8'))
    .join('\n');

  it('ships ordered migrations', () => {
    const files = readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
    expect(files.length).toBeGreaterThanOrEqual(3);
    expect(files[0]).toMatch(/^001_/);
  });

  it('defines a table for every known account store', () => {
    for (const store of KNOWN_ACCOUNT_STORES) {
      expect(sql).toContain(`CREATE TABLE ${store} (`);
    }
  });

  /**
   * S16 (P-DM-009): two tables are keyed by something that is not an account — a
   * platform-issued delivery id and a rate-limit key that is an IP for anonymous routes.
   * They carry a nullable account_id (no FK, because a dedupe insert or a limit check must
   * not fail on the state of the accounts table) and are purged by that column through
   * PURGE_TABLE_ORDER instead. Named here so the exemption is visible, and asserted below
   * so a third table cannot join the list silently.
   */
  const NOT_ACCOUNT_SCOPED = new Set(['webhook_deliveries', 'rate_limit_windows']);

  it('cascades every account-scoped table from accounts, so deletion cannot orphan rows', () => {
    const tables = [...sql.matchAll(/CREATE TABLE (\w+) \(([\s\S]*?)\n\);/g)];
    expect(tables.length).toBeGreaterThanOrEqual(KNOWN_ACCOUNT_STORES.length);
    for (const [, name, bodyText] of tables) {
      if (name === 'accounts') {
        continue;
      }
      if (NOT_ACCOUNT_SCOPED.has(name)) {
        // Purgeable by column, and the column is declared — that is the whole exemption.
        expect(bodyText).toMatch(/account_id\s+TEXT/);
        expect(bodyText).not.toContain('REFERENCES accounts');
        continue;
      }
      // Either it references accounts directly, or it cascades from a table that does.
      const cascades = /REFERENCES \w+\([\w_]+\) ON DELETE CASCADE/.test(bodyText);
      expect([name, cascades]).toEqual([name, true]);
    }
  });

  it('constrains the enumerated columns rather than trusting the application', () => {
    expect(sql).toContain("CHECK (status IN ('active', 'pending_deletion'))");
    expect(sql).toContain("CHECK (plan_id IN ('free', 'starter', 'pro'))");
    expect(sql).toContain("CHECK (conflict_policy IN ('rename', 'overwrite', 'skip'))");
    expect(sql).toContain('CHECK (expiry_days BETWEEN 1 AND 90)');
  });

  it('indexes the account_id lookups a purge depends on', () => {
    for (const idx of ['templates_account_idx', 'invoices_account_idx', 'audit_entries_account_idx']) {
      expect(sql).toContain(idx);
    }
  });
});
