/**
 * Release-integrity gate tests.
 *
 * Two halves. The first uses inline fixtures to prove each rule fires and, more
 * importantly, that it does not fire on the shapes it must tolerate. The second runs the
 * gate against THIS repository's real workflows, so the gate is a standing check rather
 * than a thing that was true once.
 *
 * The regression fixtures are the actual DocMerge defects: the `npm ci` job with no
 * lockfile (CGPT-DM-004) and the deploy job that echoed and exited zero (CGPT-DM-002).
 */
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import {
  checkReleaseIntegrity,
  entrypointSourceFor,
  moduleInvokesSomething,
  renderReleaseReport,
  ReleaseFinding,
} from '../src/releaseGate';

const WORKFLOW_DIR = join(__dirname, '..', '.github', 'workflows');
const REPO_ROOT = join(__dirname, '..');

function ids(findings: ReleaseFinding[]): string[] {
  return findings.map((f) => f.id);
}

/** The workflow as it stood before the external review. */
const BROKEN_CI = `
name: ci
on:
  push:
    branches: [main]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm ci
      - run: npx jest --coverage
  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - run: echo "deploy step placeholder — wired to platform FaaS in S8"
`;

describe('RG-01 — an install that cannot run', () => {
  it('fires when npm ci is used and no lockfile exists', () => {
    const findings = checkReleaseIntegrity({ workflows: { 'ci.yml': BROKEN_CI }, repoFiles: ['package.json'] });
    const rg01 = findings.filter((f) => f.id === 'RG-01');
    expect(rg01).toHaveLength(1);
    expect(rg01[0].severity).toBe('CRITICAL');
    expect(rg01[0].where).toBe('ci.yml :: test');
  });

  it('is silent once the lockfile is present', () => {
    const findings = checkReleaseIntegrity({
      workflows: { 'ci.yml': BROKEN_CI },
      repoFiles: ['package.json', 'package-lock.json'],
    });
    expect(ids(findings)).not.toContain('RG-01');
  });

  it('tolerates a leading ./ on supplied paths', () => {
    const findings = checkReleaseIntegrity({
      workflows: { 'ci.yml': BROKEN_CI },
      repoFiles: ['./package-lock.json'],
    });
    expect(ids(findings)).not.toContain('RG-01');
  });

  it('covers yarn and pnpm frozen installs', () => {
    const yarn = checkReleaseIntegrity({
      workflows: { 'w.yml': 'jobs:\n  build:\n    steps:\n      - run: yarn install --frozen-lockfile\n' },
      repoFiles: [],
    });
    expect(ids(yarn)).toContain('RG-01');

    const pnpm = checkReleaseIntegrity({
      workflows: { 'w.yml': 'jobs:\n  build:\n    steps:\n      - run: pnpm install --frozen-lockfile\n' },
      repoFiles: ['pnpm-lock.yaml'],
    });
    expect(ids(pnpm)).not.toContain('RG-01');
  });

  it('does not fire for an unlocked install, which is a different (lesser) problem', () => {
    const findings = checkReleaseIntegrity({
      workflows: { 'w.yml': 'jobs:\n  build:\n    steps:\n      - run: npm install\n' },
      repoFiles: [],
    });
    expect(ids(findings)).not.toContain('RG-01');
  });
});

describe('RG-02 — a step that reports success without acting', () => {
  it('fires on an echo-only deploy job', () => {
    const findings = checkReleaseIntegrity({ workflows: { 'ci.yml': BROKEN_CI }, repoFiles: ['package-lock.json'] });
    const rg02 = findings.filter((f) => f.id === 'RG-02');
    expect(rg02).toHaveLength(1);
    expect(rg02[0].where).toBe('ci.yml :: deploy');
  });

  it('is silent when the placeholder fails closed with exit 1', () => {
    const yml = `
jobs:
  deploy:
    steps:
      - run: |
          echo "::error::Deploy not implemented. Blocked on LC-1."
          exit 1
`;
    expect(ids(checkReleaseIntegrity({ workflows: { 'ci.yml': yml }, repoFiles: [] }))).not.toContain('RG-02');
  });

  it('is silent when the placeholder emits an error annotation', () => {
    const yml = 'jobs:\n  deploy:\n    steps:\n      - run: echo "::error::not implemented"\n';
    expect(ids(checkReleaseIntegrity({ workflows: { 'ci.yml': yml }, repoFiles: [] }))).not.toContain('RG-02');
  });

  it('ignores an echo in a job that claims no external action', () => {
    const yml = 'jobs:\n  lint:\n    steps:\n      - run: echo "nothing to lint yet"\n';
    expect(ids(checkReleaseIntegrity({ workflows: { 'ci.yml': yml }, repoFiles: [] }))).not.toContain('RG-02');
  });

  it('accepts a caller-supplied list of action-implying job names', () => {
    const yml = 'jobs:\n  ship-it:\n    steps:\n      - run: echo "soon"\n';
    const findings = checkReleaseIntegrity({
      workflows: { 'ci.yml': yml },
      repoFiles: [],
      actionJobHints: ['ship'],
    });
    expect(ids(findings)).toContain('RG-02');
  });

  it('does not fire when the job also does real work', () => {
    const yml = `
jobs:
  deploy:
    steps:
      - run: |
          echo "deploying"
          ./scripts/deploy.sh
`;
    expect(ids(checkReleaseIntegrity({ workflows: { 'ci.yml': yml }, repoFiles: [] }))).not.toContain('RG-02');
  });

  it('treats a comment-only or no-op run as not a placeholder claim', () => {
    const commentOnly = 'jobs:\n  deploy:\n    steps:\n      - run: |\n          # nothing here yet\n';
    expect(ids(checkReleaseIntegrity({ workflows: { 'ci.yml': commentOnly }, repoFiles: [] }))).not.toContain('RG-02');

    const noop = 'jobs:\n  deploy:\n    steps:\n      - run: |\n          :\n';
    expect(ids(checkReleaseIntegrity({ workflows: { 'ci.yml': noop }, repoFiles: [] }))).toContain('RG-02');
  });

  it('closes a run block when a later job dedents, and keeps both jobs separate', () => {
    const yml = `
jobs:
  deploy:
    steps:
      - run: |
          echo "placeholder"
  test:
    steps:
      - run: npm ci
`;
    const findings = checkReleaseIntegrity({ workflows: { 'w.yml': yml }, repoFiles: [] });
    expect(findings.some((f) => f.id === 'RG-02' && f.where === 'w.yml :: deploy')).toBe(true);
    expect(findings.some((f) => f.id === 'RG-01' && f.where === 'w.yml :: test')).toBe(true);
  });

  it('attributes a step written before any jobs key to the top level', () => {    const findings = checkReleaseIntegrity({
      workflows: { 'w.yml': 'steps:\n  - run: npm ci\n' },
      repoFiles: [],
    });
    expect(findings.some((f) => f.where === 'w.yml :: (top level)')).toBe(true);
  });

  it('reads a folded run block and a tab-indented file', () => {
    const folded = 'jobs:\n  deploy:\n    steps:\n      - run: >\n          echo hello\n';
    expect(ids(checkReleaseIntegrity({ workflows: { 'w.yml': folded }, repoFiles: [] }))).toContain('RG-02');

    const tabs = 'jobs:\n\tdeploy:\n\t\tsteps:\n\t\t\t- run: npm ci\n';
    expect(checkReleaseIntegrity({ workflows: { 'w.yml': tabs }, repoFiles: [] }).length).toBeGreaterThan(0);
  });
});

describe('RG-03 — no supply-chain gate anywhere', () => {
  it('fires when no workflow audits, scans or produces an SBOM', () => {
    expect(ids(checkReleaseIntegrity({ workflows: { 'ci.yml': BROKEN_CI }, repoFiles: [] }))).toContain('RG-03');
  });

  it('is satisfied by an audit step', () => {
    const yml = 'jobs:\n  sc:\n    steps:\n      - run: npm audit --audit-level=high\n';
    expect(ids(checkReleaseIntegrity({ workflows: { 'ci.yml': yml }, repoFiles: [] }))).not.toContain('RG-03');
  });

  it('is satisfied by a CodeQL action', () => {
    const yml = 'jobs:\n  sc:\n    steps:\n      - uses: github/codeql-action/analyze@v3\n';
    expect(ids(checkReleaseIntegrity({ workflows: { 'codeql.yml': yml }, repoFiles: [] }))).not.toContain('RG-03');
  });

  it('says nothing at all when there are no workflows to judge', () => {
    expect(checkReleaseIntegrity({ workflows: {}, repoFiles: [] })).toEqual([]);
  });
});

describe('RG-04 — coverage computed but never published', () => {
  it('fires when coverage runs with no artifact upload', () => {
    const yml = 'jobs:\n  test:\n    steps:\n      - run: npx jest --coverage\n';
    expect(ids(checkReleaseIntegrity({ workflows: { 'ci.yml': yml }, repoFiles: [] }))).toContain('RG-04');
  });

  it('is silent once the coverage directory is uploaded', () => {
    const yml = 'jobs:\n  test:\n    steps:\n      - run: npx jest --coverage\n      - uses: actions/upload-artifact@v4\n';
    expect(ids(checkReleaseIntegrity({ workflows: { 'ci.yml': yml }, repoFiles: [] }))).not.toContain('RG-04');
  });
});

/** The shape of `src/server.ts` before S13: a start() that nothing called. */
const EXPORT_ONLY_SERVER = `
/**
 * HTTP server wiring — DM-F01.
 * main(); <- in a comment, must not count
 */
import { createServer } from 'node:http';
export const MAX_BODY_BYTES = 1_000_000;
export class BodyTooLargeError extends Error {}
export function start(port: number): void {
  const server = createServer(() => {});
  server.listen(port);
}
// start(8080);  <- commented out, must not count
`;

const INVOKING_MAIN = `
import { start } from './server';
export function main(): void {
  start(8080);
}
void main();
`;

const CLEAN_CI = 'jobs:\n  test:\n    steps:\n      - run: npm audit\n';
const clean = (extra: Partial<Parameters<typeof checkReleaseIntegrity>[0]>) =>
  checkReleaseIntegrity({ workflows: { 'ci.yml': CLEAN_CI }, repoFiles: ['package-lock.json'], ...extra });

describe('entrypointSourceFor', () => {
  it('maps dist/ back to src/ and .js back to .ts', () => {
    expect(entrypointSourceFor('node dist/main.js')).toBe('src/main.ts');
    expect(entrypointSourceFor('node dist/server.js')).toBe('src/server.ts');
  });

  it('tolerates a ./ prefix, node flags, and .mjs/.cjs', () => {
    expect(entrypointSourceFor('node ./dist/main.js')).toBe('src/main.ts');
    expect(entrypointSourceFor('node --enable-source-maps --max-old-space-size=512 dist/main.js')).toBe('src/main.ts');
    expect(entrypointSourceFor('node dist/main.mjs')).toBe('src/main.ts');
    expect(entrypointSourceFor('node server.cjs')).toBe('server.ts');
    expect(entrypointSourceFor('NODE_ENV=production node dist/main.js --port 80')).toBe('src/main.ts');
  });

  it('returns undefined when the script does not run a node module', () => {
    expect(entrypointSourceFor('ts-node src/main.ts')).toBeUndefined();
    expect(entrypointSourceFor('npm run serve')).toBeUndefined();
    expect(entrypointSourceFor('node')).toBeUndefined();
  });
});

describe('moduleInvokesSomething', () => {
  it('accepts the require.main guard, a column-0 call, void/await calls', () => {
    expect(moduleInvokesSomething('if (require.main === module) {\n  main();\n}\n')).toBe(true);
    expect(moduleInvokesSomething('function main() {}\nmain();\n')).toBe(true);
    expect(moduleInvokesSomething('function main() {}\nvoid main();\n')).toBe(true);
    expect(moduleInvokesSomething('await bootstrap.start();\n')).toBe(true);
    expect(moduleInvokesSomething(INVOKING_MAIN)).toBe(true);
  });

  it('rejects a module of exports and declarations only', () => {
    expect(moduleInvokesSomething(EXPORT_ONLY_SERVER)).toBe(false);
    expect(moduleInvokesSomething('export const a = 1;\nexport function f() {\n  g();\n}\n')).toBe(false);
  });

  it('strips block and line comments before looking', () => {
    expect(moduleInvokesSomething('/* main(); */\nexport const x = 1;\n')).toBe(false);
    expect(moduleInvokesSomething('// main();\nexport const x = 1;\n')).toBe(false);
    expect(moduleInvokesSomething('/**\n * start();\n */\nexport function start() {}\n')).toBe(false);
  });
});

describe('RG-05 — a start script whose entrypoint invokes nothing (P-DM-002)', () => {
  const pkg = (start?: string) => JSON.stringify({ name: 'x', scripts: start === undefined ? { build: 'tsc' } : { start, build: 'tsc' } });

  it('fires for the pre-S13 shape: start -> dist/server.js whose source only exports', () => {
    const findings = clean({ packageJson: pkg('node dist/server.js'), sourceFiles: { 'src/server.ts': EXPORT_ONLY_SERVER } });
    const rg05 = findings.filter((f) => f.id === 'RG-05');
    expect(rg05).toHaveLength(1);
    expect(rg05[0].severity).toBe('CRITICAL');
    expect(rg05[0].where).toBe('package.json :: scripts.start -> src/server.ts');
    expect(rg05[0].what).toContain('invokes none of them');
    expect(rg05[0].why).toContain('P-DM-002');
  });

  it('fires when the entrypoint is missing from the supplied sources, and when it is unrecognised', () => {
    const missing = clean({ packageJson: pkg('node dist/main.js'), sourceFiles: { 'src/server.ts': EXPORT_ONLY_SERVER } });
    expect(missing.filter((f) => f.id === 'RG-05')).toEqual([
      expect.objectContaining({
        severity: 'CRITICAL',
        where: 'package.json :: scripts.start = "node dist/main.js"',
        what: expect.stringContaining('(src/main.ts) is not among the supplied source files'),
      }),
    ]);
    const unrecognised = clean({ packageJson: pkg('ts-node src/main.ts'), sourceFiles: { 'src/main.ts': INVOKING_MAIN } });
    expect(unrecognised.filter((f) => f.id === 'RG-05')[0].what).toContain('(unrecognised)');
    const noSources = clean({ packageJson: pkg('node dist/main.js') });
    expect(ids(noSources)).toContain('RG-05');
  });

  it('is silent when the entrypoint invokes something', () => {
    const findings = clean({ packageJson: pkg('node dist/main.js'), sourceFiles: { 'src/main.ts': INVOKING_MAIN } });
    expect(ids(findings)).not.toContain('RG-05');
  });

  it('does not fire on an invalid package.json, no start script, or no packageJson at all', () => {
    expect(ids(clean({ packageJson: '{ not json', sourceFiles: {} }))).not.toContain('RG-05');
    expect(ids(clean({ packageJson: pkg(undefined), sourceFiles: {} }))).not.toContain('RG-05');
    expect(ids(clean({ packageJson: JSON.stringify({ name: 'no-scripts' }), sourceFiles: {} }))).not.toContain('RG-05');
    expect(ids(clean({ sourceFiles: { 'src/server.ts': EXPORT_ONLY_SERVER } }))).not.toContain('RG-05');
  });
});

describe('RG-06 — a coverage exemption without a named compensating control (P-DM-010)', () => {
  it('fires for a pragma with no verified-by', () => {
    const source = "/* istanbul ignore next -- verified by booting the server, not by unit tests */\nif (require.main === module) {\n  start();\n}\n";
    const findings = clean({ sourceFiles: { 'src/server.ts': source } });
    const rg06 = findings.filter((f) => f.id === 'RG-06');
    expect(rg06).toHaveLength(1);
    expect(rg06[0].severity).toBe('HIGH');
    expect(rg06[0].where).toBe('src/server.ts :: /* istanbul ignore next -- verified by booting the server, not by unit tests */');
    expect(rg06[0].what).toContain('names no compensating control');
    expect(rg06[0].why).toContain('P-DM-010');
  });

  it('fires when verified-by names a file that is not in the repository', () => {
    const source = '/* istanbul ignore next -- verified-by: tests/boot.test.ts */\nif (require.main === module) {\n  start();\n}\n';
    const findings = clean({ sourceFiles: { 'src/main.ts': source } });
    const rg06 = findings.filter((f) => f.id === 'RG-06');
    expect(rg06).toHaveLength(1);
    expect(rg06[0].what).toBe('The named compensating control (tests/boot.test.ts) does not exist in the repository.');
  });

  it('is silent when the named control exists, and recognises c8/v8 pragmas too', () => {
    const source = '/* istanbul ignore next -- verified-by: tests/boot.test.ts (spawns the artefact) */\nif (require.main === module) {\n  start();\n}\n';
    const ok = clean({ repoFiles: ['package-lock.json', './tests/boot.test.ts'], sourceFiles: { 'src/main.ts': source } });
    expect(ids(ok)).not.toContain('RG-06');

    const c8 = clean({ sourceFiles: { 'src/a.ts': '/* c8 ignore next */\nfoo();\n' } });
    expect(c8.filter((f) => f.id === 'RG-06')).toHaveLength(1);
    const v8 = clean({ sourceFiles: { 'src/a.ts': '/* v8 ignore start */\nfoo();\n' } });
    expect(v8.filter((f) => f.id === 'RG-06')).toHaveLength(1);
  });

  it('reports every pragma in every file, and nothing for files without one', () => {
    const findings = clean({
      sourceFiles: {
        'src/a.ts': '/* istanbul ignore next */\nx();\n/* istanbul ignore else */\nif (y) z();\n',
        'src/b.ts': 'export const clean = true;\n',
      },
    });
    expect(findings.filter((f) => f.id === 'RG-06').map((f) => f.where)).toEqual([
      'src/a.ts :: /* istanbul ignore next */',
      'src/a.ts :: /* istanbul ignore else */',
    ]);
  });
});

describe('report rendering', () => {
  it('reports cleanliness plainly', () => {
    expect(renderReleaseReport([])).toContain('no findings');
  });

  it('orders by severity and names every finding', () => {
    const findings = checkReleaseIntegrity({ workflows: { 'ci.yml': BROKEN_CI }, repoFiles: [] });
    const report = renderReleaseReport(findings);
    expect(report).toContain('CRITICAL');
    expect(report.indexOf('CRITICAL')).toBeLessThan(report.indexOf('HIGH'));
    for (const f of findings) expect(report).toContain(f.id);
  });
});

describe('this repository', () => {
  function realWorkflows(): Record<string, string> {
    const out: Record<string, string> = {};
    for (const f of readdirSync(WORKFLOW_DIR)) {
      out[f] = readFileSync(join(WORKFLOW_DIR, f), 'utf8');
    }
    return out;
  }

  it('has the lockfile its own workflows install from', () => {
    expect(existsSync(join(REPO_ROOT, 'package-lock.json'))).toBe(true);
  });

  function realSources(): Record<string, string> {
    const out: Record<string, string> = {};
    const dir = join(REPO_ROOT, 'src');
    for (const f of readdirSync(dir).filter((n) => n.endsWith('.ts'))) {
      out[`src/${f}`] = readFileSync(join(dir, f), 'utf8');
    }
    return out;
  }

  function realRepoFiles(): string[] {
    const out = ['package.json', 'package-lock.json'];
    for (const f of readdirSync(join(REPO_ROOT, 'tests'))) out.push(`tests/${f}`);
    return out;
  }

  it('passes the release-integrity gate, including RG-05 and RG-06 over package.json and every src/*.ts', () => {
    const sourceFiles = realSources();
    expect(Object.keys(sourceFiles).length).toBeGreaterThan(50);
    const findings = checkReleaseIntegrity({
      workflows: realWorkflows(),
      repoFiles: realRepoFiles(),
      packageJson: readFileSync(join(REPO_ROOT, 'package.json'), 'utf8'),
      sourceFiles,
    });
    expect(renderReleaseReport(findings)).toBe('Release-integrity gate: no findings.');
  });

  it('start script points at main.ts, which invokes main() behind the require.main guard', () => {
    const pkg = JSON.parse(readFileSync(join(REPO_ROOT, 'package.json'), 'utf8')) as { scripts: Record<string, string> };
    expect(entrypointSourceFor(pkg.scripts.start)).toBe('src/main.ts');
    expect(moduleInvokesSomething(readFileSync(join(REPO_ROOT, 'src', 'main.ts'), 'utf8'))).toBe(true);
    // The pre-S13 entrypoint still only exports: the gate would fire if start pointed back at it.
    expect(moduleInvokesSomething(readFileSync(join(REPO_ROOT, 'src', 'server.ts'), 'utf8'))).toBe(false);
  });

  it('the one coverage exemption names tests/boot.test.ts, and that file exists', () => {
    const sources = realSources();
    const pragmas: string[] = [];
    for (const text of Object.values(sources)) {
      for (const m of text.match(/\/\*\s*(?:istanbul|c8|v8)\s+ignore\b[^*]*\*\//g) ?? []) pragmas.push(m);
    }
    expect(pragmas).toHaveLength(1);
    expect(pragmas[0]).toContain('verified-by: tests/boot.test.ts');
    expect(existsSync(join(REPO_ROOT, 'tests', 'boot.test.ts'))).toBe(true);
  });

  it('would have fired RG-05 and RG-06 on the pre-S13 repository', () => {
    const preS13 = JSON.stringify({ scripts: { start: 'node dist/server.js' } });
    const oldServer =
      EXPORT_ONLY_SERVER + '\n/* istanbul ignore next -- verified by booting the server, not by unit tests */\nexport const x = 1;\n';
    const findings = checkReleaseIntegrity({
      workflows: realWorkflows(),
      repoFiles: realRepoFiles(),
      packageJson: preS13,
      sourceFiles: { 'src/server.ts': oldServer },
    });
    expect(ids(findings).sort()).toEqual(['RG-05', 'RG-06']);
  });

  it('would have failed this gate before the external review', () => {
    const findings = checkReleaseIntegrity({ workflows: { 'ci.yml': BROKEN_CI }, repoFiles: ['package.json'] });
    expect(ids(findings).sort()).toEqual(['RG-01', 'RG-02', 'RG-03', 'RG-04']);
  });
});
