/**
 * Integration gate (S19 — P-DM-001 as a standing check, IG-01/IG-02).
 *
 * Fixtures first — each boundary shape the detector must find and each shape it must
 * ignore, then each implementation signal and the one mention that must not count —
 * then the gate is run over this repository with the product's exemptions, the same
 * way scripts/integration-gate.js runs it, so an interface left with only test doubles
 * behind it fails the unit suite, not the release.
 */
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import {
  DOCMERGE_INTEGRATION_EXEMPTIONS,
  IntegrationReport,
  checkIntegrationCoverage,
  findBoundaries,
  findImplementations,
  renderIntegrationReport,
} from '../src/integrationGate';

const REPO_ROOT = join(__dirname, '..');

describe('findBoundaries', () => {
  it('finds an exported interface that declares a method, with its method names', () => {
    const src = `export interface Store {\n  get(id: string): Promise<string>;\n  readonly put(id: string, v: string): void;\n}\n`;
    expect(findBoundaries({ 'src/a.ts': src })).toEqual([{ name: 'Store', kind: 'interface', file: 'src/a.ts', methods: ['get', 'put'] }]);
  });

  it('excludes a data-only interface (no methods) and a non-exported interface', () => {
    const src = `export interface Row {\n  id: string;\n  count: number;\n  nested: { x: string };\n}\ninterface Hidden {\n  run(): void;\n}\n`;
    expect(findBoundaries({ 'src/a.ts': src })).toEqual([]);
  });

  it('handles a generic interface and an extends clause', () => {
    const src = [
      'export interface Repo<T extends object> {',
      '  find<K extends keyof T>(key: K): Promise<T | undefined>;',
      '}',
      'export interface Bigger extends Repo<object>, Other {',
      '  clear(): void;',
      '}',
    ].join('\n');
    expect(findBoundaries({ 'src/a.ts': src })).toEqual([
      { name: 'Bigger', kind: 'interface', file: 'src/a.ts', methods: ['clear'] },
      { name: 'Repo', kind: 'interface', file: 'src/a.ts', methods: ['find'] },
    ]);
  });

  it('sees a method whose type-parameter default is itself generic (SqlClient.query<T = Record<string, unknown>>)', () => {
    const src = 'export interface SqlClient {\n  query<T = Record<string, unknown>>(text: string, values?: unknown[]): Promise<T>;\n}\n';
    expect(findBoundaries({ 'src/a.ts': src })).toEqual([{ name: 'SqlClient', kind: 'interface', file: 'src/a.ts', methods: ['query'] }]);
  });

  it('finds an exported function-type alias (plain and generic) and marks it "(call)"', () => {
    const src = `export type Probe = (accountId: string) => Promise<'active' | 'unknown'>;\nexport type Mapper<T> = (x: T) => T;\n`;
    expect(findBoundaries({ 'src/a.ts': src })).toEqual([
      { name: 'Mapper', kind: 'function_type', file: 'src/a.ts', methods: ['(call)'] },
      { name: 'Probe', kind: 'function_type', file: 'src/a.ts', methods: ['(call)'] },
    ]);
  });

  it("does NOT treat a parenthesised union `= ('a' | 'b')[number]` or a plain union as a boundary", () => {
    const src = `export type Colour = ('blue' | 'green')[number];\nexport type Mode = 'a' | 'b';\nexport type Pair = [string, number];\n`;
    expect(findBoundaries({ 'src/a.ts': src })).toEqual([]);
  });

  it('strips block and line comments, so a commented-out interface or a method in a doc comment is not counted', () => {
    const src = [
      '/**',
      ' * export interface Ghost {',
      ' *   haunt(): void;',
      ' * }',
      ' */',
      '// export type Spectre = (x: string) => void;',
      'export interface Real {',
      '  // ignored(): void;',
      '  /* alsoIgnored(): void; */',
      '  id: string;',
      '}',
      'export interface Live {',
      '  go(): void;',
      '}',
    ].join('\n');
    expect(findBoundaries({ 'src/a.ts': src }).map((b) => b.name)).toEqual(['Live']);
  });

  it('falls back to the rest of the file when an interface brace is unterminated', () => {
    const src = `export interface Broken {\n  run(): void;\n  // no closing brace\n`;
    expect(findBoundaries({ 'src/a.ts': src })).toEqual([{ name: 'Broken', kind: 'interface', file: 'src/a.ts', methods: ['run'] }]);
  });

  it('sorts across files by name', () => {
    const files = {
      'src/z.ts': 'export interface Zed {\n  z(): void;\n}\n',
      'src/a.ts': 'export interface Alpha {\n  a(): void;\n}\n',
    };
    expect(findBoundaries(files).map((b) => [b.name, b.file])).toEqual([
      ['Alpha', 'src/a.ts'],
      ['Zed', 'src/z.ts'],
    ]);
  });
});

describe('findImplementations — each signal counts, a signature-only mention does not', () => {
  const decl = 'export interface Store {\n  get(id: string): string;\n}\n';

  it('class … implements Store (also in a list of interfaces)', () => {
    const files = {
      'src/store.ts': decl,
      'src/impl.ts': 'class Mem implements Store {\n  get(id: string) { return id; }\n}\n',
      'src/multi.ts': 'class Both implements Other, Store {\n  get(id: string) { return id; }\n}\n',
    };
    expect(findImplementations('Store', files)).toEqual(['src/impl.ts', 'src/multi.ts']);
  });

  it('a value annotated with the type: const x: Store = …', () => {
    const files = {
      'src/store.ts': decl,
      'src/impl.ts': 'const store: Store = { get: (id) => id };\n',
      'src/generic.ts': 'private readonly repo: Store<string> = make();\n',
    };
    expect(findImplementations('Store', files)).toEqual(['src/generic.ts', 'src/impl.ts']);
  });

  it('a factory that returns it: (...): Store { … } or (...): Store => {', () => {
    const files = {
      'src/store.ts': decl,
      'src/fn.ts': 'export function makeStore(): Store {\n  return { get: (id) => id };\n}\n',
      'src/arrow.ts': 'export const build = (): Store => ({ get: (id) => id });\n',
    };
    expect(findImplementations('Store', files)).toEqual(['src/arrow.ts', 'src/fn.ts']);
  });

  it('an object literal asserted or satisfied: as Store / satisfies Store', () => {
    const files = {
      'src/store.ts': decl,
      'src/as.ts': 'const s = { get: (id: string) => id } as Store;\n',
      'src/sat.ts': 'const s = { get: (id: string) => id } satisfies Store;\n',
    };
    expect(findImplementations('Store', files)).toEqual(['src/as.ts', 'src/sat.ts']);
  });

  it('does NOT count a parameter or field typed with it, a comment, or a different identifier', () => {
    const files = {
      'src/store.ts': decl,
      'src/consumer.ts': [
        'export class Service {',
        '  constructor(private readonly store: Store) {}',
        '  async run(other: Store): Promise<Store> { return other; }',
        '}',
        '// const fake: Store = {} as Store;',
        '/* class X implements Store {} */',
        'const notIt: StoreFactory = () => 1;',
        'const arrow = (s: Store) => s;',
      ].join('\n'),
    };
    expect(findImplementations('Store', files)).toEqual([]);
  });

  it('escapes regex metacharacters in the name', () => {
    expect(findImplementations('A.B', { 'src/x.ts': 'class Q implements AxB {}' })).toEqual([]);
    expect(findImplementations('A.B', { 'src/x.ts': 'class Q implements A.B {}' })).toEqual(['src/x.ts']);
  });
});

describe('checkIntegrationCoverage', () => {
  const decl = 'export interface Store {\n  get(id: string): string;\n}\nexport type Probe = (id: string) => Promise<boolean>;\n';

  it('IG-01: a behavioural boundary with no implementation and no exemption is CRITICAL', () => {
    const report = checkIntegrationCoverage({ sourceFiles: { 'src/store.ts': decl }, repoFiles: ['src/store.ts'] });
    expect(report.ok).toBe(false);
    expect(report.boundaries.map((b) => b.name)).toEqual(['Probe', 'Store']);
    expect(report.implementations).toEqual({ Probe: [], Store: [] });
    expect(report.findings).toHaveLength(2);
    expect(report.findings[0]).toMatchObject({
      id: 'IG-01',
      severity: 'CRITICAL',
      boundary: 'Probe',
      where: 'src/store.ts :: function_type Probe',
      what: 'Exported function type with no non-test implementation in the runtime source.',
    });
    expect(report.findings[1]).toMatchObject({
      id: 'IG-01',
      boundary: 'Store',
      where: 'src/store.ts :: interface Store',
      what: 'Exported interface with no non-test implementation in the runtime source.',
    });
    expect(report.findings[1].why).toContain('P-DM-001');
  });

  it('ok path: every boundary implemented, or exempted by an existing file / a declared dependency', () => {
    const report = checkIntegrationCoverage({
      sourceFiles: {
        'src/store.ts': decl,
        'src/impl.ts': 'export class Mem implements Store {\n  get(id: string) { return id; }\n}\n',
        'src/other.ts': 'export interface Pool {\n  connect(): void;\n}\nexport interface Host {\n  show(): void;\n}\n',
      },
      repoFiles: ['./src/store.ts', 'src/impl.ts', './apps-script/Code.gs'],
      exemptions: {
        Probe: { implementedIn: 'apps-script/Code.gs', reason: 'shim' },
        Pool: { implementedBy: 'pg', reason: 'node-postgres' },
        Host: { implementedIn: './apps-script/Code.gs', reason: 'leading ./ is normalised on both sides' },
      },
      dependencies: ['pg'],
    });
    expect(report.findings).toEqual([]);
    expect(report.ok).toBe(true);
    expect(report.implementations.Store).toEqual(['src/impl.ts']);
    expect(report.implementations.Probe).toEqual([]);
  });

  it('IG-02: an exemption whose implementedIn file is missing', () => {
    const report = checkIntegrationCoverage({
      sourceFiles: { 'src/store.ts': decl },
      repoFiles: ['src/store.ts'],
      exemptions: { Store: { implementedIn: 'apps-script/Missing.gs', reason: 'x' }, Probe: { implementedIn: 'src/store.ts', reason: 'present' } },
    });
    expect(report.findings).toEqual([
      expect.objectContaining({
        id: 'IG-02',
        severity: 'HIGH',
        boundary: 'Store',
        where: 'src/store.ts :: exemption for Store',
        what: "The exemption for Store names 'apps-script/Missing.gs', which does not exist.",
      }),
    ]);
    expect(report.findings[0].why).toContain('RG-06');
    expect(report.ok).toBe(false);
  });

  it('IG-02: an exemption whose implementedBy package is not a declared runtime dependency (also when none are given)', () => {
    const base = { sourceFiles: { 'src/store.ts': decl }, repoFiles: ['src/store.ts'] };
    const withDeps = checkIntegrationCoverage({
      ...base,
      exemptions: { Store: { implementedBy: 'stripe', reason: 'x' }, Probe: { implementedBy: 'pg', reason: 'ok' } },
      dependencies: ['pg'],
    });
    expect(withDeps.findings.map((f) => [f.id, f.boundary, f.what])).toEqual([
      ['IG-02', 'Store', "The exemption for Store names package 'stripe', which is not a declared runtime dependency."],
    ]);
    const noDeps = checkIntegrationCoverage({ ...base, exemptions: { Store: { implementedBy: 'pg', reason: 'x' }, Probe: { implementedBy: 'pg', reason: 'x' } } });
    expect(noDeps.findings.map((f) => f.boundary)).toEqual(['Probe', 'Store']);
  });

  it('IG-02: an exemption that names neither a file nor a package', () => {
    const report = checkIntegrationCoverage({
      sourceFiles: { 'src/store.ts': decl },
      repoFiles: [],
      exemptions: { Store: { reason: 'trust me' }, Probe: { implementedIn: 'x', reason: 'x' } },
    });
    expect(report.findings.find((f) => f.boundary === 'Store')!.what).toBe('The exemption for Store names neither a file nor a package.');
  });

  it('IG-02: a stale exemption naming something that is not a behavioural boundary', () => {
    const report = checkIntegrationCoverage({
      sourceFiles: {
        'src/store.ts': decl + 'export class Mem implements Store {\n  get(id: string) { return id; }\n}\nexport const p: Probe = async () => true;\n',
      },
      repoFiles: [],
      exemptions: { Nothing: { implementedIn: 'src/store.ts', reason: 'stale' } },
    });
    expect(report.findings).toEqual([
      {
        id: 'IG-02',
        severity: 'HIGH',
        boundary: 'Nothing',
        where: 'exemptions :: Nothing',
        what: 'An exemption names a boundary that is not an exported behavioural interface.',
        why: 'Stale exemptions accumulate into a list nobody reads; remove it or fix the name.',
      },
    ]);
    expect(report.ok).toBe(false);
  });

  it('an implemented boundary is not checked against its exemption (the implementation wins)', () => {
    const report = checkIntegrationCoverage({
      sourceFiles: { 'src/store.ts': decl + 'export class Mem implements Store {\n  get(id: string) { return id; }\n}\nexport const p: Probe = async () => true;\n' },
      repoFiles: [],
      exemptions: { Store: { implementedIn: 'missing.gs', reason: 'would be IG-02 if it were consulted' } },
    });
    expect(report.findings).toEqual([]);
    expect(report.ok).toBe(true);
  });
});

describe('renderIntegrationReport', () => {
  it('lists every boundary with its implementers or "(no implementation)", then each finding', () => {
    const report: IntegrationReport = {
      boundaries: [
        { name: 'Store', kind: 'interface', file: 'src/a.ts', methods: ['get'] },
        { name: 'Probe', kind: 'function_type', file: 'src/a.ts', methods: ['(call)'] },
      ],
      implementations: { Store: ['src/impl.ts', 'src/other.ts'], Probe: [] },
      findings: [{ id: 'IG-01', severity: 'CRITICAL', boundary: 'Probe', where: 'src/a.ts :: function_type Probe', what: 'W.', why: 'Y.' }],
      ok: false,
    };
    const text = renderIntegrationReport(report);
    expect(text.split('\n')[0]).toBe('Integration gate: FAIL — 2 behavioural boundaries, 1 finding(s).');
    expect(text).toContain(`  ${'Store'.padEnd(28)} <- src/impl.ts, src/other.ts`);
    expect(text).toContain(`  ${'Probe'.padEnd(28)} (no implementation)`);
    expect(text).toContain('  CRITICAL IG-01  src/a.ts :: function_type Probe\n           W.\n           Y.');
  });

  it('renders PASS with no finding lines when there are none', () => {
    const text = renderIntegrationReport({
      boundaries: [{ name: 'Store', kind: 'interface', file: 'src/a.ts', methods: ['get'] }],
      implementations: { Store: ['src/impl.ts'] },
      findings: [],
      ok: true,
    });
    expect(text).toBe(`Integration gate: PASS — 1 behavioural boundaries, 0 finding(s).\n  ${'Store'.padEnd(28)} <- src/impl.ts`);
    expect(text).not.toContain('IG-0');
  });
});

describe('this repository', () => {
  function walk(dir: string, out: string[]): void {
    for (const entry of readdirSync(dir)) {
      if (['node_modules', '.git', 'dist', 'coverage'].includes(entry)) continue;
      const full = join(dir, entry);
      if (statSync(full).isDirectory()) walk(full, out);
      else out.push(relative(REPO_ROOT, full));
    }
  }

  it('every exported behavioural boundary in src/ has a production implementation or a verified exemption (P-DM-001)', () => {
    const repoFiles: string[] = [];
    walk(REPO_ROOT, repoFiles);
    const sourceFiles: Record<string, string> = {};
    for (const rel of repoFiles.filter((f) => f.startsWith('src/') && f.endsWith('.ts'))) {
      sourceFiles[rel] = readFileSync(join(REPO_ROOT, rel), 'utf8');
    }
    expect(Object.keys(sourceFiles).length).toBeGreaterThan(50);
    const pkg = JSON.parse(readFileSync(join(REPO_ROOT, 'package.json'), 'utf8')) as { dependencies?: Record<string, string> };
    const report = checkIntegrationCoverage({
      sourceFiles,
      repoFiles,
      exemptions: DOCMERGE_INTEGRATION_EXEMPTIONS,
      dependencies: Object.keys(pkg.dependencies ?? {}),
    });
    expect(renderIntegrationReport(report)).not.toContain('FAIL');
    expect(report.findings).toEqual([]);
    expect(report.ok).toBe(true);
    // The boundaries the review named are all there, and the S19 adapters stand behind them.
    const names = report.boundaries.map((b) => b.name);
    for (const name of ['HttpClient', 'PaymentGateway', 'LicenseProbe', 'SqlClient', 'StripeEnrolmentLookup', 'CustomerIdLookup']) {
      expect(names).toContain(name);
    }
    expect(report.implementations.PaymentGateway).toContain('src/paymentGateway.ts');
    expect(report.implementations.LicenseProbe).toContain('src/marketplaceLicense.ts');
    expect(report.implementations.StripeEnrolmentLookup).toContain('src/accountIdentities.ts');
    expect(report.implementations.SqlClient).toContain('src/pgClient.ts');
    // Every exemption points at a file that exists or a declared dependency.
    for (const [name, ex] of Object.entries(DOCMERGE_INTEGRATION_EXEMPTIONS)) {
      expect(names).toContain(name);
      if (ex.implementedIn !== undefined) expect(repoFiles).toContain(ex.implementedIn);
      else expect(Object.keys(pkg.dependencies ?? {})).toContain(ex.implementedBy);
    }
  });
});
