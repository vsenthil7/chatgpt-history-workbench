import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import {
  CLAIM_SCOPE_FILES,
  DISCLAIMER_ALLOWLIST,
  SIGNATURE_CLAIM_PATTERNS,
  findSignatureClaims,
  isDisclaimer,
  renderClaimsReport,
  isCodeReference,
  CODE_REFERENCE_ALLOWLIST,
} from '../src/claimsGate';
import { buildSite } from '../src/site';
import { EMPTY_STATES } from '../src/esignOps';
import { HELP_ARTICLES } from '../src/helpCenter';

const ROOT = join(__dirname, '..');

describe('findSignatureClaims — P-DM-007', () => {
  it('flags every phrase in the claim list, case-insensitively', () => {
    const files = {
      'a.md': [
        'Send it for e-sign today',
        'Our ESIGN flow',
        'E-Signature included',
        'An Electronic Signature you can trust',
        'Legally binding in 40 countries',
        'Download the signed PDF',
        'with a Certificate of Completion',
        'sent for signature',
        'Signature requests',
        'signature tracking',
        'fully signed',
      ].join('\n'),
    };
    const claims = findSignatureClaims(files);
    expect(claims.map((c) => c.phrase)).toEqual(SIGNATURE_CLAIM_PATTERNS.map((p) => p.phrase));
    expect(claims[0]).toEqual({ file: 'a.md', line: 1, phrase: 'e-sign', text: 'Send it for e-sign today' });
  });

  it('does NOT flag identifiers and words that merely contain the letters', () => {
    const files = {
      'ids.ts': "import { EsignService } from './esign';\nconst screen = 'esign_requests'; const slug = 'template_designer';",
      'copy.md': 'Approvers sign off in order. Assign a reviewer. The design is signed off.',
    };
    expect(findSignatureClaims(files)).toEqual([]);
  });

  it('allows a line ONLY when it disclaims e-sign, and every allowlist entry is a negation', () => {
    expect(isDisclaimer('Approval requests are not electronic signatures.')).toBe(true);
    expect(isDisclaimer('This is not e-sign.')).toBe(true);
    expect(isDisclaimer('DocMerge Pro does not produce a signed document or a certificate of completion.')).toBe(true);
    expect(isDisclaimer('use a dedicated e-signature service afterwards')).toBe(true);
    expect(isDisclaimer('E-signature requests included')).toBe(false);
    for (const re of DISCLAIMER_ALLOWLIST) {
      expect(re.source).toMatch(/not|dedicated/);
    }
    expect(
      findSignatureClaims({ 'x.md': 'Approval requests are not electronic signatures; e-sign is not offered.' })
    ).toEqual([]);
  });

  it('reports one claim per phrase per line, with the line number', () => {
    const claims = findSignatureClaims({ 'x.md': 'ok\nsent for signature with a signed PDF' });
    expect(claims).toHaveLength(2);
    expect(claims.every((c) => c.line === 2)).toBe(true);
  });

  it('renders a pass and a fail report', () => {
    expect(renderClaimsReport([])).toContain('PASS');
    const report = renderClaimsReport(findSignatureClaims({ 'y.md': 'legally binding' }));
    expect(report).toContain('FAIL — 1 claim(s)');
    expect(report).toContain('y.md:1  "legally binding"  legally binding');
  });
});

describe('THIS REPOSITORY makes no signature claim in user-facing copy', () => {
  const files: Record<string, string> = {};
  for (const f of CLAIM_SCOPE_FILES) {
    files[f] = readFileSync(join(ROOT, f), 'utf8');
  }
  // site/*.html is generated (and git-ignored), so the gate scans what the generator emits.
  const config = JSON.parse(readFileSync(join(ROOT, 'site.config.json'), 'utf8')) as Record<string, string>;
  delete config._readme;
  const built = buildSite(config as never);
  for (const [name, html] of Object.entries(built.files)) {
    files[`site/${name}`] = html;
  }
  // The strings a user reads inside the add-on, beyond the scanned files.
  files['esignOps.ts#EMPTY_STATES'] = Object.values(EMPTY_STATES)
    .map((e) => `${e.message} ${e.actionLabel}`)
    .join('\n');
  files['helpCenter.ts#articles'] = HELP_ARTICLES.map((a) => `${a.title}\n${a.summary}\n${a.body}`).join('\n');

  it('scans every file the gate promises to cover, plus the generated site', () => {
    expect(Object.keys(built.files).length).toBeGreaterThan(0);
    for (const f of CLAIM_SCOPE_FILES) {
      expect(files[f].length).toBeGreaterThan(0);
    }
  });

  it('finds zero claims', () => {
    const claims = findSignatureClaims(files);
    expect(renderClaimsReport(claims)).toContain('PASS');
    expect(claims).toEqual([]);
  });

  it('the only disclaimer in scope is the help-centre sentence that says the feature is NOT e-sign', () => {
    const disclaimers: string[] = [];
    for (const [file, text] of Object.entries(files)) {
      text.split('\n').forEach((line) => {
        if (isDisclaimer(line)) {
          disclaimers.push(file);
        }
      });
    }
    expect(new Set(disclaimers)).toEqual(new Set(['src/helpCenter.ts', 'helpCenter.ts#articles']));
  });

  it('module headers of esign.ts and esignOps.ts state the P-DM-007 position', () => {
    for (const f of ['esign.ts', 'esignOps.ts']) {
      const header = readFileSync(join(ROOT, 'src', f), 'utf8').slice(0, 1200);
      expect(header).toContain('Approval requests');
      expect(header).toContain('P-DM-007');
    }
    const esign = readFileSync(join(ROOT, 'src', 'esign.ts'), 'utf8');
    expect(esign).toContain('produces no signature');
  });
});

/**
 * DM-F34/DM-F36 (S19): the gate's scope was drawn around the marketplace listing, so the
 * privacy pack and the two pen-test documents — all three read by third parties — went on
 * describing a signature product for four days after the rename. Widening the scope
 * surfaced one line that is not a claim at all: a table naming `src/esign.ts` as a module.
 * That needed a second, differently-argued exemption rather than a fourth "disclaimer".
 */
describe('code references are not claims (DM-F34/DM-F36)', () => {
  it('exempts a line whose only signature token is a module path', () => {
    expect(isCodeReference('| importers | `src/esign.ts`, `src/batchOps.ts` |')).toBe(true);
    expect(findSignatureClaims({ 'LISTING_PACK.md': 'see `src/esign.ts`' })).toEqual([]);
  });

  it('still reports a line that names a module AND makes a real claim', () => {
    const line = '`src/esign.ts` sends documents for signature';
    expect(isCodeReference(line)).toBe(false);
    const claims = findSignatureClaims({ 'LISTING_PACK.md': line });
    expect(claims.map((c) => c.phrase)).toContain('for signature');
  });

  it('does not exempt the bare word, only a path with its extension', () => {
    expect(isCodeReference('our esign feature is legally binding')).toBe(false);
  });

  it('keeps the two exemption concepts separate', () => {
    expect(CODE_REFERENCE_ALLOWLIST.length).toBeGreaterThan(0);
    for (const re of CODE_REFERENCE_ALLOWLIST) {
      expect(DISCLAIMER_ALLOWLIST.map(String)).not.toContain(String(re));
    }
  });

  it('covers every document a third party reads', () => {
    for (const file of ['DATA_FLOW_AND_RETENTION.md', 'PENTEST_SCOPING_BRIEF.md', 'PENTEST_OUTREACH.md']) {
      expect(CLAIM_SCOPE_FILES).toContain(file);
    }
  });
});
