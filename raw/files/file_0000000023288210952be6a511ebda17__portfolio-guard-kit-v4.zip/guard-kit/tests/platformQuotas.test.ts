import { P95_BUDGETS_MS } from '../src/performance';
import {
  APPS_SCRIPT_LIMITS,
  DRIVE_QUOTA_UNITS,
  PLATFORM_QUOTAS,
  QUOTA_REVERIFICATION_DATE,
  QuotaGovernor,
  checkFeasibility,
  quotaFor,
  bindingConstraint,
  unstableQuotas,
  unverifiedQuotas,
  changedQuotas,
  citationFor,
} from '../src/platformQuotas';

const NOW = 1_757_800_000_000;

describe('Verified platform quotas — VER-DM6', () => {
  it('records the Docs write ceiling that bounds every batch', () => {
    const q = quotaFor('docs', 'write');
    expect(q.perMinutePerUser).toBe(60);
    expect(q.perMinutePerProject).toBe(600);
  });

  it('refuses to guess a quota it has not verified', () => {
    // 'slides' is genuinely unrecorded; Drive was added in VER-DM7.
    expect(() => quotaFor('slides', 'write')).toThrow('check before assuming one');
    expect(PLATFORM_QUOTAS.every((q) => q.source.length > 5)).toBe(true);
  });

  it('THE CONTRADICTION: our p95 budget promised more than the platform allows', () => {
    // 1500ms per row implies 40 documents a minute sustained — under the ceiling —
    // but the budget makes no allowance for the ceiling existing at all.
    const impliedFromBudget = Math.floor(60_000 / P95_BUDGETS_MS.batch_row);
    expect(impliedFromBudget).toBe(40);

    // The ST-088 load profile is the real breach: 20/min expected at 5x = 100/min.
    const loadTestImplied = 20 * 5;
    const result = checkFeasibility([
      { name: 'ST-088 load test at 5x expected traffic', api: 'docs', operation: 'write', impliedPerMinutePerUser: loadTestImplied },
    ]);
    expect(result.ok).toBe(false);
    expect(result.findings[0].message).toContain('platform allows 60');
    expect(result.findings[0].message).toContain('cannot be kept');
  });

  it('passes a promise that respects the ceiling', () => {
    expect(
      checkFeasibility([
        { name: 'Paced batch generation', api: 'docs', operation: 'write', impliedPerMinutePerUser: 60 },
      ]).ok
    ).toBe(true);
  });

  it('records the Apps Script ceiling that bounds the form forwarder', () => {
    // VER-DM2's forwarder makes one UrlFetch per submission, so this is the real
    // per-customer daily limit on form-triggered generation.
    expect(APPS_SCRIPT_LIMITS.urlFetchPerDayConsumer).toBe(20_000);
    expect(APPS_SCRIPT_LIMITS.urlFetchPerDayWorkspace).toBe(100_000);
  });
});

describe('QuotaGovernor — pacing instead of being throttled', () => {
  function build(limit = 3) {
    let time = NOW;
    return { g: new QuotaGovernor(limit, () => time), advance: (ms: number) => { time += ms; } };
  }

  it('allows work up to the ceiling with no delay', () => {
    const { g } = build();
    for (let i = 0; i < 3; i++) {
      expect(g.delayFor('acct-1')).toBe(0);
      g.record('acct-1');
    }
    expect(g.usedInWindow('acct-1')).toBe(3);
  });

  it('reports zero usage for an account that has done nothing', () => {
    const { g } = build();
    expect(g.usedInWindow('never-seen')).toBe(0);
  });

  it('asks the caller to wait once the ceiling is reached, rather than earning a 429', () => {
    const { g, advance } = build();
    for (let i = 0; i < 3; i++) g.record('acct-1');
    const delay = g.delayFor('acct-1');
    expect(delay).toBeGreaterThan(0);
    expect(delay).toBeLessThanOrEqual(60_000);
    advance(delay);
    expect(g.delayFor('acct-1')).toBe(0);
  });

  it('meters each account separately, so one heavy customer cannot stall another', () => {
    const { g } = build();
    for (let i = 0; i < 3; i++) g.record('acct-1');
    expect(g.delayFor('acct-1')).toBeGreaterThan(0);
    expect(g.delayFor('acct-2')).toBe(0);
  });

  it('forgets calls older than the window', () => {
    const { g, advance } = build();
    for (let i = 0; i < 3; i++) g.record('acct-1');
    advance(60_001);
    expect(g.usedInWindow('acct-1')).toBe(0);
    expect(g.delayFor('acct-1')).toBe(0);
  });

  it('gives an HONEST completion estimate for a large batch', () => {
    const governor = new QuotaGovernor(60, () => NOW);
    // Inside one minute's allowance: no enforced wait.
    expect(governor.estimateCompletionMs(60)).toBe(0);
    // 500 rows for one user cannot finish in under 8 minutes, whatever our code does.
    expect(governor.estimateCompletionMs(500)).toBe(8 * 60_000);
    expect(governor.estimateCompletionMs(1)).toBe(0);
  });

  it('uses Date.now by default', () => {
    const g = new QuotaGovernor(1);
    expect(g.delayFor('a')).toBe(0);
    g.record('a');
    expect(g.delayFor('a')).toBeGreaterThan(0);
  });
});

describe('Portability — the mechanism travels, the numbers do not', () => {
  it('accepts another platform quota table instead of inheriting Google numbers', () => {
    const zohoLike = [
      { api: 'crm', operation: 'write' as const, perMinutePerUser: 10, perMinutePerProject: 100, source: 'example', verifiedOn: '2026-09-20' },
    ];
    expect(quotaFor('crm', 'write', zohoLike).perMinutePerUser).toBe(10);
    const result = checkFeasibility(
      [{ name: 'Bulk sync', api: 'crm', operation: 'write', impliedPerMinutePerUser: 50 }],
      zohoLike
    );
    expect(result.ok).toBe(false);
    expect(result.findings[0].message).toContain('platform allows 10');
  });

  it('still refuses to guess when the supplied table lacks the entry', () => {
    expect(() => quotaFor('unknown', 'write', [])).toThrow('check before assuming one');
  });
});

describe('Drive quota and the binding constraint — VER-DM7', () => {
  it('records Drive from the published quota-unit model, with the derivation written down', () => {
    const drive = quotaFor('drive', 'write');
    // 325,000 units/min/user at 50 units an edit. The number is not asserted on its own:
    // it is asserted to EQUAL the division, so a figure typed in by hand cannot survive.
    expect(drive.perMinutePerUser).toBe(DRIVE_QUOTA_UNITS.perMinutePerUser / DRIVE_QUOTA_UNITS.unitsPerEdit);
    expect(drive.perMinutePerProject).toBe(
      DRIVE_QUOTA_UNITS.perMinutePerProject / DRIVE_QUOTA_UNITS.unitsPerEdit
    );
    expect(drive.perMinutePerUser).toBe(6_500);
    expect(drive.caveat).toContain('Re-verify');
    expect(unstableQuotas().map((q) => q.api)).toEqual(['drive']);
  });

  it('records WHAT CHANGED at the re-verification rather than silently moving the number', () => {
    const drive = quotaFor('drive', 'write');
    expect(changedQuotas().map((q) => q.api)).toEqual(['drive']);
    expect(drive.changeNote).toContain('12,000');
    expect(drive.changeNote).toContain('6,500');
  });

  it('DOCS is the binding constraint on a batch, not Drive filing', () => {
    const binding = bindingConstraint();
    expect(binding.api).toBe('docs');
    expect(binding.operation).toBe('write');
    expect(binding.perMinutePerUser).toBe(60);
    // Drive sits two orders of magnitude above it on either published model.
    expect(quotaFor('drive', 'write').perMinutePerUser).toBeGreaterThan(binding.perMinutePerUser * 100);
  });

  it('surfaces a future change that made a different API the constraint', () => {
    const revised = [
      { api: 'docs', operation: 'write' as const, perMinutePerUser: 60, perMinutePerProject: 600, source: 's', verifiedOn: '2026-09-20' },
      { api: 'drive', operation: 'write' as const, perMinutePerUser: 30, perMinutePerProject: 300, source: 's', verifiedOn: '2026-09-20' },
    ];
    expect(bindingConstraint(revised).api).toBe('drive');
  });

  it('the governor is configured to the binding constraint, not to a looser one', () => {
    const governor = new QuotaGovernor(bindingConstraint().perMinutePerUser, () => NOW);
    // 500 rows at the true ceiling: eight minutes, matching the help-centre wording.
    expect(governor.estimateCompletionMs(500)).toBe(8 * 60_000);
  });
});

describe('Re-verification discipline — S17', () => {
  it('every recorded quota carries the date it was last read at a primary source', () => {
    for (const q of PLATFORM_QUOTAS) {
      expect(q.verifiedOn).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      expect(q.verifiedOn).toBe(QUOTA_REVERIFICATION_DATE);
    }
    expect(APPS_SCRIPT_LIMITS.verifiedOn).toBe(QUOTA_REVERIFICATION_DATE);
    expect(DRIVE_QUOTA_UNITS.verifiedOn).toBe(QUOTA_REVERIFICATION_DATE);
  });

  it('nothing in the shipped table is a figure we could not re-reach', () => {
    expect(unverifiedQuotas()).toEqual([]);
  });

  it('a figure carried forward unverified says so in its own citation', () => {
    const stale = {
      api: 'slides',
      operation: 'write' as const,
      perMinutePerUser: 60,
      perMinutePerProject: 600,
      source: 'Slides API usage limits',
      verifiedOn: '2026-01-01',
      unverified: true,
    };
    expect(unverifiedQuotas([stale])).toEqual([stale]);
    expect(citationFor(stale)).toContain('LAST ATTEMPT FAILED');
    expect(citationFor(stale)).toContain('2026-01-01');
  });

  it('cites a verified figure plainly, with its source and date', () => {
    const citation = citationFor(quotaFor('docs', 'write'));
    expect(citation).toContain('Docs API usage limits');
    expect(citation).toContain(QUOTA_REVERIFICATION_DATE);
    expect(citation).not.toContain('LAST ATTEMPT FAILED');
  });

  it('reports no change for a table whose figures all held', () => {
    expect(changedQuotas([quotaFor('docs', 'write')])).toEqual([]);
  });
});
