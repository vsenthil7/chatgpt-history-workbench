# Portfolio defect-class register

Fifteen classes of defect that have each appeared in **two or more** of the four products
reviewed so far, every one of them in code sitting at 100% coverage.

**What this is built from.** The recorded findings of DocMerge Pro, RevRescue, TeleField
and FlowCast. It is a synthesis of session records, not a re-reading of the sibling
codebases — the guard kit has still never been run against one (R-D18 on DocMerge). Treat
every "probably also present" as a hypothesis to test, which is the whole point of writing
the list down.

**Why it matters more than any individual finding.** These products were built by one
person to one standard and reviewed independently of each other. A class that recurs
across three of them is not bad luck; it is a property of how the work is done, and it
will appear in the eight products not yet reviewed.

---

## The classes

### C-01 — Built, tested, and called from nowhere

The single most common class in the portfolio.

- **DocMerge**: DM-F02 read-only mode and DM-F03 plan limits — both fully built, fully
  tested, both promised to customers in the help centre, neither called by anything.
- **RevRescue**: F-RR01, every engine was its own only reader. F-RR02/F-RR03, read-only
  and plan limits again. After those were fixed, an automated reachability gate
  immediately found **five more** orphans (alerts, dispute, dunning, outcomefee, retry).
- **TeleField**: the retention sweep erased only telemetry, and later had no caller at all.

Gated by: RevRescue's reachability gate, TeleField's equivalent. **Not in the guard kit.**

### C-02 — A published claim with no code behind it

- **DocMerge**: the help centre promised two behaviours the product did not have.
- **RevRescue**: F-RR04 fee disputes, F-RR05 export/delete, F-RR12 cross-channel opt-out —
  all in the FAQ, help articles or trust page, none implemented.
- **TeleField**: "encrypted at rest" published in four places while tokens were plaintext.

Gated by: published-claims gates in RevRescue and TeleField. **Not in the guard kit.**

### C-03 — Deletion that does not delete

- **DocMerge**: `executeDue(deleter)` took a callback no production code supplied, so the
  published 30-day policy had nothing behind it.
- **RevRescue**: F-RR05, then F-RR09 — uninstall deleted **nothing**, a recurrence of the
  same defect after a partial fix. Later F-RR18: two domains shared one table, so export
  duplicated rows and delete reported a partial purge.
- **TeleField**: delete-my-data left the person's records.

Gated by: `purge.ts`. Pair it with `ON DELETE CASCADE`, so completeness is a property of
the schema rather than of code someone must remember to update.

### C-04 — Authentication mistaken for authorisation

- **DocMerge**: DM-F16/F17/F21 — template and signature lookups took an id from the
  request body; pause/resume on another tenant's jobs needed only a guessed id.
- **TeleField**: identity came from a spoofable `x-user-id` header; `/demo/reset` was
  unauthenticated.
- **RevRescue**: OBS-RR5, header-declared identity, closed with HMAC-signed sessions.

Gated by: `tenantGate.ts`.

### C-05 — The live platform contract is not what the code assumes

Only ever found by checking live documentation. Internal review cannot see it.

- **DocMerge**: there is no uninstall webhook; Forms cannot POST to a URL; the SLO promised
  throughput the Docs API forbids.
- **RevRescue**: VER-RR03, the webhook read its event id from a header Stripe never sends —
  every real webhook would have been refused. VER-RR02, the pinned API version was not a
  valid version string. F-RR08, every event went to the uninstall handler.
- **TeleField**: VER-T1, the webhook format would have 400'd every webhook; a missing
  `redirect_uri` on token exchange; per-org data centre read from the wrong place.

Gated by: `platformQuotas.ts`, and only for quotas. **The contract shape is ungated
everywhere.** This class has produced a live-blocker in three of four products.

### C-06 — Unbounded growth

- **DocMerge**: eleven append-only arrays.
- **TeleField**: FIFO caps bounded memory only, so Postgres grew without limit.

Gated by: `ledger.ts`, for in-process stores. TeleField's instance is the warning:
bounding the array is not bounding the table.

### C-07 — The test pins the defect

- **DocMerge**: DM-F22, an exemption right about its outcome and wrong about its reason.
- **RevRescue**: L-RR4, three tests asserted the wrong API-version format. L-RR11, a test
  *documented* a defect instead of failing on it — three occurrences. F-RR19, the restore
  drill treated an absent domain as "0 of 0, all good". F-RR21, returning raw error text
  to the caller was asserted as correct.

Gated by: the `unverifiedExemptions()` meta-gate, and only for exemptions. Otherwise
ungated, and probably ungatable — this one needs a reader who asks what a test would do if
the behaviour were wrong.

### C-08 — The gate itself passes vacuously

- **RevRescue**: L-RR6, packaging dropped `content/` and the claims gate passed on an
  empty input. L-RR7, a whitelist hid a genuinely orphaned module. L-RR13, a **type-only
  import** satisfies the reachability gate, so a module can look wired while nothing
  constructs it.
- **DocMerge**: every CI job installed with `npm ci` and there was no lockfile, so CI had
  never run at all.

Gated by: `releaseGate.ts` RG-01/RG-02/RG-03. RevRescue's rule is the one to copy
everywhere — **a gate that cannot see its inputs must throw, not pass.**

### C-09 — Nothing actually serves the application

- **RevRescue**: GAP-RR4 — no port was bound, no `npm start` existed. The app could not
  receive a request.
- **TeleField**: no `listen()`, no `npm start`.
- **DocMerge**: the deploy job echoed a placeholder and exited zero, so `main` showed a
  green deploy for five sprints that deployed nothing.

Gated by: `releaseGate.ts` RG-02 for the false-green half. The missing-entrypoint half is
ungated.

### C-10 — A silent default where a throw belongs

- **RevRescue**: F-RR20 — the opt-out port defaulted to "nobody has ever opted out" and
  the send ledger to memory, so opted-out customers would be messaged and every restart
  re-sent whole sequences. L-RR15 states it plainly.
- **FlowCast**: two critical deploy-configuration findings, closed with a fail-closed boot
  check.
- **DocMerge**: `boot.check.js` refuses to start misconfigured — the class handled well,
  by having been bitten elsewhere.

Ungated. Probably the cheapest new module to write.

### C-11 — A block inherited rather than reasoned

- **RevRescue**: L-RR8 and L-RR10 — a park audit found **four** items wrongly blocked
  behind one decision, roughly a day of buildable work idle, because the block had been
  inherited rather than reasoned.
- **DocMerge**: CASA sat on the board as a multi-week paid item since S6 on an unchecked
  assumption; the listing icons were blocked behind "needs a running app" alongside the
  screenshots, and did not need one.

Not a code gate. A standing question: *who* blocked this, and does their reason still
apply to this specific item?

### C-12 — The core loop is absent

The highest-impact class found so far.

- **RevRescue**: GAP-RR3 — there was **no scheduler**. Retries were written to a queue
  nothing drained, and dunning could only ever fire its day-0 step. The entire product
  loop was missing behind 252 passing tests at 100%.
- **TeleField**: `src/scheduler.ts` had to be built during the review.

Ungated, and it is not clear a static gate could find it. It became visible when the
question changed from "is this module correct" to "does the whole thing run".

### C-13 — A partial fix reads as a complete one

- **RevRescue**: L-RR3 and L-RR5 — recurred twice in a single day, both times caught by
  tooling rather than by the fix feeling wrong. F-RR09 was the recurrence of F-RR05.
- **DocMerge**: handled well — DM-F19/F20 were left as explicit decisions with a test
  asserting they are unreachable, which is what keeps a decision a decision.

Gated by: pinned regressions, plus re-running the gate rather than re-reading the fix.

### C-14 — Testing against a fake hides what matters

- **RevRescue**: L-RR9 — swapping a stub for real embedded Postgres produced two failures
  in minutes: multi-statement DDL rejected by the prepared-statement path (every migration
  would have failed on first contact with a live server), and BYTEA rejecting the sealed
  JSON envelope.
- **TeleField**: R-T4 — a DATE column rehydrated as the string "Tue Sep 01", and the flush
  was wired into one code path only, so OAuth callback and webhook writes sat queued.
- **DocMerge**: the adapter was tested only against a `FakeClient`, and the module header
  said so. **Checked 15 Sep 2026 against real embedded Postgres: clean** — ten contract
  tests including a wrapper that reproduces node-postgres returning BIGINT as a string.
  A negative result, and worth having.

Gated by: a database-backed contract suite. PGlite makes it cheap — in-process, no server,
no container, so it runs in CI on a clean checkout.

### C-15 — The instrument reports a clean number because it is not looking

- **DocMerge**: the submission dry run reported 10 of 20 while two *required* listing items
  were absent from the checklist entirely. Coverage was 100% while two promised features
  were called from nowhere.
- **RevRescue**: 100% coverage across 16 modules no application ever called.
- **TeleField**: a restore drill stayed green while the export bundle omitted stops.

This is the parent class of C-08 and arguably of all of them. The question it answers is
not "did the check pass" but "what would this check do if the thing were broken".

---

## Coverage map

| Class | In the guard kit | In `at-review-gates` (RevRescue) | In TeleField's gates |
| --- | --- | --- | --- |
| C-01 orphan modules | **no** | reachability | reachability |
| C-02 published claims | partial (`purge` only) | published-claims | published-claims |
| C-03 deletion | `purge.ts` | yes | yes |
| C-04 tenant isolation | `tenantGate.ts` | — | public surface |
| C-05 platform contract | quotas only | — | — |
| C-06 unbounded growth | `ledger.ts` | — | — |
| C-07 test pins defect | exemptions only | — | — |
| C-08 vacuous gate | `releaseGate.ts` | config-drift, throw-on-blind | — |
| C-09 nothing serves | partial | — | — |
| C-10 silent default | **no** | — | — |
| C-11 inherited block | n/a — process | park audit | — |
| C-12 absent core loop | **no** | — | — |
| C-13 partial fix | regressions | regressions | regressions |
| C-14 fake vs real engine | contract suite (DocMerge) | PGlite | real PG 16 |
| C-15 blind instrument | `releaseGate.ts` | throw-on-blind | — |

## The finding this map produces

**Three portable gate packages now exist for one portfolio**, built independently within
days of each other: `at-review-gates v1.0.0` (RevRescue, offered as a drop-in for all
eleven products), the five gates in TeleField's `docs/REVIEW_GATES.md`, and this kit. They
overlap, none is a superset, and each product is adopting a different subset — so a class
caught in one product stays live in another because the gate that finds it was packaged
somewhere else.

Consolidating them is the highest-value portfolio task available, and it needs no live
environment, no decision and no budget — only the three packages in one place. On the
evidence above, a merged package would need to add reachability and published-claims (from
RevRescue), and would still leave C-05, C-10 and C-12 ungated in every product.

**Nothing here has been verified against a sibling codebase.** It is the sharpest list of
hypotheses the portfolio's own records can produce, and it stays a list of hypotheses until
someone runs it.


---

## v4 addendum — four classes added 20 September 2026 (external review PPLX V001)

The review that produced these executed the code rather than reading it, and every one of
the four was invisible to a 100% coverage gate, a tenant gate, a release gate and two
internal cold-review passes.

### C-16 — the injected boundary that never got an implementation

An exported interface with only test doubles behind it, standing in for a system the
product cannot work without. Distinct from C-01 (built, tested, called from nowhere):
there, the code exists and nothing calls it; here, the code was never written, and every
caller was tested against a double and passed.

**Why every instrument misses it.** Coverage measures the lines that exist. A file that was
never written has no lines to leave uncovered, so *the more boundaries you inject, the
cleaner the number gets*. Dependency injection — correct and admirable for testability — is
what makes the omission invisible.

**Caught by:** `integrationGate.ts` (v4). **Exposure:** every product in the portfolio that
uses injected boundaries, which is all of them. Expect it to fire.

### C-17 — the runtime dependency that resolves everywhere except production

A module required by runtime code and declared in `devDependencies` or nowhere. Resolves on
every laptop and in every CI job, because `npm ci` installs devDependencies too. Fails only
in a production image built with `--omit=dev` — or, as in DocMerge, on the first execution
of a code path that had never been run.

**Caught by:** `runtimeDeps.ts` (v4), plus an SBOM assertion that the runtime component
count exceeds zero.

### C-18 — the exemption whose compensating control was never performed

A gate exemption naming a verification that nobody did. DocMerge's single coverage
exemption read "verified by booting the server, not by unit tests"; the server had never
been booted, and the defect was inside the exemption. This is DM-F22 (an exemption right
about its outcome and wrong about its reason) generalised from one gate to all of them.

**The rule:** every exemption, of any gate, needs a named test, and the gate must fail when
the named test does not exist. **Caught by:** `releaseGate.ts` RG-06 (v4);
`tenantGate.unverifiedExemptions()` already did this for its own exemptions.

### C-19 — the entrypoint that starts nothing

A declared start script pointing at a module that exports functions and invokes none of
them. The process exits 0, and whatever launched it records a clean start. Any safety
property living inside the uninvoked function — a fail-closed readiness check, in
DocMerge's case — is unreachable while every document relies on it.

**Caught by:** `releaseGate.ts` RG-05 (v4) and, more conclusively, a smoke test that spawns
the built artefact and asserts the port answers. Prefer both: the gate catches the shape on
every commit, the smoke test catches everything else.

---

## What the v4 additions do to the register's own conclusion

The v3 register's central recommendation — merge the three portable gate packages, because
a class caught in one product stays live in another purely because the gate that finds it
was packaged elsewhere — is **unchanged and now stronger**, because there are four more
classes to be unevenly distributed.

Its central caveat is also unchanged, and is the most important sentence in this document:
**this register is synthesised from session records, not from reading the sibling
codebases. Every cross-product claim in it remains a hypothesis, and the kit has still
never been run against a sibling.** One run converts the list into evidence either way, and
it is still the cheapest item on the board.
