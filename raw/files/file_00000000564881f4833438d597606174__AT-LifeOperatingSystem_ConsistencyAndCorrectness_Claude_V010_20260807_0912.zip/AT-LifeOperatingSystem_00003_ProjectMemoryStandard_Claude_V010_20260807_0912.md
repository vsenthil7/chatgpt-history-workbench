# Project Memory Standard

**AT-LOS | Claude | V010 | 07-Aug-2026 09:12 BST**
**Supersedes:** the V008 standard, which was still shipped unchanged in V009 while describing a register model V009 had already superseded.

One living document that survives across versions, across AI systems, and across gaps in attention, so no idea is rediscovered and no capability is spoken of as if it exists.

---

## 1. Fifteen registers across sixteen worksheets

`00_Index` is not a register. D-023's ceiling counts **registers**, not worksheets.

| Tab | Holds | Cannot hold |
|---|---|---|
| 01_ActiveSprint | Work being executed | Anything without a Decision Log reference |
| 02_NextSprint | Decided, not started | Anything without a named unblocker |
| 03_ParkingLot | Ideas kept, not worked | Anything without a trigger **and an expiry** |
| 04_ResearchRepository | Needs evidence before planning | Anything already decided |
| 05_DecisionLog | Every decision, reason, date, owner | Edits. Reversals are new rows |
| 06_DeferredDecisions | **CLOSED.** Migrated to 13_DecisionQueue | New rows of any kind |
| 07_Assumptions | Silent dependencies | Anything without a named failure consequence |
| 08_LessonsLearned | What each version got wrong | Praise |
| 09_FutureVision | Long-term IP | Dates |
| 10_HallucinationRegister | True state of every capability | Aspirational states |
| 11_VersionHistory | Added, removed, why, still open | Retrofitted entries |
| 12_Archive | Completed and rejected | Deletions |
| 13_DecisionQueue | Decisions needed but intentionally postponed | A row missing any of the five mandatory fields |
| 14_SprintTracker | Live task board with proof of completion | A Done row whose Register column says No |
| 15_NamingRegister | Naming candidates and rejections | A claim without a verification level and source |

## 2. Rules

1. **Nothing is deleted.** Completed and rejected work moves to Archive with a reason.
2. **Every parked idea carries a review trigger and an expiry.**
3. **Every register row has an owner.**
4. **Nothing enters Active Sprint without a Decision Log entry.**
5. **The Decision Log is append-only.** Reversals are new rows; the original is marked Superseded, never edited.
6. **Every architecture change states why**, in the Decision Log and an ADR.
7. **No capability may be described above its Hallucination Register state.** Binds humans and AI equally.
8. **Version History is written at release**, never reconstructed later.
9. **One review per month**, not per version.
10. **External factual claims state their verification level and source** (D-026 as narrowed by **D-035**). This applies to claims about the outside world — company registrations, trademarks, package availability — not to internal planning rows. V009's wording claimed every row in every register carried verification columns; most do not, and the claim was itself unverified.
11. **A postponed decision needs five fields**: why it matters, the trigger, the owner, the latest acceptable date, the cost of delay.
12. **A task is not Done until its Hallucination Register row carries an implementation reference.** The register has an Implementation Ref column for exactly this. Documentation never moves Planned to Implemented.
13. **Fifteen registers is the ceiling** (D-023). No new register without a Decision Log entry.
14. **Architecture documentation lives outside this workbook** (D-029), and inside the repository it has **one machine-readable source** — `architecture.toml` — from which documents are generated (**D-039**). Hand-editing a generated table fails the build.
15. **Where a document and an executable test disagree, the test wins** (D-028).
16. **A capability state must name what it is, not what it is intended to be** (**D-040**). An in-memory dictionary is not persistence. A regression harness is not a mutation baseline. Line coverage of existing code is not functional coverage (**D-045**).

## 3. What this standard guards against

Five failures, all of which have happened here:

- **Rediscovery.** V002 and V003 both raised Q-001 as Critical and both left it open.
- **Capability drift.** By V003 the documents discussed conversation reconstruction as if it were software. None existed.
- **Scope substitution.** V001–V003 produced three packages in thirteen hours with one completed task, which was producing a package.
- **Asserted enforcement.** V006 said CI enforced the architecture rules. There was no CI. ADR-003 named `ruff` and `mypy --strict` from V006; neither ran until V010.
- **Document drift under a guard that did not cover it.** V008 added a README check. In V009 the *authoritative* architecture document silently stayed a version behind, and nothing noticed. Rule 14 and D-039 exist because of this.

## 4. Review

Reviewed 06-Sep-2026 with the 30-day measurement (D-010). If the measurement failed, the V004 stop rule applies here too.
