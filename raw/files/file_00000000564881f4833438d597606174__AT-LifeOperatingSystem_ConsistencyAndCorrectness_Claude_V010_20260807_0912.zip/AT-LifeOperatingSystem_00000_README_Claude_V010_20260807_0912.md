# AT-Life Operating System (AT-LOS) - V010

**Release:** `AT-LifeOperatingSystem_ConsistencyAndCorrectness_Claude_V010_20260807_0912`
**Prepared by:** Claude · **07-Aug-2026 09:12 BST**
**Internal codename:** AT-LOS · **Public brand:** undecided, blocked (D-022)

## 14 findings raised. I verified each against the code. All 14 were real.

**Finding 1 is the one that matters, and it is a failure of mine specifically.**

`docs/ARCHITECTURE.md` — the file `READ_THIS_FIRST.md` tells a new engineer to read *first* — was still the V008 document. It said `at-evidence` was L2 after ADR-005 moved it to L3. It said `at-store` was PLANNED after I built it. It carried `person_id = sha256(canonical_name)` after ADR-006 replaced it. It said "11 of 15 RTM enforced" when there were 19.

In V008 I added a guard so the README could not claim absent code. It worked. The **more important** document drifted instead, because the architecture existed in three hand-maintained copies and I only guarded one.

So my V009 statement — *"an engineer can now build at-identity, at-consent and at-evidence without contradiction"* — was false. They would have read the wrong architecture.

## The structural fix

**`architecture.toml` is now the single source of truth.** The guard tests *load* `LAYERS`, `ALLOWED` and `ADAPTERS` from it. `docs/ARCHITECTURE.md` sections B and C are *generated* from it by `tools/gen_architecture.py`. Three tests enforce it: manifest internally consistent, manifest state matches disk, document matches manifest byte for byte.

Editing those tables by hand now fails the build. One file, one command, no drift.

## Other corrections

**The parser bug ChatGPT found was real.** A malformed timestamp inside a pending multi-line message did not flush it, so a later continuation stretched the event locator across the failed line and `line_coverage` reported 100% with an errored line. Fixed, with two regression tests — and the fix improved behaviour further: the orphaned continuation now becomes its own recorded issue instead of vanishing.

**`at-store` was overstated and is now named honestly.** `EventStore` → `InMemoryEventStore`, `durable = False`, manifest state `Partial`. It holds no raw bytes and does not survive a restart. S1-10 downgraded Done → Partial; durable persistence is S1-20, not built.

**Provenance no longer disappears.** `SourceContent` (content-addressed bytes) split from `SourceIngestion` (workspace, owner, source label, time). Two workspaces importing identical bytes now produce **one content, two ingestions**. V009 keyed on the hash alone and silently discarded the second importer — in the package whose job is provenance.

**ADR-005 corrected.** Only orchestration (`at-cli`) may import a concrete adapter. The prose named `at-store`, which the L1 rule and the allowlist both forbade. Adapter consumers are now derived from the manifest, so prose and rule cannot diverge.

**Versions aligned at 0.3.0**, with a guard test, and the verification artifact now *reads* versions instead of hard-coding them.

**Claims narrowed to what is true.** "Functional is at 100%" was false — it is line coverage of the code that exists. The memory NFR was false — only hashing streams; ingestion reads the whole file. Both corrected.

**Mutation testing is now reproducible.** `tools/mutation_regression.py`, 6 mutants, each re-introducing a real historical defect, **all 6 killed**, blocking CI job. Not a manual claim.

**ADR-003's promised gates now exist.** `ruff` and `mypy --strict` run as blocking CI jobs. They were named from V006 and ran nowhere until now. Both are clean.

## Prove it

```bash
cd at-platform
python -m pytest -q                            # 67 passed, 1 skipped, 100% coverage
ruff check packages tests tools verification   # clean
mypy --strict packages/*/src                   # clean
python tools/mutation_regression.py            # 6/6 killed
python tools/gen_architecture.py               # docs regenerate identically
```

Real exports re-verified: **500 events, 0 parse issues, 100% line coverage, re-ingest added 0, 2 contents, 2 ingestions.**

## Completion gate

A new engineer reading only `READ_THIS_FIRST`, `docs/ARCHITECTURE.md`, the Project Memory and the tests gets **one consistent answer**. Every capability state matches actual code. The parser cannot report full coverage with an errored line. Provenance cannot be silently lost. "Persistence" means exactly what the code does — which is in-memory, and says so.

**Sprint 2 can start.** `at-identity`, `at-consent` and `at-evidence` can be built without hitting a contradiction.

## Still true, still not done

RTM-14 and RTM-15 unenforced. `at-store` not durable. Ingestion not streaming. No GDPR basis. No consent. Every L2+ module is a contract on paper.

**AT-056 has not started. Day 2.**

One live risk is logged against V010 itself: five green gates could become the new false confidence. V009 had four of them and still shipped a stale authoritative document and a real parser bug.
