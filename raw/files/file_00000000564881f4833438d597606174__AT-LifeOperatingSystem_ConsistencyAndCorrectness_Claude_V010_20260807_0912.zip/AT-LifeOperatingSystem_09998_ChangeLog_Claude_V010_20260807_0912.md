# AT-LOS V010 Change Log

## Verification

14 findings raised by independent review. All 14 verified against the actual files and code before acceptance. None taken on trust; none rejected.

## The blocker (finding 1)

`docs/ARCHITECTURE.md` was still the V008 document throughout V009 — the first file a new engineer is told to read. It stated `at-evidence` L2 (ADR-005 moved it to L3), `at-store` PLANNED (it was built), `person_id = sha256(canonical_name)` (ADR-006 replaced it), and "11 of 15 RTM" (there were 19). The V009 claim that Sprint 2 could start was therefore false.

## Structural fix — ADR-009

- **`architecture.toml`** is the single source of truth: module names, layers, allowed imports, kind, scope, state, responsibilities, boundaries.
- Guard tests **load** `LAYERS`, `ALLOWED`, `ADAPTERS` from it rather than duplicating them.
- `docs/ARCHITECTURE.md` sections B and C are **generated** by `tools/gen_architecture.py`.
- Four new guards: manifest consistency (RTM-20a), manifest state matches disk (RTM-20b), document matches manifest (RTM-20c), package versions agree (RTM-21).

## Code

- **Parser boundary fix.** A malformed timestamp now flushes the pending message, so an event locator cannot span an errored line and `line_coverage` cannot report 100% when a line failed. Two regression tests. The orphaned continuation now becomes its own recorded issue.
- **ADR-010 store scope.** `EventStore` → `InMemoryEventStore` with `durable = False`; manifest state `Partial`; docstring states it retains no raw bytes and is not restart-safe.
- **ADR-010 provenance split.** `SourceContent` (content-addressed) separated from `SourceIngestion` (workspace, owner, source label, time). Identical bytes in two workspaces = one content, two ingestions. RTM-22.
- **ADR-005 revised.** Only orchestration may import a concrete adapter; consumers derived from `kind` in the manifest.
- Package and platform versions aligned at **0.3.0**, guarded by RTM-21. Verification artifact reads versions from package metadata.
- `EventKind` uses `StrEnum`; `pending` fully typed for `mypy --strict`.

## Gates

`ruff` and `mypy --strict` now run as **blocking CI jobs** — ADR-003 named them from V006 and CI ran neither until now. Both clean. `tools/mutation_regression.py` is a reproducible artifact and a blocking job: **6 mutants, 6 killed**, each re-introducing a real historical defect. Nothing uses `|| true` or `continue-on-error`.

Suite: **67 passed, 1 skipped, 259 statements, 0 missed, 0.30s.**

## Claims corrected

- "Functional is at 100%" → line coverage of the production code that currently exists. Functional requirement coverage is not close to 100%.
- Memory NFR → only `sha256_file` streams; `read_source` reads the whole file and the parser splits all lines. Marked **Planned**.
- Mutation testing → reproducible regression harness, not a full mutation baseline.
- Hallucination Register → 43 capabilities recounted from the sheet; V008 said 27, V009 said 38. Implementation refs updated to 0.3.0.
- Sprint Tracker → layers and dependency columns corrected to the manifest; S1-10 downgraded Done → Partial.
- Project Memory Standard → issued at V010; V009 shipped the V008 standard unchanged.

## Decisions

D-039 manifest is the single source of truth · D-040 the store is named for what it is · D-041 SourceContent split from SourceIngestion · D-042 only orchestration imports adapters · D-043 mutation regression is a blocking artifact · D-044 ruff and mypy enforced · D-045 coverage claims state exactly what is covered

## Not done

No feature work. No identity, consent or evidence started. Durable persistence (S1-20) and streaming ingestion (S1-24) planned, not built. RTM-14 and RTM-15 still unenforced. **AT-056 still not started, day 2.**
