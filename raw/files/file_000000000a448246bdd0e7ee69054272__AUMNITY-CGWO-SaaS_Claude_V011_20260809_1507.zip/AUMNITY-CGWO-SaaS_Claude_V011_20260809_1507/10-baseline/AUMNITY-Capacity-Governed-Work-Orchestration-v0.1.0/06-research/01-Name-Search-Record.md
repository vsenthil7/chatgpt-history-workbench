# Name Search Record — 01 August 2026

Rejected as already used or too conflicted in current web results:
- WorkSync — established workforce management product.
- ResourceFlow — HR/resource planning products already active.
- PlanFlow — construction planning products already active.
- WorkAlign — existing scheduling/maintenance product.
- WorkWeave and TaskWeave — active software/AI names.
- TeeFlow / FlowTime — active unrelated products.

Decision: use descriptive architecture name **Capacity-Governed Work Orchestration (CGWO)** until a dedicated legal/trademark/domain exercise is completed.
