# MVP and Progression

## Phase 0 — IPBS workbook stabilisation
Task IDs, Resource IDs, Weekly Planner, controlled values, linked tracker/timesheet.

## Phase 1 — availability and capability
Resource master, basic skill evidence, monthly availability, weekly review and previous-day confirmation.

## Phase 2 — alignment and review
Work skill requirements, resource matching, capacity warnings, plan-change reasons and plan-versus-actual report.

## Phase 3 — UraiFlow assisted entry
One narrow employee workflow: speech -> proposed tracker/time/follow-up/availability records -> confirmation.

## Phase 4 — software extraction
Build only validated workflows as a reusable module.
