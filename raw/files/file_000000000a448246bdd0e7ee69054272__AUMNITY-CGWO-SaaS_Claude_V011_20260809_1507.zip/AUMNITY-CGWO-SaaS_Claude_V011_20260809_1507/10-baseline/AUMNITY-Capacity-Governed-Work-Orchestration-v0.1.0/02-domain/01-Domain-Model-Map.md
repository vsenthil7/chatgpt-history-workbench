# Domain Model Map

1. Opportunity and Service Formation Model
2. Capability Demand Model
3. Actor Capability Development Model
4. Availability and Capacity Model
5. Work–Resource Alignment Model
6. Adaptive Planning and Execution Model
7. Outcome, Evidence and Learning Model
8. Portfolio/Founder/TEE Capacity Model

These are separate models inside one initial reusable module. Split into independently released modules only after operational evidence supports the split.
