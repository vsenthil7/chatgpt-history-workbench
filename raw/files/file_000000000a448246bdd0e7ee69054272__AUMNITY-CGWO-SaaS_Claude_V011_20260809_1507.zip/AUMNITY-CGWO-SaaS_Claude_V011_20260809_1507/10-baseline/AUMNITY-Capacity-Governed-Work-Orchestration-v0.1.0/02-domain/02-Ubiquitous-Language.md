# Ubiquitous Language

- Idea: uncommitted thought.
- Opportunity: idea accepted for structured exploration.
- Service/Product Model: definition of value, process, tools, skills, compliance, cost and readiness.
- Capability Demand: what must be demonstrably possible.
- Availability Declaration: when a resource expects to contribute.
- Capacity Window: realistic effort available in a period.
- Plan Item: placement of a Work Object into a planning horizon.
- Execution Session: actual start/pause/resume/stop history.
- Supervision Load: founder/lead decision and review capacity consumed.
- TEE Capacity: available time, energy and execution/review capacity of the supervising human/AI ecosystem.
