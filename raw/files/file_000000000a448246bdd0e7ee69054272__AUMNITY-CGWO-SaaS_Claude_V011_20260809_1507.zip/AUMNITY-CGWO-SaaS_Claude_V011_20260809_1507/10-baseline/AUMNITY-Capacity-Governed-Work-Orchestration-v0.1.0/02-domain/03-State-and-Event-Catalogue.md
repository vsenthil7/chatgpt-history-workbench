# State and Event Catalogue

## Opportunity
CAPTURED, EXPLORING, MODELLED, READINESS_REVIEW, PILOT, APPROVED, HELD, REJECTED.

## Plan item
CANDIDATE, WEEK_PLANNED, DAY_PLANNED, STARTED, PAUSED, BLOCKED, INTERRUPTED, DEFERRED, COMPLETED, CANCELLED.

## Capacity allocation
PROPOSED, RESERVED, CONSUMING, PARTIALLY_CONSUMED, CONSUMED, RELEASED, OVERRUN.

## Key events
IdeaCaptured, OpportunityPromoted, ServiceModelPrepared, CapabilityGapDetected, TrainingNeedRaised, RecruitmentNeedRaised, AvailabilityDeclared, AvailabilityReconfirmed, CapacityReserved, WorkMatched, WeeklyPlanChanged, DailyPlanChanged, WorkInterrupted, TimeRecorded, CapabilityObserved.
