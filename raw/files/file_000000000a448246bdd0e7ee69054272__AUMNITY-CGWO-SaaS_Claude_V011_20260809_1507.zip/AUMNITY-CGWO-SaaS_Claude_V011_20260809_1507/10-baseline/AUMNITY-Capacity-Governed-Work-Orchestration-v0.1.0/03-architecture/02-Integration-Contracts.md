# Integration Contracts

Customer systems may provide initial Excel/CSV loads, daily batch files, APIs or events. Every data element must have a declared system of record.

Required adapter categories: HR/resource master, calendar/leave, project/work demand, LMS/certification, payroll/timesheet output, CRM/client context and UraiFlow record proposals.
