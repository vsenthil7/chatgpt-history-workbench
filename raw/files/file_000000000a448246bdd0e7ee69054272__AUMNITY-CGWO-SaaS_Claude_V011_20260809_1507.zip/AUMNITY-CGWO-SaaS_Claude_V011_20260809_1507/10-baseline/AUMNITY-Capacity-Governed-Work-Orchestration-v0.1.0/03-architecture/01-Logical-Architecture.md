# Logical Architecture

Idea/Opportunity -> Service Modelling -> Capability Demand -> Resource Pool/Development -> Availability & Capacity -> Matching -> Overall/Weekly/Daily Plan -> Execution/Tracker -> Timesheet/Evidence -> Review/Learning.

Cross-cutting gates: company current need, founder supervision load, body/mind/TEE capacity, finance, risk and integration availability.
