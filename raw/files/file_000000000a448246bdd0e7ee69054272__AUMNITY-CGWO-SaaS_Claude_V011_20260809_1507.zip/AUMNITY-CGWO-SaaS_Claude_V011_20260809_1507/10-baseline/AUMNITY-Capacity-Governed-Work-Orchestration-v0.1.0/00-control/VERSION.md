# Version

0.1.0 — first bounded architecture and IPBS validation plan.
