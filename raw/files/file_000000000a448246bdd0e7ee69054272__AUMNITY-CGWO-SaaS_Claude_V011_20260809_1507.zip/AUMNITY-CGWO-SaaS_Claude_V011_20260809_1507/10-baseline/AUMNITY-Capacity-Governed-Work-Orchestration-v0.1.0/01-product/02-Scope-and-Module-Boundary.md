# Scope and Module Boundary

## In scope
Idea/opportunity intake; service/product readiness; capability demand; availability/capacity horizons; work-resource matching; overall/weekly/daily planning; tracker; timesheet bridge; change reasons; review feedback.

## Reused from AUMNITY
Actor, Work Object, Capability, Evidence, Identity, Organisation, Policy, Workflow, Audit, Integration and Notification.

## Not owned
Payroll, salary, full HRMS, CRM, accounting, audio transcription and general recruitment applicant tracking. These integrate through platform contracts.
