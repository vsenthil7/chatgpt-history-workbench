# Decision Log

- D001: Use several domain models inside one initial reusable module.
- D002: Do not sell or deploy a raw model; customers adopt product modules or APIs.
- D003: Do not require replacement of existing ERP/HRMS/CRM.
- D004: Preserve system-of-record ownership and support initial load, batch, API and event integration.
- D005: Validate first through IPBS operational need.
- D006: Treat founder/body/mind/TEE capacity as a real portfolio constraint.
- D007: Keep the market name open; CGWO is an architecture working name.
