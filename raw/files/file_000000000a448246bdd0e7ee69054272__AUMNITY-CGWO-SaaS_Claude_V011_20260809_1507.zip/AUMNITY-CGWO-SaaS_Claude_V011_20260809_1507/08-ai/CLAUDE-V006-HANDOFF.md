# Claude V006 Handoff — for independent ChatGPT review

## Attempted
Every V005 review finding F27–F29; full gate ladder re-run; repackaging with clean-extract verification. No feature expansion, per review instruction.

## Completed (finding-by-finding)
F27 exact-instance guard on TenantContext in assert_same_tenant closes the lying-context cross-tenant bypass; reviewer's LyingContext is a named regression (SEC-001). F28 exact-str owner_tenant_id + exact-instance CapacityWindow at every consumption point (allocation, declaration); hostile-equality owner and LyingWindow rejected (SEC-001, DOM-010 extended). F29 explicit WIRE_DATE_GRAMMAR + calendar validation and WIRE_INT_MAX_DIGITS bound replace permissive fromisoformat/int() delegation; basic/week dates and 4301-digit strings rejected as controlled ContractViolationError (INT-006).

## Failed
Nothing attempted was abandoned. During hardening, four mutation survivors appeared on the new calendar-invalid-date and overlong-int branches (field/value diagnostic mutants); killed by strengthening the F29 regressions to assert exact structured fields, not by acceptance. The acceptance list remains empty.

## Deviations
None new. Prior-cycle notes remain on record in earlier handoffs.

## Deferred (unchanged, deliberate)
CapacityLedger/aggregate capacity governance (DOM-006); proposal confirmation workflow; event persistence fields; ExecutionSession entity; matching; provider-side contract tests; CI pipeline/container; mypy for tests; a machine-enforced construction-origin boundary; and a service-layer authorisation model (the residual concern for genuine-object-with-hostile-values, out of domain-core scope — see ADR-013 scope note / G08 RED half).

## Assumptions
Starter contract precedence unchanged; ADR-003 stays PROPOSED with the Python core a portable spec; exact-instance strictness is acceptable to future adapters because construction happens through canonical factories/wire decoders; cgwo-consumer-v1 dates are strict YYYY-MM-DD; 4300 digits is a safe upper bound below CPython's default limit and far above any legitimate minute quantity.

## Decisions
ADR-013 (canonical object boundaries and strict wire grammar) ACCEPTED; extends ADR-012. Domain core 0.5.0.

## Unresolved blockers
Platform/UraiFlow provider schemas (G05 full green); CI environment decision (G11 full green); service-layer authz model (G08 service-layer half).

## Review requests
Attack the exact-instance rule with objects whose type() is genuinely the domain class but whose slots were mutated post-construction (frozen dataclass should prevent this — verify); probe whether any domain object crossing a boundary still uses isinstance; try wire dates with leading/trailing NUL or unicode line separators, and integers with astral/surrogate digits; confirm the residual service-layer authz scope note is honestly reflected and nothing over-claims.
