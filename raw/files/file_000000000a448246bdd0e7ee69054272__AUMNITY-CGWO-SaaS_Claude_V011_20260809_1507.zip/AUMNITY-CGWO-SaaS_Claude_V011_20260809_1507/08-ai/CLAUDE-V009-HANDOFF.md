# Claude V009 Handoff — for independent ChatGPT review

## Attempted
Every V008 review finding F38–F41, root-cause-first; full gate ladder re-run; repackaging with clean-extract verification. No feature expansion and NO trust-model redesign, per review instruction. Offered as the candidate domain-baseline freeze.

## Completed (finding-by-finding)
F38 — `NOT_ENTITLED` message prose changed from "authenticated principal is not entitled to tenant {tenant_id}" to "supplied authorization capability denied access to tenant {tenant_id}". Stable code unchanged. New regression fails if any current message template implies authenticated identity and asserts the capability wording (RTM SEC-004).

F39 — `StaticAuthorizationContext` now validates the entitlements CONTAINER (exact set/frozenset) before iterating, raising controlled `AuthorizationError`/`WRONG_RUNTIME_TYPE`. None/int/raw-string/list/tuple/dict are rejected; a raw string is no longer silently split into character entitlements; hostile members still rejected. Regressions added for all these cases (RTM DOM-013). Constructor hygiene only, not tamper-resistance.

F40 — Canonical release-identity protection completed. Generic versioned-artifact rule now covers release notes, gate statuses AND handoffs (canonical-series file required; any family file numbered above canonical is an error). Package ROOT directory name is validated to embed the canonical series and equal the manifest release. Negative tests cover future-gate, future-handoff, future-note, and root/manifest mismatch (RTM DOC-003; tests/test_current_cycle.py).

F41 — DOC-004/G10 made honest. DOC-004 narrowed to "specific F35 structural regression"; G10 marked "STRUCTURAL rules only"; validator comment states semantic ADR consistency remains an independent-review duty. No claim that a text validator proves general architectural consistency.

## Failed
Nothing attempted was abandoned. Explicitly NOT done, by design: any trust-model redesign; any attempt to make authz objects tamper-resistant (F34 lesson); any general semantic ADR-consistency validator (F41 — deliberately declared a review duty rather than faked).

## Deviations
None new. The generic versioned-artifact rule replaces the V008 release-note-only future check; the F35 regression is unchanged in behaviour but honestly re-scoped.

## Deferred (unchanged, deliberate)
Service-layer authenticated-identity binding AND authoritative tenant-scoped aggregate provenance (together the G08 RED half); CapacityLedger/aggregate governance; proposal confirmation workflow; event persistence fields; ExecutionSession; matching; provider-side contract tests; CI/container; mypy for tests.

## Assumptions
Starter contract precedence unchanged; ADR-003 stays PROPOSED; `StaticAuthorizationContext` is a mutable reference/contract; canonical series is V009, core version 0.6.2. A real service layer will supply an authenticated `AuthorizationPort` AND authoritative aggregate loading before deployment.

## Decisions
No new ADR. F38/F39 are corrections within ADR-011/ADR-012/ADR-015's existing scope; F40/F41 are governance-rule corrections. ADR-014 (amended) and ADR-015 stand unchanged.

## Unresolved blockers
Platform/UraiFlow provider schemas (G05 full green); service-layer trust root — authenticated identity binding AND authoritative aggregate provenance (G08 RED half); CI environment decision (G11 full green). These are the intended next tranche, not domain-core defects.

## Review requests
Confirm the F38 message no longer implies authentication anywhere in current executable messages (probe the full MESSAGES registry). Attack the F39 constructor with None/int/raw-string/list/tuple/dict and confirm controlled errors, and that a raw string is rejected rather than split. Re-run your F40 spoof: add a future GATE-STATUS-V999 or CLAUDE-V999-HANDOFF, rename the package root to a noncanonical name, or desync manifest release from the root — all should now fail the validator. Confirm F41: DOC-004/G10 now claim only the specific structural regression, and inserting a fresh contradiction into an arbitrary ADR is (correctly) NOT caught by the validator and is left to your review. If F38–F41 are clean, please consider whether V009 can be frozen as the domain baseline so the next tranche can start the service-layer vertical slice.
