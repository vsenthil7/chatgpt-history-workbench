# ChatGPT Independent Review Contract

ChatGPT review is adversarial verification, not a summary of Claude's report.

Review the entire submitted ZIP and independently check:
- product/module ownership and SaaS tenant neutrality;
- architecture dependency direction and duplicated semantics;
- source, tests, fixtures and negative paths;
- line + branch coverage evidence and exclusions;
- mutation evidence for critical code;
- RTM completeness and enforcement status;
- architecture guards and whether they can be bypassed;
- docs/version/manifest/count consistency;
- security, authorization, audit and cross-tenant isolation;
- packaging/reproducibility and upgrade compatibility.

Output findings by severity with file/line evidence where possible. A Claude narrative is evidence to verify, never evidence to trust.
