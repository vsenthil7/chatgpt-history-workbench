# Claude V005 Handoff — for independent ChatGPT review

## Attempted
Every V004 review finding F20–F26; full gate ladder re-run; repackaging with clean-extract verification. No feature expansion attempted, per review instruction.

## Completed (finding-by-finding)
F20 canonical exact-type rule closes the cross-tenant subtype bypass at construction; reviewer's EqualEverything attack is a named regression (DOM-010, SaaS-002 evidence extended); F21 strip-liar rejection across all ID/ref fields via the same root rule; F22 EvilInt negative-capacity/allocation constructions rejected, incl. in consume(); F23 exact datetime.date required — datetime rejected with controlled DomainErrors before any comparison, across all date fields (DOM-011); F24 explicit ASCII wire-integer grammar `[0-9]+` with accept/reject matrix (INT-005); F25 origin semantics corrected to convention in RTM/ADR/docstrings — DOM-009 "ENFORCED (validation) / CONVENTION (origin)"; F26 version-neutral canonical docs, AI-001 updated, stale-version validator rule added (DOC-002).

## Failed
Nothing attempted was abandoned.

## Deviations
None new. Prior-cycle notes remain on record in earlier handoffs.

## Deferred (unchanged, deliberate)
CapacityLedger/aggregate capacity governance (DOM-006); proposal confirmation workflow; event persistence fields; ExecutionSession entity; matching; provider-side contract tests; CI pipeline/container; mypy for tests; a machine-enforced construction-origin boundary (possible future ADR if persistence work needs it, per ADR-012).

## Assumptions
Starter contract precedence unchanged; ADR-003 stays PROPOSED with the Python core as a portable spec; exact-type strictness is acceptable to future adapters because wire factories are the designated canonicalisation point; `date.fromisoformat` on exact ASCII ISO strings is the wire date grammar; no policy permits anomalous mutation categories (any occurrence fails G07).

## Decisions
ADR-012 (canonical primitive trust model) ACCEPTED; ADR-010 transparently amended, not rewritten. Domain core 0.4.0.

## Unresolved blockers
Platform/UraiFlow provider schemas (G05 full green); CI environment decision (G11 full green).

## Review requests
Attack the exact-type rule itself: C-extension types, weakref proxies, functools-wrapped values, objects lying via __getattribute__; probe wire parsers with surrogate/astral strings, NUL bytes, enormous digit strings (DoS length), and ISO-date edge forms (week dates, ordinal dates) that fromisoformat may accept; re-check whether any domain field escaped the canonical rule; re-check gate-language conservatism.
