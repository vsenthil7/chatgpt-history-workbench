# Claude V010 Handoff — for independent ChatGPT review

## Attempted
Every V009 review finding F42–F44, root-cause-first; full gate ladder re-run; repackaging with clean-extract verification. No feature expansion and NO trust-model redesign, per review instruction. Offered as the candidate domain-baseline freeze.

## Completed (finding-by-finding)
F42 — `require_aggregate(value, cls, field, exc)` added to validation.py: validates an aggregate operation argument BEFORE any attribute read. Applied in `transition_plan_item` (item), `transition_allocation`/`consume_allocation` (allocation) and `windows_overlap` (one, other). str/None/object now raise controlled `WRONG_RUNTIME_TYPE` DomainErrors instead of raw AttributeError. It uses `isinstance` and ADMITS subclasses on purpose, so a lying subclass still reaches authorization and is denied there (F32 semantics) — API/invariant hygiene, NOT authorization/provenance. Guard-site matrix rows + subclass-admitted regression added (RTM DOM-008/DOM-014).

F43 — Single canonical manifest policy `scripts/manifest_policy.py` shared by `gen_manifest.py` and `validate_consistency.py`. Manifest validation is now CLOSED over the shipped managed set: unmanifested file → FAIL; missing entry → FAIL; hash mismatch → FAIL; duplicate entry → FAIL; file_count != unique entries → FAIL. `tests/test_manifest_closure.py` reproduces the exact EXTRA.txt attack and the duplicate/file_count cases (RTM DOC-006).

F44 — Explicit dev/release modes for the package-root identity check. Release mode (default) enforces root-name identity UNCONDITIONALLY: an arbitrary `BADNAME` root fails, and the root must embed the canonical series and equal the manifest release. Development trees opt out explicitly via `--dev` or a `_WIP` suffix. Regressions cover the BADNAME case and the `--dev` opt-out (RTM DOC-007).

## Failed
Nothing attempted was abandoned. Explicitly NOT done, by design: any trust-model redesign; making require_aggregate an exact-type (non-subclass) guard, which would break F32 lying-subclass authz semantics and wrongly conflate API hygiene with security; any general semantic ADR-consistency validator (F41 — remains a review duty).

## Deviations
None new. require_aggregate deliberately differs from require_exact_instance (isinstance vs type-is) because its purpose is API hygiene, not the exact-canonical-type trust stance used for value fields.

## Deferred (unchanged, deliberate)
Service-layer authenticated-identity binding AND authoritative tenant-scoped aggregate provenance (together the G08 RED half); CapacityLedger/aggregate governance; proposal confirmation workflow; event persistence fields; ExecutionSession; matching; provider-side contract tests; CI/container; mypy for tests.

## Assumptions
Starter contract precedence unchanged; ADR-003 stays PROPOSED; canonical series V010, core version 0.6.3. A real service layer will supply an authenticated AuthorizationPort AND authoritative aggregate loading before deployment.

## Decisions
No new ADR. F42 is a correction within ADR-010's existing "operation argument" claim; F43/F44 are governance-rule corrections. ADR-014 (amended) and ADR-015 stand unchanged.

## Unresolved blockers
Platform/UraiFlow provider schemas (G05 full green); service-layer trust root — authenticated identity binding AND authoritative aggregate provenance (G08 RED half); CI environment decision (G11 full green). These are the intended next tranche, not domain-core defects.

## Review requests
Re-run your F42 probes: `transition_plan_item("bad", …)`, `transition_allocation("bad", …)`, `consume_allocation("bad", …)`, `windows_overlap("bad", w)` / `windows_overlap(w, "bad")`, plus None/object — all should raise controlled WRONG_RUNTIME_TYPE, while a lying PlanItem SUBCLASS should still be admitted and denied by authorization (confirm the two concerns stay separate). Re-run your F43 attack: add an arbitrary file after manifest generation and confirm validation now FAILS; also try a duplicate manifest entry and a wrong file_count. Re-run your F44 attack: rename the package root to BADNAME and confirm release-mode validation FAILS, and that `--dev` is the explicit opt-out. If F42–F44 are clean and you find no further material domain-baseline defect, please consider freezing V010 as the domain baseline so the next tranche can begin the service-layer vertical slice.
