# Claude V007 Handoff — for independent ChatGPT review

## Attempted
Every V006 review finding F30–F33, root-cause-first; full gate ladder re-run; repackaging with clean-extract verification. No feature expansion, per review instruction.

## Completed (finding-by-finding)
F30 architectural redesign (ADR-014): authorization trust boundary; object identity is no longer a trust anchor; the reviewer's `object.__setattr__` mutation on a genuine TenantContext/CapacityWindow is a named regression and is denied at the authz layer. F31 single semantic `WIRE_INT_MAX_VALUE` bound applied to both exact-int and string paths; oversized exact ints rejected without stringifying; downstream repr() ValueError eliminated. F32 lying PlanItem/allocation subclasses resolved by the same authz decision (not more type checks); named regressions. F33 RTM AI-001 corrected + machine rule in validate_consistency.py + tests/test_current_cycle.py tying current-cycle handoff to the release series.

## Failed
Nothing attempted was abandoned. The V006 "integrity tag" defence-in-depth idea was deliberately NOT shipped — it was dead code that implied a guarantee it could not give; the honest boundary is authz.

## Deviations
None new. Prior-cycle notes remain on record in earlier handoffs. ADR-013's security premise is explicitly superseded (transparent amendment note appended, not a silent rewrite).

## Deferred (unchanged, deliberate)
Service-layer authenticated identity binding `AuthorizationPort` to real claims (G08 RED half — the domain core enforces the decision, not authentication); CapacityLedger/aggregate governance; proposal confirmation workflow; event persistence fields; ExecutionSession; matching; provider-side contract tests; CI/container; mypy for tests.

## Assumptions
Starter contract precedence unchanged; ADR-003 stays PROPOSED; `StaticAuthorizationContext` is a reference/contract, not production identity; `WIRE_INT_MAX_VALUE = 10**12` is a safe semantic bound (≈1.9M years in minutes) far below CPython's int/str conversion limit; a real service layer will supply an `AuthorizationPort` bound to authenticated identity before deployment.

## Decisions
ADR-014 (authorization trust boundary) ACCEPTED; supersedes ADR-013's security premise while retaining its exact-type guards as invariant hardening. Domain core 0.6.0 (protected operations now take an AuthorizationContext).

## Unresolved blockers
Platform/UraiFlow provider schemas (G05 full green); service-layer authenticated-identity model (G08 service-layer half); CI environment decision (G11 full green).

## Review requests
Try to obtain authority without a matching entitlement: a hostile `AuthorizationPort` implementation (duck-typed) is by design trusted to report its own entitlements — is that the right contract, or should the port itself be constrained? Probe whether any protected operation still derives an authorization-relevant fact from a caller-supplied object rather than from authz. Attack `parse_wire_int` with int subclasses that override comparison to evade the magnitude bound (should be caught by exact-int typing — verify). Check whether the current-cycle rule can be spoofed by adding a stray future RELEASE-NOTES file. Confirm G08's split GREEN/RED language is honest and nothing claims authenticated identity exists.
