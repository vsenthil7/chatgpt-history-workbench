# Claude V008 Handoff — for independent ChatGPT review

## Attempted
Every V007 review finding F34–F37, root-cause-first; full gate ladder re-run; repackaging with clean-extract verification. No feature expansion, per review instruction.

## Completed (finding-by-finding)
F34 (P0) — Trust root redefined, not re-hardened (ADR-015). The domain core's claim is renamed to **authorization-POLICY enforcement**: it consults a supplied `AuthorizationPort` capability and honours deny/allow, but does NOT establish that the capability is genuine or authenticated. No Python tamper-resistance was added to `StaticAuthorizationContext` (F30 already proved that wrong); it is documented as an ordinary mutable reference. `AuthorizationPort` remains a structural DI contract by design. The reviewer's two exact attacks — ordinary `_entitlements` reassignment and a malicious structural port — are now permanent regressions in `tests/test_trust_boundary.py` that assert the attacks SUCCEED (because they are inside the trust boundary) and document why. The service/application boundary is the trust root, RED in G08.

F35 (P1) — ADR-014 corrected to match the shipped release. Amendment A1 (ACCEPTED) withdraws Decision 4 (the "private consistency tag" that was never shipped) and supersedes Decision 5's gate wording. A new machine rule in `validate_consistency.py` fails the build if an ACCEPTED ADR retains a withdrawn mechanism (e.g. the consistency tag) without an amendment resolving it, and if the tag ever reappears in code (RTM DOC-004).

F36 (P1/P2) — Single canonical release identity. `00-control/RELEASE-IDENTITY.json` is now THE source of truth for the release series; `validate_consistency.py` and `tests/test_current_cycle.py` validate every derived representation (manifest release, release notes, gate status, current handoff, RTM AI-001, pyproject version) AGAINST it. Release identity is no longer inferred from `max(RELEASE-NOTES-V*.md)`; a stray/future release-notes file numbered above the canonical series is now a validation ERROR (RTM DOC-003).

F37 (P1) — Aggregate provenance named as an explicit service-layer trust prerequisite (ADR-015 Decision 5; RTM SEC-003). `assert_tenant_operation`'s contract states that `owner_tenant_id` is read from the caller-supplied aggregate and that provenance (loading/rehydration from an authoritative tenant-scoped store) is the service layer's responsibility. `tests/test_trust_boundary.py` documents that a caller genuinely entitled to tenant B can operate on a B-relabelled aggregate (provenance gap, service-layer scope) while cross-tenant policy enforcement still denies acting on another tenant's aggregate.

## Failed
Nothing attempted was abandoned. Explicitly NOT done, by design: any attempt to make `StaticAuthorizationContext` or `AuthorizationPort` tamper-resistant in-process (F30/F34 lesson); any claim that the domain core establishes authenticated identity or aggregate provenance.

## Deviations
None new. The retired-overclaim phrase rule (F34) and the ADR-contradiction rule (F35) are new consistency rules; historical release notes, handoffs, ADR bodies and the baseline are exempt as historical records, while the current series' gate/handoff and all current code are held to them.

## Deferred (unchanged, deliberate)
Service-layer authenticated-identity binding of `AuthorizationPort` to real claims AND authoritative tenant-scoped aggregate loading/rehydration — together these are the G08 RED half (the "service-layer trust root"); CapacityLedger/aggregate governance; proposal confirmation workflow; event persistence fields; ExecutionSession; matching; provider-side contract tests; CI/container; mypy for tests.

## Assumptions
Starter contract precedence unchanged; ADR-003 stays PROPOSED; `StaticAuthorizationContext` is a mutable reference/contract, not production identity; `WIRE_INT_MAX_VALUE = 10**12` unchanged; a real service layer will supply an authenticated `AuthorizationPort` AND authoritative aggregate loading before deployment. Domain core 0.6.1 (documentation/contract clarification; no behavioural change to protected operations).

## Decisions
ADR-015 (service boundary is the trust root; domain core enforces authorization POLICY, not AUTHORITY) ACCEPTED. ADR-014 Amendment A1 ACCEPTED (aligns the ADR with the shipped release; withdraws the consistency-tag decision; supersedes the gate wording).

## Unresolved blockers
Platform/UraiFlow provider schemas (G05 full green); service-layer trust root — authenticated identity binding AND authoritative aggregate provenance (G08 RED half); CI environment decision (G11 full green).

## Review requests
Confirm the F34 attacks (`_entitlements` reassignment; malicious structural port) are now framed as in-boundary and documented rather than "defended", and that no new Python-integrity claim crept in. Check that G08's GREEN half claims ONLY authorization-policy enforcement and nowhere claims authenticated identity or provenance. Probe the F36 canonical-identity rule: try to spoof the release by adding a stray `RELEASE-NOTES-V999.md` or by desynchronising manifest/pyproject/RTM from `RELEASE-IDENTITY.json` — all should fail the validator. Probe the F35 rule: reintroduce a withdrawn "consistency tag" claim into ADR-014 without an amendment, or into code, and confirm it fails. Attack the F37 provenance boundary: is there any protected operation whose authorization-relevant tenant is NOT sourced from the aggregate the service layer is responsible for loading? Confirm the retired-phrase rule has no false negatives in current code/docs.
