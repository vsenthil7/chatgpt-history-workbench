# Claude V004 Handoff — for independent ChatGPT review

## Attempted
Every V003 review finding F13–F19; full gate ladder re-run including the rebuilt strict mutation gate; repackaging with clean-extract verification. No feature expansion attempted, per review instruction.

## Completed (finding-by-finding)
F13 runtime enum/type validation on every field and operation argument, controlled DomainErrors, reviewer payloads as named regressions; F14 allocation truly unbypassable — "every construction path" now includes the type level (ADR-010, DOM-005/DOM-008); F15 strict constructors + explicit from_wire/parse_wire_* decoders with adversarial contract tests (INT-004); F16 create()/rehydrate() factories with declared initial states (DOM-009); F17 strict, unit-tested mutation gate — false-green paths are now test fixtures (QA-005, ADR-011); F18 non-deprecated mutmut config, warnings gone from raw output; F19 structured error identity (type + code + fields), prose as registry data, acceptance list empty (QA-006).

## Failed
Nothing attempted was abandoned. Notable course-correction: the first F19 refactor initially re-exposed ~170 string-literal/diagnostic-argument mutants; resolved properly by making structured fields part of tested identity (guard-site matrix) and hoisting identifier spellings to module-level data — not by bulk acceptance. One genuinely equivalent mutant was removed by simplifying code; zero acceptance entries exist.

## Deviations
None new. Prior-cycle notes remain on record in the V002/V003 handoffs.

## Deferred (unchanged, deliberate)
CapacityLedger/aggregate capacity governance (DOM-006); proposal confirmation workflow; event persistence fields (occurred-at, actor, correlation); ExecutionSession entity; matching; provider-side contract tests; CI pipeline/container; mypy for tests (strict on src only).

## Assumptions
Starter contract precedence unchanged; ADR-003 stays PROPOSED with the Python core as a portable spec; `datetime.datetime` acceptable where `date` is required (subclass); rehydration intentionally shares the fully-validated construction path rather than bypassing invariants; no policy currently permits timeout/suspicious/skipped/no-tests mutants (any occurrence fails G07 by design).

## Decisions
ADR-010 (runtime type integrity, wire decoding, construction semantics) and ADR-011 (verification integrity) — both ACCEPTED, reversible pre-1.0. Domain core 0.3.0.

## Unresolved blockers
Platform/UraiFlow provider schemas (G05 full green); CI environment decision (G11 full green).

## Review requests
Attack the runtime guards with types not in the adversarial matrix (subclasses of str/int, enum subclasses, objects with spoofed __class__); probe from_wire for decodings that should be rejected (locale digits, whitespace, signs); try to construct a false-green mutation summary that the gate tests miss; check whether the guard-site matrix genuinely covers every raise site; re-check gate-language conservatism.
