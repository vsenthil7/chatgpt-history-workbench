# Release Notes — AUMNITY-CGWO-SaaS_Claude_V002_20260808_2208

Input baseline: `AUMNITY-CGWO-SaaS_ChatGPT_V001_20260808_1318.zip` (manifest preserved at `evidence/provenance/V001-PACKAGE-MANIFEST.json`; hashes verified before work began).

## Changed from V001 → V002
1. **Contradictions resolved by ADR, not silent rewriting** — `11-decisions/ADR-001..006`: execution-session vs tracker ownership; supervisory-capacity generalisation; canonical scope wording; recruitment/training boundary; Platform primitive consumption; technology stack (PROPOSED with recommendation, alternatives and reversibility plan — the build proceeds without waiting on it).
2. **Canonical scope** — `01-product/CANONICAL-SCOPE.md` defines CGWO-SCOPE-1 / CGWO-NOTOWNED-1; PROJECT-START, PRODUCT-BOUNDARY and MODULARITY now reference the IDs instead of restating variants. Enforced by validator.
3. **New architecture contracts** — `PLATFORM-PRIMITIVES-CONTRACT.md` (opaque-reference consumption of Platform primitives) and `INTEGRATION-BOUNDARIES.md` (tracker/timesheet bridges, recruitment/training events, UraiFlow record proposals).
4. **First executable domain core** (`src/cgwo_core/`, pure stdlib per ADR-003): explicit tenant context and cross-tenant denial; capacity types including supervisory capacity; capacity windows and availability declarations with invariants and overlap detection; full Plan Item state machine with change-reason enforcement and event mapping; full Capacity Allocation state machine with consumption and overrun detection.
5. **Test suite** (`tests/`) covering the complete declared transition matrices, negative paths, tenant isolation and architecture purity; line and branch coverage at policy target (see `evidence/test-summary.json` — figures are machine-generated, not quoted here by design).
6. **Automated contradiction detection** — `scripts/validate_consistency.py` (required files, ADR status headers, canonical-scope references, superseded/pilot vocabulary placement, manifest hashes, evidence cross-checks) alongside the preserved `validate_starter.py`.
7. **Governance artefacts regenerated** — RTM rewritten with enforced/declared statuses and evidence pointers; `GATE-STATUS-V002.md` records the G01–G12 ladder honestly (two RED gates, see below); manifest regenerated with SHA-256 for every file.

## Deliberately unresolved
- **ADR-003 stack is PROPOSED** — awaiting confirmation; domain core is a portable spec if the decision goes another way.
- **G05 contract tests RED** — Platform/UraiFlow schemas not yet published; contracts are declared only.
- **G07 mutation RED** — harness limitation (dataclass methods not mutated) recorded as explicit next-release work; survivors classified in `evidence/mutation-summary.json`.
- Persistence, API, messaging, matching algorithms, conflict detection across windows, execution-session entity, tenant-configurable capacity types: declared, not implemented.

Preserved unchanged: `10-baseline/` (verbatim), engineering OS, testing strategy, quality-gate ladder, versioning rules, CLAUDE.md, ChatGPT review contract.
