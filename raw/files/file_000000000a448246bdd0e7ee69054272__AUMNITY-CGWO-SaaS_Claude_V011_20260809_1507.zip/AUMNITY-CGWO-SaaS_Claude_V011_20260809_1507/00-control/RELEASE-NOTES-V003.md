# Release Notes — Claude V003 (correction release)

Input: `AUMNITY-CGWO-SaaS_Claude_V002_20260808_2208.zip` plus the independent ChatGPT review of that ZIP (findings F01–F12; V002 rejected as clean baseline, correctable). V001 provenance retained at `evidence/provenance/V001-PACKAGE-MANIFEST.json`; `10-baseline/` preserved byte-for-byte.

## Review findings → what changed
- **F01 (P0)** — State-dependent allocation invariants now hold on every construction path; impossible objects (RESERVED with consumption, CONSUMED at zero, OVERRUN under limit, PROPOSED with consumption) are unconstructible. Lifecycle transition table reduced to data-consistent moves; CONSUMED/OVERRUN reachable only via consumption. ADR-007; invariant matrix + named regression tests.
- **F02 (P0)** — A single allocation can no longer exceed its window's available minutes. Aggregate/cross-allocation governance is explicitly DECLARED-not-implemented (RTM DOM-006) with an honesty-guard test that fails if a ledger API appears without real contract tests; scope doc now separates ownership ambition from implementation status.
- **F03 (P0)** — Change reasons are normalised and preserved on `PlanItemChange`; tests assert the exact supplied reason survives. ADR-008.
- **F04 (P0)** — Transitions return typed, immutable domain-change records (`PlanItemChange`, `AllocationChange`) carrying tenant, references, previous/new state, reason and quantities. Pure domain data; no messaging infrastructure. Timestamps/actor/correlation are DECLARED pending clock/identity contracts. ADR-008.
- **F05 (P0)** — ADR-009: `tenant_id` is THE enforced isolation boundary; `organisation_id` is validated sub-scope metadata, not an enforced boundary. RTM SaaS-002 corrected; SaaS-004 added; blank organisation_id rejected and tested.
- **F06** — Protected operations vs pure value calculations defined in ADR-009 and MODULARITY doc; `windows_overlap` documented as a pure value comparison.
- **F07** — mypy strict configured and passing on src; ruff check + format enforced; G02 GREEN on evidence, not assertion.
- **F08** — `pyproject.toml`, pinned `requirements-dev.txt`, one-command `scripts/run_gates.sh`. G11 stays PARTIAL: no CI/container yet, stated plainly.
- **F09** — Mutation is reproducible: domain logic delegated to module-level functions so the harness actually mutates it; `scripts/run_mutation.py` captures tool version, exact command, raw output, results listing and a machine-generated summary; survivors must be killed or listed with justification in `scripts/mutation_acceptance.json`. Outcome this release: **zero unresolved, zero accepted** — the five genuine survivors exposed real test gaps (boundary values, unasserted change-record fields) which were fixed with real tests, and string-literal noise was eliminated by anchored error-message assertions (messages are now part of the tested contract).
- **F10** — New AST guard forbids re-declaring Platform-owned primitive names in the domain core; ARC-001/002 language now distinguishes guard enforcement from semantic review.
- **F11** — Count terminology corrected via appended correction note on the V002 handoff (no silent history rewrite); counts are generated, with ZIP entries / regular files / manifest-managed files distinguished.
- **F12** — CGWO consumer-side boundary contracts (`cgwo-consumer-v1`: `TimeRecordProposal`, `AvailabilityProposal`) implemented and tested; G05 upgraded RED→PARTIAL; provider compatibility still pending external schemas.

## Also in this release
Anchored error-message tests (operator-facing messages are contract); domain core version 0.2.0 (pre-1.0 breaking change to the allocation transition table recorded in ADR-007); RTM rewritten with per-finding rows; conservative gate ladder in GATE-STATUS-V003.md.

## Deliberately unresolved
ADR-003 remains PROPOSED (no stack confirmation requested or required). Aggregate capacity ledger, confirmation workflow for inbound proposals, event persistence (timestamps/actor/correlation), ExecutionSession entity, matching, CI pipeline, provider-side contract tests: all DECLARED, none implemented, none claimed.
