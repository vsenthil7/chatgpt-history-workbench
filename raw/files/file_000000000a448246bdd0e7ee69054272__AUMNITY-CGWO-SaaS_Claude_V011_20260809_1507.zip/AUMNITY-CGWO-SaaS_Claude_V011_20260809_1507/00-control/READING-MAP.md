# Reading Map

1. `00-control/PROJECT-START.md`
2. `01-product/PRODUCT-BOUNDARY-AND-SAAS.md`
3. `02-architecture/MODULARITY-AND-REUSE.md`
4. `03-engineering/ENGINEERING-OPERATING-SYSTEM.md`
5. `04-testing/TESTING-STRATEGY.md`
6. `05-quality/QUALITY-GATES.md`
7. `06-traceability/RTM.md`
8. `07-planning/FIRST-BUILD-BACKLOG.md`
9. `11-decisions/` (ADR-001..014)
10. `05-quality/GATE-STATUS-V007.md` and `00-control/RELEASE-NOTES-V007.md` (earlier equivalents preserved as history)
11. `CLAUDE.md` when implementing
12. `08-ai/CHATGPT-REVIEW-HANDOFF.md` and `08-ai/CLAUDE-V007-HANDOFF.md` before packaging
13. `10-baseline/` for prior detailed product material
