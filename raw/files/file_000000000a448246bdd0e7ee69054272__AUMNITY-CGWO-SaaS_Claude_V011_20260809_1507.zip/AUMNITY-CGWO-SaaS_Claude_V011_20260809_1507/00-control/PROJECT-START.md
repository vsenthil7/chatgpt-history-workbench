# Project Start

**Project name:** AUMNITY CGWO SaaS  
**First page name:** 00001-CGWO-SaaS-Build-Baseline  
**Starter artifact:** AUMNITY-CGWO-SaaS_ChatGPT_V001_20260808_1318.zip  
**Created:** 08/08/2026 13:18 Europe/London

## SaaS ownership rule
This is a reusable SaaS product. IPBS may be a tenant/user and may sell/support it, but IPBS owns no generic product code.

## Product/pilot boundary
See canonical scope **CGWO-SCOPE-1** in `01-product/CANONICAL-SCOPE.md` (ADR-004).

## Explicitly not owned
See canonical exclusion **CGWO-NOTOWNED-1** in `01-product/CANONICAL-SCOPE.md` (ADR-004).

## First build objective
Turn the bounded architecture into a testable domain core with explicit contracts to AUMNITY Platform and UraiFlow, beginning with capacity/availability and planning state transitions.

## Working pattern
Claude Code = implementation. ChatGPT = independent complete-ZIP review. Repeat version-by-version using evidence, not narrative confidence.

## Baseline preservation
The supplied pre-rebuild artifact is preserved under `10-baseline/`. It is historical/input evidence, not automatically authoritative when it conflicts with this starter contract or a later approved ADR.
