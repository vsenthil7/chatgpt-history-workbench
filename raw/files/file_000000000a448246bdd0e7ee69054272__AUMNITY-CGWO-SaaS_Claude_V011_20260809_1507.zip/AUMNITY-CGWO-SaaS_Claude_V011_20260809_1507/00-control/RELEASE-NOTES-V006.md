# Release Notes — Claude V006 (trust-boundary correction release)

Input: `AUMNITY-CGWO-SaaS_Claude_V005_20260809_0646.zip` plus the independent ChatGPT review of that ZIP (findings F27–F29; V005 rejected as frozen baseline because the canonical-primitive fix left the object layer one level up still bypassable — including a demonstrated cross-tenant bypass via a lying `TenantContext` subclass). `10-baseline/` preserved byte-for-byte; no feature expansion.

## Review findings → what changed
- **F27 (P0, security)** — The lying-`TenantContext` cross-tenant bypass is closed (ADR-013). `assert_same_tenant` now exact-instance-checks `ctx` via `require_exact_instance` (`type(ctx) is TenantContext`), so a subclass overriding `__getattribute__` to misreport `tenant_id` cannot be passed at all; the isolation comparison only ever runs on a genuine, non-overriding context. The reviewer's `LyingContext` attack is a named regression.
- **F28 (P0, security)** — Both remaining object-layer holes closed: `assert_same_tenant` now requires an exact `str` `owner_tenant_id` (the hostile-equality `EqualEverything` owner is rejected), and `CapacityWindow` operands are exact-instance-checked wherever consumed (allocation and availability declaration), so the `LyingWindow` that misreported tenant and capacity can no longer enter the domain. Both attacks are named regressions.
- **F29 (P1)** — Wire grammars are now enforced explicitly instead of delegating to permissive builtins. Dates must match `WIRE_DATE_GRAMMAR` (`YYYY-MM-DD`) then pass calendar validation — `date.fromisoformat`'s basic form `20260801` and week form `2026-W31-6` are rejected deterministically. Integers must match `[0-9]+` AND stay within `WIRE_INT_MAX_DIGITS` (4300), so the 4301-digit string that raised a raw `ValueError` from CPython's conversion limit now raises a controlled `ContractViolationError`. Every case is a named regression asserting exact structured error identity.

## Scope honesty
Exact-type/instance guards defeat Python-level subtype attacks against the domain core. They do not defend against a caller that constructs a *genuine* canonical object carrying attacker-chosen field values — that is an authorisation concern for the still-absent service layer, tracked explicitly as G08's RED service-layer half (SEC-001 / ADR-013). The domain core makes no claim beyond what it can enforce.

## Verification outcome
All executable gates green on the final tree: full suite including the new adversarial object regressions, 100% line+branch coverage, strict mutation gate with zero anomalies/survivors and an empty acceptance list, ruff check+format, mypy strict, both validators, clean-extract re-verification.

## Deliberately unresolved
ADR-003 remains PROPOSED. G05 provider compatibility and G11 CI/container halves remain RED within their PARTIAL gates. CapacityLedger/aggregate governance, proposal confirmation workflow, event persistence fields, ExecutionSession, matching: DECLARED, unimplemented, unclaimed.
