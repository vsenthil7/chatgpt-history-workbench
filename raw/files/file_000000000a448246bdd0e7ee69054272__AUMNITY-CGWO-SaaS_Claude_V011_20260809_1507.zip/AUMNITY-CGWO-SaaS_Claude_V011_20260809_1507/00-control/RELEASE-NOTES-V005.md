# Release Notes — Claude V005 (trust-boundary correction release)

Input: `AUMNITY-CGWO-SaaS_Claude_V004_20260808_2330.zip` plus the independent ChatGPT review of that ZIP (findings F20–F26; V004 rejected as clean baseline over adversarial Python subtype behaviour, including a demonstrated cross-tenant bypass). `10-baseline/` preserved byte-for-byte; no feature expansion: persistence, APIs, matching, CapacityLedger and ExecutionSession remain deliberately untouched.

## Review findings → what changed
- **F20 (P0, security)** — The demonstrated cross-tenant bypass is closed at the root (ADR-012): security identifiers are canonical exact `str` only (`type(value) is str`), so a hostile subclass overriding `__eq__` can never enter a `TenantContext` — the comparison it attacked is unreachable. Named regressions use the reviewer's `EqualEverything` attack verbatim.
- **F21 (P0)** — `strip()`-liars are equally unconstructible; adversarial tests cover every important ID/ref field, fixed via the same root rule, not `.strip()` special-casing.
- **F22 (P0)** — Quantities are canonical exact `int` (bool excluded by construction); the reviewer's `EvilInt` negative-capacity and negative-allocation constructions are named failing-construction regressions. DOM-005/DOM-008 claims are now backed by the subtype suite.
- **F23 (P0)** — Dates are exact `datetime.date`; `datetime.datetime` is rejected with a controlled structured DomainError before any comparison can run — the uncontrolled `TypeError` path is unreachable, and time-of-day semantics cannot smuggle into date-only planning fields. Tested for period_start, period_end, mixed, double-datetime and declared_on. ADR-010 carries a transparent amendment note; ADR-012 records the superseding rule.
- **F24 (P1)** — The wire-integer grammar is explicit and versioned into `cgwo-consumer-v1`: exact `int` or ASCII digits `[0-9]+` only. Full-width digits, Arabic-Indic digits, signs, whitespace, separators, decimals and hex are rejected deterministically, each covered by tests. Documented in the contracts module and INTEGRATION-BOUNDARIES.
- **F25 (P1)** — Construction-origin language corrected everywhere: validated construction is ENFORCED on all paths; lifecycle ORIGIN (new vs rehydrated) is an API convention under review governance. RTM DOM-009 status now reads "ENFORCED (validation) / CONVENTION (origin)"; docstrings and ADR wording aligned.
- **F26 (P1)** — Version drift removed: CANONICAL-SCOPE now references RTM DOM-006 instead of "as of V003"; AI-001 points at the current cycle; and the consistency validator gained a stale-version rule failing the build if current canonical docs embed "as of V00N" references.

## Also noted from the review
The unrecognised `🧙` mutmut category is documented in the gate module: any non-zero unrecognised category breaks tally reconciliation and fails the gate, as the reviewer inferred.

## Verification outcome
All executable gates green on the final tree: full suite with the new adversarial subtype regressions, 100% line+branch coverage, strict mutation gate with zero anomalies/survivors and an empty acceptance list, ruff check+format, mypy strict, both validators, clean-extract re-verification.

## Deliberately unresolved
ADR-003 remains PROPOSED. G05 provider compatibility and G11 CI/container halves remain RED within their PARTIAL gates. CapacityLedger/aggregate governance, proposal confirmation workflow, event persistence fields, ExecutionSession, matching: DECLARED, unimplemented, unclaimed.
