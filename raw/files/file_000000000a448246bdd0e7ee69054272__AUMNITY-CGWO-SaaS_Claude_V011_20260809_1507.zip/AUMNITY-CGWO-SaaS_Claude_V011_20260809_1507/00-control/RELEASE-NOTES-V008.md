# Release Notes — Claude V008 (trust-boundary-definition release)

Input: `AUMNITY-CGWO-SaaS_Claude_V007_20260809_1254.zip` plus the independent ChatGPT review of that ZIP (findings F34–F37). V007 was rejected as a frozen enterprise baseline because it moved the V006/F30 mistake one abstraction upward: the domain core spoke as if it owned an "authorization security decision" when in reality it trusts a completely caller-supplied authorization capability. `10-baseline/` preserved byte-for-byte; no feature expansion.

## The architectural correction (ADR-015)
The reviewer was right that CGWO must stop trying to turn Python objects into security identities and instead name where SaaS trust begins. **No in-process Python object can prove authority — not a frozen domain value (F30), and not the authorization context either (F34).** V008 therefore redefines the claim rather than hardening another object.

The trust model is now explicit:
- **Service/application layer (trusted, does not exist yet):** authenticates the principal, establishes entitlements, constructs a genuine `AuthorizationPort`, and loads/rehydrates aggregates only from an authoritative tenant-scoped persistence boundary.
- **Domain core (this package):** enforces business invariants and honours the allow/deny semantics of the SUPPLIED authorization capability.

The domain core's security claim is renamed to **authorization-policy enforcement** and can only ever claim that. It does not, and cannot, establish that the supplied capability is genuine/authenticated (F34) or that aggregates have authoritative provenance (F37).

## Review findings → what changed
- **F34 (P0, security)** — The trust root is redefined, not re-hardened. No Python tamper-resistance was added to `StaticAuthorizationContext` (the F30 lesson forbids it); it is documented as an ordinary mutable reference, and `AuthorizationPort` is documented as a dependency-injection contract, not a security boundary. The reviewer's two exact attacks — ordinary `_entitlements` reassignment, and a malicious structural port whose `is_entitled()` returns true — are now permanent regressions in `tests/test_trust_boundary.py` that assert the attacks SUCCEED because they occur inside the trust boundary, with the rationale stated in the tests. SEC-001/SEC-002/SaaS-002 and G08 rewritten to claim only policy enforcement. A machine rule retires the overclaim phrases from current docs and code (RTM DOC-005).
- **F35 (P1)** — ADR-014 is corrected to match the release it shipped in. Amendment A1 (ACCEPTED) withdraws Decision 4 (the "private consistency tag" that was never shipped, as the V007 handoff itself stated) and supersedes Decision 5's gate wording. A new consistency rule fails the build if an ACCEPTED ADR retains a withdrawn mechanism without a resolving amendment, or if the tag reappears in code (RTM DOC-004). This closes the G10 blind spot where an accepted ADR could contradict its own release's implementation and handoff.
- **F36 (P1/P2)** — Release identity now has ONE canonical machine-readable source, `00-control/RELEASE-IDENTITY.json`. The validator and `tests/test_current_cycle.py` validate every derived representation (manifest release, release notes, gate status, current handoff, RTM AI-001, pyproject version) AGAINST it. Identity is no longer inferred from `max(RELEASE-NOTES-V*.md)`; a stray/future release-notes file numbered above the canonical series is now a validation error rather than a new authority (RTM DOC-003).
- **F37 (P1)** — Aggregate provenance is named as an explicit service-layer trust prerequisite (RTM SEC-003). `assert_tenant_operation`'s contract states that the authorized tenant is read from the caller-supplied aggregate and that loading/rehydration from an authoritative tenant-scoped store is the service layer's responsibility. A regression documents that a caller genuinely entitled to tenant B can operate on a B-relabelled aggregate (the provenance gap, service-layer scope), while cross-tenant policy enforcement still denies acting on another tenant's aggregate.

## Preserved from earlier cycles
The valid F31 (wire-integer magnitude bound) and F33 (current-cycle correspondence) improvements are retained; the hostile int-subclass probe remains permanently tested (F22/F31 regressions). All earlier adversarial suites, exact-type guards and error-identity tests are unchanged.

## Scope honesty (now precise)
G08 GREEN claims exactly one thing: the domain core consults the supplied capability and honours deny/allow. The RED half is the full service-layer trust root — authenticated identity binding AND authoritative aggregate provenance. This release makes a smaller, true claim and names the missing halves rather than implying they are covered.

## Verification outcome
All executable gates green on the final tree: full suite including the new `tests/test_trust_boundary.py` regressions, 100% line+branch coverage, strict mutation gate with zero anomalies/survivors and an empty acceptance list, ruff check+format, mypy strict, both validators, manifest verification and clean-extract re-verification.

## Deliberately unresolved
ADR-003 remains PROPOSED. G05 provider compatibility, G08 service-layer trust root (authenticated identity + aggregate provenance), and G11 CI/container halves remain RED within their PARTIAL/split gates. CapacityLedger/aggregate governance, proposal confirmation workflow, event persistence fields, ExecutionSession, matching: DECLARED, unimplemented, unclaimed. Domain core 0.6.1 (documentation/contract clarification; no behavioural change to protected operations).
