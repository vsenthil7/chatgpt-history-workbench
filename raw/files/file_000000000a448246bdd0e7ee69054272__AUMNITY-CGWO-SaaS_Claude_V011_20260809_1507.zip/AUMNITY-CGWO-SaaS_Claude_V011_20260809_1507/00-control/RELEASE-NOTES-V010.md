# Release Notes — Claude V010 (closure / freeze-candidate release)

Input: `AUMNITY-CGWO-SaaS_Claude_V009_20260809_1350.zip` plus the independent ChatGPT review of that ZIP (findings F42–F44). The review accepted F38/F39/F41 as closed, F40 as materially improved, and the ADR-015 trust model as correct — asking for NO redesign, only three disciplined corrections as a closure build before the domain freeze. `10-baseline/` preserved byte-for-byte; no feature expansion. Domain core 0.6.3.

## Review findings → what changed
- **F42 (P1 BLOCKER)** — Aggregate-typed operation arguments were read before being validated, so `transition_plan_item("bad", …)`, `transition_allocation`, `consume_allocation` and `windows_overlap` surfaced raw `AttributeError` — contradicting ADR-010/RTM DOM-008. Added a `require_aggregate` helper that validates the argument's aggregate type BEFORE any attribute read, raising a controlled `WRONG_RUNTIME_TYPE` DomainError. It deliberately uses `isinstance` and ADMITS subclasses, so a lying subclass still reaches the authorization layer and is denied there (F32 semantics preserved) — this is API/invariant hygiene, explicitly NOT authorization or provenance (ADR-015). Applied at all four sites; guard-site matrix rows added for str/None/object plus a subclass-admitted regression (RTM DOM-008/DOM-014).
- **F43 (P1)** — Manifest validation was one-way (it checked listed hashes but never that every shipped managed file was listed, so an unmanifested `EXTRA.txt` passed). Introduced a single canonical inclusion/exclusion policy (`scripts/manifest_policy.py`) shared by `gen_manifest.py` and `validate_consistency.py` so they cannot drift, and made validation CLOSED over the shipped set: it now fails on unmanifested files, missing entries, hash mismatches, duplicates and an inaccurate `file_count`. Regressions in `tests/test_manifest_closure.py` reproduce the exact `EXTRA.txt` attack (RTM DOC-006).
- **F44 (P2)** — The package-root identity check only ran for release-looking names, so an arbitrary `BADNAME` root skipped validation despite RELEASE-IDENTITY calling the directory name a derived representation. Replaced the implicit inference with explicit dev/release modes: in release-validation mode the root-identity check is UNCONDITIONAL (BADNAME fails); development trees opt out explicitly via `--dev` or a `_WIP` suffix. Regressions cover an arbitrary non-release root and the `--dev` opt-out (RTM DOC-007).

## Preserved from earlier cycles
ADR-015 and the F34/F37 trust-boundary semantics are unchanged. The F31 wire fixes, ADR-014 amendment, F38/F39/F40/F41 changes, exact-type guards, error-identity tests, canonical-identity mechanism and all prior adversarial/regression suites remain. No protected-operation behaviour changed beyond adding controlled rejection of malformed arguments.

## Scope honesty (unchanged)
G08 GREEN claims only authorization-policy enforcement; the RED half is the service-layer trust root (authenticated identity + aggregate provenance). G10 GREEN claims only STRUCTURAL consistency. The F42 guard is named API/invariant hygiene, not a security control.

## Verification outcome
All executable gates green on the final tree: full suite including the new F42 guard-site rows and F43 closed-set manifest regressions, 100% line+branch coverage, strict mutation gate with zero anomalies/survivors and an empty acceptance list, ruff check+format, mypy strict, both validators, closed-set manifest verification and clean-extract re-verification. `10-baseline/` byte-for-byte identical to V009/V008/V007.

## Freeze candidate
V010 is offered as the candidate domain-core baseline freeze. If accepted, the next tranche begins the first service-layer vertical slice: authenticated identity binding + tenant-scoped authoritative repository + one end-to-end feature path — closing the RED halves rather than re-hardening the domain core.

## Deliberately unresolved
ADR-003 remains PROPOSED. G05 provider compatibility, G08 service-layer trust root, and G11 CI/container halves remain RED within their PARTIAL/split gates. CapacityLedger/aggregate governance, proposal confirmation workflow, event persistence fields, ExecutionSession, matching: DECLARED, unimplemented, unclaimed.
