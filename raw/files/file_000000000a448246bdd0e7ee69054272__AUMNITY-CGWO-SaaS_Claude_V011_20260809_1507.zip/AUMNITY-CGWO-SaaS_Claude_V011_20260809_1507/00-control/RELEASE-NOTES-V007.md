# Release Notes — Claude V007 (trust-model correction release)

Input: `AUMNITY-CGWO-SaaS_Claude_V006_20260809_1045.zip` plus the independent ChatGPT review of that ZIP (findings F30–F33). V006 was rejected because ADR-013's security premise — that an exact-typed genuine domain object is a trustworthy tenant-authorization anchor — was proven false: `object.__setattr__` mutates a genuine frozen instance in place, defeating exact-type guards. `10-baseline/` preserved byte-for-byte; no feature expansion.

## The architectural correction (ADR-014)
The reviewer was right that this needed a redesign, not another patch. **In-process Python object identity cannot establish tenant authority.** A string inside a dataclass is a caller-supplied value, not proof of authorisation, and no `type(x) is X` check changes that because the attack uses a genuinely-typed object.

ADR-014 introduces an authorization trust boundary:
- A new `authz` module defines `AuthorizationPort` (the contract a real service authorization layer implements against authenticated identity/claims) and `StaticAuthorizationContext` (a reference implementation with entitlements frozen at construction — a contract, not a production identity system).
- `assert_authorized(authz, tenant_id)` is the real security decision: is the authenticated principal entitled to this tenant? It depends ONLY on the authenticated entitlement set, never on a caller-supplied object's attributes.
- Every protected operation (`plan-item`/`allocation` transitions, `consume`, `guarded_window`) now takes an `AuthorizationContext`. `TenantContext` is demoted to a routing label; relabeling or subclassing it changes a label, not authority.

## Review findings → what changed
- **F30 (P0, security)** — The `object.__setattr__` mutation attack is now defeated at the authorization layer: mutating `TenantContext.tenant_id` or a `CapacityWindow`'s fields changes a label/value, not the authenticated entitlement set, so the operation is still denied. The reviewer's exact mutation payloads are named regressions in `tests/test_adversarial_objects.py`. ADR-013's "genuine instance attributes are safe to read" claim is corrected; SEC-001, DOM-010 and G08 language are rewritten to stop overclaiming.
- **F31 (P1)** — `parse_wire_int` now enforces a single semantic bound `WIRE_INT_MAX_VALUE` (10¹²) identically on both the exact-`int` path and the string path, so an oversized exact int (e.g. `10**5000`) can no longer bypass the limit and surface CPython's raw `ValueError` downstream at `repr()`. Magnitude is checked without ever stringifying an unbounded int. INT-006 wording corrected; exact-int oversized regressions added.
- **F32 (P0/P1)** — Aggregate subclass attacks (`LyingPlanItem`, lying `CapacityAllocation`) are resolved by the same architectural change, not by more exact-instance checks: the transition authorizes against the aggregate's reported tenant via the authenticated entitlement set, which a lying subclass cannot forge. Named regressions included. DOM-010's object-immunity claim is withdrawn; DOM-012 records the authz-parameter requirement.
- **F33 (P2)** — The stale RTM AI-001 row is corrected to the current cycle, and a machine rule (`validate_consistency.py`) plus regression (`tests/test_current_cycle.py`) now tie the RTM current-cycle handoff reference to the actual release series, so this class of stale status cannot pass G10 again.

## Scope honesty (unchanged and now more precise)
The domain core enforces the authorization DECISION against a supplied entitlement set. It does NOT establish authenticated identity — binding `AuthorizationPort` to real authenticated claims is a service-layer responsibility that does not exist yet. G08's service-layer half is explicitly RED. This release makes a smaller, true claim rather than a larger false one.

Note: the V006 defence-in-depth "integrity tag" idea was dropped rather than shipped — it added surface without being a security control, and the honest architecture is that authz is the boundary.

## Verification outcome
All executable gates green on the final tree: full suite including the new authz and adversarial-object/mutation regressions, 100% line+branch coverage, strict mutation gate with zero anomalies/survivors and an empty acceptance list, ruff check+format, mypy strict, both validators, clean-extract re-verification.

## Deliberately unresolved
ADR-003 remains PROPOSED. G05 provider compatibility, G08 service-layer authenticated identity, and G11 CI/container halves remain RED within their PARTIAL/split gates. CapacityLedger/aggregate governance, proposal confirmation workflow, event persistence fields, ExecutionSession, matching: DECLARED, unimplemented, unclaimed.
