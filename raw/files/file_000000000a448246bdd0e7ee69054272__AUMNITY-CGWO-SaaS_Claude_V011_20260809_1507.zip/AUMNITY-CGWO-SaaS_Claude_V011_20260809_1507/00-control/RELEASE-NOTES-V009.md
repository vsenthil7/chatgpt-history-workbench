# Release Notes — Claude V009 (closure / freeze-candidate release)

Input: `AUMNITY-CGWO-SaaS_Claude_V008_20260809_1326.zip` plus the independent ChatGPT review of that ZIP (findings F38–F41). The review accepted ADR-015's service-boundary trust-root direction and explicitly asked for NO further trust-model redesign — only four disciplined corrections. `10-baseline/` preserved byte-for-byte; no feature expansion. Domain core 0.6.2 (contract/governance corrections only; no behavioural redesign).

## Review findings → what changed
- **F38 (P1)** — The current, user-visible `NOT_ENTITLED` message no longer implies authentication. `errors.py` renders it as "supplied authorization capability denied access to tenant {tenant_id}" instead of "authenticated principal is not entitled…". The stable `NOT_ENTITLED` code is unchanged (error identity is the code, not the prose — ADR-011/F19). A regression (`tests/test_error_identity.py`) fails if any current message template implies authenticated identity, and asserts the new capability wording (RTM SEC-004).
- **F39 (P1)** — `StaticAuthorizationContext` now validates its entitlements CONTAINER, not only its members. A non-set/frozenset container (None, int, raw string, list, tuple, dict) raises a controlled `AuthorizationError`/`WRONG_RUNTIME_TYPE` instead of an incidental Python `TypeError` or — worse — a raw string silently accepted as a set of characters. Exact `set`/`frozenset` is enforced, consistent with the project's exact-type stance (ADR-012). This is constructor contract hygiene, NOT an F34 tamper-resistance control. Regressions cover None/int/string/list/tuple/dict and hostile members (RTM DOM-013).
- **F40 (P1)** — The canonical release-identity protection is completed. The release-notes-specific future-version check is replaced by a GENERIC versioned-artifact rule covering release notes, gate statuses AND handoffs: the canonical-series file of each family must exist and no file of any family numbered above the canonical series may exist (the V008 rule let a stray future gate/handoff pass). Additionally the package ROOT directory name is now validated to embed the canonical series and to equal the manifest release — RELEASE-IDENTITY.json claimed the directory name was derived, but V008 never checked it. Negative tests cover each spoof path (RTM DOC-003).
- **F41 (P2/P1)** — The ADR-consistency claim is made honest. DOC-004 and G10 previously implied a general "accepted ADRs never contradict their release" guarantee; the implementation is only a specific STRUCTURAL regression for the exact F35 defect. DOC-004 is narrowed to say exactly that, G10 is marked "STRUCTURAL rules only", and the validator comment states plainly that semantic ADR consistency remains an independent-review (G12) duty. No pretence that a text validator proves architectural consistency.

## Preserved from earlier cycles
ADR-015 and the F34/F37 trust-boundary tests are unchanged. The F31 wire-integer fixes, the hostile int-subclass probe, the exact-type guards, error-identity tests, canonical-identity mechanism and all prior adversarial suites remain. No protected-operation behaviour changed.

## Scope honesty (unchanged, now precise at the message layer too)
G08 GREEN claims only authorization-policy enforcement; the RED half is the service-layer trust root (authenticated identity + aggregate provenance). G10 GREEN now explicitly claims only STRUCTURAL consistency, not semantic ADR consistency.

## Verification outcome
All executable gates green on the final tree: full suite including the new F38/F39 regressions, 100% line+branch coverage, strict mutation gate with zero anomalies/survivors and an empty acceptance list, ruff check+format, mypy strict, both validators, manifest verification and clean-extract re-verification. `10-baseline/` byte-for-byte identical to V008/V007.

## Freeze candidate
V009 is offered as the candidate domain-core baseline freeze. If accepted, the next tranche begins the first service-layer vertical slice: authenticated identity binding + tenant-scoped authoritative repository + one end-to-end feature path — closing the RED halves rather than re-hardening the domain core.

## Deliberately unresolved
ADR-003 remains PROPOSED. G05 provider compatibility, G08 service-layer trust root, and G11 CI/container halves remain RED within their PARTIAL/split gates. CapacityLedger/aggregate governance, proposal confirmation workflow, event persistence fields, ExecutionSession, matching: DECLARED, unimplemented, unclaimed.
