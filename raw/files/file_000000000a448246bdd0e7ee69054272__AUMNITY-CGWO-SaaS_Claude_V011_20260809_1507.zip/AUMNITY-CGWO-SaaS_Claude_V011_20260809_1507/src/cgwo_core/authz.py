"""Authorization-policy enforcement port (ADR-014 as amended, ADR-015).

Trust model (ADR-015, review findings F30/F32/F34/F37): **no in-process
Python object can prove authority** — not a frozen domain dataclass (F30),
and not an authorization context either (F34). The trust root is the
service/application boundary, which does not exist yet (G08 RED half). That
boundary is responsible for authenticating the principal, establishing its
entitlements, constructing a genuine ``AuthorizationPort`` capability, and
loading aggregates only from an authoritative tenant-scoped store (F37).

What this module — and the domain core — actually guarantees is
**authorization-policy enforcement**: every protected operation consults the
supplied capability before acting, and a deny decision is honoured with a
controlled ``AuthorizationError``. Nothing here can or does establish that
the supplied capability is genuine, unmutated, or bound to authenticated
identity. ``AuthorizationPort`` is a dependency-injection contract for a
trusted supplier, not a security boundary: a hostile in-process
implementation, or in-process mutation of the reference context, is inside
the trust boundary and out of scope by design
(``tests/test_trust_boundary.py`` documents this executably).

Deliberately, per ADR-015 Decision 4, no Python-level tamper resistance is
attempted anywhere in this module. F30 proved that lesson; hardening another
object would only recreate the overclaim.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from cgwo_core.errors import (
    EXPECTED_ENTITLEMENTS,
    F_TENANT_ID,
    FIELD_BLANK,
    NOT_ENTITLED,
    WRONG_RUNTIME_TYPE,
    DomainError,
    build,
)
from cgwo_core.validation import require_str


class AuthorizationError(DomainError):
    """Raised when the supplied capability denies a tenant operation."""


@runtime_checkable
class AuthorizationPort(Protocol):
    """The capability contract a trusted service layer supplies (ADR-015).

    This is a structural Protocol on purpose: it is a dependency-injection
    contract, not a security boundary. The domain core trusts whatever
    implementation the application boundary hands it — exactly as it would
    trust a repository implementation. Binding ``principal`` and
    ``is_entitled`` to real authenticated identity/claims is the service
    layer's responsibility and is not claimed by this package.
    """

    @property
    def principal(self) -> str: ...

    def is_entitled(self, tenant_id: str) -> bool: ...


class StaticAuthorizationContext:
    """Reference ``AuthorizationPort`` with entitlements set at construction.

    A test/contract reference ONLY (ADR-015 Decision 4). It is an ordinary
    mutable Python object: its attributes can be reassigned by any in-process
    caller, and no tamper resistance is attempted — deliberately. Its
    trustworthiness, like that of any port implementation, comes from being
    constructed and supplied by the trusted service boundary, never from
    Python object mechanics. Construction validates member *shape* (exact
    ``str`` entitlements, non-blank principal) and the *container* itself
    (exact ``set``/``frozenset``, F39) as invariant hygiene, raising controlled
    ``AuthorizationError``s rather than incidental Python exceptions — this is
    not a security property.
    """

    __slots__ = ("_entitlements", "_principal")

    _principal: str
    _entitlements: frozenset[str]

    def __init__(self, principal: str, entitlements: frozenset[str] | set[str]) -> None:
        checked_principal = require_str(principal, "principal", AuthorizationError)
        if not checked_principal.strip():
            raise build(AuthorizationError, FIELD_BLANK, field="principal")
        # F39: validate the CONTAINER before iterating. The declared contract is
        # an exact set/frozenset; a raw string, list, tuple, dict, None or int
        # must raise a controlled DomainError, never an incidental Python
        # TypeError and never a silently-accepted wrong container (e.g. a raw
        # string iterated character-by-character). This is ordinary constructor
        # contract hygiene, consistent with the project's exact-type stance
        # (ADR-012); it is NOT a tamper-resistance/security control (ADR-015).
        if type(entitlements) not in (set, frozenset):
            raise build(
                AuthorizationError,
                WRONG_RUNTIME_TYPE,
                field="entitlements",
                expected=EXPECTED_ENTITLEMENTS,
                actual=type(entitlements).__name__,
            )
        # Copy into a frozenset of exact-str entitlements; reject hostile members.
        checked = frozenset(
            require_str(entry, "entitlement", AuthorizationError) for entry in entitlements
        )
        self._principal = checked_principal
        self._entitlements = checked

    @property
    def principal(self) -> str:
        return self._principal

    def is_entitled(self, tenant_id: str) -> bool:
        # Exact-str comparison against this context's current entitlement set.
        checked = require_str(tenant_id, F_TENANT_ID, AuthorizationError)
        return checked in self._entitlements


def assert_authorized(authz: AuthorizationPort, tenant_id: str) -> None:
    """Deny the operation unless the supplied capability allows the tenant.

    This is authorization-POLICY enforcement (ADR-015): the domain core
    guarantees the capability is consulted and a deny is honoured with a
    controlled error. It does not establish that ``authz`` is genuine or
    authenticated — that is the service-layer trust root, currently RED
    (G08). The tenant being authorized is passed in by the protected
    operation from the aggregate's own label; the aggregate's provenance is
    likewise a service-layer prerequisite (F37, RTM SEC-003).
    """
    if not isinstance(authz, AuthorizationPort):
        raise build(
            AuthorizationError,
            WRONG_RUNTIME_TYPE,
            field="authz",
            expected="AuthorizationPort",
            actual=type(authz).__name__,
        )
    checked = require_str(tenant_id, F_TENANT_ID, AuthorizationError)
    if not authz.is_entitled(checked):
        raise build(AuthorizationError, NOT_ENTITLED, tenant_id=checked)
