"""Canonical-primitive runtime guards for domain trust boundaries (ADR-012).

Python type annotations are not runtime constraints, and ``isinstance`` is
too permissive for untrusted values: hostile subclasses of ``str``/``int``
can override equality, comparison and ``.strip()`` to defeat security and
invariant checks (V004 review findings F20–F22), ``isinstance`` itself
consults a spoofable ``__class__``, and ``datetime.datetime`` slips through
``isinstance(x, date)`` while breaking date-only semantics (F23).

The domain therefore stores ONLY canonical primitives, enforced with exact
type checks (``type(value) is ...``), which read the real type slot and are
immune to ``__class__`` spoofing:

* exact built-in ``str`` — no subclasses, so no hostile ``__eq__``/``strip``
* exact built-in ``int`` — ``bool`` excluded by construction
* exact ``datetime.date`` — ``datetime.datetime`` excluded by design
* exact enum member type — Enum classes with members cannot be subclassed,
  and the exact-type rule additionally defeats spoofed ``__class__`` objects

Raw wire values are normalised only in explicit parsers
(``contracts.from_wire`` / ``parse_wire_*``), which emit canonical values.
"""

from __future__ import annotations

from datetime import date
from enum import Enum
from typing import TypeVar

from cgwo_core.errors import (
    EXPECTED_DATE,
    EXPECTED_INT,
    EXPECTED_STR,
    WRONG_RUNTIME_TYPE,
    DomainError,
    build,
)

T = TypeVar("T")


def require_str(value: object, field: str, exc_cls: type[DomainError]) -> str:
    if type(value) is not str:
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=EXPECTED_STR,
            actual=type(value).__name__,
        )
    return value


def require_optional_str(value: object, field: str, exc_cls: type[DomainError]) -> str | None:
    if value is None:
        return None
    return require_str(value, field, exc_cls)


def require_int(value: object, field: str, exc_cls: type[DomainError]) -> int:
    if type(value) is not int:
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=EXPECTED_INT,
            actual=type(value).__name__,
        )
    return value


def require_date(value: object, field: str, exc_cls: type[DomainError]) -> date:
    if type(value) is not date:
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=EXPECTED_DATE,
            actual=type(value).__name__,
        )
    return value


def require_exact_instance[T](
    value: object, expected_cls: type[T], field: str, exc_cls: type[DomainError]
) -> T:
    """Require an EXACT instance of a domain class — no subclasses (ADR-013).

    Domain objects that cross trust boundaries (e.g. ``TenantContext``,
    ``CapacityWindow``) must be canonical: a subclass can override
    ``__getattribute__`` to lie about ``tenant_id`` or ``available_minutes``
    and defeat isolation/quantity checks (V005 review F27/F28). ``type() is``
    reads the real type slot and cannot be spoofed. Callers still read
    attributes normally afterwards, but only from a genuine, non-overriding
    instance.
    """
    if type(value) is not expected_cls:
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=expected_cls.__name__,
            actual=type(value).__name__,
        )
    return value


def require_enum[E: Enum](
    value: object, enum_cls: type[E], field: str, exc_cls: type[DomainError]
) -> E:
    if type(value) is not enum_cls:
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=enum_cls.__name__,
            actual=type(value).__name__,
        )
    return value


def require_aggregate[T](
    value: object, expected_cls: type[T], field: str, exc_cls: type[DomainError]
) -> T:
    """Require an aggregate operation argument to BE the aggregate type (F42).

    This is public-API / invariant hygiene ONLY (ADR-010): protected operations
    must reject a malformed argument (e.g. a ``str``, ``None`` or arbitrary
    ``object`` passed where a ``PlanItem``/``CapacityAllocation``/``CapacityWindow``
    is expected) with a controlled ``WRONG_RUNTIME_TYPE`` DomainError BEFORE
    reading any attribute, rather than crashing with an incidental
    ``AttributeError``.

    Unlike ``require_exact_instance`` this deliberately ACCEPTS subclasses: it
    is NOT a security/provenance control (ADR-015). A lying aggregate subclass
    is admitted here and is handled by the authorization layer exactly as the
    F32 regressions require — the domain core never treats aggregate contents
    as authority. The guard only stops non-aggregate arguments from producing
    uncontrolled Python exceptions.

    Mechanism (V010 review, F45): the check reads the REAL runtime type via
    ``issubclass(type(value), expected_cls)`` rather than ``isinstance``.
    ``isinstance`` consults a spoofable ``__class__`` (documented at the top of
    this module since ADR-012), so an arbitrary object exposing a lying
    ``__class__`` property passed the V010 guard and then crashed with the very
    raw ``AttributeError`` the guard exists to prevent. ``type()`` reads the
    real type slot and cannot be spoofed; a genuine subclass's true type still
    inherits the aggregate class and is admitted, while a ``__class__``
    impostor's true type does not and is rejected with a controlled
    ``WRONG_RUNTIME_TYPE`` DomainError naming its REAL type.
    """
    if not issubclass(type(value), expected_cls):
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=expected_cls.__name__,
            actual=type(value).__name__,
        )
    # mypy cannot narrow through issubclass(type(value), ...); the targeted
    # suppression is sound because the runtime check above is STRICTER than
    # isinstance-based narrowing — it consulted the real type slot, not a
    # spoofable __class__. A runtime typing.cast() call is deliberately NOT
    # used: cast is a runtime no-op, so its type argument is unkillable by any
    # test and would force mutation-acceptance entries (ADR-011 keeps the
    # acceptance list empty). Call sites consume the returned validated value,
    # like every other require_* helper, which keeps return-path mutants lethal.
    return value  # type: ignore[return-value]
