"""CGWO domain core — capacity/availability and planning state transitions.

Pure standard-library reference implementation per ADR-003 (Status: PROPOSED).
All Platform primitives are consumed as opaque references per ADR-006.
Capacity types generalise supervisory/review capacity per ADR-002.
Execution/tracker ownership per ADR-001. Allocation invariants per ADR-007.
Domain-change records per ADR-008. Isolation boundary per ADR-009.
"""

from cgwo_core.allocation import AllocationChange, AllocationState, CapacityAllocation
from cgwo_core.authz import (
    AuthorizationError,
    AuthorizationPort,
    StaticAuthorizationContext,
    assert_authorized,
)
from cgwo_core.capacity import (
    AvailabilityDeclaration,
    CapacityType,
    CapacityWindow,
    windows_overlap,
)
from cgwo_core.contracts import (
    CONSUMER_CONTRACT_VERSION,
    AvailabilityProposal,
    ContractViolationError,
    TimeRecordProposal,
    parse_wire_capacity_type,
    parse_wire_date,
    parse_wire_int,
)
from cgwo_core.errors import DomainError
from cgwo_core.plan_item import (
    ChangeReasonRequiredError,
    InvalidTransitionError,
    PlanItem,
    PlanItemChange,
    PlanItemInvariantError,
    PlanItemState,
)
from cgwo_core.tenancy import (
    CrossTenantAccessError,
    MissingTenantContextError,
    TenantContext,
    TenantIsolationError,
    assert_tenant_operation,
)

__all__ = [
    "CONSUMER_CONTRACT_VERSION",
    "AllocationChange",
    "AllocationState",
    "AuthorizationError",
    "AuthorizationPort",
    "AvailabilityDeclaration",
    "AvailabilityProposal",
    "CapacityAllocation",
    "CapacityType",
    "CapacityWindow",
    "ChangeReasonRequiredError",
    "ContractViolationError",
    "CrossTenantAccessError",
    "DomainError",
    "InvalidTransitionError",
    "MissingTenantContextError",
    "PlanItem",
    "PlanItemChange",
    "PlanItemInvariantError",
    "PlanItemState",
    "StaticAuthorizationContext",
    "TenantContext",
    "TenantIsolationError",
    "TimeRecordProposal",
    "assert_authorized",
    "assert_tenant_operation",
    "parse_wire_capacity_type",
    "parse_wire_date",
    "parse_wire_int",
    "windows_overlap",
]
