"""Tenant context and the authorization-based isolation check (ADR-014).

`tenant_id` is the isolation label (ADR-009). Tenant authority is never
established by this package (ADR-014 as amended, ADR-015): a `TenantContext`
is a plain value/label, and `assert_tenant_operation` performs
authorization-POLICY enforcement against a supplied `AuthorizationPort`
capability. The capability's genuineness and the aggregate's provenance are
service-layer trust prerequisites (G08 RED half; RTM SEC-001/SEC-003).
"""

from __future__ import annotations

from dataclasses import dataclass

from cgwo_core.authz import AuthorizationPort, assert_authorized
from cgwo_core.errors import (
    CROSS_TENANT,
    EXPECTED_TENANT_CONTEXT,
    F_CTX,
    F_ORGANISATION_ID,
    F_OWNER_TENANT_ID,
    F_TENANT_ID,
    FIELD_BLANK,
    ORGANISATION_ID_BLANK,
    WRONG_RUNTIME_TYPE,
    DomainError,
    build,
)
from cgwo_core.validation import require_optional_str, require_str


class TenantIsolationError(DomainError):
    """Base class for tenant-isolation failures."""


class MissingTenantContextError(TenantIsolationError):
    """Raised when a protected operation lacks a usable tenant context."""


class CrossTenantAccessError(TenantIsolationError):
    """Raised when a tenant context targets another tenant's aggregate."""


def _validate_context(tenant_id: object, organisation_id: object) -> None:
    checked_tenant = require_str(tenant_id, F_TENANT_ID, MissingTenantContextError)
    if not checked_tenant.strip():
        raise build(MissingTenantContextError, FIELD_BLANK, field=F_TENANT_ID)
    checked_org = require_optional_str(
        organisation_id, F_ORGANISATION_ID, MissingTenantContextError
    )
    if checked_org is not None and not checked_org.strip():
        raise build(MissingTenantContextError, ORGANISATION_ID_BLANK)


@dataclass(frozen=True, slots=True)
class TenantContext:
    """A caller-supplied tenant label (NOT proof of authority, ADR-014)."""

    tenant_id: str
    organisation_id: str | None = None

    def __post_init__(self) -> None:
        _validate_context(self.tenant_id, self.organisation_id)


def assert_tenant_operation(
    authz: AuthorizationPort, ctx: TenantContext, owner_tenant_id: str
) -> None:
    """Authorize a protected operation on an aggregate owned by a tenant.

    Two independent checks (ADR-014 as amended, ADR-015):

    1. **Authorization-policy enforcement** — the supplied ``authz``
       capability must report the principal entitled to ``owner_tenant_id``
       (the aggregate's own tenant label). The domain core guarantees this
       consultation happens and a deny is honoured; it does NOT establish
       that the capability is genuine or authenticated — that is the
       service-layer trust root (G08 RED half, ADR-015).
    2. **Routing consistency** — the caller's ``ctx`` label must name the same
       tenant it claims to be operating within. This catches honest routing
       mistakes; it is not itself a security boundary.

    ``owner_tenant_id`` IS a caller-supplied fact: it is read from the
    aggregate object passed into the protected operation. The check therefore
    also assumes AGGREGATE PROVENANCE (F37, RTM SEC-003): the application
    layer must have loaded/rehydrated the aggregate from an authoritative
    tenant-scoped persistence boundary. A caller genuinely entitled to tenant
    B who relabels an arbitrary object as B-owned will pass this check; the
    domain package does not, and cannot, establish object provenance.
    """
    checked_owner = require_str(owner_tenant_id, F_OWNER_TENANT_ID, CrossTenantAccessError)
    assert_authorized(authz, checked_owner)
    # ``ctx`` is a routing label, not a security anchor (ADR-014), but reading
    # a stray attribute off a non-context value would be an uncontrolled
    # AttributeError; require a genuine context to keep the routing check
    # controlled. This is NOT the policy decision — that was assert_authorized
    # above, which no ctx value can influence.
    if type(ctx) is not TenantContext:
        raise build(
            MissingTenantContextError,
            WRONG_RUNTIME_TYPE,
            field=F_CTX,
            expected=EXPECTED_TENANT_CONTEXT,
            actual=type(ctx).__name__,
        )
    # A genuine TenantContext validated its tenant_id at construction, so the
    # routing comparison can use it directly. This is a label consistency check
    # (ADR-014), never the security decision.
    if ctx.tenant_id != checked_owner:
        raise build(CrossTenantAccessError, CROSS_TENANT)
