# ADR-014 — Authorization trust boundary: identity is not object identity

Status: ACCEPTED
Date: 2026-08-09
Responds to: independent review of V006, findings F30 and F32.
Supersedes: the security premise of ADR-013 (that an exact-type genuine domain object is a trustworthy tenant-authorization anchor). ADR-013's exact-type/instance guards are retained ONLY as invariant hardening, explicitly demoted from a security control.

## Context
ADR-013 tried to make tenant isolation safe by requiring exact (non-subclass) domain objects. The V006 review proved this premise false: `@dataclass(frozen=True, slots=True)` is not an integrity boundary — `object.__setattr__(TenantContext("attacker"), "tenant_id", "victim")` mutates a genuine, exact-typed instance in place, after validation, and `assert_same_tenant(ctx, "victim")` then passes (F30). The same mutation defeats `CapacityWindow`, and a hostile `PlanItem`/`CapacityAllocation` subclass overriding `__getattribute__` defeats protected operations from one layer up (F32). No amount of `type(x) is X` checking can fix this, because the attack uses a genuinely-typed object.

**The architectural lesson: in-process Python object identity cannot be an authorization trust anchor.** A string inside a dataclass is a caller-supplied value, not proof of authority. Authorization must be bound to an *authenticated* authority established at the service/application boundary — never inferred from the contents of a domain object the caller handed us.

## Decisions
1. **A domain object never proves tenant authority.** The domain core is redefined as operating on *caller-asserted* values whose invariants it enforces; it does not and cannot decide whether the caller is entitled to act for a tenant.
2. **Authorization is a named boundary port.** A new `authz` module defines `AuthorizationContext` (an authenticated principal + the set of tenant ids that principal is entitled to act for) and an `AuthorizationPort` protocol that a real service layer implements against authenticated identity/claims. The domain core ships one reference implementation, `StaticAuthorizationContext`, whose entitlements are fixed at construction from a trusted caller — it is a contract/reference, not a production identity system.
3. **Protected operations require an `AuthorizationContext`, not just a `TenantContext`.** `assert_authorized(authz, tenant_id)` checks that the authenticated principal is entitled to the tenant the operation targets. `TenantContext` is demoted to a plain caller-supplied value object (a routing/label carrier), never a proof of authority.
4. **Object-mutation invariants are hardened but not trusted for security.** Value objects add a lightweight post-construction integrity check (a private consistency tag) so accidental/among-honest-code mutation is caught, while the ADR is explicit that this is defence-in-depth, not an authorization control.
5. **RTM/gate language is corrected.** SEC-001 is rewritten: the domain core enforces *invariants and structural isolation of values*, while *tenant authorization* is DECLARED at the `authz` port and DEFERRED to the service layer. G08 domain-core stays GREEN only for what it truly enforces; the authorization half is explicitly RED/DECLARED.

## Consequences
- The F30/F32 attacks can no longer reach a protected decision on the basis of a mutated/lying object, because the security decision is `authz`-based: mutating `TenantContext.tenant_id` changes a label, not the authenticated entitlement set, and a lying subclass of an aggregate cannot manufacture entitlement it was not granted.
- The domain core makes a smaller, TRUE claim rather than a larger false one.
- New module `src/cgwo_core/authz.py`; protected operations gain an authorization parameter; regressions include the exact `object.__setattr__` and lying-subclass attacks proving they cannot obtain authority.
- Version 0.6.0 (pre-1.0 breaking change: protected operations take an AuthorizationContext).

---

## Amendment A1 (V008, review finding F35) — corrections so this ACCEPTED decision matches the shipped architecture

The independent V007 review (F35) found this ADR, as accepted, contradicting
the release it shipped in. An ACCEPTED ADR is authoritative architecture, so
the contradictions are corrected here by transparent amendment, not silent
rewrite. The original text above is preserved unchanged.

1. **Decision 4 is WITHDRAWN — the consistency tag was deliberately not
   shipped.** No "lightweight post-construction integrity check / private
   consistency tag" exists in V007 or later. As recorded in
   `08-ai/CLAUDE-V007-HANDOFF.md`, the mechanism was dead code implying a
   guarantee it could not give and was removed before release. Object-mutation
   resistance is NOT provided at any level; see ADR-015 Decision 4.

2. **Decision 5's gate wording is superseded.** The shipped V007 gate said
   "GREEN (domain-core AUTHORIZATION check) / RED (service-layer authenticated
   identity)", which neither matched Decision 5's "authorization half is
   explicitly RED/DECLARED" nor survived the V007 review (F34). The final
   wording is defined by ADR-015 Decision 6: the GREEN half claims only
   **authorization-policy enforcement**; the RED half covers the full
   service-layer trust root (authenticated identity binding AND authoritative
   aggregate provenance).

3. **Scope note.** This ADR's core lesson — object identity is not a trust
   anchor — stands. Its residual overclaim (treating the supplied
   authorization capability as an "authenticated" security decision inside
   the domain core) is resolved by ADR-015, which this amendment defers to
   for the final trust-boundary formulation.

Amendment status: ACCEPTED, 2026-08-09.
