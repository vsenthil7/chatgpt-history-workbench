# ADR-015 — The service boundary is the trust root; the domain core enforces authorization POLICY, not authorization AUTHORITY

Status: ACCEPTED
Date: 2026-08-09
Responds to: independent review of V007, findings F34 (P0) and F37 (P1).
Relates to: ADR-014 (amended by its Amendment A1 to align with this decision).

## Context

V007 (ADR-014) correctly removed domain-object identity as a trust anchor, but
re-created the same class of claim one layer up. The V007 review (F34)
reproduced two attacks against the shipped package:

1. `StaticAuthorizationContext._entitlements` is reassignable by ordinary
   attribute assignment — no `object.__setattr__` trick required — after which
   `is_entitled("victim")` returns true and a protected victim-tenant
   transition succeeds.
2. `AuthorizationPort` is a `@runtime_checkable` structural Protocol, so any
   duck-typed object whose `is_entitled()` returns `True` is accepted and
   authorizes the operation.

Both attacks are *correct behaviour of the shipped contract* and *fatal to the
shipped claim*. The gate said "GREEN (domain-core AUTHORIZATION check)" and
RTM SEC-001 said the decision is one "which no mutated or lying object can
forge". Those statements described a security property the package does not
have: the package holds no authenticated principal — it holds an arbitrary
in-process Python object whose `is_entitled()` result it trusts.

The V006/F30 lesson generalises: **no in-process Python object — domain value,
frozen dataclass, or authorization context — can prove authority to code
running in the same interpreter as the caller.** Attempting to make
`StaticAuthorizationContext` "unforgeable" with further Python mechanisms
would repeat the exact mistake ADR-014 was written to end, and is explicitly
rejected here.

The review also identified a second, distinct gap (F37): protected operations
authorize against `item.tenant_id` / `allocation.tenant_id` — the tenant
label carried by the aggregate the caller supplied. A caller with a genuine
entitlement to tenant B can relabel an arbitrary object as B-owned and have
the domain treat it as B's data. That is not a privilege-escalation bug; it is
an **aggregate-provenance** gap: nothing in the domain package establishes
that the aggregate came from an authoritative tenant-scoped store.

## Decision

1. **The trust root is the service/application boundary, by definition.**
   The trust model is:

   - *Service/application layer (trusted, DOES NOT EXIST YET):* authenticates
     the principal, establishes its entitlements, constructs a genuine
     authorization capability, and loads/rehydrates aggregates exclusively
     from an authoritative tenant-scoped persistence boundary.
   - *Domain core (this package):* enforces business invariants and honours
     the allow/deny semantics of the **supplied** authorization capability.

2. **The domain core's security claim is renamed and narrowed to
   "authorization-policy enforcement".** The domain core guarantees exactly:
   (a) every protected operation consults the supplied capability before
   acting, and (b) a deny decision is honoured with a controlled
   `AuthorizationError`. It does not and cannot guarantee the capability is
   genuine, unmutated, or bound to any authenticated identity. Wording such
   as "the real security decision", "authenticated entitlement set" (as a
   property of this package), and "no mutated or lying object can forge" is
   retired from current canonical documents; a machine rule in
   `validate_consistency.py` keeps the retired phrases out.

3. **`AuthorizationPort` remains a structural Protocol, deliberately.** The
   port is a dependency-injection contract for a trusted supplier, not a
   security boundary. A hostile in-process implementation is *inside* the
   trust boundary and out of scope — exactly as a hostile implementation of a
   repository interface would be. This answers the V007 handoff question: as
   an application-layer DI contract, yes; as a domain-enforced security
   boundary, no such thing is possible in-process.

4. **`StaticAuthorizationContext` is documented as mutable and non-defensive.**
   It is a reference implementation for tests and contract demonstration. No
   further Python hardening (name mangling, MappingProxy, C extensions,
   integrity tags) will be attempted, per the F30 lesson.

5. **Aggregate provenance is an explicit, named service-layer trust
   prerequisite (F37).** Protected domain operations assume the aggregate
   supplied by the application layer was loaded/rehydrated from an
   authoritative tenant-scoped persistence boundary; domain-object provenance
   is not established by the domain package itself. This joins authenticated
   identity in the RED half of G08 (RTM SEC-003).

6. **G08 is split with precise names.** Sub-gate wording is now:
   `GREEN (domain-core authorization-policy enforcement) / RED (service-layer
   trust root: authenticated identity binding AND authoritative aggregate
   provenance)`. The GREEN half may only ever claim policy enforcement.

7. **The trust boundary is documented by executable regressions, not
   defended by code.** `tests/test_trust_boundary.py` reproduces the
   reviewer's exact F34 attacks (entitlement reassignment on the reference
   context; a malicious structural port) and the F37 relabelling scenario,
   asserting that they SUCCEED, with the trust-boundary rationale in the test
   itself. These tests document the contract; any future change that makes
   them fail signals that someone is again trying to turn a Python object
   into a security identity, and must be reviewed against this ADR.

## Alternatives considered

- *Harden `StaticAuthorizationContext` (double underscore names,
  `__setattr__` overrides, proxies).* Rejected: F30 proved in-process
  integrity cannot be delivered, and a "mostly tamper-resistant" object
  invites exactly the overclaim this ADR removes.
- *Constrain `AuthorizationPort` to a nominal ABC with a registration
  scheme.* Rejected: registration is equally forgeable in-process and would
  imply a guarantee it cannot give, while breaking legitimate DI.
- *Remove `StaticAuthorizationContext` entirely.* Rejected: the reference
  implementation is needed to test deny/allow semantics and to state the
  contract; the fix is honest documentation, not deletion.

## Consequences

- The domain core makes a smaller, true claim; the missing halves
  (authenticated identity, aggregate provenance) are named, RED, and
  service-layer scoped.
- RTM SaaS-002 / SEC-001 / SEC-002 rewritten; SEC-003 added (provenance).
- No behavioural change to any protected operation; version 0.6.1
  (documentation/contract clarification only).
- Reversal path: none anticipated — a future service layer implements the
  trust root; it does not move it back into the domain core.
