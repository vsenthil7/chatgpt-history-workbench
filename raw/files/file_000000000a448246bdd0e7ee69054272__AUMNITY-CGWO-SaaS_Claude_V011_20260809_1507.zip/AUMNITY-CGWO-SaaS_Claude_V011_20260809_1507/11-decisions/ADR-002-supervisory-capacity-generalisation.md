# ADR-002 — Supervisory/review capacity generalisation

Status: ACCEPTED
Date: 2026-08-08
Supersedes: origin-specific vocabulary "TEE Capacity", "founder capacity", "body/mind capacity" in reusable artefacts.

## Context
Baseline model 8 ("Portfolio/Founder/TEE Capacity Model"), ubiquitous-language terms "Supervision Load" and "TEE Capacity", and decision D006 encode a real constraint: work consumes not only executor time but supervisory decision/review capacity, and unbounded supervision demand is a genuine planning gate. The vocabulary, however, is origin-specific ("founder", "TEE", "body/mind") and unsuitable for tenant-neutral SaaS.

## Decision
1. The generic concept is **capacity types**. The reusable domain models at least `EXECUTION` and `SUPERVISORY` capacity; tenants may configure additional types by policy.
2. Supervisory capacity is a first-class, allocatable, exhaustible capacity like execution capacity: plans that exceed available supervisory/review capacity raise the same conflict signals as execution overruns.
3. "Founder", "TEE" and "body/mind" survive only in the preserved baseline and in this ADR. Pilot tenants may label their capacity types however they wish through tenant configuration.

## Consequences
- `CapacityType` enum in the domain core with `EXECUTION` and `SUPERVISORY` (implemented this release).
- Tenant-configurable capacity-type extension is declared, not yet implemented.
- Consistency validator forbids the superseded vocabulary outside `10-baseline/` and `11-decisions/`.
