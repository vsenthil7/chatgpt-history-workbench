# ADR-011 — Verification integrity: strict mutation gate and structured error identity

Status: ACCEPTED
Date: 2026-08-08
Responds to: independent review of V003, findings F17, F18 and F19.

## Context
The V003 mutation runner returned GREEN based solely on "no unaccepted survivors", so a run with tool failures, unparseable output, timeouts, or untested/no-tests mutants could pass silently (F17). Its mutmut configuration used deprecated key names (F18). And V003 killed 79 string-literal mutants by anchoring exact human prose, effectively making punctuation part of the domain API (F19).

## Decisions
1. **The mutation gate demands an explicitly complete, successful run.** The decision logic lives in `scripts/mutation_gate.py` as pure, unit-tested functions (`tests/test_mutation_gate.py`, including the reviewer's false-green scenarios as fixtures). GREEN requires: zero exit codes from both mutmut commands; a parseable final tally covering every category; a positive total that reconciles exactly with the category sum; zero timeout/suspicious/skipped/no-tests mutants (no policy currently permits any); survivor listing reconciling with the tally; and zero survivors without a justification entry in the human-reviewed `scripts/mutation_acceptance.json`. Any anomaly is an explicit failure reason, never a silent zero.
2. **Mutmut configuration uses the pinned version's current key names** (`source_paths`, `pytest_add_cli_args_test_selection`); the deprecation warnings are gone from the packaged raw output.
3. **Error identity is structured, prose is data** (F19): every domain error carries a stable exception type, a stable `code`, and structured `fields`; human-readable messages are rendered from the module-level `MESSAGES` registry and may evolve without breaking tests. Tests anchor type + code + fields (see the guard-site matrix), not wording. Message templates and field-name identifiers live at module level by design: behaviour stays inside functions where the mutation harness exercises it, diagnostic data is data.

## Consequences
- A false-green mutation result now requires defeating a unit-tested gate, not just an empty survivors list.
- Mutation score reflects behaviour and structured error identity; wording changes are free.
- One genuinely equivalent mutant (`int(s, 10)` vs `int(s)`) was eliminated by removing the redundant argument rather than via the acceptance list, which remains empty.
