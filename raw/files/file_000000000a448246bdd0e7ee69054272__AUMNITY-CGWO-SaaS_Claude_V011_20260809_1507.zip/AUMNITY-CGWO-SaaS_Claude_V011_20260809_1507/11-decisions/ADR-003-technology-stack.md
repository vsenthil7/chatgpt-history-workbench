# ADR-003 — Technology stack for the CGWO domain core

Status: PROPOSED (recommendation implemented as reversible reference; awaiting confirmation or counter-decision)
Date: 2026-08-08

## Context
No starter or baseline document declares a language, framework, persistence or test toolchain. The quality gates (100% line+branch coverage G04, mutation testing G07, architecture guards G06) require concrete tooling. Stopping the release on this question was rejected; instead the decision is recorded here with alternatives and a recommendation, and the build proceeds on the recommendation in a reversible way.

## Alternatives
| Option | Toolchain | For | Against |
|---|---|---|---|
| A. Python 3.12 | pytest, pytest-cov (branch), mutmut, ruff | Starter validation tooling is already Python; fastest domain modelling; mature coverage/mutation tools; strong typing via dataclasses+mypy | Weaker static guarantees than compiled options; async web layer decisions deferred |
| B. TypeScript/Node | vitest, c8, Stryker | One language across API+web UI later; strong ecosystem | No existing TS in repo; domain purity harder to guard; toolchain heavier in this environment |
| C. Kotlin/JVM | JUnit5, JaCoCo, Pitest | Strong typing, mature enterprise ops | Slowest iteration for an incubating architecture; no existing JVM assets |

## Recommendation and interim decision
Adopt **Option A (Python 3.12)** for the domain core and validation tooling. The domain core in this release is written to be a **portable specification**: pure standard-library code, immutable value objects, explicit state-transition tables, no framework, no I/O — so a later switch re-implements ~300 lines against an already-tested behavioural spec rather than discarding architecture.

## Consequences
- G04 coverage evidence is produced with pytest-cov (line+branch).
- G07 mutation tooling (mutmut) is declared but deferred to the next release (see gate status); the gate stays RED.
- Persistence, API framework and messaging are **explicitly undecided** and require follow-up ADRs before any I/O code is written.
- If Option A is rejected, this ADR is superseded and the state-transition tables in `src/cgwo_core/` become the normative spec for the replacement implementation.
