# ADR-013 — Canonical object boundaries and strict wire grammar

Status: ACCEPTED — SECURITY PREMISE SUPERSEDED by ADR-014 (V007)
Date: 2026-08-09
Responds to: independent review of V005, findings F27, F28 and F29.
Extends: ADR-012 (canonical primitives) from primitive fields to domain objects and wire decoders.

## Context
ADR-012 canonicalised primitive *fields* with exact-type checks, but the same trust-boundary weakness survived one object layer up. The V005 review demonstrated: a `TenantContext` subclass overriding `__getattribute__` to report `tenant_id == "victim"` while storing `"attacker"` passed `assert_same_tenant`'s `isinstance` check — a working cross-tenant bypass (F27); `assert_same_tenant` never exact-checked `owner_tenant_id`, so a hostile-equality `str` owner was accepted, and a `CapacityWindow` subclass lying about tenant and `available_minutes` was accepted into `CapacityAllocation` (F28); and the wire parsers delegated to `date.fromisoformat` (which accepts basic and week-date forms outside the documented `YYYY-MM-DD` grammar) and to `int()` (which raises a raw `ValueError` above CPython's ~4300-digit conversion limit) (F29).

## Decisions
1. **Domain objects that cross trust boundaries must be canonical**, enforced with `require_exact_instance` (`type(value) is ExpectedClass`): no subclasses, so `__getattribute__` cannot lie about a security- or invariant-bearing attribute. Applied to every `TenantContext` consumed by `assert_same_tenant` and every `CapacityWindow` consumed by `CapacityAllocation` and `AvailabilityDeclaration`. A genuine instance's attributes are only then safe to read.
2. **Both operands of the isolation check are canonicalised**: `assert_same_tenant` exact-checks `ctx` (F27) and requires an exact `str` `owner_tenant_id` (F28) before comparing. A hostile-equality owner can no longer force a match.
3. **Wire grammars are enforced explicitly, never delegated to permissive builtins** (F29): dates must match `WIRE_DATE_GRAMMAR` (`YYYY-MM-DD`) and then pass calendar validation via `date(...)`; integers must match `WIRE_INT_GRAMMAR` (`[0-9]+`) AND stay within `WIRE_INT_MAX_DIGITS` (4300) so the CPython conversion-limit `ValueError` is pre-empted with a controlled `ContractViolationError`. ISO week/basic/ordinal date forms are outside `cgwo-consumer-v1`.

## Consequences
- The demonstrated cross-tenant bypass is closed at the object layer: no lying context or window can enter the domain; the isolation comparison only ever runs on canonical operands.
- Regressions use the reviewer's exact attacks (`tests/test_adversarial_objects.py`); the guard-site matrix gains the owner-type row.
- RTM rows SEC-001 (canonical object boundaries), INT-006 (strict wire grammar) added; SaaS-002/DOM-010 evidence extended. Domain core version 0.5.0 (pre-1.0 breaking change: stricter accepted object types and wire grammar).
- Honest scope note: exact-type guards defeat Python-level subtype attacks. They do not, and cannot, defend against a caller that constructs a *genuine* canonical object with attacker-chosen field values; that is an authorisation concern for the (still absent) service layer, tracked under G08's RED service-layer half, not a domain-core guarantee.
