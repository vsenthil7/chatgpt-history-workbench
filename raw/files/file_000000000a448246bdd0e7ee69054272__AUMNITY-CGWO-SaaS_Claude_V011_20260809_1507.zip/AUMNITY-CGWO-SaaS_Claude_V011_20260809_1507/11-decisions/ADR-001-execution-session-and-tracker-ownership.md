# ADR-001 — Execution Session vs external tracker/timesheet ownership

Status: ACCEPTED
Date: 2026-08-08
Supersedes: baseline `10-baseline/.../01-product/02-Scope-and-Module-Boundary.md` in-scope word "tracker" as an owned system.

## Context
The starter contract (PROJECT-START, PRODUCT-BOUNDARY) scopes CGWO to "tracker/timesheet **domain bridges**". The preserved baseline scope lists "tracker; timesheet bridge" as owned, and Phase 0 references an IPBS workbook with a linked tracker/timesheet. These conflict: does CGWO own a tracker product, or only bridge to trackers?

## Decision
1. CGWO owns the **Execution Session** domain record: start/pause/resume/stop history bound to a Plan Item, plus the Plan Item and Capacity Allocation state machines. This is domain state, not a tracker UI product.
2. External trackers and timesheet systems remain **systems of record outside CGWO**, integrated through bridge adapters (planned-work push, actuals pull, `TimeRecorded` ingestion).
3. The IPBS workbook tracker/timesheet is **pilot evidence only** (Phase 0 of the preserved baseline). No workbook structure, column, or ID scheme may appear in reusable code.

## Consequences
- Canonical scope wording (ADR-004) says "execution session recording and tracker/timesheet domain bridges".
- Bridge adapter contracts are declared in `02-architecture/INTEGRATION-BOUNDARIES.md`.
- The starter contract prevails over the baseline where they conflict, per PROJECT-START baseline-preservation rule.

## Alternatives rejected
- CGWO ships its own tracker product: duplicates widely available tools, violates D003 (no forced replacement of existing systems).
- CGWO holds no execution state at all: makes adaptive replanning and plan-vs-actual impossible without round-tripping external systems.
