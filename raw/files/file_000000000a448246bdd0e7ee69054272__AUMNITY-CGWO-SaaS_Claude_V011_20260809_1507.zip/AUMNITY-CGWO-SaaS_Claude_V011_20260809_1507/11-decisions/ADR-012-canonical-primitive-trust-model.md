# ADR-012 — Canonical primitive trust model

Status: ACCEPTED
Date: 2026-08-09
Responds to: independent review of V004, findings F20, F21, F22, F23, F24 and F25.
Amends/supersedes: the `isinstance`-based guard rule and the "datetime accepted as date" clause of ADR-010; narrows ADR-010's lifecycle-origin claim (F25).

## Context
The V004 review demonstrated real bypasses against the `isinstance`-based runtime guards using ordinary Python subtype behaviour: a `str` subclass overriding `__eq__` defeated the cross-tenant check (a working SaaS isolation bypass, F20); a `str` subclass overriding `strip()` smuggled blank identifiers in (F21); an `int` subclass overriding comparisons constructed negative capacity and negative allocations (F22); and `datetime.datetime` — a `date` subclass — passed date guards, producing an uncontrolled `TypeError` on mixed comparison and smuggling time-of-day semantics into date-only planning fields (F23). `isinstance` also consults a spoofable `__class__`. Separately, the wire-integer grammar was implicitly "whatever Python's `int()` accepts" (F24).

## Decisions
1. **The domain stores only canonical primitives.** Guards use exact type checks — `type(value) is str / int / date / <EnumClass>` — which read the real type slot: no subclasses, no spoofed `__class__`, no hostile operator overrides, `bool` excluded from `int` by construction, `datetime.datetime` excluded from `date` by design. If CGWO ever needs intra-day windows, that is a deliberate separate model, never inheritance smuggling.
2. **Canonicalisation happens only at explicit wire boundaries.** `from_wire`/`parse_wire_*` decode supported wire representations and emit canonical values; once inside the domain, hostile subtype behaviour cannot exist.
3. **Wire-integer grammar is explicit** (F24): `cgwo-consumer-v1` accepts an exact `int` or an exact `str` matching `[0-9]+` (ASCII decimal digits; no sign, whitespace, Unicode digits, separators or decimals). Python's permissive `int()` parsing is not the contract. Chosen for deterministic cross-language provider compatibility.
4. **Lifecycle origin is convention, not machine enforcement** (F25): `create()`/`rehydrate()` name intent and share one fully-validated construction path; direct dataclass construction remains public and equally validated. RTM DOM-009 claims exactly that — validated construction ENFORCED, origin semantics CONVENTION under review governance. A machine-enforced construction boundary is a possible future ADR if persistence work needs it.
5. Enum member exactness: Python enums with members cannot be subclassed (tested), and the exact-type rule additionally rejects spoofed-`__class__` impostors.

## Consequences
- The reviewer's attack classes are named regressions in `tests/test_adversarial_subtypes.py`; the demonstrated cross-tenant bypass is impossible because no hostile identifier can construct a `TenantContext` at all.
- RTM rows DOM-010 (canonical primitives), DOM-011 (exact-date semantics), INT-005 (wire grammar) added; DOM-009 reworded; SaaS-002/DOM-005/DOM-008 evidence extended with the subtype suite.
- Domain core version 0.4.0 (pre-1.0 breaking change: stricter accepted types).
