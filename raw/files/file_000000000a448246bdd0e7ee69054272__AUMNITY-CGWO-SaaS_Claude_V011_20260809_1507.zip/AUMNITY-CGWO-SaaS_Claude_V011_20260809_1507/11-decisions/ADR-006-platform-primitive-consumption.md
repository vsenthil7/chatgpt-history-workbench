# ADR-006 — AUMNITY Work Platform primitive consumption

Status: ACCEPTED
Date: 2026-08-08

## Context
The baseline reuse list (Actor, Work Object, Capability, Evidence, Identity, Organisation, Policy, Workflow, Audit, Integration, Notification) and the starter prohibitions both place universal primitives with the AUMNITY Work Platform. The build contract must state concretely what "consume, don't duplicate" means in code.

## Decision
1. CGWO stores **opaque references** (IDs) to Platform-owned primitives, never their internal structure: `resource_ref` → Platform Actor, `work_object_ref` → Platform Work Object, `capability_ref` → Platform Capability, `tenant_id`/`organisation_id` → Platform Organisation/Tenancy.
2. Every protected CGWO operation carries an explicit `TenantContext`; tenancy semantics are Platform-defined, CGWO enforces isolation at its own boundaries (SaaS-002).
3. CGWO defines no user, actor, organisation, identity, capability-taxonomy or generic work-object entity. Capability **demand** (what a piece of work requires) is CGWO's; the capability taxonomy is the Platform's.
4. Platform contracts are consumed as published interfaces/events; CGWO never reads Platform persistence.

## Consequences
- Domain core reference fields are plain identifier strings validated for presence, not shape.
- The architecture guard test forbids the domain core from importing anything except the standard library and itself.
- `02-architecture/PLATFORM-PRIMITIVES-CONTRACT.md` declares the required contract surface.
