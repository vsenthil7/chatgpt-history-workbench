# ADR-005 — Recruitment/training integration boundary

Status: ACCEPTED
Date: 2026-08-08

## Context
The baseline charter says CGWO should "generate recruitment/training work when the resource pool is insufficient", while the not-owned list excludes "general recruitment applicant tracking". Read casually, the charter could license ATS/LMS features inside CGWO.

## Decision
CGWO's obligation ends at **detecting the gap and raising the need**: `CapabilityGapDetected`, `TrainingNeedRaised`, `RecruitmentNeedRaised` events, optionally materialised as Work Objects via the AUMNITY Work Platform. Applicant tracking, learning management and certification systems remain external, integrated through the adapter categories in `INTEGRATION-BOUNDARIES.md`. Observed capability changes flow back as `CapabilityObserved` against Platform-owned Capability records.

## Consequences
- No ATS/LMS entities in the CGWO domain model, ever, without superseding this ADR.
