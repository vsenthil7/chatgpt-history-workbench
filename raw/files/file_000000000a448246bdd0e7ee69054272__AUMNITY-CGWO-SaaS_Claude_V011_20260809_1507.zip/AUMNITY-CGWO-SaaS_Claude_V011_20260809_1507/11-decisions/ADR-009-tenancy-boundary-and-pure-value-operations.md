# ADR-009 — Isolation boundary and protected vs pure operations

Status: ACCEPTED
Date: 2026-08-08
Responds to: independent review of V002, findings F05 and F06.

## Context
V002's RTM claimed "tenant/org context ENFORCED" while only tenant-ID equality was enforced and `organisation_id` was unvalidated, unused metadata. Separately, `CapacityWindow.overlaps()` takes no tenant context, which looked like a breach of "protected operations carry explicit tenant context".

## Decision
1. **`tenant_id` is THE enforced isolation boundary** in the domain core. `organisation_id` is an optional Platform-owned sub-scope reference: validated for well-formedness (non-blank when provided), carried as metadata, **not** an independently enforced security boundary. If organisation-level isolation becomes security-significant, that is a superseding ADR plus modelling and tests — not a silent claim.
2. **Operation classes are explicit** (documented in `02-architecture/MODULARITY-AND-REUSE.md`):
   - *Protected operations* mutate aggregates or reveal aggregate data across a boundary; they take `TenantContext` and call `assert_same_tenant` (e.g. `transition`, `consume`, `guarded_window`).
   - *Pure value calculations* operate on already-authorised objects with no context parameter (e.g. `windows_overlap`, value-object construction). Cross-tenant comparisons in pure functions return domain facts (windows in different tenants never compete) and are not access-control decisions.
3. New public domain functions must be classified as one or the other at review time.

## Consequences
- RTM SaaS-002 language corrected to claim exactly what is enforced; organisation sub-scope tracked as a separate DECLARED row.
- Blank-but-present `organisation_id` is rejected (tested).
