# ADR-004 — Canonical scope wording (single source of truth)

Status: ACCEPTED
Date: 2026-08-08

## Context
The CGWO boundary is stated in at least three different wordings: the project page baseline, PROJECT-START/PRODUCT-BOUNDARY, and the preserved baseline scope document. They are unions rather than contradictions (after ADR-001), but per the one-source-of-truth rule the boundary must be written once and referenced elsewhere.

## Decision
The canonical boundary lives in `01-product/CANONICAL-SCOPE.md` under the ID **CGWO-SCOPE-1**. Every other artefact references the ID instead of restating the boundary in different words. The consistency validator enforces that the canonical sentence exists exactly where declared and that documents outside the baseline reference the ID.

## Consequences
- PROJECT-START and PRODUCT-BOUNDARY updated to reference CGWO-SCOPE-1.
- The preserved baseline is historical evidence and is exempt.
