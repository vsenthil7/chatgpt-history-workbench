# ADR-007 — Allocation state/data invariants and window governance

Status: ACCEPTED
Date: 2026-08-08
Responds to: independent review of V002, findings F01 and F02.
Amends: the V002 allocation transition table (previously permitted lifecycle jumps into quantity-bearing states).

## Context
V002's `CapacityAllocation` enforced only base invariants, so impossible objects were directly constructible (RESERVED with consumption; CONSUMED at zero; OVERRUN under the limit; PROPOSED with consumption), bypassing the state machine. Nothing bound an allocation to its window's capacity, contradicting "capacity-governed".

## Decision
1. **State-dependent invariants are enforced on every construction path** (constructor, `dataclasses.replace`, transitions): PROPOSED/RESERVED require `consumed == 0`; CONSUMING requires `0 <= consumed < allocated`; PARTIALLY_CONSUMED requires `0 < consumed < allocated`; CONSUMED requires `consumed == allocated`; OVERRUN requires `consumed > allocated`; RELEASED preserves its final consumption history unchanged (including over-consumption when released from OVERRUN).
2. **Quantity-bearing states are reachable only through `consume_allocation`.** The lifecycle transition table is reduced to data-consistent moves: PROPOSED→{RESERVED, RELEASED}; RESERVED→{CONSUMING, RELEASED}; CONSUMING→{PARTIALLY_CONSUMED (pause with recorded partial), RELEASED}; PARTIALLY_CONSUMED→{CONSUMING (resume), RELEASED}; OVERRUN→{RELEASED}; CONSUMED and RELEASED are terminal. Pausing with zero recorded consumption is invalid; release or keep consuming.
3. **A single allocation can never exceed its window**: `allocated_minutes <= window.available_minutes`.
4. **Aggregate capacity governance remains DECLARED, not implemented**: nothing yet prevents multiple allocations from jointly over-committing one window/pool. That model (working name `CapacityLedger`, RTM DOM-006) is explicit future work, and no CGWO artefact may claim aggregate/cross-allocation conflict detection until it exists. A regression test guards the honesty of this deferral.

## Consequences
- Direct-construction bypass is impossible; negative construction tests cover every inconsistent state/quantity combination.
- The V002→V003 transition-table change is a domain-core (0.x) breaking change, permitted pre-1.0 and recorded here.
