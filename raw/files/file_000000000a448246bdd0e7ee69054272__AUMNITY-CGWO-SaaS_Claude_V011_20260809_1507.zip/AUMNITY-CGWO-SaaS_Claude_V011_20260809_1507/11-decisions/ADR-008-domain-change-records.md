# ADR-008 — Typed domain-change records

Status: ACCEPTED
Date: 2026-08-08
Responds to: independent review of V002, findings F03 and F04.

## Context
V002 validated replanning change reasons and then discarded them, and represented domain events as bare strings — neither auditable nor useful for review/learning/plan-vs-actual analysis.

## Decision
1. Every guarded transition returns a **typed, immutable domain-change record**: `PlanItemChange` (event type, tenant, work-object reference, previous/new state, normalised change reason, resulting item) and `AllocationChange` (event type, tenant, plan-item and resource references, previous/new state, allocated minutes, consumed-before/after, resulting allocation).
2. Change reasons are normalised (trimmed; empty → None) and preserved on the record; tests assert the exact supplied reason survives.
3. These records are **pure domain data** — no messaging infrastructure, no serialisation format, no event bus. Persistence/dispatch is future work behind contracts.
4. **Deliberately excluded for now**: occurred-at timestamps, acting identity, correlation/causation IDs. They require clock and identity contracts (Platform-owned) and would break determinism if improvised; they are DECLARED fields for the event-persistence slice.

## Consequences
- Audit/review/learning slices can consume complete transition facts.
- Event-name constants remain (asserted by tests) as the `event_type` vocabulary aligned with the baseline event catalogue.
