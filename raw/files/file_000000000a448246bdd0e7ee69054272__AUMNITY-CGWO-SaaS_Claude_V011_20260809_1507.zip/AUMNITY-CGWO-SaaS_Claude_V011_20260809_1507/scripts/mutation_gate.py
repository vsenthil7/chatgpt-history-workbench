"""Mutation-gate decision logic (ADR-011, review finding F17).

Pure, unit-tested functions deciding whether a mutation run may be GREEN.
GREEN requires an explicitly COMPLETE, SUCCESSFUL run — not merely the
absence of unaccepted survivors. Any anomaly (tool failure, unparseable
output, uncounted mutants, timeouts, suspicious results, skipped or
untested mutants, tally/listing disagreement) fails the gate loudly rather
than silently becoming zeros.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

#: Emoji vocabulary of the pinned mutmut version's progress line.
EMOJI_KEYS = {
    "🎉": "killed",
    "🙁": "survived",
    "⏰": "timeout",
    "🤔": "suspicious",
    "🔇": "skipped",
    "🫥": "no_tests",
}
#: Categories that are fatal when non-zero (no policy currently allows them).
FATAL_CATEGORIES = ("timeout", "suspicious", "skipped", "no_tests")


@dataclass
class GateDecision:
    ok: bool
    reasons: list[str] = field(default_factory=list)
    tally: dict[str, int] = field(default_factory=dict)
    total_expected: int | None = None
    survivors: list[str] = field(default_factory=list)
    accepted: dict[str, str] = field(default_factory=dict)
    unresolved: list[str] = field(default_factory=list)


def parse_tally(run_output: str) -> dict[str, int] | None:
    """Parse the final emoji tally; None when absent/unparseable."""
    pairs = re.findall(r"(🎉|🙁|⏰|🤔|🔇|🫥)\s*(\d+)", run_output)
    if not pairs:
        return None
    tally: dict[str, int] = {}
    for emoji, count in pairs:  # later occurrences win: final progress line
        tally[EMOJI_KEYS[emoji]] = int(count)
    if set(tally) != set(EMOJI_KEYS.values()):
        return None
    return tally


def parse_total(run_output: str) -> int | None:
    """Parse the final N/M progress marker's M; None when absent."""
    markers = re.findall(r"(\d+)/(\d+)", run_output)
    if not markers:
        return None
    return int(markers[-1][1])


def parse_survivors(results_output: str) -> list[str]:
    return re.findall(r"^\s*(\S+): survived$", results_output, re.MULTILINE)


def evaluate(
    run_returncode: int,
    results_returncode: int,
    run_output: str,
    results_output: str,
    acceptance: dict[str, str],
) -> GateDecision:
    """Decide the gate. Every anomaly is an explicit failure reason."""
    decision = GateDecision(ok=False)
    if run_returncode != 0:
        decision.reasons.append(f"mutmut run exited {run_returncode}")
    if results_returncode != 0:
        decision.reasons.append(f"mutmut results exited {results_returncode}")

    tally = parse_tally(run_output)
    if tally is None:
        decision.reasons.append("mutation tally missing or unparseable from run output")
        return decision
    decision.tally = tally

    total = parse_total(run_output)
    decision.total_expected = total
    if total is None:
        decision.reasons.append("total mutant count missing from run output")
    elif total <= 0:
        decision.reasons.append("total mutant count is not > 0")
    elif sum(tally.values()) != total:
        decision.reasons.append(
            f"tally categories sum to {sum(tally.values())} but total is {total}"
        )

    for category in FATAL_CATEGORIES:
        if tally[category] != 0:
            decision.reasons.append(
                f"{category} mutants present ({tally[category]}) with no governing policy"
            )

    survivors = parse_survivors(results_output)
    decision.survivors = survivors
    if len(survivors) != tally["survived"]:
        decision.reasons.append(
            f"results listing shows {len(survivors)} survivors but tally says {tally['survived']}"
        )
    decision.accepted = {s: acceptance[s] for s in survivors if s in acceptance}
    decision.unresolved = [s for s in survivors if s not in acceptance]
    if decision.unresolved:
        decision.reasons.append(
            f"unresolved survivors without acceptance justification: {len(decision.unresolved)}"
        )

    decision.ok = not decision.reasons
    return decision
