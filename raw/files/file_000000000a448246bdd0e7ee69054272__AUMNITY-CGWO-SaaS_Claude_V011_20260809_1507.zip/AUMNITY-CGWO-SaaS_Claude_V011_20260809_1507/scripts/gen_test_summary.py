#!/usr/bin/env python3
"""Generate evidence/test-summary.json from pytest/coverage outputs (DOC-001)."""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
out = (ROOT / "evidence/pytest-output.txt").read_text(encoding="utf-8")
passed_match = re.search(r"(\d+) passed", out)
if passed_match is None:
    raise SystemExit("pytest output does not record a pass count")
failed_match = re.search(r"(\d+) failed", out)
cov = json.loads((ROOT / "evidence/coverage.json").read_text(encoding="utf-8"))
totals = cov["totals"]
summary = {
    "generated_by": "scripts/gen_test_summary.py from evidence/pytest-output.txt "
    "and evidence/coverage.json",
    "tests_passed": int(passed_match.group(1)),
    "tests_failed": int(failed_match.group(1)) if failed_match else 0,
    "coverage_line_percent": round(100.0 * totals["covered_lines"] / totals["num_statements"], 2),
    "coverage_branch_percent": round(
        100.0 * totals["covered_branches"] / totals["num_branches"], 2
    ),
    "statements": totals["num_statements"],
    "branches": totals["num_branches"],
    "missing_lines": totals["missing_lines"],
    "missing_branches": totals["num_branches"] - totals["covered_branches"],
}
(ROOT / "evidence/test-summary.json").write_text(
    json.dumps(summary, indent=1) + "\n", encoding="utf-8"
)
print(json.dumps(summary, indent=1))
