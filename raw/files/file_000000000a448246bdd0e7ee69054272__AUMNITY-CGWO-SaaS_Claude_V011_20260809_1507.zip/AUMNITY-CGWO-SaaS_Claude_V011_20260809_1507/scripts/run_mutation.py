#!/usr/bin/env python3
"""Run mutation testing reproducibly and generate machine-readable evidence.

Review findings F09/F17: captures exact tool version, command, raw output and
per-survivor classification, then delegates the GREEN/RED decision to the
unit-tested strict gate in scripts/mutation_gate.py. Survivors are only
'accepted' when listed with justification in scripts/mutation_acceptance.json
(human-reviewed); any anomaly at all fails the gate.

Usage: python3 scripts/run_mutation.py
Writes: evidence/mutation-raw-output.txt, evidence/mutation-results.txt,
        evidence/mutation-summary.json
Exit:   0 only for an explicitly complete, fully successful run.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from importlib.metadata import version
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mutation_gate import evaluate

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence"
ACCEPTANCE_FILE = ROOT / "scripts" / "mutation_acceptance.json"
COMMAND = [sys.executable, "-m", "mutmut", "run"]

shutil.rmtree(ROOT / "mutants", ignore_errors=True)
run = subprocess.run(COMMAND, cwd=ROOT, capture_output=True, text=True, check=False)
run_output = f"{run.stdout}\n{run.stderr}"
(EVIDENCE / "mutation-raw-output.txt").write_text(
    f"$ {' '.join(COMMAND)}\n\n{run_output}", encoding="utf-8"
)
results = subprocess.run(
    [sys.executable, "-m", "mutmut", "results"],
    cwd=ROOT,
    capture_output=True,
    text=True,
    check=False,
)
(EVIDENCE / "mutation-results.txt").write_text(results.stdout, encoding="utf-8")

acceptance: dict[str, str] = json.loads(ACCEPTANCE_FILE.read_text(encoding="utf-8"))
decision = evaluate(
    run_returncode=run.returncode,
    results_returncode=results.returncode,
    run_output=run_output,
    results_output=results.stdout,
    acceptance=acceptance,
)

summary = {
    "tool": "mutmut",
    "tool_version": version("mutmut"),
    "command": " ".join(COMMAND),
    "config": "setup.cfg [mutmut] (source_paths / pytest test-selection args)",
    "regenerate_with": "python3 scripts/run_mutation.py",
    "raw_output": "evidence/mutation-raw-output.txt",
    "results_listing": "evidence/mutation-results.txt",
    "gate_module": "scripts/mutation_gate.py (unit tested in tests/test_mutation_gate.py)",
    "run_returncode": run.returncode,
    "results_returncode": results.returncode,
    "total_expected": decision.total_expected,
    "tally": decision.tally,
    "accepted_survivors": decision.accepted,
    "unresolved_survivors": decision.unresolved,
    "gate_ok": decision.ok,
    "gate_reasons": decision.reasons,
    "gate_rule": "GREEN requires an explicitly complete successful run: zero exit "
    "codes, parseable tally reconciling to a positive total, zero "
    "timeout/suspicious/skipped/no-tests mutants, and zero unaccepted survivors",
}
(EVIDENCE / "mutation-summary.json").write_text(
    json.dumps(summary, indent=1) + "\n", encoding="utf-8"
)
print(json.dumps({"tally": decision.tally, "gate_ok": decision.ok}, indent=1))
for reason in decision.reasons:
    print("GATE FAIL:", reason)
sys.exit(0 if decision.ok else 1)
