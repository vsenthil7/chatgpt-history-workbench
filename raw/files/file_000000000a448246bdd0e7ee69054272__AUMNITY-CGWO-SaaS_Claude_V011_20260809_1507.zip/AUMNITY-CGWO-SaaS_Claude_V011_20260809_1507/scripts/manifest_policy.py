"""Canonical manifest inclusion/exclusion policy (F43/F46 — single source of truth).

Both `gen_manifest.py` (which WRITES the manifest) and `validate_consistency.py`
(which CHECKS it) import `managed_files` from here, so the set of files that
"should be in the manifest" is defined in exactly one place and the two tools
cannot drift. The V009 review (F43) showed hash-only validation is one-way: it
proved every LISTED file still hashed correctly but never proved every SHIPPED
managed file was LISTED, so an unmanifested `EXTRA.txt` passed. Closing the set
requires both tools to agree on membership, which is what this module provides.

EXCLUSIONS ARE AN EXPLICIT ALLOWLIST (V010 review, F46). The V010 policy
generically excluded EVERY path containing a dot-prefixed component
(`part.startswith(".")`), which meant an attacker could sidestep the closed-set
integrity boundary entirely just by choosing a hidden pathname: an unmanifested
`.evil/payload.py` was invisible to `is_managed()` and consistency validation
PASSED. A release-package integrity control must not let the excluded universe
be chosen by the adversary. Only the specific, known, named build/cache
directories and generated files below are unmanaged; ANY other path — hidden or
not — is managed and must therefore appear in the manifest or fail validation.
If a hidden directory is ever intentionally shipped in future, it must be named
here explicitly (a reviewed policy change), never admitted by a generic rule.
"""

from __future__ import annotations

from pathlib import Path

# Directories whose entire subtree is never managed. EXPLICIT NAMES ONLY (F46):
# known build/test/tool caches and local development directories. There is
# deliberately NO generic dot-directory rule.
EXCLUDE_DIRS = {
    "mutants",  # mutmut working tree
    "__pycache__",  # CPython bytecode cache
    ".pytest_cache",  # pytest cache
    ".ruff_cache",  # ruff cache
    ".mypy_cache",  # mypy cache
    ".mutmut-cache",  # legacy mutmut cache name
    ".hypothesis",  # hypothesis example database
    ".git",  # local VCS metadata (never shipped)
    ".venv",  # local virtual environment (never shipped)
}
# Files excluded by basename anywhere in the tree. The outer manifest cannot
# hash itself; a nested baseline manifest is the baseline's own concern; the
# coverage db is a build artifact; .DS_Store is macOS filesystem litter.
EXCLUDE_FILES = {"PACKAGE-MANIFEST.json", ".coverage", ".DS_Store"}


def is_managed(rel: Path) -> bool:
    """Return True if the repo-relative path should appear in the manifest."""
    if any(part in EXCLUDE_DIRS for part in rel.parts):
        return False
    return rel.name not in EXCLUDE_FILES


def managed_files(root: Path) -> list[str]:
    """The canonical sorted list of managed repo-relative POSIX paths."""
    managed: list[str] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if is_managed(rel):
            managed.append(rel.as_posix())
    return managed
