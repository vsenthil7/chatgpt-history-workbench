#!/usr/bin/env python3
"""Regenerate PACKAGE-MANIFEST.json with SHA-256 hashes.

The set of managed files comes from the shared canonical policy in
`manifest_policy.py`, which `validate_consistency.py` also uses, so the
generator and validator cannot drift (F43).
"""

from __future__ import annotations

import hashlib
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from manifest_policy import managed_files

ROOT = Path(__file__).resolve().parents[1]

files = []
for rel in managed_files(ROOT):
    path = ROOT / rel
    files.append(
        {
            "path": rel,
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
    )

manifest = {
    "schema": "aumnity-package-manifest/1",
    "project": "AUMNITY CGWO SaaS",
    "release": ROOT.name,
    "generated": datetime.now(UTC).isoformat(timespec="seconds"),
    "file_count": len(files),
    "files": files,
}
(ROOT / "PACKAGE-MANIFEST.json").write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
print(f"manifest written: {len(files)} files")
