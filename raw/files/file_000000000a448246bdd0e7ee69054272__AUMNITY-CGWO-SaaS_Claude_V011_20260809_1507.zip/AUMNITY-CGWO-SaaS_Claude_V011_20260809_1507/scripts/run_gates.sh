#!/usr/bin/env bash
# One-command executable-gate runner (review finding F08).
# Regenerates the machine-readable evidence under evidence/.
# Usage: bash scripts/run_gates.sh [--with-mutation]
set -euo pipefail
cd "$(dirname "$0")/.."

python3 scripts/validate_starter.py | tee evidence/starter-validator-output.txt
ruff check src tests scripts | tee evidence/ruff-output.txt
ruff format --check src tests scripts | tee -a evidence/ruff-output.txt
python3 -m mypy | tee evidence/mypy-output.txt
python3 -m pytest --cov=cgwo_core --cov-branch --cov-report=term-missing \
  --cov-report=json:evidence/coverage.json | tee evidence/pytest-output.txt
python3 scripts/gen_test_summary.py
if [[ "${1:-}" == "--with-mutation" ]]; then
  python3 scripts/run_mutation.py
fi
python3 scripts/validate_consistency.py --skip-manifest | tee evidence/consistency-output.txt
echo "gates complete; regenerate manifest last with: python3 scripts/gen_manifest.py"
