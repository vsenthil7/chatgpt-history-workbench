"""Creation vs rehydration semantics (ADR-010, review finding F16)."""

from datetime import date

import pytest

from cgwo_core.allocation import (
    INITIAL_STATE as ALLOCATION_INITIAL,
)
from cgwo_core.allocation import (
    AllocationInvariantError,
    AllocationState,
    CapacityAllocation,
)
from cgwo_core.capacity import CapacityWindow
from cgwo_core.plan_item import (
    INITIAL_STATE as PLAN_ITEM_INITIAL,
)
from cgwo_core.plan_item import (
    PlanItem,
    PlanItemState,
)

WINDOW = CapacityWindow(
    tenant_id="t1",
    resource_ref="actor-1",
    period_start=date(2026, 8, 1),
    period_end=date(2026, 8, 5),
    available_minutes=600,
)


def test_new_plan_items_always_start_in_the_initial_state():
    assert PLAN_ITEM_INITIAL is PlanItemState.CANDIDATE
    assert PlanItem.create("t1", "wo-1").state is PlanItemState.CANDIDATE


def test_new_allocations_always_start_proposed_and_unconsumed():
    assert ALLOCATION_INITIAL is AllocationState.PROPOSED
    created = CapacityAllocation.create("t1", WINDOW, "pi-1", 120)
    assert created.state is AllocationState.PROPOSED
    assert created.consumed_minutes == 0


def test_rehydration_restores_mid_lifecycle_state():
    item = PlanItem.rehydrate("t1", "wo-1", PlanItemState.COMPLETED)
    assert item.state is PlanItemState.COMPLETED
    alloc = CapacityAllocation.rehydrate(
        "t1", WINDOW, "pi-1", 120, 50, AllocationState.PARTIALLY_CONSUMED
    )
    assert alloc.state is AllocationState.PARTIALLY_CONSUMED


def test_rehydration_enforces_every_invariant():
    with pytest.raises(AllocationInvariantError):
        CapacityAllocation.rehydrate("t1", WINDOW, "pi-1", 120, 999, AllocationState.RESERVED)
    with pytest.raises(AllocationInvariantError):
        CapacityAllocation.rehydrate("t1", WINDOW, "pi-1", 120, 0, "RESERVED")  # type: ignore[arg-type]
