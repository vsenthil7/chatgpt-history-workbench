"""Executable documentation of the SaaS trust boundary (ADR-015; F34/F37).

The V007 review reproduced two attacks against the shipped package and one
provenance scenario. This module asserts that they behave EXACTLY as the
trust model requires — the F34 attacks SUCCEED because they occur inside the
trust boundary, and the F37 relabelling SUCCEEDS when the caller is genuinely
entitled — and states, in the tests themselves, why that is the correct
contract rather than a defect.

These are not "the attack is blocked" tests. They are boundary-definition
tests. If any of them starts to FAIL, it means someone has tried again to
turn an in-process Python object into a security identity (the exact mistake
ADR-014/ADR-015 exist to end), and the change must be reviewed against
ADR-015 before proceeding.

The domain core's real, tested guarantee — that a deny decision from the
supplied capability is honoured — lives in test_authz.py and the tenancy
suite. Here we pin the LIMITS of that guarantee.
"""

import pytest

from cgwo_core.authz import (
    AuthorizationError,
    AuthorizationPort,
    StaticAuthorizationContext,
    assert_authorized,
)
from cgwo_core.plan_item import PlanItem, PlanItemState
from cgwo_core.tenancy import TenantContext

# --- F34a: the reference context is an ordinary mutable object ---------------


def test_f34_reference_context_entitlements_are_reassignable_by_design():
    """ADR-015 D4: StaticAuthorizationContext is a reference, not a vault.

    The reviewer reassigned ``_entitlements`` with ordinary attribute
    assignment and gained entitlement. That works, and is DOCUMENTED to work:
    no in-process object can defend its own integrity against the process it
    runs in (the generalised F30 lesson). Trust comes from the service layer
    constructing and owning this object, never from Python mechanics.
    """
    authz = StaticAuthorizationContext("attacker", frozenset({"attacker"}))
    assert authz.is_entitled("victim") is False

    # Ordinary assignment — no object.__setattr__ trick required.
    authz._entitlements = frozenset({"victim"})

    # It now reports entitlement, and policy enforcement honours that report.
    assert authz.is_entitled("victim") is True
    assert_authorized(authz, "victim")  # no raise: the capability said yes

    item = PlanItem.create("victim", "wo")
    # The protected operation succeeds because the SUPPLIED capability allowed
    # it. This is authorization-policy enforcement doing exactly its job on a
    # capability the caller (here, an in-boundary test) chose to corrupt.
    item.transition(PlanItemState.WEEK_PLANNED, authz, TenantContext("victim"))


# --- F34b: AuthorizationPort is a structural DI contract, not a guard --------


class _MaliciousPort:
    """A hostile duck-typed AuthorizationPort that authorizes everything."""

    principal = "attacker"

    def is_entitled(self, tenant_id: str) -> bool:
        return True


def test_f34_structural_port_is_trusted_by_design():
    """ADR-015 D3: the port is a dependency-injection contract, not a boundary.

    A structurally-compatible object satisfies the Protocol and is trusted,
    exactly as a repository implementation would be. A hostile in-process
    implementation is INSIDE the trust boundary; defending against it in the
    domain core is impossible and is not attempted.
    """
    evil = _MaliciousPort()
    assert isinstance(evil, AuthorizationPort)

    # Policy enforcement consults it and honours its answer.
    assert_authorized(evil, "victim")

    item = PlanItem.create("victim", "wo")
    item.transition(PlanItemState.WEEK_PLANNED, evil, TenantContext("victim"))


def test_policy_enforcement_still_honours_a_deny():
    """The guarantee that DOES hold: a capability that denies is obeyed.

    This is the domain core's true, enforceable claim — the counterpart that
    makes the boundary meaningful. A well-behaved capability that reports "not
    entitled" causes a controlled AuthorizationError.
    """
    honest = StaticAuthorizationContext("p", frozenset({"tenant-a"}))
    with pytest.raises(AuthorizationError):
        assert_authorized(honest, "tenant-b")


# --- F37: aggregate provenance is a service-layer prerequisite ---------------


def test_f37_relabelled_aggregate_is_accepted_when_caller_is_entitled():
    """ADR-015 D5: the domain core does not establish aggregate provenance.

    A caller genuinely entitled to tenant B can construct an aggregate that
    claims tenant B and operate on it. The domain core authorizes against the
    aggregate's own label and CANNOT know whether the aggregate came from an
    authoritative tenant-scoped store. This is not privilege escalation (the
    caller really is entitled to B); it is the provenance gap the service
    layer must close (RTM SEC-003). Documented here so the boundary is
    explicit rather than implied.
    """
    authz_b = StaticAuthorizationContext("service-b", frozenset({"tenant-b"}))

    # An aggregate the caller simply asserts belongs to tenant-b. Nothing in
    # the domain package proves it was loaded from tenant-b's store.
    caller_asserted = PlanItem.create("tenant-b", "wo-from-nowhere")

    caller_asserted.transition(PlanItemState.WEEK_PLANNED, authz_b, TenantContext("tenant-b"))
    # Succeeds: entitlement to B + a B-labelled aggregate. Provenance is the
    # service layer's responsibility, by explicit design (F37).


def test_f37_entitlement_to_one_tenant_does_not_reach_another():
    """The provenance gap does NOT weaken cross-tenant policy enforcement.

    Being entitled to tenant B does not let the same principal act on a
    genuinely tenant-A-labelled aggregate: policy enforcement denies it.
    """
    authz_b = StaticAuthorizationContext("service-b", frozenset({"tenant-b"}))
    item_a = PlanItem.create("tenant-a", "wo-a")
    with pytest.raises(AuthorizationError):
        item_a.transition(PlanItemState.WEEK_PLANNED, authz_b, TenantContext("tenant-a"))
