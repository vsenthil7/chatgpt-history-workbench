from datetime import date
from datetime import date as _date_check  # noqa: F401  (used in wire tests)

import pytest

from cgwo_core.capacity import CapacityInvariantError, CapacityType
from cgwo_core.contracts import (
    CONSUMER_CONTRACT_VERSION,
    AvailabilityProposal,
    ContractViolationError,
    TimeRecordProposal,
)


def time_proposal(**kw):
    base = {
        "tenant_id": "t1",
        "resource_ref": "actor-1",
        "work_object_ref": "wo-1",
        "minutes": 30,
    }
    base.update(kw)
    return TimeRecordProposal(**base)


def test_contract_is_versioned():
    assert CONSUMER_CONTRACT_VERSION == "cgwo-consumer-v1"


def test_valid_time_record_proposal():
    proposal = time_proposal(narrative="stand-up follow-up work")
    assert proposal.minutes == 30
    assert proposal.source_system == "uraiflow"


@pytest.mark.parametrize(
    "kw",
    [
        {"tenant_id": " "},
        {"resource_ref": ""},
        {"work_object_ref": "  "},
        {"source_system": " "},
        {"minutes": 0},
        {"minutes": -10},
    ],
)
def test_time_record_proposal_violations_rejected(kw):
    with pytest.raises(ContractViolationError):
        time_proposal(**kw)


def availability_proposal(**kw):
    base = {
        "tenant_id": "t1",
        "resource_ref": "actor-1",
        "period_start": date(2026, 8, 1),
        "period_end": date(2026, 8, 5),
        "available_minutes": 300,
    }
    base.update(kw)
    return AvailabilityProposal(**base)


def test_valid_availability_proposal_converts_to_window():
    window = availability_proposal(capacity_type=CapacityType.SUPERVISORY).to_window()
    assert window.available_minutes == 300
    assert window.capacity_type is CapacityType.SUPERVISORY


def test_availability_proposal_rejects_windows_cgwo_would_reject():
    with pytest.raises(CapacityInvariantError):
        availability_proposal(period_end=date(2026, 7, 31))
    with pytest.raises(CapacityInvariantError):
        availability_proposal(available_minutes=-1)
    with pytest.raises(CapacityInvariantError):
        availability_proposal(tenant_id=" ")


def test_availability_proposal_requires_source_system():
    with pytest.raises(ContractViolationError):
        availability_proposal(source_system="  ")


# --- Wire decoding (ADR-010, review finding F15) -----------------------------
class TestFromWire:
    def test_valid_wire_values_decode_to_domain_enums(self):
        proposal = AvailabilityProposal.from_wire(
            tenant_id="t1",
            resource_ref="actor-1",
            period_start="2026-08-01",
            period_end="2026-08-05",
            available_minutes="300",
            capacity_type="SUPERVISORY",
        )
        assert proposal.capacity_type is CapacityType.SUPERVISORY
        assert proposal.period_start == date(2026, 8, 1)
        assert proposal.available_minutes == 300
        assert proposal.to_window().capacity_type is CapacityType.SUPERVISORY

    def test_unknown_capacity_type_string_rejected(self):
        with pytest.raises(ContractViolationError):
            AvailabilityProposal.from_wire(
                tenant_id="t1",
                resource_ref="actor-1",
                period_start="2026-08-01",
                period_end="2026-08-05",
                available_minutes=300,
                capacity_type="TURBO",
            )

    @pytest.mark.parametrize("bad_type", [3, None, True, ["EXECUTION"]])
    def test_wrong_capacity_type_value_types_rejected(self, bad_type):
        with pytest.raises(ContractViolationError):
            AvailabilityProposal.from_wire(
                tenant_id="t1",
                resource_ref="actor-1",
                period_start="2026-08-01",
                period_end="2026-08-05",
                available_minutes=300,
                capacity_type=bad_type,
            )

    @pytest.mark.parametrize("bad_date", ["2026-13-01", "yesterday", "", 20260801, None])
    def test_malformed_wire_dates_rejected(self, bad_date):
        with pytest.raises(ContractViolationError):
            AvailabilityProposal.from_wire(
                tenant_id="t1",
                resource_ref="actor-1",
                period_start=bad_date,
                period_end="2026-08-05",
                available_minutes=300,
            )

    @pytest.mark.parametrize("bad_minutes", ["3O0", "", None, 12.5, True])
    def test_malformed_wire_minutes_rejected(self, bad_minutes):
        with pytest.raises(ContractViolationError):
            AvailabilityProposal.from_wire(
                tenant_id="t1",
                resource_ref="actor-1",
                period_start="2026-08-01",
                period_end="2026-08-05",
                available_minutes=bad_minutes,
            )

    def test_blank_wire_fields_rejected(self):
        with pytest.raises(ContractViolationError):
            AvailabilityProposal.from_wire(
                tenant_id="  ",
                resource_ref="actor-1",
                period_start="2026-08-01",
                period_end="2026-08-05",
                available_minutes=300,
            )

    def test_time_record_from_wire_decodes_minutes(self):
        proposal = TimeRecordProposal.from_wire(
            tenant_id="t1",
            resource_ref="actor-1",
            work_object_ref="wo-1",
            minutes="45",
            narrative="captured from call",
        )
        assert proposal.minutes == 45

    def test_time_record_from_wire_rejects_garbage_minutes(self):
        with pytest.raises(ContractViolationError):
            TimeRecordProposal.from_wire(
                tenant_id="t1",
                resource_ref="actor-1",
                work_object_ref="wo-1",
                minutes="lots",
            )

    def test_strict_constructor_rejects_raw_capacity_type(self):
        """Incidental dataclass construction is NOT the wire contract."""
        with pytest.raises(CapacityInvariantError):
            availability_proposal(capacity_type="SUPERVISORY")  # type: ignore[arg-type]
