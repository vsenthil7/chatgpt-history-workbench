import pytest
from tests._authz import ALL_TENANTS_AUTHZ as AUTHZ

from cgwo_core.plan_item import (
    ALLOWED_TRANSITIONS,
    DEFAULT_EVENT,
    EVENT_BY_TRANSITION,
    REASON_REQUIRED_DEMOTIONS,
    REASON_REQUIRED_TARGETS,
    ChangeReasonRequiredError,
    InvalidTransitionError,
    PlanItem,
)
from cgwo_core.plan_item import (
    PlanItemState as S,
)
from cgwo_core.tenancy import CrossTenantAccessError, TenantContext

CTX = TenantContext(tenant_id="t1")


def item(state=S.CANDIDATE):
    return PlanItem(tenant_id="t1", work_object_ref="wo-1", state=state)


ALL_PAIRS = [(f, t) for f, targets in ALLOWED_TRANSITIONS.items() for t in targets]


def test_state_machine_covers_full_baseline_catalogue():
    assert set(ALLOWED_TRANSITIONS) == set(S)


@pytest.mark.parametrize("frm,to", ALL_PAIRS)
def test_every_declared_transition_succeeds_with_reason(frm, to):
    result = item(frm).transition(to, AUTHZ, CTX, change_reason="replanning evidence")
    assert result.item.state is to
    assert result.item.tenant_id == "t1"
    assert result.event_type == EVENT_BY_TRANSITION.get((frm, to), DEFAULT_EVENT)


def test_transition_returns_new_immutable_item():
    original = item()
    result = original.transition(S.WEEK_PLANNED, AUTHZ, CTX)
    assert original.state is S.CANDIDATE
    assert result.item is not original


@pytest.mark.parametrize(
    "frm,to",
    [
        (S.CANDIDATE, S.DAY_PLANNED),
        (S.CANDIDATE, S.STARTED),
        (S.WEEK_PLANNED, S.STARTED),
        (S.STARTED, S.CANDIDATE),
        (S.COMPLETED, S.STARTED),
        (S.CANCELLED, S.CANDIDATE),
    ],
)
def test_undeclared_transitions_rejected(frm, to):
    with pytest.raises(InvalidTransitionError):
        item(frm).transition(to, AUTHZ, CTX, change_reason="irrelevant")


@pytest.mark.parametrize("to", sorted(REASON_REQUIRED_TARGETS, key=lambda s: s.value))
def test_reason_required_targets_reject_missing_reason(to):
    sources = [f for f, targets in ALLOWED_TRANSITIONS.items() if to in targets]
    with pytest.raises(ChangeReasonRequiredError):
        item(sources[0]).transition(to, AUTHZ, CTX)


@pytest.mark.parametrize("frm,to", sorted(REASON_REQUIRED_DEMOTIONS, key=str))
def test_plan_demotions_reject_blank_reason(frm, to):
    with pytest.raises(ChangeReasonRequiredError):
        item(frm).transition(to, AUTHZ, CTX, change_reason="   ")


def test_promotion_needs_no_reason_and_emits_weekly_event():
    result = item(S.CANDIDATE).transition(S.WEEK_PLANNED, AUTHZ, CTX)
    assert result.event_type == "WeeklyPlanChanged"


def test_daily_planning_emits_daily_event():
    result = item(S.WEEK_PLANNED).transition(S.DAY_PLANNED, AUTHZ, CTX)
    assert result.event_type == "DailyPlanChanged"


def test_interruption_emits_work_interrupted():
    result = item(S.STARTED).transition(S.INTERRUPTED, AUTHZ, CTX, change_reason="urgent op issue")
    assert result.event_type == "WorkInterrupted"


def test_unmapped_transition_emits_default_event():
    result = item(S.DAY_PLANNED).transition(S.STARTED, AUTHZ, CTX)
    assert result.event_type == DEFAULT_EVENT


def test_cross_tenant_transition_denied():
    with pytest.raises(CrossTenantAccessError):
        item().transition(S.WEEK_PLANNED, AUTHZ, TenantContext(tenant_id="t2"))


@pytest.mark.parametrize("kw", [{"tenant_id": " "}, {"work_object_ref": ""}])
def test_blank_references_rejected(kw):
    base = {"tenant_id": "t1", "work_object_ref": "wo-1"}
    base.update(kw)
    with pytest.raises(ValueError):
        PlanItem(**base)


def test_change_record_preserves_exact_reason_and_states():
    reason = "client escalation INC-4411 pre-empted the slot"
    change = item(S.STARTED).transition(S.INTERRUPTED, AUTHZ, CTX, change_reason=reason)
    assert change.change_reason == reason
    assert change.previous_state is S.STARTED
    assert change.new_state is S.INTERRUPTED
    assert change.tenant_id == "t1"
    assert change.work_object_ref == "wo-1"
    assert change.item.state is S.INTERRUPTED


def test_change_record_normalises_padded_reason():
    change = item(S.STARTED).transition(S.PAUSED, AUTHZ, CTX, change_reason="  lunch break  ")
    assert change.change_reason == "lunch break"


def test_change_record_reason_is_none_when_not_supplied():
    change = item(S.CANDIDATE).transition(S.WEEK_PLANNED, AUTHZ, CTX)
    assert change.change_reason is None
