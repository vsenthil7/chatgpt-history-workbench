import pytest
from tests._authz import ALL_TENANTS_AUTHZ, authz_for

from cgwo_core.authz import (
    AuthorizationError,
    StaticAuthorizationContext,
    assert_authorized,
)
from cgwo_core.tenancy import (
    CrossTenantAccessError,
    MissingTenantContextError,
    TenantContext,
    assert_tenant_operation,
)


def test_valid_context_defaults_organisation_to_none():
    ctx = TenantContext(tenant_id="t1")
    assert ctx.tenant_id == "t1"
    assert ctx.organisation_id is None


def test_context_carries_organisation():
    assert TenantContext(tenant_id="t1", organisation_id="o1").organisation_id == "o1"


@pytest.mark.parametrize("bad", ["", "   "])
def test_blank_tenant_id_rejected(bad):
    with pytest.raises(MissingTenantContextError):
        TenantContext(tenant_id=bad)


def test_authorized_operation_within_entitled_tenant_passes():
    assert_tenant_operation(authz_for("t1"), TenantContext("t1"), "t1")


def test_operation_denied_when_principal_not_entitled():
    # ctx routing is consistent, but the principal is not entitled to t1.
    with pytest.raises(AuthorizationError):
        assert_tenant_operation(authz_for("t9"), TenantContext("t1"), "t1")


def test_routing_mismatch_denied_even_when_entitled():
    # Principal is entitled to both, but the ctx label names a different tenant
    # than the aggregate it targets: a controlled cross-tenant routing error.
    with pytest.raises(CrossTenantAccessError):
        assert_tenant_operation(ALL_TENANTS_AUTHZ, TenantContext("t2"), "t1")


def test_assert_authorized_membership():
    ctx = StaticAuthorizationContext("p", frozenset({"t1"}))
    assert_authorized(ctx, "t1")
    with pytest.raises(AuthorizationError):
        assert_authorized(ctx, "t2")


def test_static_context_rejects_blank_principal():
    with pytest.raises(AuthorizationError):
        StaticAuthorizationContext("  ", frozenset({"t1"}))


def test_static_context_rejects_hostile_entitlement_member():
    class EqualEverything(str):
        def __eq__(self, other):
            return True

        def __ne__(self, other):
            return False

        __hash__ = str.__hash__

    # A hostile-equality entitlement is rejected at construction (exact str).
    with pytest.raises(AuthorizationError):
        StaticAuthorizationContext("p", {EqualEverything("t1")})


def test_static_context_entitlements_are_not_mutable_via_attribute():
    ctx = StaticAuthorizationContext("p", frozenset({"t1"}))
    # slots + no setter: there is no public way to widen entitlements.
    assert not hasattr(ctx, "__dict__")
    assert ctx.is_entitled("t1") is True
    assert ctx.is_entitled("t2") is False
