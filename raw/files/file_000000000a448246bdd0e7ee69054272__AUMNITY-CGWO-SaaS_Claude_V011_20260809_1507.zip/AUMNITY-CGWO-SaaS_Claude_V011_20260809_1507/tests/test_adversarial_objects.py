"""Adversarial domain-object attacks under the ADR-014 trust model.

History: V006 tried to make object identity a trust anchor (exact-type
guards). The V006 review (F30) proved that wrong — ``object.__setattr__``
mutates a genuine frozen instance, and a lying subclass (F32) defeats
attribute reads from one layer up. ADR-014 moves the security decision to an
authenticated authorization boundary: a protected operation is allowed only
if the authenticated principal is entitled to the aggregate's tenant, a fact
no caller-supplied object can forge.

These regressions use the reviewer's exact attacks (post-construction
mutation, hostile-equality owner, lying ``TenantContext``/``CapacityWindow``/
``PlanItem`` subclasses) and prove none of them obtains authority.
"""

from datetime import date

import pytest
from tests._authz import authz_for

from cgwo_core import errors as E
from cgwo_core.allocation import (
    AllocationInvariantError,
    AllocationState,
    CapacityAllocation,
    consume_allocation,
    transition_allocation,
)
from cgwo_core.authz import AuthorizationError
from cgwo_core.capacity import CapacityInvariantError, CapacityWindow, windows_overlap
from cgwo_core.contracts import (
    WIRE_INT_MAX_VALUE,
    ContractViolationError,
    TimeRecordProposal,
    parse_wire_int,
)
from cgwo_core.errors import INTEGER_OUT_OF_RANGE
from cgwo_core.plan_item import (
    PlanItem,
    PlanItemInvariantError,
    PlanItemState,
    transition_plan_item,
)
from cgwo_core.tenancy import CrossTenantAccessError, TenantContext

D1, D5 = date(2026, 8, 1), date(2026, 8, 5)


def victim_window(tenant: str = "victim") -> CapacityWindow:
    return CapacityWindow(
        tenant_id=tenant,
        resource_ref="actor-1",
        period_start=D1,
        period_end=D5,
        available_minutes=600,
    )


# --- F30: post-construction mutation of a genuine object ----------------------
def test_f30_mutated_tenant_context_cannot_obtain_authority():
    """The reviewer's exact attack: mutate a genuine, exact-typed context."""
    ctx = TenantContext("attacker")
    object.__setattr__(ctx, "tenant_id", "victim")
    assert type(ctx) is TenantContext  # still genuinely exact
    # An attacker principal is only entitled to 'attacker', not 'victim'. The
    # victim aggregate's transition authorizes against 'victim' and is denied,
    # regardless of the mutated label the attacker carries.
    item = PlanItem(tenant_id="victim", work_object_ref="wo-1")
    with pytest.raises(AuthorizationError):
        item.transition(PlanItemState.WEEK_PLANNED, authz_for("attacker"), ctx)


def test_f30_mutated_window_cannot_grant_capacity_or_authority():
    window = victim_window(tenant="attacker")
    object.__setattr__(window, "tenant_id", "victim")
    object.__setattr__(window, "available_minutes", 1_000_000_000)
    # Even with a mutated genuine window, an operation on it authorizes against
    # the window's tenant; an attacker principal is not entitled to 'victim'.
    alloc = CapacityAllocation.create("victim", victim_window(), "p", 100)
    with pytest.raises(AuthorizationError):
        alloc.transition(AllocationState.RESERVED, authz_for("attacker"), TenantContext("victim"))


# --- F32: lying aggregate subclasses ------------------------------------------
def test_f32_lying_plan_item_cannot_execute_against_victim():
    class LyingPlanItem(PlanItem):
        def __getattribute__(self, name):
            if name == "tenant_id":
                return "victim"
            return super().__getattribute__(name)

    item = LyingPlanItem("attacker", "work")
    # The lie reports 'victim', so the operation authorizes against 'victim' —
    # which the attacker principal is not entitled to. Denied.
    with pytest.raises(AuthorizationError):
        item.transition(PlanItemState.WEEK_PLANNED, authz_for("attacker"), TenantContext("victim"))


def test_f32_lying_plan_item_cannot_use_genuine_victim_authority_either():
    """If the attacker somehow held victim authority the routing check still
    binds ctx to the reported owner; and without it, authorization denies."""

    class LyingPlanItem(PlanItem):
        def __getattribute__(self, name):
            if name == "tenant_id":
                return "victim"
            return super().__getattribute__(name)

    item = LyingPlanItem("attacker", "work")
    # With an authz that is NOT entitled to victim, denied at authorization.
    with pytest.raises(AuthorizationError):
        item.transition(
            PlanItemState.WEEK_PLANNED, authz_for("attacker", "other"), TenantContext("victim")
        )


# --- F27/F28 (now subsumed): hostile owner / lying context at the authz layer -
def test_f27_lying_context_subclass_denied_by_authorization():
    class LyingContext(TenantContext):
        def __getattribute__(self, name):
            if name == "tenant_id":
                return "victim"
            return super().__getattribute__(name)

    item = PlanItem(tenant_id="victim", work_object_ref="wo-1")
    with pytest.raises(AuthorizationError):
        item.transition(PlanItemState.WEEK_PLANNED, authz_for("attacker"), LyingContext("attacker"))


def test_genuine_authorized_operation_succeeds():
    item = PlanItem(tenant_id="t1", work_object_ref="wo-1")
    change = item.transition(PlanItemState.WEEK_PLANNED, authz_for("t1"), TenantContext("t1"))
    assert change.new_state is PlanItemState.WEEK_PLANNED
    assert change.tenant_id == "t1"


def test_routing_mismatch_still_controlled():
    item = PlanItem(tenant_id="t1", work_object_ref="wo-1")
    # Entitled to both, but ctx names t2 while the aggregate is t1.
    with pytest.raises(CrossTenantAccessError):
        item.transition(PlanItemState.WEEK_PLANNED, authz_for("t1", "t2"), TenantContext("t2"))


# --- F31 (V006 review): oversized integers bounded on BOTH paths -------------
def test_f31_exact_int_over_limit_rejected():
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_int(WIRE_INT_MAX_VALUE + 1, "minutes")
    assert excinfo.value.code == INTEGER_OUT_OF_RANGE
    assert excinfo.value.fields == {"field": "minutes"}


def test_f31_massively_oversized_exact_int_rejected_without_stringifying():
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_int(10**5000, "minutes")
    assert excinfo.value.code == INTEGER_OUT_OF_RANGE


def test_f31_negative_exact_int_rejected():
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_int(-1, "minutes")
    assert excinfo.value.code == INTEGER_OUT_OF_RANGE


def test_f31_exact_int_at_limit_accepted():
    assert parse_wire_int(WIRE_INT_MAX_VALUE, "minutes") == WIRE_INT_MAX_VALUE


def test_f31_zero_is_accepted_by_wire_int():
    # Pins the `< 0` boundary (a `<= 0` or `< 1` mutant would reject zero).
    assert parse_wire_int(0, "minutes") == 0


def test_f31_one_is_accepted_by_wire_int():
    assert parse_wire_int(1, "minutes") == 1


def test_f31_string_with_too_many_digits_rejected():
    overlong = "9" * (len(str(WIRE_INT_MAX_VALUE)) + 1)
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_int(overlong, "minutes")
    assert excinfo.value.code == INTEGER_OUT_OF_RANGE
    assert excinfo.value.fields == {"field": "minutes"}


def test_f31_string_same_digits_but_over_value_rejected():
    over = str(WIRE_INT_MAX_VALUE + 5)  # 13 digits, numerically larger
    assert len(over) == len(str(WIRE_INT_MAX_VALUE))
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_int(over, "minutes")
    assert excinfo.value.code == INTEGER_OUT_OF_RANGE
    assert excinfo.value.fields == {"field": "minutes"}


def test_f31_string_at_limit_accepted():
    assert parse_wire_int(str(WIRE_INT_MAX_VALUE), "minutes") == WIRE_INT_MAX_VALUE


def test_f31_from_wire_time_record_rejects_oversized_exact_int():
    with pytest.raises(ContractViolationError):
        TimeRecordProposal.from_wire(
            tenant_id="t1",
            resource_ref="a",
            work_object_ref="w",
            minutes=10**5000,
        )


# --- Trust-model honesty: the authz contract IS the trust root (ADR-014) -----
def test_authz_is_the_trust_root_not_the_domain_object():
    """This documents the trust model precisely (review F30 lesson).

    The domain core trusts the AuthorizationPort to report authenticated
    entitlements — that is the whole point of moving the decision there. A
    caller who can already forge an AuthorizationContext with victim
    entitlements has, by definition, defeated authentication UPSTREAM; the
    domain core cannot and does not claim to defend against a forged
    authenticated identity. What it DOES guarantee is that no manipulation of
    DOMAIN OBJECTS (mutation, lying subclasses, relabeled contexts) can obtain
    authority without such an entitlement. The pair of assertions below makes
    that boundary explicit.
    """
    # Domain-object manipulation cannot obtain authority:
    item = PlanItem(tenant_id="victim", work_object_ref="wo-1")
    with pytest.raises(AuthorizationError):
        item.transition(PlanItemState.WEEK_PLANNED, authz_for("attacker"), TenantContext("victim"))
    # Only a genuine entitlement (which a service layer binds to authenticated
    # identity) authorizes the operation:
    change = item.transition(
        PlanItemState.WEEK_PLANNED, authz_for("victim"), TenantContext("victim")
    )
    assert change.new_state is PlanItemState.WEEK_PLANNED


# --- F42: aggregate operation-argument hygiene (subclass still reaches authz) --
def test_f42_aggregate_subclass_is_admitted_and_handled_by_authz():
    """The F42 guard is API hygiene, NOT a security control (ADR-015): it
    rejects non-aggregates but ADMITS subclasses, so a lying subclass still
    reaches the authorization layer and is denied there (F32 semantics), rather
    than being rejected as a wrong type. This keeps the two concerns separate."""

    class LyingPlanItem(PlanItem):
        def __getattribute__(self, name):
            if name == "tenant_id":
                return "victim"
            return super().__getattribute__(name)

    item = LyingPlanItem("attacker", "work")
    # Not a WRONG_RUNTIME_TYPE rejection — the subclass is admitted, then denied
    # by authorization because 'attacker' is not entitled to 'victim'.
    with pytest.raises(AuthorizationError):
        item.transition(PlanItemState.WEEK_PLANNED, authz_for("attacker"), TenantContext("victim"))


# --- F45: require_aggregate reads the REAL type — spoofed __class__ rejected --
# The V010 review defeated the F42 guard with an object whose __class__
# property lies: isinstance consulted the spoofed __class__, admitted the
# impostor, and the operation then crashed with the raw AttributeError the
# guard exists to prevent — contradicting RTM DOM-008/DOM-014. The guard now
# checks issubclass(type(value), expected_cls): type() reads the real type
# slot, so genuine subclasses are still admitted (F32/F42 semantics preserved)
# while __class__ impostors get a controlled WRONG_RUNTIME_TYPE naming their
# REAL type. The four-way contract (normal PASS / real subclass PASS / plain
# malformed rejected / spoofed impostor rejected) is regressed at ALL FOUR F42
# sites below; the plain-malformed leg also lives in the guard-site matrix.


def _spoofing(target_cls):
    """An object that is NOT target_cls but lies about it via __class__."""

    class Impostor:
        @property
        def __class__(self):
            return target_cls

    return Impostor()


def _assert_spoof_rejected(excinfo, field, expected):
    err = excinfo.value
    assert err.code == E.WRONG_RUNTIME_TYPE
    assert err.fields["field"] == field
    assert err.fields["expected"] == expected
    # The controlled error names the impostor's REAL type, not the lie.
    assert err.fields["actual"] == "Impostor"


def test_f45_transition_plan_item_rejects_spoofed_class():
    spoof = _spoofing(PlanItem)
    assert isinstance(spoof, PlanItem)  # the lie isinstance believes
    assert type(spoof) is not PlanItem  # the truth the guard reads
    with pytest.raises(PlanItemInvariantError) as excinfo:
        transition_plan_item(
            spoof, PlanItemState.WEEK_PLANNED, authz_for("t1"), TenantContext("t1")
        )
    _assert_spoof_rejected(excinfo, "item", "PlanItem")


def test_f45_transition_allocation_rejects_spoofed_class():
    with pytest.raises(AllocationInvariantError) as excinfo:
        transition_allocation(
            _spoofing(CapacityAllocation),
            AllocationState.RESERVED,
            authz_for("t1"),
            TenantContext("t1"),
        )
    _assert_spoof_rejected(excinfo, "allocation", "CapacityAllocation")


def test_f45_consume_allocation_rejects_spoofed_class():
    with pytest.raises(AllocationInvariantError) as excinfo:
        consume_allocation(_spoofing(CapacityAllocation), 1, authz_for("t1"), TenantContext("t1"))
    _assert_spoof_rejected(excinfo, "allocation", "CapacityAllocation")


def test_f45_windows_overlap_rejects_spoofed_class_both_sides():
    real = CapacityWindow(
        tenant_id="t1",
        resource_ref="actor-1",
        period_start=date(2026, 8, 1),
        period_end=date(2026, 8, 5),
        available_minutes=600,
    )
    with pytest.raises(CapacityInvariantError) as excinfo:
        windows_overlap(_spoofing(CapacityWindow), real)
    _assert_spoof_rejected(excinfo, "one", "CapacityWindow")
    with pytest.raises(CapacityInvariantError) as excinfo:
        windows_overlap(real, _spoofing(CapacityWindow))
    _assert_spoof_rejected(excinfo, "other", "CapacityWindow")


def test_f45_normal_and_genuine_subclass_still_admitted_at_every_site():
    """The fix must NOT regress F32/F42: real aggregates and REAL subclasses
    (true type inherits the aggregate class) pass the guard at all four sites."""
    authz, ctx = authz_for("t1"), TenantContext("t1")

    class SubPlanItem(PlanItem):
        pass

    class SubAllocation(CapacityAllocation):
        pass

    class SubWindow(CapacityWindow):
        pass

    window = CapacityWindow(
        tenant_id="t1",
        resource_ref="actor-1",
        period_start=date(2026, 8, 1),
        period_end=date(2026, 8, 5),
        available_minutes=600,
    )
    sub_window = SubWindow(
        tenant_id="t1",
        resource_ref="actor-1",
        period_start=date(2026, 8, 3),
        period_end=date(2026, 8, 9),
        available_minutes=600,
    )

    # transition_plan_item: normal + subclass
    assert (
        transition_plan_item(
            PlanItem.create("t1", "wo-1"), PlanItemState.WEEK_PLANNED, authz, ctx
        ).new_state
        is PlanItemState.WEEK_PLANNED
    )
    assert (
        transition_plan_item(
            SubPlanItem("t1", "wo-2"), PlanItemState.WEEK_PLANNED, authz, ctx
        ).new_state
        is PlanItemState.WEEK_PLANNED
    )

    # transition_allocation + consume_allocation: normal + subclass
    def alloc(cls):
        return cls(
            tenant_id="t1",
            window=window,
            plan_item_ref="pi-1",
            allocated_minutes=120,
            consumed_minutes=0,
            state=AllocationState.PROPOSED,
        )

    for cls in (CapacityAllocation, SubAllocation):
        reserved = transition_allocation(alloc(cls), AllocationState.RESERVED, authz, ctx)
        assert reserved.new_state is AllocationState.RESERVED

    for cls in (CapacityAllocation, SubAllocation):
        consumable = cls(
            tenant_id="t1",
            window=window,
            plan_item_ref="pi-1",
            allocated_minutes=120,
            consumed_minutes=0,
            state=AllocationState.RESERVED,
        )
        assert consume_allocation(consumable, 30, authz, ctx).consumed_minutes_after == 30

    # windows_overlap: normal + subclass on both sides
    assert windows_overlap(window, sub_window) is True
    assert windows_overlap(sub_window, window) is True
