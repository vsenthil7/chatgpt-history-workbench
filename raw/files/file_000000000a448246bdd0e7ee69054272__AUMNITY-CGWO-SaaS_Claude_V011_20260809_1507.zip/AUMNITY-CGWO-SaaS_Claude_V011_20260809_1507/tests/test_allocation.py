from datetime import date

import pytest
from tests._authz import ALL_TENANTS_AUTHZ as AUTHZ

from cgwo_core.allocation import (
    ALLOWED_TRANSITIONS,
    DEFAULT_EVENT,
    EVENT_BY_TARGET,
    AllocationInvariantError,
    CapacityAllocation,
)
from cgwo_core.allocation import (
    AllocationState as A,
)
from cgwo_core.capacity import CapacityWindow
from cgwo_core.plan_item import InvalidTransitionError
from cgwo_core.tenancy import CrossTenantAccessError, TenantContext

CTX = TenantContext(tenant_id="t1")
WINDOW = CapacityWindow(
    tenant_id="t1",
    resource_ref="actor-1",
    period_start=date(2026, 8, 1),
    period_end=date(2026, 8, 5),
    available_minutes=600,
)

#: A consumed_minutes value consistent with each state for allocated=120.
CONSISTENT_CONSUMED = {
    A.PROPOSED: 0,
    A.RESERVED: 0,
    A.CONSUMING: 50,
    A.PARTIALLY_CONSUMED: 50,
    A.CONSUMED: 120,
    A.OVERRUN: 130,
    A.RELEASED: 0,
}


def allocation(state=A.PROPOSED, allocated=120, consumed=None, **kw):
    if consumed is None:
        consumed = CONSISTENT_CONSUMED[state]
    base = {
        "tenant_id": "t1",
        "window": WINDOW,
        "plan_item_ref": "pi-1",
        "allocated_minutes": allocated,
        "consumed_minutes": consumed,
        "state": state,
    }
    base.update(kw)
    return CapacityAllocation(**base)


ALL_PAIRS = [(f, t) for f, targets in ALLOWED_TRANSITIONS.items() for t in targets]


def test_state_machine_covers_full_baseline_catalogue():
    assert set(ALLOWED_TRANSITIONS) == set(A)


@pytest.mark.parametrize("frm,to", ALL_PAIRS)
def test_every_declared_lifecycle_transition_succeeds(frm, to):
    change = allocation(frm).transition(to, AUTHZ, CTX)
    assert change.allocation.state is to
    assert change.event_type == EVENT_BY_TARGET.get(to, DEFAULT_EVENT)


def test_quantity_states_unreachable_via_lifecycle_transition():
    for targets in ALLOWED_TRANSITIONS.values():
        assert A.CONSUMED not in targets
        assert A.OVERRUN not in targets


def test_reservation_emits_capacity_reserved():
    assert allocation().transition(A.RESERVED, AUTHZ, CTX).event_type == "CapacityReserved"


@pytest.mark.parametrize(
    "frm,to",
    [
        (A.PROPOSED, A.CONSUMING),
        (A.RESERVED, A.PARTIALLY_CONSUMED),
        (A.CONSUMING, A.CONSUMED),
        (A.CONSUMING, A.OVERRUN),
        (A.PARTIALLY_CONSUMED, A.CONSUMED),
        (A.OVERRUN, A.CONSUMED),
        (A.CONSUMED, A.RELEASED),
        (A.RELEASED, A.PROPOSED),
    ],
)
def test_undeclared_transitions_rejected(frm, to):
    with pytest.raises(InvalidTransitionError):
        allocation(frm).transition(to, AUTHZ, CTX)


def test_pausing_with_zero_recorded_consumption_is_invalid():
    with pytest.raises(AllocationInvariantError):
        allocation(A.CONSUMING, consumed=0).transition(A.PARTIALLY_CONSUMED, AUTHZ, CTX)


def test_cross_tenant_transition_denied():
    with pytest.raises(CrossTenantAccessError):
        allocation().transition(A.RESERVED, AUTHZ, TenantContext(tenant_id="t2"))


def test_partial_consumption():
    change = allocation(A.RESERVED).consume(50, AUTHZ, CTX)
    assert change.allocation.state is A.PARTIALLY_CONSUMED
    assert change.allocation.consumed_minutes == 50
    assert change.event_type == "TimeRecorded"


def test_exact_consumption_completes_allocation():
    change = allocation(A.PARTIALLY_CONSUMED, consumed=70).consume(50, AUTHZ, CTX)
    assert change.allocation.state is A.CONSUMED
    assert change.event_type == "TimeRecorded"


def test_overrun_detected_and_signalled():
    change = allocation(A.CONSUMING, consumed=100).consume(30, AUTHZ, CTX)
    assert change.allocation.state is A.OVERRUN
    assert change.allocation.consumed_minutes == 130
    assert change.event_type == "CapacityOverrunDetected"


def test_consume_from_active_session_below_limit_stays_partial():
    change = allocation(A.CONSUMING, consumed=10).consume(20, AUTHZ, CTX)
    assert change.allocation.state is A.PARTIALLY_CONSUMED


def test_consumption_illegal_before_reservation():
    with pytest.raises(InvalidTransitionError):
        allocation(A.PROPOSED).consume(10, AUTHZ, CTX)


@pytest.mark.parametrize("minutes", [0, -5])
def test_nonpositive_consumption_rejected(minutes):
    with pytest.raises(AllocationInvariantError):
        allocation(A.RESERVED).consume(minutes, AUTHZ, CTX)


def test_cross_tenant_consumption_denied():
    with pytest.raises(CrossTenantAccessError):
        allocation(A.RESERVED).consume(10, AUTHZ, TenantContext(tenant_id="t2"))


def test_change_record_carries_quantities_and_states():
    change = allocation(A.RESERVED).consume(50, AUTHZ, CTX)
    assert change.previous_state is A.RESERVED
    assert change.new_state is A.PARTIALLY_CONSUMED
    assert change.allocated_minutes == 120
    assert change.consumed_minutes_before == 0
    assert change.consumed_minutes_after == 50
    assert change.tenant_id == "t1"
    assert change.plan_item_ref == "pi-1"
    assert change.resource_ref == "actor-1"


def test_lifecycle_change_record_keeps_consumption_stable():
    change = allocation(A.PARTIALLY_CONSUMED, consumed=50).transition(A.CONSUMING, AUTHZ, CTX)
    assert change.consumed_minutes_before == change.consumed_minutes_after == 50


@pytest.mark.parametrize(
    "kw",
    [
        {"tenant_id": "t2"},
        {"plan_item_ref": "  "},
        {"allocated": 0},
        {"consumed": -1},
    ],
)
def test_base_invariants_rejected(kw):
    with pytest.raises(AllocationInvariantError):
        allocation(**kw)


# --- Review finding F01: impossible state/data combinations must not construct
@pytest.mark.parametrize(
    "state,consumed",
    [
        (A.PROPOSED, 25),
        (A.PROPOSED, 500),
        (A.RESERVED, 5),
        (A.RESERVED, 500),
        (A.CONSUMING, 120),
        (A.CONSUMING, 121),
        (A.PARTIALLY_CONSUMED, 0),
        (A.PARTIALLY_CONSUMED, 120),
        (A.PARTIALLY_CONSUMED, 121),
        (A.CONSUMED, 0),
        (A.CONSUMED, 119),
        (A.CONSUMED, 121),
        (A.OVERRUN, 119),
        (A.OVERRUN, 120),
    ],
)
def test_f01_direct_construction_cannot_bypass_state_machine(state, consumed):
    with pytest.raises(AllocationInvariantError):
        allocation(state, consumed=consumed)


@pytest.mark.parametrize(
    "state,consumed",
    [
        (A.PROPOSED, 0),
        (A.RESERVED, 0),
        (A.CONSUMING, 0),
        (A.CONSUMING, 119),
        (A.PARTIALLY_CONSUMED, 1),
        (A.PARTIALLY_CONSUMED, 119),
        (A.CONSUMED, 120),
        (A.OVERRUN, 121),
        (A.RELEASED, 0),
        (A.RELEASED, 50),
        (A.RELEASED, 130),
    ],
)
def test_f01_consistent_states_construct(state, consumed):
    assert allocation(state, consumed=consumed).consumed_minutes == consumed


# --- Review finding F02: allocation must not exceed its capacity window
def test_f02_allocation_cannot_exceed_window_capacity():
    with pytest.raises(AllocationInvariantError):
        allocation(allocated=601)


def test_f02_allocation_may_use_entire_window():
    assert allocation(allocated=600, state=A.PROPOSED).allocated_minutes == 600


def test_f02_zero_capacity_window_admits_no_allocation():
    empty = CapacityWindow(
        tenant_id="t1",
        resource_ref="actor-1",
        period_start=date(2026, 8, 1),
        period_end=date(2026, 8, 1),
        available_minutes=0,
    )
    with pytest.raises(AllocationInvariantError):
        CapacityAllocation(tenant_id="t1", window=empty, plan_item_ref="pi-1", allocated_minutes=1)


def test_one_minute_allocation_is_valid():
    assert allocation(allocated=1).allocated_minutes == 1


def test_one_minute_consumption_is_valid():
    change = allocation(A.RESERVED, allocated=2).consume(1, AUTHZ, CTX)
    assert change.allocation.state is A.PARTIALLY_CONSUMED
    assert change.allocation.consumed_minutes == 1


def test_lifecycle_change_record_carries_references():
    change = allocation().transition(A.RESERVED, AUTHZ, CTX)
    assert change.plan_item_ref == "pi-1"
    assert change.resource_ref == "actor-1"
