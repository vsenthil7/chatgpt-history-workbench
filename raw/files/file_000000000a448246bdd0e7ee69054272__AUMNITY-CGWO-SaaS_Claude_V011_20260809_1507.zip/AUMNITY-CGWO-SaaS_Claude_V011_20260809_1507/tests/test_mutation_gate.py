"""Unit tests for the strict mutation-gate decision logic (ADR-011, F17).

Synthetic fixtures prove the gate cannot return GREEN for incomplete,
failed, anomalous or unparseable mutation runs — the false-green paths the
V003 review identified.
"""

import sys
from pathlib import Path

# Resolve the real scripts/ dir both from the repository layout and from the
# mutation harness's mutants/ copy (which mirrors tests/ but not scripts/).
_HERE = Path(__file__).resolve()
for _candidate in (_HERE.parents[1] / "scripts", _HERE.parents[2] / "scripts"):
    if _candidate.is_dir():
        sys.path.insert(0, str(_candidate))
        break
from mutation_gate import evaluate, parse_survivors, parse_tally, parse_total

GOOD_RUN = "⠏ 239/239  🎉 239 🫥 0  ⏰ 0  🤔 0  🙁 0  🔇 0\n9.5 mutations/second\n"


def good(**overrides):
    args = {
        "run_returncode": 0,
        "results_returncode": 0,
        "run_output": GOOD_RUN,
        "results_output": "",
        "acceptance": {},
    }
    args.update(overrides)
    return evaluate(**args)


def test_complete_clean_run_is_green():
    decision = good()
    assert decision.ok is True
    assert decision.reasons == []
    assert decision.tally["killed"] == 239
    assert decision.total_expected == 239


def test_nonzero_run_exit_fails():
    assert "mutmut run exited 2" in good(run_returncode=2).reasons


def test_nonzero_results_exit_fails():
    assert "mutmut results exited 1" in good(results_returncode=1).reasons


def test_missing_tally_fails():
    decision = good(run_output="mutmut crashed before mutating\n")
    assert decision.ok is False
    assert any("unparseable" in r for r in decision.reasons)


def test_partial_tally_fails():
    decision = good(run_output="⠏ 10/10  🎉 10 🙁 0\n")
    assert decision.ok is False
    assert any("unparseable" in r for r in decision.reasons)


def test_zero_total_fails():
    decision = good(run_output="0/0  🎉 0 🫥 0  ⏰ 0  🤔 0  🙁 0  🔇 0\n")
    assert any("not > 0" in r for r in decision.reasons)


def test_missing_total_fails():
    decision = good(run_output="🎉 5 🫥 0  ⏰ 0  🤔 0  🙁 0  🔇 0\n")
    assert any("total mutant count missing" in r for r in decision.reasons)


def test_unreconciled_tally_fails():
    # 100 mutants but categories only account for 70: the reviewer's example
    decision = good(run_output="70/100  🎉 70 🫥 0  ⏰ 0  🤔 0  🙁 0  🔇 0\n")
    assert any("sum to 70 but total is 100" in r for r in decision.reasons)


def test_no_tests_mutants_fail_even_with_zero_survivors():
    # The reviewer's false-green example: 70 killed, 30 no-tests, 0 survivors
    decision = good(run_output="100/100  🎉 70 🫥 30  ⏰ 0  🤔 0  🙁 0  🔇 0\n")
    assert decision.ok is False
    assert any("no_tests mutants present (30)" in r for r in decision.reasons)


def test_timeout_suspicious_skipped_fail():
    decision = good(run_output="10/10  🎉 7 🫥 0  ⏰ 1  🤔 1  🙁 0  🔇 1\n")
    reasons = " | ".join(decision.reasons)
    assert "timeout mutants present (1)" in reasons
    assert "suspicious mutants present (1)" in reasons
    assert "skipped mutants present (1)" in reasons


def test_survivor_listing_must_reconcile_with_tally():
    decision = good(
        run_output="10/10  🎉 9 🫥 0  ⏰ 0  🤔 0  🙁 1  🔇 0\n",
        results_output="",  # tally says 1 survivor; listing shows none
    )
    assert any("listing shows 0 survivors but tally says 1" in r for r in decision.reasons)


def test_unaccepted_survivor_fails():
    decision = good(
        run_output="10/10  🎉 9 🫥 0  ⏰ 0  🤔 0  🙁 1  🔇 0\n",
        results_output="    pkg.mod.x_fn__mutmut_1: survived\n",
    )
    assert decision.unresolved == ["pkg.mod.x_fn__mutmut_1"]
    assert decision.ok is False


def test_accepted_survivor_with_justification_passes():
    decision = good(
        run_output="10/10  🎉 9 🫥 0  ⏰ 0  🤔 0  🙁 1  🔇 0\n",
        results_output="    pkg.mod.x_fn__mutmut_1: survived\n",
        acceptance={"pkg.mod.x_fn__mutmut_1": "equivalent mutant: reviewed 2026-08-08"},
    )
    assert decision.ok is True
    assert decision.accepted == {"pkg.mod.x_fn__mutmut_1": "equivalent mutant: reviewed 2026-08-08"}


def test_parsers_are_deterministic():
    assert parse_total("3/7 then 7/7 done") == 7
    assert parse_tally("no emojis here") is None
    assert parse_survivors("    a.b: survived\n    c.d: survived\n") == ["a.b", "c.d"]
