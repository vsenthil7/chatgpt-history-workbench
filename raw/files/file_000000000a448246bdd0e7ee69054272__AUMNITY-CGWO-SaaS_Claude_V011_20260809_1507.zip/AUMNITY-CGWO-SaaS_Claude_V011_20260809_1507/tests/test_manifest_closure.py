"""F43/F46/F47 regressions: package-manifest integrity is CLOSED over the
shipped set — with an EXPLICIT exclusion allowlist and VERIFIED metadata.

The V009 review (F43) showed hash-only validation is one-way — it proved every
listed file still hashed correctly but never that every shipped managed file
was listed, so an unmanifested EXTRA.txt passed. The V010 review then showed
two further gaps: the exclusion policy generically ignored EVERY dot-prefixed
directory, so an unmanifested `.evil/payload.py` was invisible and validation
PASSED (F46); and the manifest's `bytes` metadata was generated but never
checked, so a falsified size also PASSED (F47). These tests exercise the
SHIPPED validator against a temporary copy so all three closure rules are
anchored, and assert the generator and validator share one membership policy.
"""

import json
import shutil
import subprocess
import sys
from pathlib import Path


def _repo_root() -> Path:
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "00-control/RELEASE-IDENTITY.json").is_file():
            return parent
    return here.parents[1]


ROOT = _repo_root()
sys.path.insert(0, str(ROOT / "scripts"))
from manifest_policy import EXCLUDE_DIRS, is_managed


def _copy_package(tmp_path: Path) -> Path:
    dest = tmp_path / ROOT.name
    # Excluded-by-policy directories are dev/build litter; skip them at copy
    # time (sourced from the SHARED policy so this helper cannot drift from it).
    shutil.copytree(
        ROOT, dest, ignore=shutil.ignore_patterns(*EXCLUDE_DIRS, ".coverage", ".DS_Store")
    )
    return dest


def _regen_manifest(pkg: Path) -> None:
    """Regenerate the copy's manifest with the SHIPPED generator so each attack
    test is HERMETIC: it starts from a provably consistent copy and then makes
    exactly one adversarial change, ensuring the validator failure it asserts
    has exactly one cause (and the pass-control genuinely passes) regardless of
    whether the LIVE tree's manifest is momentarily stale mid-gate-pipeline."""
    subprocess.run(
        [sys.executable, "scripts/gen_manifest.py"],
        cwd=pkg,
        capture_output=True,
        text=True,
        check=True,
    )


def _run_validator(pkg: Path, *extra: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "scripts/validate_consistency.py", *extra],
        cwd=pkg,
        capture_output=True,
        text=True,
        check=False,
    )


def test_manifest_matches_shared_policy():
    """The manifest's file set equals the shared policy's managed set (F43)."""
    sys.path.insert(0, str(ROOT / "scripts"))
    from manifest_policy import managed_files

    manifest = json.loads((ROOT / "PACKAGE-MANIFEST.json").read_text(encoding="utf-8"))
    listed = {e["path"] for e in manifest["files"]}
    assert listed == set(managed_files(ROOT))
    assert manifest["file_count"] == len(listed)


def test_unmanifested_file_fails_validation(tmp_path):
    """The exact F43 attack: an extra file added after manifest generation."""
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    (pkg / "EXTRA.txt").write_text("junk\n")
    result = _run_validator(pkg)  # full manifest check (no --skip-manifest)
    assert result.returncode != 0
    assert "F43" in result.stdout
    assert "EXTRA.txt" in result.stdout


def test_duplicate_manifest_entry_fails(tmp_path):
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    mf = pkg / "PACKAGE-MANIFEST.json"
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    manifest["files"].append(dict(manifest["files"][0]))  # duplicate first entry
    mf.write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F43" in result.stdout


def test_wrong_file_count_fails(tmp_path):
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    mf = pkg / "PACKAGE-MANIFEST.json"
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    manifest["file_count"] = manifest["file_count"] + 100
    mf.write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F43" in result.stdout


# --- F46: exclusions are an EXPLICIT allowlist — hidden dirs are not a bypass --
def test_f46_policy_manages_arbitrary_hidden_paths():
    """Unit anchor for the policy itself: known named caches are excluded,
    but an ARBITRARY hidden directory is MANAGED — the excluded universe is a
    reviewed allowlist, never an adversary-chosen naming convention."""
    # Known build/cache directories stay excluded.
    assert not is_managed(Path(".pytest_cache/v/cache/lastfailed"))
    assert not is_managed(Path(".ruff_cache/CACHEDIR.TAG"))
    assert not is_managed(Path("mutants/src/cgwo_core/plan_item.py"))
    assert not is_managed(Path("src/__pycache__/x.pyc"))
    # The F46 attack surface: arbitrary hidden paths ARE managed.
    assert is_managed(Path(".evil/payload.py"))
    assert is_managed(Path(".hidden-file"))
    assert is_managed(Path("src/.sneaky/mod.py"))


def test_f46_unmanifested_hidden_file_fails_validation(tmp_path):
    """The exact F46 attack: `.evil/payload.py` added after manifest
    generation must fail closed-set validation, exactly as EXTRA.txt does."""
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    evil = pkg / ".evil"
    evil.mkdir()
    (evil / "payload.py").write_text("payload\n")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert ".evil/payload.py" in result.stdout
    assert "F43" in result.stdout  # reported through the closed-set rule


# --- F47: manifest `bytes` metadata is VERIFIED, not decorative ---------------
def test_f47_falsified_bytes_fails_validation(tmp_path):
    """The exact F47 attack: a false `bytes` value with the file and its
    SHA-256 untouched must fail — the schema carries no unverified metadata."""
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    mf = pkg / "PACKAGE-MANIFEST.json"
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    manifest["files"][0]["bytes"] = manifest["files"][0]["bytes"] + 999
    mf.write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "bytes mismatch" in result.stdout
    assert "F47" in result.stdout


def test_f47_correct_bytes_pass(tmp_path):
    """Control: the untampered copy (correct bytes everywhere) passes, so the
    F47 rule rejects only genuine mismatches."""
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    result = _run_validator(pkg)
    assert result.returncode == 0, result.stdout
