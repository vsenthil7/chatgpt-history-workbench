"""Shared authorization helpers for tests (ADR-014).

``ALL_TENANTS_AUTHZ`` is entitled to every tenant id used across the suite,
so ordinary operational tests exercise the domain logic rather than the
authorization gate. Cross-tenant and authorization-specific tests build their
own narrowly-scoped contexts to prove denial.
"""

from cgwo_core.authz import StaticAuthorizationContext

#: Entitled to every tenant id that appears in the test suite.
ALL_TENANTS_AUTHZ = StaticAuthorizationContext(
    principal="test-principal",
    entitlements=frozenset({"t1", "t2", "victim", "attacker"}),
)


def authz_for(*tenant_ids: str) -> StaticAuthorizationContext:
    """A context entitled to exactly the given tenant ids."""
    return StaticAuthorizationContext(
        principal="test-principal", entitlements=frozenset(tenant_ids)
    )
