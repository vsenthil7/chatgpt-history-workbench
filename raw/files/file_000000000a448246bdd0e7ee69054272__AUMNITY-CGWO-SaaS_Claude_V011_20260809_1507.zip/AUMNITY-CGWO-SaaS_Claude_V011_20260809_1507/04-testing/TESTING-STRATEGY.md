# Testing Strategy — LOS-derived quality model

## Purpose
Testing is a product contract, not an afterthought. A green unit-test suite alone is insufficient.

## Required layers once implementation exists
1. **Unit/domain tests** — invariants, value objects, policies, state transitions and edge cases.
2. **Contract tests** — every public API/event/adapter/shared contract, including backward compatibility.
3. **Integration tests** — persistence, queues, providers, identity/tenant isolation and module boundaries.
4. **End-to-end tests** — only critical user journeys; deterministic fixtures; no dependence on uncontrolled production services.
5. **Architecture guards** — dependency direction, forbidden imports, package ownership and tenant leakage.
6. **Security/SaaS isolation tests** — cross-tenant access denial, authorization, audit integrity, secret handling.
7. **Migration/compatibility tests** — schema/event/API migration and upgrade paths.
8. **Mutation testing** — required for high-risk domain/policy code; surviving mutants become explicit work.
9. **Regression tests** — every escaped defect gets a reproducer before the fix.
10. **Documentation/RTM consistency gates** — declared requirements, tests, versions and manifests must agree.

## Coverage policy
- New executable product packages: target **100% line and branch coverage** unless a documented exception is approved.
- Coverage is not evidence of correctness; mutation, property/edge tests and contract tests remain required.
- Generated code/vendor code is excluded explicitly, never silently.

## Test determinism
No sleep-based correctness, real-clock dependency, uncontrolled network calls, random data without a fixed seed, or shared mutable external fixtures in the default suite.

## Declare-first rule
A new feature starts by declaring its requirement, owner module, public contract and tests/RTM row before implementation. Guards are allowed to fail immediately until the declared implementation exists.
