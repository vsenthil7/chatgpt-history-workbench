# Engineering Operating System — LOS learning applied

## Core rules
- **Declare first, implement second.** Requirement → ownership → contract → test/RTM declaration → code.
- **Generic before tenant-specific.** Never hard-code a customer, company, workbook, role name or field mapping into reusable domain code.
- **Bounded ownership.** A module may call another through a published contract; it may not copy that module's logic.
- **Small core.** Shared/core code is earned by reuse across bounded modules, not placed there for convenience.
- **Evidence over claims.** "tests pass" means attach machine-generated results; "100%" means line and branch evidence.
- **No hidden bypass.** Skips, xfails, ignores and exclusions are governed and justified.
- **Docs are executable governance.** Architecture, RTM, ADR, version and package manifests are quality-gated.
- **One source of truth.** Counts, package lists and version facts should be generated or checked, not duplicated manually.
- **Independent review loop.** Claude Code builds; ChatGPT independently reviews the complete ZIP; Claude corrects; repeat.

## Reusability decision before every significant component
1. Is it tenant-specific configuration/data?
2. Is it bounded-product logic?
3. Is it truly shared domain/platform capability?
4. Does another package already own it?
5. Can a contract/event/adapter remove the dependency?
6. Are we duplicating code or semantics?

The answer and ownership decision belongs in the PR/change evidence for significant additions.
