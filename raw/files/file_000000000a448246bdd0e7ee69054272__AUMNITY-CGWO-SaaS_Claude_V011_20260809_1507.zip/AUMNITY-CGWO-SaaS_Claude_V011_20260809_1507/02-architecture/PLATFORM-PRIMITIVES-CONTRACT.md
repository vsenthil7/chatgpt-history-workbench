# AUMNITY Work Platform Primitives Contract (ADR-006)

Scope reference: CGWO-SCOPE-1 / CGWO-NOTOWNED-1.

CGWO consumes the following Platform-owned primitives strictly by opaque reference and published contract. CGWO never defines, extends or persists their internal structure.

| Primitive | CGWO usage | Reference field |
|---|---|---|
| Organisation/Tenant | explicit tenant context on every protected operation | `tenant_id`, `organisation_id` |
| Actor | the resource being planned/allocated | `resource_ref` |
| Work Object | the unit of work being planned | `work_object_ref` |
| Capability | taxonomy for demand/matching/observation | `capability_ref` |
| Evidence | attachment target for review/learning outputs | `evidence_ref` |
| Policy | tenant-configurable planning/matching policy source | consumed via contract, not stored |
| Audit | all state transitions are auditable events | emitted, not stored by CGWO |
| Notification | plan-change and conflict notifications | emitted via contract |
| Identity/Workflow/Integration | authn/z, orchestration hosting, adapter transport | consumed via contract |

Contract status: DECLARED (provider side). CGWO's own consumer-side expectations for the first slice are now versioned and executable in `src/cgwo_core/contracts.py` (`cgwo-consumer-v1`, review finding F12); provider compatibility testing attaches to these once the Platform publishes its side. The domain core keeps references as opaque strings (see `src/cgwo_core/`).
