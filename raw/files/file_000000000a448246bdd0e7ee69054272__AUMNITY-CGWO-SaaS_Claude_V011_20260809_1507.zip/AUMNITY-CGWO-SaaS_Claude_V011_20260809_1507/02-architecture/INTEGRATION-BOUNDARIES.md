# Integration Boundaries (ADR-001, ADR-005, UraiFlow)

Scope reference: CGWO-SCOPE-1 / CGWO-NOTOWNED-1.

## Tracker/timesheet bridges (ADR-001)
- CGWO owns Plan Item, Capacity Allocation and Execution Session domain state.
- External trackers/timesheets are systems of record, reached through bridge adapters: planned-work push (outbound), actuals/`TimeRecorded` pull or event ingestion (inbound).
- Every bridged data element has a declared system of record (baseline D004 upheld).
- Pilot workbooks (e.g. the IPBS Phase-0 tracker) are fixtures/evidence only; no workbook structure enters reusable code.

## Recruitment/training (ADR-005)
- Outbound only: `CapabilityGapDetected`, `TrainingNeedRaised`, `RecruitmentNeedRaised`, optionally materialised as Platform Work Objects.
- Inbound only: `CapabilityObserved` updates against Platform Capability references.
- No ATS/LMS entities inside CGWO.

## UraiFlow
- UraiFlow owns audio, transcription and conversation extraction.
- CGWO consumes **record proposals** (proposed tracker/time/follow-up/availability records) as inbound suggestions requiring confirmation before they mutate CGWO state.
- Contract status: consumer-side shapes implemented and tested in `src/cgwo_core/contracts.py` (`TimeRecordProposal`, `AvailabilityProposal`, version `cgwo-consumer-v1`); the confirmation workflow and provider-side compatibility remain DECLARED.
- Wire value grammar (ADR-012): dates are ISO-8601 `YYYY-MM-DD` strings; integers are exact ints or ASCII decimal digit strings matching `[0-9]+` (no sign/whitespace/Unicode digits — see `WIRE_INT_GRAMMAR`); enum values are exact value strings (e.g. `"SUPERVISORY"`). Unknown or non-canonical values are rejected deterministically.

## Adapter categories (carried forward from baseline)
HR/resource master, calendar/leave, project/work demand, LMS/certification, payroll/timesheet output, CRM/client context, UraiFlow record proposals. Initial-load (file), batch, API and event transports all remain supported patterns.
