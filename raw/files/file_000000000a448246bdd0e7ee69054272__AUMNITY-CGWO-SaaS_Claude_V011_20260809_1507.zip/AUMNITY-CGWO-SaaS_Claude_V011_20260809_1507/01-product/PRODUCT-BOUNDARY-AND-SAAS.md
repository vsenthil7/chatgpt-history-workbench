# Product Boundary and SaaS Model

## Boundary
Canonical scope: **CGWO-SCOPE-1** in `01-product/CANONICAL-SCOPE.md` (ADR-004).

## Not owned
Canonical exclusion: **CGWO-NOTOWNED-1** in `01-product/CANONICAL-SCOPE.md` (ADR-004).

## Commercial/operating model
Products are reusable SaaS. IPBS is currently one tenant/user and may sell, support or implement the product. Other AT/WE companies and external customers may later become tenants, operators, implementation partners or channels. Product ownership and domain code therefore cannot be tied to IPBS.

## Tenant-neutral design
Use organisation/tenant configuration, policy, adapters and feature entitlements instead of customer-specific branches. A customer name may appear in pilot fixtures/docs, never as a reusable domain assumption.
