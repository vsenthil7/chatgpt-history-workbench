# Versioning and Packaging

## Product versions
Use semantic versions for releasable SaaS/API behavior. Incubating architecture may start at 0.x.y. Breaking public contracts require explicit migration and version rationale.

## AI review artifact versions
Use an independent review/build sequence in filenames so product SemVer is not confused with AI iteration:
`<Product>_<AIName>_VNNN_YYYYMMDD_HHMM.zip`

## Every ZIP contains
- source and tests (when implementation begins);
- current product/architecture docs;
- RTM and ADR/decision evidence;
- machine-readable package manifest with SHA-256 hashes;
- gate evidence or explicit NOT-YET-IMPLEMENTED markers;
- handoff/change rationale.
