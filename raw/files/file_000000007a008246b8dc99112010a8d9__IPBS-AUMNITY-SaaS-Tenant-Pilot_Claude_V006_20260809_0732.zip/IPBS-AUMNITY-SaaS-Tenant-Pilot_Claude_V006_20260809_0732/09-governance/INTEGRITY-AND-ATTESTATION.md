# Integrity and Attestation Procedure (ADR-0005, V003)

## Two layers, no excluded directories

**Layer 1 — internal payload manifest.** `PACKAGE-MANIFEST.json` lists every file in the package except itself, with byte size and SHA-256. `validate_manifest.py` verifies exact inventory (no omissions, no unexpected files, no duplicates), bytes and hashes. There is no directory exempt from this check; corrupting or adding ANY file — including every evidence file — is detected (negative tests M1–M3).

**Layer 2 — external release attestation.** Facts that depend on the finished manifest or the finished ZIP cannot live inside the ZIP without self-reference or staleness. They are recorded in an attestation document shipped ALONGSIDE the artifact (and in the handoff message): final ZIP SHA-256 · exact build command + BUILD_TIMESTAMP · manifest-validation transcript over the exact final payload · final-payload smoke transcript (clean extraction of the shipped ZIP, all validators re-run) · deterministic double-build hash comparison.

## Build sequence (eliminates V002's circularity)

1. Write/modify all payload content.
2. Generate payload-stage evidence into `13-evidence/`: workbook inventory run, starter/register validator transcripts, negative-test transcript.
3. Generate the manifest over the complete tree (`generate_manifest.py`, BUILD_TIMESTAMP-deterministic).
4. **Freeze the payload.** Nothing is added or changed after this point.
5. Externally: validate the manifest, build the ZIP twice (deterministic packaging), compare hashes, extract the shipped ZIP cleanly, re-run every validator from the extraction, compute the final SHA-256.
6. Write the attestation document next to the artifact.

## What each layer proves

| Claim | Proven by |
|---|---|
| Every packaged file is exactly as built (integrity) | Layer 1: manifest + validate_manifest, runnable by any holder of the ZIP |
| Evidence files were not altered after build | Layer 1 (they are manifest-covered) |
| The shipped artifact is this exact payload | Layer 2: attestation hash of the final ZIP |
| The build is reproducible | Layer 2: double-build identical hashes + recorded command |
| The exact final payload passes all validators | Layer 2: smoke transcript from a clean extraction of the shipped ZIP |

The V002 statement "final ZIP independently re-extracted/re-validated" is made precisely here: the attestation's smoke section IS that re-validation, and it names the hash it was run against.
