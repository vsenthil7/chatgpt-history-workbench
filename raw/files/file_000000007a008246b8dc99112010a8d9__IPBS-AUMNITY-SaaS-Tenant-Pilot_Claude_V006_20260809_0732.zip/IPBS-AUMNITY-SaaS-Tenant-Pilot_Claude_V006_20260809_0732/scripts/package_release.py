#!/usr/bin/env python3
"""Deterministic release packaging (G11). Produces a byte-reproducible ZIP:
sorted entry order, fixed timestamp from BUILD_TIMESTAMP, fixed permissions,
no extra attributes. Building the same tree twice yields identical SHA-256."""
from pathlib import Path
import hashlib, os, sys, zipfile

def build(root: Path, out_zip: Path, stamp):
    files = sorted(p for p in root.rglob('*') if p.is_file())
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        for p in files:
            arc = f'{root.name}/{p.relative_to(root).as_posix()}'
            zi = zipfile.ZipInfo(arc, date_time=stamp)
            zi.external_attr = 0o644 << 16
            zi.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(zi, p.read_bytes())
    return hashlib.sha256(out_zip.read_bytes()).hexdigest()

if __name__ == '__main__':
    root = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    ts = os.environ.get('BUILD_TIMESTAMP', '2026-08-08T22:37:00')
    y, mo, d = int(ts[0:4]), int(ts[5:7]), int(ts[8:10])
    h, mi, s = int(ts[11:13]), int(ts[14:16]), int(ts[17:19])
    digest = build(root, out, (y, mo, d, h, mi, s))
    print(f'{out.name} sha256={digest}')
