#!/usr/bin/env python3
"""G01: manifest/integrity validation. Checks: schema, required metadata, exact
inventory (no omissions, no unexpected files, no duplicates), byte sizes, SHA-256,
artifact naming. ADR-0005 (V003): NO excluded directories — every file except the
manifest itself is inside the integrity boundary, including all evidence files."""
from pathlib import Path
import hashlib, json, re, sys

ROOT = Path(__file__).resolve().parents[1]
MPATH = ROOT / 'PACKAGE-MANIFEST.json'
errors = []

try:
    m = json.loads(MPATH.read_text(encoding='utf-8'))
except Exception as e:
    print(f'MANIFEST VALIDATION: FAIL\n - cannot parse manifest: {e}'); sys.exit(1)

for key in ('schema', 'created', 'project', 'first_page', 'ai_artifact', 'files'):
    if key not in m:
        errors.append(f'missing manifest key: {key}')
if m.get('schema') != 'aumnity-starter-manifest/v1':
    errors.append(f"unexpected schema: {m.get('schema')}")
art = m.get('ai_artifact', '')
if not re.fullmatch(r'IPBS-AUMNITY-SaaS-Tenant-Pilot_(Claude|ChatGPT)_V\d{3}_\d{8}_\d{4}\.zip', art):
    errors.append(f'ai_artifact name violates VERSIONING-AND-PACKAGING pattern: {art}')

entries = m.get('files', [])
paths = [e.get('path') for e in entries]
dups = {p for p in paths if paths.count(p) > 1}
if dups:
    errors.append(f'duplicate manifest entries: {sorted(dups)}')

actual = {p.relative_to(ROOT).as_posix()
          for p in ROOT.rglob('*') if p.is_file() and p.name != 'PACKAGE-MANIFEST.json'}
listed = set(paths)
for p in sorted(listed - actual):
    errors.append(f'manifest lists missing file: {p}')
for p in sorted(actual - listed):
    errors.append(f'file not in manifest: {p}')

checked = 0
for e in entries:
    p = ROOT / e['path']
    if not p.is_file():
        continue
    data = p.read_bytes()
    if len(data) != e.get('bytes'):
        errors.append(f"byte mismatch {e['path']}: manifest {e.get('bytes')} actual {len(data)}")
    digest = hashlib.sha256(data).hexdigest()
    if digest != e.get('sha256'):
        errors.append(f"sha256 mismatch {e['path']}")
    checked += 1

if errors:
    print('MANIFEST VALIDATION: FAIL')
    for e in errors: print(' -', e)
    sys.exit(1)
print(f'MANIFEST VALIDATION: PASS ({checked} files: inventory exact, no duplicates, '
      'bytes and SHA-256 verified; zero excluded directories — all evidence inside the integrity boundary)')
