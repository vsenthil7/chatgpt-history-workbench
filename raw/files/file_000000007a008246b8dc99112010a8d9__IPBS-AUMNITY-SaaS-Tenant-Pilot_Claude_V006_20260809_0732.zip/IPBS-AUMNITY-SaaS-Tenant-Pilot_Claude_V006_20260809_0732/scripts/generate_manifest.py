#!/usr/bin/env python3
"""Regenerate PACKAGE-MANIFEST.json deterministically. 'created' comes from the
BUILD_TIMESTAMP env var (ISO-8601) — never wall clock. ADR-0005 (V003): the manifest
covers EVERY file except itself; there are NO excluded directories. Manifest-dependent
proofs (final hash, smoke over the exact final payload) live in the external release
attestation shipped alongside the ZIP, never inside it."""
from pathlib import Path
import hashlib, json, os, sys

ROOT = Path(__file__).resolve().parents[1]
ts = os.environ.get('BUILD_TIMESTAMP')
if not ts:
    sys.exit('BUILD_TIMESTAMP env var required (deterministic builds; no wall clock)')

files = sorted(p for p in ROOT.rglob('*') if p.is_file() and p.name != 'PACKAGE-MANIFEST.json')
entries = []
for p in files:
    data = p.read_bytes()
    entries.append({'path': p.relative_to(ROOT).as_posix(), 'bytes': len(data),
                    'sha256': hashlib.sha256(data).hexdigest()})
manifest = {'schema': 'aumnity-starter-manifest/v1',
            'created': ts,
            'project': 'IPBS AUMNITY SaaS Tenant Pilot',
            'first_page': '00001-IPBS-Tenant-Validation-Baseline',
            'ai_artifact': f"IPBS-AUMNITY-SaaS-Tenant-Pilot_{os.environ.get('BUILD_LABEL','Claude_V003_20260808_2309')}.zip",
            'files': entries}
(ROOT / 'PACKAGE-MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(f'manifest regenerated deterministically: {len(entries)} files, created={ts}')
