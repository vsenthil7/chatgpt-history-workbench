#!/usr/bin/env python3
"""G10 register/document consistency validation, V006 (final closure: ADR-0009 tenant trust anchor; registry active_from enforcement).
The lifecycle is enforced as durable HISTORY, not snapshot schemas: a later state must
machine-prove every required earlier transition and retain its evidence.

Check groups (PASS covers exactly these, nothing broader):
 1. CSV structure (schema v2), unique IDs, required fields.
 2. Vocabulary and ownership model (owner/UNRESOLVED/decision_scope/candidates).
 3. LIFECYCLE EVENT LOG (12-requirements/lifecycle-events.csv): every RPR has a
    history starting at OBSERVED; each transition has a legal predecessor
    (CLASSIFIED←OBSERVED; PROPOSED←OBSERVED/CLASSIFIED; PROMOTED←CLASSIFIED/PROPOSED;
    IMPLEMENTED←PROMOTED; VALIDATED←IMPLEMENTED); timestamps non-decreasing; no
    duplicate events; current status == latest event. State skipping is impossible:
    VALIDATED without recorded PROMOTED and IMPLEMENTED events fails.
 4. STAGE EVIDENCE PERSISTENCE: at status ≥ PROMOTED the PROMOTED event must retain
    a BACKLOG: reference; at ≥ IMPLEMENTED the IMPLEMENTED event must retain
    PRODUCT-RELEASE:/CONTRACT: provenance; deleting earlier-stage evidence fails.
 5. EXTERNAL IMPLEMENTATION PROVENANCE: implementation_evidence must contain
    PRODUCT-RELEASE:<product>@<artifact> (product == implementation_product,
    artifact == implementation_version, artifact matches the registry pattern),
    CONTRACT:<ns.vN> (== implementation_contract_version, namespace from registry),
    and RTM:/TEST: cross-reference. A generic FILE: reference is NOT provenance.
    Products resolve against 09-governance/EXTERNAL-PRODUCT-REGISTRY.csv (ACTIVE,
    approval recorded); pilot self-reference rejected.
 6. VALIDATION EVIDENCE SEMANTICS: ACCEPTANCE/USAGE/FINDINGS/CONTRACT-TEST resolve
    to JSON files matching per-class schemas (rpr_id match, named actors, REAL
    parsed ISO dates, outcome ACCEPT[-WITH-CONDITIONS], result PASS, product/version
    consistency, FINDINGS→USAGE linkage). TENANT BINDING: ACCEPTANCE and USAGE
    tenant must equal the canonical tenant_id in 09-governance/TENANT-IDENTITY.json.
    TEMPORAL POLICY: acceptance/usage cannot predate the IMPLEMENTED instant;
    findings cannot predate their source usage; the VALIDATED event cannot predate
    the evidence it relies on; contract tests may legitimately predate formal
    release (documented) but not the VALIDATED event.
    Lifecycle timestamps must be timezone-aware ISO-8601 and are compared AS UTC
    INSTANTS, not strings — offset games cannot invert chronology.
    TENANT TRUST ANCHOR (ADR-0009): the canonical TENANT-IDENTITY.json is itself
    validated against the machine-readable 'Pilot-tenant-id:' authority carried by
    an ACCEPTED governance ADR — exactly one declaration must exist, and drift of
    the canonical tenant away from the anchored pilot identity fails validation.
    REGISTRY TEMPORAL AUTHORITY: active_from must parse as a real date, and an
    IMPLEMENTED event cannot predate its product's governed active_from.
    superseded_by is an informational pointer (a SUPERSEDED product is not ACTIVE
    and therefore already unusable); no retirement logic is invented here.
 7. Structured evidence reference resolution (WB:/F:/ADR:/DEP:/FILE: exact objects).
 8. ADR↔RPR matrix (PROPOSED caps gated RPRs at PROPOSED; REJECTED/SUPERSEDED rules).
 9. Narrative consistency (totals, owner/status counts, PROPOSED set, analytics line).
10. RTM count string; workbook machine counters in the analysis.
"""
from pathlib import Path
from datetime import date, datetime, timezone
import csv, json, re, sys

ROOT = Path(__file__).resolve().parents[1]
errors = []
TENANT_ID = json.loads((ROOT / '09-governance/TENANT-IDENTITY.json').read_text(encoding='utf-8'))['tenant_id']

def parse_instant(rid, value, where):
    """Timezone-aware ISO-8601 → UTC datetime; naive or unparseable → error, None."""
    try:
        dt = datetime.fromisoformat(str(value))
    except Exception:
        errors.append(f'{rid}: {where}: timestamp is not valid ISO-8601: {value!r}'); return None
    if dt.tzinfo is None:
        errors.append(f'{rid}: {where}: timestamp must be timezone-aware: {value!r}'); return None
    return dt.astimezone(timezone.utc)

def parse_ev_date(rid, cls, value):
    """Real calendar date (or tz-aware datetime) → date in UTC; regex shapes rejected."""
    s = str(value)
    try:
        if 'T' in s:
            dt = datetime.fromisoformat(s)
            return (dt if dt.tzinfo is None else dt.astimezone(timezone.utc)).date()
        return date.fromisoformat(s)
    except Exception:
        errors.append(f'{rid}: {cls} evidence date does not parse as a real calendar date: {value!r}')
        return None

OWNERS = {'PLATFORM', 'CGWO', 'URAIFLOW', 'TENANT-IPBS', 'NEW-MODULE', 'UNRESOLVED'}
STATUS_ORDER = ['OBSERVED', 'CLASSIFIED', 'PROPOSED', 'PROMOTED', 'IMPLEMENTED', 'VALIDATED']
ALLOWED_PREV = {'CLASSIFIED': {'OBSERVED'}, 'PROPOSED': {'OBSERVED', 'CLASSIFIED'},
                'PROMOTED': {'CLASSIFIED', 'PROPOSED'}, 'IMPLEMENTED': {'PROMOTED'},
                'VALIDATED': {'IMPLEMENTED'}}
CLASS_OWNER = {'1': 'PLATFORM', '2': 'CGWO', '3': 'URAIFLOW', '4': 'TENANT-IPBS', '5': 'NEW-MODULE'}
CANDIDATE_TOKENS = OWNERS - {'UNRESOLVED'} | {'EXTERNAL-SOR', 'PER-CONTEXT'}
SCHEMA = ['id', 'ipbs_observation', 'generic_requirement', 'classification', 'owner',
          'decision_scope', 'candidate_owners', 'status', 'implementation_product',
          'implementation_version', 'implementation_contract_version',
          'implementation_evidence', 'validation_evidence']
IMPL_FIELDS = SCHEMA[8:12]
EV_CLASSES = ('ACCEPTANCE', 'USAGE', 'FINDINGS', 'CONTRACT-TEST')

def sidx(s): return STATUS_ORDER.index(s) if s in STATUS_ORDER else -1

# --- load ---------------------------------------------------------------------
with (ROOT / '12-requirements/promotion-register.csv').open(encoding='utf-8') as f:
    reader = csv.DictReader(f)
    if reader.fieldnames != SCHEMA:
        print('REGISTER/DOCS CONSISTENCY: FAIL\n - CSV columns do not match schema v2'); sys.exit(1)
    rows = list(reader)
row_by_id = {r['id']: r for r in rows}
md = (ROOT / '12-requirements/REQUIREMENT-PROMOTION-REGISTER.md').read_text(encoding='utf-8')
analysis = (ROOT / '11-analysis/BASELINE-ANALYSIS.md').read_text(encoding='utf-8')
rtm = (ROOT / '06-traceability/RTM.md').read_text(encoding='utf-8')
deps = (ROOT / '12-requirements/CROSS-PRODUCT-DEPENDENCIES.md').read_text(encoding='utf-8')
inv = json.loads((ROOT / '11-analysis/workbook-inventory.json').read_text(encoding='utf-8'))
sheets = {s['name']: s for s in inv['sheets']}
findings = set(re.findall(r'\| \**\s*(F-\d{2})\**', analysis))
dep_ids = set(re.findall(r'\| (X-\d{2}) \|', deps))
adr_files = {}
for p in (ROOT / '02-architecture/ADR').glob('ADR-*.md'):
    adr_id = '-'.join(p.stem.split('-')[:2]); text = p.read_text(encoding='utf-8')
    sm = re.findall(r'\*\*Status:\*\* (\w+)', text)
    gates = set()
    for line in re.findall(r'^Gates: (.+)$', text, re.M):
        gates |= {g.strip() for g in line.split(',')}
    succ = re.search(r'^Superseded-by: (ADR-\d{4})$', text, re.M)
    boot = re.search(r'^Bootstrap-products: (.+)$', text, re.M)
    tenant_decls = re.findall(r'^Pilot-tenant-id: (.+)$', text, re.M)
    approves = set(re.findall(r'^Approves-product: (.+)$', text, re.M))
    adr_files[adr_id] = {'status': sm[-1] if sm else 'UNKNOWN', 'gates': gates,
                         'successor': succ.group(1) if succ else None,
                         'bootstrap': {x.strip() for x in boot.group(1).split(',')} if boot else set(),
                         'approves': {x.strip() for x in approves},
                         'tenant_decls': [x.strip() for x in tenant_decls]}

# external product registry (governance data, not validator code)
registry = {}
with (ROOT / '09-governance/EXTERNAL-PRODUCT-REGISTRY.csv').open(encoding='utf-8') as f:
    for pr in csv.DictReader(f):
        registry[pr['product_id']] = pr
        if pr['status'] == 'ACTIVE':
            apr, pid = pr['approval_adr'], pr['product_id']
            if apr not in adr_files:
                errors.append(f'registry {pid}: approval reference {apr!r} is not an existing ADR (the STARTER bypass is abolished — every ACTIVE product requires an ACCEPTED ADR)')
            elif adr_files[apr]['status'] != 'ACCEPTED':
                errors.append(f'registry {pid}: approval ADR {apr} is {adr_files[apr]["status"]}, not ACCEPTED')
            elif pid not in (adr_files[apr]['bootstrap'] | adr_files[apr]['approves']):
                errors.append(f'registry {pid}: approval ADR {apr} does not name this product (Bootstrap-products/Approves-product) — an ADR cannot approve products it never mentions')

# tenant trust anchor (ADR-0009): authority → canonical identity → evidence
anchor_decls = [(aid, d) for aid, info in adr_files.items() for d in info['tenant_decls']]
if not anchor_decls:
    errors.append('no Pilot-tenant-id authority declaration found in any ADR — the canonical tenant has no trust anchor (ADR-0009)')
elif len(anchor_decls) > 1:
    errors.append(f'duplicate/conflicting Pilot-tenant-id declarations: {anchor_decls} — exactly one governance authority is required')
else:
    anchor_adr, anchor_tenant = anchor_decls[0]
    if adr_files[anchor_adr]['status'] != 'ACCEPTED':
        errors.append(f'Pilot-tenant-id authority {anchor_adr} is {adr_files[anchor_adr]["status"]}, not ACCEPTED')
    if TENANT_ID != anchor_tenant:
        errors.append(f'canonical TENANT-IDENTITY tenant_id {TENANT_ID!r} has drifted from the anchored pilot identity {anchor_tenant!r} ({anchor_adr}) — internal consistency below a drifted root proves nothing about this pilot')

# registry active_from: real date, enforced against IMPLEMENTED instants (checked per-row below)
for pid, pr in registry.items():
    try:
        pr['_active_from'] = date.fromisoformat(pr['active_from'])
    except Exception:
        errors.append(f'registry {pid}: active_from does not parse as a real date: {pr["active_from"]!r}')
        pr['_active_from'] = None

# lifecycle event log
events_by_rpr = {}
with (ROOT / '12-requirements/lifecycle-events.csv').open(encoding='utf-8') as f:
    evrows = list(csv.DictReader(f))
seen_eids = set()
for e in evrows:
    if e['event_id'] in seen_eids: errors.append(f"duplicate event_id {e['event_id']}")
    seen_eids.add(e['event_id'])
    if e['event'] not in STATUS_ORDER: errors.append(f"{e['event_id']}: unknown event {e['event']}")
    if e['rpr_id'] not in row_by_id: errors.append(f"{e['event_id']}: event for unknown {e['rpr_id']}")
    events_by_rpr.setdefault(e['rpr_id'], []).append(e)

def check_history(rid, st):
    evs = events_by_rpr.get(rid)
    if not evs:
        errors.append(f'{rid}: no lifecycle history — every RPR requires an event trail'); return {}
    names = [e['event'] for e in evs]
    if names[0] != 'OBSERVED':
        errors.append(f'{rid}: history must start at OBSERVED')
    if len(set(names)) != len(names):
        errors.append(f'{rid}: duplicate lifecycle events {sorted(set(n for n in names if names.count(n) > 1))}')
    prev_name, prev_inst = None, None
    for e in evs:
        inst = parse_instant(rid, e['timestamp'], f"event {e['event']}")
        if not e.get('recorded_by', '').strip():
            errors.append(f"{rid}: event {e['event']} has empty recorded_by (minimal actor record; authoritative identity deferred to the Platform audit primitive)")
        if prev_name is not None:
            allowed = ALLOWED_PREV.get(e['event'], set())
            if prev_name not in allowed:
                errors.append(f"{rid}: illegal transition {prev_name} → {e['event']} (allowed predecessors: {sorted(allowed)})")
            if inst is not None and prev_inst is not None and inst < prev_inst:
                errors.append(f"{rid}: event chronology violated at {e['event']} — compared as UTC instants, not strings ({inst.isoformat()} < {prev_inst.isoformat()})")
        prev_name = e['event']
        prev_inst = inst if inst is not None else prev_inst
        e['_utc'] = inst
    if names[-1] != st:
        errors.append(f'{rid}: status {st} != latest lifecycle event {names[-1]} — status is a projection of history, not a free cell')
    by_name = {e['event']: e for e in evs}
    # a later state must PROVE earlier transitions happened
    if sidx(st) >= sidx('PROMOTED') and 'PROMOTED' not in by_name:
        errors.append(f'{rid}: status {st} without a recorded PROMOTED event — state skipping')
    if sidx(st) >= sidx('IMPLEMENTED') and 'IMPLEMENTED' not in by_name:
        errors.append(f'{rid}: status {st} without a recorded IMPLEMENTED event — state skipping')
    if st == 'VALIDATED' and 'VALIDATED' not in by_name:
        errors.append(f'{rid}: VALIDATED status without VALIDATED event')
    # stage evidence must PERSIST in the history
    if 'PROMOTED' in by_name and sidx(st) >= sidx('PROMOTED') and 'BACKLOG:' not in by_name['PROMOTED']['evidence']:
        errors.append(f'{rid}: PROMOTED event has lost its BACKLOG: evidence — promotion history must persist')
    if 'IMPLEMENTED' in by_name and sidx(st) >= sidx('IMPLEMENTED'):
        iev = by_name['IMPLEMENTED']['evidence']
        if 'PRODUCT-RELEASE:' not in iev or 'CONTRACT:' not in iev:
            errors.append(f'{rid}: IMPLEMENTED event has lost its provenance (PRODUCT-RELEASE:/CONTRACT:) — implementation history must persist')
    return by_name

# --- provenance & semantic evidence helpers -----------------------------------
def check_impl_provenance(rid, r, evidence_str, where):
    toks = [t.strip() for t in evidence_str.split(';') if t.strip()]
    kinds = {t.split(':', 1)[0] for t in toks}
    if kinds and kinds <= {'FILE'}:
        errors.append(f'{rid}: {where}: a generic FILE: reference is not implementation provenance')
    for need in ('PRODUCT-RELEASE', 'CONTRACT'):
        if need not in kinds:
            errors.append(f'{rid}: {where}: missing {need}: provenance token')
    if not ({'RTM', 'TEST'} & kinds):
        errors.append(f'{rid}: {where}: missing RTM:/TEST: cross-reference into the owning product')
    for t in toks:
        kind, _, rest = t.partition(':')
        if kind == 'PRODUCT-RELEASE':
            prod, _, artifact = rest.partition('@')
            if prod != r['implementation_product']:
                errors.append(f'{rid}: {where}: PRODUCT-RELEASE product {prod} != implementation_product')
            reg = registry.get(prod)
            if reg and not re.fullmatch(reg['artifact_name_pattern'], artifact):
                errors.append(f'{rid}: {where}: artifact {artifact} does not match registry pattern for {prod}')
            if artifact != r['implementation_version']:
                errors.append(f'{rid}: {where}: PRODUCT-RELEASE artifact != implementation_version')
        elif kind == 'CONTRACT':
            if rest != r['implementation_contract_version']:
                errors.append(f'{rid}: {where}: CONTRACT {rest} != implementation_contract_version')
            reg = registry.get(r['implementation_product'])
            if reg and not rest.startswith(reg['contract_namespace'] + '.'):
                errors.append(f'{rid}: {where}: contract namespace does not match registry ({reg["contract_namespace"]})')
        elif kind == 'RTM' or kind == 'TEST':
            pr = rest.split(':', 1)[0]
            if pr != r['implementation_product']:
                errors.append(f'{rid}: {where}: {kind} reference names product {pr} != implementation_product')
        elif kind == 'HASH':
            if not re.fullmatch(r'sha256:[0-9a-f]{64}', rest):
                errors.append(f'{rid}: {where}: HASH must be sha256:<64 hex>')
        elif kind == 'FILE':
            if not (ROOT / rest).is_file():
                errors.append(f'{rid}: {where}: FILE ref does not resolve: {t}')
        else:
            errors.append(f'{rid}: {where}: unknown provenance token {kind}:')

def load_ev_json(rid, cls, path):
    p = ROOT / path
    if not p.is_file():
        errors.append(f'{rid}: {cls} evidence file missing: {path}'); return None
    if p.stat().st_size == 0:
        errors.append(f'{rid}: {cls} evidence file is empty — an empty file is not evidence: {path}'); return None
    try:
        return json.loads(p.read_text(encoding='utf-8'))
    except Exception:
        errors.append(f'{rid}: {cls} evidence is not valid JSON per its schema: {path}'); return None

def check_validation_semantics(rid, r, refs, hist):
    got, loaded = {}, {}
    for ref in refs:
        for cls in EV_CLASSES:
            if ref.startswith(cls + ':FILE:'):
                got[cls] = ref[len(cls) + 6:]
    for cls in EV_CLASSES:
        if cls not in got:
            errors.append(f'{rid}: VALIDATED missing {cls}: evidence class'); continue
        data = load_ev_json(rid, cls, got[cls])
        if data is None: continue
        def need(*fields):
            for fld in fields:
                if not str(data.get(fld, '')).strip():
                    errors.append(f'{rid}: {cls} evidence missing required field {fld}')
        if str(data.get('rpr_id', '')) != rid:
            errors.append(f"{rid}: {cls} evidence rpr_id={data.get('rpr_id')} — evidence bound to a different requirement")
        ev_date = parse_ev_date(rid, cls, data.get('date', ''))
        data['_date'] = ev_date
        if cls in ('ACCEPTANCE', 'USAGE') and str(data.get('tenant', '')) != TENANT_ID:
            errors.append(f"{rid}: {cls} tenant {data.get('tenant')!r} != canonical tenant_id {TENANT_ID!r} — another tenant's evidence can never validate this pilot's requirement")
        if cls == 'ACCEPTANCE':
            need('tenant', 'acceptor', 'acceptor_role', 'product', 'version')
            if data.get('outcome') not in ('ACCEPT', 'ACCEPT-WITH-CONDITIONS'):
                errors.append(f"{rid}: ACCEPTANCE outcome {data.get('outcome')!r} does not support VALIDATED")
            if data.get('product') != r['implementation_product'] or data.get('version') != r['implementation_version']:
                errors.append(f'{rid}: ACCEPTANCE product/version does not match implementation fields')
        elif cls == 'USAGE':
            need('tenant', 'scenario', 'actor', 'product', 'version', 'result')
            if data.get('product') != r['implementation_product'] or data.get('version') != r['implementation_version']:
                errors.append(f'{rid}: USAGE product/version does not match implementation fields')
        elif cls == 'FINDINGS':
            need('reviewed_by')
            src = str(data.get('source_usage', ''))
            if not src or not (ROOT / src).is_file():
                errors.append(f'{rid}: FINDINGS source_usage does not reference existing usage evidence')
            else:
                data['_src'] = src
            fnd = data.get('findings')
            if fnd is None or (fnd != 'NONE' and not isinstance(fnd, list)):
                errors.append(f'{rid}: FINDINGS must list finding IDs or state reviewed NONE')
        elif cls == 'CONTRACT-TEST':
            need('product', 'test_id', 'artifact')
            if data.get('result') != 'PASS':
                errors.append(f"{rid}: CONTRACT-TEST result {data.get('result')!r} — only PASS supports VALIDATED")
            if data.get('contract_version') != r['implementation_contract_version']:
                errors.append(f'{rid}: CONTRACT-TEST contract_version mismatch')
            if data.get('product') != r['implementation_product']:
                errors.append(f'{rid}: CONTRACT-TEST product mismatch')
        loaded[cls] = data
    # temporal policy (day precision for evidence; documented in VALIDATION-EVIDENCE-CRITERIA):
    impl_ev = hist.get('IMPLEMENTED'); val_ev = hist.get('VALIDATED')
    impl_d = impl_ev['_utc'].date() if impl_ev and impl_ev.get('_utc') else None
    val_d = val_ev['_utc'].date() if val_ev and val_ev.get('_utc') else None
    for cls in ('ACCEPTANCE', 'USAGE'):
        d = loaded.get(cls, {}).get('_date')
        if d and impl_d and d < impl_d:
            errors.append(f'{rid}: {cls} dated {d} precedes the IMPLEMENTED instant ({impl_d}) — evidence cannot pre-date the implementation it validates')
    fd = loaded.get('FINDINGS', {})
    ud = loaded.get('USAGE', {}).get('_date')
    if fd.get('_date') and ud and fd['_date'] < ud:
        errors.append(f"{rid}: FINDINGS dated {fd['_date']} precede their source USAGE ({ud})")
    if val_d:
        for cls in EV_CLASSES:
            d = loaded.get(cls, {}).get('_date')
            if d and d > val_d:
                errors.append(f'{rid}: VALIDATED event ({val_d}) precedes its own {cls} evidence ({d}) — validation cannot rely on evidence from its future')
    # CONTRACT-TEST lower bound deliberately open: pre-release contract testing is a
    # legitimate engineering workflow (documented policy); upper bound enforced above.

def resolve_ref(rid, ref, allow_lifecycle=False):
    ref = ref.strip()
    if not ref: return
    parts = ref.split(':'); kind = parts[0]
    if kind == 'WB':
        if len(parts) < 2 or parts[1] not in sheets:
            errors.append(f'{rid}: WB ref unknown sheet: {ref}'); return
        sh = sheets[parts[1]]
        if len(parts) >= 3:
            col = parts[2]
            if col not in sh['headers']:
                errors.append(f'{rid}: WB ref unknown column: {ref}'); return
            if len(parts) == 4:
                if parts[3] != 'FORMULA':
                    errors.append(f'{rid}: WB ref bad flag: {ref}')
                elif col not in sh['preseeded_formula_cells_by_column']:
                    errors.append(f'{rid}: FORMULA flag on non-formula column: {ref}')
    elif kind == 'F':
        if len(parts) != 2 or parts[1] not in findings: errors.append(f'{rid}: unknown finding ref: {ref}')
    elif kind == 'ADR':
        if len(parts) != 2 or parts[1] not in adr_files: errors.append(f'{rid}: unknown ADR ref: {ref}')
    elif kind == 'DEP':
        if len(parts) != 2 or parts[1] not in dep_ids: errors.append(f'{rid}: unknown dependency ref: {ref}')
    elif kind == 'FILE':
        if not (ROOT / ref[5:]).is_file():
            errors.append(f'{rid}: FILE ref does not resolve to exact path: {ref}')
    elif kind in {'BACKLOG'} | set(EV_CLASSES):
        if not allow_lifecycle:
            errors.append(f'{rid}: lifecycle token {kind}: not permitted at this status')
    else:
        errors.append(f'{rid}: unstructured evidence reference: {ref}')

# --- per-row checks -----------------------------------------------------------
ids = [r['id'] for r in rows]
if len(ids) != len(set(ids)): errors.append('duplicate register IDs')
by_owner, by_status, proposed_ids = {}, {}, []
for r in rows:
    rid, st = r['id'], r['status']
    if not re.fullmatch(r'RPR-\d{3}', rid): errors.append(f'{rid}: malformed ID')
    for field in ('ipbs_observation', 'generic_requirement', 'validation_evidence'):
        if not r[field].strip(): errors.append(f'{rid}: empty {field}')
    if r['owner'] not in OWNERS: errors.append(f"{rid}: invalid owner {r['owner']}")
    if st not in STATUS_ORDER: errors.append(f"{rid}: invalid status {st}"); continue
    if r['classification'] not in CLASS_OWNER: errors.append(f"{rid}: invalid classification")

    if r['owner'] == 'UNRESOLVED':
        if r['decision_scope'] != 'CROSS-PRODUCT':
            errors.append(f'{rid}: UNRESOLVED requires decision_scope=CROSS-PRODUCT')
        cands = [c for c in r['candidate_owners'].split('|') if c]
        if not cands or any(c not in CANDIDATE_TOKENS for c in cands):
            errors.append(f'{rid}: UNRESOLVED requires valid candidate_owners, got {r["candidate_owners"]!r}')
        if st != 'PROPOSED': errors.append(f'{rid}: UNRESOLVED requires status PROPOSED, is {st}')
        if not re.search(r'(ADR:ADR-\d{4}|DEP:X-\d{2})', r['validation_evidence']):
            errors.append(f'{rid}: UNRESOLVED requires ADR/DEP reference')
    else:
        if r['decision_scope'] or r['candidate_owners']:
            errors.append(f'{rid}: decision_scope/candidate_owners only valid for UNRESOLVED')
        if r['owner'] == 'NEW-MODULE':
            if r['classification'] != '5': errors.append(f'{rid}: NEW-MODULE requires class 5')
            if st not in {'PROPOSED', 'PROMOTED'}: errors.append(f'{rid}: NEW-MODULE requires PROPOSED/PROMOTED')
        elif CLASS_OWNER[r['classification']] != r['owner']:
            errors.append(f'{rid}: classification/owner mismatch')

    hist = check_history(rid, st)

    impl_set = [f for f in IMPL_FIELDS if r[f].strip()]
    if sidx(st) < sidx('IMPLEMENTED'):
        if impl_set: errors.append(f'{rid}: implementation fields populated below IMPLEMENTED ({impl_set})')
    else:
        missing = [f for f in IMPL_FIELDS if not r[f].strip()]
        if missing: errors.append(f'{rid}: status {st} requires all implementation fields; missing {missing}')
        prod = r['implementation_product'].strip()
        if prod:
            if 'IPBS' in prod.upper() or 'PILOT' in prod.upper():
                errors.append(f'{rid}: implementation_product references the pilot itself ({prod}) — prohibited; implementation is external only')
            elif prod not in registry:
                errors.append(f'{rid}: implementation_product not in EXTERNAL-PRODUCT-REGISTRY: {prod}')
            elif registry[prod]['status'] != 'ACTIVE':
                errors.append(f'{rid}: implementation_product {prod} is not ACTIVE in the registry')
            else:
                if r['implementation_version'].strip() and not re.fullmatch(
                        registry[prod]['artifact_name_pattern'], r['implementation_version'].strip()):
                    errors.append(f'{rid}: implementation_version does not match registry pattern for {prod}')
        if r['implementation_contract_version'].strip() and not re.fullmatch(
                r'[a-z][\w.-]*\.v\d+', r['implementation_contract_version'].strip()):
            errors.append(f'{rid}: implementation_contract_version format invalid')
        if not r['implementation_evidence'].strip():
            errors.append(f'{rid}: status {st} requires implementation provenance evidence')
        else:
            check_impl_provenance(rid, r, r['implementation_evidence'], 'row')
        if hist.get('IMPLEMENTED') and 'PRODUCT-RELEASE:' in hist['IMPLEMENTED']['evidence']:
            check_impl_provenance(rid, r, hist['IMPLEMENTED']['evidence'], 'IMPLEMENTED event')
        impl_inst = hist.get('IMPLEMENTED', {}).get('_utc')
        af = registry.get(prod, {}).get('_active_from') if prod else None
        if impl_inst and af and impl_inst.date() < af:
            errors.append(f'{rid}: IMPLEMENTED {impl_inst.date()} predates {prod} governed active_from ({af}) — a product cannot implement requirements before it is governed active')

    if st == 'PROMOTED' and 'BACKLOG:' not in (r['validation_evidence'] + r['implementation_evidence']):
        errors.append(f'{rid}: PROMOTED requires BACKLOG: reference')
    refs = [x.strip() for x in r['validation_evidence'].split(';')]
    if st == 'VALIDATED':
        check_validation_semantics(rid, r, refs, hist)
    for ref in refs:
        resolve_ref(rid, ref, allow_lifecycle=(sidx(st) >= sidx('PROMOTED')))

    by_owner[r['owner']] = by_owner.get(r['owner'], 0) + 1
    by_status[st] = by_status.get(st, 0) + 1
    if st == 'PROPOSED': proposed_ids.append(rid)

# events referencing unknown RPRs already flagged; RPRs lacking events flagged in check_history

# --- ADR↔RPR matrix -----------------------------------------------------------
for adr_id, info in adr_files.items():
    for rid in info['gates']:
        r = row_by_id.get(rid)
        if r is None: errors.append(f'{adr_id} gates unknown entry {rid}'); continue
        st, a_st = r['status'], info['status']
        if a_st == 'PROPOSED' and sidx(st) > sidx('PROPOSED'):
            errors.append(f'{rid}: status {st} illegal while gating {adr_id} is PROPOSED (max PROPOSED)')
        if a_st == 'PROPOSED' and st == 'CLASSIFIED':
            errors.append(f'{rid}: gated by {adr_id} (PROPOSED) but marked CLASSIFIED')
        if a_st == 'REJECTED':
            errors.append(f'{rid}: cites REJECTED {adr_id}; must re-point to a replacement decision first')
        if a_st == 'SUPERSEDED':
            succ = info['successor']
            if not succ or f'ADR:{succ}' not in r['validation_evidence']:
                errors.append(f'{rid}: gating {adr_id} SUPERSEDED; RPR must cite successor {succ or "(none declared)"}')

# --- narrative consistency ----------------------------------------------------
tm = re.search(r'\*\*Total\*\* \| \*\*(\d+)\*\*', md)
if not tm or int(tm.group(1)) != len(rows): errors.append(f'narrative total != CSV rows ({len(rows)})')
for owner, n in by_owner.items():
    label = re.escape(owner) + (r' \(proposed\)' if owner == 'NEW-MODULE' else '')
    if not re.search(rf'\| {label} \| {n} \|', md): errors.append(f'narrative owner count for {owner} != {n}')
for status, n in by_status.items():
    if not re.search(rf'\| {status} \| {n} \|', md): errors.append(f'narrative status count for {status} != {n}')
nm = re.search(r'PROPOSED entries: ([^.]+)\.', md)
if not nm or set(re.findall(r'RPR-\d{3}', nm.group(1))) != set(proposed_ids):
    errors.append('narrative PROPOSED set != CSV')
prod_owned = sum(n for o, n in by_owner.items() if o in {'PLATFORM', 'CGWO', 'URAIFLOW'})
expect = (f"{prod_owned} entries owned by SaaS products (PLATFORM {by_owner.get('PLATFORM',0)}, "
          f"CGWO {by_owner.get('CGWO',0)}, URAIFLOW {by_owner.get('URAIFLOW',0)}), "
          f"{by_owner.get('NEW-MODULE',0)} proposed new module, {by_owner.get('TENANT-IPBS',0)} tenant configuration, "
          f"{by_owner.get('UNRESOLVED',0)} unresolved")
if expect not in md: errors.append('narrative product-ownership analytics line missing/mismatched')

if f'({len(rows)} entries' not in rtm: errors.append(f'RTM entry-count string does not match CSV ({len(rows)})')

t = inv['totals']
for needle, label in [(f"**{t['dv_object_count']}** DataValidation objects", 'DV-object count'),
                      (f"{t['sheet_count']} sheets", 'sheet count'),
                      (f"transaction_data_rows={t['transaction_data_rows']}", 'transaction row counter'),
                      (f"{t['instruction_rows']} instruction", 'instruction row counter'),
                      (f"{t['reference_rows']} reference", 'reference row counter'),
                      (f"{t['review_template_rows']} review-template", 'review-template row counter')]:
    if needle not in analysis: errors.append(f'analysis missing machine-derived {label}')
if str(t['preseeded_formula_cells']) not in analysis: errors.append('analysis formula-cell count missing')

if errors:
    print('REGISTER/DOCS CONSISTENCY: FAIL')
    for e in errors: print(' -', e)
    sys.exit(1)
n_ev = sum(len(v) for v in events_by_rpr.values())
print(f'REGISTER/DOCS CONSISTENCY: PASS — scope: 10 check groups (see docstring); {len(rows)} entries; owners '
      + ', '.join(f'{k}={v}' for k, v in sorted(by_owner.items()))
      + '; statuses ' + ', '.join(f'{k}={v}' for k, v in sorted(by_status.items()))
      + f'; product-owned={prod_owned}; lifecycle history enforced as UTC instants ({n_ev} events across {len(events_by_rpr)} RPRs, '
      f'state-skipping and offset-inversion impossible); tenant-bound ({TENANT_ID}, anchored to ADR authority) evidence semantics with real ISO dates, temporal policy '
      f'and external provenance against {len(registry)} ADR-approved registry products (STARTER abolished; active_from enforced); ADR matrix over {len(adr_files)} ADRs. '
      'PASS covers exactly the listed checks, nothing broader.')
