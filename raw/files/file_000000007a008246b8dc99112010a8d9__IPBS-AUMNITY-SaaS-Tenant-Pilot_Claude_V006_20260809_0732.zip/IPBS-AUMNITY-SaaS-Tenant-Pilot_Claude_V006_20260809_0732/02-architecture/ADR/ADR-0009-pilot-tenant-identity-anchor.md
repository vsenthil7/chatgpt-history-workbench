# ADR-0009 — Pilot tenant identity trust anchor

**Status:** ACCEPTED · **Date:** 2026-08-09 (V006) · Scope: pilot governance — anchors the already-established identity of AT-P0006 (IPBS AUMNITY SaaS Tenant Pilot); decides NO reusable SaaS product boundary
Pilot-tenant-id: IPBS

## Context
V005 correctly bound VALIDATED evidence to the canonical tenant in `09-governance/TENANT-IDENTITY.json`, but the reviewer changed that file's `tenant_id` to OTHER-TENANT and the validator passed, even reporting "tenant-bound (OTHER-TENANT)" — inside a repository that is, by its established project contract, the IPBS pilot. The trust chain ended one step too early: evidence → configured tenant was proven; configured tenant → immutable pilot identity was not. This is exactly the registry-authority pattern fixed by ADR-0008.

## Decision
1. This ADR carries the machine-readable authority line `Pilot-tenant-id: IPBS` above, recording the pilot identity already established by the project contract (AT-P0006, PROJECT-START.md). Recording an established fact is pilot governance; no product boundary is decided.
2. The trust chain is now: **pilot governance authority (this ADR) → canonical TENANT-IDENTITY.json → ACCEPTANCE/USAGE evidence.** The validator fails if: the authority declaration is missing; more than one `Pilot-tenant-id:` declaration exists anywhere in the ADR set (duplicate/conflicting authority); the declaring ADR is not ACCEPTED; or `TENANT-IDENTITY.json`'s `tenant_id` differs from the anchor.
3. **Display-name policy (documented decision):** `tenant_id` is the immutable identity and is anchored; `display_name` is informational and MAY change without affecting identity (positive test TA5). Any future change to `tenant_id` itself requires superseding this ADR — a governance decision, never a configuration edit.
4. The anchor remains governance data read by the validator — the tenant is not hard-coded in validator source.
