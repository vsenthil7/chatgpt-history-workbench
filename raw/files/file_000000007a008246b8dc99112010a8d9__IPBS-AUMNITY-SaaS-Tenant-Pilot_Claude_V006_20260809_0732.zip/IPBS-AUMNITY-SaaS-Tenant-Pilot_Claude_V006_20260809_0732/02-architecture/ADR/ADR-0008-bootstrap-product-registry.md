# ADR-0008 — Bootstrap approval of the initial external product registry

**Status:** ACCEPTED · **Date:** 2026-08-09 (V005) · Scope: pilot/repository governance — records the already-established initial external product set from the starter PRODUCT-BOUNDARY-AND-SAAS.md; decides NO new product boundary
Bootstrap-products: AUMNITY-Work-Platform-SaaS, AUMNITY-CGWO-SaaS, UraiFlow-SaaS

## Context
The V004 registry marked its three initial products `approval_adr=STARTER`, and the validator exempted STARTER from ADR checks — making STARTER an unrestricted approval bypass: the reviewer inserted `Fake-SaaS,ACTIVE,STARTER` and a fully consistent fake implementation validated (V004 review blocker 5).

## Decision
1. The `STARTER` token is abolished. EVERY ACTIVE registry row must cite an existing ACCEPTED ADR.
2. This ADR is the bootstrap approval for exactly the three products named in the machine-readable `Bootstrap-products:` line above — the set already established by the starter package's product-boundary document. Citing this ADR for any other product fails validation.
3. Any future product (e.g. a Capability SaaS under ADR-0002 or its successor) requires its own ACCEPTED ADR containing a machine-readable `Approves-product: <product_id>` line before its registry row may be ACTIVE. Registry membership remains a data change; approval authority is an ADR decision — never a validator-code edit and never a bare registry edit.

## Consequences
Negative tests: STARTER rejected outright; unlisted product citing this ADR rejected; product citing a PROPOSED ADR rejected. Positive simulation: a product citing a properly ACCEPTED approving ADR passes — the door is governed, not welded shut.
