# ADR-0005 — Package integrity boundary and external release attestation

**Status:** ACCEPTED · **Date:** 2026-08-08 (V003) · Scope: pilot packaging governance (within this package's own authority; no product boundary affected)

## Context
V002 excluded `13-evidence/post-manifest/` from the manifest to escape self-reference, which put the very files cited as G01/G11 evidence outside the integrity boundary: they could be altered, corrupted or supplemented without detection (V002 review blocker 1). The shipped smoke transcript also described a candidate tree, not the exact final payload (blocker-adjacent point 3).

## Decision
1. **Internal payload manifest covers EVERY file** in the package except `PACKAGE-MANIFEST.json` itself. No excluded directories exist. Corruption or addition of any file — including every evidence file — fails `validate_manifest.py` (negative-tested).
2. **Manifest-dependent proofs move OUTSIDE the artifact** into an external release attestation shipped alongside the ZIP (and reproduced in the handoff): final ZIP SHA-256, build command/environment, the manifest-validation transcript over the exact final payload, the final-payload smoke transcript (all validators re-run from a clean extraction of the shipped ZIP), and the double-build determinism proof.
3. **Sequencing (no circularity):** (a) all payload content and payload-stage evidence written; (b) manifest generated over everything; (c) payload frozen; (d) manifest validation, deterministic double-build, clean extraction and full smoke run — all recorded externally in the attestation. Nothing is added to the tree after the manifest is generated.
4. **What each layer proves:** the internal manifest proves payload integrity to anyone holding the ZIP; the external attestation proves the shipped artifact's identity, determinism and final-payload validation. The final ZIP hash is never embedded inside the ZIP.

See 09-governance/INTEGRITY-AND-ATTESTATION.md for the operational procedure.
