# ADR-0003 — Attestation and timesheet ownership (reworked V002)

**Status:** PROPOSED · **Date:** 2026-08-08 (V001), reworked 2026-08-08 (V002)
Gates: RPR-006, RPR-017

## V002 rework note
The V001 version of this ADR asserted that three approve/reject/correct appearances "earn a shared primitive" and proposed a three-way split gating RPR-006/007/017/042 while those entries sat at CLASSIFIED. Independent review rejected both: (a) three vocabulary-similar workflows inside ONE tenant workbook are not evidence of cross-bounded-context reuse — execution confirmation, timesheet approval and proposal decision have different domain invariants; (b) ADR-gated entries must not be CLASSIFIED. Both defects are corrected here.

## Context
The workbook shows three human-decision workflows: employee execution confirmation (06), timesheet approval (07, Draft→Submitted→Approved→Rejected→Corrected), and UraiFlow proposal decision (08, Pending/Confirm/Edit-and-confirm/Reject/Defer). It also *declares* timesheet consolidation from execution while *implementing* manual re-entry (finding F-18). Parallel CGWO architecture work reportedly moves toward CGWO owning Execution Session / Plan Item / Allocation state with trackers/timesheets possibly external systems of record via bridges (dependency X-01 — reported, unverified from this package).

## Decision structure (proposed, not decided)
Separated concerns, each resolved on its own evidence:
1. **Audit/change-history mechanics** — Platform primitive per the starter promotion rule's explicit naming of audit/evidence. NOT gated here; RPR-007 stays CLASSIFIED.
2. **Human attestation/decision mechanics** (RPR-006) — ownership open. A shared primitive requires demonstrated reuse across ≥2 bounded contexts *in product architectures*, not vocabulary similarity in one workbook. Until then each context may own its decision state machine over shared audit/identity primitives. → CROSS-PRODUCT / PROPOSED; dependency X-02.
3. **Timesheet/actuals consolidation** (RPR-017) — ownership open between CGWO-internal consolidation and external-system-of-record integration via bridges. Must be reconciled with the current CGWO architecture package. → CROSS-PRODUCT / PROPOSED; dependency X-01.
4. **Billable/client mapping** (RPR-042) — tenant configuration by direct application of promotion rule 4; no ADR gate needed; removed from this ADR's scope. Generic billing remains not-proposed (one tenant's flag is insufficient reuse evidence).

## To accept this ADR
Read the current CGWO architecture package (X-01) and the Platform boundary position (X-02); then assign owners for RPR-006 and RPR-017 and move them to CLASSIFIED/PROMOTED accordingly. Human/product-owner approval required. Not silently acceptable.
