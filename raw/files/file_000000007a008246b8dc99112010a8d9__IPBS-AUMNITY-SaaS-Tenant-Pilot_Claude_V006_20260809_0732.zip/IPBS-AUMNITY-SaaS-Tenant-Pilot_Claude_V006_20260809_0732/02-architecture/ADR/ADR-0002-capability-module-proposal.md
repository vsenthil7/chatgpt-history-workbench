# ADR-0002 — Ownership of workforce capability (skills/verification/training/recruitment)

**Status:** PROPOSED · **Date:** 2026-08-08 · **Version:** Claude V001

## Context
The baseline captures per-resource Current_Skills, Verified_Capabilities, Training_Need and Recruitment/Backup_Need (01_Resource_Master E–H), defines a six-level proficiency scale (99_Lists Skill Level: Awareness→Expert) that nothing references (finding F-04), and drives planning through a manual skill-suitability judgement (04 Resource_Skill_Check, F-05). Weekly review question 5 explicitly asks what training or recruitment need was discovered.

The Modularity placement test fails to yield a single existing owner:
- Platform owns identity, but proficiency/verification/training semantics are richer than an identity attribute.
- CGWO *consumes* suitability at planning time but should not own the taxonomy it matches against.
- UraiFlow may *propose* capability updates from conversations but owns extraction, not the domain.

## Options
A. Fold into Platform as extended resource attributes — smallest footprint; risks bloating the shared core (violates "small core: shared code is earned by reuse, not convenience").
B. Fold into CGWO — couples the taxonomy to one consumer; a future scheduling/HR product would have to reach into CGWO.
C. **New bounded module "AUMNITY Capability" (working name)** owning: skill taxonomy + proficiency levels, capability verification/evidence, training-need signals, recruitment/backup signals; publishing a capability-profile contract consumed by CGWO (RPR-012) and a proposal-commit target for UraiFlow.

## Recommendation
Option C, per promotion rule 5 (genuinely new reusable bounded capability → separate module before implementation). RPR-050 remains PROPOSED and RPR-012 is contract-phrased so it survives whichever option is approved.

## Required to proceed
Human/product-owner approval; then module boundary doc, contract draft, and register status → PROMOTED. No implementation anywhere until approved.

## V002 addendum
Status remains PROPOSED per independent review: the bounded-module idea is plausible but must be compared against current Work Platform and CGWO boundaries (dependency X-04 in CROSS-PRODUCT-DEPENDENCIES.md) before any module/product is created. Not silently acceptable.
Gates: RPR-050

## V003 addendum 2 — internal scope challenge (review point 7)
The proposed module currently bundles capability/profile concepts (skill taxonomy, proficiency, verified capability/evidence — a natural cluster) with training-need, recruitment-need and backup-need signals, which may instead be workforce-planning RESPONSES to a published capability/capacity gap: a capability service states "resource lacks capability X at proficiency Y"; whether the response is training, reallocation, recruitment or backup capacity may belong to CGWO or another workforce domain. The workbook storing these columns in one sheet is not domain-boundary evidence. This decomposition question is recorded as unresolved inside ADR-0002 and in X-04; approval requires answering it explicitly. Status remains PROPOSED.
