# ADR-0004 — Referential-integrity decomposition (and reference-data scope note)

**Status:** PROPOSED · **Date:** 2026-08-08 (V002)
Gates: RPR-003

## Context
V001's RPR-003 placed referential integrity for task↔plan↔execution↔time↔proposal wholly in Platform. Independent review objected: a central Platform service should not know every product's internal record relationships.

## Proposed decomposition
- **Platform:** tenant-scoped, globally stable identifier primitives and identity (RPR-004 already covers generation; stays CLASSIFIED).
- **Each bounded context (CGWO, UraiFlow, capability module if approved):** internal referential integrity of its own records (plan→allocation→execution inside CGWO; proposal lifecycle inside UraiFlow).
- **Cross-context references** (e.g. execution → proposal, timesheet → work item): validated through published-reference contracts at the boundary, not by reaching into another context's persistence.

## Reference-data scope note (not gated)
The same principle narrows RPR-008 without gating it: Platform provides reference-data *mechanism* (storage, tenant extension points, versioning); vocabulary *semantics* belong to bounded contexts. Recorded here for rationale; RPR-008's narrowed wording stands on the starter Modularity doc ("shared core must remain smaller than the products that consume it") and needs no approval to stay CLASSIFIED.

## To accept this ADR
Platform and each product repository confirm the decomposition against their current contracts (dependency X-03); then RPR-003 is split/assigned and leaves CROSS-PRODUCT. Human approval required.
