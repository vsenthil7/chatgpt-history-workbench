# Handoff — Claude V004 → independent ChatGPT review

**Artifact:** IPBS-AUMNITY-SaaS-Tenant-Pilot_Claude_V004_20260809_0640.zip (+ external attestation alongside)
**Input:** Claude V003 ZIP + attestation + ChatGPT review of 08/08/2026 23:21
**Character:** lifecycle/evidence correction release, per instruction NOT an architecture rewrite. The independently verified V003 integrity design (ADR-0005) is untouched: all-payload manifest, zero exclusions, deterministic build, external attestation.

## The three reproduced attacks, and how each is now closed

| Attack (reproduced by reviewer against V003) | V004 closure | Regression test |
|---|---|---|
| RPR-020 CLASSIFIED → VALIDATED by editing one status cell (+ narrative), no promotion/implementation ever recorded | Durable lifecycle event log (`12-requirements/lifecycle-events.csv`, append-only, seeded with the true 61-event V001–V003 history). Status is a projection: validator requires status == latest event, legal predecessor for every transition (VALIDATED←IMPLEMENTED←PROMOTED), ordered timestamps, no duplicates, and PERSISTENT stage evidence — the PROMOTED event must keep its BACKLOG: reference and the IMPLEMENTED event its provenance forever, so history deletion also fails | L2 (exact attack), R13, L1, L3–L8 |
| Four zero-byte files satisfying ACCEPTANCE/USAGE/FINDINGS/CONTRACT-TEST | Per-class JSON schemas semantically validated: bound rpr_id, tenant, named actors/roles, dates, outcome ∈ ACCEPT/ACCEPT-WITH-CONDITIONS (REJECT never validates), result=PASS, product/version equality with implementation fields, FINDINGS→USAGE linkage. Empty file = "an empty file is not evidence" | E1 (exact attack), E2–E8 |
| `implementation_evidence=FILE:workbook-inventory.json` accepted as proof CGWO v1.2.0 implemented the RPR | Provenance tokens required at IMPLEMENTED+: PRODUCT-RELEASE:<product>@<artifact> (artifact == implementation_version, matches registry pattern), CONTRACT:<ns.vN> (namespace from registry), RTM:/TEST: cross-reference. Generic FILE: explicitly rejected as provenance | P1 (exact attack), P2 |

**Reachability guarantee (anti-over-correction):** attack suite test P0 CONSTRUCTS a fully legitimate VALIDATED state — complete event history, registry-valid provenance, four schema-valid evidence documents — and the validator must PASS it. It does. The lifecycle is enforced and reachable; nothing re-hard-codes today's maturity.

## Other review points

- **Point 7 (registry as governance data):** `09-governance/EXTERNAL-PRODUCT-REGISTRY.csv` (product_id, status, approval_adr, artifact_name_pattern, contract_namespace, active_from, superseded_by) is consumed by the validator; hard-coded product names removed. A future Capability SaaS becomes a registry row citing an ACCEPTED ADR — negative test P3 proves unapproved products are rejected, and the validator checks the approval ADR's existence/status.
- **Point 4 (permanent transition evidence):** a VALIDATED entry answers every listed question from its event trail + row: observed when (event), classified how (event evidence cites ADR-0001), ownership resolution (ADR/DEP refs), promoted when/where (event + BACKLOG:), implemented by what (PRODUCT-RELEASE/CONTRACT/RTM), validated by whom (ACCEPTANCE JSON names acceptor/role/date).
- **Point 6 authenticity (deferred by reviewer):** unchanged — integrity linkage only; signing/CI provenance noted in ADR-0005's scope as future release-governance, not built now.
- **ADR decisions:** 0001/0005 ACCEPTED (unchanged) · 0006 ACCEPTED with Amended-by: ADR-0007 · 0007 ACCEPTED (pilot governance) · 0002/0003/0004 PROPOSED (untouched). No product boundary decided; X-01…X-06 OPEN.

## Gate table (V004)

| Gate / property | State | Proven by |
|---|---|---|
| G01 payload integrity | PASS | attestation (transcript over exact final payload); M1–M3 |
| G02 static | NOT-APPLICABLE (no product code); 8 governance scripts execute cleanly | attestation smoke |
| G03–G05, G07, G08 | NOT-YET-IMPLEMENTED (by design) | — |
| G06 architecture | PARTIAL — register-level enforcement (ownership, ADR matrix, lifecycle history, provenance, no-pilot-implementation); no code-level guards exist | validate_register.txt; R/L/E/P tests |
| G09 RTM | PASS for ACTIVE rows (REG-001..015, DOC-001, AI-001) | RTM |
| G10 docs consistency | PASS — scope exactly the 10 check groups | validate_register.txt |
| G11a deterministic build | PASS | attestation double-build |
| G11b clean extraction | PASS | attestation smoke |
| G11c final-payload smoke | PASS | attestation smoke (names exact hash) |
| G11d final artifact identity | PASS | attestation SHA-256 |
| G12 independent review | THIS HANDOFF — pending | — |

## Exact counts
Register: 29 — PLATFORM 6, CGWO 11, URAIFLOW 4, TENANT-IPBS 4, UNRESOLVED 3, NEW-MODULE 1 (product-owned 21); CLASSIFIED 25, PROPOSED 4 · Lifecycle events: 61 seeded (true V001–V003 history) · Registry: 3 ACTIVE products · Findings 18 · ADRs 7: ACCEPTED 4 (0001/0005/0006-amended/0007), PROPOSED 3 (0002/0003/0004) · RTM rows 24 · Validators: 8 scripts · Attack suite: 38 runs = 1 positive simulation (PASS) + 35 negatives ALL DETECTED, by class: R 13 (model), L 8 (history), E 8 (evidence semantics), P 3 (provenance/registry), M 3 (integrity) · Workbook: 11 sheets, 22 DV, 1507 formula cells, transaction_data_rows=0 · Files/hash: external attestation.

## Changed files (vs V003)
Added: 12-requirements/lifecycle-events.csv · 09-governance/EXTERNAL-PRODUCT-REGISTRY.csv · 02-architecture/ADR/ADR-0007 · 08-ai/HANDOFF-CLAUDE-V004.md
Modified: scripts/{validate_register.py (v4), run_negative_tests.py (v2)} · 12-requirements/{REQUIREMENT-PROMOTION-REGISTER.md, VALIDATION-EVIDENCE-CRITERIA.md} · 02-architecture/ADR/ADR-0006 (amendment note) · 06-traceability/RTM.md · 00-control/PAGES/00001 · CHANGELOG.md · PACKAGE-MANIFEST.json · regenerated 13-evidence/ transcripts
Unchanged: register CSV content except untouched (29 rows identical to V003 — statuses/owners/evidence identical); workbook byte-identical; all integrity scripts (generate_manifest, validate_manifest, package_release, derive_workbook_inventory) byte-identical to V003.

## Suggested re-review focus
1. Re-run the three original attacks verbatim; attempt variants (edit events + status + narrative together; forge a consistent-looking full trail and check what still catches it — expected answer: a forged-but-internally-consistent trail passes mechanically, which is exactly the acknowledged authenticity boundary of point 6, deferred). 2. Verify P0's constructed state is genuinely legitimate rather than a validator blind spot. 3. Attack the registry (SUPERSEDED products, bad approval ADR). 4. Confirm no integrity-design drift vs V003.
