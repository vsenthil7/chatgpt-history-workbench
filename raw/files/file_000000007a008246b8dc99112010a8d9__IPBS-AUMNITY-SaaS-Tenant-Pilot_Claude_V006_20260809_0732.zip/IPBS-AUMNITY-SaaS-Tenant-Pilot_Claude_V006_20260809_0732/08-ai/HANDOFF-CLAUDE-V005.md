# Handoff — Claude V005 → independent ChatGPT review (baseline-acceptance candidate)

**Artifact:** IPBS-AUMNITY-SaaS-Tenant-Pilot_Claude_V005_20260809_0716.zip (+ external attestation)
**Input:** Claude V004 ZIP + attestation + ChatGPT review of 09/08/2026 07:16
**Character:** narrow enforcement hardening exactly as instructed. NOT redesigned: lifecycle event-history model, status-as-projection, semantic evidence classes, provenance tokens, owner=UNRESOLVED model, all-payload manifest, deterministic packaging, external attestation, workbook facts. The four integrity scripts remain byte-identical to V003/V004.

## The four reproduced gaps → closures → permanent regression tests

| Reproduced attack (V004) | V005 closure | Tests |
|---|---|---|
| ACCEPTANCE/USAGE tenant = OTHER-TENANT → PASS | Canonical `tenant_id` in 09-governance/TENANT-IDENTITY.json; ACCEPTANCE and USAGE tenant must EQUAL it (not merely be non-empty). Case/identity mismatches fail | T1–T4 |
| `date = 2026-99-99` accepted (regex shape, not date) | Real ISO-8601 parsing for all evidence dates (datetime/date.fromisoformat); impossible calendar dates rejected. Event timestamps additionally must be timezone-AWARE | D1–D4 |
| Chronology inverted via UTC offsets (`-12:00` vs `+14:00`) while strings sort correctly | Lifecycle timestamps parsed and compared as UTC INSTANTS; the exact attack now fails with both instants printed in UTC | Z1 |
| ACCEPTANCE dated weeks before implementation → PASS | Temporal policy: ACCEPTANCE/USAGE ≥ IMPLEMENTED instant; FINDINGS ≥ source USAGE; VALIDATED event ≥ all evidence it relies on. CONTRACT-TEST deliberately keeps no lower bound (pre-release contract testing is legitimate — documented), only the VALIDATED upper bound | TE1–TE3 |
| `Fake-SaaS,ACTIVE,STARTER` registry insertion → PASS | STARTER abolished. ADR-0008 (ACCEPTED, pilot governance — records the starter-established initial three products via machine-readable `Bootstrap-products:`; decides no new boundary, per your point 10 authorization). Every ACTIVE product requires an existing ACCEPTED ADR that NAMES it (`Approves-product:` for future products). Registry stays data-driven; no product names returned to validator code | G1–G3; positive G4 proves an ADR-approved new product passes |

Also per points 6–8: `recorded_by` now required non-empty and honestly labeled a minimal actor record (A1); RTM:/TEST: wording changed to "structured external provenance reference, syntactically and registry-consistency validated; existence/authenticity verified during cross-product reconciliation"; the event log is described as an "append-only logical lifecycle model within the governed release process" with cross-release non-repudiation explicitly deferred (ADR-0005 boundary, unchanged).

## Attack suite (all rerun from clean extraction of the shipped ZIP — see attestation)
**Positive simulations: 2/2 PASSED** — P0 (fully legitimate future VALIDATED state) and G4 (new product with its own ACCEPTED approving ADR). The enforced rules remain satisfiable; nothing re-freezes the lifecycle.
**Negative tests: 51/51 DETECTED** — R 13 (model) · L 8 (history) · E 8 (evidence semantics) · P 3 (provenance) · T 4 (tenant) · D 4 (dates) · Z 1 (instant chronology) · TE 3 (temporal policy) · G 3 (registry authority) · A 1 (actor) · M 3 (integrity).

## Gate table (V005)
| Gate / property | State | Proven by |
|---|---|---|
| G01 payload integrity | PASS | attestation manifest transcript; M1–M3 |
| G02 static | NOT-APPLICABLE (no product code); 8 scripts run clean | attestation smoke |
| G03–G05, G07, G08 | NOT-YET-IMPLEMENTED (by design) | — |
| G06 architecture | PARTIAL — register-level enforcement incl. tenant/time/registry authority; no code-level guards exist | validate_register.txt; R/L/E/P/T/D/Z/TE/G/A |
| G09 RTM | PASS for ACTIVE rows (REG-001..018, DOC-001, AI-001) | RTM |
| G10 docs consistency | PASS — scope exactly the 10 check groups | validate_register.txt |
| G11a–d | PASS (deterministic double-build · clean extraction · final-payload smoke incl. full attack suite · external hash) | attestation |
| G12 independent review | THIS HANDOFF — pending | — |

## Exact counts
Register: 29 — PLATFORM 6, CGWO 11, URAIFLOW 4, TENANT-IPBS 4, UNRESOLVED 3, NEW-MODULE 1 (product-owned 21); CLASSIFIED 25, PROPOSED 4 · Lifecycle events: 61 · Registry: 3 ACTIVE products, all approval ADR-0008 (bootstrap) · Tenant identity: IPBS (governed) · Findings 18 · ADRs 8: ACCEPTED 5 (0001, 0005, 0006 amended, 0007 amended, 0008), PROPOSED 3 (0002/0003/0004) · RTM rows 27 · Validators: 8 scripts · Suite: 53 runs = 2 positive + 51 negative, all as expected · Workbook: 11 sheets, 22 DV objects, 1507 formula cells, transaction_data_rows=0 · Files & final hash: external attestation.

## Changed files (vs V004)
Added: 09-governance/TENANT-IDENTITY.json · 02-architecture/ADR/ADR-0008 · 08-ai/HANDOFF-CLAUDE-V005.md
Modified: 09-governance/EXTERNAL-PRODUCT-REGISTRY.csv (approval_adr STARTER→ADR-0008) · scripts/{validate_register.py, run_negative_tests.py} · 02-architecture/ADR/ADR-0007 (V005 amendment) · 12-requirements/{VALIDATION-EVIDENCE-CRITERIA.md, REQUIREMENT-PROMOTION-REGISTER.md (wording)} · 06-traceability/RTM.md · 00-control/PAGES/00001 · CHANGELOG.md · PACKAGE-MANIFEST.json · 13-evidence/ transcripts
Unchanged: register CSV (29 rows byte-identical), lifecycle-events.csv, workbook, all four integrity scripts, ADR-0002/0003/0004, X-01…X-06.

## Acceptance framing
Per your instruction this handoff is prepared as a candidate for **"Tenant Requirements Discovery Baseline — ACCEPTED"** — which accepts the requirements-discovery baseline only. Live IPBS tenant validation explicitly remains a later phase requiring real product implementations, IPBS configuration, representative usage, contract exercises, findings and recorded acceptance. On acceptance, the recommended next phase is cross-product reconciliation of ADR-0002/0003/0004 and X-01…X-06 against the owning-product packages, rather than further version-churning this baseline.

## Suggested re-review focus
1. Rerun the four reproduced attacks verbatim plus variants (mixed-precision dates, DST boundaries, tenant homoglyphs). 2. Attack ADR-0008 (edit its Bootstrap-products line — should be caught by manifest integrity within the release; note the acknowledged cross-release boundary). 3. Verify G4's positive path is genuinely governed (requires ACCEPTED + named product). 4. Confirm the four integrity scripts are still byte-identical. 5. Decide baseline acceptance.
