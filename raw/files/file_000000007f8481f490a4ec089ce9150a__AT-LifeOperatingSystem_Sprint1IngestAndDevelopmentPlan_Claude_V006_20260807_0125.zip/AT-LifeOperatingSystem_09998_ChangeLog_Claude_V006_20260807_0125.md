# AT-LOS V006 Change Log

## Added - code

- `at-platform` monorepo: uv workspace, per-package pyproject, pytest from root.
- `at-ingest-core`: Event, Participant, SourceRef, ParseIssue, IngestResult, Source contract. Source-agnostic and domain-free. SourceRef raises if any of source_id, locator or source_sha256 is missing.
- `at-ingest-whatsapp`: deterministic parser handling both iOS bracketed and Android bare dialects, 12- and 24-hour clocks, multi-line messages, attachments, media placeholders, system messages, and the invisible LTR/RTL marks WhatsApp injects.
- 15 tests covering each of the above, running in 0.02 seconds with no network.
- Three ADRs: monorepo structure, deterministic core, Python choice.

## Verified against real data

- Consultant group export: 182 events, 0 unparsed, 100% coverage, 3 participants, 20 multi-line events, 18 attachments.
- Bhuvana direct export: 318 events, 0 unparsed, 100% coverage, 2 participants.
- Correction to V004 method: the naive regex reported a spurious participant named "3" and folded continuation lines into noise.

## Added - planning

- Sprint planner with three sprints, each carrying an acceptance test a person can watch pass.
- Eight anti-hallucination sprint rules, including: a task is not Done until its Hallucination Register row carries the commit hash.
- Repository and package naming for all 12 components plus the app.
- Reusability contract: six enforced checks, including a named real non-AT-LOS consumer per package.
- Development design document covering layers, dependency direction, design principles and what remains undecided.

## Decisions

- D-019: one monorepo with independently publishable packages. Partially un-parks PK-009 and PK-010, which were deferred in V004 as premature and are no longer premature because code exists.
- D-020: deterministic core; an LLM may write Inferred, never Observed.
- D-021: Python 3.11+ for the platform. Does not constrain the client (DD-001 stays deferred).

## Adopted from ChatGPT, 07-Aug-2026

- The documents rule, in its sharper form: work must produce executable or measurable evidence; documentation is allowed only as a by-product. The problem was never documents, it is documents counted as progress.
- Architecture discovery frozen except where implementation exposes a real decision, which then becomes an ADR.
- The 30-day measurement and the engineering run in parallel, not in sequence.
- No permanent AI role split. Recorded as a live risk in V005 and not formalised.

## Unchanged

- V005 Project Memory and Project Memory Standard.
- V004 decision memo, evidence register, consultant analysis.
- V001 charter, methodology, naming and versioning standard, research landscape.
