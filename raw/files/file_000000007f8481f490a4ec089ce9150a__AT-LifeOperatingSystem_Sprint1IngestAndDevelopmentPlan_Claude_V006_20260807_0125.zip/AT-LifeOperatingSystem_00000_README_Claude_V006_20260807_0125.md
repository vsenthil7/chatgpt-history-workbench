# AT-Life Operating System (AT-LOS) - V006

**Release:** `AT-LifeOperatingSystem_Sprint1IngestAndDevelopmentPlan_Claude_V006_20260807_0125`
**Prepared by:** Claude
**Timestamp:** 07-Aug-2026 01:25 BST
**Trigger for this version:** working code, per the V005 rule that no new version is created for a conversation alone.

## Why V006 exists

ChatGPT's V005 verdict was that the next version should be triggered by something actually working — a parser, with tests, and real source data flowing through it.

That is what this is. **The code came first; these documents are its by-product.**

## What runs

```
cd at-platform
PYTHONPATH=packages/at-ingest-core/src:packages/at-ingest-whatsapp/src \
  python -m pytest -q
```

15 tests, 0.02 seconds, no network.

Against the two real WhatsApp exports:

| Export | Events | Unparsed | Coverage | Participants |
|---|---|---|---|---|
| Consultant group | 182 | 0 | 100% | 3 |
| Bhuvana direct | 318 | 0 | 100% | 2 |

20 multi-line messages correctly held as single events. 18 attachments separated from message bodies. The naive regex used for the V004 analysis reported a participant called "3" and could not distinguish a continuation line from a message.

## Three capability states moved. Nine did not.

| Capability | Was | Now |
|---|---|---|
| WhatsApp text parser | Planned | **Implemented** |
| Event and provenance model | Manual only | **Implemented** |
| Monorepo and workspace | Vision only | **Implemented** |

Still Planned: evidence schema in code, meeting-lifecycle extraction, identity resolution, consent gate, person model, observer model, LLM export ingestion. Still Manual only: the follow-through measurement — AT-056 has not started.

`06_HallucinationSync` in the sprint planner records both facts. Copy it into `10_HallucinationRegister` in the Project Memory; do not maintain two truths.

## The repo question, answered

**One monorepo, `at-platform`, with independently publishable packages.** Not repo-per-API, not one application.

A separate repository does not make code reusable. Reuse comes from a stable contract, a version number and no reverse dependencies. Six repos can be hopelessly coupled; one repo's packages can lift out cleanly. Full reasoning in `docs/adr/ADR-001-monorepo.md` and section 2 of the design document.

Reusability is enforced by six CI checks, not by intention. The one that bites: every package must name a real non-AT-LOS consumer, and a package with no real second consumer after two sprints is a folder with ambition, not a reusable component.

## Package names

`at-ingest-core` · `at-ingest-whatsapp` · `at-ingest-llm-export` · `at-evidence` · `at-identity` · `at-commitments` · `at-questions` · `at-consent` · `at-timeline` · `at-store` · `at-cli` · app: `atlos-api`

Rule: `at-<capability>` for reusable packages, `<product>-<surface>` for apps. Capability names, never brand names. **Product branding stays deferred under DD-006** — a brand needs a legal check and its own decision.

## The rule that stops hallucination during development

**A task is not Done until its Hallucination Register row is updated with the commit hash.** Code merged with a stale register is not Done. Eight sprint rules in `00_HowToUse`, including ChatGPT's sharper version of the documents rule: the problem was never documents, it is documents counted as progress.

## Package contents

| File | What it is |
|---|---|
| `at-platform_repo_V006_...zip` | The working repository. Unzip and run pytest |
| `00030_SprintPlanner` | 3 sprints, repo/package names, reusability contract, capability sync |
| `00031_DevelopmentDesignDocument` | Layers, principles, the repo decision, what is not decided |
| `00000_README` · `00002_Metadata` · `09998_ChangeLog` · `09999_Manifest` | Release artefacts |

Carried forward unchanged: the V005 Project Memory, the V004 decision memo, evidence register and consultant analysis.

## What has not happened

No lawful basis under UK GDPR (AT-052). No consent from Subha or Bhuvana (AT-053). The 30-day measurement has not started (AT-056) — and it should start tonight, by hand, because it consumes calendar time that the engineering does not.
