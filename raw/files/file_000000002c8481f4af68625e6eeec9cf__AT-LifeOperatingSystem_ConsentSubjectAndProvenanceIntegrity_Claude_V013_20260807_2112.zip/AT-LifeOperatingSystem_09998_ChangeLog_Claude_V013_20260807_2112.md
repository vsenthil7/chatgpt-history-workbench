# AT-LOS V013 Change Log

**Release type:** consent-subject separation and provenance integrity. One new ADR (013), which **amends** ADR-012 rather than superseding it.

## Verified

12 findings raised. All 12 verified against the code before acceptance. None rejected.
Cumulative across five reviews: **58 raised, 58 confirmed, 0 rejected.**

## ADR-013 - provenance is not consent

- `owner_ref` → `importer_ref`; `owners_of_event()` → `importers_of_event()`.
- New `SubjectRef` and `subjects_of_event()`: candidate data subjects, raw names, resolution left to at-identity.
- **DQ-012** opened: authority for every subject, or redaction of unauthorised subjects. Blocks `at-consent`. ADR-012 had chosen a permissive rule silently.
- `origin_kind` joins `registration_id`. `sequence` added so identical import tuples do not collapse; `next_sequence()` finds the free slot.
- `put_source()` enforces referential integrity; `__post_init__` re-derives IDs; `ProvenanceError` raised.
- Occurrence-id collisions differing only in `label` or `revoked_at` are rejected, so a replay cannot erase a revocation.

## Tooling

- **Facts measured, not estimated.** `FactsError` refuses derivation from a failing suite. Nesting sentinel prevents recursion.
- **Mutation pre-flight.** All targets verified before mutating. Added after a timeout-killed run left a mutant on disk.
- **Package artefact audit.** `release_check.py [dir]` checks shipped workbooks, metadata and filenames; historical artefacts exempt by name.
- 5 new RTM rules (29-33); 11 mutants, up from 8.
- CI gains a mutation pre-flight step.

## Documents

Counts synced from derived facts · S1-20 contract wording · "Next review due" instead of "Reviewed" · reading-order numbering · ADR docstring reference · store test evidence recomputed.

## Decisions

D-051 provenance is not consent · D-052 facts measured, mutation pre-flight · D-053 origin_kind is part of source-version identity

## Not done

No feature work. `at-identity`, `at-consent`, `at-evidence` not started. **AT-056 remains Not started — unmoved without a date.**
