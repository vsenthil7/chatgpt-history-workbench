# AT-Life Operating System (AT-LOS) - V013

**Release:** `AT-LifeOperatingSystem_ConsentSubjectAndProvenanceIntegrity_Claude_V013_20260807_2112`
**Prepared by:** Claude · **07-Aug-2026 21:12 BST**

## 12 findings. All verified. All real.

Finding 1 is the one that mattered, and it was right.

### Provenance is not consent (ADR-013)

`owner_ref` on `ImportOccurrence` recorded **who imported a source**. ADR-012 then called `owners_of_event()` *the consent lookup* — while `ConsentGrant` is `subject + purpose`. A chat imported by A contains B, C and D. Building `at-consent` on that would have asked the wrong party for permission.

**Two graphs now, not one:**

```
provenance:  Event → SourceRegistration → ImportOccurrence[] → importer_ref[]
subjects:    Event → SubjectRef[] → PersonRef[] → purpose → ConsentGrant
```

`owner_ref` → `importer_ref`. `owners_of_event()` → `importers_of_event()`. The name was doing the damage — it read like an answer to a question it could not answer.

**DQ-012 is now open and blocks `at-consent`:** does processing require authority for *every* subject in an event, or may unauthorised subjects be redacted? ADR-012 silently chose "at least one". That is a decision for you and AT-052, not for me.

### Three identity defects

**`origin_kind`** joins registration identity — the same bytes as a WhatsApp export and a ChatGPT export were collapsing, first write winning.

**Occurrences genuinely don't deduplicate** — a `sequence` field. The old claim was false: an identical tuple collapsed under `setdefault`.

**Referential integrity enforced** — `put_source()` rejects mismatched chains; IDs are re-derived in `__post_init__`, so a forged ID raises `ProvenanceError` at construction.

### Facts were estimated

`tests_passed = collected - 1` with a hard-coded skip and ignored return codes. A failing suite could still produce a clean-looking fact set. Facts now come from a real run and raise **`FactsError`** rather than deriving from a red suite.

### RTM-23 overclaimed

It checked four Markdown files and no shipped artefact. `release_check.py` now audits workbooks, metadata and filenames too, with historical artefacts exempt by name.

Also fixed: `__all__` exported a deleted class (star import raised) · S1-20 contract wording · "Reviewed 06-Sep-2026" written in the past tense about a future date · duplicated reading item · a docstring citing an ADR that didn't exist.

## One I found in my own tooling

A mutation run killed by timeout left a mutant on disk. `try/finally` cannot catch SIGKILL, and the next run would have read the mutated file as pristine and restored the corruption permanently. It had already broken `make_id` so every sequence hashed identically — the tests caught it by **hanging**.

`preflight()` now verifies every mutant target before a single byte is written.

And one mutant **survived** at first: my two-importer test used different timestamps, so a timestamp-only identity still passed it. Mutation testing found what 92 passing tests did not. There is now a same-instant test.

## Gates

```
pytest                 92 passed, 1 skipped · 325 statements, 0 missed, 100%
architecture guards    22 collected
ruff / mypy --strict   clean
mutation regression    11/11 killed (pre-flight verified)
standalone install     3/3 clean venvs
release integrity      0 failures, documents + shipped artefacts
real exports           500 events, 0 issues, 2 registrations, 2 occurrences
```

RTM: **30 passing + 1 skipped + 2 not enforced = 33.**

## Start Sprint 2 — with one gate

`at-identity` and `at-evidence` can be built now. **`at-consent` needs DQ-012 decided first**, and DQ-012 needs AT-052. That is a real dependency, not more architecture.

## Still not done

RTM-14, RTM-15 unenforced · store not durable (S1-20) · ingestion not streaming · no GDPR basis, no consent · every L2+ module is a contract on paper.

**AT-056 remains Not started.** Unmoved, deliberately, until you give a date.
