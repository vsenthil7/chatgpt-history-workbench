# AT-LOS V020 Change Log

**Release type:** capability. ADR-020. **Closes S1-20.** Does not close DQ-004.

## Added — durable storage

- **`EventRepository` port** (`_ports.py`): what every store must do, engine-free.
- **`SqliteEventStore`** (`_sqlite.py`): durable reference implementation. Schema versioned; a foreign version raises `SchemaVersionError`.
- **`_records.py`**: provenance contracts extracted as pure dataclasses, shared by both stores.
- **`open_store(path)`**: durable with a path, in-memory without.
- **`purge_orphaned_events()`** on both stores.
- **Shared contract suite**: 23 behaviours parametrised over in-memory and durable.
- **Durability tests**: survives restart, idempotent across restart, revocation persisted, raw bytes absent, foreign schema refused, audit trail retained after purge.
- **`at-cli`**: `import`, `inspect`, `purge`.
- **MT-006** manual test; EXT-UAT-001 extended with an optional storage step.

## Changed

`at-store` state `Partial` → `Implemented`. `revoke_occurrence` raises `KeyError` for an unknown id on both stores. Known limitations rewritten: storage is opt-in, the export file itself is not kept, deletion is deliberate.

## Registered

`TST-INT-CONTRACT-STORE` in `testing.toml` · RTM-69 to RTM-75 · a 14th mutation case for the schema-version refusal.

## Decisions

D-075 durable storage behind a port · D-076 one contract suite per port · D-077 raw bytes are never retained · D-078 purging keeps the audit trail

## Not done

Concurrency, backup, encryption at rest, retention schedules, query language, migration tooling. `at-identity`, `at-consent`, `at-evidence` not started. No product application. No network API. **AT-056 remains Not started.**
