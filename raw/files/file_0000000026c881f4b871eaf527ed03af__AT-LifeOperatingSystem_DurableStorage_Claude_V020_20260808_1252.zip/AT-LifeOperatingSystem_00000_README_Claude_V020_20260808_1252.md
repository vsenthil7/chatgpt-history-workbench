# AT-Life Operating System (AT-LOS) - V020

**Release:** `AT-LifeOperatingSystem_DurableStorage_Claude_V020_20260808_1252`
**Prepared by:** Claude · **08-Aug-2026 12:52 BST**

```
V020 — DurableStorage

pytest                 241 passed, 1 skipped
coverage               755 statements, 180 branches, 100% line and branch
architecture guards    48 collected
integration (real venv) 2 collected
mutation regression    14/14 killed
RTM                    72 passing + 1 skipped + 2 not enforced = 75
modules / products     11 declared, 2 product applications
test suites            16 built, 4 declared not built (3 external)
documentation          40 pages, 2 publication profiles
packages measured      at-cli, at-ingest-core, at-ingest-llm-export, at-ingest-whatsapp, at-store
platform version       0.11.0

Facts measured: outcomes=True coverage=True
```

## Your verdict was right: two adapters and nothing to store them in

**S1-20 is closed.** Every guarantee the platform makes — content-derived
identity, idempotent re-ingest, provenance, revocation — now survives the process
ending.

## A port, not an engine

`EventRepository` is a Protocol. Callers depend on it; nothing above `at-store`
names SQLite.

**SQLite is the reference implementation, not the answer to DQ-004.** It is
stdlib, single-file, transactional and serverless — the right *first* durable
engine and the wrong thing to build a product assumption on. A different engine
later is a new class implementing the same port, not a migration of everything
above it.

**One contract suite, 23 behaviours, parametrised over both stores.** A durable
store that behaved differently from the in-memory one would not be a drop-in
replacement, and every test that ever passed against the in-memory store would
silently mean less.

## Three decisions worth naming (ADR-020)

**Raw bytes are not stored.** `SourceContent` keeps the hash and size; `blob_ref`
exists for a future blob store and stays null. The platform records that content
with a given hash was imported — it does not keep a second copy of a person's
chat history, which would double the exposure of exactly the data AT-052 has not
established a lawful basis for.

**Purging keeps the audit trail.** `orphaned_events()` reports; nothing is deleted
automatically. `purge` removes events — and **retains import occurrences and their
revocations**. The record of who imported what, and when they withdrew, must
outlive the data it justified.

**A different schema version raises rather than reads.** Interpreting unknown
records as known ones is the silent corruption every guard here exists to prevent.

## Verifiable by a person

```bash
python -m at_cli import <export> --database at.sqlite3   # first run: 4 new
python -m at_cli import <export> --database at.sqlite3   # second: 0 new
python -m at_cli inspect --database at.sqlite3
python -m at_cli purge   --database at.sqlite3
```

The second import is a **separate process** and still adds nothing. That is
MT-006.

## What is coded

`at-ingest-core` ✅ · `at-ingest-whatsapp` ✅ · `at-ingest-llm-export` ✅ ·
**`at-store` ✅ (was Partial)** · `at-cli` ✅ — **5 of 11 packages, none partial.**

The ingestion and storage foundation is complete. AT-LOS product: **not started.**
Network API: **not started.**

## Deliberately not done

No query language, indexing beyond provenance lookup, **concurrent writers**,
backup, encryption at rest, or retention schedule. The database has been
exercised with hundreds of events, not millions. Those belong with AT-052 and a
real deployment; inventing them now would be guessing.

## Next

`at-identity`. **`at-consent` stays blocked on DQ-012 and DQ-013.** No product app
or HTTP layer before DQ-014.

**AT-056 remains Not started.**
