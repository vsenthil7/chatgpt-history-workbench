# AT-Life Operating System (AT-LOS) - V012

**Release:** `AT-LifeOperatingSystem_BaselineIntegrityAndProvenanceBoundary_Claude_V012_20260807_1728`
**Prepared by:** Claude · **07-Aug-2026 17:28 BST**

## Versioning, settled

The package released as **V010.1 is canonical project release V011.** It is retained unchanged by hash and is **not** reissued. From here every release takes the next integer — no decimal patch versions (D-048). Release *type* lives in the metadata, never in the number.

## 18 findings. All 18 verified. All 18 real.

Two were foundational architecture, not documentation — and they are the reason this pass was worth doing before `at-consent`.

### Finding 9 — provenance identity omitted the field consent depends on

`ingestion_id = hash(workspace | source_id | content_sha256)`. **No `owner_ref`.** Two owners importing the same bytes into the same workspace collapsed into one record under `setdefault`. The second owner vanished.

### Finding 10 — an Event had no path to an owner at all

`SourceRef` carried workspace, source, content and locator. Nothing linked it to an import. `at-consent`'s first question — *whose data is this?* — had no answer.

**ADR-012 settles it.** Three records, three jobs:

| Record | Identity | Dedups? |
|---|---|---|
| `SourceContent` | bytes hash | globally |
| `SourceRegistration` | `workspace \| source_id \| content_sha256` | per workspace |
| `ImportOccurrence` | `registration \| owner_ref \| imported_at` | **never** |

An Event belongs to the **registration**, not the occurrence. Adding an occurrence id to `SourceRef` was rejected: identical bytes imported twice would produce duplicate events and break idempotency (RTM-12).

```
Evidence → Event → SourceRegistration → active ImportOccurrence[] → owner_ref[]
```

`owners_of_event()` is the consent lookup. Empty set means refuse — absence of provenance is never permission. Revocation records `revoked_at` and never deletes; an event survives while any other owner's import is active, and `orphaned_events()` reports the rest for cascade.

## Finding 1 — the checker claimed more than it verified

V011's consistency tool scanned **three regex patterns across four Markdown files** and reported "all artefacts consistent" while five stale facts survived. That was the honest description problem, not a bug.

Replaced by real machinery:

- **`tools/release_facts.py`** — 37 fields derived from the code. Nothing typed.
- **`tools/release_check.py`** — 12 check families: versions, counts, RTM reconciliation, release stamps, superseded terminology, adapter rule, ADR range, module state vs disk, RTM rules naming real tests.
- **`tools/build_release.py`** — writes `release_facts.json`; the workbooks are generated from it.
- **`rtm.toml`** — RTM rules and statuses as data. V011's workbook typed statuses summing to 26 against 25 rules; `test_rtm_counts_reconcile` makes that impossible.

It caught all 18 findings on its first run, then caught four more I introduced while fixing them.

## Finding 8 — a CI gate that could not have run

standalone-install ran `pytest packages/at-ingest-core/tests` — a directory that does not exist — and passed one package to pip twice. RTM-13 was marked PASSING on a YAML file.

`tools/standalone_install_check.py` builds a **real clean venv per package**, installs only declared dependencies, imports, and runs that package's tests. **3/3 clean**, locally and in CI.

## Everything else

Parser test count, guard count, statement count, ADR range, release stamps, `RawSource` terminology, the absolute "Project Memory wins" rule, index column K→P, "sixteen registers", the canonical-contract row, consultant analysis conflating artefact with capability, commit-hash wording (D-049), mutation harness `try/finally`.

**Consultant analysis** is now split: *artefact — manually produced* (Manual only) and *automated capability* (Planned). It was marked Implemented, which would have let a future reader believe the system does it.

## Gates — all green

```
pytest                    79 passed, 1 skipped · 294 statements, 0 missed, 100%
architecture guards       22 collected
ruff                      clean          mypy --strict     clean
mutation regression       8/8 killed
standalone install        3/3 clean
release integrity         0 failures
real exports              500 events, 0 issues, 2 registrations, 2 occurrences
```

RTM: **25 passing + 1 skipped + 2 not enforced = 28 rules.** Counts reconcile, and a test asserts they do.

## Completion gate

A fresh AI given only this zip gets one answer to all twenty questions. Where does `at-identity` go? `architecture.toml`, L2, may import core and store. Who imports an adapter? Only `at-cli`. What is durable? Nothing — the store is in-memory and says so. How will `at-consent` decide? `owners_of_event()`.

**Start Sprint 2.** Architecture frozen by default — reopen only for a contradiction implementation uncovers, and only the affected module.

## Still not done

RTM-14, RTM-15 unenforced · store not durable (S1-20) · ingestion not streaming (S1-24) · no GDPR basis, no consent · every L2+ module is a contract on paper.

**AT-056 remains Not started.** I have not moved it and will not until you provide a first measurement date — recording it as started would be the exact fabrication this whole system exists to prevent.
