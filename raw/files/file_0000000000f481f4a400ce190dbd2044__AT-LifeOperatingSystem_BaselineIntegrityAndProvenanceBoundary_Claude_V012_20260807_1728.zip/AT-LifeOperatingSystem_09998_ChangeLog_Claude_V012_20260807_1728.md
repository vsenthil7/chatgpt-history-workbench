# AT-LOS V012 Change Log

**Release type:** Baseline integrity and provenance boundary. One new ADR (012), forced by a foundational gap.
**Versioning:** the package released as V010.1 is canonical project release **V011**, retained by hash and not reissued. Integer versions only from here (D-048).

## Verified

18 findings raised. All 18 verified against the files and code before acceptance. None rejected.
Cumulative across four reviews: **46 raised, 46 confirmed, 0 rejected.**

## Architecture — ADR-012

- `SourceIngestion` replaced by **`SourceRegistration`** (source version: workspace + source_id + content hash, deterministic, deduplicating) and **`ImportOccurrence`** (one import act: registration + owner + timestamp, never deduplicating, revocable).
- An **Event belongs to the registration**. Adding an occurrence id to `SourceRef` was rejected — it would duplicate events and break RTM-12.
- `owners_of_event()`, `occurrences_for_registration()`, `revoke_occurrence()`, `orphaned_events()` implemented and tested. Empty owner set means consent must refuse.
- 19 store tests covering two owners in one workspace, revocation, orphaning and audit retention.

## Release machinery

- **`rtm.toml`** — 28 rules as data. Statuses reconcile (25 + 1 + 2), asserted by `test_rtm_counts_reconcile`; `test_every_rtm_test_name_exists` requires a PASSING rule to name a real test.
- **`tools/release_facts.py`** — 37 derived fields, memoised, non-recursive.
- **`tools/release_check.py`** — 12 check families. Replaces `consistency_check.py`, which is deleted.
- **`tools/build_release.py`** — writes `release_facts.json`; workbooks generated from it.
- **`tools/standalone_install_check.py`** — real clean venv per package. RTM-13 now genuinely passes.
- `docs/ARCHITECTURE.md` RTM table generated from `rtm.toml`; §B and §C still generated from `architecture.toml`.
- Mutation harness restores files in a `finally` block; two new mutants for the ADR-012 guarantees. **8/8 killed.**

## Documents corrected

Parser tests 37→39 · guards 19→22 · statements 235→294 · release stamps V010→V012 · RTM "21 of 24"→generated · `RawSource` terminology removed · absolute "Project Memory wins" removed · ADR range →012 · adapter rule stated once.

## Project Memory

Index column K→P · "sixteen registers"→fifteen · canonical-contract row regenerated · **consultant analysis split into manually-produced artefact and not-implemented automated capability** · implementation refs to 0.3.0 · D-047 to D-050 · four Lessons entries · V011 canonical numbering note · S1-27/28/29.

## Not done

No feature work. `at-identity`, `at-consent`, `at-evidence` not started. Durable persistence (S1-20) and streaming ingestion (S1-24) planned. RTM-14 and RTM-15 unenforced. **AT-056 remains Not started — not moved without evidence.**
