# TalkProof — PO DECISION RECORD — V001

| Field | Value |
|---|---|
| **Created** | 2026-10-04 22:11 (Europe/London) |
| **Version** | V001 |
| **Status** | RECORD OF PRODUCT OWNER DECISIONS — record only (no code, no requirement text changed by this file) |
| **Source artifacts** | PO decision message 2026-10-04 22:02; TALKPROOF_PO_DECISION_GATE_V001_20261004_2151.md; TALKPROOF_REQUIREMENT_RECOVERY_V6_20261004_2155.md Part 46 |
| **Scope** | The 13 decisions put to the PO at the 21:51 gate; the corrected D-22 count |
| **Explicit exclusions** | No new decision is taken here; no CR text is approved; no FR/NFR ID issued |
| **Decisions consumed** | D-15, D-26, D-24, D-19, D-20, D-23, D-25, D-17, D-16 (investigation only), D-22 (selection only) |
| **Unresolved items** | D-06, D-18, D-21 remain OPEN |
| **Change / provenance** | Created in the 2026-10-04 pre-build pass authorised by the Product Owner decision record of 22:02; author: Claude (builder); no source artefact modified; no code changed; no V7 created. |

## 1. Decisions approved by the Product Owner on 2026-10-04 22:02

| Decision | PO decision (verbatim intent) | Effect | What it does NOT do |
|---|---|---|---|
| **D-15** | APPROVED: accept BRD-001 v1.0.1 as parent authority. | BRD-001 sits above PRD-001 in the requirement-authority chain. Reconciliation performed in `TALKPROOF_BRD_REQUIREMENT_RECONCILIATION_V001`. | Does not amend BRD-001 text. |
| **D-26** | APPROVED: close as satisfied by E-01 as corrected/reconciled into V6. | D-26 CLOSED. CR work may be selected (D-22). | Does not authorise any CR implementation. |
| **D-24** | APPROVED: Postgres-first; graph only after E-03 justifies it. | Design constraint on CR-14 (PSM). | Does not approve CR-14. |
| **D-19** | APPROVED: no cross-tenant knowledge aggregation; reconsider only after the stated RLS/CR-22 conditions. | Standing constraint. Reopen trigger: row 1 (Tier-A RLS) at D5 **and** CR-22 analysed. | Does not approve CR-22. |
| **D-20** | APPROVED: accept the Part 19.2 CLM/model-portfolio gate; N remains unset pending E-04 evidence. | No fine-tune may be proposed until all five gate conditions hold. | Does not set N; does not approve any training. |
| **D-23** | APPROVED: scorecard remains internal only; reconsider after evidenced D5 capability. | CR-20 scope = internal. | Does not approve CR-20. |
| **D-25** | APPROVED: defer continuous AI pentest procurement until a deployable staging/production environment exists. | No procurement action. Reopen trigger: EV-04 evidence of a deployed environment. | Does not decide buy vs build. |
| **D-17** | APPROVED: Part 26 autonomy-ceiling table becomes governing policy, not yet a product requirement. | Policy in force for any automation/agent work. | Does not approve CR-18. |
| **D-16** | APPROVED FOR INVESTIGATION: execute E-02 and R-C. Does NOT approve ERS/ETSI as the final product architecture. | E-02 and R-C executed in `TALKPROOF_EVIDENCE_RESEARCH_PACK_V001`; the yes/no follow-on is put back to the PO in `TALKPROOF_REMAINING_PO_DECISIONS_V001`. | Does not approve CR-07/CR-08. |
| **D-22** | APPROVED FOR REQUIREMENTS ANALYSIS per the per-CR table, with the count correction below. | 11 CRs expanded in `TALKPROOF_CR_REQUIREMENTS_ANALYSIS_V001`; 4 conditional assessed; 8 deferred untouched. | Selection is not approval of CR text; no FR/NFR is created by selection. |

## 2. Corrected D-22 categorisation (authoritative, per PO)

| Category | Count | CRs |
|---|---|---|
| SELECT FOR ANALYSIS | **11** | CR-01, CR-02, CR-03, CR-04 (expansion gated on R-D), CR-05, CR-06, CR-09, CR-13, CR-14, CR-15, CR-23 (expansion gated on R-D and R-E) |
| CONDITIONAL | **4** | CR-07 and CR-08 (on D-16 outcome), CR-11 (on D-21), CR-12 (on R-D) |
| DEFER | **8** | CR-10, CR-16, CR-17, CR-18, CR-19, CR-20, CR-21, CR-22 |
| **Total** | **23** | — |

Correction note: the 21:51 gate artefact listed 11 CRs under SELECT but wrote "SELECT now = 10". The PO's count (11) is authoritative; the gate artefact is not edited (immutable); this record supersedes its count.

## 3. Decisions remaining OPEN

| Decision | Status | Where the recommendation now stands |
|---|---|---|
| D-06 | OPEN | `TALKPROOF_CERTIFICATE_LIFECYCLE_ARCHITECTURE_V001` and `TALKPROOF_REMAINING_PO_DECISIONS_V001` |
| D-18 | OPEN | `TALKPROOF_REMAINING_PO_DECISIONS_V001` (after CR-15 analysis) |
| D-21 | OPEN | `TALKPROOF_REMAINING_PO_DECISIONS_V001` (after CR-12 analysis and R-D) |

## 4. Register state after this record

Decided: D-01..D-05, D-07..D-15, D-17, D-19, D-20, D-22 (selection), D-23, D-24, D-25, D-26 · Decided-for-investigation: D-16 · Open: D-06, D-18, D-21. No FR/NFR/BR/CD/EV identifier created. No sprint created. No code changed. V6 unchanged. V7 not created.
