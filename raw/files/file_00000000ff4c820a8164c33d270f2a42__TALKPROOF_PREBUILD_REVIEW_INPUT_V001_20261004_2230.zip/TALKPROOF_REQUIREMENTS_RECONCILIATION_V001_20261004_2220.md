# TalkProof — REQUIREMENTS RECONCILIATION — V001

| Field | Value |
|---|---|
| **Created** | 2026-10-04 22:20 (Europe/London) |
| **Version** | V001 |
| **Status** | RECONCILIATION RECORD — proposed requirement changes prepared for the governance process; NO FR/NFR/BR identifier issued; nothing applied to FRD/NFRD/BRD/PRD text |
| **Source artifacts** | BRD-001 v1.0.1; PRD-001 v1.0.1; FRD-001 v1.0.1 (82 FRs); NFRD-001 v1.0.0 (67 NFRs); TRACEABILITY §1 (BR-11..19); V6 Parts 1, 7, 38–40, 46; PO decision record 22:02; TALKPROOF_BRD_REQUIREMENT_RECONCILIATION_V001; TALKPROOF_CR_REQUIREMENTS_ANALYSIS_V001; TALKPROOF_CERTIFICATE_LIFECYCLE_ARCHITECTURE_V001 |
| **Scope** | Apply ONLY approved PO decisions to the requirement set; list every requirement change they entail; map conformance defects to the requirement they violate; register the analysed CRs as proposed requirements with provenance |
| **Explicit exclusions** | Open decisions (D-06, D-18, D-21) are shown as conditional rows, not applied; research findings create no requirement; the 8 deferred CRs are absent |
| **Decisions consumed** | D-01, D-03, D-04, D-05, D-07, D-08, D-09, D-10, D-11, D-12, D-13, D-14, D-15, D-17, D-19, D-20, D-22, D-23, D-24, D-25, D-26 |
| **Unresolved items** | PD-A/PD-B (BRD amendment); D-06/D-16/D-18/D-21 conditional rows; ID issuance is the governance process's act after independent review |
| **Change / provenance** | Created in the 2026-10-04 pre-build pass authorised by the Product Owner decision record of 22:02; author: Claude (builder); no source artefact modified; no code changed; no V7 created. |

Row key — **Type:** CHANGE (existing requirement text changes because a PO decision requires it) · CONFORM (requirement unchanged; code must conform — recorded for the tracker) · NEW-PROPOSED (new requirement wording prepared from an approved decision or an analysed CR; ID to be issued by governance) · COVERAGE-GAP (BRD/PRD acceptance criterion with no FR/NFR owner) · CONDITIONAL (depends on an open decision). **Provenance** names the decision/CR/code fact; nothing is sourced from a research finding alone.

## 1. Changes entailed by APPROVED decisions

| # | Requirement | Type | Change required | Provenance |
|---|---|---|---|---|
| RC-01 | FR-012, NFR-014 (RS256) | CONFORM | No text change. Code (`config.py:37` HS256) must conform. | D-01 |
| RC-02 | FR-054(4), NFR-023 ("Hedera/Ethereum/private network") | CHANGE | Replace the named list with "an anchor adapter selected per tenant/platform configuration; supported adapters are listed in the provider registry; no adapter is product identity". Keep the ≤10-minute and "independently verifiable without platform access" clauses. | D-03 (NEW PO DECISION 2026-10-04) |
| RC-03 | FR-040, FR-053 ("any model failure → needs_manual_review"; 60-s timeout) | CONFORM | No text change. Code tolerates one failed model and uses 30 s; fenced JSON counts as failure (CD-16). S48/M30-T05 must implement FR-040 as written, not "degrade to 2-of-2". | D-04 |
| RC-04 | FR-040 vocabulary `confirmed/disputed/uncertain` | CONFORM | No text change. Persisted reviews and the certificate payload use POSITIVE/NEGATIVE/NEUTRAL/INCONCLUSIVE; the persisted/audited contract must use requirement terms (mapping allowed internally). | D-05 |
| RC-05 | FR-056 ("Twilio, Telnyx, and Vonage") | CHANGE | Replace the named list with "carrier adapters selected via M05 routing and configuration; no carrier is special in the requirement". Exotel becomes a listed adapter. Same treatment for BRD C-04 under PD-A. | D-07 (NEW PO DECISION) |
| RC-06 | FR-011 (30-min lockout), FR-045 (2-h impersonation max) | CONFORM | No text change; code 15 min / 60 min is drift. | D-08 |
| RC-07 | PRD §6 Won't-Have (AI-originated interactions) | CHANGE (PRD) | Add the scoped clarification: proof subject remains human; AI-originated interactions may be captured/verified as a distinct capability; TalkProof does not become an autonomous-calling product. EU AI Act Art 50 disclosure event becomes evidence where this capability is used (CR-05). | D-09 Option B |
| RC-08 | NFR-042/043 (RPO ≤15 min / RTO ≤4 h) | CONFORM | No text change. DR runbook states RTO 60 min (stricter) — consistent; restore-test record missing (EV-07). | D-10 |
| RC-09 | NFR-057 (80 % floor) | CONFORM | No text change. Engineering gate `fail_under=100` is a stricter policy; it is red (CD-17) and must be made honest (fix the 23 lines or set the gate to the policy value with the PO's knowledge). | D-11 |
| RC-10 | FR-054(1) canonical set | CHANGE | Extend "call metadata + transcript + consensus result + approver + timestamp" to the evidence set in CR-04 (recording hash, transcript hash, STT/model/prompt/provider versions, policy/regulation versions, consent record id/version, disclosure text, approval record). Mechanism (Merkle/ERS) is NOT added here (D-12 accepted scope, not mechanism). | D-12 |
| RC-11 | New requirement: provider configuration through the product | NEW-PROPOSED | "Tenants and the platform operator select every pipeline provider (carrier, STT, reviewer models, voting strategy, certification/TSA/anchor, storage, messaging) through the product UI and configuration tables, resolved at runtime by the config resolver with campaign > tenant > platform > default precedence; keys alone are insufficient; provider selection is audited." Provenance: D-13; tracker BR-18 (S45 EPIC); row 45 D4 resolver. | D-13 |
| RC-12 | Part 2b ten areas | — | Already in analysis (CR-05..CR-13); see §3. | D-14 |
| RC-13 | Requirement-authority order | CHANGE (process) | BRD-001 above PRD-001; BR-11..BR-19 recognised as tracker-layer BRs pending PD-A. | D-15 |
| RC-14 | Autonomy ceilings | NEW-PROPOSED (policy, not FR) | Part 26 table recorded as governing policy in the architecture record; becomes a requirement only via CR-18 (deferred). | D-17 |
| RC-15 | Cross-tenant data use | NEW-PROPOSED (constraint) | "No data, derived signal or learned artefact of one tenant informs any other tenant's processing or outputs" — standing constraint until the D-19 reopen conditions. | D-19 |
| RC-16 | Model training gate | NEW-PROPOSED (constraint) | Part 19.2 five-condition gate; N unset. | D-20 |
| RC-17 | Scorecard exposure | CONSTRAINT | CR-20 (deferred) scope = internal. | D-23 |
| RC-18 | PSM storage | CONSTRAINT | Postgres-first; graph only after E-03. | D-24 |
| RC-19 | AI pentest | — | No requirement; procurement deferred. NFR-028 unchanged. | D-25 |

## 2. Conformance defects mapped to the requirement they violate (no new requirement; tracker items in `TALKPROOF_SPRINT_TRACKER_RECONCILIATION_V001`)

| CD | Violates | Note |
|---|---|---|
| CD-01 Exotel adapter attr/relative callback | FR-056 (working carrier path), BR-16 | S43 conformance |
| CD-02 Stripe signature scheme | FR-042 | S09 conformance |
| CD-03 OIDC claims / no JWKS / no SAML ACS | FR-015, FR-016 | S03 conformance |
| CD-04 vault write-only, router results discarded | FR-030, FR-028 | S06/S49 conformance |
| CD-05 `dev-secret` defaults | NFR-025 | S21/S34/S09 conformance |
| CD-06 `iota_client` undeclared | NFR-023 (until RC-02 adapter model lands, the IOTA adapter must at least declare its dependency) | S51 |
| CD-07 audit chain race | FR-022, NFR-034 | S05 conformance |
| CD-08 no production caller: consent, rate limiter, SLA escalation, SIEM, ConfigResolver, resilience | FR-078, FR-080, FR-035, FR-027, BR-18/RC-11, NFR-046 | S21, S07, S05, S47+, S20 |
| CD-09 transcription interface-only | FR-052 | S47 in progress |
| CD-10 storage drivers no writer | FR-058, BR-15 | S33 conformance |
| CD-11 orchestrator bypasses M22 ledger | M22 scope (S23), NFR-065 | S23 conformance (independent of D-18) |
| CD-12 blocking sleeps in request | NFR-001 (response time) | S12/S45 |
| CD-13 issue flow has no anchor/PDF | FR-054(3)–(6) | S12 — ordering blocked on D-06 |
| CD-14 Flutter android only; README stale | FR-067..073; G51 | S17/S19 + docs |
| CD-15 Celery declared unused | documentation (ADR-009) | AD-4 |
| CD-16 Gemini tokens; fence stripping | FR-040, NFR-065 | S48 |
| CD-17 coverage gate red | NFR-057 policy | D-11 |

## 3. Analysed CRs registered as PROPOSED requirements (wording in `TALKPROOF_CR_REQUIREMENTS_ANALYSIS_V001`; ID to be issued by governance after independent review)

| CR | Proposed as | Kind | Provenance | Status |
|---|---|---|---|---|
| CR-01 | NFR (completion governance) | process/NFR | G01, BR-11, D-22 | ready for governance |
| CR-02 | NFR (executable conformance) | NFR | G02, NFRD measurement column | ready |
| CR-03 | NFR (adapter standard) | NFR | G45, D-13, CD-01/04/10 | ready |
| CR-04 | FR-054(1) extension | FR change | D-12, R-D | ready (placement of approval record follows D-06) |
| CR-05 | FR (regulation catalogue) + NFR-030 extension | FR/NFR | D-14, R-C | ready |
| CR-06 | NFR-024/056 extension | NFR change | D-14 | ready |
| CR-09 | NFR (provider-exit verifiability) | NFR | D-14, R-36/R-06 | ready |
| CR-13 | NFR-025..028 extension | NFR change | D-14 | ready |
| CR-14 | FR (product state model) | FR | D-24, brief §6 | ready |
| CR-15 | M22 scope extension | FR/NFR change | M22 scope, CD-11 | ready; D-18 decides form (amend recommended) |
| CR-23 | FR (certificate status lifecycle) + FR-036/FR-077 reconciliation | FR | Part 29.5, code fact | ready; cost field pending E-05 |
| CR-07 | NFR (evidence record format) | NFR | D-16 investigation | CONDITIONAL on D-16 = yes |
| CR-12 | FR (standalone verifier) + FR-055 change | FR | R-06/R-36/AC-02.6, R-D | CONDITIONAL on D-21 = yes |
| CR-08, CR-11 | — | — | — | CONDITIONAL (D-16/E-07; D-21) |

## 4. Coverage gaps from the BRD (PD-B pending)

| Gap | BRD AC | Proposed owner | Wording (proposed) |
|---|---|---|---|
| CG-1 | AC-02.3 transcription + 3-model consensus ≤ 3 minutes after call completion | NFR (performance, M11) | "For calls ≤ 10 minutes, transcription and consensus complete within 3 minutes of call completion at P95; longer calls within 2× real-time (FR-052)." |
| CG-2 | AC-02.7 verbatim disclosure text delivered is recorded immutably | FR (M11) + NFR-030(d) | "The disclosure text as delivered on the call is captured verbatim, hashed into the evidence root (CR-04) and linked to the consent record (NFR-030(e))." |

## 5. CONDITIONAL rows (open decisions — shown, not applied)

| Decision | If decided as recommended | Requirement effect |
|---|---|---|
| D-06 (c) | FR-054 Processing (1)–(6) rewritten to the lifecycle eight steps; NFR-023 applies to the T1 leaf and to status records; NFR-024 applies to T0 and T1 | CHANGE |
| D-16 yes | CR-07 becomes an NFR; FR-054(2) gains "algorithm identifier recorded" | NEW |
| D-18 amend | M22 scope text extended per CR-15 | CHANGE |
| D-21 yes | CR-12 becomes an FR; FR-055 extended with status display and R-D lists | NEW + CHANGE |

## 6. Reconciliation totals

Requirements CHANGED by approved decisions (text): 5 (FR-054(1), FR-054(4)/NFR-023, FR-056, PRD §6, authority order) · CONFORM (code must change, text unchanged): 6 · NEW-PROPOSED from approved decisions: 4 (RC-11, RC-14, RC-15, RC-16) · Proposed from analysed CRs: 11 ready + 2 conditional + 2 pending · Coverage gaps: 2 · **FR/NFR/BR IDs issued: 0.**
