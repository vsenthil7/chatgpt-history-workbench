# TalkProof — EVIDENCE RESEARCH PACK — V001

| Field | Value |
|---|---|
| **Created** | 2026-10-04 22:14 (Europe/London) |
| **Version** | V001 |
| **Status** | EVIDENCE / RESEARCH RECORD — findings and recommendations only; nothing approved |
| **Source artifacts** | talkproof-backend-master.zip (services/api/app/services/certified_voice_service.py, models/certified_voice.py, iota_service.py, pdf_service.py, orchestrator_service.py; requirements.txt); V6 Parts 29, 32, 33, 41, 43; primary sources listed in §3; e02_prototype.py / e02_output.txt (retained beside this file) |
| **Scope** | E-02 (ERS integration with existing content_hash), R-C (primary-source revalidation of the standards/legal claims V6 relies on), R-D (relying-party model), R-E (trust-root governance — obligations part; cost part not possible without E-05) |
| **Explicit exclusions** | No TSA token was obtained (no TSA reachable from the verification environment); no live anchor; no legal advice — R-D/R-E are desk analyses for the PO and counsel, not opinions of law; E-04/E-05 need live data and are not attempted |
| **Decisions consumed** | D-16 (investigation authorised), D-12 (binding scope), D-03 (provider-neutral anchor), D-04, D-09 B |
| **Unresolved items** | R-C items not yet read in primary form: ETSI EN 319 102-1, FCC TCPA dockets, OWASP ASI list, C2PA audio spec; R-E cost model (needs E-05) |
| **Change / provenance** | Created in the 2026-10-04 pre-build pass authorised by the Product Owner decision record of 22:02; author: Claude (builder); no source artefact modified; no code changed; no V7 created. |

Label key — **SOURCE FACT** (from an authoritative document) · **CODE FACT** (read in the supplied repo at the cited line) · **RESEARCH FINDING** (external source, cited) · **ARCHITECTURE ANALYSIS** (reasoning on the above) · **RECOMMENDATION** (for the PO).

## 1. E-02 — Does an RFC 4998 ERS evidence record integrate with the existing canonical-JSON `content_hash` and PDF embedding without re-issuing old certificates?

**Method.** Read-only prototype executed against the production hashing functions imported from the supplied backend (`app.services.certified_voice_service._canonical_json` / `_sha256`), with the exact 7-field payload shape built by `draft_certificate()` (`certified_voice_service.py:146-154`). Hash tree and archive-timestamp chain modelled in pure Python following RFC 4998 §4 (sorted leaf hashes per node, timestamp over the root). No DB, no network, no code change. Script and output retained as `e02_prototype.py` / `e02_output.txt`.

| # | Finding | Label |
|---|---|---|
| E02-1 | `content_hash` = SHA-256 over `json.dumps(payload, sort_keys=True, separators=(",",":"), default=str)`; stored beside `canonical_json` on `call_certificates` (`certified_voice_service.py:51-57,155,166`; `models/certified_voice.py:60-64`). | CODE FACT |
| E02-2 | The existing `content_hash` can be used **unchanged** as one leaf of an ERS data-object group; the Merkle root over {certificate_payload, recording, transcript, provenance} is computed without touching the certificate row; a second archive timestamp over {approval record, root_T0} chains to it; the verifier recomputes all of it from the payload + leaves + two timestamps. Prototype assertions pass. | CODE FACT (prototype) |
| E02-3 | Therefore **no re-issue of existing certificates is needed** to adopt ERS: the ERS record is additive (a new `evidence_record` artefact referencing `content_hash`), and the certificate's own hash semantics are preserved. There are **no issued anchored certificates in evidence** anyway (Part 41, Part 44), so migration risk is nil today. | ARCHITECTURE ANALYSIS |
| E02-4 | What the code lacks for an ERS record: (i) no algorithm identifier on `content_hash` (Part 43 check 3); (ii) no recording hash, transcript hash, STT/model/prompt provenance in any persisted artefact (Part 41); (iii) the HiL approval (`issue()` sets `issued_at`, `issued_by`, `proposal_id`) is **outside** the hashed material — `canonical_json` is frozen at draft time (`certified_voice_service.py:209-241`); (iv) no TSA client, no `rfc3161`/`asn1` library in `requirements.txt`; (v) `pdf_service.generate_campaign_report` is campaign-level and embeds the campaign IOTA tx, not a per-certificate hash (`pdf_service.py:97,243,287`); (vi) `CallCertificate.status` admits `revoked` (`models/certified_voice.py:22`) but **no code path ever sets it** (repo-wide grep: only the `!= "revoked"` filter at `:137`). | CODE FACT |
| E02-5 | PDF embedding: an ERS record is a separate artefact (ASN.1 per RFC 4998 or XML per RFC 6283); the PDF would carry the certificate hash, the T1 TSA token and the anchor reference (as FR-054(5) already requires) plus a reference/QR to the evidence record. Nothing in the current PDF path prevents this; the current path simply does not do it. | ARCHITECTURE ANALYSIS |
| E02-6 | Limitation: no RFC 3161 TimeStampToken was obtained (no TSA reachable); the chain structure is validated, the token verification (`openssl ts -verify`) is not. A staging run with a public TSA is the remaining step and is cheap. | EXTERNAL VERIFICATION GAP |

**E-02 result: STRUCTURAL FIT CONFIRMED — ERS wraps the existing hash additively; no re-issue; four code additions required (algorithm id, binding hashes, approval-in-hash or two-timestamp design, TSA client). Token-level verification pending a staging TSA call.**

## 2. R-C — Primary-source revalidation of the claims V6 relies on

| Claim in V6 | Primary source checked | Result | Label |
|---|---|---|---|
| RFC 4998 defines an Evidence Record with hash trees whose root is timestamped, and two renewal modes (timestamp renewal, hash-tree renewal) that let old records survive algorithm deprecation (V6 Part 13.5, 29.1, CR-07) | RFC 4998 (IETF, Aug 2007), datatracker/rfc-editor text | **CONFIRMED.** The RFC states the leaves are hashes of the data objects, a timestamp is requested only for the root hash, and that archive timestamps must be renewed before algorithms weaken, distinguishing Timestamp Renewal from Hash-Tree Renewal, the latter required when the hash algorithm itself loses security. | RESEARCH FINDING |
| An XML form exists (RFC 6283) | RFC 6283 / draft-ietf-ltans-xmlers | CONFIRMED to exist (XMLERS, alternative syntax to the ASN.1 ERS, with renewal procedures and an appendix on verification). Detail not read line-by-line. | RESEARCH FINDING |
| Library support is available for ERS | Bouncy Castle `org.bouncycastle.asn1.tsp.EvidenceRecord` (Java) | CONFIRMED (Java). No Python ERS library found in the pinned requirements; a Python implementation or a Java sidecar is an engineering choice for CR-07. | RESEARCH FINDING |
| ETSI TS 119 312 V2.1.1 (2026-06) exists and covers PQ/hybrid suites (V6 CR-08) | ETSI deliverable `ts_119312v020101p.pdf` | **CONFIRMED.** V2.1.1 is dated 2026-06 and its contents include a section on hash functions for use in post-quantum contexts and a section on hybrid cryptographic schemes with recommended hybrid suites. The EU digital-identity standards tracker records that ETSI approved it in June 2026 for publication as v2.1.1. | RESEARCH FINDING |
| EU AI Act Art. 50 transparency obligations apply from 2 Aug 2026 (V6 Part 13.5 item 6, CR-05) | Law-firm and Commission-referencing briefings (Cooley, Stibbe, McCann FitzGerald, Macfarlanes), Aug 2026 | **CONFIRMED with a correction:** Art. 50(1),(3),(4),(5) apply from 2 August 2026; Commission guidelines were adopted 20 July 2026; under the Digital Omnibus the Art. 50(2) marking obligation for systems already on the market before 2 Aug 2026 applies from 2 December 2026. Fines up to €15 m or 3 % of worldwide turnover. **V6's "already in force" is right for 50(1)/(3)/(4)/(5); CR-05's regulation catalogue must carry the 50(2) transitional date.** | RESEARCH FINDING |
| OTel GenAI semantic conventions: "Development, no stable release" (V6 Part 21, CR-15) | Multiple July–Sept 2026 analyses of the OTel registry and changelog | **CONFIRMED and strengthened:** as of mid-2026 no `gen_ai.*` attribute, span, metric or event is Stable; on 12 June 2026 (semconv v1.42.0) the GenAI and MCP conventions were moved out of the core repository into `open-telemetry/semantic-conventions-genai`, the old doc pages became redirect stubs, and that repository had published no tagged release as of July 2026. Attribute renames occurred across 2026 release cycles. **Consequence for D-18:** pinning TalkProof's persisted ledger schema to a Development convention with no tagged release is not a stable base; it is suitable as a versioned export mapping, not as the primary schema.** | RESEARCH FINDING |
| RFC 3161 TSA tokens verifiable offline with `openssl ts` (NFR-024) | Standard practice; not re-searched (stable since 2001) | Accepted as settled. | SOURCE FACT (NFRD) |

**Not revalidated in this pass (still open under R-C):** ETSI EN 319 102-1 (LTV validation procedures), FCC TCPA dockets cited in Part 13.4, OWASP Agentic Top-10 list text, C2PA/CAWG audio provenance spec. None of these is load-bearing for D-06, D-18 or D-21.

## 3. R-D — Relying-party model (what a TalkProof certificate proves and does not prove)

**Purpose (V6 Part 29.4):** state, per relying-party class, the claim set a certificate makes, so that FR-055's "Verify Now", CR-12's verifier output and every marketing use of "proof" are bounded. This is a desk analysis for the PO and counsel; it is not legal advice.

### 3.1 What the artefacts can carry (after the lifecycle in `TALKPROOF_CERTIFICATE_LIFECYCLE_ARCHITECTURE_V001`)

| Claim class | Claim | Mechanism | Who can check it without TalkProof |
|---|---|---|---|
| C1 Integrity | these bytes (recording, transcript, verdict payload, approval record) have not changed since they were hashed | SHA-256 leaves + Merkle root (ERS) | anyone with the artefacts + verifier |
| C2 Existence-at-time | the evidence root existed at T0; the approved certificate existed at T1 | RFC 3161 tokens (TSA) + anchor tx | anyone with `openssl ts` and the anchor explorer |
| C3 Provenance of process | which STT engine, which three models/versions/prompts, which routing/regulation/policy versions were used | CR-04/CR-05/CR-06 fields hashed into the root | anyone reading the evidence record |
| C4 Human attestation | a reviewer with role R approved verdict V against evidence root T0 at T1, with reason text | HiL `ApprovalDecision` (FR-036) bound into the T1 leaf | anyone reading the evidence record; identity of the reviewer only via TalkProof (pseudonymous role outside) |
| C5 Model attestation | three independent models returned these structured verdicts | per-model outputs hashed (CR-04) | anyone; **reproducibility of the model output is not provable** (E-06 open) |
| C6 Status | the certificate is valid / superseded-by / revoked as of date S | CR-23 status record (timestamped) | anyone, if the status list is embedded at renewal or served signed |

### 3.2 What the artefacts do NOT prove (must be stated by the verifier in plain language)

- That the words in the transcript are a true transcript of the audio (STT error is bounded only by confidence fields, not proven).
- That the recording is of the person claimed (speaker identity beyond diarisation confidence).
- That the disclosure was *understood* or that consent was *informed*.
- That the verdict is *correct* — only that three named models and a named human reached it on this evidence.
- Legal effect in any jurisdiction (OOS-04).

### 3.3 Relying-party classes

| Class | Decision they take | Claims they need | Claims they must be told are absent |
|---|---|---|---|
| RP-1 Counterparty / call recipient's organisation | accept proof that disclosure X was delivered on call Y | C1, C2, C3 (STT), C4, C6 | C5 correctness; identity beyond diarisation |
| RP-2 Regulator (TCPA/FCC, PECR, EU AI Act deployer) | was the disclosure delivered; was consent valid; was AI involvement disclosed (Art 50 where D-09 B is used) | C1, C2, C3 (regulation versions), C4, C6, consent record binding (NFR-030(e)) | truth of content |
| RP-3 Court / tribunal | admissibility and weight | all of C1–C6 + chain of custody across the HiL gap (hence two timestamps) | legal effect (court decides) |
| RP-4 Auditor (SOC2, client audit) | controls operated as designed | C3, C4, C6, audit-chain linkage (FR-022) | — |
| RP-5 Tenant itself | internal QA, dispute handling | all | — |

**R-D conclusion (RECOMMENDATION):** the verifier output and the PDF must print two lists — "This certificate proves" (C1–C6 as applicable) and "This certificate does not prove" (§3.2). The ordering decision (D-06) must deliver C4 and the chain of custody across the HiL gap, which only a two-timestamp design does (see lifecycle artefact). **R-D is complete for the purpose of gating CR-04/CR-12/CR-23 and D-06/D-21.**

## 4. R-E — Trust-root governance and independent-operator obligations

| Obligation area | What TalkProof (WET) must operate | Evidence it must keep | Open cost item |
|---|---|---|---|
| Signing / hashing keys | algorithm inventory (CBOM, CR-08); key custody for any signature TalkProof itself applies (today: none — hash only) | key ceremony records, rotation log | low |
| TSA relationship | contract with ≥1 publicly trusted TSA (NFR-024 names DigiCert/Sectigo/GlobalSign class); fallback TSA; tokens stored with the record | TSA policy OID, token archive | per-token fee × certificates/month (E-05) |
| Anchor relationship | per D-03: configured adapters; public verification material cached (CR-09) | tx receipts, explorer independence | per-anchor fee; batching reduces (T0 roots can be batched) |
| Renewal operations | scheduled ERS timestamp renewal before TSA cert expiry; hash-tree renewal before SHA-256 deprecation (ETSI TS 119 312 V2.1.1 as the trigger source, CR-19) | renewal calendar, renewal records | operations time; multi-year |
| Reviewer authority | who may approve (FR-032 floor, FR-034 SoD); reviewer identity escrow for RP-3 | approval decisions (FR-036) | — |
| Verifier releases | signed, versioned verifier (CR-12/CR-13); verifier version in every certificate | release signatures, SBOM | medium |
| Status/revocation | who may revoke; revocation is itself timestamped/anchored (CR-23) | status records | low |
| Retention and tenant exit | evidence verifiable after tenant leaves (CR-11); retention per FR-058/FR-077 | export bundles | storage |
| Provider disappearance | TSA/anchor/STT/model vendor exit must not invalidate old evidence (CR-09 principle) | cached public material | — |
| Liability / indemnity / longevity SLA | contractual; outside engineering | — | **PO/commercial — not analysable here** |

**R-E conclusion:** the obligations part is complete enough to gate CR-23 and the lifecycle design. The cost part requires E-05 (first live tenant) and remains open.

## 5. Other code facts gathered for D-06 / D-18 / D-21 (no new CD identifiers issued)

| Fact | Where | Bearing |
|---|---|---|
| HiL approval and issuance are not part of any hashed/anchored material; `canonical_json` fixed at draft | `certified_voice_service.py:146-166, 209-241` | D-06: option (a) as coded today would timestamp a payload that omits the approval |
| `revoked` status defined, never assigned | `models/certified_voice.py:22`; grep | CR-23: status lifecycle is absent, not merely incomplete |
| Only anchor path is campaign-level (`certify_campaign`) with env stub tx; `iota_client` undeclared | `iota_service.py:55-80,180-186`; `requirements.txt` | D-06: per-certificate anchoring does not exist in any ordering |
| PDF is a campaign summary with IOTA tx footer | `pdf_service.py:97,243,276-287` | D-06/FR-054(5): per-call certificate PDF absent |
| M22 ledger model: `AIInteractionLedger` persists model name (String 64), provider, tokens, cost, status, audit_log link; orchestrator's real calls bypass it | `models/ai_ledger.py`; V6 CD-11 | D-18: a persisted ledger already exists and is hash-chain linked — extension, not replacement, is the lower-risk path |
| Verification endpoint recomputes from DB only; no downloadable artefact | `certified_voice_service.py:247-258`; routes | D-21: FR-055 offline verification is unmet at D1 regardless of CR-12 |

## 6. Summary of what this pack settles

| Item | Status |
|---|---|
| E-02 | DONE (structural); token-level verification pending a staging TSA call |
| R-C | DONE for the load-bearing claims (RFC 4998, ETSI TS 119 312 V2.1.1, EU AI Act Art 50, OTel GenAI); four secondary sources still unread |
| R-D | DONE (gates CR-04, CR-12, CR-23, D-06, D-21) |
| R-E | DONE (obligations); cost part open pending E-05 |
| E-04, E-05, E-06..E-10 | NOT attempted (require live data / prototypes outside this pass) |
