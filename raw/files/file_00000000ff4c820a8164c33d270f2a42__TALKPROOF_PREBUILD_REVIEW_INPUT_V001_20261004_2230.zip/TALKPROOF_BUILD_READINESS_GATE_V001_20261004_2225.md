# TalkProof — BUILD READINESS GATE — V001

| Field | Value |
|---|---|
| **Created** | 2026-10-04 22:25 (Europe/London) |
| **Version** | V001 |
| **Status** | BUILD-READINESS RECORD — identifies what may enter implementation once the PO signs this package off after independent review; no code written; no sprint created |
| **Source artifacts** | TALKPROOF_SPRINT_TRACKER_RECONCILIATION_V001; TALKPROOF_REQUIREMENTS_RECONCILIATION_V001; TALKPROOF_ARCHITECTURE_RECONCILIATION_V001; V6 Parts 38–45; SPRINT_TRACKER.md; project ways-of-working (plan-first, commit-first, lowest sprint first, 4-layer tests, migrations last) |
| **Scope** | Build-ready work packages; the FIRST BUILD BATCH; blockers |
| **Explicit exclusions** | Nothing blocked on D-06/D-16/D-18/D-21 or on un-issued CR IDs is build-ready; frontend re-opens need the Flutter SDK environment |
| **Decisions consumed** | All approved decisions (see PO decision record) |
| **Unresolved items** | Independent review of this package; PO sign-off; D-06/D-16/D-18/D-21 for batch 2 |
| **Change / provenance** | Created in the 2026-10-04 pre-build pass authorised by the Product Owner decision record of 22:02; author: Claude (builder); no source artefact modified; no code changed; no V7 created. |

## 0. Readiness rule applied
A work package is build-ready only if: (1) its authority is an **approved** requirement or PO decision (no CR, no open D); (2) it belongs to an **existing** sprint; (3) its acceptance criteria and tests are statable from the FRD/NFRD or the tracker's TST-ids; (4) its evidence can be produced in the existing verification environment (pytest + PostgreSQL) or is explicitly deferred to staging; (5) it does not change architecture pending AD-1/AD-3.

## 1. Build-ready work packages

| WP | Authority | Sprint (existing) | Defect / gap | Repos / components | Acceptance criteria | Required tests | Evidence required | D now → D target after WP | Dependencies | Build order |
|---|---|---|---|---|---|---|---|---|---|---|
| WP-01 | D-01 (FR-012, NFR-014) | S03 M02 | HS256 in `core/config.py:37` | backend: core/config.py, services/auth_service.py, tests | RS256 keys configurable; HS256 rejected; refresh/revoke unchanged | unit (jwt alg), integration auth round-trip, negative (HS256 token rejected) | pytest run log; no key committed (NFR-025) | D3 → D3 (conformant) | none | 1 |
| WP-02 | D-08 (FR-011, FR-045) | S03 M02, S10 M09 | `LOCKOUT_MINUTES=15`, `IMPERSONATION_MAX_MINUTES=60` | backend auth_service, impersonate_service | 30-min lockout after 5 fails; impersonation max 120 min | unit + integration; negative (121 min refused) | pytest log | D3 → D3 | none | 1 |
| WP-03 | FR-022/NFR-034 (CD-07) | S05 M04 | no lock on `prev_hash` | backend repositories/audit_repo.py | concurrent writes keep a single valid chain; `verify_chain()` passes under concurrency | integration concurrency test (threads/async) | pytest log | D3 → D3 | none | 1 |
| WP-04 | FR-027 (CD-08 SIEM caller) | S05 M04 | exporter has no caller | backend worker/schedule | export runs on schedule or on trigger; signed | integration | pytest log | D3 → D3 | WP-10 (worker pattern) optional | 2 |
| WP-05 | FR-028/030 (CD-04) | S06 M05 | vault write-only; router result discarded | backend core/crypto.py, provider_service, router | `decrypt_secret` used by router; resolved key returned to caller; platform fallback; spend cap synchronous | unit + integration; negative (no key → 503 `provider_unavailable`) | pytest log | D2 → D3 (router) | none | 1 |
| WP-06 | FR-035 (CD-08 SLA escalation) | S07 M06 | no caller | backend worker | escalation fires at SLA expiry | integration with time control | pytest log | D3 → D3 | WP-10 | 2 |
| WP-07 | FR-042 (CD-02), NFR-025 (CD-05) | S09 M08 | HMAC(body) not Stripe `t=,v1=`; `dev-stripe-secret` default | backend routes/billing.py | Stripe scheme implemented from Stripe's webhook signing reference (version recorded); no default secret; unset secret → startup error | unit (fixture with provenance), negative (bad sig 400) | pytest log + reference citation | D3 → D3 | none | 2 |
| WP-08 | NFR-025 (CD-05) | S21 M20, S34 M24 | `dev-secret` defaults | backend routes/webhooks.py:30,32 | no default; unset → refuse to start | unit | pytest log | — | none | 1 |
| WP-09 | FR-078, NFR-030 (CD-08, G36) | S21 M20 | consent never enforced; no DNC | backend call_service / telephony_service / whatsapp_service initiation paths; compliance_service | US-number outbound without consent → 403; DNC blocks; revocation ≤1 s; consent id recorded on the call | integration (positive, negative, revocation timing) | pytest log | D2 → D3 | none | 1 |
| WP-10 | FR-080 (CD-08 rate limiter) | S21 M20 | middleware unused | backend main.py | limiter wired; configurable | integration | pytest log | D2 → D3 | none | 1 |
| WP-11 | M22 scope, NFR-065 (CD-11) | S23 M22 | orchestrator calls not ledgered; model name only | backend orchestrator_service `_call_*`, ai_ledger_service, models/ai_ledger.py (+ migration for `model_version`) | every orchestrator model call writes a ledger row; version recorded (or "unversioned") | integration; migration up/down/up | pytest log | D3 → D3 (conformant) | none — **independent of D-18** | 2 |
| WP-12 | FR-075/NFR-046 (G28) | S20 M19 | primitives unused | backend provider call sites | each external call wrapped in a per-service CircuitBreaker | integration (chaos: trip + unrelated service unaffected) | pytest log | D2 → D3 | none | 2 |
| WP-13 | FR-006/NFR-038 (row 1) | S02 M01 | RLS helpers never called | backend migration (policies), db session event | RLS enabled on domain tables; dual-layer test passes with each layer disabled in turn | integration on PostgreSQL | pytest log; policy dump | D2 → D3 | none | 2 |
| WP-14 | FR-058, BR-15 (CD-10) | S33 M23 | no production writer | backend orchestrator `_download_recording`, storage resolver | recording bytes written via resolved driver; key + SHA-256 stored on the call | integration with MemoryDriver + S3 adapter contract test (provenance recorded) | pytest log | D3 → D3 (integrated); D1 (dual-channel) unchanged | none | 2 |
| WP-15 | FR-052, BR-18 (CD-09) | S47 M29-T02..T05 | adapter absent in ZIP | backend services/transcription/*, orchestrator `_transcribe`, config keys | no config → whisper identical; config → engine; second real adapter from Google STT docs; segments/confidence persisted | TST-M29-1; contract tests per CR-03 principle | pytest log | D2 → D3 (abstraction) | WP-05 (keys via vault) recommended first | 3 |
| WP-16 | FR-040/053 (D-04, D-05, CD-16), BR-18 | S48 M30-T01..T06 | roster hardcoded; one-failure tolerated; vocabulary; Gemini tokens; fence stripping | backend orchestrator `_ai_verify`, `_call_*`, new adapters | three adapters; roster from config; **any failure → `needs_manual_review` (FR-040)**; 60-s timeout; `confirmed/disputed/uncertain` persisted; tokens/cost for all three | TST-M30-1; negative (one model down → manual review) | pytest log | D3 → D3 (conformant) | WP-05 | 3 |
| WP-17 | FR-028/030, BR-18 (G04) | S49 M31-T01..T05 | `os.environ` keys | backend orchestrator, iota_service, storage drivers, pdf_service | zero `os.environ` key reads; keys via vault; per-tenant metering + 402 | TST-M31-1 (security) | pytest log + grep proof | D2 → D3 | WP-05 | 3 |
| WP-18 | BR-18 | S50 M32 | fixed vote | backend | strategies + config; HUMAN_REVIEW preserved | TST-M32-1 | pytest log | D3 → D3 | WP-16 | 4 |
| WP-19 | NFR-023 (CD-06), BR-18 | S51 M33-T01..T02 only | interface + IOTA adapter; undeclared dep | backend iota_service, requirements.txt | `CertificationProvider` interface; IOTA adapter declares and uses a real client lib (or is marked D2 until it does); failure-no-block parity | TST-M33-1 (part) | pytest log | D2 → D2/D3 | none for T01–T02; **T03–T05 blocked (D-06/D-16)** | 4 |
| WP-20 | FR-056/BR-16 (CD-01) | S43 M25 | wrong settings attr; relative callback | backend campaign_carrier/resolver.py:109-112, call_service | Exotel adapter conformance per Exotel API reference (version recorded) | contract test with provenance | pytest log | D2 → D3 | WP-17 | 4 |
| WP-21 | BR-14 (EV-03) | S34 M24 | GET handshake absent; bare digest accepted; `_send` fake | backend routes/webhooks.py, whatsapp_service | `hub.verify_token` handshake; only `sha256=<hex>`; real Graph send adapter from Meta docs | integration + contract (provenance) | pytest log | D2/D3 → D3 | WP-08 | 4 |
| WP-22 | NFR-057 / D-11 (CD-17) | S24 policy | gate red at 99.74 % | backend tests | either the 23 lines covered or `fail_under` set to the policy value with a dated note | CI | CI log | — | none | 1 |
| WP-23 | BR-11 / CR-01 principle | tracker | TC-1..TC-12 | docs/92_planning | tracker aligned to code facts | review | commit | — | PO acceptance of §1 of the tracker reconciliation | 1 |

## 2. NOT build-ready (and why)

| Package | Blocked by |
|---|---|
| S51 M33-T03..T05 (TSA adapter, provider-from-config, lifecycle integration) | D-06 (ordering), D-16 (record format) |
| S12 M11-T05/T06 re-open (per-call anchor, PDF, TSA; CD-13; RC-10 bindings) | D-06, D-16; S51 |
| Any CR-01..CR-23 implementation | governance has not issued IDs; D-18/D-21 for CR-15/CR-12 |
| Evidence record / status service / verifier | D-06, D-16, D-21, CR-07/CR-23/CR-12 |
| Flutter iOS/desktop (CD-14), native plugins | Flutter SDK verification environment; signing certs (BRD C-05) |
| WebSocket/LiveKit/push real transports (S14–S16) | P2; not blocked by decisions but outside the proof-chain priority; schedule after batch 2 |
| Object Lock, Tier B/C provisioning, deployment | infrastructure (EV-04) |
| S56 Telegram | P2; BR-19 tracker-only (PD-A) |
| S39 | project rule: blocked on team onboarding |

## 3. FIRST BUILD BATCH (recommended)

Order 1 packages, all with authority = approved decision or unchanged FR/NFR, all in existing sprints, lowest sprint first, each a commit-first ticket with tests in the same commit:

| Seq | WP | Sprint | One-line scope |
|---|---|---|---|
| 1 | WP-22 | S24 policy | make the coverage gate honest (D-11) |
| 2 | WP-23 | tracker | apply TC-1..TC-12 (docs only) |
| 3 | WP-13 | S02 | RLS policies + dual-layer test |
| 4 | WP-01 | S03 | RS256 |
| 5 | WP-02 | S03/S10 | lockout 30 min; impersonation 120 min |
| 6 | WP-03 | S05 | audit chain concurrency lock |
| 7 | WP-05 | S06 | vault read path + router result (prerequisite for S47–S51) |
| 8 | WP-08 | S21/S34 | remove `dev-secret` defaults |
| 9 | WP-09 | S21 | consent enforcement + DNC on initiation paths |
| 10 | WP-10 | S21 | wire rate limiter |

Expected result of batch 1: eight closed sprints become conformant with their own approved requirements; no new feature; no architecture change; no decision dependency; suite stays green at the honest gate. Batch 2 (order 2–3): WP-04, 06, 07, 11, 12, 14, then S47 → S48 → S49 (WP-15..17). Batch 3 (order 4): WP-18..21. Batch 4: everything released by D-06/D-16/D-18/D-21.

## 4. Blockers preventing coding (as of this gate)

| # | Blocker | Blocks | Owner |
|---|---|---|---|
| B-1 | This package has not been independently reviewed or signed off by the PO | everything (process gate) | PO + reviewer |
| B-2 | D-06, D-16 (yes/no), D-18, D-21 undecided | batch 4; S51 T03–T05; S12 re-open | PO |
| B-3 | No staging/production environment (EV-04) | all D5+ evidence; token-level E-02; WP-14 Object Lock part | ops |
| B-4 | No Flutter SDK in the verification environment (EV-05) | frontend re-opens | ops |
| B-5 | Provider sandbox credentials (Exotel, Meta, Stripe, Google STT) not available to the builder | D4 contract runs for WP-07/15/20/21 (code can be written; conformance evidence waits) | PO/ops |
| B-6 | PD-A undecided (BRD amendment) | nothing in code; documentation only | PO |

**There is no technical blocker to batch 1.** It is gated only by B-1.
