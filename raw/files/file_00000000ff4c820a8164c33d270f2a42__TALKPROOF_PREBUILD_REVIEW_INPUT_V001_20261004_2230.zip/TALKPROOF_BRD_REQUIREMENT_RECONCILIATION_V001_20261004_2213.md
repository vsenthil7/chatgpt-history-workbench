# TalkProof — BRD REQUIREMENT RECONCILIATION — V001

| Field | Value |
|---|---|
| **Created** | 2026-10-04 22:13 (Europe/London) |
| **Version** | V001 |
| **Status** | ANALYSIS — reconciliation record; proposes, does not apply, document amendments |
| **Source artifacts** | docs/01_brd/BRD.md (= supplied TALKPROOF_BRD.md, SHA-256 identical); docs/02_requirements/PRD.md v1.0.1; FRD.md v1.0.1; NFRD.md v1.0.0; docs/03_architecture/ARCHITECTURE.md ARCH-001 v1.1; TELECOM_PROVIDER_POLICY.md; docs/92_planning/TRACEABILITY.md §1; SPRINT_TRACKER.md; V6 Parts 1, 2, 7, 38–41 |
| **Scope** | BRD-001 authority chain; BR-01..BR-10 against R-01..R-44 and the 46 V6 rows; ACs, assumptions, constraints, risks, OOS; source of BR-11..BR-19; BR-03/05; version footer; prior PO decisions that supersede BRD statements |
| **Explicit exclusions** | No BRD text is amended here; no new BR identifier is invented; D-levels are not re-assessed |
| **Decisions consumed** | D-15 (BRD-001 is parent authority); D-01..D-14 as recorded in V6 Part 7 |
| **Unresolved items** | Whether BRD-001 should be amended to v1.1 to absorb tracker BR-11..BR-19 and the superseded A-03/C-03/OOS-02 statements — PROPOSED PO DECISION, see §9 |
| **Change / provenance** | Created in the 2026-10-04 pre-build pass authorised by the Product Owner decision record of 22:02; author: Claude (builder); no source artefact modified; no code changed; no V7 created. |

## 1. Authority chain (as the documents themselves declare it)

| Rank | Document | ID / version / status | Evidence | Position after D-15 and V6 Part 7 |
|---|---|---|---|---|
| 0 | Product Owner dated decisions | V6 Part 7 (2026-10-04 19:16/19:18) + PO record 22:02 | — | Supersede any document statement they explicitly resolve (D-03, D-07, D-09 etc.). Nothing else is superseded by implication. |
| 1 | **BRD-001** | v1.0.1 · 2026-06-16 · "Approved for Development" · owner WET | `docs/01_brd/BRD.md` | **Parent authority (D-15)**. Business intent, BR-01..BR-10, ACs, A/C/R/OOS. |
| 2 | PRD-001 | v1.0.1 · 2026-06-16 · Approved for Development · related BRD-001/FRD-001/NFRD-001 | `docs/02_requirements/PRD.md` | Product scope, personas, epics, release plan. |
| 3 | FRD-001 / NFRD-001 | v1.0.1 / v1.0.0 · 2026-06-16 · Approved for Development | `docs/02_requirements/FRD.md`, `NFRD.md` | FR-001..FR-082, NFR-001..NFR-067. Binding requirement text. |
| 4 | ARCH-001 | v1.1 · "Baseline (stack-corrected)" · 2026-06 | `docs/03_architecture/ARCHITECTURE.md` | Design baseline; **not** a requirement source. Where it conflicts with FRD/NFRD the FRD/NFRD wins unless a PO decision says otherwise (V6 Part 7 principle, applied in D-01, D-08, D-10). |
| 4 | TELECOM_PROVIDER_POLICY | "Active" · M25/S43 · cites BR-16 | `docs/03_architecture/` | Operational policy for one module; subordinate to FRD. |
| 5 | SPRINT_TRACKER / TRACEABILITY | living planning record, 16 Jun → 29 Jun 2026 | `docs/92_planning/` | Planning and attestation; never requirement authority (V6 Part 4 D-02 rationale). **Carries BR-11..BR-19 (see §4).** |

Chain confirmed consistent in the documents' own "Related Documents" fields: BRD ↔ PRD ↔ FRD ↔ NFRD cross-reference each other; ARCH references none of them by ID.

## 2. BR-01..BR-10 against the recovered requirements (R-01..R-44), FRs and V6 rows

| BR | BRD statement (short) | FRs that implement it (FRD §) | R-/G- rows touching it | V6 rows | Conflict / finding |
|---|---|---|---|---|---|
| BR-01 Multi-tenant SaaS by WET | onboard/manage/suspend/offboard tenants; AC-01.1..01.5 (plan/quota, suspend, export, metrics, impersonation) | FR-005, FR-009, FR-010, FR-044..047 | R-? impersonation 2 h (FR-045) vs code 60 min → D-08 | 1, 2, 3 (impersonation) | AC-01.5 time-box: BRD says "time-box"; FR-045 says max 2 h; code 60 min. **D-08 decided (2 h stands)** — no BRD conflict. |
| BR-02 Certified outbound campaigns | recorded, transcribed, 3-model consensus, tamper-proof blockchain-anchored PDF **gated by HiL before issuance**; AC-02.5 approve → issue PDF with hash + RFC3161 + anchor; AC-02.6 offline verifiable; AC-02.7 verbatim disclosure recorded immutably; AC-02.3 ≤3 min | FR-050..055, FR-040, FR-058, FR-078 | R-09 (approval precedes certification) ✔ consistent; R-10 ARCH (anchor before HiL) ✘ conflicts BRD too; R-06/R-36 offline verification ✔; G38 consent/disclosure not bound | 14–21, 24, 38 | **BRD-001 sides with the FRD on ordering** (approval first) → evidence for D-06. **AC-02.7 (verbatim disclosure immutably recorded) has no FR of its own** — NFR-030(d) carries it; code: not captured (Part 41 consent row). AC-02.3 "3 minutes" has no FR/NFR counterpart (NFR-004 throughput only) — gap in requirement coverage. |
| BR-03 Real-time comms suite | PSTN calls, chat, meetings | FR-056..066 | R-16 LiveKit; G19/G20 absent | 23, 25–30, 46 | No BRD/FRD conflict; code far below (D2). Row 46 inbound calling maps to BR-03 — consistent (see §5). |
| BR-04 HiL gating | every consequential action HiL-gated; AI advisory | FR-032..037 | R-02 proof thesis; D-09 | 10, 11 | Consistent. FR-032 "≥1 reviewer approval floor cannot be changed by tenant config" is the BR-04 floor. |
| BR-05 Forensic audit trail | hash-chained, per-IP; `verify_chain()` | FR-022..027 | CD-07 (race) | 6, 7 | Consistent; CD-07 is a conformance defect against FR-022. Row 46 inbound audit parity maps to BR-05 — consistent (§5). |
| BR-06 Isolation tiers | shared pool / dedicated schema / single tenant | FR-006..008 | G49; row 1 RLS D2 | 1, 2 | Consistent; **R-04 risk mitigation in BRD names RLS** — code has RLS helpers never called (FR-006 "both layers active"). Conformance gap, not a document conflict. |
| BR-07 BYO provider keys | AC-07.2 test-connection verifies key before saving | FR-028..031 | G24 `_probe` length check; CD-04 vault write-only | 8, 9 | AC-07.2 as written requires a real provider probe; FR-029 same; code does not. Conformance gap. |
| BR-08 Security/compliance/billing | SSO/MFA, RBAC, KMS, SOC2/GDPR/TCPA/HIPAA-ready; freemium/premium/enterprise | FR-011..021, FR-041..043, FR-074..080; NFR-014.. | D-01 RS256; D-08; G23 Fernet not KMS; CD-02 Stripe | 3, 4, 5, 34–40 | Consistent at BR level; FR/NFR-level drift decided in D-01/D-08/D-10/D-11. |
| BR-09 Web/desktop/mobile from shared code | Flutter app + React admin (v1.0.1 correction); AC-09.3 desktop targets; AC-09.4 store review | FR-002/003, FR-067..073; PRD E-15 | D-02 (M17 = Flutter desktop); CD-14 (`android/` only, no `ios/`, no desktop targets) | 31, 32, 33 | Consistent with D-02. AC-09.3/09.4 are far from met (row 32 D2). |
| BR-10 White-label & positioning | resale under own brand; AC-10.5 Professional ≤ $499/mo | FR-081/082, FR-041 | row 41 UNABLE beyond D3 | 41 | No conflict. Pricing ACs are commercial, not testable in code. |

**Conclusion of §2:** no BR-01..BR-10 statement contradicts a recovered requirement or a PO decision. Two BRD acceptance criteria lack a dedicated FR (AC-02.3 three-minute pipeline; AC-02.7 verbatim disclosure immutability beyond NFR-030(d)) — recorded as **requirement-coverage gaps** for `TALKPROOF_REQUIREMENTS_RECONCILIATION_V001` (no ID issued here).

## 3. Assumptions, constraints, risks, out-of-scope — reconciled against PO decisions and code

| BRD item | Statement | Reconciliation | Status |
|---|---|---|---|
| A-03 | Anchoring on Hedera/Ethereum/private provides admissibility | **Superseded by D-03** (provider-neutral; named providers become adapters). Admissibility question itself → R-D/R-E. | SUPERSEDED (decision) |
| A-04 | RFC3161 TSAs available and admissible | Consistent with NFR-024; no TSA implemented (row 17 D1). Admissibility → R-D. | OPEN (research) |
| A-07 | Flutter mobile approvable by stores without architectural change | Contradicted by code: no `ios/`, no native plugins (CD-14). | AT RISK |
| C-03 | Ethereum gas volatile; Hedera/private preferred | Superseded by D-03 (adapter choice, not product identity). | SUPERSEDED |
| C-04 | PSTN via Twilio/Telnyx/Vonage | **D-07**: provider-neutral; Exotel is another adapter. FR-056 list to be reworded (G16). | SUPERSEDED |
| C-05 | Desktop code-signing certificates | Consistent with D-02; nothing built. | OPEN |
| C-08 | API back-compat once a tenant is live | = NFR-059; no tenant live. | CONSISTENT |
| R-01 | Model independence (≥2 vendors) | = FR-040 rule; code uses Anthropic/OpenAI/Google ✔ (row 14). | CONSISTENT |
| R-04 | Tier-A cross-contamination; mitigation RLS | FR-006; code RLS absent → mitigation not in force (row 1 D2). | AT RISK |
| R-07 | App Store rejection | See A-07. | AT RISK |
| OOS-01 | Outbound AI voice agents out of scope | = D-09 Option B. | CONSISTENT |
| OOS-02 | Native WhatsApp Business API out of scope for v1.0, deferred to v1.1 | **Contradicted by the planning layer**: tracker BR-14 / S34 / M24 built WhatsApp (June 2026) without a BRD amendment. The BRD was not updated. | **DOCUMENT CONFLICT → PO decision proposed (§9, PD-A)** |
| OOS-06 | Real-time translation deferred to v1.2 | No code; consistent. | CONSISTENT |
| OOS-07 | Custom blockchain for Tier A out of scope | Under D-03 any anchor adapter is configurable; the BRD's commercial tiering of which adapter a tier may select is a packaging rule, not contradicted. | CONSISTENT |

## 4. Source of BR-11..BR-19 (the "BR-14 / BR-15 / BR-18" references)

**Resolved.** `docs/92_planning/TRACEABILITY.md §1` extends the BR table beyond BRD-001: BR-11 (verification/duplication/history, June S24–S27), BR-12/BR-13 "_(reserved)_", BR-14 (WhatsApp channel, M24/F05/F06), BR-15 (pluggable storage, M23/F05), BR-16 (campaign carrier abstraction, M25), BR-17 (de-politicised vocabulary, M26), BR-18 (config-driven pipeline, M27 and children M28–M33), BR-19 (Telegram, M38). These were added in June 2026 planning sessions (tracker footers 2026-06-21..06-26). **They exist only in the planning layer; BRD-001 v1.0.1 was never amended to include them.** V6 Part 38's "BR-14/15/18" citations are therefore correct as references to TRACEABILITY §1, but they are **not** BRD-001 authority. Consequence: the V6 "Authoritative requirement" column for rows 22, 43, 44, 45 cites a planning-layer BR, and the D4 for row 45 rests on the S46 plan contract (`_plan_S46_M28_config_resolver.md`) — unchanged and still valid as a component contract.

## 5. BR-03 / BR-05 on row 46 — not a mismatch

V6 row 46 (inbound calling + polymorphic pipeline) cites BR-03/05. TRACEABILITY RT-31 (I01, S31) and RT-59 (I02, S59) map to **BR-03 (PSTN calling) and BR-05 (audit parity: inbound now writes the same forensic audit row as outbound)**. In BRD-001, BR-03 is the real-time communications suite (PSTN calls) and BR-05 the forensic audit trail. The mapping is semantically correct. The gate's "semantic mismatch" flag is withdrawn.

## 6. BRD header/footer version inconsistency

Header table: Version 1.0.1 (revision 1.0.1 dated 2026-06-16 recorded). Footer line 516: "*End of BRD-001 v1.0.0*". Clerical. Proposed fix: footer → v1.0.1 in the next BRD revision (PD-A below). No effect on authority.

## 7. ARCH-001 statements superseded or contradicted (for the architecture reconciliation)

| ARCH item | Statement | Status |
|---|---|---|
| ADR-007 | RFC 3161 + IOTA dual timestamp | IOTA as named anchor superseded by D-03 (adapter). The *dual* (TSA + anchor) principle is consistent with FR-054(3)(4). |
| §10 flowchart | anchor → PDF → HiL gate | Conflicts with FR-054 Description and BRD AC-02.5 (approval first). D-06 open; recommendation in `TALKPROOF_CERTIFICATE_LIFECYCLE_ARCHITECTURE_V001`. |
| §11.1 model names | GPT-4o, Claude 3.5 Sonnet, Gemini 1.5 Pro | Design baseline only; model roster is configuration (BR-18/S48), not architecture. |
| ADR-009 | Polling orchestrator Phase 1 → Celery Phase 2 | Code: 60-s poll; Celery declared unused (CD-15). Consistent with Phase 1. |
| §8 RLS | RLS for Tier A | Required by FR-006; absent in code (row 1). |

## 8. Prior PO decisions that override BRD statements (recorded, no action)

D-03 overrides A-03/C-03 (anchor providers); D-07 overrides C-04 (carrier list); D-09 Option B is consistent with OOS-01 and adds a scoped capability the BRD does not mention (AI-originated interactions captured/verified as evidence); D-12/D-13 add bindings and provider-configuration requirements the BRD does not state. None of these contradicts a BR; they refine below BR level.

## 9. Proposed Product Owner decision items arising (PROPOSED — not decided; numbering continues the V6 register for convenience and is subject to PO acceptance)

| Proposed | Question | Options | Analyst recommendation |
|---|---|---|---|
| **PD-A (candidate D-27)** | Amend BRD-001 to v1.1 to (i) absorb the planning-layer BR-11..BR-19 as business requirements, (ii) retire OOS-02 (WhatsApp built), (iii) record D-03/D-07 as superseding A-03/C-03/C-04, (iv) fix the footer version? | amend now / amend at next release / leave BRD at v1.0.1 and keep BR-11..19 as "tracker BRs" | **amend now** — the BRD is the parent authority (D-15); a parent that omits six active business requirements and lists a built feature as out of scope is not fit to govern. Documentation change only; no scope change (the scope already exists in the tracker). |
| **PD-B (candidate D-28)** | Are AC-02.3 (≤3-minute transcription + consensus) and AC-02.7 (verbatim disclosure recorded immutably) to receive FR/NFR coverage? | yes (route to requirements reconciliation) / no (BRD AC stands alone) | **yes** — both are testable acceptance criteria with no FR/NFR owner; AC-02.7 is the TCPA proof claim the product sells. |

## 10. Reconciliation result

- BRD-001 accepted as parent authority: **applied as record** (D-15).
- Conflicts found: 1 document conflict (OOS-02 vs built BR-14), 0 BR-level conflicts with recovered requirements, 2 AC coverage gaps, 1 clerical (footer), 3 superseded assumptions/constraints (A-03, C-03, C-04), 3 at-risk assumptions (A-07, R-04, R-07).
- BR-11..BR-19 provenance: TRACEABILITY §1, June 2026 — not BRD-001.
- No BR identifier invented; BR-12/BR-13 remain "_(reserved)_" as the tracker records them.
