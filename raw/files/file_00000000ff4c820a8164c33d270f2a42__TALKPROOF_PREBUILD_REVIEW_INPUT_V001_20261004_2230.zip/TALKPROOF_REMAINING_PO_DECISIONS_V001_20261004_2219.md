# TalkProof — REMAINING PO DECISIONS — V001

| Field | Value |
|---|---|
| **Created** | 2026-10-04 22:19 (Europe/London) |
| **Version** | V001 |
| **Status** | RECOMMENDATION RECORD — NO PRODUCT OWNER DECISION HAS BEEN APPLIED BY THIS ARTIFACT |
| **Source artifacts** | TALKPROOF_CERTIFICATE_LIFECYCLE_ARCHITECTURE_V001; TALKPROOF_EVIDENCE_RESEARCH_PACK_V001; TALKPROOF_CR_REQUIREMENTS_ANALYSIS_V001 (CR-15, CR-12, CR-07); TALKPROOF_BRD_REQUIREMENT_RECONCILIATION_V001 (§9); V6 Part 46 |
| **Scope** | Final recommendations for D-06, D-18, D-21; the D-16 yes/no follow-on; the two proposed decision items from the BRD reconciliation; the architecture decisions that need PO approval |
| **Explicit exclusions** | Does not decide anything; does not issue IDs; does not schedule sprints |
| **Decisions consumed** | All decisions in TALKPROOF_PO_DECISION_RECORD_V001 |
| **Unresolved items** | D-06, D-16 (follow-on), D-18, D-21, PD-A, PD-B, AD-1..AD-5 — all await the PO after independent review |
| **Change / provenance** | Created in the 2026-10-04 pre-build pass authorised by the Product Owner decision record of 22:02; author: Claude (builder); no source artefact modified; no code changed; no V7 created. |

## 1. D-06 — HiL / anchor / PDF ordering

**Question (unchanged):** (a) FRD approval → anchor → PDF · (b) ARCH anchor → PDF → HiL · (c) two timestamps.

**Evidence now complete:** lifecycle defined (architecture artefact §1); E-02 shows the two-timestamp chain wraps the existing `content_hash` additively; R-C confirms RFC 4998 chain/renewal semantics; R-D shows a court-class relying party needs the capture→review custody proven; BRD-001 AC-02.5 and FR-054 both put approval before issuance, so (b) is unsupported by any approved document.

**RECOMMEND OPTION (c)** — T0 RFC 3161 timestamp over the evidence root before reviewer presentation; T1 RFC 3161 timestamp + anchor over the certificate leaf (evidence root + approval record + payload) after approval; PDF after T1; rejections and status changes timestamped; T0 anchoring optional/batched.

**Confidence:** MEDIUM-HIGH. **Residual blocker (not a blocker to deciding):** token-level E-02 verification on staging with a public TSA; TSA cost at volume (E-05).

**If approved, consequential approvals needed:** D-16 = yes (below); CR-07, CR-04/05/06, CR-23 to proceed through governance; S51/M33 and S12/M11 conformance work ordered in `TALKPROOF_BUILD_READINESS_GATE_V001`.

## 2. D-16 follow-on — ERS / ETSI LTV as the evidence-record substrate (yes / no)

The PO approved investigation only. E-02 and R-C are done.

**RECOMMEND "yes"** — adopt RFC 4998 ERS (ASN.1; RFC 6283 XML as export) as the evidence-record substrate, with ETSI TS 119 312 (current version) as the algorithm-deprecation trigger source. Reason: structural fit proven on the real hashing code with no re-issue; the standard provides the renewal mechanism V6 identified as the biggest omission; no bespoke format is needed. **Confidence:** HIGH. **Evidence still outstanding before the first production record:** one staging run obtaining a real TSA token (cheap); choice of Python ERS implementation vs Java sidecar (engineering, CR-07 build).

## 3. D-18 — Decision Ledger (CR-15): yes (new OTel-based schema) / amend (extend M22)

**Evidence now complete:** CR-15 expanded; R-C: no `gen_ai.*` attribute is Stable, the conventions moved to a separate repository on 12 June 2026 with no tagged release, and attributes were renamed across 2026; code: `AIInteractionLedger` already exists, is persisted and hash-chain-linked, but is bypassed by the orchestrator (CD-11) and lacks version/outcome/decision fields.

**RECOMMEND OPTION "amend"** — keep `AIInteractionLedger` (M22) as the persisted ledger; extend it with the CR-15 fields (decision_id, capability, model_version, prompt_version, provider_version, policy/regulation versions, outcome=UNKNOWN default, outcome_verified_by, outcome_proposed_by_ai, correction_id); treat the OTel GenAI conventions as a **versioned export mapping**, not the storage schema; close CD-11 as an M22 conformance item independently of this decision.

**Confidence:** HIGH. **Evidence required before approval:** NONE beyond this pass. **Requirement effect:** M22 scope wording extended (proposed in the requirements reconciliation, no ID issued).

## 4. D-21 — Standalone published verifier (CR-12) becomes a requirement: yes / no

**Evidence now complete:** R-D done; CR-12 expanded; three existing sources already require offline verifiability (NFR-024 `openssl ts`, FR-055 in-browser hash after download, BRD AC-02.6 "without platform access"); code: nothing verifiable leaves the server (D1).

**RECOMMEND "yes"** — CR-12 proceeds through governance as a requirement (published, versioned, signed verifier; in-browser FR-055 check shares its core; R-D "proves / does not prove" output mandatory). This changes V2's "any CLI is DESIGN" position because the BRD-level acceptance criterion (AC-02.6) is not met by the FR-055 in-browser check alone once the evidence record exists outside the PDF.

**Confidence:** HIGH. **Evidence required before approval:** NONE. **Consequence:** CR-11 condition then met; CR-09 and CR-23 depend on it.

## 5. Proposed decision items from the BRD reconciliation (PROPOSED, unnumbered until the PO accepts them into the register)

| Proposed | Question | Recommendation |
|---|---|---|
| PD-A | Amend BRD-001 → v1.1: absorb tracker BR-11..BR-19; retire OOS-02 (WhatsApp built); record D-03/D-07 superseding A-03/C-03/C-04; fix footer version | **amend now** (documentation only) |
| PD-B | Give AC-02.3 (≤3-minute transcription+consensus) and AC-02.7 (verbatim disclosure recorded immutably) FR/NFR coverage | **yes** |

## 6. Architecture decisions requiring PO approval (from `TALKPROOF_ARCHITECTURE_RECONCILIATION_V001`)

| AD | Decision | Recommendation |
|---|---|---|
| AD-1 | Replace ARCH-001 §10 flowchart with the lifecycle §1 (depends on D-06) | yes, after D-06 |
| AD-2 | Reword ADR-007 to "RFC 3161 archive timestamps (T0/T1) + provider-neutral anchor" (D-03 already requires the second half) | yes |
| AD-3 | Introduce `EvidenceRecordService` (ERS build/verify/renew) and `CertificateStatusService` as components; TSA client as its own adapter distinct from the anchor adapter (S51/M33) | yes, after D-16/CR-07 |
| AD-4 | Record ADR-009 Phase-1 polling as current; Celery/Redis declared-unused (CD-15) to be either removed from requirements/compose or scheduled — PO to choose | remove until a Phase-2 trigger exists |
| AD-5 | ARCH §11 model names and AI gateway: state that roster/provider are configuration (BR-18) and that the AI gateway/provider router is the mandatory key path (D-13, CD-04) | yes |

## 7. Decision sheet

| Decision | Recommendation | Confidence | PO can decide now? | Remaining blocker |
|---|---|---|---|---|
| D-06 | OPTION (c) | MEDIUM-HIGH | Yes | none for the decision; staging TSA run before first production certificate |
| D-16 follow-on | yes (ERS) | HIGH | Yes | none |
| D-18 | amend (extend M22) | HIGH | Yes | none |
| D-21 | yes (CR-12 requirement) | HIGH | Yes | none |
| PD-A | amend BRD now | HIGH | Yes | none |
| PD-B | yes | HIGH | Yes | none |
| AD-1..AD-5 | as tabled | HIGH | AD-2, AD-4, AD-5 now; AD-1/AD-3 after D-06/D-16 | — |

**STOP. These are recommendations. Nothing above is applied until the Product Owner records a decision.**
