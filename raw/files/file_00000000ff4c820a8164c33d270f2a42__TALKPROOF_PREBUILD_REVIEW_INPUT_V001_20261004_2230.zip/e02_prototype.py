"""E-02 read-only prototype: can an RFC 4998 ERS-style evidence record wrap the
existing S12 CallCertificate canonical-JSON content_hash WITHOUT changing it?

Uses the production hashing functions from the supplied repo (import only; no DB,
no network, no code change). Hash tree + archive-timestamp CHAIN are modelled in
pure Python; the TSA token itself is NOT obtained (no TSA reachable here) and is
represented by a placeholder record. Conclusions are structural only.
"""
import hashlib, json, sys
sys.path.insert(0, ".")
from app.services.certified_voice_service import _canonical_json, _sha256  # production functions

# 1. Exactly the 7-field payload shape built by draft_certificate() (certified_voice_service.py:146-154)
payload = {"call_id":"11111111-1111-1111-1111-111111111111","campaign_id":"22222222-2222-2222-2222-222222222222",
           "tenant_id":"33333333-3333-3333-3333-333333333333","verdict":"POSITIVE","agreement":"0.667",
           "model_count":3,"per_model":{"claude-3-5-sonnet":"POSITIVE","gpt-4o":"POSITIVE","gemini-1.5-pro":"NEGATIVE"}}
canonical = _canonical_json(payload)
content_hash = _sha256(canonical)              # == CallCertificate.content_hash today
print("existing content_hash:", content_hash)

# 2. ERS data-object group at T0 (evidence root): leaves are hashes of data objects.
#    The EXISTING content_hash is used as-is as one leaf. Other leaves are the bindings D-12 accepted
#    (recording, transcript, model/prompt provenance) — placeholders here; absent today in code.
def h(b: bytes) -> bytes: return hashlib.sha256(b).digest()
leaves_T0 = {
  "certificate_payload": bytes.fromhex(content_hash),          # unchanged existing hash
  "recording":  h(b"<recording bytes>"),                        # Part 41: not stored today
  "transcript": h(b"<transcript text>"),                        # Part 41: no transcript hash today
  "provenance": h(b'{"models":[...],"prompt_version":"..."}'),  # CR-04 candidate
}
def merkle_root(leaf_hashes):
    nodes = sorted(leaf_hashes)                                   # RFC 4998 §4.2: sort hashes in a node before concat
    while len(nodes) > 1:
        if len(nodes) % 2: nodes.append(nodes[-1])
        nodes = [h(nodes[i]+nodes[i+1]) for i in range(0,len(nodes),2)]
    return nodes[0]
root_T0 = merkle_root(list(leaves_T0.values()))
ats_T0 = {"reducedHashTree": "<path for each leaf>", "timeStamp": "<RFC3161 TimeStampToken over root_T0 — NOT OBTAINED (no TSA reachable)>",
          "rootHex": root_T0.hex(), "digestAlgorithm": "sha256"}

# 3. T1: approval record + reference to T0 root → second archive timestamp (D-06 option (c))
approval = {"proposal_id":"<hil proposal>","approver_role":"reviewer","decision":"approved","evidence_root_T0": root_T0.hex(),
            "certificate_content_hash": content_hash}
leaf_T1 = h(_canonical_json(approval).encode())
root_T1 = merkle_root([leaf_T1, root_T0])
ats_T1 = {"rootHex": root_T1.hex(), "timeStamp": "<RFC3161 TimeStampToken over root_T1 — NOT OBTAINED>", "digestAlgorithm": "sha256"}

# 4. Verifier side: given payload + leaves + both ATS, recompute without any TalkProof service.
assert _sha256(_canonical_json(payload)) == content_hash
assert merkle_root(list(leaves_T0.values())) == root_T0
assert merkle_root([h(_canonical_json(approval).encode()), root_T0]) == root_T1
# 5. Renewal (RFC 4998 timestamp renewal): new ATS over hash of previous timestamp — chain grows, old bytes untouched.
record = {"version":1,"digestAlgorithms":["sha256"],"archiveTimeStampSequence":[[ats_T0],[ats_T1]]}
print(json.dumps(record, indent=1)[:600])
print("RESULT: existing content_hash wraps unchanged as an ERS leaf; no certificate re-issue needed. Missing in code: algorithm id, recording/transcript hashes, approval record in hashed material, any TSA token.")
