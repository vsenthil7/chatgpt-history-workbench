# TalkProof — TRACEABILITY — V001

| Field | Value |
|---|---|
| **Created** | 2026-10-04 22:22 (Europe/London) |
| **Version** | V001 |
| **Status** | TRACEABILITY RECORD — derived from authoritative documents and V6; no D-level re-assessed; no ID issued |
| **Source artifacts** | BRD-001; TRACEABILITY.md §1–2 and sprint status; SPRINT_TRACKER.md index + S12/S45–S59; FRD/NFRD registers; PRD §5/§7; ARCH-001; V6 Part 38 (46 rows), Parts 39–45; backend code paths as cited in V6/E-01 and re-checked for rows 16–19, 42, 45 |
| **Scope** | Full chain for all 46 capability rows; decision→requirement→sprint chain; BR-02 acceptance-criterion coverage |
| **Explicit exclusions** | HLD/LLD/BDD/TEST_CASES not cross-indexed in this pass; Flutter/admin tests not executed here (EV-05) |
| **Decisions consumed** | All approved decisions; open decisions shown as open |
| **Unresolved items** | Target D-levels are V4 planning targets, not approved requirements; CG-1/CG-2 coverage pending PD-B |
| **Change / provenance** | Created in the 2026-10-04 pre-build pass authorised by the Product Owner decision record of 22:02; author: Claude (builder); no source artefact modified; no code changed; no V7 created. |

Chain: Business requirement → product module → FR/NFR → PO decision → architecture component → existing sprint → code area → acceptance criterion/test → evidence → current D-level → target D-level. One row per V6 capability (46 rows, V4 Part 3 order; D-levels are the frozen V6 values and are not re-assessed). "BR-nn (tracker)" = TRACEABILITY §1 business requirement not in BRD-001 (see BRD reconciliation §4). Targets are the V4 Part 3 targets; they are planning intent, not requirements.

## 1. Capability traceability (46 rows)

| # | Capability | Business req. (BRD-001 / tracker) | Product module (PRD/RT) | FR/NFR | PO decision | ARCH component | Existing sprint(s) | Implementation / code area | Acceptance criterion / test id | Evidence (E-01/V6) | D-level now (V6) | D target (V4) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Tenancy Tier A (RLS) | BR-01, BR-06 | M01 | FR-005/006; NFR-038 | — | §8 multi-tenant | S02 | app/core/db.py (RLS helpers), models/tenant.py | TST-M01-2; NFR-038 dual-layer test | E-01 D-1; EV-04 | D2 (RLS) · D3 (app) | D7 |
| 2 | Tenancy Tier B/C | BR-06 | M01 | FR-007/008 | — | §8 | S02 | services/isolation_service.py | TST-M01-2 | E-01 D-2 | D3 / D2 | D7/D6 |
| 3 | Auth core | BR-08 | M02 | FR-011..013; NFR-014/017 | D-01 RS256; D-08 30 min | §16 | S03 | services/auth_service.py, core/config.py:37 | TST-M02-1 | E-01 D-3; drift G29/G30 | D3 | D7 |
| 4 | SSO OIDC/SAML, SCIM | BR-08 | M02 | FR-015..017 | — | §16 | S03 | services/sso_service.py, scim_service.py | TST-M02-2/3 | CD-03; EV-04 | D2 / D2 / D3 | D5 |
| 5 | RBAC | BR-08 | M03 | FR-019..021; NFR-018 | — | §16 | S04 | core/rbac.py, services/role_service.py | TST-M03-1/2 | E-01 D-5 | D3 | D7 |
| 6 | Audit chain / access trail / auth events | BR-05 | M04 | FR-022..025; NFR-034/036/037 | — | §10 hash chain | S05 | repositories audit_repo.py, middleware | TST-M04-1..3 | CD-07 | D3 | D7 |
| 7 | SIEM export | BR-05 | M04 | FR-027 | — | §13 | S05 | services/siem_service.py | TST-M04-3 | CD-08 (no caller); EV-04 | D3 | D5 |
| 8 | BYO key store + router + metering | BR-07 | M05 | FR-028/030/031 | D-13 | §11.2 gateway | S06, S49 | services/provider_service.py, core/crypto.py:37 | TST-M05-1/2; TST-M31-1 | CD-04; G04 | D2 (router) · D3 (store) | D7 |
| 9 | Test-connection | BR-07 (AC-07.2) | M05 | FR-029 | — | §13 | S06 | provider_service `_probe` | TST-M05-1 | G24 | D2 | D5 |
| 10 | HiL engine | BR-04 | M06 | FR-032..036 | — | ADR-008 | S07 | services/hil_service.py, models/hil.py | TST-M06-1/2 | CD-08 (SLA escalation no caller) | D3 | D7 |
| 11 | Governed AI envelope | BR-04 | M07 | FR-037 | — | §11.2 | S08 | services/ai_service.py | TST-M07-1 | E-01 D-11 | D3 | D7 |
| 12 | Governed AI provider calls | BR-04 | M07 | FR-037/040 | — | §11.2 | S08 | ai_service `_invoke_model` (stub) | TST-M07-2 | G03 | D2 | D5 |
| 13 | Guardrails PII/injection | BR-04 | M07 | FR-038/039 | — | §11.2 | S08 | ai_service guardrails | TST-M07-1 | G37 | D3 | D5 |
| 14 | 3-model consensus (orchestrator) | BR-02 | M11/M07 | FR-040/053 | D-04 (FR-040 stands); D-05 vocabulary | §11.1 | S12, S48, S57 | services/orchestrator_service.py:374-512 | TST-M11-1; TST-M30-1 | CD-16; EV-01; G05/G06 | D3 | D5 |
| 15 | Transcription | BR-02 | M11 | FR-052 | D-13 | §10 | S12, S47 | orchestrator `_transcribe`:319; services/transcription/base.py | TST-M29-1 | CD-09; EV-01; G11/G12 | D3 (inline) / D2 (abstraction) | D5 |
| 16 | Hash + canonical certificate + offline verify | BR-02 (AC-02.5/02.6) | M11 | FR-054(1-2)/FR-055 | D-12; D-06 open | §10; ADR-007 | S12 | services/certified_voice_service.py:124-258 | TST-M11-2 | Part 41; G38/G39; E-02 | D2 | D6 |
| 17 | RFC3161 TSA | BR-02 | M11 | FR-054(3)/NFR-024 | D-06 open; D-16 | ADR-007; AD-2/3 | S12 (claimed), S51-T04 | absent | NFR-024 openssl ts | G07 (absent) | D1 | D5 |
| 18 | Blockchain anchor | BR-02 | M11 | FR-054(4)/NFR-023 | D-03; D-06 open | ADR-007; AD-2 | S12, S51 | services/iota_service.py:55-200 | NFR-023 integration test | CD-06; CD-12; CD-13 | D2 | D5 |
| 19 | Certified PDF | BR-02 | M11 | FR-054(5); NFR-056 | D-06 open | §10 | S12 | services/pdf_service.py:97-320 (campaign-level) | TST-M11-2 | CD-13 | D3 | D6 |
| 20 | S3 Object Lock immutability | BR-02 | M11 | FR-054(6)/NFR-045 | — | §4 storage | S12 (claimed 'at deployment') | absent | NFR-045 delete-denied test | Part 41 (absent) | D1 | D5 |
| 21 | Client portal | BR-02 (AC-02.6) | M11 | FR-055 | D-21 open | §3 | S12/S17 | routes verify endpoint (authenticated) | TST-M11-2 | G43 | D2 | D6 |
| 22 | Campaign carrier abstraction + selection | BR-16 (tracker) | M25 | FR-056 (RC-05); POLICY §2 | D-07 | §13; TELECOM_PROVIDER_POLICY | S43 | services/campaign_carrier/*, resolver.py:109-112 | TST-M25-1 | CD-01; G13; EV-02 | D2 | D4 |
| 23 | M12 PSTN out/in + numbers | BR-03, BR-07 | M12 | FR-056/057 | D-07 | §13 | S13, S31 | services/telephony_service.py (`_dial`,`_provision_number`) | TST-M12-1/2 | G14/G15; EV-02 | D2 | D6 |
| 24 | Recording dual-channel + storage | BR-02, BR-03 | M12/M11 | FR-058 | — | §4, §10 | S13, S33 | orchestrator `_download_recording`:286; services/storage/* | TST-M12-2; TST-M23-1 | G17; CD-10; EV-02 | D1 (dual) / D3 (storage) | D5 |
| 25 | Chat models/REST | BR-03 | M13 | FR-059 | — | §9 | S14 | services/chat_service.py | TST-M13-1 | E-01 D-25 | D3 | D6 |
| 26 | Chat realtime WebSocket + presence | BR-03 | M13/M15 | FR-060/066 | — | §9 | S14, S16 | absent (WebSocket) | TST-M13-2 | G19 | D2 | D6 |
| 27 | E2E DMs | BR-03 | M13 | FR-061 | — | §9 | S14 | chat_service (server-side) | TST-M13-2 | E-01 D-27 | D2 | D5 |
| 28 | Meetings scheduling/rooms | BR-03 | M14 | FR-062 | — | §9 ADR-005 | S15 | services/meeting_service.py (`_mint_sfu_token` fake) | TST-M14-1 | G20 | D3 | D6 |
| 29 | Meeting recording / transcription / summary | BR-03, BR-04 | M14 | FR-063/064 | — | §9 | S15 | meeting_service | TST-M14-2 | E-01 D-29 | D2 | D5 |
| 30 | Push + email | BR-03 | M15 | FR-065 | — | §13 | S16 | services/notification_service.py (`_dispatch`) | TST-M15-1 | G21 | D2 | D5 |
| 31 | Flutter app (web/desktop) | BR-09 | M16/M17 | FR-067..071 | D-02 | ADR-003 | S17, S29, S30, S32, S36 | talkproof-app lib/src/* | TST-M16-1/2; Q07 gate | EV-05 (tests not run here) | D3 | D6 |
| 32 | Flutter mobile native | BR-09 (AC-09.4) | M18 | FR-072/073 | D-02 | ADR-003 | S19 | talkproof-app lib/src/mobile/*; android/ only | TST-M18-1 | CD-14; EV-05 | D2 | D6 |
| 33 | Admin portal | BR-09 | PRD E-15 / RT-18 | FR-003; PRD | D-02 (M17 ≠ admin) | ADR-004 | S18, S28, S35 | talkproof-admin src/* | TST-M17-1; Vitest 239 | EV-05 | D3 | D6 |
| 34 | Observability endpoints | BR-08 | M19 | FR-074 | — | §15 | S20 | routes/ops.py | TST-M19-1 | E-01 D-34 | D3 | D5 |
| 35 | Resilience wrapping | BR-08 | M19 | FR-075/NFR-046 | — | §15 | S20 | core/resilience.py (unused) | NFR-046 chaos test | G28; CD-08 | D2 | D5 |
| 36 | DR | BR-08 | M19 | FR-076; NFR-042/043/044 | D-10 | §14/§15 | S20 | docs/40_operations/DR_RUNBOOK.md; backup.sh absent | FR-076 restore test record | EV-07; R-36 | D2 | D5 |
| 37 | GDPR export/erase | BR-08 | M20 | FR-077 | — | §16 | S21 | services/compliance_service.py | TST-M20-1 | E-01 D-37 | D3 | D5 |
| 38 | TCPA consent | BR-02 (AC-02.7), BR-08 | M20 | FR-078; NFR-030 | — | §16 | S21 | compliance_service ConsentRecord; `require_consent` no caller | TST-M20-2; NFR-030 tests | CD-08; G36; G38 | D2 | D5 |
| 39 | KMS envelope | BR-08 | M20 | FR-079; NFR-020/022 | — | §16 | S21/S06 | core/crypto.py (Fernet) | NFR-020 review | G23 | D2 | D5 |
| 40 | Security headers / rate limit | BR-08 | M20 | FR-080 | — | §16 | S21 | middleware security (headers wired; limiter unused) | TST-M20-1 | CD-08 | D3 / D2 | D5 |
| 41 | White-label / packaging | BR-10 | M21 | FR-081/082 | — | §3 | S22 | services whitelabel; admin BrandingPage | TST-M21-1 | UNABLE beyond D3 (custom domain) | D3 | D6 |
| 42 | AI ledger | BR-04, BR-05, BR-07 | M22 | M22 scope; NFR-065 | D-18 open | §11.2 | S23 | models/ai_ledger.py, services/ai_ledger_service.py | TST-M22-1..3 | CD-11 (orchestrator bypass) | D3 | D5 |
| 43 | Storage abstraction | BR-15 (tracker) | M23 | FR-058; BR-15 | — | §4 | S33 | services/storage/drivers/* (Drive, S3) | TST-M23-1 | CD-10; EV-04 | D3 | D5 |
| 44 | WhatsApp channel | BR-14 (tracker); BRD OOS-02 conflict | M24 | BR-14 | PD-A | §13 | S34, S35, S36 | services/whatsapp_service.py:143-150 (`_send` fake); routes/webhooks.py:53-63 | TST-M24-1 (6 integration tests) | EV-03 (handshake absent; bare digest) | D2 send / D3 governance / D3 inbound / D2 adapter | D5 |
| 45 | Config resolver | BR-18 (tracker) | M28 | RC-11 (proposed FR) | D-13 | §8 config | S46 (DONE) → integration S47+ | services/config_resolver.py; `_plan_S46_M28_config_resolver.md` contract | TST-M28-1 (24 tests, PostgreSQL 16.15) | Config Resolver test-run record | D4 (component) | D5 (integrated) |
| 46 | Inbound calling + polymorphic pipeline | BR-03, BR-05 | I01/I02 | FR-056/057 (inbound); FR-024 audit parity | — | §10, §13 | S31, S59 | services/pipeline_service.py; orchestrator `_PipelineSource`:117-170 | TST-I01-1; TST-I02-1 | EV-02 (carrier stub) | D3 | D5 |

## 2. Decision → requirement → sprint traceability

| Decision | Requirement(s) touched | Sprint(s) that must conform | Code area |
|---|---|---|---|
| D-01 | FR-012, NFR-014 | S03 | core/config.py:37, auth_service |
| D-03 | FR-054(4), NFR-023 (RC-02) | S51 (M33), S12 | iota_service → anchor adapter |
| D-04 | FR-040/053 | S48 (M30-T05 must conform), S57 | orchestrator `_ai_verify`, `_majority_vote` |
| D-05 | FR-040 vocabulary | S44 (M26 already renamed labels) / S48 | orchestrator prompt; certificate payload |
| D-07 | FR-056 (RC-05) | S43, S13 | campaign_carrier, telephony_service |
| D-08 | FR-011, FR-045 | S03, S10 | auth_service LOCKOUT_MINUTES; impersonate_service |
| D-09 B | PRD §6 (RC-07) | none (no code) | — |
| D-10 | NFR-042/043 | S20 | DR runbook; restore test |
| D-11 | NFR-057 | S24 policy; CD-17 | pytest.ini fail_under |
| D-12 | FR-054(1) (RC-10, CR-04) | S12 | certified_voice_service payload |
| D-13 | RC-11 (new) ; BR-18 | S45 EPIC: S46 ✔, S47–S51 | config_resolver + pipeline stages |
| D-15 | authority order; PD-A | docs | BRD.md |
| D-17 | policy | none | — |
| D-19 / D-20 / D-23 / D-24 / D-25 | constraints | none | — |
| D-26 | closed | — | — |
| D-06 (open) | FR-054(3)-(6) | S12 (CD-13), S51 | certified_voice_service, iota_service, pdf_service |
| D-18 (open) | M22 scope (CR-15) | S23 | models/ai_ledger.py |
| D-21 (open) | FR-055 (CR-12) | S12/S17 | verify endpoint; Flutter portal |

## 3. BRD acceptance-criterion coverage (BR-02 only — the product's proof claim)

| AC | FR/NFR owner | V6 row(s) | D now | Covered by a test today? |
|---|---|---|---|---|
| AC-02.1 create campaign, assign, launch | FR-050/051 | 14 (campaign flow) | D3 | partially (M11 tests) |
| AC-02.2 agent dials in-app, auto-record | FR-051/057/058 | 23, 24 | D2/D1 | no (carrier fake) |
| AC-02.3 transcription + consensus ≤ 3 min | none (CG-1 proposed) | 14, 15 | D3 | no |
| AC-02.4 consensus presented to reviewer | FR-053, FR-032 | 10, 14 | D3 | yes (state machine) |
| AC-02.5 approve → PDF with hash, RFC3161, anchor | FR-054 | 16–19 | D1–D3 | hash only |
| AC-02.6 offline verifiable without platform | FR-055, NFR-024 | 16, 21 | D1/D2 | no artefact leaves server |
| AC-02.7 verbatim disclosure recorded immutably | NFR-030(d) (CG-2 proposed) | 38 | D2 | no |

## 4. Integrity notes
- 46 rows = V6 Part 38 rows; no row added or removed.
- BR-12/BR-13 are reserved in TRACEABILITY and map to nothing.
- Sprint IDs are the existing tracker IDs; none invented.
- Tests named are the tracker's TST-ids or the NFRD measurement; "no" means no test exercises the requirement at the required level today.
