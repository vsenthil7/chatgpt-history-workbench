# TalkProof — CR REQUIREMENTS ANALYSIS — V001

| Field | Value |
|---|---|
| **Created** | 2026-10-04 22:18 (Europe/London) |
| **Version** | V001 |
| **Status** | REQUIREMENTS ANALYSIS — candidate-grade expansions for governance review; NO FR/NFR ID issued; nothing approved |
| **Source artifacts** | V6 Part 32 (CR-01..CR-23 compressed), Parts 38–41, 43; FRD/NFRD (cited per CR); TRACEABILITY §1–2; SPRINT_TRACKER S45–S59; TALKPROOF_EVIDENCE_RESEARCH_PACK_V001 (R-C, R-D, R-E, E-02); TALKPROOF_CERTIFICATE_LIFECYCLE_ARCHITECTURE_V001 |
| **Scope** | The 11 D-22 SELECTED candidates expanded to the 19-field structure (P S CP CV R AC EV D SI CI OI £ FM FB A DvA EM TC PO); the 4 CONDITIONAL candidates assessed for whether their condition is now met |
| **Explicit exclusions** | The 8 DEFER candidates (CR-10, 16, 17, 18, 19, 20, 21, 22) are NOT expanded and NOT promoted; no sprint numbers; no code |
| **Decisions consumed** | D-22 (selection, corrected count 11/4/8), D-12, D-13, D-14, D-17, D-19, D-20, D-23, D-24 |
| **Unresolved items** | Approval of each CR as a requirement (governance process, after independent review); D-16 yes/no (CR-07/08); D-18 (CR-15); D-21 (CR-12/11) |
| **Change / provenance** | Created in the 2026-10-04 pre-build pass authorised by the Product Owner decision record of 22:02; author: Claude (builder); no source artefact modified; no code changed; no V7 created. |

Field key: **P** problem · **S** source/reason · **CP** competitor pressure · **CV** customer value · **R** requirement statement (candidate wording) · **AC** acceptance criteria · **EV** evidence required to claim D4+ · **D** dependencies · **SI/CI/OI/£** security / compliance / operational / cost impact · **FM** failure mode · **FB** fallback · **A** autonomy level (per D-17 table) · **DvA** deterministic vs AI · **EM** execution mode (inline / EVENT / NRT / BATCH) · **TC** tenant-configurable · **PO** PO approval required (always yes).

Each block ends with **Provenance** (which approved decision / recovered requirement / code fact grounds it) and **Grade** (requirement-grade = all 19 fields independently stated; candidate-grade = a field still depends on open work).

---

## CR-01 — Completion-level governance made executable
- **P** Tracker "DONE" ≠ product completion: 20/46 rows lowered under the authoritative D-scale (V6 Part 38); S12 recorded TSA/anchor as ☑ while code is D1/D2 (SPRINT_TRACKER S12 completion note "at deployment").
- **S** G01 (code-corroborated); brief Req 1; V6 Part 13.1; BR-11 (tracker: "build claims independently verified before reliance").
- **CP** Competitors ship D3 and call it done; buyers increasingly ask for evidence (Part 13.5 item 9).
- **CV** WET and tenants can see, per capability, what is specified / designed / implemented / contract-verified / live / E2E / production-ready.
- **R** Every capability row in the product state record carries a D-target, a D-actual and machine-readable evidence references; a D-level may be raised only when evidence of the kind defined for that level (authoritative D1–D7 definitions, V6 header) is attached; a capability whose D5+ evidence fails or expires drops automatically to the highest level whose evidence still holds; the sprint tracker's DONE flag is distinct from D-actual and may not be used as D-evidence.
- **AC** (1) the 46 V6 rows load as the initial state with the V6 D-levels; (2) attaching a passing contract-test run raises D3→D4 and nothing else does; (3) revoking the only D5 evidence drops the row to D4 within one BATCH cycle; (4) a report lists every row where tracker status = DONE and D-actual < D-target.
- **EV** product-state rows + CI artefacts linked by hash; one audited D-level change record per change.
- **D** CR-14 (PSM) for storage; D-24 constraint (Postgres).
- **SI** none · **CI** supports SOC2 change-evidence and ISO 42001 lifecycle · **OI** changes the definition of done for every sprint; tracker gains a D-actual column · **£** low.
- **FM** stale evidence references → row shows a level it no longer deserves. **FB** evidence references validated nightly; manual override logged with reason.
- **A** A0 · **DvA** deterministic · **EM** EVENT on CI + BATCH nightly · **TC** no · **PO** yes.
- **Provenance** D-14/D-22 selection; code fact G01; BR-11 (tracker). **Grade: requirement-grade.**

## CR-02 — FR/NFR → executable conformance checks
- **P** No FR/NFR is traced to an executable check (G02); the 82 FRs and 67 NFRs are verified by document review only; coverage gate measures lines, not requirements (CD-17, D-11).
- **S** R-42; Part 13.5 item 3; NFRD §1 "Measurement" column already names a check per NFR.
- **CP** Spec-driven conformance tooling is commodity; conformance *history* is not.
- **CV** "Requirement X holds at commit Y" is demonstrable to auditors and clients.
- **R** Each approved FR/NFR has at least one executable check (contract, property, integration, E2E or compliance test) tagged with the requirement ID and the requirement document version; CI fails when a tagged check regresses; a conformance report lists, per requirement, the checks, last result and run artefact; requirements with no check are listed as UNCOVERED, never hidden.
- **AC** (1) tagging convention exists and the existing 1,465 backend tests can be tagged incrementally; (2) report shows FR-054 as UNCOVERED today and COVERED only when a check exercises steps (3)–(6); (3) a deliberately broken check for FR-022 fails CI; (4) report versioned with FRD/NFRD version.
- **EV** CI artefact per run; report stored in PSM (CR-14).
- **D** CR-14; CR-01 (D-level evidence kind "contract-verified" = this).
- **SI** none · **CI** positive · **OI** check authoring becomes part of requirement approval · **£** medium (authoring).
- **FM** checks that test the wrong thing (self-referential). **FB** independent review of check↔requirement mapping (A4: AI-drafted, human-approved).
- **A** A4 · **DvA** deterministic execution · **EM** EVENT on CI · **TC** no · **PO** yes.
- **Provenance** G02 (recovered gap); NFR measurement column; D-11. **Grade: requirement-grade.**

## CR-03 — Provider adapter standard + conformance harness
- **P** Every provider boundary is a seam or mock: `_dial`, `_place`, `_stripe`, `_send`, `_dispatch`, `_submit_to_iota`, `_probe`, storage `_client` (V6 Part 44 "provider boundaries mocked — all"); Exotel adapter broken (CD-01); S3/Drive adapters have no writer (CD-10); no adapter has a contract with provenance except the Config Resolver (row 45).
- **S** brief Req 3; G45 (NEWREQ); D-13 (provider configuration through the product); BR-16/BR-18 (tracker); Senthil's standing rule: adapters must be real adapters written from the provider's API documentation, with only live details as parameters.
- **CP** Adapters are commodity; a recorded conformance history per provider version is not.
- **CV** Switching provider is a configuration change that is proven, not asserted.
- **R** Every provider adapter (carrier, STT, reviewer model, TSA, anchor, storage, messaging, payments, SSO) implements the common contract for its kind and passes a conformance suite that (a) is derived from the provider's published API reference with the reference version recorded, (b) exercises the production adapter against the provider's sandbox or a recorded fixture whose provenance is stated, (c) asserts request shape, response mapping, error-code mapping, circuit-breaker wrapping (NFR-046) and version detection; the suite result and provider API version are recorded per deployment; an adapter without a passing conformance run cannot be marked above D3; keys enter only via the M05 vault (FR-028/030).
- **AC** (1) Exotel adapter conformance run fails today on CD-01 and passes after the fix; (2) a fake adapter returning deterministic ids fails the suite; (3) S3 adapter conformance asserts `_client()` construction and bucket; (4) removing a provider's sandbox credentials yields "NOT RUN", never "PASS".
- **EV** conformance run artefacts with provider reference version; recorded in PSM.
- **D** CR-14; S45/M27 children (S47–S51) are the adapters; CD-04 (vault read path) must exist.
- **SI** sandbox credentials via vault only · **CI** n/a · **OI** harness maintenance per provider · **£** medium.
- **FM** sandbox ≠ production behaviour. **FB** staging live run (G50) as D5 evidence.
- **A** A4 (harness may be AI-drafted; approval human) · **DvA** deterministic · **EM** EVENT on deploy + BATCH weekly · **TC** no (tenant selects providers; standard is platform) · **PO** yes.
- **Provenance** G45, D-13, CD-01/04/10, Part 44. **Grade: requirement-grade.**

## CR-04 — Verdict provenance bound into the certificate *(expansion gated on R-D — R-D is now complete, gate cleared)*
- **P** Certificate payload has seven fields (`certified_voice_service.py:146-154`): no model versions, prompt version, provider, policy/regulation versions, reviewer identity-role, transcript hash, recording hash (Part 41, G38/G39/G40).
- **S** R-02; D-12 (bindings accepted in scope); Part 21 derived requirement; R-D claim class C3/C5.
- **CP** "AI-verified" claims without provenance are unauditable.
- **CV** A disputed certificate can be audited to the exact models, versions, prompts, policies and reviewer role used.
- **R** The evidence root (lifecycle step 2) includes hashes of: recording; transcript; STT engine + version; for each reviewer model its identifier, version, provider, prompt version and structured output; routing-policy version; regulation/policy catalogue versions in force (CR-05); consent record id + text version; disclosure text as delivered. The certificate leaf (step 4a) includes the approval record (role, decision, reason, time) and references the evidence root. Where a provider does not expose a version the value "unversioned" is recorded explicitly. Changing any bound item invalidates the hash. The verifier displays every bound field. No secret or raw PII beyond what FR-054 already places in the certificate enters the hashed material.
- **AC** (1) altering one character of the transcript invalidates the root; (2) the PDF and verifier show model ids/versions/prompt version/reviewer role; (3) a model returning no version string is recorded as "unversioned" and the certificate still issues; (4) R-D "proves / does not prove" lists appear verbatim in verifier output.
- **EV** evidence record + verifier output; contract test over the hashing function.
- **D** CR-07 (record format), CR-05 (catalogue), CR-06 (timestamp provenance), CR-15 (decision ids), D-06 outcome, S48/M30 (model adapters expose versions).
- **SI** no secrets in payload · **CI** supports EU AI Act Art 50 deployer transparency and TCPA evidence · **OI** payload schema versioned · **£** low.
- **FM** provider hides version. **FB** explicit "unversioned" + HiL note.
- **A** A0 · **DvA** deterministic · **EM** inline · **TC** no · **PO** yes.
- **Provenance** D-12 (approved scope), R-D (done), code facts. **Grade: requirement-grade** (depends on D-06 only for *where* the approval record sits, which both viable options place in the hashed material).

## CR-05 — Regulation and policy version provenance
- **P** Only consent text version is recorded (NFR-030(a)); nothing records which TCPA/PECR/AI-Act rule version applied to a decision (Part 2b).
- **S** D-14 area "legal/regulatory version at decision time"; Part 13.4; R-C: Art 50(1)/(3)/(4)/(5) apply 2 Aug 2026, Art 50(2) transitional to 2 Dec 2026 — a dated catalogue is exactly what is needed.
- **CP** Regulatory-history compounding (Part 15).
- **CV** "Which rules applied on date X in jurisdiction Y" is answerable from the record.
- **R** A versioned regulation/policy catalogue (jurisdiction, instrument, provision, version, valid-from, valid-to, source URL, curator) exists; every consent check, DNC check, disclosure delivery and verdict decision records the catalogue version ids in force; catalogue changes are human-curated and audited (FR-022); the first entries are TCPA/FCC (US), PECR (UK), EU AI Act Art 50 with its two applicability dates.
- **AC** (1) query returns the rule set in force for a date/jurisdiction; (2) a decision made on 1 Aug 2026 records a different Art 50 entry than one on 3 Aug 2026; (3) catalogue edit without curator role is refused and audited.
- **EV** catalogue rows + ledger rows; contract test.
- **D** CR-15 (decision rows), CR-04 (binding), CR-19 (alerts — deferred; manual curation until then).
- **SI** none · **CI** core · **OI** human curation calendar · **£** low tech / ongoing human.
- **FM** stale catalogue. **FB** curator review on a fixed cadence until CR-19 exists.
- **A** A2 for proposals; human for changes · **DvA** deterministic · **EM** EVENT · **TC** jurisdiction selection yes; catalogue no · **PO** yes.
- **Provenance** D-14, R-C. **Grade: requirement-grade.**

## CR-06 — Trusted-time claims separated by provenance
- **P** Timestamps in evidence come from platform clock (`issued_at = datetime.now()`), provider webhooks and device clocks with no provenance class; TSA absent (row 17 D1).
- **S** NFR-024, NFR-056; D-14 area "clock/time trust beyond TSA"; lifecycle §1.
- **CP** —. **CV** A court or auditor sees which times are proven (TSA/anchor) and which are informative.
- **R** Every timestamp in an evidence record or certificate carries a provenance class ∈ {tsa, anchor, platform, provider, device}; only `tsa` and `anchor` are trust anchors; the PDF renders proven times with the TSA/anchor reference and informative times labelled as such, in the campaign timezone with explicit zone (NFR-056).
- **AC** (1) verifier output lists each timestamp with its class; (2) a certificate with no `tsa`-class timestamp cannot be marked issued; (3) PDF shows "T1 (TSA DigiCert-class, token id …)" vs "call ended (carrier clock)".
- **EV** evidence schema + contract test. **D** CR-07, S51/M33 TSA adapter.
- **SI/CI** positive · **OI** minimal · **£** low. **FM** none material · **FB** n/a.
- **A** A0 · **DvA** deterministic · **EM** inline · **TC** no · **PO** yes.
- **Provenance** NFR-024/056, D-14. **Grade: requirement-grade.**

## CR-09 — Provider-exit verifiability
- **P** Verification today is an authenticated endpoint recomputing from TalkProof's own DB (`verify_certificate`); nothing a third party can verify leaves the server; any provider (STT, model, TSA, anchor) disappearing would make historic claims unverifiable.
- **S** R-41 (runtime switching only); D-14 area "provider exit"; R-E (provider disappearance); CR-03 principle.
- **CP** —. **CV** Evidence outlives every vendor.
- **R** Verifying any certificate requires no live call to any provider: all provider-derived artefacts (transcripts, model outputs, TSA tokens, anchor receipts) are stored with provider + version provenance; the public verification material needed (TSA certificate chain, anchor proof) is cached in the evidence record at issue and at each renewal; the verifier runs with network disabled and reports an anchor as "unverifiable offline" rather than failing the certificate when the chain is unreachable (TSA still verifies).
- **AC** (1) offline verification of an issued certificate passes with network disabled; (2) deleting the anchor adapter does not change the verifier result for TSA claims; (3) exported bundle contains everything the verifier needs.
- **EV** offline verification test record. **D** CR-07, CR-12 (verifier), CR-11.
- **SI/CI** positive · **OI** cache public material · **£** low. **FM** anchor chain unavailable. **FB** multi-anchor policy (D-03).
- **A** A0 · **DvA** deterministic · **EM** inline + BATCH re-verification · **TC** no · **PO** yes.
- **Provenance** R-36/R-06 (offline verification already required), D-14, R-E. **Grade: requirement-grade.**

## CR-13 — Build and AI supply-chain provenance (SBOM / AIBOM / SLSA)
- **P** No SBOM, no AIBOM, no build provenance; `iota_client` undeclared yet imported (CD-06) is the kind of drift a BOM catches; NFR-026/027/028 scanning requirements exist without an attestation artefact.
- **S** D-14 area "AI supply-chain provenance"; NFR-025..028; Part 13.2; EU CRA SBOM mandate (Dec 2027, secondary source — not revalidated).
- **CP** commodity tooling. **CV** Buyers and auditors receive signed attestations of what runs and which models/prompts verified their calls.
- **R** Every deployment produces a signed SBOM (CycloneDX class) and an AIBOM listing models, versions, prompts, agents and tools used by the product, plus build provenance (SLSA class); the product-state record links each deployment to its attestations; CVE matching runs against the SBOM in CI; an unsigned or missing attestation blocks deploy; the verifier version (CR-12) is itself attested.
- **AC** (1) a deployment with a dependency not in the SBOM is blocked; (2) AIBOM lists the three reviewer models and the Whisper engine with versions; (3) CVE match on a pinned package fails CI.
- **EV** attestation files + CI records. **D** CR-14 (links); CI pipeline.
- **SI** core · **CI** NFR-026/027/028 evidence; ISO 42001 · **OI** CI changes · **£** low.
- **FM** unsigned artefact. **FB** block (no fallback).
- **A** A4 · **DvA** deterministic · **EM** EVENT on build · **TC** no · **PO** yes.
- **Provenance** NFR-025..028, D-14. **Grade: requirement-grade.**

## CR-14 — Product State Model (bi-temporal, Postgres-first per D-24)
- **P** Intent (BRD/PRD/FRD/NFRD), decisions (D-register), implementation (tracker), verification (E-01/V6), runtime and evidence live in six unlinked documents; contradictions are resolved by hand (this pass is the proof).
- **S** brief §6; Part 16; D-24 (Postgres-first; graph only after E-03).
- **CP** —. **CV** One queryable record answers "what did we promise, what exists, what is proven, what runs" — the input to CR-01, CR-02, CR-03, CR-13.
- **R** A versioned, bi-temporal relational model (valid-time + transaction-time) in the existing PostgreSQL (Alembic-managed) links: requirements (BR/FR/NFR with document version), PO decisions, capabilities (the 46 rows), components, provider bindings, sprints/tickets, tests and conformance runs, deployments and attestations, D-levels and evidence, defects (CD), decisions-at-runtime (ledger ids), corrections and knowledge versions; contradictions are stored with validity intervals, never auto-resolved; relationship traversal uses recursive SQL; a graph store is introduced only if E-03 shows traversal cost requires it.
- **AC** (1) the V6 46-row table, the FR/NFR registers, CD-01..17, D-01..26 and the tracker index load as the initial dataset; (2) "which sprint implements FR-054 and what is its D-actual" is one query; (3) a requirement text change creates a new version without deleting the old; (4) E-03 benchmark harness exists before any graph proposal.
- **EV** schema + migration up/down/up + loaded dataset + queries. **D** none (Postgres); D-24.
- **SI** access control on PSM (admin:read) · **CI** n/a · **OI** ingestion from tracker/CI · **£** medium.
- **FM** PSM diverges from reality. **FB** observed runtime is authoritative for runtime; PSM for intent; gap rows (CR-17, deferred) later.
- **A** A0 · **DvA** deterministic · **EM** NRT ingestion · **TC** no · **PO** yes.
- **Provenance** D-24 (approved constraint), brief §6. **Grade: requirement-grade.**

## CR-15 — Intelligence Decision Ledger with persisted rows and UNKNOWN-default outcomes
- **P** `AIInteractionLedger` (M22, S23) persists only M07 governed-AI calls; the orchestrator's real Anthropic/OpenAI/Gemini calls bypass it (CD-11); model is name-only (String 64), no version, no prompt version, no outcome field, no decision id (`models/ai_ledger.py`; V6 Part 43 check 2).
- **S** M22 scope (every AI provider call ledgered); brief §13/§15; Part 21; R-C (OTel GenAI is Development with no tagged release).
- **CP** —. **CV** Every automated decision is reconstructable: route, inputs hash, model/version/prompt, cost, outcome and who verified the outcome.
- **R** (wording shaped by R-C) Every automated intelligence decision — including every reviewer-model call in the certification pipeline — has a persisted (never sampled) ledger row in the existing hash-chain-linked ledger, extended with: `decision_id`, `capability`, `workflow`, `model_version`, `prompt_version`, `provider_version`, `routing_policy_version`, `regulation_versions_in_force`, `outcome` defaulting to UNKNOWN until a verified signal arrives, `outcome_verified_by`, `outcome_proposed_by_ai` (never copied into `outcome`), `correction_id`; the row set is exportable in an OpenTelemetry GenAI-compatible mapping whose convention version is recorded per export (the mapping is an export format, not the storage schema, because the convention has no stable release).
- **AC** (1) every orchestrator model call writes a row (CD-11 closed); (2) `outcome` is UNKNOWN on insert and cannot be set by any AI-originated path; (3) model version present for all three reviewer adapters; (4) export validates against the pinned OTel GenAI convention version named in the export header.
- **EV** ledger rows + contract test + export validation. **D** CR-14 (links), S48/M30 (adapters expose versions), S23 conformance (CD-11).
- **SI** content capture per tenant policy; no secrets · **CI** Art 50 / ISO 42001 traceability · **OI** storage growth → retention policy · **£** low–medium.
- **FM** sampling drops rows. **FB** persistence mandatory; alert on write failure.
- **A** A0 · **DvA** deterministic · **EM** NRT · **TC** content-capture level yes · **PO** yes.
- **Provenance** M22 scope (recovered), CD-11, R-C. **Grade: requirement-grade.** → feeds D-18 (see `TALKPROOF_REMAINING_PO_DECISIONS_V001`).

## CR-23 — Certificate status, correction, supersession and revocation lifecycle *(expansion gated on R-D and R-E — R-D complete; R-E obligations complete, cost open; gate cleared for wording)*
- **P** `CallCertificate.status` admits `revoked` but no code path sets it; no superseding reference; no status discovery for a holder of the PDF; FR-036 says issuance is not rollbackable after delivery; FR-077 says certified records within retention cannot be erased — an immutable-but-wrong certificate has no correction path (Part 29.5).
- **S** independent review C09; FR-036, FR-055, FR-077; lifecycle step 7; R-E (status authority).
- **CP** an immutable wrong certificate is a liability, not a moat.
- **CV** Relying parties can discover that a certificate was superseded or revoked, and why class.
- **R** An issued certificate has exactly one current status ∈ {valid, superseded-by <certificate>, revoked, under-review}; every status change is a status record that is hash-bound to the certificate leaf, RFC 3161 timestamped and anchored (same strength as issuance), written by a role authorised for status changes, with a reason class (wrong verdict, wrong consent link, reviewer error, key compromise, provider mis-transcription, legal order) and reason text; supersession requires a new evidence root and a new certificate that references the superseded one; the original artefacts are never deleted or altered (FR-077, NFR-045); the verifier and the client portal (FR-055) display current status; an offline verifier reads the status list embedded at the last renewal or a signed status response cached in the export (CR-11); revocation of an anchored certificate is itself anchored.
- **AC** (1) revoking a certificate writes an anchored status record and the verifier shows REVOKED; (2) superseding links old→new and new→old; (3) a user without the status role is refused and audited; (4) an exported bundle verifies offline and shows the status as of export; (5) the original PDF still verifies as "integrity OK, status REVOKED".
- **EV** status records + verifier output + contract tests. **D** CR-07, CR-12, D-06 outcome, R-E (role authority).
- **SI** status role is A2 (D-17) · **CI** FR-077/NFR-045 reconciled · **OI** status-change runbook · **£** low (+ TSA/anchor per status change).
- **FM** status list stale offline. **FB** status discovery URL in PDF with "last known status" semantics.
- **A** A2 · **DvA** deterministic · **EM** inline · **TC** no · **PO** yes.
- **Provenance** Part 29.5, code fact (revoked never set), R-D, R-E. **Grade: requirement-grade for wording; cost field depends on E-05.**

---

## CONDITIONAL candidates — has the condition been met by this pass?

| CR | Condition (per D-22) | State after this pass | Conclusion |
|---|---|---|---|
| CR-07 Evidence records conform to RFC 4998 ERS / ETSI LTV | D-16 outcome | D-16 investigation executed: E-02 structural fit confirmed; R-C confirmed RFC 4998 renewal semantics and ETSI TS 119 312 V2.1.1. The yes/no is now a PO decision (recommendation "yes" in `TALKPROOF_REMAINING_PO_DECISIONS_V001`). | **Condition ready to be met** — expansion to 19 fields is drafted below as candidate-grade pending D-16 = yes. |
| CR-08 Cryptographic agility / PQ readiness | D-16 outcome; E-07 input | Same as CR-07; E-07 (which TSAs offer hybrid PQ tokens) not done. | **Condition partly met**; expansion deferred until D-16 = yes and E-07. |
| CR-11 Tenant exit with continued verification | D-21 | D-21 recommendation provided (yes) but not decided. | **Condition not yet met** — remains conditional. |
| CR-12 Standalone published verifier | R-D | R-D complete (Evidence pack §3). | **Condition met** — expanded below; feeds D-21. |

### CR-07 — Evidence records as RFC 4998 ERS (candidate-grade pending D-16 = yes)
- **P** chain stops at SHA-256 over 7 fields; no algorithm id; no renewal concept; G41 DESIGN has no standard. **S** Part 13.5 item 1; R-C (RFC 4998 confirmed); E-02. **CP** difficult to reproduce as an operated service. **CV** evidence verifiable decades out.
- **R** Each certificate's evidence (lifecycle §1) is stored as an RFC 4998 Evidence Record (ASN.1; RFC 6283 XML acceptable as an export form) with explicit `digestAlgorithms`, an archive-timestamp sequence (T0 chain, T1 chain, status chain), and renewal performed before any used algorithm is deprecated per ETSI TS 119 312 current version or before TSA certificate expiry; the existing `content_hash` is preserved as a leaf (E-02); a renewed record verifies both old and new chains.
- **AC** (1) `openssl ts -verify`-class check of each token in the chain passes; (2) E-02 prototype assertions reproduced with a real TSA token on staging; (3) a timestamp renewal adds a chain element without altering any prior bytes; (4) hash-tree renewal to a second algorithm verifies old and new.
- **EV** ERS artefacts + verifier run. **D** TSA adapter (S51/M33-T04), anchor adapter (S51), CR-04/05/06 leaves, CR-12. **SI** TSA key compromise handling · **CI** eIDAS/ETSI alignment · **OI** renewal calendar · **£** TSA tokens + renewal batches (E-05). **FM** missed renewal. **FB** scheduled-job alarms; CR-19 later. **A** A0 · **DvA** deterministic · **EM** inline (issue) + BATCH (renewal) · **TC** no · **PO** yes. **Provenance** D-16 investigation, E-02, R-C. **Grade: requirement-grade once D-16 = yes.**

### CR-12 — Standalone, published verifier (condition met: R-D done)
- **P** no artefact leaves the server that a third party can hash; FR-055 offline verification at D1; NFR-024 `openssl ts` verification unmet; R-06/R-36/BRD AC-02.6 all require offline verification. **S** R-06, R-36, AC-02.6, R-D. **CP** open-source ERS/TSA verifiers exist; the edge is operating, not authoring. **CV** anyone can verify without TalkProof.
- **R** An open, versioned verifier (library + CLI; the in-browser FR-055 check uses the same core) validates evidence records (CR-07), RFC 3161 tokens, anchor proofs (per adapter type), status records (CR-23) and bound provenance fields (CR-04) using only the record and public material; it prints the R-D "proves / does not prove" lists; the verifier version and release signature (CR-13) are recorded in every certificate; a previous verifier version remains able to verify certificates issued under it.
- **AC** (1) a third party verifies a certificate with the verifier and public material only; (2) tampering with any leaf is detected; (3) a revoked certificate shows REVOKED; (4) network disabled → TSA claims verify, anchor "unverifiable offline".
- **EV** published artefact + conformance tests + signed release. **D** CR-07, CR-09, CR-23, CR-13. **SI** supply chain (signed releases) · **CI** positive · **OI** release discipline · **£** medium. **FM** verifier bug invalidates valid certificates. **FB** versioning; prior version. **A** A4 · **DvA** deterministic · **EM** n/a · **TC** no · **PO** yes. **Provenance** R-06/R-36/AC-02.6 (recovered + BRD), R-D. **Grade: requirement-grade.** → feeds D-21.

---

## DEFER candidates — untouched, with their recorded triggers
CR-10 (after D-06/D-16 fix the mechanism and E-09) · CR-16 (after CR-15 analysed) · CR-17 (second wave, after CR-14) · CR-18 (D-17 policy suffices; nothing near A3) · CR-19 (after CR-14/CR-17) · CR-20 (D-23 internal; after CR-01/14) · CR-21 (second wave, after CR-15) · CR-22 (D-19 "none"; no learning). None expanded; none promoted.

## Count check
SELECT expanded: 11 (CR-01, 02, 03, 04, 05, 06, 09, 13, 14, 15, 23) · CONDITIONAL assessed: 4 (CR-07 drafted, CR-08 deferred to D-16/E-07, CR-11 still conditional, CR-12 expanded) · DEFER untouched: 8 · Total 23. FR/NFR IDs issued: 0.
