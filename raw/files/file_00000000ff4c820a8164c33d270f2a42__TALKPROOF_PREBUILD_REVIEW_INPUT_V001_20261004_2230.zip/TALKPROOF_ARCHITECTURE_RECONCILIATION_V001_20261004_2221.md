# TalkProof — ARCHITECTURE RECONCILIATION — V001

| Field | Value |
|---|---|
| **Created** | 2026-10-04 22:21 (Europe/London) |
| **Version** | V001 |
| **Status** | RECONCILIATION RECORD — distinguishes existing / required correction / proposed / deferred architecture; proposals need PO approval (AD-1..AD-5); no architecture changed by this file |
| **Source artifacts** | ARCH-001 v1.1 (§3–§17, ADR-001..010); TELECOM_PROVIDER_POLICY.md; HLD.md/LLD.md (listed, not reconciled line-by-line); backend code (app/services, app/models, app/core, routes); V6 Parts 16–29, 38–45; TALKPROOF_CERTIFICATE_LIFECYCLE_ARCHITECTURE_V001; PO decisions |
| **Scope** | Architecture against approved requirements, existing architecture document, actual code, provider-neutrality decisions, lifecycle analysis and D-scale evidence |
| **Explicit exclusions** | HLD/LLD/BDD/TEST_PLAN not reconciled in this pass (they are derivative of ARCH-001 and will move with it); no vendor selected; no code |
| **Decisions consumed** | D-03, D-04, D-07, D-10, D-12, D-13, D-17, D-19, D-20, D-24, D-25 |
| **Unresolved items** | AD-1..AD-5 (PO); D-06/D-16/D-18/D-21 consequences |
| **Change / provenance** | Created in the 2026-10-04 pre-build pass authorised by the Product Owner decision record of 22:02; author: Claude (builder); no source artefact modified; no code changed; no V7 created. |

Status key — **EXISTING** (in ARCH-001 and in code as described) · **DOC-ONLY** (in ARCH-001, not in code) · **CODE-ONLY** (in code, not in ARCH-001) · **CORRECTION REQUIRED** (ARCH-001 or code contradicts an approved requirement/decision) · **PROPOSED** (new, needs PO approval) · **DEFERRED** (recorded, not for build).

## 1. Component-by-component reconciliation

| Area | ARCH-001 says | Code (E-01/V6, re-checked where noted) | Approved requirement / decision | Status | Action owner |
|---|---|---|---|---|---|
| API service, FastAPI, Postgres, Alembic (ADR-001/002) | FastAPI monolith, Postgres | matches | FR-001; D-24 | EXISTING | — |
| Repos: Flutter app, React admin (ADR-003/004) | three repos | three repos supplied; Flutter has `android/` only, no `ios/`, no desktop targets (CD-14) | FR-002/003, FR-067..073, D-02 | CORRECTION REQUIRED (code vs FR); doc README stale (G51) | S17/S19 |
| Multi-tenant Tier A RLS (§8) | RLS policies via session variable | RLS helpers present, never called; no policies, no migration (row 1 D2) | FR-006 "both layers active", NFR-038 | CORRECTION REQUIRED | S02 conformance |
| Tier B/C | dedicated schema / manifest | empty schema / dict manifest (G49) | FR-007/008 | DOC-ONLY beyond D2/D3 | S02 |
| Auth JWT (§16) | — | HS256; 15-min lockout; 60-min impersonation | D-01 RS256; D-08 | CORRECTION REQUIRED | S03/S10 |
| Audit hash chain (§10 "Hash-Chain Algorithm") | row_hash over prev_hash etc.; `verify_chain()` | implemented; no lock on prev_hash (CD-07) | FR-022/023, NFR-034 | CORRECTION REQUIRED (race) | S05 |
| BYO keys / provider router (§11.2, M05) | AI gateway resolves BYO keys via router | vault write-only; `decrypt_secret` no callers; router results discarded; pipeline reads `os.environ` (CD-04, G04) | FR-028/030, D-13 | CORRECTION REQUIRED | S06/S49 |
| Certification pipeline (§10 flowchart) | webhook → download → Whisper → 3-model → aggregate → audit → **TSA → anchor → PDF → HiL** | webhook → Whisper (real, env key) → 3 models (real, env keys) → DB rows → HiL → `status=issued` + SHA-256 of 7 fields; no TSA, no per-call anchor, no per-call PDF (Part 41, CD-13) | FR-054 (approval first), BRD AC-02.5, D-12; D-06 OPEN | CORRECTION REQUIRED (ordering doc vs FRD) + DOC-ONLY (TSA/anchor/PDF per call) | AD-1 after D-06; S12/S51 |
| ADR-007 "RFC 3161 + IOTA dual timestamp" | IOTA named | IOTA via env stub; `iota_client` undeclared (CD-06); campaign-level only | D-03 provider-neutral; NFR-023/024 | CORRECTION REQUIRED (doc) | AD-2 |
| ADR-008 HiL gate on issuance | yes | implemented (`issue()` requires executed proposal) | FR-032 floor | EXISTING | — |
| AI layer §11.1 (GPT-4o, Claude 3.5 Sonnet, Gemini 1.5 Pro; AI gateway) | named models; gateway | literal model strings in orchestrator; M07 `_invoke_model` stub; roster hardcoded (S45 finding) | BR-18 (config-driven), D-13, FR-040 (≥2 providers ✔) | CORRECTION REQUIRED (doc should say roster = config) | AD-5; S48 |
| §11.2 Governed AI principles (advisory-by-default, guardrails) | yes | M07 guardrails implemented (regex, G37); advisory envelope ✔; M07 provider call stub | FR-037..039 | EXISTING (envelope) / DOC-ONLY (real provider via M07) | S08 |
| ADR-009 polling orchestrator → Celery | Phase 1 polling | 60-s poll; Celery/Redis declared, unused (CD-15) | — | EXISTING (Phase 1); CORRECTION (declared-unused deps) | AD-4 |
| RTC §9 (LiveKit SFU, WebSocket) | LiveKit, WebSocket gateway | `_mint_sfu_token` fake; zero WebSocket code (G19/G20) | FR-060/062 | DOC-ONLY | S14/S15 |
| Telephony §13 / TELECOM_PROVIDER_POLICY (M25) | carrier abstraction, config precedence campaign>tenant>platform | `CampaignCarrierProvider` + resolver exist; Exotel adapter broken (CD-01); Twilio `_place` fake; M12 `_dial` fake | FR-056 (RC-05 reworded), D-07, BR-16 | EXISTING (interface) / CORRECTION (CD-01) / DOC-ONLY (second real carrier) | S43 |
| Storage (§4 MinIO/S3) | S3/MinIO | `StorageDriver` + Drive/S3 adapters, no production writer (CD-10); recordings never stored (Part 41) | FR-058, NFR-045 Object Lock, BR-15 | DOC-ONLY beyond D3 | S33 |
| Config (§8 per-tenant config) | config tables | tables + admin API + `ConfigResolver` (D4 component) with no production importer (CD-08) | BR-18/RC-11 | EXISTING (component) / CORRECTION (integration) | S47–S51 |
| Observability/resilience (M19) | circuit breakers, metrics | primitives exist; nothing wrapped (G28); ops endpoints ✔ | NFR-046, FR-075 | CORRECTION REQUIRED | S20 |
| Compliance (M20) consent/DNC | TCPA consent enforcement | `ConsentRecord` + check endpoint; never enforced on call paths; no DNC (CD-08, G36) | FR-078, NFR-030 | CORRECTION REQUIRED | S21 |
| Deployment §14 (Vultr, docker-compose.prod) | ports 8097/8098/5435 | no deployment artefact (EV-04) | — | DOC-ONLY | ops |
| Celery/Redis in compose | — | declared unused | — | see AD-4 | — |

## 2. Required corrections to ARCH-001 (document) — for PO approval

| AD | Correction | Depends on |
|---|---|---|
| AD-1 | Replace §10 flowchart with the lifecycle (architecture artefact §1): ER → T0 → reviewer → approve → T1 + anchor → PDF → verify → status | D-06 |
| AD-2 | ADR-007 → "RFC 3161 archive timestamps (T0/T1) + provider-neutral anchor adapter (D-03)"; remove IOTA as identity | none (D-03 already decided) |
| AD-3 | Add components: `EvidenceRecordService` (ERS build/verify/renew), `CertificateStatusService` (CR-23), `TsaClient` adapter (RFC 3161, provider-neutral by protocol) distinct from `CertificationProvider` (anchor adapter, S51/M33) | D-16, CR-07, CR-23 |
| AD-4 | ADR-009: record Phase 1 polling as current; remove Celery/Redis from declared dependencies/compose until a Phase-2 trigger, or schedule the migration | none |
| AD-5 | §11: model roster, STT engine, voting rule, anchor/TSA, carrier and storage are configuration (BR-18/RC-11); the provider router/vault is the mandatory key path (D-13, CD-04); AI gateway = M05 router + M07 envelope, not a separate service | none |

Also record (no decision needed): §8 RLS, §9 RTC and §4 storage are currently DOC-ONLY and are tracked as sprint conformance items, not as architecture changes.

## 3. Proposed architecture (new, candidate) — summary with status

| Proposal | Source | Status |
|---|---|---|
| Evidence record (ERS) + two-timestamp lifecycle | lifecycle artefact; CR-07 | PROPOSED (D-06/D-16) |
| Certificate status lifecycle | CR-23 | PROPOSED |
| Standalone verifier (library + CLI + in-browser core) | CR-12 | PROPOSED (D-21) |
| Product State Model, Postgres-first | CR-14; D-24 | PROPOSED (constraint approved) |
| Adapter conformance harness | CR-03 | PROPOSED |
| Decision ledger = M22 extended + OTel export mapping | CR-15; D-18 (amend recommended) | PROPOSED (D-18) |
| Regulation/policy catalogue | CR-05 | PROPOSED |
| SBOM/AIBOM/SLSA in CI | CR-13 | PROPOSED |
| Autonomy ceilings (policy, A2 on evidence/crypto/auth/consent/verdict) | D-17 | APPROVED POLICY (not a component) |

## 4. Deferred / rejected (recorded, not for build)

Intelligence router / CRAG / learned routing / CLM training (D-20 gate; Parts 18–23) · graph database (D-24, after E-03) · A5+ autonomy on evidence/crypto/auth/consent/verdict (D-17) · cross-tenant learning (D-19) · customer-facing scorecard (D-23) · AI pentest procurement (D-25) · chunk-level commitments (CR-10, after D-06/E-09) · Celery Phase 2 (AD-4 trigger) · real-time translation (BRD OOS-06) · bespoke long-term evidence formats (rejected, Part 35.1).

## 5. Provider-neutrality check (D-03, D-07, D-13) against code

| Boundary | Neutral in requirement? | Neutral in code? | Gap |
|---|---|---|---|
| Campaign carrier | yes (BR-16, D-07) | interface + resolver yes; only Exotel (broken) + fake Twilio | second real adapter + CD-01 |
| M12 PSTN | yes (FR-056 after RC-05) | `_dial` fake for all | real adapters |
| STT | yes (FR-052 BYO) | interface only (S47 T01) | S47 T02–T05 |
| Reviewer models | yes (BR-18) | literal strings | S48 |
| Voting | yes (BR-18) | fixed 2-of-3 | S50 |
| Anchor | yes (D-03) | IOTA stub only | S51 |
| TSA | yes by protocol (RFC 3161) | absent | S51-T04 |
| Storage | yes (BR-15) | adapters, no writer | S33 |
| Keys | yes (FR-028/030) | `os.environ` | S49 |
| Messaging (WhatsApp) | yes (BR-14) | `_send` fake; inbound real (D3) | S34 |

## 6. D-scale view of the architecture

Only one component is contract-verified (Config Resolver, row 45, D4). Every proof-chain component the architecture document draws (TSA, anchor, per-call PDF, Object Lock, portal, offline verifier) is D1–D2. The architecture record must therefore carry D-actual per component (CR-01) so that ARCH-001 stops describing a system that does not exist as if it did.
