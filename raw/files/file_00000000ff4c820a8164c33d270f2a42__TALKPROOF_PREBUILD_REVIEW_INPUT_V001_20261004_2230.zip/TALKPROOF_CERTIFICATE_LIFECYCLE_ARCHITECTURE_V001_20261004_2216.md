# TalkProof — CERTIFICATE LIFECYCLE ARCHITECTURE — V001

| Field | Value |
|---|---|
| **Created** | 2026-10-04 22:16 (Europe/London) |
| **Version** | V001 |
| **Status** | ARCHITECTURE PROPOSAL — for independent review and PO decision on D-06; nothing here is approved or implemented |
| **Source artifacts** | FRD FR-032..036, FR-040, FR-052..055, FR-058, FR-077, FR-078; NFRD NFR-023, NFR-024, NFR-030, NFR-045, NFR-056; BRD BR-02 AC-02.5..02.7; ARCH-001 §10, ADR-007/008; V6 Parts 29, 41, 43; TALKPROOF_EVIDENCE_RESEARCH_PACK_V001 (E-02, R-C, R-D, R-E); backend code cited |
| **Scope** | Complete certificate/proof lifecycle: capture → evidence formation → reviewer presentation → approve/reject/modify → timestamp/anchor → issue → verify → supersede/revoke/correct; comparison of D-06 options (a)(b)(c); one recommendation |
| **Explicit exclusions** | No code; no FR/NFR ID; no sprint; does not decide D-06; provider choices (which TSA, which anchor) are configuration per D-03 and are not decided |
| **Decisions consumed** | D-03, D-04, D-05, D-09 B, D-12 (bindings accepted in scope), D-13, D-16 (investigation done), D-17 (A2 ceiling on evidence/crypto) |
| **Unresolved items** | D-06 (PO); D-16 yes/no (PO); CR-07/CR-23 approval; E-02 token-level verification on staging |
| **Change / provenance** | Created in the 2026-10-04 pre-build pass authorised by the Product Owner decision record of 22:02; author: Claude (builder); no source artefact modified; no code changed; no V7 created. |

## 0. Terms

- **Evidence root (ER)** — Merkle root over the hashed evidence objects of one call (RFC 4998 data-object group).
- **T0** — archive timestamp (RFC 3161 token) over the ER, taken **before** the reviewer sees the evidence.
- **T1** — archive timestamp over the certificate leaf = H(ER ‖ approval record ‖ certificate payload), taken **after** approval.
- **Anchor** — external, provider-neutral commitment (D-03) of a root hash; the adapter and its finality semantics are configuration.
- **Status record** — a timestamped, hash-bound statement {valid | superseded-by | revoked | under-review} about an issued certificate (CR-23).
- **Verifier** — any process that, with only the evidence record, the public TSA/anchor material and (optionally) the artefacts, can recompute every hash and check every token (R-06, R-36, CR-12).

Provider-neutral boundary: TSA = RFC 3161 protocol (any trusted TSA); anchor = `CertificationProvider` adapter (S51/M33 pattern, D-03); STT/models = adapters (S47/S48); storage = `StorageDriver` (S33). Nothing below names a vendor.

## 1. Lifecycle — every transition

| # | Transition | Canonical content (what is serialised) | Hashes | Timestamps | Anchors | Human approval record | Immutable after this step | Mutable after this step | Rejection behaviour | Modification behaviour | Supersession / revocation | Verifier-visible proof | Provider-neutral boundary |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | **Capture** (call ends; FR-051/058) | recording bytes (dual-channel, FR-058); carrier call metadata; consent record id + consent text version (FR-078, NFR-030(a)(d)(e)); disclosure script text as delivered (AC-02.7) | H_rec = SHA-256(recording bytes); H_consent; H_disclosure | none yet (provider/device clocks recorded as *informative*, CR-06) | none | none | nothing yet (stored to Object-Lock bucket, NFR-045, but not committed) | all | n/a | n/a | n/a | none yet | carrier adapter (M25) · storage adapter (M23) |
| 2 | **Evidence formation** (transcribe + verify; FR-052/053/040) | transcript (segments, speakers, confidences) ; STT engine + version; prompt version; per-model structured verdicts; model ids/versions/providers; consensus result (FR-040 vocabulary, D-05); regulation/policy versions in force (CR-05); timestamp provenance classes (CR-06) | H_transcript; H_provenance; H_verdicts; **ER = Merkle root over {H_rec, H_consent, H_disclosure, H_transcript, H_provenance, H_verdicts}** with explicit algorithm id | **T0 = RFC 3161 token over ER** (NFR-024) | optional batched anchor of many ERs (cost control, R-E); not required for proof | none | ER and every leaf (any later change creates a new ER) | reviewer notes; nothing in the root | n/a | any correction to evidence → new ER' (step 2 repeats); ER kept as evidence of what was changed | n/a | ER + T0: "this evidence existed, unchanged, at T0" (claim C1+C2 for evidence) | STT adapter · reviewer-model adapters · TSA adapter (RFC 3161 generic) |
| 3 | **Reviewer presentation** (FR-032/033; reviewer inbox) | presented set = artefacts whose hashes are in ER; proposal payload = {certificate draft, ER, T0 token id} | proposal payload hash = H(ER ‖ draft) — stored in the HiL proposal (`request_issue` already stores `content_hash`) | — | — | proposal `pending → under_review` (FR-033) | ER, T0 | reviewer's own notes | — | reviewer cannot edit evidence; may request re-formation (→ step 2, new ER') | — | reviewer sees exactly what ER commits to; any mismatch between displayed artefact and ER leaf = tamper alert | HiL engine (platform) |
| 4a | **Approve** (FR-034 SoD, FR-036 provenance) | approval record = {proposal id, ER, approver role, approver id (pseudonymised in export), decision=approved, reason, decision time (platform clock, informative)} | H_approval; **certificate leaf CL = H(ER ‖ H_approval ‖ certificate payload)** where payload = FR-054(1) set (call metadata + transcript hash + consensus + approver + T0 reference) | **T1 = RFC 3161 token over CL** | **anchor of CL (mandatory, NFR-023 ≤10 min)**; tx id recorded | approval record (above) | CL, T1, anchor tx, approval record | status only (via step 7) | n/a | n/a | n/a | "a reviewer approved exactly ER at T1; the approved content is CL" (claims C2, C4) | TSA adapter · anchor adapter (D-03) |
| 4b | **Reject** (FR-033 reason mandatory) | rejection record = {proposal id, ER, approver role, decision=rejected, reason} | H_reject; leaf = H(ER ‖ H_reject) | T1' = RFC 3161 token over the rejection leaf (optional but recommended — proves the evidence was reviewed and declined) | none | rejection record | ER, T0, rejection record | — | **no certificate exists; nothing anchored as a certificate**; evidence retained per FR-058/FR-077; a new proposal may be opened on the same ER or a new ER' (FR-033 "resubmitted as a new Proposal") | — | n/a | "this evidence was reviewed and rejected at T1'" | HiL · TSA |
| 4c | **Modify** (reviewer requests change; not an FRD state — handled as reject-and-resubmit) | as 4b, reason = "re-form evidence"; then step 2 with ER' | — | — | — | rejection record | ER, T0 preserved | — | — | ER' ≠ ER; both exist; the certificate, if later approved, references ER' and may cite ER as "prior evidence set" | — | audit trail of change (FR-022) | — |
| 5 | **Certificate issue** (FR-054(5)(6)) | PDF (brand, locale/timezone NFR-056) embedding: CL hex, algorithm id, T1 token, anchor tx id + adapter type, ER hex, T0 token id, QR to verifier, verifier version, "proves / does not prove" lists (R-D) | H_pdf recorded in the evidence record (not in CL — the PDF is a rendering of CL) | — | — | — | PDF object (Object Lock, NFR-045) | signed link (FR-055, 30-day re-issuable) | n/a | n/a | n/a | PDF ↔ CL ↔ T1 ↔ anchor | PDF renderer (platform); storage adapter |
| 6 | **Verify** (FR-055, NFR-024, CR-12) | input: PDF or evidence record (+ artefacts optionally) | recompute every leaf → ER → CL | verify T0, T1 tokens (`openssl ts -verify` class) | check anchor tx against public material (cached per CR-09; "unverifiable" if chain unreachable, TSA still verifies) | read approval record | — | — | — | — | must also check **status** (step 7) | prints C1–C6 results + "does not prove" list | verifier: standalone (CR-12) or in-browser (FR-055) |
| 7 | **Supersede / revoke / correct** (CR-23; FR-077 retention; FR-036 "not rollbackable after delivery") | status record = {certificate CL, new status, reason class, superseding CL if any, authority role, time} | H_status; status leaf chained to CL | RFC 3161 token over the status leaf | anchor of the status leaf (so revocation is as strong as issuance) | status authority (role per R-E) | all prior material stays immutable; status is append-only | — | — | correction = new ER'' → new certificate CL'' with `supersedes = CL`; CL marked `superseded-by CL''` | as stated | verifier shows status as of the latest status record it can see; offline verifier uses the status list embedded at the last renewal | status authority (platform) · TSA · anchor |
| 8 | **Preserve / renew** (RFC 4998 renewal; CR-07/CR-08) | archive-timestamp sequence over all records | hash-tree renewal before SHA-256 deprecation; timestamp renewal before TSA certificate expiry | new tokens chained | re-anchor optional | — | all previous chains | — | — | — | — | verifier validates old and new chains | TSA (any) |

**What the human approves (precisely):** the ER (a hash) plus the draft certificate payload that references it. The approver never approves bytes they did not see: the ER commits to exactly the artefacts shown (step 3). **What becomes immutable and when:** evidence at T0 (step 2); the approved certificate at T1 (step 4a); status facts when written (step 7). **Can the final certificate prove the approved content is exactly what was anchored?** Yes: CL includes ER and H_approval; T1 and the anchor are over CL; the verifier recomputes CL from the same inputs.

## 2. D-06 options tested against the lifecycle (using the completed evidence)

| Test | (a) FRD: approval → anchor → PDF (single T1) | (b) ARCH §10: anchor → PDF → HiL | (c) two timestamps (T0 evidence, T1 certificate) |
|---|---|---|---|
| Exists before human approval | unanchored evidence | anchored PDF of pre-review content | ER timestamped at T0; no certificate |
| What the human approves | draft payload (today: 7 fields, no evidence hashes) | an already-anchored PDF | ER + draft referencing ER |
| Timestamped / anchored | approved payload at T1 | pre-review payload at T0 only | ER at T0 (TSA), CL at T1 (TSA + anchor) |
| Immutable | approved content | pre-review content; approval is a mutable DB row unless re-anchored | both |
| Human rejects / modifies | nothing anchored — clean; but **no timestamped proof the evidence was unchanged between capture and review** | an anchored artefact must be revoked/superseded — requires CR-23 *before* first issue; orphan risk | ER + rejection record timestamped; new ER' on modification; clean |
| Certificate proves approved content = anchored content | yes for the payload; **chain-of-custody gap** capture→review unproven | **no** (approval not in anchored material) | **yes, and custody gap closed** |
| Consistency with approved documents | FR-054 ✔, BRD AC-02.5 ✔ | FR-054 ✘, BRD AC-02.5 ✘ (both say approval first) | FR-054 ✔ (certificate still produced on approval), AC-02.5 ✔, extends with a pre-review evidence timestamp the FRD does not forbid |
| Code distance (Part 41/E-02) | add TSA + per-cert anchor + PDF per call + approval into hash | same plus revocation model first | add evidence hashing (D-12 bindings), ER, TSA at two points, anchor at T1, approval into CL |
| Standards fit (R-C) | single archive timestamp — RFC 4998 compatible | compatible but semantically wrong for HiL | RFC 4998 archive-timestamp chain — direct fit (E-02) |
| Cost | 1 TSA token + 1 anchor per certificate | 1 token + 1 anchor + re-anchor for approval | 2 TSA tokens per certificate; anchors: 1 mandatory (T1); T0 anchors optional/batched |
| Relying-party needs (R-D) | RP-1/RP-2 satisfied; RP-3 custody weak | RP-3 fails (approval unproven) | all five classes |
| Autonomy policy (D-17) | A2 on evidence/crypto — all options are human-gated | same | same |

## 3. Recommendation for D-06 (exactly one)

**RECOMMEND OPTION (c) — two timestamps**, specified as in §1: T0 = RFC 3161 archive timestamp over the evidence root before reviewer presentation; T1 = RFC 3161 archive timestamp **and** anchor over the certificate leaf after HiL approval; PDF issued after T1; rejection and status changes are themselves timestamped; anchoring at T0 optional and batched.

Why (c) and not (a): (a) satisfies the documents but leaves the capture→review custody gap unproven, which is exactly the challenge a counterparty or court will raise (R-D RP-3); E-02 shows (c) costs one additional TSA token and no redesign of the existing `content_hash`. Why not (b): it contradicts FR-054 and BRD AC-02.5 and would require the CR-23 revocation model to exist before the first certificate.

**Confidence:** HIGH that (b) must be excluded; MEDIUM-HIGH for (c) over (a) — the residual uncertainty is commercial (TSA token cost at volume, E-05) and the token-level E-02 verification on staging.

**Dependencies if (c) is approved:** D-16 → "yes" (CR-07 ERS as the evidence-record substrate), because (c) is naturally an ERS archive-timestamp chain; CR-04/05/06 bindings (D-12 scope) supply the ER leaves; CR-23 supplies step 7; S51/M33 (certification provider abstraction) supplies the TSA and anchor adapters; S12/M11 conformance supplies per-call anchor/PDF (CD-13).

**If the PO chooses (a) instead:** §1 still holds with step 2's T0 removed and ER computed but not timestamped; everything else is unchanged.

## 4. Requirement consequences (for `TALKPROOF_REQUIREMENTS_RECONCILIATION_V001`; no IDs issued)

- FR-054 Processing (1)–(6): rewrite to the eight steps above (approval before issue retained).
- FR-054(1) canonical set: add evidence root, approval record, provenance (D-12 accepted scope; CR-04/05/06).
- NFR-023: "every issued certificate… anchored within 10 minutes" → applies to CL at T1; add "status records are anchored".
- NFR-024: applies to T0 and T1 tokens.
- FR-055: verifier must display status (step 7) and the R-D "proves / does not prove" lists.
- FR-036: "not rollbackable after PDF delivery" → reconcile with CR-23 supersession (rollback ≠ supersession; keep FR-036, add supersession).
- New requirement candidates: evidence record (CR-07), status lifecycle (CR-23), algorithm identifier (CR-08), timestamp provenance (CR-06).

## 5. Architecture consequences (for `TALKPROOF_ARCHITECTURE_RECONCILIATION_V001`)

ARCH §10 flowchart must be replaced by §1 of this document; ADR-007 reworded to "RFC 3161 archive timestamps (T0/T1) + provider-neutral anchor"; a new component `EvidenceRecordService` (ERS build/verify/renew) and `CertificateStatusService` (step 7) are proposed; `CertificationProvider` (S51) becomes the anchor adapter; TSA client is a separate adapter (RFC 3161 is provider-neutral by protocol).
