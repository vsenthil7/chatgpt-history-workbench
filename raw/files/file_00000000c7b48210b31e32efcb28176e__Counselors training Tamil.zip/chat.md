# WhatsApp Chat Export: Counselors training Tamil
Export date: 10 October 2026 at 1:19 pm

---

## 1 October 2026

[9:22 am] __+91 93427 61782 created the group__

---

## 9 October 2026

[1:11 pm] __+91 93427 61782 added You__

[1:11 pm] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

[1:12 pm] **+91 70102 55160:** OK ma'am

[1:12 pm] **+91 93427 61782:** 87545 98779
@Subha

[1:12 pm] **+91 93427 61782:**
> _+91 93427 61782: 87545 98779
@Subha_
connect this lead

[1:30 pm] **You:** Dialed cut the call, updated the details in CRM @~Upgrow Academy

[1:45 pm] **+91 93427 61782:** pls share the details in whatsapp

[1:47 pm] **You:**
> _+91 93427 61782: pls share the details in whatsapp_
I try to reach, call ringed 20 seconds, and then cut the call, so i will call again 3.30 Pm and share the call status

[2:25 pm] **+91 93427 61782:** @all slight changes in meeting time. We will have the meeting at 2.50pm not at 2.30pm

[2:25 pm] **+91 70102 55160:** OK ma'am

[2:25 pm] **+91 63825 75914:** Ok mam

[2:25 pm] **You:** Ok mam

[2:25 pm] **+91 733 896 3764:** Ok mam

[2:26 pm] **+91 96985 26562:**
> _+91 93427 61782: @all slight changes in meeting time. We will have the meeting at 2.50pm not at 2.30pm_
Ok mam

[2:50 pm] **You:** Pls share the link

[2:51 pm] **Up Growacademy Fathima Sherin:** https://meet.google.com/fsd-xmaf-jiu

[2:51 pm] **Up Growacademy Fathima Sherin:** please join

[5:24 pm] **+91 93427 61782:** Tomorrow at 10.30 am We will be having meeting with Fahad sir
@all

[5:24 pm] **+91 733 896 3764:** Ok

[5:24 pm] **+91 63825 75914:** Ok mam

[5:24 pm] **+91 96985 26562:**
> _+91 93427 61782: Tomorrow at 10.30 am We will be having meeting with Fahad sir
@all_
Ok mam

[5:29 pm] **+91 70102 55160:** OK ma'am

[5:34 pm] **You:** Ok Mam

---

## 10 October 2026

[9:12 am] **+91 70102 55160:** Good morning ma'am

[9:13 am] **+91 93427 61782:** Good morning Team @all

[9:13 am] **+91 93427 61782:** 90924 68061
90922 91111
866 738 4464
@~Meena ☺️

[9:13 am] **+91 93427 61782:** 7397 411 914
98403 42203
866 773 5872
@~Salana Nazir

[9:15 am] **+91 63825 75914:**
> _+91 93427 61782: 90924 68061
90922 91111
866 738 4464
@~Meena ☺️_
Ok mam

[9:16 am] **+91 96985 26562:**
> _+91 93427 61782: Good morning Team @all_
Good morning mam

[9:17 am] **+91 93427 61782:** 93420 49934
866 815 8518
63694 80160
@Subha

[9:19 am] **+91 733 896 3764:**
> _+91 93427 61782: Good morning Team @all_
Good morning mam

[9:57 am] **+91 733 896 3764:** 7397411914 - Interested but he preferred to join later

[9:57 am] **+91 93427 61782:**
> _+91 93427 61782: 93420 49934
866 815 8518
63694 80160
@Subha_
@Subha have you connected these leads

[9:57 am] **+91 733 896 3764:** 9840342203 - switched off

[9:58 am] **+91 733 896 3764:** 8667735872 - asked to call at 2pm

[10:00 am] **+91 93427 61782:** have you added all the 3 leads in CRM @~Salana Nazir

[10:00 am] **+91 733 896 3764:** Yes mam

[10:32 am] **You:**
> _+91 93427 61782: @Subha have you connected these leads_
Yes dialing

[10:42 am] **You:** 93420 49934 : Kid crying she will call later, 866 815 8518 Busy he will call once he is free , 63694 80160 Voice not audible, Yesterday lead: ringing @~Upgrow Academy

[10:42 am] **You:** yes Mam

[10:43 am] **+91 96985 26562:**
> _+91 93427 61782: Tomorrow at 10.30 am We will be having meeting with Fahad sir
@all_
@~Upgrow Academy mam, do we have this meeting today?

[10:44 am] **+91 93427 61782:**
> _+91 96985 26562: @~Upgrow Academy mam, do we have this meeting today?_
The meeting has been postponed due to the unavailability of Fahad Sir. I will inform you of the meeting time once it has been rescheduled.

[10:46 am] **+91 63825 75914:** Ok mam

[10:46 am] **+91 70102 55160:** OK ma'am

[10:50 am] **+91 733 896 3764:**
> _+91 93427 61782: The meeting has been postponed due to the unavailability of Fahad Sir. I will inform you of the meeting time once it has been rescheduled._
Ok Mam

[11:12 am] **+91 93427 61782:** 97500 73673
97157 14586
88258 45143
@~Nivi

[11:12 am] **+91 93427 61782:** 93458 93918
94447 20957
861 067 3025
@~Megana

[11:12 am] **+91 70102 55160:**
> _+91 93427 61782: 93458 93918
94447 20957
861 067 3025
@~Megana_
OK ma'am

[11:52 am] **+91 96985 26562:**
> _+91 93427 61782: 97500 73673
97157 14586
88258 45143
@~Nivi_
Ok mam

[12:40 pm] **+91 93427 61782:** Who is available

[12:40 pm] **+91 93427 61782:** @all

[12:41 pm] **Up Growacademy Fathima Sherin:** 📢 *Upcoming Batch Update*

🌙 *Monday Night – 9:00 PM*
• Enrolled: 3
• Target: 10
• *Need: 7 more admissions*

🌞 *Monday Morning – 10:00 AM*
• Enrolled: 2
• Target: 10
• *Need: 8 admissions*

[12:41 pm] **+91 63825 75914:** S mam

[12:44 pm] **+91 70102 55160:** S mam

[12:56 pm] **Up Growacademy Fathima Sherin:** Any admissions expecting guysss

@all
