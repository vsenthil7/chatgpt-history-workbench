# AT-LOS V025 Change Log

**Release type:** source graph and structured fidelity. ADR-025, amending ADR-024 and ADR-023. Last pre-evidence correction.

## at-ingest-llm-export

`_validate_graph()` checks the whole graph before any branch question: non-object nodes, dangling parents, cycles **anywhere**. Malformed nodes are reported and excluded from extraction. Structured parts are preserved as their **original JSON objects** — no truncation, no `default=str`.

## Documents and guards

RTM-112 rejects capability generalisations ("every module beyond L0/L1", "everything else is specification"). RTM-113 fails the build on any current document claiming the external publication boundary works. RTM-114 and RTM-115 cover the two blockers. 25 mutation cases.

`docs/TEST_STRATEGY.md` and `README.md` reconciled; the Test Strategy workbook's documentation map now says **Intended**, not **Is**, and states the mechanism's status plainly.

## Decisions

D-098 structural validity belongs to the structure · D-099 preservation means the whole value · D-100 no capability generalisations · D-101 no describing a Partial mechanism as working

## Opened

**DQ-016** — how the external documentation publication boundary is actually enforced.

## Open

DQ-004, DQ-012, DQ-013, DQ-014, DQ-016 · external publication boundary Partial since V018 · **AT-056 Not started**.
