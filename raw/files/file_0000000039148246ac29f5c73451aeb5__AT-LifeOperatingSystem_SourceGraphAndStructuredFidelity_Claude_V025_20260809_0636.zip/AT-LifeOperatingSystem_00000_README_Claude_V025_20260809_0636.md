# AT-Life Operating System (AT-LOS) - V025

**Release:** `AT-LifeOperatingSystem_SourceGraphAndStructuredFidelity_Claude_V025_20260809_0636`
**Prepared by:** Claude · **09-Aug-2026 06:36 BST**

```
V025 — SourceGraphAndStructuredFidelity

pytest                 403 passed, 1 skipped
coverage               1269 statements, 352 branches, 100% line and branch
architecture guards    54 collected
integration (real venv) 2 collected
mutation regression    25/25 killed
RTM                    112 passing + 1 skipped + 2 not enforced = 115
modules / products     11 declared, 2 product applications
test suites            17 built, 4 declared not built (3 internal, 1 external)
documentation          46 pages, 2 publication profiles
packages measured      at-cli, at-identity, at-ingest-core, at-ingest-llm-export, at-ingest-whatsapp, at-store
platform version       0.16.0

Facts measured: outcomes=True coverage=True
```

## Both blockers were real, and one was mine twice over

**Cycle detection was scoped to the walked path.** A cycle anywhere other than the
current branch — or **any** cycle in an export naming no `current_node` — was
accepted with 0 issues and 100% coverage. Reproduced exactly as you described.

Structural validity is a property of the **graph**, not of the path a reader
happened to end on. Every node is now checked before any branch question is
asked: non-object nodes, dangling parents, cycles anywhere. A malformed node is
reported *and* excluded, so one bad entry cannot stop the rest being read.

**The structured-content fix truncated at 500 characters.** V023 kept a count.
V024 replaced it with `json.dumps(...)[:500]` and I called it *preserved* — a
1273-character block stored as 500, still reporting 0 issues and 100% coverage.
**The same silent loss, in a new place, introduced by the fix for it.**

The block is now kept as its **original JSON object**: no truncation, no
`default=str` coercion. The parts came from `json.loads`, so they are already
JSON-safe, and `Event.meta`'s type-stability contract makes them storable by
construction.

## Two claim-level fixes

**"Every module beyond L0/L1 — no code exists"** was true when written and false
from V021. **"Everything else is specification"** likewise. Both survived several
reconciliations because each fix targeted one phrase. RTM-112 now rejects the
*pattern*: name the modules, or generate the section.

**The publication boundary said two things at once.** The Standard, the Test
Strategy workbook and ADR-018 described it as working while the metadata called
it open. RTM-113 fails the build on any current document claiming it works.

It stays **Partial**, now tracked as **DQ-016**. MkDocs builds pages omitted from
`nav`; a real boundary needs a separate `docs_dir`, an exclude plugin, or a
build-time check that no internal page reaches the output. Nothing is published,
so nothing has leaked — but the mechanism must exist before it is relied on.

## What this release does not do

It does not build the publication boundary, and it does not start `at-evidence`.

What it does is remove the last two reasons evidence could not trust ingestion:
**the canonical Event preserves the source completely enough to know what was
there, and the conversation graph is structurally valid independently of which
branch is selected.**

## Next

`at-evidence`. `at-consent` still needs **DQ-012 and DQ-013** from you.

**AT-056 remains Not started.**
