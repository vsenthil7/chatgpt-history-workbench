# AT-Life Operating System (AT-LOS) - V007

**Release:** `AT-LifeOperatingSystem_DecisionQueueAndSprintTracker_Claude_V007_20260807_0245`
**Prepared by:** Claude · **Timestamp:** 07-Aug-2026 02:45 BST
**Internal codename:** AT-LOS · **Public brand:** undecided, and blocked (D-022)

## What V007 adds

Three registers, and the sprint tracker folded into the Project Memory so there is one place to look.

**`13_DecisionQueue`** — decisions known to be needed and *intentionally* postponed. Eleven entries, each carrying five mandatory fields plus a delay cost. This answers the question every future reader will ask: *we knew this needed deciding, why didn't we?* The answer is now always "because the trigger hasn't happened", never "we forgot".

**`14_SprintTracker`** — 24 task rows with a Definition of Done that names a runnable command, the evidence actually produced, and a **Register updated** column. A task is not Done until that column says Yes. Seven rows say Yes; all seven were delivered on 07-Aug.

**`15_NamingRegister`** — 35 rows covering every name considered. Each states the claim, the verification level, the source, the date and who verified it — and, separately, **what was not verified**.

## Why the naming register has a verification column

Twelve rejections in it are marked **Unverified**. They came from a single AI review and were not independently checked. They're recorded so nobody re-suggests them, not as established fact.

One correction is recorded explicitly: Elyvora was logged as having a "registered UK mark". The UK company is real — ELYVORA LTD, 16502994, incorporated 08-Jun-2025, software development. The trademark is not: it is a *pending US application, serial 98959367, in Class 12* — drones and bicycle parts. Right conclusion, wrong evidence, and D-018 says that isn't good enough.

**No candidate has legal clearance. Not one.** That is queued as DQ-002 with a trigger, not left floating.

## Decisions added

D-022 rename blocked, AT-LOS internal only · D-023 Decision Queue adopted, sixteen registers is the ceiling · D-024 availability is a filter applied last, never a reason to choose · D-025 nothing published to PyPI until the brand settles · D-026 every register row states verification level and source

## Capability state

27 capabilities tracked. **4 Implemented, 3 Manual only, 6 Planned, 11 Vision/Named/Research, 3 Rejected.** Four moved up since V005 — all four in V006, all four code.

## The number that matters

`14_SprintTracker` row H-01 is a KPI, not a task: **days AT-056 has been Not started — currently 2.**

The 30-day follow-through measurement is the only Critical item with no dependency and no progress. Two consecutive nights went to naming. Naming was not useless — AT-LOS as an external brand would have been an expensive mistake — but the pattern is the one logged against V005: interesting problem, deep exploration, excellent documentation, primary measurable outcome delayed.

The counter resets when the measurement starts. It cannot be recovered later; it consumes calendar time nothing else can give back.

## Contents

| File | What it is |
|---|---|
| `00020_ProjectMemory` | **The living document. Sixteen registers. Start here** |
| `00003_ProjectMemoryStandard` | The rules and what they guard against |
| `00031_DevelopmentDesignDocument` | Layers, principles, the monorepo decision |
| `at-platform_repo` | Working code. Unzip, run pytest |
| `00001_DecisionMemo` · `03000_EvidenceRegister` · `AT-SubhaBhuvana_CallEffectivenessAnalysis` | Carried forward from V004 |

**Superseded:** the V006 standalone sprint planner — it is now `14_SprintTracker`. Do not maintain both. `06_DeferredDecisions` is closed; its rows migrated to `13_DecisionQueue`.

## The rule behind all of this

Nothing important lives only in Senthil's mind. If a thought is not in one of the sixteen registers, it is at risk of being forgotten or rediscovered. Putting it in one is what makes it safe to stop thinking about it tonight.

Sixteen registers is also a lot. D-023 caps it: no new register without a Decision Log entry. The V005 risk stands — this could become the work.
