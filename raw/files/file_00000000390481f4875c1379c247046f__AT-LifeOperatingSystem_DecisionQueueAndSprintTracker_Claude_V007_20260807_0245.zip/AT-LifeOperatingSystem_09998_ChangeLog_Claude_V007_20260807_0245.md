# AT-LOS V007 Change Log

## Added

- **`13_DecisionQueue`** — 11 postponed decisions, each with why it matters, the trigger that forces it, latest acceptable date, owner, and cost of delaying too long. Turns "we forgot" into "the trigger has not happened".
- **`14_SprintTracker`** — 24 rows across 3 sprints with Definition of Done, evidence produced, verification date and a mandatory `Register updated` column. Includes KPI row H-01: days AT-056 has been Not started.
- **`15_NamingRegister`** — 35 rows. Every row carries claim, verification level, source, date, verifier and what was NOT verified. 12 rejections marked Unverified.
- Six new decisions, D-022 to D-026, plus D-019 to D-021 back-filled from V006.
- Two assumptions: AS-010 (a third party may register a shortlisted name first), AS-011 (WhatsApp export format stability).
- PK-015: Decision Validation as a reusable module, parked with an expiry — process, not product, until proven otherwise.
- FV-009: Decision Validation as a future product.
- Four Lessons Learned entries covering V006 and V007.

## Changed

- V006 standalone sprint planner folded into `14_SprintTracker`. Do not maintain both.
- `06_DeferredDecisions` closed. All seven rows migrated to `13_DecisionQueue` with triggers and delay costs added. Sheet retained for traceability; no new rows.
- `10_HallucinationRegister` synced with shipped code: 27 capabilities, 4 Implemented.
- AT-005a moved to Done in `01_ActiveSprint`; AT-058 unblocked in Next Sprint.
- PK-009 and PK-010 marked largely answered by D-019.

## Corrected

- Elyvora rejection reason. Recorded as "registered UK mark"; verified as a pending US application, serial 98959367, Class 12 (drones, bicycles, vehicle parts). The UK company collision is real and separately verified: ELYVORA LTD 16502994, incorporated 08-Jun-2025, SIC 62012.
- Eryvanta added as GitHub org holder — github.com/eryvanta, created 09-Feb-2026 — missed in the original review that ranked it second.

## Decided

- D-022: repository rename blocked. AT-LOS is an internal codename only. No public brand adopted.
- D-023: Decision Queue adopted. Sixteen registers is the ceiling; no new register without a Decision Log entry.
- D-024: availability is a filter applied last, never a reason to choose. Brand flows vision to positioning to shortlist to availability to clearance.
- D-025: no package published to PyPI until the brand is settled. An unpublished package claims no public namespace.
- D-026: every register row states its verification level and source.

## Unchanged

- All working code from V006. No code changed in this release.
- V004 decision memo, evidence register, consultant analysis.
- V001 charter, methodology, naming and versioning standard.
