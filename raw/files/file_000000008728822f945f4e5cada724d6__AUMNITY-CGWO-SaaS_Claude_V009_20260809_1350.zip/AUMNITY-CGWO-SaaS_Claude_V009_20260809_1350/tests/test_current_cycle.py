"""F33/F36 regression: release identity has ONE canonical source, and every
derived representation must match it.

The V006 review (F33) found the RTM's AI-001 row still calling the V005 handoff
the "current cycle" while the package was V006. The first fix derived the
series from ``max(RELEASE-NOTES-V*.md)``; the V007 review (F36) showed that
made "the highest release-note filename" the authority, so a stray/future
release-notes file could spoof the release. This version reads the canonical
identity from ``00-control/RELEASE-IDENTITY.json`` and asserts the other
representations agree with it — never the reverse.
"""

import json
import re
import tomllib
from pathlib import Path


def _repo_root() -> Path:
    """Resolve the real repository root, even when pytest is invoked from the
    mutation harness's mutants/ sandbox. Walk up until the canonical identity
    file is found."""
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "00-control/RELEASE-IDENTITY.json").is_file():
            return parent
    return here.parents[1]


ROOT = _repo_root()


def _canonical_series() -> str:
    """THE release series, from the single canonical source (F36)."""
    identity = json.loads((ROOT / "00-control/RELEASE-IDENTITY.json").read_text(encoding="utf-8"))
    series = identity["series"]
    assert re.fullmatch(r"V\d+", series), f"canonical series malformed: {series}"
    return series


def _canonical_core_version() -> str:
    identity = json.loads((ROOT / "00-control/RELEASE-IDENTITY.json").read_text(encoding="utf-8"))
    return identity["core_version"]


def test_rtm_current_cycle_references_canonical_handoff():
    series = _canonical_series()
    rtm = (ROOT / "06-traceability/RTM.md").read_text(encoding="utf-8")
    ai_row = next(line for line in rtm.splitlines() if line.startswith("| AI-001 "))
    handoff = f"CLAUDE-{series}-HANDOFF.md"
    assert handoff in ai_row, (
        f"RTM AI-001 must reference the canonical current-cycle handoff {handoff}; row was: {ai_row}"
    )


def test_canonical_handoff_and_notes_and_gate_exist():
    series = _canonical_series()
    assert (ROOT / f"08-ai/CLAUDE-{series}-HANDOFF.md").is_file()
    assert (ROOT / f"00-control/RELEASE-NOTES-{series}.md").is_file()
    assert (ROOT / f"05-quality/GATE-STATUS-{series}.md").is_file()


def test_manifest_release_matches_canonical_series():
    series = _canonical_series()
    mf = ROOT / "PACKAGE-MANIFEST.json"
    if not mf.is_file():
        # Manifest is generated at packaging time; skip if absent in WIP.
        return
    release = json.loads(mf.read_text(encoding="utf-8")).get("release", "")
    assert f"_{series}_" in release or release.endswith(f"_{series}"), (
        f"manifest release '{release}' does not embed canonical series {series}"
    )


def test_pyproject_version_matches_canonical_core_version():
    core_version = _canonical_core_version()
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    assert pyproject["project"]["version"] == core_version, (
        f"pyproject version {pyproject['project']['version']!r} != canonical "
        f"core_version {core_version!r}"
    )


def test_no_release_note_is_newer_than_canonical_series():
    """The F36 spoof: a stray/future RELEASE-NOTES file must NOT become the
    apparent release authority. Any release note numbered higher than the
    canonical series is a validation failure, not a new current version."""
    series = _canonical_series()
    canonical_n = int(series[1:])
    higher = []
    for note in (ROOT / "00-control").glob("RELEASE-NOTES-V*.md"):
        m = re.search(r"V(\d+)", note.name)
        if m and int(m.group(1)) > canonical_n:
            higher.append(note.name)
    assert not higher, (
        f"release notes {higher} are newer than canonical {series}; identity must be "
        f"anchored to RELEASE-IDENTITY.json, not the highest filename"
    )


# --- F40: generic versioned-artifact spoof coverage ---------------------------
# These assert the VALIDATOR (not just this test) rejects future gate/handoff
# artifacts and root/manifest mismatches. We invoke the validator as a module
# against a temporary copy so the checks exercise the shipped rule.

import shutil
import subprocess
import sys


def _copy_package(tmp_path: Path) -> Path:
    dest = tmp_path / ROOT.name
    shutil.copytree(ROOT, dest)
    # Drop caches that would bloat the copy.
    for junk in ("mutants", ".pytest_cache", ".ruff_cache", ".mypy_cache"):
        p = dest / junk
        if p.is_dir():
            shutil.rmtree(p)
    return dest


def _run_validator(pkg: Path) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "scripts/validate_consistency.py", "--skip-manifest"],
        cwd=pkg,
        capture_output=True,
        text=True,
        check=False,
    )


def test_validator_rejects_future_gate_status(tmp_path):
    pkg = _copy_package(tmp_path)
    series = _canonical_series()
    (pkg / "05-quality" / f"GATE-STATUS-V{int(series[1:]) + 991}.md").write_text("stub\n")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F40" in result.stdout


def test_validator_rejects_future_handoff(tmp_path):
    pkg = _copy_package(tmp_path)
    series = _canonical_series()
    (pkg / "08-ai" / f"CLAUDE-V{int(series[1:]) + 991}-HANDOFF.md").write_text("stub\n")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F40" in result.stdout


def test_validator_rejects_future_release_note(tmp_path):
    pkg = _copy_package(tmp_path)
    series = _canonical_series()
    (pkg / "00-control" / f"RELEASE-NOTES-V{int(series[1:]) + 991}.md").write_text("stub\n")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F40" in result.stdout


def test_validator_rejects_noncanonical_package_root(tmp_path):
    pkg = _copy_package(tmp_path)
    renamed = tmp_path / "AUMNITY-CGWO-SaaS_Claude_V001_20200101_0000"
    pkg.rename(renamed)
    result = _run_validator(renamed)
    assert result.returncode != 0
    assert "F40" in result.stdout
