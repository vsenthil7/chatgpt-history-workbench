"""Adversarial domain-object attacks under the ADR-014 trust model.

History: V006 tried to make object identity a trust anchor (exact-type
guards). The V006 review (F30) proved that wrong — ``object.__setattr__``
mutates a genuine frozen instance, and a lying subclass (F32) defeats
attribute reads from one layer up. ADR-014 moves the security decision to an
authenticated authorization boundary: a protected operation is allowed only
if the authenticated principal is entitled to the aggregate's tenant, a fact
no caller-supplied object can forge.

These regressions use the reviewer's exact attacks (post-construction
mutation, hostile-equality owner, lying ``TenantContext``/``CapacityWindow``/
``PlanItem`` subclasses) and prove none of them obtains authority.
"""

from datetime import date

import pytest
from tests._authz import authz_for

from cgwo_core.allocation import AllocationState, CapacityAllocation
from cgwo_core.authz import AuthorizationError
from cgwo_core.capacity import CapacityWindow
from cgwo_core.contracts import (
    WIRE_INT_MAX_VALUE,
    ContractViolationError,
    TimeRecordProposal,
    parse_wire_int,
)
from cgwo_core.errors import INTEGER_OUT_OF_RANGE
from cgwo_core.plan_item import PlanItem, PlanItemState
from cgwo_core.tenancy import CrossTenantAccessError, TenantContext

D1, D5 = date(2026, 8, 1), date(2026, 8, 5)


def victim_window(tenant: str = "victim") -> CapacityWindow:
    return CapacityWindow(
        tenant_id=tenant,
        resource_ref="actor-1",
        period_start=D1,
        period_end=D5,
        available_minutes=600,
    )


# --- F30: post-construction mutation of a genuine object ----------------------
def test_f30_mutated_tenant_context_cannot_obtain_authority():
    """The reviewer's exact attack: mutate a genuine, exact-typed context."""
    ctx = TenantContext("attacker")
    object.__setattr__(ctx, "tenant_id", "victim")
    assert type(ctx) is TenantContext  # still genuinely exact
    # An attacker principal is only entitled to 'attacker', not 'victim'. The
    # victim aggregate's transition authorizes against 'victim' and is denied,
    # regardless of the mutated label the attacker carries.
    item = PlanItem(tenant_id="victim", work_object_ref="wo-1")
    with pytest.raises(AuthorizationError):
        item.transition(PlanItemState.WEEK_PLANNED, authz_for("attacker"), ctx)


def test_f30_mutated_window_cannot_grant_capacity_or_authority():
    window = victim_window(tenant="attacker")
    object.__setattr__(window, "tenant_id", "victim")
    object.__setattr__(window, "available_minutes", 1_000_000_000)
    # Even with a mutated genuine window, an operation on it authorizes against
    # the window's tenant; an attacker principal is not entitled to 'victim'.
    alloc = CapacityAllocation.create("victim", victim_window(), "p", 100)
    with pytest.raises(AuthorizationError):
        alloc.transition(AllocationState.RESERVED, authz_for("attacker"), TenantContext("victim"))


# --- F32: lying aggregate subclasses ------------------------------------------
def test_f32_lying_plan_item_cannot_execute_against_victim():
    class LyingPlanItem(PlanItem):
        def __getattribute__(self, name):
            if name == "tenant_id":
                return "victim"
            return super().__getattribute__(name)

    item = LyingPlanItem("attacker", "work")
    # The lie reports 'victim', so the operation authorizes against 'victim' —
    # which the attacker principal is not entitled to. Denied.
    with pytest.raises(AuthorizationError):
        item.transition(PlanItemState.WEEK_PLANNED, authz_for("attacker"), TenantContext("victim"))


def test_f32_lying_plan_item_cannot_use_genuine_victim_authority_either():
    """If the attacker somehow held victim authority the routing check still
    binds ctx to the reported owner; and without it, authorization denies."""

    class LyingPlanItem(PlanItem):
        def __getattribute__(self, name):
            if name == "tenant_id":
                return "victim"
            return super().__getattribute__(name)

    item = LyingPlanItem("attacker", "work")
    # With an authz that is NOT entitled to victim, denied at authorization.
    with pytest.raises(AuthorizationError):
        item.transition(
            PlanItemState.WEEK_PLANNED, authz_for("attacker", "other"), TenantContext("victim")
        )


# --- F27/F28 (now subsumed): hostile owner / lying context at the authz layer -
def test_f27_lying_context_subclass_denied_by_authorization():
    class LyingContext(TenantContext):
        def __getattribute__(self, name):
            if name == "tenant_id":
                return "victim"
            return super().__getattribute__(name)

    item = PlanItem(tenant_id="victim", work_object_ref="wo-1")
    with pytest.raises(AuthorizationError):
        item.transition(PlanItemState.WEEK_PLANNED, authz_for("attacker"), LyingContext("attacker"))


def test_genuine_authorized_operation_succeeds():
    item = PlanItem(tenant_id="t1", work_object_ref="wo-1")
    change = item.transition(PlanItemState.WEEK_PLANNED, authz_for("t1"), TenantContext("t1"))
    assert change.new_state is PlanItemState.WEEK_PLANNED
    assert change.tenant_id == "t1"


def test_routing_mismatch_still_controlled():
    item = PlanItem(tenant_id="t1", work_object_ref="wo-1")
    # Entitled to both, but ctx names t2 while the aggregate is t1.
    with pytest.raises(CrossTenantAccessError):
        item.transition(PlanItemState.WEEK_PLANNED, authz_for("t1", "t2"), TenantContext("t2"))


# --- F31 (V006 review): oversized integers bounded on BOTH paths -------------
def test_f31_exact_int_over_limit_rejected():
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_int(WIRE_INT_MAX_VALUE + 1, "minutes")
    assert excinfo.value.code == INTEGER_OUT_OF_RANGE
    assert excinfo.value.fields == {"field": "minutes"}


def test_f31_massively_oversized_exact_int_rejected_without_stringifying():
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_int(10**5000, "minutes")
    assert excinfo.value.code == INTEGER_OUT_OF_RANGE


def test_f31_negative_exact_int_rejected():
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_int(-1, "minutes")
    assert excinfo.value.code == INTEGER_OUT_OF_RANGE


def test_f31_exact_int_at_limit_accepted():
    assert parse_wire_int(WIRE_INT_MAX_VALUE, "minutes") == WIRE_INT_MAX_VALUE


def test_f31_zero_is_accepted_by_wire_int():
    # Pins the `< 0` boundary (a `<= 0` or `< 1` mutant would reject zero).
    assert parse_wire_int(0, "minutes") == 0


def test_f31_one_is_accepted_by_wire_int():
    assert parse_wire_int(1, "minutes") == 1


def test_f31_string_with_too_many_digits_rejected():
    overlong = "9" * (len(str(WIRE_INT_MAX_VALUE)) + 1)
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_int(overlong, "minutes")
    assert excinfo.value.code == INTEGER_OUT_OF_RANGE
    assert excinfo.value.fields == {"field": "minutes"}


def test_f31_string_same_digits_but_over_value_rejected():
    over = str(WIRE_INT_MAX_VALUE + 5)  # 13 digits, numerically larger
    assert len(over) == len(str(WIRE_INT_MAX_VALUE))
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_int(over, "minutes")
    assert excinfo.value.code == INTEGER_OUT_OF_RANGE
    assert excinfo.value.fields == {"field": "minutes"}


def test_f31_string_at_limit_accepted():
    assert parse_wire_int(str(WIRE_INT_MAX_VALUE), "minutes") == WIRE_INT_MAX_VALUE


def test_f31_from_wire_time_record_rejects_oversized_exact_int():
    with pytest.raises(ContractViolationError):
        TimeRecordProposal.from_wire(
            tenant_id="t1",
            resource_ref="a",
            work_object_ref="w",
            minutes=10**5000,
        )


# --- Trust-model honesty: the authz contract IS the trust root (ADR-014) -----
def test_authz_is_the_trust_root_not_the_domain_object():
    """This documents the trust model precisely (review F30 lesson).

    The domain core trusts the AuthorizationPort to report authenticated
    entitlements — that is the whole point of moving the decision there. A
    caller who can already forge an AuthorizationContext with victim
    entitlements has, by definition, defeated authentication UPSTREAM; the
    domain core cannot and does not claim to defend against a forged
    authenticated identity. What it DOES guarantee is that no manipulation of
    DOMAIN OBJECTS (mutation, lying subclasses, relabeled contexts) can obtain
    authority without such an entitlement. The pair of assertions below makes
    that boundary explicit.
    """
    # Domain-object manipulation cannot obtain authority:
    item = PlanItem(tenant_id="victim", work_object_ref="wo-1")
    with pytest.raises(AuthorizationError):
        item.transition(PlanItemState.WEEK_PLANNED, authz_for("attacker"), TenantContext("victim"))
    # Only a genuine entitlement (which a service layer binds to authenticated
    # identity) authorizes the operation:
    change = item.transition(
        PlanItemState.WEEK_PLANNED, authz_for("victim"), TenantContext("victim")
    )
    assert change.new_state is PlanItemState.WEEK_PLANNED
