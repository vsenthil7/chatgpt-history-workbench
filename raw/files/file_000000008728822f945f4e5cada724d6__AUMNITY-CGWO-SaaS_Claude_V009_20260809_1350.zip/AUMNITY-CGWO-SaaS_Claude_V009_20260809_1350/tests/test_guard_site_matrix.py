"""Exhaustive guard-site matrix (ADR-010/ADR-011).

One row per raise site in the domain core: each row triggers the site and
asserts the FULL structured error identity — exception type, stable code and
the exact ``fields`` payload. This is the behavioural anchor that lets the
mutation gate stay honest without turning message prose into a contract:
mutants that damage diagnostic structure (field names, expected types,
actual types, transition endpoints) die here.
"""

from datetime import date

import pytest
from tests._authz import ALL_TENANTS_AUTHZ as AUTHZ
from tests._authz import authz_for as _authz_for

from cgwo_core import errors as E
from cgwo_core.allocation import (
    AllocationInvariantError,
    AllocationState,
    CapacityAllocation,
)
from cgwo_core.authz import AuthorizationError, assert_authorized  # noqa: F401
from cgwo_core.capacity import (
    AvailabilityDeclaration,
    CapacityInvariantError,
    CapacityType,
    CapacityWindow,
)
from cgwo_core.contracts import (
    AvailabilityProposal,
    ContractViolationError,
    TimeRecordProposal,
    parse_wire_capacity_type,
    parse_wire_date,
    parse_wire_int,
)
from cgwo_core.plan_item import (
    ChangeReasonRequiredError,
    InvalidTransitionError,
    PlanItem,
    PlanItemInvariantError,
    PlanItemState,
)
from cgwo_core.tenancy import (
    CrossTenantAccessError,
    MissingTenantContextError,
    TenantContext,
    assert_tenant_operation,
)

CTX = TenantContext(tenant_id="t1")
D1, D5 = date(2026, 8, 1), date(2026, 8, 5)
WINDOW = CapacityWindow(
    tenant_id="t1",
    resource_ref="actor-1",
    period_start=D1,
    period_end=D5,
    available_minutes=600,
)


def w(**kw):
    base = {
        "tenant_id": "t1",
        "resource_ref": "actor-1",
        "period_start": D1,
        "period_end": D5,
        "available_minutes": 600,
    }
    base.update(kw)
    return CapacityWindow(**base)


def alloc(**kw):
    base = {
        "tenant_id": "t1",
        "window": WINDOW,
        "plan_item_ref": "pi-1",
        "allocated_minutes": 120,
        "consumed_minutes": 0,
        "state": AllocationState.PROPOSED,
    }
    base.update(kw)
    return CapacityAllocation(**base)


def decl(**kw):
    base = {
        "tenant_id": "t1",
        "resource_ref": "actor-1",
        "window": WINDOW,
        "declared_on": D1,
    }
    base.update(kw)
    return AvailabilityDeclaration(**base)


def trp(**kw):
    base = {
        "tenant_id": "t1",
        "resource_ref": "actor-1",
        "work_object_ref": "wo-1",
        "minutes": 30,
    }
    base.update(kw)
    return TimeRecordProposal(**base)


def wrong(field, expected, actual):
    return E.WRONG_RUNTIME_TYPE, {"field": field, "expected": expected, "actual": actual}


# (id, callable, exception type, code, exact fields payload)
MATRIX = [
    # --- tenancy._validate_context ------------------------------------------
    (
        "ctx-tenant-type",
        lambda: TenantContext(tenant_id=123),
        MissingTenantContextError,
        *wrong("tenant_id", "str", "int"),
    ),
    (
        "ctx-tenant-blank",
        lambda: TenantContext(tenant_id="  "),
        MissingTenantContextError,
        E.FIELD_BLANK,
        {"field": "tenant_id"},
    ),
    (
        "ctx-org-type",
        lambda: TenantContext(tenant_id="t1", organisation_id=7),
        MissingTenantContextError,
        *wrong("organisation_id", "str", "int"),
    ),
    (
        "ctx-org-blank",
        lambda: TenantContext(tenant_id="t1", organisation_id=" "),
        MissingTenantContextError,
        E.ORGANISATION_ID_BLANK,
        {},
    ),
    # --- tenancy.assert_tenant_operation / authz.assert_authorized ----------
    (
        "authz-owner-type",
        lambda: assert_tenant_operation(AUTHZ, CTX, 5),
        CrossTenantAccessError,
        *wrong("owner_tenant_id", "str", "int"),
    ),
    (
        "authz-ctx-type",
        lambda: assert_tenant_operation(AUTHZ, "t1", "t1"),
        MissingTenantContextError,
        *wrong("ctx", "TenantContext", "str"),
    ),
    (
        "authz-not-entitled",
        lambda: assert_tenant_operation(_authz_for("t9"), CTX, "t1"),
        AuthorizationError,
        E.NOT_ENTITLED,
        {"tenant_id": "t1"},
    ),
    (
        "authz-cross-route",
        lambda: assert_tenant_operation(AUTHZ, CTX, "t2"),
        CrossTenantAccessError,
        E.CROSS_TENANT,
        {},
    ),
    # --- capacity._validate_window ------------------------------------------
    (
        "win-tenant-type",
        lambda: w(tenant_id=1),
        CapacityInvariantError,
        *wrong("tenant_id", "str", "int"),
    ),
    (
        "win-tenant-blank",
        lambda: w(tenant_id=" "),
        CapacityInvariantError,
        E.FIELD_BLANK,
        {"field": "tenant_id"},
    ),
    (
        "win-resource-type",
        lambda: w(resource_ref=1),
        CapacityInvariantError,
        *wrong("resource_ref", "str", "int"),
    ),
    (
        "win-resource-blank",
        lambda: w(resource_ref=""),
        CapacityInvariantError,
        E.FIELD_BLANK,
        {"field": "resource_ref"},
    ),
    (
        "win-start-type",
        lambda: w(period_start="2026-08-01"),
        CapacityInvariantError,
        *wrong("period_start", "datetime.date", "str"),
    ),
    (
        "win-end-type",
        lambda: w(period_end=20260805),
        CapacityInvariantError,
        *wrong("period_end", "datetime.date", "int"),
    ),
    (
        "win-order",
        lambda: w(period_end=date(2026, 7, 31)),
        CapacityInvariantError,
        E.PERIOD_ORDER,
        {},
    ),
    (
        "win-minutes-type",
        lambda: w(available_minutes="600"),
        CapacityInvariantError,
        *wrong("available_minutes", "int", "str"),
    ),
    (
        "win-minutes-bool",
        lambda: w(available_minutes=True),
        CapacityInvariantError,
        *wrong("available_minutes", "int", "bool"),
    ),
    (
        "win-minutes-neg",
        lambda: w(available_minutes=-1),
        CapacityInvariantError,
        E.AVAILABLE_MINUTES_NEGATIVE,
        {},
    ),
    (
        "win-captype",
        lambda: w(capacity_type="EXECUTION"),
        CapacityInvariantError,
        *wrong("capacity_type", "CapacityType", "str"),
    ),
    # --- capacity._validate_declaration -------------------------------------
    (
        "decl-tenant-type",
        lambda: decl(tenant_id=5),
        CapacityInvariantError,
        *wrong("tenant_id", "str", "int"),
    ),
    (
        "decl-resource-type",
        lambda: decl(resource_ref=5),
        CapacityInvariantError,
        *wrong("resource_ref", "str", "int"),
    ),
    (
        "decl-window-type",
        lambda: decl(window="not-a-window"),
        CapacityInvariantError,
        *wrong("window", "CapacityWindow", "str"),
    ),
    (
        "decl-date-type",
        lambda: decl(declared_on="2026-08-01"),
        CapacityInvariantError,
        *wrong("declared_on", "datetime.date", "str"),
    ),
    (
        "decl-tenant-mismatch",
        lambda: decl(tenant_id="t2"),
        CapacityInvariantError,
        E.DECLARATION_TENANT_MISMATCH,
        {},
    ),
    (
        "decl-resource-mismatch",
        lambda: decl(resource_ref="actor-2"),
        CapacityInvariantError,
        E.DECLARATION_RESOURCE_MISMATCH,
        {},
    ),
    # --- plan_item._validate_plan_item --------------------------------------
    (
        "pi-tenant-type",
        lambda: PlanItem(tenant_id=9, work_object_ref="wo-1"),
        PlanItemInvariantError,
        *wrong("tenant_id", "str", "int"),
    ),
    (
        "pi-tenant-blank",
        lambda: PlanItem(tenant_id=" ", work_object_ref="wo-1"),
        PlanItemInvariantError,
        E.FIELD_BLANK,
        {"field": "tenant_id"},
    ),
    (
        "pi-ref-type",
        lambda: PlanItem(tenant_id="t1", work_object_ref=9),
        PlanItemInvariantError,
        *wrong("work_object_ref", "str", "int"),
    ),
    (
        "pi-ref-blank",
        lambda: PlanItem(tenant_id="t1", work_object_ref=" "),
        PlanItemInvariantError,
        E.FIELD_BLANK,
        {"field": "work_object_ref"},
    ),
    (
        "pi-state-type",
        lambda: PlanItem(tenant_id="t1", work_object_ref="wo-1", state="CANDIDATE"),
        PlanItemInvariantError,
        *wrong("state", "PlanItemState", "str"),
    ),
    # --- plan_item.transition_plan_item -------------------------------------
    (
        "pi-target-type",
        lambda: PlanItem.create("t1", "wo-1").transition("WEEK_PLANNED", AUTHZ, CTX),
        InvalidTransitionError,
        *wrong("target", "PlanItemState", "str"),
    ),
    (
        "pi-transition-denied",
        lambda: PlanItem.create("t1", "wo-1").transition(PlanItemState.STARTED, AUTHZ, CTX),
        InvalidTransitionError,
        E.TRANSITION_NOT_ALLOWED,
        {"source": "CANDIDATE", "target": "STARTED"},
    ),
    (
        "pi-reason-type",
        lambda: PlanItem.create("t1", "wo-1").transition(
            PlanItemState.DEFERRED, AUTHZ, CTX, change_reason=5
        ),
        ChangeReasonRequiredError,
        *wrong("change_reason", "str", "int"),
    ),
    (
        "pi-reason-missing",
        lambda: PlanItem.create("t1", "wo-1").transition(PlanItemState.DEFERRED, AUTHZ, CTX),
        ChangeReasonRequiredError,
        E.CHANGE_REASON_REQUIRED,
        {"source": "CANDIDATE", "target": "DEFERRED"},
    ),
    # --- allocation._validate_allocation ------------------------------------
    (
        "al-tenant-type",
        lambda: alloc(tenant_id=1),
        AllocationInvariantError,
        *wrong("tenant_id", "str", "int"),
    ),
    (
        "al-window-type",
        lambda: alloc(window={"available_minutes": 600}),
        AllocationInvariantError,
        *wrong("window", "CapacityWindow", "dict"),
    ),
    (
        "al-ref-type",
        lambda: alloc(plan_item_ref=1),
        AllocationInvariantError,
        *wrong("plan_item_ref", "str", "int"),
    ),
    (
        "al-ref-blank",
        lambda: alloc(plan_item_ref="  "),
        AllocationInvariantError,
        E.FIELD_BLANK,
        {"field": "plan_item_ref"},
    ),
    (
        "al-allocated-type",
        lambda: alloc(allocated_minutes="120"),
        AllocationInvariantError,
        *wrong("allocated_minutes", "int", "str"),
    ),
    (
        "al-allocated-bool",
        lambda: alloc(allocated_minutes=True),
        AllocationInvariantError,
        *wrong("allocated_minutes", "int", "bool"),
    ),
    (
        "al-consumed-type",
        lambda: alloc(consumed_minutes="0"),
        AllocationInvariantError,
        *wrong("consumed_minutes", "int", "str"),
    ),
    (
        "al-state-type",
        lambda: alloc(state="X"),
        AllocationInvariantError,
        *wrong("state", "AllocationState", "str"),
    ),
    (
        "al-tenant-mismatch",
        lambda: alloc(tenant_id="t2"),
        AllocationInvariantError,
        E.ALLOCATION_TENANT_MISMATCH,
        {},
    ),
    (
        "al-allocated-zero",
        lambda: alloc(allocated_minutes=0),
        AllocationInvariantError,
        E.ALLOCATED_MINUTES_NON_POSITIVE,
        {},
    ),
    (
        "al-consumed-neg",
        lambda: alloc(consumed_minutes=-1),
        AllocationInvariantError,
        E.CONSUMED_MINUTES_NEGATIVE,
        {},
    ),
    (
        "al-exceeds-window",
        lambda: alloc(allocated_minutes=601),
        AllocationInvariantError,
        E.ALLOCATION_EXCEEDS_WINDOW,
        {},
    ),
    (
        "al-proposed-consumed",
        lambda: alloc(consumed_minutes=5),
        AllocationInvariantError,
        E.STATE_REQUIRES_ZERO_CONSUMPTION,
        {"state": "PROPOSED"},
    ),
    (
        "al-reserved-consumed",
        lambda: alloc(state=AllocationState.RESERVED, consumed_minutes=5),
        AllocationInvariantError,
        E.STATE_REQUIRES_ZERO_CONSUMPTION,
        {"state": "RESERVED"},
    ),
    (
        "al-consuming-bound",
        lambda: alloc(state=AllocationState.CONSUMING, consumed_minutes=120),
        AllocationInvariantError,
        E.CONSUMING_BOUND_VIOLATED,
        {},
    ),
    (
        "al-partial-bound",
        lambda: alloc(state=AllocationState.PARTIALLY_CONSUMED, consumed_minutes=0),
        AllocationInvariantError,
        E.PARTIAL_BOUND_VIOLATED,
        {},
    ),
    (
        "al-consumed-exact",
        lambda: alloc(state=AllocationState.CONSUMED, consumed_minutes=119),
        AllocationInvariantError,
        E.CONSUMED_MUST_EQUAL_ALLOCATED,
        {},
    ),
    (
        "al-overrun-excess",
        lambda: alloc(state=AllocationState.OVERRUN, consumed_minutes=120),
        AllocationInvariantError,
        E.OVERRUN_REQUIRES_EXCESS,
        {},
    ),
    # --- allocation.transition_allocation / consume_allocation ---------------
    (
        "al-target-type",
        lambda: alloc().transition("RESERVED", AUTHZ, CTX),
        InvalidTransitionError,
        *wrong("target", "AllocationState", "str"),
    ),
    (
        "al-transition-denied",
        lambda: alloc().transition(AllocationState.CONSUMING, AUTHZ, CTX),
        InvalidTransitionError,
        E.TRANSITION_NOT_ALLOWED,
        {"source": "PROPOSED", "target": "CONSUMING"},
    ),
    (
        "al-consume-state",
        lambda: alloc().consume(10, AUTHZ, CTX),
        InvalidTransitionError,
        E.CONSUME_FROM_INVALID_STATE,
        {"state": "PROPOSED"},
    ),
    (
        "al-consume-minutes-type",
        lambda: alloc(state=AllocationState.RESERVED).consume(True, AUTHZ, CTX),
        AllocationInvariantError,
        *wrong("minutes", "int", "bool"),
    ),
    (
        "al-consume-nonpositive",
        lambda: alloc(state=AllocationState.RESERVED).consume(0, AUTHZ, CTX),
        AllocationInvariantError,
        E.CONSUME_NON_POSITIVE,
        {},
    ),
    # --- contracts strict constructors ---------------------------------------
    (
        "trp-tenant-type",
        lambda: trp(tenant_id=1),
        ContractViolationError,
        *wrong("tenant_id", "str", "int"),
    ),
    (
        "trp-tenant-blank",
        lambda: trp(tenant_id=" "),
        ContractViolationError,
        E.FIELD_BLANK,
        {"field": "tenant_id"},
    ),
    (
        "trp-resource-blank",
        lambda: trp(resource_ref=" "),
        ContractViolationError,
        E.FIELD_BLANK,
        {"field": "resource_ref"},
    ),
    (
        "trp-wo-blank",
        lambda: trp(work_object_ref=" "),
        ContractViolationError,
        E.FIELD_BLANK,
        {"field": "work_object_ref"},
    ),
    (
        "trp-narrative-type",
        lambda: trp(narrative=7),
        ContractViolationError,
        *wrong("narrative", "str", "int"),
    ),
    (
        "trp-source-blank",
        lambda: trp(source_system=" "),
        ContractViolationError,
        E.FIELD_BLANK,
        {"field": "source_system"},
    ),
    (
        "trp-minutes-type",
        lambda: trp(minutes="45"),
        ContractViolationError,
        *wrong("minutes", "int", "str"),
    ),
    (
        "trp-minutes-zero",
        lambda: trp(minutes=0),
        ContractViolationError,
        E.CONTRACT_MINUTES_NON_POSITIVE,
        {},
    ),
    (
        "avail-source-blank",
        lambda: AvailabilityProposal(
            tenant_id="t1",
            resource_ref="a",
            period_start=D1,
            period_end=D5,
            available_minutes=60,
            source_system=" ",
        ),
        ContractViolationError,
        E.FIELD_BLANK,
        {"field": "source_system"},
    ),
    # --- contracts wire parsers ----------------------------------------------
    (
        "wire-captype-type",
        lambda: parse_wire_capacity_type(3),
        ContractViolationError,
        *wrong("capacity_type", "str", "int"),
    ),
    (
        "wire-captype-unknown",
        lambda: parse_wire_capacity_type("TURBO"),
        ContractViolationError,
        E.UNKNOWN_ENUM_VALUE,
        {"field": "capacity_type", "value": "TURBO", "expected": "CapacityType"},
    ),
    (
        "wire-date-type",
        lambda: parse_wire_date(20260801, "period_start"),
        ContractViolationError,
        *wrong("period_start", "str", "int"),
    ),
    (
        "wire-date-bad",
        lambda: parse_wire_date("yesterday", "period_end"),
        ContractViolationError,
        E.INVALID_WIRE_DATE,
        {"field": "period_end", "value": "yesterday"},
    ),
    (
        "wire-date-calendar-invalid",
        lambda: parse_wire_date("2026-13-01", "period_end"),
        ContractViolationError,
        E.INVALID_WIRE_DATE,
        {"field": "period_end", "value": "2026-13-01"},
    ),
    (
        "wire-int-bool",
        lambda: parse_wire_int(True, "minutes"),
        ContractViolationError,
        E.INVALID_WIRE_INT,
        {"field": "minutes", "value": True},
    ),
    (
        "wire-int-type",
        lambda: parse_wire_int(12.5, "minutes"),
        ContractViolationError,
        *wrong("minutes", "str", "float"),
    ),
    (
        "wire-int-bad",
        lambda: parse_wire_int("3O0", "minutes"),
        ContractViolationError,
        E.INVALID_WIRE_INT,
        {"field": "minutes", "value": "3O0"},
    ),
]


@pytest.mark.parametrize(
    "action,exc_cls,code,fields",
    [row[1:] for row in MATRIX],
    ids=[row[0] for row in MATRIX],
)
def test_guard_site_full_identity(action, exc_cls, code, fields):
    with pytest.raises(exc_cls) as excinfo:
        action()
    assert type(excinfo.value) is exc_cls
    assert excinfo.value.code == code
    assert excinfo.value.fields == fields


def test_happy_paths_still_construct():
    assert w().capacity_type is CapacityType.EXECUTION
    assert alloc().state is AllocationState.PROPOSED
    assert decl().declared_on == D1
    assert trp().minutes == 30
    assert parse_wire_capacity_type("SUPERVISORY") is CapacityType.SUPERVISORY
    assert parse_wire_date("2026-08-01", "period_start") == D1
    assert parse_wire_int("45", "minutes") == 45
    assert parse_wire_int(45, "minutes") == 45
