"""Capacity allocation state machine with state-dependent data invariants.

Review findings F01/F02 (V002) are closed here (ADR-007):

* Every construction path — including direct dataclass construction and
  ``dataclasses.replace`` — enforces state-dependent invariants between
  ``allocated_minutes``, ``consumed_minutes`` and ``state``, so the state
  machine cannot be bypassed by building an impossible object.
* A single allocation can never claim more minutes than its capacity window
  offers. Aggregate/cross-allocation capacity governance (multiple
  allocations against one window/pool) is a DECLARED, unimplemented model —
  see RTM DOM-006 — and is deliberately NOT claimed by this module.

Quantity-bearing states (``PARTIALLY_CONSUMED``, ``CONSUMED``, ``OVERRUN``)
are reachable only through :func:`consume_allocation`; ``transition`` covers
pure lifecycle moves whose data remains consistent.

Runtime type integrity (ADR-010, review findings F13/F14): every field —
including ``state`` — is validated for its runtime type on every construction
path, so malformed values like ``state="X"`` raise a controlled
``AllocationInvariantError`` instead of constructing. ``create``/``rehydrate``
factories make new-vs-reload intent explicit (F16).
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum

from cgwo_core.authz import AuthorizationPort
from cgwo_core.capacity import CapacityWindow
from cgwo_core.errors import (
    ALLOCATED_MINUTES_NON_POSITIVE,
    ALLOCATION_EXCEEDS_WINDOW,
    ALLOCATION_TENANT_MISMATCH,
    CONSUME_FROM_INVALID_STATE,
    CONSUME_NON_POSITIVE,
    CONSUMED_MINUTES_NEGATIVE,
    CONSUMED_MUST_EQUAL_ALLOCATED,
    CONSUMING_BOUND_VIOLATED,
    F_ALLOCATED_MINUTES,
    F_CONSUMED_MINUTES,
    F_MINUTES,
    F_PLAN_ITEM_REF,
    F_STATE,
    F_TARGET,
    F_TENANT_ID,
    F_WINDOW,
    FIELD_BLANK,
    OVERRUN_REQUIRES_EXCESS,
    PARTIAL_BOUND_VIOLATED,
    STATE_REQUIRES_ZERO_CONSUMPTION,
    TRANSITION_NOT_ALLOWED,
    DomainError,
    build,
)
from cgwo_core.plan_item import InvalidTransitionError
from cgwo_core.tenancy import TenantContext, assert_tenant_operation
from cgwo_core.validation import (
    require_enum,
    require_exact_instance,
    require_int,
    require_str,
)


class AllocationState(str, Enum):
    PROPOSED = "PROPOSED"
    RESERVED = "RESERVED"
    CONSUMING = "CONSUMING"
    PARTIALLY_CONSUMED = "PARTIALLY_CONSUMED"
    CONSUMED = "CONSUMED"
    RELEASED = "RELEASED"
    OVERRUN = "OVERRUN"


A = AllocationState

#: Lifecycle transitions whose data remains consistent (ADR-007).
#: CONSUMED and OVERRUN are reachable only via consume_allocation().
ALLOWED_TRANSITIONS: dict[AllocationState, frozenset[AllocationState]] = {
    A.PROPOSED: frozenset({A.RESERVED, A.RELEASED}),
    A.RESERVED: frozenset({A.CONSUMING, A.RELEASED}),
    A.CONSUMING: frozenset({A.PARTIALLY_CONSUMED, A.RELEASED}),
    A.PARTIALLY_CONSUMED: frozenset({A.CONSUMING, A.RELEASED}),
    A.CONSUMED: frozenset(),
    A.RELEASED: frozenset(),
    A.OVERRUN: frozenset({A.RELEASED}),
}

EVENT_BY_TARGET: dict[AllocationState, str] = {
    A.RESERVED: "CapacityReserved",
    A.OVERRUN: "CapacityOverrunDetected",
}

DEFAULT_EVENT = "CapacityAllocationChanged"
CONSUMPTION_EVENT = "TimeRecorded"

#: States from which recorded consumption is legal.
CONSUMABLE_STATES: frozenset[AllocationState] = frozenset(
    {A.RESERVED, A.CONSUMING, A.PARTIALLY_CONSUMED}
)


class AllocationInvariantError(DomainError):
    """Raised when an allocation violates a domain invariant."""


#: The state every genuinely new allocation starts in (ADR-010, F16).
INITIAL_STATE = AllocationState.PROPOSED


def _validate_allocation(
    tenant_id: object,
    window: object,
    plan_item_ref: object,
    allocated_minutes: object,
    consumed_minutes: object,
    state: object,
) -> None:
    checked_tenant = require_str(tenant_id, F_TENANT_ID, AllocationInvariantError)
    checked_window = require_exact_instance(
        window, CapacityWindow, F_WINDOW, AllocationInvariantError
    )
    checked_ref = require_str(plan_item_ref, F_PLAN_ITEM_REF, AllocationInvariantError)
    checked_allocated = require_int(
        allocated_minutes, F_ALLOCATED_MINUTES, AllocationInvariantError
    )
    checked_consumed = require_int(consumed_minutes, F_CONSUMED_MINUTES, AllocationInvariantError)
    checked_state = require_enum(state, AllocationState, F_STATE, AllocationInvariantError)
    if checked_tenant != checked_window.tenant_id:
        raise build(AllocationInvariantError, ALLOCATION_TENANT_MISMATCH)
    if not checked_ref.strip():
        raise build(AllocationInvariantError, FIELD_BLANK, field=F_PLAN_ITEM_REF)
    if checked_allocated <= 0:
        raise build(AllocationInvariantError, ALLOCATED_MINUTES_NON_POSITIVE)
    if checked_consumed < 0:
        raise build(AllocationInvariantError, CONSUMED_MINUTES_NEGATIVE)
    if checked_allocated > checked_window.available_minutes:
        raise build(AllocationInvariantError, ALLOCATION_EXCEEDS_WINDOW)
    # State-dependent invariants (ADR-007, review finding F01):
    if checked_state in (A.PROPOSED, A.RESERVED) and checked_consumed != 0:
        raise build(
            AllocationInvariantError,
            STATE_REQUIRES_ZERO_CONSUMPTION,
            state=checked_state.value,
        )
    if checked_state is A.CONSUMING and checked_consumed >= checked_allocated:
        raise build(AllocationInvariantError, CONSUMING_BOUND_VIOLATED)
    if checked_state is A.PARTIALLY_CONSUMED and not (0 < checked_consumed < checked_allocated):
        raise build(AllocationInvariantError, PARTIAL_BOUND_VIOLATED)
    if checked_state is A.CONSUMED and checked_consumed != checked_allocated:
        raise build(AllocationInvariantError, CONSUMED_MUST_EQUAL_ALLOCATED)
    if checked_state is A.OVERRUN and checked_consumed <= checked_allocated:
        raise build(AllocationInvariantError, OVERRUN_REQUIRES_EXCESS)
    # RELEASED carries its final consumption history unchanged (including an
    # over-consumed history when released from OVERRUN); only the base
    # invariants above constrain it.


@dataclass(frozen=True, slots=True)
class AllocationChange:
    """Typed domain-change record for one allocation transition (ADR-008)."""

    event_type: str
    tenant_id: str
    plan_item_ref: str
    resource_ref: str
    previous_state: AllocationState
    new_state: AllocationState
    allocated_minutes: int
    consumed_minutes_before: int
    consumed_minutes_after: int
    allocation: CapacityAllocation


def transition_allocation(
    allocation: CapacityAllocation,
    target: AllocationState,
    authz: AuthorizationPort,
    ctx: TenantContext,
) -> AllocationChange:
    """Protected operation (ADR-009/ADR-014): apply one guarded lifecycle
    transition, authorized via the supplied AuthorizationPort capability
    (policy enforcement only — ADR-015)."""
    assert_tenant_operation(authz, ctx, allocation.tenant_id)
    checked_target = require_enum(target, AllocationState, F_TARGET, InvalidTransitionError)
    if checked_target not in ALLOWED_TRANSITIONS[allocation.state]:
        raise build(
            InvalidTransitionError,
            TRANSITION_NOT_ALLOWED,
            source=allocation.state.value,
            target=checked_target.value,
        )
    moved = replace(allocation, state=checked_target)
    return AllocationChange(
        event_type=EVENT_BY_TARGET.get(checked_target, DEFAULT_EVENT),
        tenant_id=allocation.tenant_id,
        plan_item_ref=allocation.plan_item_ref,
        resource_ref=allocation.window.resource_ref,
        previous_state=allocation.state,
        new_state=checked_target,
        allocated_minutes=allocation.allocated_minutes,
        consumed_minutes_before=allocation.consumed_minutes,
        consumed_minutes_after=moved.consumed_minutes,
        allocation=moved,
    )


def consume_allocation(
    allocation: CapacityAllocation,
    minutes: int,
    authz: AuthorizationPort,
    ctx: TenantContext,
) -> AllocationChange:
    """Protected operation (ADR-014): record consumption; derives the state."""
    assert_tenant_operation(authz, ctx, allocation.tenant_id)
    if allocation.state not in CONSUMABLE_STATES:
        raise build(
            InvalidTransitionError,
            CONSUME_FROM_INVALID_STATE,
            state=allocation.state.value,
        )
    checked_minutes = require_int(minutes, F_MINUTES, AllocationInvariantError)
    if checked_minutes <= 0:
        raise build(AllocationInvariantError, CONSUME_NON_POSITIVE)
    total = allocation.consumed_minutes + checked_minutes
    if total > allocation.allocated_minutes:
        target = A.OVERRUN
    elif total == allocation.allocated_minutes:
        target = A.CONSUMED
    else:
        target = A.PARTIALLY_CONSUMED
    consumed = replace(allocation, consumed_minutes=total, state=target)
    return AllocationChange(
        event_type=EVENT_BY_TARGET.get(target, CONSUMPTION_EVENT),
        tenant_id=allocation.tenant_id,
        plan_item_ref=allocation.plan_item_ref,
        resource_ref=allocation.window.resource_ref,
        previous_state=allocation.state,
        new_state=target,
        allocated_minutes=allocation.allocated_minutes,
        consumed_minutes_before=allocation.consumed_minutes,
        consumed_minutes_after=total,
        allocation=consumed,
    )


@dataclass(frozen=True, slots=True)
class CapacityAllocation:
    """Reservation of part of a CapacityWindow for a Plan Item."""

    tenant_id: str
    window: CapacityWindow
    plan_item_ref: str
    allocated_minutes: int
    consumed_minutes: int = 0
    state: AllocationState = AllocationState.PROPOSED

    def __post_init__(self) -> None:
        _validate_allocation(
            self.tenant_id,
            self.window,
            self.plan_item_ref,
            self.allocated_minutes,
            self.consumed_minutes,
            self.state,
        )

    @classmethod
    def create(
        cls,
        tenant_id: str,
        window: CapacityWindow,
        plan_item_ref: str,
        allocated_minutes: int,
    ) -> CapacityAllocation:
        """Create a genuinely NEW allocation in the initial state (ADR-010)."""
        return cls(
            tenant_id=tenant_id,
            window=window,
            plan_item_ref=plan_item_ref,
            allocated_minutes=allocated_minutes,
            consumed_minutes=0,
            state=INITIAL_STATE,
        )

    @classmethod
    def rehydrate(
        cls,
        tenant_id: str,
        window: CapacityWindow,
        plan_item_ref: str,
        allocated_minutes: int,
        consumed_minutes: int,
        state: AllocationState,
    ) -> CapacityAllocation:
        """Reload a persisted allocation (trusted rehydration, ADR-010).

        Same code path as direct construction on purpose: every invariant —
        including runtime type validation — is enforced either way.
        """
        return cls(
            tenant_id=tenant_id,
            window=window,
            plan_item_ref=plan_item_ref,
            allocated_minutes=allocated_minutes,
            consumed_minutes=consumed_minutes,
            state=state,
        )

    def transition(
        self, target: AllocationState, authz: AuthorizationPort, ctx: TenantContext
    ) -> AllocationChange:
        return transition_allocation(self, target, authz, ctx)

    def consume(
        self, minutes: int, authz: AuthorizationPort, ctx: TenantContext
    ) -> AllocationChange:
        return consume_allocation(self, minutes, authz, ctx)
