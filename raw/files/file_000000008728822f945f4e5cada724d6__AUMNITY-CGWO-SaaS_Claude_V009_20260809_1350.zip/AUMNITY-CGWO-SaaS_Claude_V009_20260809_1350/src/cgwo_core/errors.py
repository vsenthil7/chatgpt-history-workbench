"""Structured domain errors: stable type + stable code + evolvable message.

ADR-011 (review finding F19): error *identity* (exception type and ``code``)
is the tested, mutation-anchored contract; the human-readable message comes
from the module-level registry below and may evolve without breaking tests.
Message templates live at module level deliberately: behaviour-affecting
logic stays inside functions where the mutation harness exercises it, while
prose is data.
"""

from __future__ import annotations


class DomainError(ValueError):
    """Base class for all CGWO domain and contract errors.

    ``code`` and the structured ``fields`` are stable, tested identity;
    the message is evolvable prose rendered from :data:`MESSAGES`.
    """

    def __init__(self, code: str, message: str, **fields: object) -> None:
        super().__init__(message)
        self.code = code
        self.fields = fields


# --- Stable error codes (contract) -------------------------------------------
WRONG_RUNTIME_TYPE = "WRONG_RUNTIME_TYPE"
FIELD_BLANK = "FIELD_BLANK"
ORGANISATION_ID_BLANK = "ORGANISATION_ID_BLANK"
CROSS_TENANT = "CROSS_TENANT"
NOT_ENTITLED = "NOT_ENTITLED"
PERIOD_ORDER = "PERIOD_ORDER"
AVAILABLE_MINUTES_NEGATIVE = "AVAILABLE_MINUTES_NEGATIVE"
DECLARATION_TENANT_MISMATCH = "DECLARATION_TENANT_MISMATCH"
DECLARATION_RESOURCE_MISMATCH = "DECLARATION_RESOURCE_MISMATCH"
TRANSITION_NOT_ALLOWED = "TRANSITION_NOT_ALLOWED"
CHANGE_REASON_REQUIRED = "CHANGE_REASON_REQUIRED"
ALLOCATION_TENANT_MISMATCH = "ALLOCATION_TENANT_MISMATCH"
ALLOCATED_MINUTES_NON_POSITIVE = "ALLOCATED_MINUTES_NON_POSITIVE"
CONSUMED_MINUTES_NEGATIVE = "CONSUMED_MINUTES_NEGATIVE"
ALLOCATION_EXCEEDS_WINDOW = "ALLOCATION_EXCEEDS_WINDOW"
STATE_REQUIRES_ZERO_CONSUMPTION = "STATE_REQUIRES_ZERO_CONSUMPTION"
CONSUMING_BOUND_VIOLATED = "CONSUMING_BOUND_VIOLATED"
PARTIAL_BOUND_VIOLATED = "PARTIAL_BOUND_VIOLATED"
CONSUMED_MUST_EQUAL_ALLOCATED = "CONSUMED_MUST_EQUAL_ALLOCATED"
OVERRUN_REQUIRES_EXCESS = "OVERRUN_REQUIRES_EXCESS"
CONSUME_FROM_INVALID_STATE = "CONSUME_FROM_INVALID_STATE"
CONSUME_NON_POSITIVE = "CONSUME_NON_POSITIVE"
CONTRACT_MINUTES_NON_POSITIVE = "CONTRACT_MINUTES_NON_POSITIVE"
UNKNOWN_ENUM_VALUE = "UNKNOWN_ENUM_VALUE"
INVALID_WIRE_DATE = "INVALID_WIRE_DATE"
INVALID_WIRE_INT = "INVALID_WIRE_INT"
INTEGER_OUT_OF_RANGE = "INTEGER_OUT_OF_RANGE"

# --- Message registry (prose; may evolve) -------------------------------------
MESSAGES: dict[str, str] = {
    WRONG_RUNTIME_TYPE: "{field} must be of exact type {expected}, got {actual}",
    FIELD_BLANK: "{field} must be non-blank",
    ORGANISATION_ID_BLANK: "organisation_id, when provided, must be non-blank",
    CROSS_TENANT: "tenant context does not match aggregate owner tenant",
    NOT_ENTITLED: "supplied authorization capability denied access to tenant {tenant_id}",
    PERIOD_ORDER: "period_end must not precede period_start",
    AVAILABLE_MINUTES_NEGATIVE: "available_minutes must be >= 0",
    DECLARATION_TENANT_MISMATCH: "declaration tenant must match window tenant",
    DECLARATION_RESOURCE_MISMATCH: "declaration resource must match window resource",
    TRANSITION_NOT_ALLOWED: "transition {source} -> {target} is not allowed",
    CHANGE_REASON_REQUIRED: "transition {source} -> {target} requires a change reason",
    ALLOCATION_TENANT_MISMATCH: "allocation tenant must match window tenant",
    ALLOCATED_MINUTES_NON_POSITIVE: "allocated_minutes must be > 0",
    CONSUMED_MINUTES_NEGATIVE: "consumed_minutes must be >= 0",
    ALLOCATION_EXCEEDS_WINDOW: (
        "allocated_minutes must not exceed the capacity window's available_minutes"
    ),
    STATE_REQUIRES_ZERO_CONSUMPTION: "state {state} requires consumed_minutes == 0",
    CONSUMING_BOUND_VIOLATED: "state CONSUMING requires consumed_minutes < allocated_minutes",
    PARTIAL_BOUND_VIOLATED: (
        "state PARTIALLY_CONSUMED requires 0 < consumed_minutes < allocated_minutes"
    ),
    CONSUMED_MUST_EQUAL_ALLOCATED: (
        "state CONSUMED requires consumed_minutes == allocated_minutes"
    ),
    OVERRUN_REQUIRES_EXCESS: "state OVERRUN requires consumed_minutes > allocated_minutes",
    CONSUME_FROM_INVALID_STATE: "cannot record consumption from state {state}",
    CONSUME_NON_POSITIVE: "consumed minutes must be > 0",
    CONTRACT_MINUTES_NON_POSITIVE: "minutes must be > 0",
    UNKNOWN_ENUM_VALUE: "{field} value {value!r} is not a valid {expected}",
    INVALID_WIRE_DATE: "{field} value {value!r} is not a valid ISO date",
    INVALID_WIRE_INT: "{field} value {value!r} is not a valid integer",
    INTEGER_OUT_OF_RANGE: "{field} exceeds the permitted wire integer range",
}


def build(exc_cls: type[DomainError], code: str, **fields: object) -> DomainError:
    """Construct a domain error with its registry message rendered."""
    return exc_cls(code, MESSAGES[code].format(**fields), **fields)


# --- Structured field/expected identifiers (diagnostic data, not logic) -------
# Module-level on purpose (ADR-011): behaviour lives in functions where the
# mutation harness exercises it; identifier spellings are data, asserted via
# DomainError.fields in the adversarial suite.
F_TENANT_ID = "tenant_id"
F_ORGANISATION_ID = "organisation_id"
F_CTX = "ctx"
F_OWNER_TENANT_ID = "owner_tenant_id"
F_RESOURCE_REF = "resource_ref"
F_PERIOD_START = "period_start"
F_PERIOD_END = "period_end"
F_AVAILABLE_MINUTES = "available_minutes"
F_CAPACITY_TYPE = "capacity_type"
F_WINDOW = "window"
F_DECLARED_ON = "declared_on"
F_WORK_OBJECT_REF = "work_object_ref"
F_STATE = "state"
F_TARGET = "target"
F_CHANGE_REASON = "change_reason"
F_PLAN_ITEM_REF = "plan_item_ref"
F_ALLOCATED_MINUTES = "allocated_minutes"
F_CONSUMED_MINUTES = "consumed_minutes"
F_MINUTES = "minutes"
F_NARRATIVE = "narrative"
F_SOURCE_SYSTEM = "source_system"
EXPECTED_STR = "str"
EXPECTED_INT = "int"
EXPECTED_DATE = "datetime.date"  # exact: datetime.datetime is deliberately excluded (ADR-012)
EXPECTED_TENANT_CONTEXT = "TenantContext"
EXPECTED_CAPACITY_WINDOW = "CapacityWindow"
EXPECTED_ENTITLEMENTS = "set or frozenset"
