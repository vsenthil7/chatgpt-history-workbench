# AT-Life Operating System (AT-LOS) - V030

**Release:** `AT-LifeOperatingSystem_CanonicalEventIdentityAndIngestionFreeze_Claude_V030_20260809_1630`
**Prepared by:** Claude · **09-Aug-2026 16:30 BST** · Corrective only — no feature tranche, **no `at-evidence` code**. **Proposed ingestion FREEZE.**

Your V029 verdict named the remaining correction exactly: *make canonical identity unique within the imported source, reconcile duplicate textual representations, and settle permanent Event ID width.* V030 does those three things and the three governance findings, and nothing else. Every finding was reproduced byte-for-byte on pristine V029 before any code was touched: the duplicate-uuid collision, the fallback-versus-real `conversation-0` collision in all three providers, and both silent `"BLOCK"` disappearances — all at zero issues, exactly as you reported.

## The identity fix is structural (F01)

Conversation identity is now resolved by `parse_export`, because uniqueness is a **source-level** property no extractor can see. Provider identity maps into `conversation:id:…`, synthetic fallback into `conversation:index:…` — disjoint namespaces, so a provider id spelling `conversation-0` **cannot** collide with fallback conversation 0; the collision is unspellable, not unlikely. A repeated provider id is a source inconsistency: reported as a located diagnostic naming both conversation indexes, with each occurrence keeping a distinct deterministic `#occurrence:<k>` identity. On top, source-wide locator/Event-id uniqueness is an **enforced invariant at Event emission** — the namespaces make a clash unconstructible from provider data (the proof is pinned by test), and the runtime guard is the class defence for any future provider or refactor. ADR-029's "collision-free final fallback" sentence is retracted in an amendment stamp; three mutants re-create your F01 reproductions and die.

## Nothing textual is silently chosen (F02)

`text` and `content` are dual representations, and their relationship is provider data. The normalisation is explicit (blocks joined with `\n`, both sides stripped): equal → consumed once, no noise; disagreeing — including your `text=""` case → top-level text stays canonical, the content-derived text is preserved in `Event.meta["content_text"]`, and the disagreement is a located diagnostic. Tested for equal, unequal, empty-vs-non-empty, edge-whitespace (not a disagreement), interior-whitespace (a disagreement), multi-block, structured-only and unicode round-trip; the "top-level text wins unconditionally" mutant dies.

## Identity width is settled (F03)

**32 hex / 128 bits platform-wide** — `event_id`, and because the class audit found the same 16-hex truncation in `registration_id`, `occurrence_id` and decision ids, all four, plus the lossy-locator digest. `identity.toml` declares `digest_chars = 32` and the identity guard recomputes every derived id. Every "lossless" claim about hashed forms is corrected to collision-resistant; only the clean-id passthrough is lossless. The migration note you asked for: **no migration exists to write — no downstream record holds these ids yet.** That is precisely why this is the moment.

## Governance (F04, F05, F06)

`release_facts.py` now derives headline test **and coverage** figures deterministically; FACTS blocks publish "Deterministic tests collected/passed/skipped" and a separately-labelled environment-dependent integration row, the sentinel patterns track the renamed rows (a `-1` in the new row is still caught), and the generator was run to a verified fixed point. The hostile suite gained the interaction layers you specified — Layer B field-pair consistency, Layer C collection invariants (22 new tests) — with Layer D property/fuzz remaining a named gap, per your instruction not to grow the scalar list. RTM-130 is reworded to match its guard: behavioural presence tests are the normative proof, the syntax scan is the cheap secondary check. The strict-JSON duplicate-key edge is **recorded, non-blocking**, in ADR-030, metadata and the Standard.

## Gates (deterministic, this build; independent rerun required)

**511 passed** / 1 by-design skip of **512 deterministic tests** · 100% on **1427 statements** / 434 branches · **47/47 mutants killed** (5 new: F01a/F01b/F01c/F02/F03) · `ruff` and `mypy --strict` clean via exact CI commands · RTM **138 rules: 134 + 1 + 3** (RTM-134..138 added) · blocking package audit clean. Environment-dependent: 2 integration tests collected; this build ran them (2 passed); an offline environment legitimately skips — never aggregated.

## What changed for identity consumers

Locators for provider-identified conversations changed from `conversation:X#…` to `conversation:id:X#…`, and **all** Event ids changed (width). Acceptable only now, pre-evidence — the same reasoning as ADR-006's "settle identity before Sprint 2", recorded in ADR-030.

## Next

Your independent V030 review → if it passes: **FREEZE INGESTION CONTRACT → start `at-evidence` immediately** (AT-012). No V031 for parser polish without a demonstrated data-loss, identity or raw-exception blocker. `at-consent` still needs **DQ-012 and DQ-013**. **AT-056 remains Not started.**
