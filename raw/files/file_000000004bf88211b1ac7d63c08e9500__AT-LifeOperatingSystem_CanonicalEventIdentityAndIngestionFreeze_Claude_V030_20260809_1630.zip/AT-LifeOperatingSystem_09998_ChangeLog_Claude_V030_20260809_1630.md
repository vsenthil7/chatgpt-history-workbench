# AT-LOS V030 Change Log

**Release type:** canonical Event identity and ingestion freeze. ADR-030, amending ADR-006, ADR-014 and ADR-029. Corrective only, responding to the V029 independent deep review (F01–F06). No feature tranche, no `at-evidence` code. Proposed as the last corrective ingestion release.

## at-ingest-llm-export / at-ingest-core

**Identity is unique within its source (F01).** Conversation identity resolved source-level in `parse_export`: provider identity → `conversation:id:…`, synthetic fallback → `conversation:index:…` — disjoint namespaces; a provider id spelling `conversation-0` cannot collide with fallback conversation 0. A repeated provider id keeps a distinct deterministic `#occurrence:<k>` identity **and** raises a located diagnostic naming both conversation indexes. Source-wide locator/Event-id uniqueness is enforced at Event emission; the namespaces make a clash unspellable from provider data (pinned by test) and the guard is the class defence. ADR-029's "collision-free final fallback" claim retracted by amendment stamp.

**Dual representations reconciled (F02).** Explicit normalisation (content blocks joined with `\n`, both sides stripped). Equal → consumed once. Disagreeing — including empty-vs-non-empty → top-level `text` canonical, content text preserved in `Event.meta["content_text"]`, located diagnostic. Eight-case test coverage plus unicode meta round-trip.

**Identity width settled (F03).** 32 hex / 128 bits platform-wide: `event_id`, `registration_id`, `occurrence_id`, decision ids, lossy-locator digest — the review named one site; the class audit widened four. `identity.toml` `digest_chars = 32`, recomputed by the identity guard. "Lossless" corrected to collision-resistant everywhere; only the clean-id passthrough is lossless. Migration note: none to write — no downstream record holds these ids.

## Governance and tooling

**Deterministic separation (F04).** `release_facts.py` derives headline test and coverage figures from `-m "not integration"`; FACTS rows labelled "Deterministic …" with a separate environment-dependent integration row; sentinel patterns track the renamed rows; generator verified to a fixed point (second run: zero changes).

**Interaction layers (F05).** `test_canonical_identity_and_fidelity.py` (22 tests): Layer B field-pair consistency (dual representations; `sender`+`role` both valid disagreeing; `created_at`+`timestamp` both valid disagreeing), Layer C collection invariants (duplicate ids ×3 providers, fallback spellings ×3, occurrence determinism, 12-id adversarial sweep ×3 asserting no shared locator/id and no vanished unit). Layer D remains a named gap.

**RTM wording (F06).** RTM-130 reworded — behavioural presence tests normative, syntax guard secondary; guard docstring rewritten to match. RTM-133 note re-scoped to single-field hostility.

**Recorded, non-blocking:** strict-JSON duplicate-key gap (`json.loads` keeps the last value) — ADR-030, metadata, Standard.

## RTM, tests, mutation

RTM-134 (disjoint namespaces), RTM-135 (occurrence disambiguation + diagnostic), RTM-136 (enforced source-wide uniqueness), RTM-137 (dual-representation contract), RTM-138 (128-bit canonical digests). **138 rules: 134 + 1 + 3.** 22 new tests; **511 of 512 deterministic passing** (1 by-design skip), 100% on **1427 statements / 434 branches**; **47/47 mutants** including five re-creating V029 F01a/F01b/F01c/F02/F03; `ruff` and `mypy --strict` clean via exact CI commands. Integration (environment-dependent): 2 collected, 2 passed in this build environment.

## Documents and workbooks

Standard: V029's "lossless"/"collision-free" wording corrected in place with the correction visible; six V030 rules and the recorded strict-JSON gap added. Project Memory: D-117..D-122; V030 version history; V029 CURRENT COUNT demoted to historical; V030 CURRENT COUNT from `release_facts.json` with deterministic figures and a separated environment-dependent note. Test Strategy: derived sheets regenerated (138 RTM, 47 mutants, V030 facts); new `23_V030ReviewDisposition` with the full F01–F06 + recorded-gap table.

## Decisions

D-117 source-level identity, disjoint namespaces, enforced uniqueness · D-118 dual representations reconciled, never silently chosen · D-119 128-bit canonical identity platform-wide · D-120 deterministic and environment-dependent figures never share a heading · D-121 hostile layers named; a claim names its layer · D-122 a rule's wording never exceeds its test

## Open

DQ-004, DQ-012, DQ-013, DQ-014, **DQ-016 (RTM-120 NOT ENFORCED — no external publication)** · Layer D arbitrary-JSON property coverage and real LLM export corpus: named gaps · strict-JSON duplicate keys: recorded, non-blocking · **ingestion FREEZE on independent V030 pass → `at-evidence` (AT-012) immediately** · **AT-056 Not started**.
