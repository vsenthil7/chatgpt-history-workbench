"""Authorization-policy enforcement tests (ADR-014 as amended, ADR-015).

The authz boundary is authorization-POLICY enforcement: the domain core
consults the supplied capability and honours deny/allow, but does not
establish that the capability is genuine or authenticated (that is the
service-layer trust root, G08 RED half). These tests exercise the port, the
reference context and the assertion, including the wrong-type and
blank-principal guards. The trust-boundary limits themselves (F34/F37) are
documented executably in tests/test_trust_boundary.py.
"""

import pytest

from cgwo_core.authz import (
    AuthorizationError,
    AuthorizationPort,
    StaticAuthorizationContext,
    assert_authorized,
)
from cgwo_core.errors import (
    FIELD_BLANK,
    NOT_ENTITLED,
    WRONG_RUNTIME_TYPE,
    DomainError,
)


def ctx(*tenants):
    return StaticAuthorizationContext("principal-1", frozenset(tenants))


def test_principal_is_exposed():
    assert ctx("t1").principal == "principal-1"


def test_is_entitled_membership():
    c = ctx("t1", "t2")
    assert c.is_entitled("t1") is True
    assert c.is_entitled("t2") is True
    assert c.is_entitled("t3") is False


def test_static_context_satisfies_the_port_protocol():
    assert isinstance(ctx("t1"), AuthorizationPort)


def test_assert_authorized_allows_entitled_tenant():
    assert_authorized(ctx("t1"), "t1")  # no raise


def test_assert_authorized_denies_unentitled_tenant():
    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(ctx("t1"), "t2")
    assert isinstance(excinfo.value, DomainError)
    assert excinfo.value.code == NOT_ENTITLED
    assert excinfo.value.fields == {"tenant_id": "t2"}


def test_assert_authorized_rejects_non_port_authz():
    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(object(), "t1")  # type: ignore[arg-type]
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    assert excinfo.value.fields == {
        "field": "authz",
        "expected": "AuthorizationPort",
        "actual": "object",
    }


def test_assert_authorized_rejects_non_str_tenant():
    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(ctx("t1"), 5)  # type: ignore[arg-type]
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    assert excinfo.value.fields == {
        "field": "tenant_id",
        "expected": "str",
        "actual": "int",
    }


@pytest.mark.parametrize("bad", ["", "   "])
def test_blank_principal_rejected(bad):
    with pytest.raises(AuthorizationError) as excinfo:
        StaticAuthorizationContext(bad, frozenset({"t1"}))
    assert excinfo.value.code == FIELD_BLANK
    assert excinfo.value.fields == {"field": "principal"}


def test_non_str_principal_rejected():
    with pytest.raises(AuthorizationError) as excinfo:
        StaticAuthorizationContext(5, frozenset({"t1"}))  # type: ignore[arg-type]
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    assert excinfo.value.fields == {
        "field": "principal",
        "expected": "str",
        "actual": "int",
    }


def test_non_str_entitlement_member_rejected():
    with pytest.raises(AuthorizationError) as excinfo:
        StaticAuthorizationContext("p", {5})  # type: ignore[arg-type]
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    assert excinfo.value.fields == {
        "field": "entitlement",
        "expected": "str",
        "actual": "int",
    }


def test_entitlements_accept_set_or_frozenset():
    assert StaticAuthorizationContext("p", {"t1"}).is_entitled("t1")
    assert StaticAuthorizationContext("p", frozenset({"t1"})).is_entitled("t1")


def test_is_entitled_rejects_non_str_query():
    with pytest.raises(AuthorizationError) as excinfo:
        ctx("t1").is_entitled(5)  # type: ignore[arg-type]
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    assert excinfo.value.fields == {
        "field": "tenant_id",
        "expected": "str",
        "actual": "int",
    }


class DuckPort:
    """A structural AuthorizationPort implementation (protocol, not subclass)."""

    principal = "duck"

    def is_entitled(self, tenant_id: str) -> bool:
        return tenant_id == "allowed"


def test_duck_typed_port_is_accepted():
    assert_authorized(DuckPort(), "allowed")
    with pytest.raises(AuthorizationError):
        assert_authorized(DuckPort(), "denied")
