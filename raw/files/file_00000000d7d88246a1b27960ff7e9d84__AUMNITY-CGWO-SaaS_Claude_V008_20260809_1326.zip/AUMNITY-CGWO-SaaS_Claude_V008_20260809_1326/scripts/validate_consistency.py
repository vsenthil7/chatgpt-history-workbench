#!/usr/bin/env python3
"""Machine-detectable contradiction checks for the CGWO repository (DOC-001, ADR-004).

Checks: required files; ADR status headers; canonical-scope single source of truth;
superseded/tenant-specific vocabulary placement; manifest hash integrity; evidence
presence and gate-status cross-reference.
Exit code 0 = PASS, 1 = violations found.
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

REQUIRED = [
    "00-control/PROJECT-START.md",
    "00-control/READING-MAP.md",
    "00-control/RELEASE-NOTES-V002.md",
    "00-control/RELEASE-IDENTITY.json",
    "CLAUDE.md",
    "01-product/CANONICAL-SCOPE.md",
    "01-product/PRODUCT-BOUNDARY-AND-SAAS.md",
    "02-architecture/MODULARITY-AND-REUSE.md",
    "02-architecture/PLATFORM-PRIMITIVES-CONTRACT.md",
    "02-architecture/INTEGRATION-BOUNDARIES.md",
    "03-engineering/ENGINEERING-OPERATING-SYSTEM.md",
    "04-testing/TESTING-STRATEGY.md",
    "05-quality/QUALITY-GATES.md",
    "05-quality/GATE-STATUS-V002.md",
    "06-traceability/RTM.md",
    "07-planning/FIRST-BUILD-BACKLOG.md",
    "08-ai/CHATGPT-REVIEW-HANDOFF.md",
    "08-ai/CLAUDE-V002-HANDOFF.md",
    "09-governance/VERSIONING-AND-PACKAGING.md",
    "evidence/test-summary.json",
]
for rel in REQUIRED:
    if not (ROOT / rel).is_file():
        errors.append(f"missing required file: {rel}")

# --- ADR status headers -------------------------------------------------------
ADR_DIR = ROOT / "11-decisions"
adr_files = sorted(ADR_DIR.glob("ADR-*.md")) if ADR_DIR.is_dir() else []
if not adr_files:
    errors.append("no ADR files found in 11-decisions/")
STATUS_RE = re.compile(r"^Status:\s*(ACCEPTED|PROPOSED|SUPERSEDED|REJECTED)", re.MULTILINE)
for adr in adr_files:
    if not STATUS_RE.search(adr.read_text(encoding="utf-8")):
        errors.append(f"{adr.relative_to(ROOT)}: missing/invalid 'Status:' header")

# --- Canonical scope: defined once, referenced elsewhere ----------------------
DEFINING = Path("01-product/CANONICAL-SCOPE.md")
REFERENCING = [
    "00-control/PROJECT-START.md",
    "01-product/PRODUCT-BOUNDARY-AND-SAAS.md",
    "02-architecture/MODULARITY-AND-REUSE.md",
]
scope_text = (ROOT / DEFINING).read_text(encoding="utf-8") if (ROOT / DEFINING).is_file() else ""
for scope_id in ("CGWO-SCOPE-1", "CGWO-NOTOWNED-1"):
    if f"## {scope_id}" not in scope_text:
        errors.append(f"{DEFINING}: canonical id {scope_id} not defined")
    for rel in REFERENCING:
        f = ROOT / rel
        if (
            f.is_file()
            and scope_id == "CGWO-SCOPE-1"
            and scope_id not in f.read_text(encoding="utf-8")
        ):
            errors.append(f"{rel}: does not reference {scope_id}")

# --- Vocabulary placement (ADR-002, tenant neutrality) ------------------------
SELF = Path(__file__).resolve()
# Enforcement points necessarily name the tokens they forbid.
ENFORCEMENT_FILES = {
    "scripts/validate_consistency.py",
    "tests/test_architecture_guard.py",
}
EXEMPT_PREFIXES = ("10-baseline/", "11-decisions/", "evidence/provenance/")
SUPERSEDED = [re.compile(p) for p in (r"\bTEE\b", r"\bfounder\b", r"body/mind")]
PILOT = re.compile(r"\bIPBS\b")
PILOT_DOC_ALLOWLIST = {
    "00-control/PROJECT-START.md",  # names IPBS as tenant/pilot, per SaaS rule
    "00-control/RELEASE-NOTES-V002.md",
    "00-control/RELEASE-NOTES-V003.md",
    "00-control/RELEASE-NOTES-V004.md",
    "00-control/RELEASE-NOTES-V005.md",
    "00-control/RELEASE-NOTES-V006.md",
    "00-control/RELEASE-NOTES-V007.md",
    "00-control/RELEASE-NOTES-V008.md",
    "01-product/CANONICAL-SCOPE.md",  # states the exclusion itself
    "01-product/PRODUCT-BOUNDARY-AND-SAAS.md",
    "02-architecture/INTEGRATION-BOUNDARIES.md",
    "07-planning/FIRST-BUILD-BACKLOG.md",
    "08-ai/CLAUDE-V002-HANDOFF.md",
    "08-ai/CLAUDE-V003-HANDOFF.md",
    "08-ai/CLAUDE-V004-HANDOFF.md",
    "08-ai/CLAUDE-V005-HANDOFF.md",
    "08-ai/CLAUDE-V006-HANDOFF.md",
    "08-ai/CLAUDE-V007-HANDOFF.md",
    "08-ai/CLAUDE-V008-HANDOFF.md",
    "CLAUDE.md",
}
for path in sorted(ROOT.rglob("*")):
    if not path.is_file() or path.resolve() == SELF:
        continue
    rel = path.relative_to(ROOT).as_posix()
    if (
        rel in ENFORCEMENT_FILES
        or rel.startswith(EXEMPT_PREFIXES)
        or rel.startswith(("mutants/", "."))
        or "__pycache__" in rel
    ):
        continue
    if path.suffix not in {".md", ".py", ".json", ".ini", ".cfg", ".txt"}:
        continue
    text = path.read_text(encoding="utf-8", errors="ignore")
    in_code = rel.startswith(("src/", "tests/"))
    for rx in SUPERSEDED:
        if rx.search(text):
            errors.append(
                f"{rel}: superseded vocabulary '{rx.pattern}' outside baseline/ADRs (ADR-002)"
            )
    if PILOT.search(text) and (
        in_code or (not rel.startswith(("src/", "tests/")) and rel not in PILOT_DOC_ALLOWLIST)
    ):
        errors.append(f"{rel}: pilot-tenant name outside allowlisted pilot/evidence docs")

# --- Manifest hash integrity --------------------------------------------------
if "--skip-manifest" not in sys.argv:
    mf = ROOT / "PACKAGE-MANIFEST.json"
    if mf.is_file():
        manifest = json.loads(mf.read_text(encoding="utf-8"))
        for entry in manifest.get("files", []):
            p = ROOT / entry["path"]
            if not p.is_file():
                errors.append(f"manifest lists missing file: {entry['path']}")
            elif hashlib.sha256(p.read_bytes()).hexdigest() != entry["sha256"]:
                errors.append(f"manifest hash mismatch: {entry['path']}")
    else:
        errors.append("PACKAGE-MANIFEST.json missing")

# --- Evidence and gate-status cross-checks ------------------------------------
summary_path = ROOT / "evidence/test-summary.json"
if summary_path.is_file():
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    if summary.get("tests_passed", 0) <= 0 or summary.get("tests_failed", 1) != 0:
        errors.append("evidence/test-summary.json does not record a fully passing suite")
    for key in ("coverage_line_percent", "coverage_branch_percent"):
        if summary.get(key) != 100.0:
            errors.append(f"evidence: {key} is not 100 (G04)")
# --- Stale-version rule (V004 review, F26): current canonical docs must not
# embed "as of V00N" implementation-status references; history files may.
STALE_VERSION_RE = re.compile(r"as of V\d+")
CANONICAL_DOC_DIRS = ("01-product/", "02-architecture/")
CANONICAL_DOC_FILES = {"06-traceability/RTM.md", "00-control/READING-MAP.md"}
for path in sorted(ROOT.rglob("*.md")):
    rel = path.relative_to(ROOT).as_posix()
    is_canonical = rel.startswith(CANONICAL_DOC_DIRS) or rel in CANONICAL_DOC_FILES
    if is_canonical and STALE_VERSION_RE.search(path.read_text(encoding="utf-8")):
        errors.append(
            f"{rel}: stale 'as of V00N' status reference in a current canonical doc (F26); point at an RTM row instead"
        )

# --- Overclaim heuristic (V003 review): strong bypass-immunity claims must be
# backed by the adversarial construction suite actually attacking raw values.
OVERCLAIM_PHRASES = ("every construction path", "cannot be bypassed")
rtm_text = (
    (ROOT / "06-traceability/RTM.md").read_text(encoding="utf-8")
    if (ROOT / "06-traceability/RTM.md").is_file()
    else ""
)
if any(phrase in rtm_text for phrase in OVERCLAIM_PHRASES):
    adversarial = ROOT / "tests/test_adversarial_construction.py"
    if not adversarial.is_file():
        errors.append(
            "RTM claims construction-path immunity but tests/test_adversarial_construction.py is missing"
        )
    else:
        attack_text = adversarial.read_text(encoding="utf-8")
        if 'state="X"' not in attack_text or '"EXECUTION"' not in attack_text:
            errors.append(
                "adversarial suite no longer contains the raw-value attack payloads backing the RTM immunity claim"
            )

# --- Canonical release identity (V007 review, F36) ----------------------------
# ONE machine-readable source of truth (00-control/RELEASE-IDENTITY.json) defines
# the release series. Every other representation is DERIVED and must MATCH it.
# Release identity is never inferred from the artefacts being checked (the V007
# rule used max(RELEASE-NOTES-V*.md), so a stray higher-numbered file became the
# apparent authority — the exact spoof the reviewer asked us to close).
identity_path = ROOT / "00-control/RELEASE-IDENTITY.json"
series: str | None = None
if not identity_path.is_file():
    errors.append("missing canonical release identity: 00-control/RELEASE-IDENTITY.json (F36)")
else:
    try:
        identity = json.loads(identity_path.read_text(encoding="utf-8"))
        series = identity["series"]
        core_version = identity["core_version"]
    except (json.JSONDecodeError, KeyError) as exc:
        errors.append(f"RELEASE-IDENTITY.json is malformed (F36): {exc}")
        series = None

if series is not None:
    if not re.fullmatch(r"V\d+", series):
        errors.append(f"RELEASE-IDENTITY.json series '{series}' is not of the form V<n> (F36)")

    # 1. The canonical release note for THIS series must exist, and no
    #    release-notes file may claim a HIGHER series than the canonical one
    #    (that is the stray-future-file spoof).
    note_versions = []
    for note in sorted((ROOT / "00-control").glob("RELEASE-NOTES-V*.md")):
        m = re.search(r"V(\d+)", note.name)
        if m:
            note_versions.append(int(m.group(1)))
    canonical_n = int(series[1:])
    if canonical_n not in note_versions:
        errors.append(
            f"no RELEASE-NOTES for canonical series {series} (F36); identity and notes disagree"
        )
    higher = [f"V{n}" for n in note_versions if n > canonical_n]
    if higher:
        errors.append(
            f"release-notes {higher} are newer than the canonical series {series} (F36); "
            f"release identity must not be spoofed by a stray/future release-notes file"
        )

    # 2. The manifest 'release' string must embed the canonical series.
    mf_path = ROOT / "PACKAGE-MANIFEST.json"
    if mf_path.is_file():
        try:
            release_str = json.loads(mf_path.read_text(encoding="utf-8")).get("release", "")
        except json.JSONDecodeError:
            release_str = ""
        if f"_{series}_" not in release_str and not release_str.endswith(f"_{series}"):
            errors.append(
                f"manifest release '{release_str}' does not match canonical series {series} (F36)"
            )

    # 3. The gate status, current handoff and current release note for the
    #    canonical series must all exist.
    for derived in (
        f"05-quality/GATE-STATUS-{series}.md",
        f"08-ai/CLAUDE-{series}-HANDOFF.md",
        f"00-control/RELEASE-NOTES-{series}.md",
    ):
        if not (ROOT / derived).is_file():
            errors.append(f"canonical series {series} artefact missing: {derived} (F36)")

    # 4. pyproject version must equal the canonical core_version.
    pyproject_path = ROOT / "pyproject.toml"
    if pyproject_path.is_file():
        pv = re.search(r'(?m)^version\s*=\s*"([^"]+)"', pyproject_path.read_text(encoding="utf-8"))
        if pv and pv.group(1) != core_version:
            errors.append(
                f"pyproject version '{pv.group(1)}' != canonical core_version "
                f"'{core_version}' (F36)"
            )

    # 5. Current-cycle rule (F33, now anchored to canonical identity): the RTM
    #    AI-001 row must reference the CANONICAL series' handoff.
    rtm_path = ROOT / "06-traceability/RTM.md"
    if rtm_path.is_file():
        ai_rows = [
            line
            for line in rtm_path.read_text(encoding="utf-8").splitlines()
            if line.startswith("| AI-001 ")
        ]
        expected_handoff = f"CLAUDE-{series}-HANDOFF.md"
        if not ai_rows:
            errors.append("RTM has no AI-001 row for the current-cycle check (F33)")
        elif expected_handoff not in ai_rows[0]:
            errors.append(
                f"RTM AI-001 does not reference the canonical current-cycle handoff "
                f"{expected_handoff} (F33/F36)"
            )

if series is not None:
    gate_status = ROOT / f"05-quality/GATE-STATUS-{series}.md"
    if gate_status.is_file() and "evidence/test-summary.json" not in gate_status.read_text(
        encoding="utf-8"
    ):
        errors.append(
            f"GATE-STATUS-{series}.md must reference evidence/test-summary.json, not hand-typed counts"
        )

# --- Retired-overclaim phrase rule (V007 review, F34) -------------------------
# The domain core enforces authorization POLICY, not authenticated authority.
# Phrases that claim the domain core owns an authenticated security decision, or
# that a supplied object cannot be forged, are retired from CURRENT canonical
# docs and current code. History (baseline/ADR bodies/old handoffs/old gates)
# may quote them; the machine rule keeps them out of the live surface.
RETIRED_PHRASES = (
    "no mutated or lying object can forge",
    "authenticated entitlement set",
    "the real security decision",
    "domain-core AUTHORIZATION check",
)
OVERCLAIM_EXEMPT_PREFIXES = (
    "10-baseline/",
    "11-decisions/",  # ADR bodies quote the retired wording while correcting it
    "evidence/",
    "00-control/RELEASE-NOTES-",  # release notes are historical records
)
OVERCLAIM_EXEMPT_FILES = {
    "scripts/validate_consistency.py",  # this rule names the phrases it forbids
}
# Older-version gate statuses and handoffs are historical; only the CURRENT
# series' gate/handoff are held to the retired-phrase rule.
for path in sorted(ROOT.rglob("*.md")):
    rel = path.relative_to(ROOT).as_posix()
    if rel.startswith(OVERCLAIM_EXEMPT_PREFIXES) or rel in OVERCLAIM_EXEMPT_FILES:
        continue
    # Skip superseded-version gate/handoff history (keep only current series).
    m = re.search(r"(?:GATE-STATUS|CLAUDE)-V(\d+)", path.name)
    if m and series is not None and int(m.group(1)) != int(series[1:]):
        continue
    lowered = path.read_text(encoding="utf-8", errors="ignore").lower()
    for phrase in RETIRED_PHRASES:
        if phrase.lower() in lowered:
            errors.append(
                f"{rel}: retired overclaim phrase '{phrase}' in a current doc (F34); "
                f"the domain core enforces authorization POLICY, not authenticated authority"
            )
for src_path in sorted((ROOT / "src").rglob("*.py")):
    rel = src_path.relative_to(ROOT).as_posix()
    lowered = src_path.read_text(encoding="utf-8", errors="ignore").lower()
    for phrase in RETIRED_PHRASES:
        if phrase.lower() in lowered:
            errors.append(f"{rel}: retired overclaim phrase '{phrase}' in current code (F34)")

# --- ADR/gate/handoff contradiction rule (V007 review, F35) -------------------
# An ACCEPTED ADR is authoritative architecture and must not contradict the
# release it ships in. ADR-014 shipped two contradictions (a "consistency tag"
# it never built; a GREEN authorization claim its own handoff/gate disowned).
# The fix was Amendment A1; this rule ensures the contradiction cannot silently
# reappear: if an ACCEPTED ADR still asserts the withdrawn mechanisms, it must
# carry an amendment/superseding note that resolves them.
adr014 = ROOT / "11-decisions/ADR-014-authorization-trust-boundary.md"
if adr014.is_file():
    adr_text = adr014.read_text(encoding="utf-8")
    handoff7 = ROOT / "08-ai/CLAUDE-V007-HANDOFF.md"
    handoff_says_not_shipped = handoff7.is_file() and "NOT shipped" in handoff7.read_text(
        encoding="utf-8"
    )
    asserts_tag = "private consistency tag" in adr_text
    has_amendment = "Amendment A1" in adr_text
    if asserts_tag and handoff_says_not_shipped and not has_amendment:
        errors.append(
            "ADR-014 asserts a 'private consistency tag' the handoff says was NOT shipped, "
            "with no amendment resolving it (F35): an ACCEPTED ADR must match the release"
        )
    # The integrity tag must not actually exist in code while being called dead.
    if "consistency_tag" in (ROOT / "src/cgwo_core/tenancy.py").read_text(encoding="utf-8"):
        errors.append(
            "tenancy.py contains a consistency_tag the architecture says is not shipped (F35)"
        )

if errors:
    print("CONSISTENCY: FAIL")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("CONSISTENCY: PASS")
