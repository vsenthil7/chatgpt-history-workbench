// Each conformance check is tested twice: against an implementation that satisfies the invariant, and
// against one shaped like the defect it exists to catch. A check that cannot go red is decoration.
import {
  conformsDeletion, conformsLedgerCap, conformsIdentity, conformsWriteGate,
  conformsBackoff, conformsAsyncRoutes, conformsTenancy, summarise,
  MemoryStore, appendCapped, purgeTenant, Namespace
} from '../src';

const NS: Namespace[] = [
  { prefix: 'acct:', scope: 'tenant', what: 'account' },
  { prefix: 'records:', scope: 'installation', what: 'records' }
];

describe('DC-01 deletion conformance', () => {
  const harness = (purgeAll: boolean) => {
    const store = new MemoryStore();
    return {
      seed: (t: string) => { store.set(`acct:${t}`, 1); store.set('records:r1', 2); },
      purge: (t: string) => purgeAll ? purgeTenant(store, NS, t) : store.delete(`acct:${t}`),
      remainingKeys: () => store.keys()
    };
  };

  it('passes a purge that covers every namespace', () => {
    expect(conformsDeletion(harness(true)).pass).toBe(true);
  });

  it('fails the shape the defect took in eight products', () => {
    const f = conformsDeletion(harness(false));
    expect(f.pass).toBe(false);
    expect(f.detail).toMatch(/survived the published deletion: records:r1/);
  });

  it('respects an explicit allowlist for deletion-proof rows', () => {
    const store = new MemoryStore();
    const h = {
      seed: (t: string) => { store.set(`acct:${t}`, 1); store.set('proof:erased', true); },
      purge: (t: string) => store.delete(`acct:${t}`),
      remainingKeys: () => store.keys(),
      allowed: ['proof:erased']
    };
    expect(conformsDeletion(h).pass).toBe(true);
  });
});

describe('DC-02 ledger conformance', () => {
  it('passes a capped ledger and fails an uncapped one', () => {
    const capped = new MemoryStore();
    expect(conformsLedgerCap({ append: n => { for (let i = 0; i < n; i++) appendCapped(capped, 'l', [i], 50); }, size: () => capped.get<number[]>('l')!.length, cap: 50 }).pass).toBe(true);
    const raw: number[] = [];
    const f = conformsLedgerCap({ append: n => { for (let i = 0; i < n; i++) raw.push(i); }, size: () => raw.length, cap: 50 });
    expect(f.pass).toBe(false);
    expect(f.detail).toMatch(/unbounded/);
  });
});

describe('DC-07 identity conformance', () => {
  it('fails when the caller can claim a role, passes when it is derived', () => {
    expect(conformsIdentity({ resolve: i => i.claimedRole ?? 'member', privilegedRole: 'owner' }).pass).toBe(false);
    expect(conformsIdentity({ resolve: () => 'member', privilegedRole: 'owner' }).pass).toBe(true);
  });
});

describe('DC-03/DC-10 write-gate conformance', () => {
  it('passes a gate that blocks writes, keeps reads open and recovers', () => {
    let blocked = false;
    const findings = conformsWriteGate({
      blockedState: () => { blocked = true; },
      attemptWrite: () => ({ allowed: !blocked }),
      attemptRead: () => ({ allowed: true }),
      recover: () => { blocked = false; }
    });
    expect(summarise(findings)).toMatchObject({ passed: 3, failed: 0 });
  });

  it('fails a declared-but-unenforced state, a hostage read, and a missing recovery path', () => {
    const findings = conformsWriteGate({
      blockedState: () => undefined,
      attemptWrite: () => ({ allowed: true }),
      attemptRead: () => ({ allowed: false })
    });
    const { failed, report } = summarise(findings);
    expect(failed).toBe(2);
    expect(report).toMatch(/declared and not enforced/);
    expect(report).toMatch(/read access must survive a billing problem/);
    const stuck = conformsWriteGate({
      blockedState: () => undefined, attemptWrite: () => ({ allowed: false }),
      attemptRead: () => ({ allowed: true }), recover: () => undefined
    });
    expect(summarise(stuck).report).toMatch(/stays read-only forever/);
  });
});

describe('DC-06 backoff conformance', () => {
  it('passes a real sleep and fails a no-op one', async () => {
    const real = await conformsBackoff({ callWithRealSleep: async () => ({ elapsedMs: 120, retried: true }), minimumExpectedMs: 100 });
    expect(real.pass).toBe(true);
    const noop = await conformsBackoff({ callWithRealSleep: async () => ({ elapsedMs: 0, retried: true }), minimumExpectedMs: 100 });
    expect(noop.pass).toBe(false);
    expect(noop.detail).toMatch(/no-op/);
  });

  it('refuses to pass when the harness never retried', async () => {
    const f = await conformsBackoff({ callWithRealSleep: async () => ({ elapsedMs: 999, retried: false }), minimumExpectedMs: 100 });
    expect(f.pass).toBe(false);
  });
});

describe('DC-13 route conformance', () => {
  it('passes a fully wrapped table, fails a bare route, and never passes vacuously', () => {
    expect(conformsAsyncRoutes({ routes: [{ label: 'GET /a', wrapped: true }] }).pass).toBe(true);
    expect(conformsAsyncRoutes({ routes: [{ label: 'POST /b', wrapped: false }] }).detail).toMatch(/hangs the request/);
    expect(conformsAsyncRoutes({ routes: [] }).pass).toBe(false);
  });
});

describe('DC-11 tenancy conformance', () => {
  it('passes isolated tenants and fails a shared counter with a cross-tenant read', () => {
    let n = 0;
    const shared = conformsTenancy({ createFor: () => ({ id: `ID-${++n > 1 ? 1 : 1}` }), visibleTo: () => ['ID-1'] });
    expect(summarise(shared).failed).toBeGreaterThan(0);
    const perTenant = new Map<string, number>();
    const isolated = conformsTenancy({
      createFor: t => { const next = (perTenant.get(t) ?? 0) + 1; perTenant.set(t, next); return { id: `${t}-${next}` }; },
      visibleTo: t => [`${t}-1`]
    });
    expect(summarise(isolated)).toMatchObject({ failed: 0 });
  });
});

describe('summarise', () => {
  it('reports pass and fail counts with a readable line each', () => {
    const { passed, failed, report } = summarise([
      { check: 'a', pass: true, detail: 'fine' }, { check: 'b', pass: false, detail: 'broken' }
    ]);
    expect({ passed, failed }).toEqual({ passed: 1, failed: 1 });
    expect(report).toBe('PASS a — fine\nFAIL b — broken');
  });
});
