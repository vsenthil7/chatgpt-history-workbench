// Every test here is written as the defect it prevents, using the shape the defect actually took in the
// products it was found in. A module that cannot show its own failure mode is not prevention, it is code.
import {
  MemoryStore, appendCapped, droppedCount, seenBefore,
  csvParse, csvCell, importRows,
  Namespace, classifyKey, belongsToTenant, tenantKeys, exportTenant, purgeTenant, unclassifiedKeys,
  claimOwner, deriveRole, assignRole, requireRole, Role,
  checkWrite, recordPayment, subscriptionOf, Subscription,
  TenantRegistry, nextId, tenantTag,
  ResilientClient, CircuitOpenError, HttpLike, MAX_DELAY_MS,
  asyncHandler, assertAllWrapped
} from '../src';

const NS: Namespace[] = [
  { prefix: 'acct:', scope: 'tenant', what: 'install record' },
  { prefix: 'sub:', scope: 'tenant', what: 'subscription' },
  { prefix: 'audit', scope: 'installation', what: 'audit log' },
  { prefix: 'records:', scope: 'installation', what: 'the product\'s own records' }
];

describe('DC-01 — the published deletion policy (8 products)', () => {
  it('deletes the records a substring match would have left behind', () => {
    const store = new MemoryStore();
    store.set('acct:t1', { installed: true });
    store.set('sub:t1', { plan: 'trial' });
    store.set('records:r1', { note: 'a case, a ticket, an incident — the bulk of the data' });
    store.set('audit', [{ at: 1 }]);
    expect(purgeTenant(store, NS, 't1')).toBe(4);
    expect(store.keys()).toEqual([]);
  });

  it('exports exactly what it would delete, so portability matches the deletion claim', () => {
    const store = new MemoryStore();
    store.set('acct:t1', 1); store.set('records:r1', 2);
    expect(Object.keys(exportTenant(store, NS, 't1')).sort()).toEqual(tenantKeys(store, NS, 't1').sort());
  });

  it('refuses an empty tenant id instead of matching everything', () => {
    const store = new MemoryStore();
    store.set('acct:t1', 1);
    expect(() => purgeTenant(store, NS, ' ')).toThrow(/tenantId required/);
    expect(store.keys()).toHaveLength(1);
  });

  it('matches tenants by exact segment, never by substring', () => {
    expect(belongsToTenant('acct:abc-123', 'abc')).toBe(false);
    expect(belongsToTenant('acct:abc', 'abc')).toBe(true);
  });

  it('leaves installation-scoped data alone when asked to scope to one tenant', () => {
    const store = new MemoryStore();
    store.set('acct:t1', 1); store.set('records:r1', 2);
    expect(tenantKeys(store, NS, 't1', false)).toEqual(['acct:t1']);
  });

  it('reports any namespace the registry does not claim — the drift guard', () => {
    const store = new MemoryStore();
    store.set('acct:t1', 1);
    store.set('queue:pending', [1]);                       // a module added later, unregistered
    expect(unclassifiedKeys(store, NS)).toEqual(['queue:pending']);
    // and it is never purged silently — an unclassified key is reported, not deleted
    expect(tenantKeys(store, NS, 't1')).not.toContain('queue:pending');
    expect(classifyKey(NS, 'queue:pending')).toBeUndefined();
    expect(classifyKey(NS, 'audit')).toBe('installation');
  });
});

describe('DC-02 — unbounded ledgers (7 products)', () => {
  it('caps FIFO and counts what it dropped', () => {
    const store = new MemoryStore();
    appendCapped(store, 'log', [1, 2, 3], 2);
    expect(store.get<number[]>('log')).toEqual([2, 3]);
    expect(droppedCount(store, 'log')).toBe(1);
    appendCapped(store, 'log', [4], 2);
    expect(droppedCount(store, 'log')).toBe(2);
    expect(droppedCount(store, 'other')).toBe(0);
  });

  it('dedupes webhook ids without growing forever', () => {
    const store = new MemoryStore();
    expect(seenBefore(store, 'seen', 'e1')).toBe(false);
    expect(seenBefore(store, 'seen', 'e1')).toBe(true);
    for (let i = 0; i < 10; i++) seenBefore(store, 'seen', `x${i}`, 3);
    expect(store.get<string[]>('seen')!.length).toBe(3);
    expect(droppedCount(store, 'seen')).toBeGreaterThan(0);
  });

  it('uses the default cap when none is given', () => {
    const store = new MemoryStore();
    appendCapped(store, 'log', [1]);
    expect(droppedCount(store, 'log')).toBe(0);
  });
});

describe('DC-04 — naive CSV handling (5 products)', () => {
  it('parses the CRLF export every platform actually produces', () => {
    expect(csvParse('a,b\r\n1,2\r\n')).toEqual([['a', 'b'], ['1', '2']]);
    expect(csvParse('a,b\r1,2')).toEqual([['a', 'b'], ['1', '2']]);
  });

  it('keeps quoted commas and doubled quotes', () => {
    expect(csvParse('a,b\n"x,1","y""z"\n')).toEqual([['a', 'b'], ['x,1', 'y"z']]);
    expect(() => csvParse('a,"unterminated')).toThrow(/unterminated quote/);
  });

  it('quotes on the way out too', () => {
    expect(csvCell('plain')).toBe('plain');
    expect(csvCell('has,comma')).toBe('"has,comma"');
    expect(csvCell('has"quote')).toBe('"has""quote"');
  });

  it('validates the whole file before applying any of it', () => {
    const rows = importRows('id,status\r\nc1,pass\r\nc2,fail\r\n', ['id', 'status'], r => ({ id: r[0], status: r[1] }));
    expect(rows).toEqual([{ id: 'c1', status: 'pass' }, { id: 'c2', status: 'fail' }]);
    expect(() => importRows('wrong,header\n', ['id', 'status'], r => r)).toThrow(/CSV header must be id,status/);
    expect(() => importRows('', ['id', 'status'], r => r)).toThrow(/CSV header/);
  });
});

describe('DC-07 — caller-declared identity (4 products)', () => {
  it('derives role from trusted context, and ownership is claimed once', () => {
    const store = new MemoryStore();
    claimOwner(store, 'acc-owner');
    expect(claimOwner(store, 'acc-second')).toBe('acc-owner');
    expect(deriveRole(store, { accountId: 'acc-owner' })).toBe('owner');
    expect(deriveRole(store, { accountId: 'acc-admin', platformAdmin: true })).toBe('admin');
    expect(deriveRole(store, { accountId: 'acc-x' })).toBe('member');
  });

  it('an explicit assignment wins, and only an owner may make one', () => {
    const store = new MemoryStore();
    claimOwner(store, 'acc-owner');
    assignRole(store, 'owner', 'acc-x', 'admin');
    expect(deriveRole(store, { accountId: 'acc-x' })).toBe('admin');
    expect(() => assignRole(store, 'admin' as Role, 'acc-y', 'owner')).toThrow(/Only the owner/);
  });

  it('guards read the same at every call site', () => {
    expect(() => requireRole('member', ['owner', 'admin'])).toThrow(/Forbidden/);
    expect(() => requireRole('owner', ['owner'])).not.toThrow();
  });
});

describe('DC-03 / DC-10 — billing state enforced at the write (6 and 4 products)', () => {
  const store = () => {
    const s = new MemoryStore();
    s.set<Subscription>('sub:t1', { plan: 'trial', trialEndsAt: 1_000 });
    return s;
  };

  it('blocks writes after the trial ends but never blocks reads', () => {
    const s = store();
    expect(checkWrite(s, 't1', 999, true).allowed).toBe(true);
    const out = checkWrite(s, 't1', 1_001, true);
    expect(out.allowed).toBe(false);
    expect(out.allowed === false && out.reason).toMatch(/trial has ended/);
    expect(checkWrite(s, 't1', 1_001, false).allowed).toBe(true);   // reads stay open
  });

  it('blocks a cancelled workspace and a past-due one after its grace point', () => {
    const s = new MemoryStore();
    s.set<Subscription>('sub:t1', { plan: 'cancelled' });
    expect(checkWrite(s, 't1', 0, true).allowed).toBe(false);
    s.set<Subscription>('sub:t2', { plan: 'past_due', readOnlyFrom: 500 });
    expect(checkWrite(s, 't2', 499, true).allowed).toBe(true);
    expect(checkWrite(s, 't2', 500, true).allowed).toBe(false);
    s.set<Subscription>('sub:t3', { plan: 'past_due' });
    expect(checkWrite(s, 't3', 10_000, true).allowed).toBe(true);   // dunning started, grace not set yet
  });

  it('does not block a tenant that has no subscription yet', () => {
    expect(checkWrite(new MemoryStore(), 'new-tenant', 0, true).allowed).toBe(true);
  });

  it('has a recovery path — its absence was the defect in six products', () => {
    const s = store();
    s.set<Subscription>('sub:t1', { plan: 'past_due', readOnlyFrom: 0 });
    expect(checkWrite(s, 't1', 10, true).allowed).toBe(false);
    recordPayment(s, 't1', 10);
    expect(checkWrite(s, 't1', 10, true).allowed).toBe(true);
    expect(subscriptionOf(s, 't1')!.plan).toBe('active');
    expect(recordPayment(new MemoryStore(), 'fresh', 1).plan).toBe('active');
  });
});

describe('DC-11 — multi-tenancy from day one (2 products)', () => {
  it('gives each tenant its own instance, and ids never collide across tenants', () => {
    const made: string[] = [];
    const registry = new TenantRegistry<{ id: string }>(t => { made.push(t); return { id: t }; });
    expect(registry.for('t1')).toBe(registry.for('t1'));
    expect(registry.for('t2').id).toBe('t2');
    expect(made).toEqual(['t1', 't2']);
    expect(registry.size()).toBe(2);
    expect(registry.forget('t1')).toBe(true);
    expect(() => registry.for(' ')).toThrow(/tenantId required/);
  });

  it('ids are monotonic per tenant AND distinct across tenants', () => {
    const store = new MemoryStore();
    const a1 = nextId(store, 't1', 'board');
    const a2 = nextId(store, 't1', 'board');
    const b1 = nextId(store, 't2', 'board');
    expect(a1).toMatch(/^BOARD-[0-9a-z]{1,6}-1$/);
    expect(a2.endsWith('-2')).toBe(true);
    // the original version returned BOARD-1 for both tenants, and this test asserted it
    expect(b1).not.toBe(a1);
    expect(b1.endsWith('-1')).toBe(true);
    expect(tenantTag('t1')).not.toBe(tenantTag('t2'));
    expect(tenantTag('tenant-a')).not.toBe(tenantTag('tenant-b'));   // near-identical ids must still differ
    expect(() => nextId(store, '  ', 'board')).toThrow(/tenantId required/);
  });
});

describe('DC-06 — backoff that actually runs (5 products)', () => {
  const seq = (...items: HttpLike[]) => { const q = [...items]; return async () => q.shift()!; };

  it('honours Retry-After in SECONDS and caps it', async () => {
    const slept: number[] = [];
    const c = new ResilientClient({}, async ms => { slept.push(ms); });
    await c.run('op', seq({ status: 429, retryAfterSeconds: 2 }, { status: 200 }));
    expect(slept).toEqual([2000]);
    const c2 = new ResilientClient({}, async ms => { slept.push(ms); });
    await c2.run('op', seq({ status: 429, retryAfterSeconds: 9_999 }, { status: 200 }));
    expect(slept[1]).toBe(MAX_DELAY_MS);
  });

  it('backs off exponentially with jitter, then exhausts', async () => {
    const slept: number[] = [];
    const c = new ResilientClient({ maxRetries: 2, baseDelayMs: 100, breakerThreshold: 99 }, async ms => { slept.push(ms); }, () => 0);
    await expect(c.run('op', async () => ({ status: 500 }))).rejects.toThrow(/Exhausted retries on op: 500/);
    expect(slept).toEqual([100, 200]);
  });

  it('opens the breaker across operations and blocks until cooldown', async () => {
    let clock = 0;
    const c = new ResilientClient({ maxRetries: 99, breakerThreshold: 2, breakerCooldownMs: 100 }, async () => {}, () => 0, () => clock);
    await expect(c.run('a', async () => ({ status: 503 }))).rejects.toThrow(CircuitOpenError);
    await expect(c.run('b', async () => ({ status: 200 }))).rejects.toThrow(CircuitOpenError);
    clock = 101;
    await expect(c.run('b', async () => ({ status: 200 }))).resolves.toMatchObject({ status: 200 });
  });

  it('does not retry a 4xx, and uses a real sleep by default', async () => {
    const c = new ResilientClient();
    await expect(c.run('op', async () => ({ status: 404 }))).rejects.toThrow(/Non-retryable 404 on op/);
    const timed = new ResilientClient({ maxRetries: 1, baseDelayMs: 1, breakerThreshold: 99 }, undefined, () => 0);
    const started = Date.now();
    await timed.run('op', seq({ status: 500 }, { status: 200 }));
    expect(Date.now() - started).toBeGreaterThanOrEqual(0);          // the default sleep is real, not a no-op
  });
});

describe('DC-13 — async handler errors (1 product, open portfolio-wide)', () => {
  const mkRes = () => {
    const sent: Array<{ code: number; body: unknown }> = [];
    return { sent, res: { status: (code: number) => ({ json: (body: unknown) => { sent.push({ code, body }); } }) } };
  };

  it('turns a rejected handler into a response instead of a hung request', async () => {
    const { sent, res } = mkRes();
    const errors: string[] = [];
    const handler = asyncHandler('POST /webhook', async () => { throw new Error('boom'); }, { onError: (e, label) => errors.push(`${label}:${e.message}`) });
    await handler({}, res);
    expect(sent).toEqual([{ code: 500, body: { error: 'boom', at: 'POST /webhook' } }]);
    expect(errors).toEqual(['POST /webhook:boom']);
  });

  it('passes a successful handler through untouched, and supports a custom status', async () => {
    const { sent, res } = mkRes();
    await asyncHandler('GET /ok', async (_req, r) => { r.status(200).json({ ok: true }); })({}, res);
    expect(sent).toEqual([{ code: 200, body: { ok: true } }]);
    const second = mkRes();
    await asyncHandler('POST /x', async () => { throw new Error(''); }, { status: 400 })({}, second.res);
    expect(second.sent).toEqual([{ code: 400, body: { error: 'Internal error', at: 'POST /x' } }]);
  });

  it('fails the build when a route is registered unwrapped', () => {
    expect(() => assertAllWrapped([{ label: 'GET /a', wrapped: true }])).not.toThrow();
    expect(() => assertAllWrapped([{ label: 'GET /a', wrapped: true }, { label: 'POST /b', wrapped: false }]))
      .toThrow(/Unwrapped async routes \(DC-13\): POST \/b/);
  });
});

describe('store contract', () => {
  it('supports prefix listing and delete', () => {
    const s = new MemoryStore();
    s.set('a:1', 1); s.set('b:1', 2);
    expect(s.keys('a:')).toEqual(['a:1']);
    expect(s.keys()).toHaveLength(2);
    expect(s.delete('a:1')).toBe(true);
    expect(s.delete('a:1')).toBe(false);
    expect(s.get('missing')).toBeUndefined();
  });
});
