// The minimal store contract the rest of the baseline is written against. Products keep their own
// implementation (Forge KVS, Postgres, in-memory); only this shape is assumed.
export interface Store {
  get<T>(key: string): T | undefined;
  set<T>(key: string, value: T): void;
  delete(key: string): boolean;
  keys(prefix?: string): string[];
}

export class MemoryStore implements Store {
  private m = new Map<string, unknown>();
  get<T>(key: string): T | undefined { return this.m.get(key) as T | undefined; }
  set<T>(key: string, value: T): void { this.m.set(key, value); }
  delete(key: string): boolean { return this.m.delete(key); }
  keys(prefix?: string): string[] {
    const all = [...this.m.keys()];
    return prefix ? all.filter(k => k.startsWith(prefix)) : all;
  }
}
