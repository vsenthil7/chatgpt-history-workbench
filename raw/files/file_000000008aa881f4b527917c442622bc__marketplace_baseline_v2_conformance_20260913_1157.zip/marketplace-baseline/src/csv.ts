// DC-04 — naive CSV handling. Found in 5 products. `split(',')` fails every CRLF export, which is what Excel
// and every platform export actually produces, and mis-parses any quoted comma.
export function csvParse(text: string): string[][] {
  const rows: string[][] = []; let field = ''; let row: string[] = []; let inQ = false;
  const src = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (inQ) {
      if (ch === '"') {
        if (src[i + 1] === '"') { field += '"'; i++; } else inQ = false;
      } else field += ch;
    } else if (ch === '"') inQ = true;
    else if (ch === ',') { row.push(field); field = ''; }
    else if (ch === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
    else field += ch;
  }
  if (inQ) throw new Error('Malformed CSV: unterminated quote');
  if (field !== '' || row.length) { row.push(field); rows.push(row); }
  return rows.filter(r => r.some(c => c.trim() !== ''));
}

export function csvCell(v: string): string {
  return /[",\n\r]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
}

// Validate-then-apply: a bad row halfway through must not leave the earlier rows written.
export function importRows<T>(text: string, header: string[], map: (row: string[], index: number) => T): T[] {
  const grid = csvParse(text);
  if (grid.length === 0 || grid[0].map(c => c.trim()).join(',') !== header.join(',')) {
    throw new Error(`CSV header must be ${header.join(',')}`);
  }
  return grid.slice(1).map((row, i) => map(row, i));
}
