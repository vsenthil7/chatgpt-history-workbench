// DC-03 and DC-10 — billing state declared and never enforced (6 products) and read-only/suspended state
// enforced nowhere (4 products). Trial expiry, dunning read-only and cancellation were all maintained
// correctly in a billing module and checked at no mutating entry point. One gate, called at the entry
// points, with reads pinned open: never hold a customer's data hostage.
import { Store } from './store';

export type Plan = 'trial' | 'active' | 'past_due' | 'cancelled';
export interface Subscription { plan: Plan; trialEndsAt?: number; readOnlyFrom?: number }
export type GateResult = { allowed: true } | { allowed: false; reason: string };

export const REASONS = {
  trial: 'Your trial has ended — choose a plan to keep editing. Your data stays available to read and export.',
  past_due: 'Payment failed — TestPulse-style read-only until it is resolved. Reads and export stay open.',
  cancelled: 'This subscription is cancelled — the workspace is read-only. Export remains available.'
};

export function subscriptionOf(store: Store, tenantId: string): Subscription | undefined {
  return store.get<Subscription>(`sub:${tenantId}`);
}

// `mutating` is the caller's declaration that this operation writes. Reads always pass.
export function checkWrite(store: Store, tenantId: string, now: number, mutating: boolean): GateResult {
  if (!mutating) return { allowed: true };
  const sub = subscriptionOf(store, tenantId);
  if (!sub) return { allowed: true };                                  // not yet billed: do not block setup
  if (sub.plan === 'cancelled') return { allowed: false, reason: REASONS.cancelled };
  if (sub.plan === 'past_due' && sub.readOnlyFrom !== undefined && now >= sub.readOnlyFrom) {
    return { allowed: false, reason: REASONS.past_due };
  }
  if (sub.plan === 'trial' && sub.trialEndsAt !== undefined && now >= sub.trialEndsAt) {
    return { allowed: false, reason: REASONS.trial };
  }
  return { allowed: true };
}

// Recovery path — its absence was a defect in 6 products: a tenant who fixed their card stayed read-only.
export function recordPayment(store: Store, tenantId: string, now: number): Subscription {
  const sub = subscriptionOf(store, tenantId) ?? { plan: 'trial' as Plan };
  const next: Subscription = { ...sub, plan: 'active', readOnlyFrom: undefined, trialEndsAt: undefined };
  store.set(`sub:${tenantId}`, next);
  store.set(`sub:${tenantId}:recoveredAt`, now);
  return next;
}
