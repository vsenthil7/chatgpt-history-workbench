// DC-13 — async handler errors swallowed. Found once and flagged portfolio-wide: Express 4 ignores a
// rejected promise from an async handler, so an unexpected failure leaves the request hanging with no
// status — and the test times out rather than failing, which is how it survives a green suite.
export type Handler<Req, Res> = (req: Req, res: Res) => unknown | Promise<unknown>;
export interface ResponseLike { status(code: number): { json(body: unknown): void } }

export interface AsyncRouterOptions {
  onError?: (error: Error, label: string) => void;
  status?: number;
}

// Wraps a handler so every rejection becomes a response. Framework-free: pass any (req, res) pair.
export function asyncHandler<Req, Res extends ResponseLike>(label: string, fn: Handler<Req, Res>, opts: AsyncRouterOptions = {}): (req: Req, res: Res) => Promise<void> {
  return async (req, res) => {
    try {
      await fn(req, res);
    } catch (e) {
      const error = e as Error;
      if (opts.onError) opts.onError(error, label);
      res.status(opts.status ?? 500).json({ error: error.message || 'Internal error', at: label });
    }
  };
}

// A drift guard: assert in a test that every route registered goes through asyncHandler.
export function assertAllWrapped(routes: ReadonlyArray<{ label: string; wrapped: boolean }>): void {
  const bare = routes.filter(r => !r.wrapped).map(r => r.label);
  if (bare.length) throw new Error(`Unwrapped async routes (DC-13): ${bare.join(', ')}`);
}
