// Marketplace baseline — the six recurring defect classes no standing gate catches, prevented in code.
// Each module names the class it exists for and the number of products that hit it.
export * from './store';
export * from './ledger';        // DC-02 unbounded ledgers (7 products)
export * from './csv';           // DC-04 naive CSV handling (5 products)
export * from './tenantData';    // DC-01 published deletion not implemented (8 products)
export * from './identity';      // DC-07 caller-declared identity (4 products)
export * from './writeGate';     // DC-03 / DC-10 billing state never enforced (6 / 4 products)
export * from './tenancy';       // DC-11 no multi-tenancy (2 products)
export * from './backoff';       // DC-06 retry/backoff that does not run (5 products)
export * from './asyncRouter';   // DC-13 async handler errors swallowed (1, open portfolio-wide)
export * from './conformance';   // the invariants, checkable against a product's own code
