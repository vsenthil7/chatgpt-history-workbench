// DC-11 — no multi-tenancy. Found in 2 products, both late and both severe: one process-wide instance and
// one id counter served every workspace, so ids collided and tenants read each other's data. The fix is
// cheap on day one and expensive afterwards, so it belongs in the foundation.
export class TenantRegistry<T> {
  private instances = new Map<string, T>();
  constructor(private factory: (tenantId: string) => T) {}

  for(tenantId: string): T {
    if (!tenantId.trim()) throw new Error('tenantId required');
    let instance = this.instances.get(tenantId);
    if (!instance) { instance = this.factory(tenantId); this.instances.set(tenantId, instance); }
    return instance;
  }

  forget(tenantId: string): boolean { return this.instances.delete(tenantId); }
  size(): number { return this.instances.size; }
}

// Ids must be monotonic per tenant (so deleting a record cannot make the next id collide) AND distinct
// ACROSS tenants — ids end up in urls, exports and support tickets, where two tenants both holding "BOARD-1"
// is the collision the per-tenant sequence was supposed to prevent.
//
// The first version of this function returned `${kind}-${n}` from a per-tenant sequence, and its own test
// asserted that two tenants both got BOARD-1 — the test pinned the defect the module exists to prevent.
// It was caught by running the conformance check against a product rather than against this package.
export function tenantTag(tenantId: string): string {
  let hash = 5381;
  for (let i = 0; i < tenantId.length; i++) hash = ((hash * 33) ^ tenantId.charCodeAt(i)) >>> 0;
  // Take the low-order end: the leading characters of a djb2 hash barely move between similar ids
  // ('t1' and 't2' produced the same 4-char prefix), which would have reintroduced the collision.
  return hash.toString(36).slice(-6);
}

export function nextId(store: { get<T>(k: string): T | undefined; set<T>(k: string, v: T): void }, tenantId: string, kind: string): string {
  if (!tenantId.trim()) throw new Error('tenantId required');
  const key = `seq:${tenantId}:${kind}`;
  const next = (store.get<number>(key) ?? 0) + 1;
  store.set(key, next);
  return `${kind.toUpperCase()}-${tenantTag(tenantId)}-${next}`;
}
