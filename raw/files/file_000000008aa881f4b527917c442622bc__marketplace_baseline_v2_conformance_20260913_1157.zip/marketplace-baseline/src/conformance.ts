// Conformance — the invariant, checkable against a product's OWN implementation.
//
// Adopting the baseline modules means a rewrite, and a rewrite is how adoption stalls: three of the eight
// modules are adopted nowhere for exactly that reason. What actually matters is not that a product uses this
// code, but that it satisfies the invariant the code exists to protect. So each check takes a small harness
// describing what the product already has, and reports whether the invariant holds.
//
// These return findings rather than throwing, so they can run as a jest test, a CI script, or a one-off audit
// during a review pass. Every check is written to FAIL against the shape the defect actually took.
export interface Finding { check: string; pass: boolean; detail: string }

const ok = (check: string, detail: string): Finding => ({ check, pass: true, detail });
const bad = (check: string, detail: string): Finding => ({ check, pass: false, detail });

// DC-01 — the published deletion policy. Harness: seed a tenant the way the product does, then delete.
export interface DeletionHarness {
  seed(tenantId: string): void;      // exercise a realistic end-to-end flow, not one write
  purge(tenantId: string): unknown;  // the product's own delete-my-data / retention sweep
  remainingKeys(): string[];         // everything still in the product's store afterwards
  allowed?: string[];                // keys legitimately surviving (deletion proof rows, cross-tenant data)
}

export function conformsDeletion(h: DeletionHarness, tenantId = 'conformance-tenant'): Finding {
  h.seed(tenantId);
  h.purge(tenantId);
  const allowed = h.allowed ?? [];
  const left = h.remainingKeys().filter(k => !allowed.includes(k));
  return left.length === 0
    ? ok('DC-01 deletion', 'nothing survived the purge that was not explicitly allowed')
    : bad('DC-01 deletion', `${left.length} key(s) survived the published deletion: ${left.slice(0, 8).join(', ')}`);
}

// DC-02 — bounded ledgers. Harness: append many events the way the product does, then report the size.
export interface LedgerHarness {
  append(n: number): void;
  size(): number;
  cap: number;
}

export function conformsLedgerCap(h: LedgerHarness): Finding {
  const over = h.cap * 2;
  h.append(over);
  const size = h.size();
  return size <= h.cap
    ? ok('DC-02 ledger cap', `bounded at ${size} after ${over} appends`)
    : bad('DC-02 ledger cap', `grew to ${size} after ${over} appends — unbounded, and platform value limits make this a hard write failure`);
}

// DC-07 — identity. Harness: resolve a role from a payload the caller controls.
export interface IdentityHarness {
  resolve(input: { accountId: string; claimedRole?: string }): string;
  privilegedRole: string;
}

export function conformsIdentity(h: IdentityHarness): Finding {
  const claimed = h.resolve({ accountId: 'attacker', claimedRole: h.privilegedRole });
  return claimed !== h.privilegedRole
    ? ok('DC-07 identity', `a caller claiming "${h.privilegedRole}" resolved to "${claimed}"`)
    : bad('DC-07 identity', `a caller who claimed "${h.privilegedRole}" was given it — identity is caller-declared`);
}

// DC-03/DC-10 — the write gate. Harness: put the tenant in a blocked state, then attempt a write and a read.
export interface WriteGateHarness {
  blockedState(): void;
  attemptWrite(): { allowed: boolean };
  attemptRead(): { allowed: boolean };
  recover?(): void;
}

export function conformsWriteGate(h: WriteGateHarness): Finding[] {
  h.blockedState();
  const findings: Finding[] = [];
  findings.push(h.attemptWrite().allowed
    ? bad('DC-03 write gate', 'a write succeeded while the subscription was blocked — the state is declared and not enforced')
    : ok('DC-03 write gate', 'writes blocked in the blocked state'));
  findings.push(h.attemptRead().allowed
    ? ok('DC-10 reads open', 'reads stay available — data is not held hostage')
    : bad('DC-10 reads open', 'reads were blocked too — export and read access must survive a billing problem'));
  if (h.recover) {
    h.recover();
    findings.push(h.attemptWrite().allowed
      ? ok('DC-03 recovery', 'writes resume after payment recovery')
      : bad('DC-03 recovery', 'still blocked after recovery — a tenant who fixes their card stays read-only forever'));
  }
  return findings;
}

// DC-06 — the retry actually sleeps in production. Harness: call the product's client WITHOUT injecting a
// sleep, which is precisely what every test in the affected products did.
export interface BackoffHarness {
  callWithRealSleep(): Promise<{ elapsedMs: number; retried: boolean }>;
  minimumExpectedMs: number;
}

export async function conformsBackoff(h: BackoffHarness): Promise<Finding> {
  const { elapsedMs, retried } = await h.callWithRealSleep();
  if (!retried) return bad('DC-06 backoff', 'the harness did not retry — the check needs a retryable response');
  return elapsedMs >= h.minimumExpectedMs
    ? ok('DC-06 backoff', `slept ~${elapsedMs}ms across the retry`)
    : bad('DC-06 backoff', `retried in ${elapsedMs}ms against a minimum of ${h.minimumExpectedMs}ms — the production sleep is a no-op`);
}

// DC-13 — async routes. Harness: the product's route table, and whether each is error-wrapped.
export interface RouteHarness { routes: ReadonlyArray<{ label: string; wrapped: boolean }> }

export function conformsAsyncRoutes(h: RouteHarness): Finding {
  const bare = h.routes.filter(r => !r.wrapped).map(r => r.label);
  if (h.routes.length === 0) return bad('DC-13 async routes', 'no routes described — the check cannot pass vacuously');
  return bare.length === 0
    ? ok('DC-13 async routes', `${h.routes.length} route(s) all error-wrapped`)
    : bad('DC-13 async routes', `unwrapped: ${bare.join(', ')} — a rejection here hangs the request and times the test out instead of failing it`);
}

// DC-11 — tenancy. Harness: perform the same operation for two tenants and report what each sees.
export interface TenancyHarness {
  createFor(tenantId: string): { id: string };
  visibleTo(tenantId: string): string[];
}

export function conformsTenancy(h: TenancyHarness): Finding[] {
  const a = h.createFor('tenant-a');
  const b = h.createFor('tenant-b');
  const findings: Finding[] = [];
  findings.push(a.id !== b.id
    ? ok('DC-11 id isolation', `ids differ across tenants (${a.id} vs ${b.id})`)
    : bad('DC-11 id isolation', `both tenants produced id "${a.id}" — one counter is serving every tenant`));
  const leaked = h.visibleTo('tenant-a').filter(id => id === b.id);
  findings.push(leaked.length === 0
    ? ok('DC-11 read isolation', 'tenant A cannot see tenant B\'s records')
    : bad('DC-11 read isolation', `tenant A can see ${leaked.join(', ')} — cross-tenant read`));
  return findings;
}

export function summarise(findings: ReadonlyArray<Finding>): { passed: number; failed: number; report: string } {
  const failed = findings.filter(f => !f.pass);
  const report = findings.map(f => `${f.pass ? 'PASS' : 'FAIL'} ${f.check} — ${f.detail}`).join('\n');
  return { passed: findings.length - failed.length, failed: failed.length, report };
}
