// DC-01 — published deletion/retention not implemented. Found in 8 products, the most common defect in the
// portfolio: the trust page promises a hard delete, and the sweep clears one namespace while cases, logs,
// audit trails and queues live on. One registry, read by export, delete AND the retention sweep, plus a
// drift test so a new namespace cannot be added without being classified.
import { Store } from './store';

export type Scope = 'tenant' | 'installation';
export interface Namespace { prefix: string; scope: Scope; what: string }

export function classifyKey(namespaces: ReadonlyArray<Namespace>, key: string): Scope | undefined {
  return namespaces.find(n => key.startsWith(n.prefix))?.scope;
}

// Exact segment match: tenant 'abc' must never claim tenant 'abc-123' (a real substring-matching defect).
export function belongsToTenant(key: string, tenantId: string): boolean {
  return key.split(':').includes(tenantId);
}

export function tenantKeys(store: Store, namespaces: ReadonlyArray<Namespace>, tenantId: string, installationScoped = true): string[] {
  if (!tenantId.trim()) throw new Error('tenantId required');
  return store.keys().filter(k => {
    const scope = classifyKey(namespaces, k);
    if (scope === undefined) return false;
    return scope === 'tenant' ? belongsToTenant(k, tenantId) : installationScoped;
  });
}

export function exportTenant(store: Store, namespaces: ReadonlyArray<Namespace>, tenantId: string, installationScoped = true): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const k of tenantKeys(store, namespaces, tenantId, installationScoped)) out[k] = store.get(k);
  return out;
}

export function purgeTenant(store: Store, namespaces: ReadonlyArray<Namespace>, tenantId: string, installationScoped = true): number {
  const keys = tenantKeys(store, namespaces, tenantId, installationScoped);
  for (const k of keys) store.delete(k);
  return keys.length;
}

// The drift guard: run a full end-to-end flow in a test, then assert this is empty.
export function unclassifiedKeys(store: Store, namespaces: ReadonlyArray<Namespace>): string[] {
  return store.keys().filter(k => classifyKey(namespaces, k) === undefined);
}
