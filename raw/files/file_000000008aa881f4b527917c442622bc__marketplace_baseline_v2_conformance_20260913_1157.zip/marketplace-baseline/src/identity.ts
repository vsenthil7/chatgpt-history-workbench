// DC-07 — caller-declared identity. Found in 4 products: role or user id taken from a header or payload the
// caller controls, so any member could act as owner. Identity is derived here from whatever the platform
// documents as trustworthy, never from input, and the derivation is one function so it can be audited.
import { Store } from './store';

export type Role = 'owner' | 'admin' | 'member';
export const OWNER_KEY = 'role:owner';

export interface TrustedContext {
  accountId: string;        // from the platform's own context, not a header
  platformAdmin?: boolean;  // e.g. the product's site-admin permission, checked server-side
}

export function claimOwner(store: Store, accountId: string): string {
  const existing = store.get<string>(OWNER_KEY);
  if (existing) return existing;
  store.set(OWNER_KEY, accountId);
  return accountId;
}

export function deriveRole(store: Store, ctx: TrustedContext): Role {
  const assigned = store.get<Role>(`role:user:${ctx.accountId}`);
  if (assigned) return assigned;
  if (store.get<string>(OWNER_KEY) === ctx.accountId) return 'owner';
  return ctx.platformAdmin === true ? 'admin' : 'member';
}

export function assignRole(store: Store, actor: Role, accountId: string, role: Role): Role {
  if (actor !== 'owner') throw new Error('Only the owner can assign roles');
  store.set(`role:user:${accountId}`, role);
  return role;
}

// Guard helper so authorization reads the same at every call site.
export function requireRole(actual: Role, allowed: ReadonlyArray<Role>): void {
  if (!allowed.includes(actual)) throw new Error('Forbidden');
}
