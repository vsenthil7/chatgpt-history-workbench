// DC-02 — unbounded ledgers. Found in 7 products: dedupe sets, audit logs, error counters and notification
// logs appended to storage without limit, until the platform's per-value size limit hard-fails every write.
// The loss must be observable, so drops are counted rather than silent.
import { Store } from './store';

export const DEFAULT_CAP = 10_000;

export function appendCapped<T>(store: Store, key: string, items: T[], cap: number = DEFAULT_CAP): { kept: T[]; dropped: number } {
  const all = [...(store.get<T[]>(key) ?? []), ...items];
  const overflow = Math.max(0, all.length - cap);
  const kept = overflow > 0 ? all.slice(overflow) : all;
  store.set(key, kept);
  if (overflow > 0) store.set(`${key}:dropped`, (store.get<number>(`${key}:dropped`) ?? 0) + overflow);
  return { kept, dropped: overflow };
}

export function droppedCount(store: Store, key: string): number {
  return store.get<number>(`${key}:dropped`) ?? 0;
}

// A dedupe set is the commonest instance of this class: unbounded `seen` arrays behind webhook idempotency.
export function seenBefore(store: Store, key: string, id: string, cap: number = DEFAULT_CAP): boolean {
  const seen = store.get<string[]>(key) ?? [];
  if (seen.includes(id)) return true;
  appendCapped(store, key, [id], cap);
  return false;
}
