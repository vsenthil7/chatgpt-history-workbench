// DC-06 — retry/backoff that does not run. Found in 5 products: a production sleep that was a no-op because
// every test injected its own; Retry-After slept as milliseconds when the header is seconds; a breaker
// wrapping nothing the live path used. The real sleep is the default here, and `run` takes an operation
// rather than a path so a platform SDK call (which often cannot be expressed as a URL string) goes through
// the same policy.
export interface HttpLike { status: number; body?: unknown; retryAfterSeconds?: number }
export const MAX_DELAY_MS = 60_000;

export class CircuitOpenError extends Error { constructor() { super('Circuit open'); } }

export interface RetryOptions {
  maxRetries?: number; baseDelayMs?: number; breakerThreshold?: number; breakerCooldownMs?: number;
}

export class ResilientClient {
  private failures = 0;
  private openUntil = 0;
  constructor(
    private opts: RetryOptions = {},
    private sleep: (ms: number) => Promise<void> = ms => new Promise(r => setTimeout(r, ms)),
    private rand: () => number = Math.random,
    private now: () => number = Date.now
  ) {}

  async run(label: string, op: () => Promise<HttpLike>): Promise<HttpLike> {
    const { maxRetries = 3, baseDelayMs = 100, breakerThreshold = 5, breakerCooldownMs = 30_000 } = this.opts;
    if (this.now() < this.openUntil) throw new CircuitOpenError();
    let attempt = 0;
    for (;;) {
      const res = await op();
      if (res.status === 429 || res.status >= 500) {
        this.failures++;
        if (this.failures >= breakerThreshold) {
          this.openUntil = this.now() + breakerCooldownMs;
          throw new CircuitOpenError();
        }
        if (attempt >= maxRetries) throw new Error(`Exhausted retries on ${label}: ${res.status}`);
        await this.sleep(this.delayFor(res, attempt, baseDelayMs));
        attempt++;
        continue;
      }
      if (res.status >= 400) throw new Error(`Non-retryable ${res.status} on ${label}`);
      this.failures = 0;
      return res;
    }
  }

  // Retry-After is SECONDS. Slept as milliseconds it becomes a retry storm into the rate limiter.
  private delayFor(res: HttpLike, attempt: number, baseDelayMs: number): number {
    return res.retryAfterSeconds !== undefined
      ? Math.min(res.retryAfterSeconds * 1000, MAX_DELAY_MS)
      : Math.min(baseDelayMs * 2 ** attempt * (1 + this.rand()), MAX_DELAY_MS);
  }
}
