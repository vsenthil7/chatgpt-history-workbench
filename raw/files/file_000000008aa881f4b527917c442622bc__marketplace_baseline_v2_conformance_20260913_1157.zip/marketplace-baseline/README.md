# Marketplace baseline — the six classes no gate catches

The standing gates (reachability, published claims, platform entrypoints, entrypoint type-check) catch 7 of
the 13 recurring defect classes. The other six are not gateable: they are things the code either does or does
not do. Every one of them was retrofitted into several products *after* those products reached 100% coverage.
This package is that retrofit, done once.

| Module | Class | Products that hit it | What it prevents |
|---|---|---|---|
| `tenantData.ts` | DC-01 | **8** | Export, delete and the retention sweep all read one namespace registry; exact-segment tenant matching; a drift guard that reports any unregistered namespace |
| `ledger.ts` | DC-02 | 7 | FIFO-capped ledgers with a visible drop counter; `seenBefore` for webhook dedupe |
| `writeGate.ts` | DC-03 / DC-10 | 6 / 4 | One write gate at the mutating entry points, reads always open, **and a payment-recovery path** — whose absence was the defect in six products |
| `csv.ts` | DC-04 | 5 | RFC-4180 in and out; validate-then-apply so a bad row leaves nothing written |
| `backoff.ts` | DC-06 | 5 | A real default sleep (not a no-op), `Retry-After` in seconds and capped, a breaker shared across operations, and `run(label, op)` so SDK calls go through the same policy |
| `identity.ts` | DC-07 | 4 | Role derived server-side from the platform's trustworthy context; ownership claimed once; `requireRole` so guards read the same everywhere |
| `tenancy.ts` | DC-11 | 2 | Per-tenant instances and per-tenant monotonic ids, from day one |
| `asyncRouter.ts` | DC-13 | 1, open elsewhere | A rejected async handler becomes a response instead of a hung request; `assertAllWrapped` fails the build on a bare route |

## Conformance — prove the invariant with the code you already have

Adopting eight modules is a rewrite, and a rewrite is how adoption stalls. What matters is not that a product
uses this code but that it satisfies the invariant. `conformance.ts` exports one check per class, each taking
a small harness describing what the product already has:

```ts
conformsDeletion({ seed, purge, remainingKeys })   // does your delete-my-data actually cover a real flow?
conformsLedgerCap({ append, size, cap })           // is your dedupe set bounded?
conformsIdentity({ resolve, privilegedRole })      // can a caller claim a role?
conformsWriteGate({ blockedState, attemptWrite, attemptRead, recover })
conformsBackoff({ callWithRealSleep, minimumExpectedMs })   // run it WITHOUT injecting a sleep
conformsAsyncRoutes({ routes })
conformsTenancy({ createFor, visibleTo })
```

Each check is tested twice in this package: against an implementation that holds the invariant, and against
one shaped like the defect. A check that cannot go red is decoration.

**It has already earned itself.** Run against TestPulse's own code, the tenancy check failed — and the defect
was in *this package*: `nextId` scoped the sequence per tenant but returned `BOARD-1` for every tenant, and
this package's own test asserted that as correct. The test pinned the defect the module exists to prevent,
which is lesson L-6 occurring inside the code written to prevent L-6. Ids are now tenant-qualified, and a
second bug surfaced on the fix (the leading characters of the hash barely moved between similar tenant ids,
so 't1' and 't2' collided again — the tag now takes the low-order end).

## Adopting it

1. Implement the four-method `Store` interface over whatever the product already uses. Nothing else is assumed.
2. Replace the equivalents in the product one module at a time, running that product's suite between each.
3. Add the two drift guards as tests: `unclassifiedKeys` after an end-to-end flow, and `assertAllWrapped`
   over the route table.
4. Where a module does not fit, say so in the review log rather than forking it quietly — a second copy is
   how DC-04 ended up in five products.

## The bar

30 tests, 100% branches/functions/lines/statements, zero pragmas, no runtime dependencies. Every test is
written as the defect it prevents, in the shape that defect actually took: a substring match that missed the
records, a sleep that was a no-op, a role read from a header, an id counter shared by every tenant.

A module that cannot demonstrate its own failure mode is not prevention, it is just more code.
