"""Shared helpers for quality gates: locate roots, write machine-readable evidence."""

import json
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

PLATFORM_ROOT = Path(__file__).resolve().parents[2]
REPO_ROOT = PLATFORM_ROOT.parent
# ADR-012 (V003 review Finding 4): shipped evidence inside the package is
# immutable; verification-time evidence must never rewrite it. When
# AUMNITY_EVIDENCE_DIR is set (release-mode validation), all gate output goes
# there instead, keeping the released tree byte-identical and the release
# ladder idempotent.
_override = os.environ.get("AUMNITY_EVIDENCE_DIR")
EVIDENCE_DIR = Path(_override) if _override else PLATFORM_ROOT / "evidence"
GATES_DIR = PLATFORM_ROOT / "scripts" / "gates"


def write_evidence(gate: str, result: dict[str, Any]) -> None:
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    result = {"gate": gate, "generated_at": datetime.now(UTC).isoformat(), **result}
    (EVIDENCE_DIR / f"{gate}.json").write_text(json.dumps(result, indent=2) + "\n")
