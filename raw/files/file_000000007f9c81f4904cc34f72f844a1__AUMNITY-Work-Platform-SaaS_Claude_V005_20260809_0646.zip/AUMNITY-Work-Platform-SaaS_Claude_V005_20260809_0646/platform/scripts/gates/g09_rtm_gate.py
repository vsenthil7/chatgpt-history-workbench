#!/usr/bin/env python3
"""G09 — RTM gate: every ENFORCED requirement maps to real, collectable evidence.

Parses the authoritative RTM table. For rows with Status ENFORCED, the
Evidence/Test column must reference either pytest node prefixes (verified via
--collect-only) or gate evidence files (verified on disk after gates run).
"""

import re
import subprocess
import sys

from _common import PLATFORM_ROOT, REPO_ROOT, write_evidence

RTM_PATH = REPO_ROOT / "06-traceability" / "RTM.md"

# V002 review Finding 7: for tenancy/security requirements, broad file references
# must not masquerade as requirement proof. These rows must cite specific test
# node ids (file::test), each verified against pytest collection.
HIGH_RISK_IDS = {"DW-FR-013", "SaaS-002", "SaaS-003", "TEN-001", "TEN-002", "AUD-002", "AUD-003"}


def _resolves(reference: str) -> bool:
    """True iff pytest can collect the file or exact node id."""
    run = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "--collect-only",
            "-q",
            "-p",
            "no:cacheprovider",
            reference,
        ],
        cwd=PLATFORM_ROOT,
        capture_output=True,
        text=True,
        env={
            "PYTHONHASHSEED": "0",
            "PATH": "/usr/bin:/bin",
            "PYTHONPATH": "packages/aumnity_contracts/src:packages/aumnity_kernel/src",
        },
    )
    return run.returncode == 0


def main() -> int:
    rows = []
    for line in RTM_PATH.read_text().splitlines():
        if line.startswith("|") and not line.startswith("|--") and "Requirement" not in line:
            cells = [c.strip() for c in line.strip("|").split("|")]
            if len(cells) >= 6:
                rows.append({"id": cells[0], "evidence": cells[4], "status": cells[5]})
    failures = []
    resolution_cache: dict[str, bool] = {}
    checked = 0
    for row in rows:
        if row["status"] != "ENFORCED":
            continue
        checked += 1
        references = re.findall(r"`([^`]+)`", row["evidence"])
        if not references:
            failures.append(f"{row['id']}: ENFORCED but no evidence reference")
            continue
        if row["id"] in HIGH_RISK_IDS:
            node_refs = [r for r in references if "::" in r]
            if not node_refs:
                failures.append(
                    f"{row['id']}: high-risk requirement must cite specific "
                    "test node ids (file::test), not whole files"
                )
        for reference in references:
            if reference.startswith("tests/"):
                if reference not in resolution_cache:
                    resolution_cache[reference] = _resolves(reference)
                if not resolution_cache[reference]:
                    failures.append(f"{row['id']}: test reference not collectable: {reference}")
            elif reference.startswith("evidence/"):
                if not (PLATFORM_ROOT / reference).is_file():
                    failures.append(f"{row['id']}: evidence file missing: {reference}")
            elif reference.startswith("scripts/"):
                if not (PLATFORM_ROOT / reference).is_file():
                    failures.append(f"{row['id']}: gate script missing: {reference}")
            else:
                failures.append(f"{row['id']}: unrecognised evidence reference: {reference}")
    status = "PASS" if not failures else "FAIL"
    write_evidence(
        "g09_rtm",
        {
            "status": status,
            "rows_total": len(rows),
            "rows_enforced_checked": checked,
            "failures": failures,
        },
    )
    print(f"G09 {status}: {checked} ENFORCED rows checked, {len(failures)} failure(s)")
    for failure in failures:
        print(" -", failure)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
