#!/usr/bin/env python3
"""Run the full gate ladder in order, capturing evidence for each step.

Modes (V002 review Finding 8 — manifest ordering):
  build   — developer working tree. Step 0 verifies the INCOMING manifest and
            records the drift report as evidence WITHOUT failing (drift is
            expected while building), then runs G02..G10, then regenerates and
            verifies the manifest so it covers fresh evidence.
  release — clean checkout / extracted package. Step 0 incoming manifest
            verification MUST pass: a released tree that disagrees with its own
            manifest is a failed release. No regeneration is performed in
            release mode; the tree is validated exactly as shipped.
            ADR-012: release-mode gate output is written to an EXTERNAL
            evidence directory (AUMNITY_EVIDENCE_DIR; a temp dir by default),
            so verification never rewrites manifest-controlled shipped
            evidence — the release ladder is read-only over the tree and can
            be run any number of times, each ending in a passing G01.

Order: G01-incoming -> G02 static -> G03 unit -> G04 coverage -> G05 contract
-> G08 isolation -> G06 architecture -> G07 mutation -> G09 RTM -> G10 docs
-> (build mode only) G01 generate + verify.
G11 packaging is the release procedure itself: scripts/gates/g11_release.py.
"""

import os
import subprocess
import sys
import tempfile
from pathlib import Path

import _common
from _common import PLATFORM_ROOT

GATES_DIR = Path(__file__).resolve().parent


def _evidence_dir(mode: str) -> Path:
    if os.environ.get("AUMNITY_EVIDENCE_DIR"):
        return Path(os.environ["AUMNITY_EVIDENCE_DIR"])
    if mode == "release":
        external = Path(tempfile.mkdtemp(prefix="aumnity-release-evidence-"))
        print(f"release-mode evidence directory (external, ADR-012): {external}")
        return external
    return PLATFORM_ROOT / "evidence"


def _env() -> dict[str, str]:
    # PATH must include the running interpreter's bin dir so a bootstrapped
    # venv's tools are found (V002 review Finding 5).
    interpreter_bin = str(Path(sys.executable).resolve().parent)
    path = os.pathsep.join(dict.fromkeys([interpreter_bin, "/usr/local/bin", "/usr/bin", "/bin"]))
    env = {
        "PYTHONHASHSEED": "0",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PATH": path,
        "PYTHONPATH": "packages/aumnity_contracts/src:packages/aumnity_kernel/src",
        "HOME": os.environ.get("HOME", "/tmp"),
    }
    if os.environ.get("AUMNITY_EVIDENCE_DIR"):
        env["AUMNITY_EVIDENCE_DIR"] = os.environ["AUMNITY_EVIDENCE_DIR"]
    return env


def _run(name: str, command: list[str], evidence_file: str | None = None) -> dict[str, object]:
    run = subprocess.run(command, cwd=PLATFORM_ROOT, capture_output=True, text=True, env=_env())
    record: dict[str, object] = {
        "gate": name,
        "command": " ".join(command),
        "returncode": run.returncode,
        "status": "PASS" if run.returncode == 0 else "FAIL",
    }
    if evidence_file:
        _common.EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
        (_common.EVIDENCE_DIR / evidence_file).write_text(
            run.stdout + ("\n--- stderr ---\n" + run.stderr if run.stderr else "")
        )
        record["evidence"] = f"evidence/{evidence_file}"
    print(f"{name}: {record['status']}  ({record['command']})")
    return record


def main() -> int:
    mode = sys.argv[1] if len(sys.argv) > 1 else "build"
    if mode not in {"build", "release"}:
        print("usage: run_gates.py [build|release]")
        return 2
    evidence_dir = _evidence_dir(mode)
    os.environ["AUMNITY_EVIDENCE_DIR"] = str(evidence_dir)
    _common.EVIDENCE_DIR = evidence_dir
    py = sys.executable
    results: list[dict[str, object]] = []

    incoming = _run(
        "G01-incoming-verify",
        [py, str(GATES_DIR / "g01_validate_package.py")],
        "g01_incoming.txt",
    )
    if mode == "release":
        results.append(incoming)
    else:
        # Build mode: record honestly, do not gate on expected working drift —
        # but the drift report is evidence a reviewer can inspect.
        incoming["status"] = f"RECORDED({incoming['status']})"
        results.append(incoming)

    results += [
        _run(
            "G02-ruff-lint",
            [py, "-m", "ruff", "check", "packages", "tests", "scripts"],
            "g02_ruff_lint.txt",
        ),
        _run(
            "G02-ruff-format",
            [py, "-m", "ruff", "format", "--check", "packages", "tests"],
            "g02_ruff_format.txt",
        ),
        _run("G02-mypy", [py, "-m", "mypy"], "g02_mypy.txt"),
        _run(
            "G03-unit",
            [py, "-m", "pytest", "tests/unit", "-q", "-p", "no:cacheprovider"],
            "g03_unit.txt",
        ),
        _run(
            "G04-coverage",
            [
                py,
                "-m",
                "pytest",
                "-q",
                "-p",
                "no:cacheprovider",
                "--cov",
                "--cov-report=term-missing",
                f"--cov-report=json:{evidence_dir}/g04_coverage.json",
            ],
            "g04_coverage.txt",
        ),
        _run(
            "G05-contract",
            [py, "-m", "pytest", "tests/contract", "-q", "-p", "no:cacheprovider"],
            "g05_contract.txt",
        ),
        _run(
            "G08-isolation",
            [py, "-m", "pytest", "tests/isolation", "-q", "-p", "no:cacheprovider"],
            "g08_isolation.txt",
        ),
        _run("G06-architecture", [py, str(GATES_DIR / "g06_architecture_guard.py")]),
        _run("G07-mutation", [py, str(GATES_DIR / "g07_mutation_gate.py")]),
        _run("G09-rtm", [py, str(GATES_DIR / "g09_rtm_gate.py")]),
        _run("G10-docs", [py, str(GATES_DIR / "g10_docs_gate.py")]),
    ]
    if mode == "build":
        results += [
            _run(
                "G01-manifest-generate",
                [py, str(GATES_DIR / "g01_validate_package.py"), "generate"],
            ),
            _run("G01-manifest-verify", [py, str(GATES_DIR / "g01_validate_package.py")]),
        ]

    gating = [r for r in results if not str(r["status"]).startswith("RECORDED")]
    overall = "PASS" if all(r["status"] == "PASS" for r in gating) else "FAIL"
    _common.write_evidence("gate_ladder", {"status": overall, "mode": mode, "results": results})
    print(f"\nGATE LADDER ({mode}): {overall}")
    return 0 if overall == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
