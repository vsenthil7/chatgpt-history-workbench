"""Domain event envelope shared by all platform modules.

Events carry the organisation boundary explicitly and are immutable.
Payload values are restricted to strings to keep envelopes serialisable and
schema-stable; richer payloads belong in module-owned event schemas layered on
top of this envelope.

ADR-008: the payload is defensively copied into a read-only mapping proxy at
construction, so no caller — including one holding a reference obtained before
or after audit recording — can alter a recorded event (V002 review Finding 3).
"""

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime
from types import MappingProxyType

from aumnity_contracts.errors import ValidationError
from aumnity_contracts.ids import OrganisationId, PrincipalId, require_identifier


@dataclass(frozen=True, slots=True)
class EventEnvelope:
    """Immutable record of one domain occurrence."""

    event_type: str
    organisation_id: OrganisationId
    actor_principal_id: PrincipalId
    subject_id: str
    subject_version: int
    occurred_at: datetime
    payload: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        require_identifier(self.event_type, "event_type")
        require_identifier(self.organisation_id, "organisation_id")
        require_identifier(self.actor_principal_id, "actor_principal_id")
        require_identifier(self.subject_id, "subject_id")
        if self.subject_version < 1:
            raise ValidationError("subject_version must be >= 1")
        for key, value in self.payload.items():
            if not isinstance(key, str) or not isinstance(value, str):
                raise ValidationError("payload keys and values must be strings")
        # Defensive private copy behind a read-only view: mutating the mapping
        # the caller passed in, or the mapping this envelope exposes, can never
        # change recorded history.
        object.__setattr__(self, "payload", MappingProxyType(dict(self.payload)))
