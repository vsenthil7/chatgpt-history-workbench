"""Deterministic fixtures: injected clock and sequential ids; no real time, no randomness."""

import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
for pkg in ("aumnity_contracts", "aumnity_kernel"):
    sys.path.insert(0, str(_ROOT / "packages" / pkg / "src"))

import pytest  # noqa: E402
from aumnity_contracts import SequenceIdGenerator, TenantContext, TickingClock  # noqa: E402
from aumnity_kernel import AuditLog, CriticalWorkEvidencePolicy  # noqa: E402
from aumnity_kernel.adapters.memory import (  # noqa: E402
    InMemoryAuditSink,
    InMemoryEvidenceRepository,
    InMemoryOrganisationRepository,
    InMemoryPrincipalRepository,
    InMemoryTenantProvisioner,
    InMemoryWorkObjectRepository,
)
from aumnity_kernel.identity import PrincipalKind  # noqa: E402
from aumnity_kernel.organisation import (  # noqa: E402
    OrganisationDirectory,
    PlatformProvisioning,
)
from aumnity_kernel.workobject.service import WorkObjectRegistry  # noqa: E402


@pytest.fixture()
def clock() -> TickingClock:
    return TickingClock()


@pytest.fixture()
def ids() -> SequenceIdGenerator:
    return SequenceIdGenerator()


@pytest.fixture()
def audit_sink() -> InMemoryAuditSink:
    return InMemoryAuditSink()


@pytest.fixture()
def directory(clock: TickingClock, ids: SequenceIdGenerator) -> OrganisationDirectory:
    """Published tenant-protected service (ADR-013); shares stores with provisioning."""
    return OrganisationDirectory(
        organisations=InMemoryOrganisationRepository(),
        principals=InMemoryPrincipalRepository(),
        clock=clock,
        ids=ids,
    )


@pytest.fixture()
def provisioning(
    directory: OrganisationDirectory, clock: TickingClock, ids: SequenceIdGenerator
) -> PlatformProvisioning:
    """Trusted platform-admin boundary (ADR-013); NOT part of the published API."""
    return PlatformProvisioning(
        provisioner=InMemoryTenantProvisioner(
            directory._organisations,  # adapter composition: shared concrete stores
            directory._principals,
        ),
        clock=clock,
        ids=ids,
    )


@pytest.fixture()
def audit(audit_sink: InMemoryAuditSink, directory: OrganisationDirectory) -> AuditLog:
    return AuditLog(audit_sink, principals=directory)


@pytest.fixture()
def registry(
    clock: TickingClock,
    ids: SequenceIdGenerator,
    audit: AuditLog,
    directory: OrganisationDirectory,
) -> WorkObjectRegistry:
    return WorkObjectRegistry(
        work_objects=InMemoryWorkObjectRepository(),
        evidence=InMemoryEvidenceRepository(),
        audit=audit,
        completion_policy=CriticalWorkEvidencePolicy(),
        principals=directory,
        clock=clock,
        ids=ids,
    )


@pytest.fixture()
def tenant_a(provisioning: PlatformProvisioning) -> TenantContext:
    org, founder = provisioning.create_organisation(
        "Alpha Fixture Org", "Alpha Founder", PrincipalKind.HUMAN
    )
    return TenantContext(org.organisation_id, founder.principal_id)


@pytest.fixture()
def tenant_b(provisioning: PlatformProvisioning) -> TenantContext:
    org, founder = provisioning.create_organisation(
        "Beta Fixture Org", "Beta Founder", PrincipalKind.HUMAN
    )
    return TenantContext(org.organisation_id, founder.principal_id)
