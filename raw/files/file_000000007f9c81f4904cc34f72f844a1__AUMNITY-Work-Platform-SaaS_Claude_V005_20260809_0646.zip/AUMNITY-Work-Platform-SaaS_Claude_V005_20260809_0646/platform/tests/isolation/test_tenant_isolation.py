"""Tenant isolation and cross-tenant denial tests (RTM: SaaS-001/SaaS-002, DW-FR-013).

Gate G08 evidence: every protected read/write path denies cross-tenant access.
"""

from datetime import UTC, datetime

import pytest
from aumnity_contracts import (
    EventEnvelope,
    NotFoundError,
    OrganisationId,
    PrincipalId,
    SequenceIdGenerator,
    TenantContext,
    TenantIsolationError,
    TickingClock,
    ValidationError,
    WorkObjectId,
)
from aumnity_kernel import AuditLog
from aumnity_kernel.adapters.memory import (
    InMemoryOrganisationRepository,
    InMemoryPrincipalRepository,
    InMemoryTenantProvisioner,
)
from aumnity_kernel.evidence import EvidenceKind
from aumnity_kernel.identity import Principal, PrincipalKind
from aumnity_kernel.organisation import (
    Organisation,
    OrganisationDirectory,
    PlatformProvisioning,
)
from aumnity_kernel.workobject.model import Priority, RiskLevel
from aumnity_kernel.workobject.service import WorkObjectRegistry

pytestmark = pytest.mark.isolation


def _create(registry: WorkObjectRegistry, tenant: TenantContext) -> WorkObjectId:
    return registry.create(
        tenant,
        title="Alpha-only record",
        purpose="Isolation subject",
        work_type="generic.task",
        priority=Priority.NORMAL,
        risk_level=RiskLevel.LOW,
        owner_id=tenant.principal_id,
    ).work_object_id


def test_cross_tenant_read_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.get(tenant_b, wid)


def test_cross_tenant_transition_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.mark_ready(tenant_b, wid)


def test_cross_tenant_evidence_attachment_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.attach_evidence(
            tenant_b,
            wid,
            kind=EvidenceKind.DOCUMENT,
            uri="evidence/steal.pdf",
            content_sha256="feed",
            source_system="MANUAL",
            source_reference="steal-1",
        )


def test_cross_tenant_decomposition_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    parent = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.create(
            tenant_b,
            title="Hostile child",
            purpose="Attach to foreign parent",
            work_type="generic.task",
            priority=Priority.NORMAL,
            risk_level=RiskLevel.LOW,
            owner_id=tenant_b.principal_id,
            parent_id=parent,
        )


def test_cross_tenant_children_listing_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    parent = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.children(tenant_b, parent)


def test_cross_tenant_evidence_listing_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.evidence_for(tenant_b, wid)


def test_audit_trail_is_tenant_filtered(
    registry: WorkObjectRegistry,
    tenant_a: TenantContext,
    tenant_b: TenantContext,
    audit: AuditLog,
) -> None:
    _create(registry, tenant_a)
    _create(registry, tenant_b)
    a_entries = audit.entries_for(tenant_a)
    b_entries = audit.entries_for(tenant_b)
    assert {e.organisation_id for e in a_entries} == {tenant_a.organisation_id}
    assert {e.organisation_id for e in b_entries} == {tenant_b.organisation_id}


def test_unknown_id_is_not_found_not_isolation(
    registry: WorkObjectRegistry, tenant_a: TenantContext
) -> None:
    """ADR-006: distinct internal types; edge maps both to one external shape."""
    with pytest.raises(NotFoundError):
        registry.get(tenant_a, WorkObjectId("wob-never-existed"))


class TestPrincipalBindingRegression:
    """Regressions for V002 review Findings 1 and 2 (ChatGPT, 2026-08-08).

    ChatGPT reproduced foreign owner/assignee acceptance and mismatched
    TenantContext acceptance against the delivered V002 package. Every exploit
    reproduced there must fail here permanently.
    """

    def test_foreign_owner_rejected(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        with pytest.raises(TenantIsolationError):
            registry.create(
                tenant_a,
                title="Injection attempt",
                purpose="owner from another organisation",
                work_type="TASK",
                priority=Priority.NORMAL,
                risk_level=RiskLevel.LOW,
                owner_id=tenant_b.principal_id,
            )

    def test_foreign_assignee_rejected(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        wid = _create(registry, tenant_a)
        registry.mark_ready(tenant_a, wid)
        registry.mark_assignable(tenant_a, wid)
        with pytest.raises(TenantIsolationError):
            registry.assign(tenant_a, wid, tenant_b.principal_id)
        # denial left no partial state behind
        assert registry.get(tenant_a, wid).assignee_id is None

    def test_mismatched_context_principal_rejected_on_create(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            registry.create(
                forged,
                title="Forged context",
                purpose="principal from another organisation",
                work_type="TASK",
                priority=Priority.NORMAL,
                risk_level=RiskLevel.LOW,
                owner_id=tenant_b.principal_id,
            )

    def test_cross_tenant_acting_principal_rejected_on_read(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        wid = _create(registry, tenant_a)
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            registry.get(forged, wid)

    def test_unknown_acting_principal_rejected(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        ghost = TenantContext(tenant_a.organisation_id, PrincipalId("prn-nonexistent"))
        with pytest.raises(TenantIsolationError):
            registry.get(ghost, WorkObjectId("wob-000001"))

    def test_same_tenant_owner_and_assignee_accepted(
        self,
        registry: WorkObjectRegistry,
        directory: OrganisationDirectory,
        tenant_a: TenantContext,
    ) -> None:
        colleague = directory.create_principal(tenant_a, PrincipalKind.HUMAN, "Colleague")
        wo = registry.create(
            tenant_a,
            title="Legitimate work",
            purpose="same-organisation principals",
            work_type="TASK",
            priority=Priority.NORMAL,
            risk_level=RiskLevel.LOW,
            owner_id=colleague.principal_id,
        )
        registry.mark_ready(tenant_a, wo.work_object_id)
        registry.mark_assignable(tenant_a, wo.work_object_id)
        assigned = registry.assign(tenant_a, wo.work_object_id, colleague.principal_id)
        assert assigned.owner_id == colleague.principal_id
        assert assigned.assignee_id == colleague.principal_id

    def test_rejected_operation_writes_no_audit_event(
        self,
        registry: WorkObjectRegistry,
        audit: AuditLog,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        """Audit actor can never be foreign: binding fails before any emit."""
        before = len(audit.entries_for(tenant_a))
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            registry.create(
                forged,
                title="No audit trace expected",
                purpose="rejected before emit",
                work_type="TASK",
                priority=Priority.NORMAL,
                risk_level=RiskLevel.LOW,
                owner_id=tenant_a.principal_id,
            )
        entries = audit.entries_for(tenant_a)
        assert len(entries) == before
        member_ids = {tenant_a.principal_id}
        assert all(e.actor_principal_id in member_ids for e in entries)


class TestAuditImmutabilityRegression:
    """Regression for V002 review Finding 3: recorded history cannot be tampered."""

    def test_recorded_payload_rejects_mutation(
        self, registry: WorkObjectRegistry, audit: AuditLog, tenant_a: TenantContext
    ) -> None:
        wid = _create(registry, tenant_a)
        registry.mark_ready(tenant_a, wid)
        entry = audit.entries_for(tenant_a)[0]
        with pytest.raises(TypeError):
            entry.payload["k"] = "tampered"  # type: ignore[index]
        assert "k" not in audit.entries_for(tenant_a)[0].payload

    def test_caller_supplied_payload_dict_is_decoupled(self, tenant_a: TenantContext) -> None:
        source = {"key": "original"}
        event = EventEnvelope(
            event_type="Probe",
            organisation_id=tenant_a.organisation_id,
            actor_principal_id=tenant_a.principal_id,
            subject_id="wob-000001",
            subject_version=1,
            occurred_at=datetime(2026, 1, 1, tzinfo=UTC),
            payload=source,
        )
        source["key"] = "tampered"
        source["new"] = "injected"
        assert dict(event.payload) == {"key": "original"}


class TestAuditBoundaryRegression:
    """Regressions for V003 review Findings 1–2 (ChatGPT, 2026-08-08 23:01).

    The published AuditLog is a protected boundary (ADR-010): forged contexts
    can neither read nor write, and an audit actor can never be foreign AT THIS
    BOUNDARY, not merely for events emitted via WorkObjectRegistry.
    """

    @staticmethod
    def _event(org: TenantContext, actor: PrincipalId, event_type: str = "Probe") -> EventEnvelope:
        return EventEnvelope(
            event_type=event_type,
            organisation_id=org.organisation_id,
            actor_principal_id=actor,
            subject_id="wob-000001",
            subject_version=1,
            occurred_at=datetime(2026, 1, 1, tzinfo=UTC),
        )

    def test_forged_context_audit_read_rejected(
        self,
        registry: WorkObjectRegistry,
        audit: AuditLog,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        """The exact V003 exploit: TenantContext(Org-A, Principal-B) read Org-A history."""
        _create(registry, tenant_a)
        assert len(audit.entries_for(tenant_a)) == 1  # legitimate read works
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            audit.entries_for(forged)

    def test_foreign_actor_audit_write_rejected(
        self, audit: AuditLog, tenant_a: TenantContext, tenant_b: TenantContext
    ) -> None:
        """The exact V003 exploit: Org-A event carrying Org-B's principal as actor.

        Under ADR-014 the attribution rule (actor == bound acting principal)
        rejects this before any membership question arises: a foreign actor can
        never equal a proven member, so the denial subsumes isolation.
        """
        injected = self._event(tenant_a, tenant_b.principal_id, "Injected")
        with pytest.raises(ValidationError, match="must be the acting principal"):
            audit.record(tenant_a, injected)
        assert audit.entries_for(tenant_a) == ()

    def test_unknown_actor_audit_write_rejected(
        self, audit: AuditLog, tenant_a: TenantContext
    ) -> None:
        with pytest.raises(ValidationError, match="must be the acting principal"):
            audit.record(tenant_a, self._event(tenant_a, PrincipalId("prn-nonexistent")))
        assert audit.entries_for(tenant_a) == ()

    def test_forged_context_audit_write_rejected(
        self, audit: AuditLog, tenant_a: TenantContext, tenant_b: TenantContext
    ) -> None:
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            audit.record(forged, self._event(tenant_a, tenant_a.principal_id))
        assert audit.entries_for(tenant_a) == ()

    def test_cross_organisation_event_write_rejected(
        self, audit: AuditLog, tenant_a: TenantContext, tenant_b: TenantContext
    ) -> None:
        """A member of Org-A cannot record an event stamped for Org-B."""
        with pytest.raises(TenantIsolationError):
            audit.record(tenant_a, self._event(tenant_b, tenant_b.principal_id))
        assert audit.entries_for(tenant_b) == ()

    def test_valid_same_tenant_write_and_read(
        self,
        audit: AuditLog,
        directory: OrganisationDirectory,
        tenant_a: TenantContext,
    ) -> None:
        """ADR-014: a principal records AS ITSELF under its own context."""
        colleague = directory.create_principal(tenant_a, PrincipalKind.SERVICE, "Recorder")
        colleague_context = TenantContext(tenant_a.organisation_id, colleague.principal_id)
        audit.record(
            colleague_context,
            self._event(colleague_context, colleague.principal_id, "ServiceEvent"),
        )
        entries = audit.entries_for(tenant_a)
        assert [e.event_type for e in entries] == ["ServiceEvent"]
        assert entries[0].actor_principal_id == colleague.principal_id

    def test_same_tenant_actor_impersonation_rejected(
        self,
        audit: AuditLog,
        directory: OrganisationDirectory,
        tenant_a: TenantContext,
    ) -> None:
        """The exact V004 review Finding 3 scenario: founder context, colleague actor."""
        colleague = directory.create_principal(tenant_a, PrincipalKind.SERVICE, "Recorder")
        with pytest.raises(ValidationError, match="must be the acting principal"):
            audit.record(tenant_a, self._event(tenant_a, colleague.principal_id, "Forged"))
        assert audit.entries_for(tenant_a) == ()

    def test_no_cross_tenant_event_disclosure(
        self,
        registry: WorkObjectRegistry,
        audit: AuditLog,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        _create(registry, tenant_a)
        _create(registry, tenant_b)
        for context in (tenant_a, tenant_b):
            entries = audit.entries_for(context)
            assert entries
            assert {e.organisation_id for e in entries} == {context.organisation_id}


class TestTenantBootstrapAtomicityRegression:
    """Regressions for V003 Finding 3 and V004 Finding 2 (ADR-011).

    All four failure shapes ChatGPT demanded: each store failing BEFORE and
    AFTER its own write. After any failure, observers must see neither an
    organisation nor a principal.
    """

    @staticmethod
    def _bootstrap_under(
        organisations: InMemoryOrganisationRepository,
        principals: InMemoryPrincipalRepository,
        clock: TickingClock,
        ids: SequenceIdGenerator,
    ) -> PlatformProvisioning:
        return PlatformProvisioning(
            provisioner=InMemoryTenantProvisioner(organisations, principals),
            clock=clock,
            ids=ids,
        )

    @staticmethod
    def _assert_no_partial_tenant(
        organisations: InMemoryOrganisationRepository,
        principals: InMemoryPrincipalRepository,
    ) -> None:
        assert organisations.get(OrganisationId("org-000001")) is None
        assert principals.get(PrincipalId("prn-000002")) is None

    @pytest.mark.parametrize("when", ["before write", "after write"])
    def test_principal_store_failure_leaves_no_partial_tenant(
        self, clock: TickingClock, ids: SequenceIdGenerator, when: str
    ) -> None:
        organisations = InMemoryOrganisationRepository()

        class FailingPrincipalRepository(InMemoryPrincipalRepository):
            def add(self, principal: Principal) -> None:
                if when == "after write":
                    super().add(principal)  # the harder V004-review shape
                raise RuntimeError(f"principal persistence failed {when}")

        principals = FailingPrincipalRepository()
        provisioning = self._bootstrap_under(organisations, principals, clock, ids)
        with pytest.raises(RuntimeError, match="principal persistence failed"):
            provisioning.create_organisation("Doomed Org", "Doomed Founder", PrincipalKind.HUMAN)
        self._assert_no_partial_tenant(organisations, principals)

    @pytest.mark.parametrize("when", ["before write", "after write"])
    def test_organisation_store_failure_leaves_no_partial_tenant(
        self, clock: TickingClock, ids: SequenceIdGenerator, when: str
    ) -> None:
        class FailingOrganisationRepository(InMemoryOrganisationRepository):
            def add(self, organisation: Organisation) -> None:
                if when == "after write":
                    super().add(organisation)
                raise RuntimeError(f"organisation persistence failed {when}")

        organisations = FailingOrganisationRepository()
        principals = InMemoryPrincipalRepository()
        provisioning = self._bootstrap_under(organisations, principals, clock, ids)
        with pytest.raises(RuntimeError, match="organisation persistence failed"):
            provisioning.create_organisation("Doomed Org", "Doomed Founder", PrincipalKind.HUMAN)
        self._assert_no_partial_tenant(organisations, principals)

    def test_successful_bootstrap_persists_both(
        self, provisioning: PlatformProvisioning, directory: OrganisationDirectory
    ) -> None:
        org, founder = provisioning.create_organisation(
            "Whole Org", "Whole Founder", PrincipalKind.HUMAN
        )
        context = TenantContext(org.organisation_id, founder.principal_id)
        assert directory.get_organisation(context) == org
        assert directory.require_member(context, founder.principal_id) == founder


class TestOrganisationBoundaryRegression:
    """Regression for V004 review Finding 1: cross-tenant organisation metadata."""

    def test_cross_tenant_organisation_read_impossible_by_construction(
        self, directory: OrganisationDirectory, tenant_a: TenantContext
    ) -> None:
        """The published surface has NO arbitrary-id organisation lookup at all;
        `get_organisation` takes only a bound TenantContext."""
        import inspect

        parameters = list(inspect.signature(directory.get_organisation).parameters)
        assert parameters == ["context"]
        assert directory.get_organisation(tenant_a).organisation_id == tenant_a.organisation_id

    def test_forged_context_organisation_read_rejected(
        self,
        directory: OrganisationDirectory,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            directory.get_organisation(forged)

    def test_trusted_provisioning_is_not_published(self) -> None:
        import aumnity_kernel

        assert "PlatformProvisioning" not in aumnity_kernel.__all__
        assert "OrganisationRegistry" not in aumnity_kernel.__all__
