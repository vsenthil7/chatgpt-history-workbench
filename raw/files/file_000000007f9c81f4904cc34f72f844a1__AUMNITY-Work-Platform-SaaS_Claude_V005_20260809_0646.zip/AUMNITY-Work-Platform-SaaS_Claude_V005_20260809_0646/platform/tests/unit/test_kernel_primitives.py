"""Unit tests for organisation, identity, evidence, audit, policy, adapters."""

from datetime import UTC, datetime

import pytest
from aumnity_contracts import (
    EventEnvelope,
    EvidenceId,
    OrganisationId,
    PrincipalId,
    TenantContext,
    TenantIsolationError,
    ValidationError,
    WorkObjectId,
)
from aumnity_kernel import AuditLog, CriticalWorkEvidencePolicy
from aumnity_kernel.adapters.memory import InMemoryWorkObjectRepository
from aumnity_kernel.evidence import EvidenceKind, EvidenceRecord
from aumnity_kernel.identity import Principal, PrincipalKind
from aumnity_kernel.organisation import (
    Organisation,
    OrganisationDirectory,
    PlatformProvisioning,
)
from aumnity_kernel.workobject.model import Priority, RiskLevel, WorkObject
from aumnity_kernel.workobject.state import WorkObjectState

_NOW = datetime(2026, 1, 1, tzinfo=UTC)


def _work_object(risk: RiskLevel, evidence: tuple[EvidenceId, ...] = ()) -> WorkObject:
    return WorkObject(
        work_object_id=WorkObjectId("wob-1"),
        organisation_id=OrganisationId("org-1"),
        title="Title",
        purpose="Purpose",
        work_type="generic.task",
        state=WorkObjectState.APPROVED,
        priority=Priority.NORMAL,
        risk_level=risk,
        requester_id=PrincipalId("prn-1"),
        owner_id=PrincipalId("prn-1"),
        created_at=_NOW,
        updated_at=_NOW,
        evidence_ids=evidence,
    )


class TestOrganisationServices:
    def test_provision_then_read_own_organisation(
        self, provisioning: PlatformProvisioning, directory: OrganisationDirectory
    ) -> None:
        org, founder = provisioning.create_organisation(
            "Example Org", "Founding Operator", PrincipalKind.HUMAN
        )
        context = TenantContext(org.organisation_id, founder.principal_id)
        assert directory.get_organisation(context) == org

    def test_create_organisation_creates_member_founder(
        self, provisioning: PlatformProvisioning, directory: OrganisationDirectory
    ) -> None:
        org, founder = provisioning.create_organisation(
            "Example Org", "Founding Operator", PrincipalKind.HUMAN
        )
        context = TenantContext(org.organisation_id, founder.principal_id)
        assert directory.require_member(context, founder.principal_id) == founder

    def test_organisation_validation(self) -> None:
        with pytest.raises(ValidationError):
            Organisation(OrganisationId("org-1"), "", _NOW)

    def test_create_principal_requires_member_acting_principal(
        self,
        directory: OrganisationDirectory,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            directory.create_principal(forged, PrincipalKind.HUMAN, "Intruder")

    def test_create_principal_with_unknown_context_rejected(
        self, directory: OrganisationDirectory
    ) -> None:
        ghost = TenantContext(OrganisationId("org-ghost"), PrincipalId("prn-x"))
        with pytest.raises(TenantIsolationError):
            directory.create_principal(ghost, PrincipalKind.HUMAN, "Nobody")

    def test_require_member_success(
        self, directory: OrganisationDirectory, tenant_a: TenantContext
    ) -> None:
        principal = directory.require_member(tenant_a, tenant_a.principal_id)
        assert principal.organisation_id == tenant_a.organisation_id

    def test_require_member_unknown_is_isolation_error(
        self, directory: OrganisationDirectory, tenant_a: TenantContext
    ) -> None:
        # Unknown and foreign principals raise the SAME error so principal
        # existence in other tenants cannot be probed (ADR-007).
        with pytest.raises(TenantIsolationError, match="not accessible"):
            directory.require_member(tenant_a, PrincipalId("prn-missing"))

    def test_require_member_cross_organisation_rejected(
        self,
        directory: OrganisationDirectory,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        with pytest.raises(TenantIsolationError, match="not accessible"):
            directory.require_member(tenant_a, tenant_b.principal_id)


class TestPrincipal:
    def test_validation_rejects_blank_display_name(self) -> None:
        with pytest.raises(ValidationError):
            Principal(
                PrincipalId("prn-1"),
                OrganisationId("org-1"),
                PrincipalKind.AI,
                "",
            )

    def test_kinds_cover_human_ai_service(self) -> None:
        assert {kind.value for kind in PrincipalKind} == {"HUMAN", "AI", "SERVICE"}


class TestEvidenceRecord:
    def test_validation_rejects_blank_uri(self) -> None:
        with pytest.raises(ValidationError):
            EvidenceRecord(
                evidence_id=EvidenceId("evd-1"),
                organisation_id=OrganisationId("org-1"),
                work_object_id=WorkObjectId("wob-1"),
                kind=EvidenceKind.DOCUMENT,
                uri="",
                content_sha256="abc",
                submitted_by=PrincipalId("prn-1"),
                submitted_at=_NOW,
                source_system="MANUAL",
                source_reference="ref-1",
            )

    def test_record_is_immutable(self) -> None:
        record = EvidenceRecord(
            evidence_id=EvidenceId("evd-1"),
            organisation_id=OrganisationId("org-1"),
            work_object_id=WorkObjectId("wob-1"),
            kind=EvidenceKind.TEST_RESULT,
            uri="evidence/report.json",
            content_sha256="abc",
            submitted_by=PrincipalId("prn-1"),
            submitted_at=_NOW,
            source_system="MANUAL",
            source_reference="ref-1",
        )
        with pytest.raises(AttributeError):
            record.uri = "other"  # type: ignore[misc]


class TestCompletionPolicy:
    def test_critical_without_evidence_violates(self) -> None:
        policy = CriticalWorkEvidencePolicy()
        violations = policy.violations(_work_object(RiskLevel.CRITICAL))
        assert violations == ("critical work object requires at least one evidence record",)

    def test_critical_with_evidence_passes(self) -> None:
        policy = CriticalWorkEvidencePolicy()
        assert policy.violations(_work_object(RiskLevel.CRITICAL, (EvidenceId("evd-1"),))) == ()

    @pytest.mark.parametrize("risk", [RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH])
    def test_non_critical_without_evidence_passes(self, risk: RiskLevel) -> None:
        assert CriticalWorkEvidencePolicy().violations(_work_object(risk)) == ()


class TestWorkObjectModel:
    def test_version_below_one_rejected(self) -> None:
        with pytest.raises(ValidationError, match="version"):
            WorkObject(
                work_object_id=WorkObjectId("wob-1"),
                organisation_id=OrganisationId("org-1"),
                title="T",
                purpose="P",
                work_type="generic.task",
                state=WorkObjectState.DRAFT,
                priority=Priority.LOW,
                risk_level=RiskLevel.LOW,
                requester_id=PrincipalId("prn-1"),
                owner_id=PrincipalId("prn-1"),
                created_at=_NOW,
                updated_at=_NOW,
                version=0,
            )


class TestAuditLog:
    """AuditLog is a protected boundary (ADR-010): tenant-bound reads AND writes."""

    @staticmethod
    def _event(context: TenantContext) -> EventEnvelope:
        return EventEnvelope(
            event_type="WorkObjectCreated",
            organisation_id=context.organisation_id,
            actor_principal_id=context.principal_id,
            subject_id="wob-1",
            subject_version=1,
            occurred_at=_NOW,
        )

    def test_entries_are_tenant_filtered(
        self, audit: AuditLog, tenant_a: TenantContext, tenant_b: TenantContext
    ) -> None:
        audit.record(tenant_a, self._event(tenant_a))
        audit.record(tenant_b, self._event(tenant_b))
        entries = audit.entries_for(tenant_a)
        assert len(entries) == 1
        assert entries[0].organisation_id == tenant_a.organisation_id


class TestInMemoryWorkObjectRepository:
    def test_get_unknown_returns_none(self) -> None:
        assert InMemoryWorkObjectRepository().get(WorkObjectId("wob-x")) is None

    def test_save_and_get_return_defensive_copies(self) -> None:
        repo = InMemoryWorkObjectRepository()
        original = _work_object(RiskLevel.LOW)
        repo.save(original)
        original.title = "mutated after save"
        loaded = repo.get(original.work_object_id)
        assert loaded is not None
        assert loaded.title == "Title"
        loaded.title = "mutated after load"
        reloaded = repo.get(original.work_object_id)
        assert reloaded is not None
        assert reloaded.title == "Title"

    def test_children_of_filters_by_parent(self) -> None:
        repo = InMemoryWorkObjectRepository()
        parent = _work_object(RiskLevel.LOW)
        repo.save(parent)
        child = _work_object(RiskLevel.LOW)
        child.work_object_id = WorkObjectId("wob-2")
        child.parent_id = parent.work_object_id
        repo.save(child)
        children = tuple(repo.children_of(parent.work_object_id))
        assert [c.work_object_id for c in children] == ["wob-2"]
