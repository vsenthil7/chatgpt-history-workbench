"""Unit tests for aumnity_contracts (RTM: ARC-002, SaaS-002 foundations)."""

from datetime import UTC, datetime

import pytest
from aumnity_contracts import (
    EventEnvelope,
    InvalidTransitionError,
    NotFoundError,
    OrganisationId,
    PlatformError,
    PolicyViolationError,
    PrincipalId,
    SequenceIdGenerator,
    TenantContext,
    TenantIsolationError,
    TickingClock,
    ValidationError,
    require_identifier,
)
from aumnity_contracts.source_systems import SOURCE_SYSTEM_URAIFLOW


class TestRequireIdentifier:
    def test_valid_identifier_is_returned_unchanged(self) -> None:
        assert require_identifier("org-1", "field") == "org-1"

    def test_non_string_rejected(self) -> None:
        with pytest.raises(ValidationError, match="must be a string"):
            require_identifier(123, "field")  # type: ignore[arg-type]

    def test_empty_rejected(self) -> None:
        with pytest.raises(ValidationError, match="non-empty"):
            require_identifier("", "field")

    def test_whitespace_only_rejected(self) -> None:
        with pytest.raises(ValidationError, match="non-empty"):
            require_identifier("   ", "field")

    def test_surrounding_whitespace_rejected(self) -> None:
        with pytest.raises(ValidationError, match="surrounding whitespace"):
            require_identifier(" org-1", "field")

    def test_over_length_rejected(self) -> None:
        with pytest.raises(ValidationError, match="128"):
            require_identifier("x" * 129, "field")

    def test_max_length_accepted(self) -> None:
        assert require_identifier("x" * 128, "field") == "x" * 128


class TestErrorTaxonomy:
    @pytest.mark.parametrize(
        "error_type",
        [
            ValidationError,
            NotFoundError,
            TenantIsolationError,
            InvalidTransitionError,
            PolicyViolationError,
        ],
    )
    def test_all_errors_are_platform_errors(self, error_type: type[Exception]) -> None:
        assert issubclass(error_type, PlatformError)


class TestTenantContext:
    def test_valid_context(self) -> None:
        ctx = TenantContext(OrganisationId("org-1"), PrincipalId("prn-1"))
        assert ctx.organisation_id == "org-1"
        assert ctx.principal_id == "prn-1"

    def test_invalid_organisation_rejected(self) -> None:
        with pytest.raises(ValidationError):
            TenantContext(OrganisationId(""), PrincipalId("prn-1"))

    def test_context_is_immutable(self) -> None:
        ctx = TenantContext(OrganisationId("org-1"), PrincipalId("prn-1"))
        with pytest.raises(AttributeError):
            ctx.organisation_id = OrganisationId("org-2")  # type: ignore[misc]


class TestEventEnvelope:
    def _envelope(self, version: int = 1) -> EventEnvelope:
        return EventEnvelope(
            event_type="WorkObjectCreated",
            organisation_id=OrganisationId("org-1"),
            actor_principal_id=PrincipalId("prn-1"),
            subject_id="wob-1",
            subject_version=version,
            occurred_at=datetime(2026, 1, 1, tzinfo=UTC),
        )

    def test_valid_envelope_defaults_empty_payload(self) -> None:
        assert self._envelope().payload == {}

    def test_version_below_one_rejected(self) -> None:
        with pytest.raises(ValidationError, match="subject_version"):
            self._envelope(version=0)

    def test_envelope_is_immutable(self) -> None:
        event = self._envelope()
        with pytest.raises(AttributeError):
            event.event_type = "Other"  # type: ignore[misc]


class TestProviders:
    def test_ticking_clock_is_deterministic(self) -> None:
        clock = TickingClock()
        first, second = clock.now(), clock.now()
        assert (second - first).total_seconds() == 1
        assert first == datetime(2026, 1, 1, tzinfo=UTC)

    def test_ticking_clock_custom_start_and_step(self) -> None:
        start = datetime(2030, 6, 1, tzinfo=UTC)
        clock = TickingClock(start=start, step_seconds=60)
        assert clock.now() == start
        assert (clock.now() - start).total_seconds() == 60

    def test_sequence_id_generator(self) -> None:
        ids = SequenceIdGenerator()
        assert ids.new_id("wob") == "wob-000001"
        assert ids.new_id("wob") == "wob-000002"
        assert ids.new_id("org") == "org-000003"


def test_uraiflow_source_system_constant() -> None:
    """ISS-003: standardised name replaces withdrawn KURALFLOW identifier."""
    assert SOURCE_SYSTEM_URAIFLOW == "URAIFLOW"


class TestEventPayloadImmutability:
    """ADR-008 (V002 review Finding 3): payloads are read-only and decoupled."""

    @staticmethod
    def _event(payload: object) -> EventEnvelope:
        return EventEnvelope(
            event_type="Probe",
            organisation_id=OrganisationId("org-000001"),
            actor_principal_id=PrincipalId("prn-000001"),
            subject_id="wob-000001",
            subject_version=1,
            occurred_at=datetime(2026, 1, 1, tzinfo=UTC),
            payload=payload,  # type: ignore[arg-type]
        )

    def test_payload_is_read_only(self) -> None:
        event = self._event({"key": "value"})
        with pytest.raises(TypeError):
            event.payload["key"] = "tampered"  # type: ignore[index]
        with pytest.raises(TypeError):
            del event.payload["key"]  # type: ignore[attr-defined]

    def test_non_string_payload_value_rejected(self) -> None:
        with pytest.raises(ValidationError, match="must be strings"):
            self._event({"key": 7})

    def test_non_string_payload_key_rejected(self) -> None:
        with pytest.raises(ValidationError, match="must be strings"):
            self._event({7: "value"})
