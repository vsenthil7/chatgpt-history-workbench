# AUMNITY Work Platform — product code

Reusable multi-tenant SaaS platform kernel. Tenant-neutral by construction:
no customer, tenant or withdrawn module names may appear in `packages/`
(enforced by gate G06).

## Layout
- `packages/aumnity_contracts/` — pure shared contracts (typed IDs, TenantContext,
  events, errors, deterministic providers). Imports nothing from the kernel.
- `packages/aumnity_kernel/` — domain kernel (organisation, identity, work object
  lifecycle, evidence, policy, audit) behind ports; `adapters/memory.py` provides
  in-memory adapters. Kernel domain never imports adapters.
- `tests/` — `unit/`, `contract/` (marker `contract`), `isolation/` (marker
  `isolation`).
- `scripts/gates/` — evidence-producing quality gates G01–G11; evidence lands in
  `evidence/`.

## Reproducible toolchain (ADR-009)
The environment contract is: **Python 3.12** plus the pinned toolchain in
`requirements-dev.txt`. From a clean machine:

```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r requirements-dev.txt
```

## Running
From this `platform/` directory:

```bash
export PYTHONHASHSEED=0
export PYTHONPATH=packages/aumnity_contracts/src:packages/aumnity_kernel/src
python3 -m pytest -q                          # full suite
python3 scripts/gates/run_gates.py build      # working-tree ladder (records incoming
                                              # manifest drift, regenerates at end)
python3 scripts/gates/run_gates.py release    # clean-checkout ladder (incoming
                                              # manifest MUST verify; no regeneration)
python3 scripts/gates/g11_release.py <outdir> # canonical release gate: clean-venv
                                              # full ladder, deterministic double
                                              # build, extracted-final-ZIP validation
```

The artifact release version is read from the repository root `ARTIFACT-VERSION`
file; packaging logic is never hand-edited per release.

Every gate writes machine-readable evidence to `evidence/`; `gate_ladder.json`
records the ordered run. Claims about tests/coverage/mutation are only valid when
backed by these files.

Version: see `VERSION` (must match `pyproject.toml` and `CHANGELOG.md`; gate G10).
