# Handoff for Independent ChatGPT Review — Claude build V005 (hardening release)

Scope: exactly the V004 review's four findings — public-boundary audit,
provisioner atomicity, audit attribution semantics, current-doc labels — no new
feature tranche, no architectural restart. Dispositions:
`11-issues/REVIEW-FINDINGS-V004.md` (all four FIXED, none dropped). OD-001
remains OPEN.

## Product changes (0.3.0 → 0.4.0, breaking, no external consumer)
- ADR-013 public-boundary audit of the WHOLE `aumnity_kernel.__all__`:
  `OrganisationRegistry` split into published/protected
  `OrganisationDirectory` (context-only `get_organisation` returning the
  caller's own organisation — arbitrary-id lookup no longer exists) and
  unpublished trusted `PlatformProvisioning` (tenant creation, unscoped by
  nature: it precedes any tenant context). A machine-checkable inventory
  contract classifies every export (protected service / value / policy),
  enforces context-first on every public method of every protected service,
  and pins trusted boundaries (`PlatformProvisioning`, `AuditSink`,
  `TenantProvisioner`) as unpublished — new surface cannot drift past it.
- ADR-011 hardened: `InMemoryTenantProvisioner` snapshots BOTH stores via an
  explicit adapter transaction API and restores BOTH on ANY failure —
  write-then-fail in either store leaves neither an orphan organisation nor an
  orphan principal; the rollback contract is defined (wholesale state
  replacement, non-raising by construction), not pretended.
- ADR-014: audit actor attribution — `actor_principal_id` is the
  authenticated acting caller, enforced by equality with the bound context
  principal; same-tenant impersonation now raises `ValidationError`;
  delegated recording is DECLARED as AUD-004 with its consequence stated.

## Gates/docs
- ADR-015 + G10 C7 v2: current headings/nav labels must be version-neutral or
  equal ARTIFACT-VERSION; the three stale V004 headings are fixed; a negative
  self-test (reintroducing the exact stale README heading) was demonstrated to
  fail the gate. Historical records remain exempt by scope.
- RTM: SaaS-003 (boundary inventory) and AUD-003 (attribution) ENFORCED with
  node ids; AUD-004 (delegation) DECLARED; TEN-002 evidence covers all four
  failure shapes; G09 high-risk set extended accordingly. V003 Finding 5
  status honestly revised to "partially fixed by V004, completed in V005".

## Regression protection (from the review's exact reproductions)
Cross-tenant organisation read (now impossible by construction — signature
regression); forged-context organisation read; principal-store failure before
AND after write; organisation-store failure before AND after write (public-read
assertions: no orphan either way); founder-context/colleague-actor
impersonation; reworked same-tenant valid write/read.

## How to verify
```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r platform/requirements-dev.txt
cd platform && PYTHONHASHSEED=0 python3 scripts/gates/run_gates.py release   # run twice — identical
```
Counts live only in evidence (DOC C2); clean-room pip freeze + double-ladder
idempotence proof in `evidence/g11_packaging.json` and the sidecar JSON.

## Honest notes
- SEC-001 (roles/permissions) and AUD-004 (delegation provenance) remain
  DECLARED; INF-001 PostgreSQL adapter remains DECLARED — the provisioner's
  atomicity there will be a database transaction replacing the snapshot
  adapter wholesale.
- Mutation scope unchanged (ADR-004); no remote CI exists here — clean-room
  venv ladder remains the substitute evidence.
