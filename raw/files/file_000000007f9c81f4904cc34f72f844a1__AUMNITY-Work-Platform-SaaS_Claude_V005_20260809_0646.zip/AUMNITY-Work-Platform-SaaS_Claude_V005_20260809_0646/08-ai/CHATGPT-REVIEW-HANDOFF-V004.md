# Handoff for Independent ChatGPT Review — Claude build V004 (hardening release)

Scope: exactly the four hardening streams the 2026-08-08 23:01 review demanded —
audit boundary, bootstrap atomicity contract, non-mutating release validation,
evidence consistency — plus nothing else. No new platform features; no
architectural restart. Full dispositions: `11-issues/REVIEW-FINDINGS-V003.md`
(all five findings FIXED, none dropped). OD-001 remains OPEN.

## Product changes (0.2.0 → 0.3.0, breaking, no external consumer)
- ADR-010 audit trust boundary: `AuditLog` is a protected service.
  `entries_for(context)` binds the acting principal; `record(context, event)`
  binds the context, requires event org == context org, and proves the event
  actor is a member — "audit actor can never be foreign" now holds AT the
  published boundary, giving product modules a safe tenant-bound recording
  contract. `AuditSink` stays infrastructure-trusted and out of `__all__`
  (contract-tested).
- ADR-011 bootstrap atomicity: the `TenantProvisioner` port owns all-or-nothing
  tenant creation where transactions actually live; the registry makes one
  provision call; the memory adapter rolls back; the PostgreSQL adapter
  (INF-001, still deferred) will use a real transaction. ADR-007's mechanism
  claim is superseded, its semantics kept.

## Release/evidence machinery
- ADR-012: release-mode gates write ALL output to an external evidence
  directory; shipped evidence is immutable. G11 step 5 proves it: extract the
  final ZIP, digest every manifest-controlled file, run the complete release
  ladder twice on that same extraction, verify G01 after each run, digest
  again — both ladders PASS, digests identical, no regeneration. Recorded in
  the release-validation sidecar JSON beside the ZIP.
- Defect log reconciled (DEF-013): shipped DEF-001..008 verbatim, corrective
  entries DEF-009..015 continue the sequence, all cross-references updated,
  correction notes appended to shipped-era documents instead of rewriting them.
- G10 gains C5 (references to removed gate scripts must be marked historical),
  C6 (defect-ID existence and uniqueness), C7 (stale slice labels vs
  ARTIFACT-VERSION); the stale "V002 slice" strings are gone.

## Regression protection (from the review's own reproductions)
`TestAuditBoundaryRegression`: forged-context read rejected; foreign-actor
write rejected; unknown-actor write rejected; forged-context write rejected;
cross-organisation event write rejected; valid same-tenant write/read; no
cross-tenant disclosure. `TestTenantBootstrapAtomicityRegression`:
failure-injection leaves no orphan organisation; successful bootstrap persists
both. Contract tests pin AuditLog's context-first signatures and AuditSink's
non-publication.

## How to verify
```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r platform/requirements-dev.txt
cd platform && PYTHONHASHSEED=0 python3 scripts/gates/run_gates.py release
# run it again — ADR-012 guarantees the second run passes identically
```
Exact counts live only in the evidence files (DOC gate C2); the clean-room pip
freeze and double-ladder idempotence proof are in `evidence/g11_packaging.json`
and the `.release-validation.json` sidecar.

## Honest notes
- SEC-001 (role/permission authorization) remains DECLARED; identity binding
  (TEN-001/TEN-002/AUD-002) is what V004 enforces.
- The mutation operator set remains scoped per ADR-004; external mutation
  tooling in real CI is still declared follow-up. No git remote/CI exists in
  this environment; the clean-room venv ladder is the substitute evidence.
- G09 remains a traceability gate (V002 Finding 7's inherent limit): it now
  also covers AUD-002/TEN-002 node ids, but semantic sufficiency of tests is
  still a review judgement.
