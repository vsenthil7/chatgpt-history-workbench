# Independent Review Findings — V002 (ChatGPT, 2026-08-08 22:25) and dispositions in V003

Source: ChatGPT review of `AUMNITY-Work-Platform-SaaS_Claude_V002_20260808_2214.zip`
(sha256 `31aae5d9ef34617afd5afdcea9eb41b44a1cf5b8bd8c46f43c8423c15248dcc3`).
Rule applied: no finding may silently disappear; each is FIXED, DEFERRED with
justification, or OPEN.

| # | Finding | Disposition | Where |
|---|---|---|---|
| 1 | Cross-tenant principals accepted as owner/assignee | **FIXED** | ADR-007; `PrincipalDirectory` port; `WorkObjectRegistry.create/assign` validate membership; regressions `tests/isolation/test_tenant_isolation.py::TestPrincipalBindingRegression` (foreign owner, foreign assignee, same-tenant accepted); defect log DEF-009 |
| 2 | TenantContext organisation/principal mismatch accepted | **FIXED** | ADR-007; `_bind()` on every protected operation; unknown and foreign principals raise the same `TenantIsolationError` (no probing oracle); founding principal removes the unverified-bootstrap fixture; regressions incl. mismatched-context and no-audit-trace tests; DEF-009 |
| 3 | "Immutable" audit events mutable via payload dict | **FIXED** | ADR-008; defensive copy + `MappingProxyType` in `EventEnvelope.__post_init__`; regressions `TestAuditImmutabilityRegression` and `TestEventPayloadImmutability`; DEF-010 |
| 4 | G11 "clean-checkout smoke" did not execute the quality ladder | **FIXED** | ADR-009; `g11_release.py` runs the COMPLETE ladder (`run_gates.py release`) in a fresh-venv clean room AND again inside the extracted final ZIP |
| 5 | Build dependencies not reproducibly declared | **FIXED** | ADR-009; pinned `platform/requirements-dev.txt` + `[project.optional-dependencies].dev`; G11 bootstraps from the pins and records `pip freeze` as evidence |
| 6 | G07 failure reason conflated tool absence with format drift | **FIXED** | G07 reports `dependency-unavailable` / `formatter-execution-error` / `baseline-not-formatted` distinctly in evidence; DEF-011 |
| 7 | G09 proved evidence existence, not requirement truth | **FIXED (mechanism), inherent limit acknowledged** | High-risk rows (DW-FR-013, SaaS-002, TEN-001) must cite specific collectable test node ids; RTM updated accordingly. G09 remains a traceability gate — semantic proof lives in the referenced tests plus independent review, and that limit is stated rather than claimed away |
| 8 | G01 generate-before-verify could absorb drift | **FIXED** | `run_gates.py` verifies the INCOMING manifest first (recorded in build mode, gating in release mode); release mode never regenerates; DEF-008 records the duplicated-process incident behind the stray file of Finding 9 |
| 9 | Two competing G11 implementations shipped | **FIXED** | Single canonical `scripts/gates/g11_release.py`; both `g11_package.py` and the stray `g11_package_release.py` removed; provenance of the stray file recorded in DEF-008 |
| 10 | Artifact version hard-coded in packaging logic | **FIXED** | Root `ARTIFACT-VERSION` file is the single source; `g11_release.py` reads it; product semantic version (0.2.0) remains a separate dimension in `platform/VERSION` |

OD-001 ("TEE supervision capacity") remains **OPEN** — unchanged, not guessed.

Verification note: every FIXED row above is exercised by the V003 gate ladder;
the review's own reproduction snippets are encoded as permanent regression
tests so the exploits can never silently return.

> Numbering note (2026-08-08, V004): the DEF references above were reconciled
> after the V003 review found this file citing IDs that the shipped defect log
> used for different, older defects. The reconciliation itself is DEF-013.
