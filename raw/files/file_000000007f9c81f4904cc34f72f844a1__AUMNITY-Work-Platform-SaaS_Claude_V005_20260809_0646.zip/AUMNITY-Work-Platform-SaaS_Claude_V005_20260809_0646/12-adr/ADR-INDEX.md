# Architecture Decision Records

| ADR | Title | Status |
|---|---|---|
| ADR-001 | Repository layout, language and toolchain for the platform kernel | ACCEPTED |
| ADR-002 | Explicit tenant context and ports-and-adapters isolation model | ACCEPTED |
| ADR-003 | V002 first-slice scope: shared kernel only | ACCEPTED |
| ADR-004 | Deterministic in-repo mutation gate instead of external mutation tool | ACCEPTED |
| ADR-005 | RTM unification and baseline reference corrections | ACCEPTED |
| ADR-006 | Domain error taxonomy and edge mapping for tenant isolation | ACCEPTED |
| ADR-007 | Tenant/principal identity binding via PrincipalDirectory port and founding principal | ACCEPTED |
| ADR-008 | Structurally immutable event payloads | ACCEPTED |
| ADR-009 | Pinned toolchain contract and clean-room release validation | ACCEPTED |
| ADR-010 | Audit trust boundary: AuditLog is a protected service; AuditSink is infrastructure-trusted | ACCEPTED |
| ADR-011 | Tenant bootstrap atomicity via TenantProvisioner port (supersedes ADR-007's atomicity mechanism) | ACCEPTED |
| ADR-012 | Non-mutating, idempotent release validation with external verification evidence | ACCEPTED |
| ADR-013 | Public kernel boundary classification; OrganisationDirectory (protected) split from PlatformProvisioning (trusted admin) | ACCEPTED |
| ADR-014 | Audit actor attribution: actor is the authenticated acting caller; delegation deferred with declared consequence | ACCEPTED |
| ADR-015 | Current-document version labels are gate-enforced against ARTIFACT-VERSION | ACCEPTED |

---

## ADR-001 — Repository layout, language and toolchain
**Context.** The starter demands deterministic builds, 100% line+branch coverage on
executable product packages, architecture guards and machine-readable evidence. The
baseline recommends Python services (FastAPI later).
**Decision.** `platform/` is the product code root. Two packages:
`packages/aumnity_contracts` (pure shared contracts: IDs, tenant context, events, errors,
clock/id-generation protocols — no dependency on any other package) and
`packages/aumnity_kernel` (platform primitives: Organisation, Principal, Work Object
registry, Evidence, Policy, Audit; depends only on `aumnity_contracts`). Python 3.12,
pytest + coverage (branch), ruff, mypy (strict). All quality gates are runnable scripts
under `platform/scripts/gates/` producing JSON/text evidence under `platform/evidence/`.
`PYTHONHASHSEED=0` for gate runs; release ZIP built with normalised mtimes for
reproducibility.
**Consequences.** No web framework or database dependency in V002; the kernel is
importable by future `services/platform_api` without modification.

## ADR-002 — Explicit tenant context and ports-and-adapters
**Context.** SaaS guard: "Protected operations must carry explicit tenant/organisation
context and be tested for cross-tenant denial. Avoid global mutable tenant state."
**Decision.** Every protected kernel operation takes a `TenantContext`
(organisation id + acting principal id) as its first argument. Repositories and the audit
log are ports (Protocols) with in-memory adapters in V002. Repository reads are
tenant-filtered inside the kernel service, never left to the adapter alone: the service
re-checks `organisation_id` on every loaded aggregate and raises `TenantIsolationError`
on mismatch, so a defective adapter cannot silently leak. There is no module-level
mutable tenant state anywhere.
**Consequences.** A PostgreSQL adapter later implements the same ports and inherits the
same contract tests (deferred: RTM row INF-001).

## ADR-003 — V002 first-slice scope
**Context.** First build objective: "harden the platform boundary, define
tenant/organisation semantics and shared contracts, then build the minimum shared kernel
demanded by real bounded modules — not a speculative mega-core." Baseline minimum build
boundary and Brutal Readiness Audit both restrict initial scope.
**Decision.** V002 implements exactly: Organisation registry; Principal identity
(HUMAN/AI/SERVICE); Work Object registry with the baseline lifecycle state machine,
version increments, recursive decomposition (parent/child in same organisation),
minimal assignment-to-principal, immutable evidence attachment with SHA-256 content
reference, evidence-gated completion policy for critical work, and an append-only,
tenant-scoped audit trail emitting the baseline event names. Explicitly deferred with
declared RTM rows: Actor/Capability/Capacity (D02/D03), review-as-work-object (D04),
knowledge/handover (D05), UraiFlow bridge implementation (D06 — the source-system
constant and evidence linkage fields exist as contract only), SLA timers, AI gateway,
service catalogue, pricing, persistence adapter, HTTP edge, Playwright (no
browser-visible journey exists yet, so the Playwright obligation is not triggered).
**Consequences.** CGWO and UraiFlow consume the kernel through its public service API and
events; no bounded-product logic entered the kernel.

## ADR-004 — Deterministic in-repo mutation gate
**Context.** QA-002 requires mutation testing for critical domain/policy logic with
attached evidence. External mutation tools introduce nondeterminism and environment
coupling that conflict with the deterministic-build rule in this sandboxed pipeline.
**Decision.** `g07_mutation_gate.py` performs AST-based mutations (comparison-operator
swaps, boolean-operator swaps, constant flips, arithmetic swaps) over the declared
critical modules (`workobject/state.py`, `policy.py`), runs the fast unit suite per
mutant, and writes a machine-readable kill report. Threshold: 100% of generated mutants
killed; any survivor fails the gate and becomes explicit work.
**Limitation (honest).** The operator set is narrower than a full mutation tool; this is
recorded, not hidden. Adopting `mutmut` in CI proper is a declared follow-up (RTM QA-002
note).
**Consequences.** Mutation evidence is reproducible byte-for-byte across runs.

## ADR-005 — RTM unification and baseline reference corrections
**Context.** ISS-002/ISS-004: two unlinked RTMs and broken renamed references.
**Decision.** `06-traceability/RTM.md` (starter location) is the single authoritative
RTM. Baseline DW-FR-001…015 are imported into it with per-row status; the baseline RTM
file remains untouched under `10-baseline/` and is superseded by reference. Baseline
broken links are documented in `11-issues/BASELINE-ISSUES.md`; baseline files are never
edited, honouring the baseline-preservation rule.
**Consequences.** One requirement namespace; G09 enforces that every ENFORCED row maps to
collectable test node IDs.

## ADR-006 — Error taxonomy and isolation edge mapping
**Context.** Cross-tenant access must be denied and testable, but a public API must not
leak resource existence.
**Decision.** Kernel raises typed errors: `TenantIsolationError` (cross-tenant access),
`NotFoundError`, `InvalidTransitionError`, `PolicyViolationError`, `ValidationError`,
all subclassing `PlatformError`. The future HTTP edge MUST map `TenantIsolationError`
to the same external representation as `NotFoundError` (404) to avoid existence leaks;
inside the trust boundary the distinct type keeps isolation failures observable and
auditable. This mapping obligation is recorded as contract, tested at the edge when the
edge exists (deferred RTM row API-001).

## ADR-007 — Tenant/principal identity binding (V002 review Findings 1–2)

**Context.** ChatGPT's independent V002 review reproduced two exploits: a Work
Object could be created/assigned with a principal belonging to another
organisation, and a TenantContext mixing Organisation A with a principal from
Organisation B was accepted. DW-FR-013 cannot be ENFORCED while identity binding
is absent. Three concepts must be separated: authentication (out of kernel
scope), tenant/principal identity binding (this ADR — cannot be deferred), and
role/permission authorization (SEC-001, legitimately deferred).

**Decision.** The kernel validates principal membership through a
`PrincipalDirectory` port (`require_member(context, principal_id)`), implemented
in-process by `OrganisationRegistry`. Every protected `WorkObjectRegistry`
operation first *binds* the context (`require_member(context,
context.principal_id)`), and every principal reference an operation accepts
(owner, assignee) is proven a member of the context organisation. Unknown and
foreign principals raise the same `TenantIsolationError` so principal existence
in other tenants cannot be probed. `create_organisation` atomically creates the
founding principal, eliminating V002's unverified-bootstrap fixture limitation.
No CGWO/UraiFlow/IPBS coupling is introduced.

**Consequences.** Breaking change to `WorkObjectRegistry.__init__` and
`create_organisation` (product 0.1.0 → 0.2.0; no external consumer existed).
Denials occur before any state change or audit emission, so a rejected
operation leaves no trace other than the raised error.

## ADR-008 — Structurally immutable event payloads (V002 review Finding 3)

**Context.** `EventEnvelope` was a frozen dataclass, but `payload:
dict[str, str]` remained mutable; ChatGPT mutated a recorded audit entry through
its payload reference.

**Decision.** `payload` is typed `Mapping[str, str]`; `__post_init__`
defensively copies the caller's mapping and wraps the private copy in
`types.MappingProxyType`. Both the write boundary (caller keeps mutating their
own dict — envelope unaffected) and the read boundary (any holder of the
envelope gets a read-only view) are protected structurally, not by convention.
Payload keys and values are validated to be strings.

**Consequences.** Attempted mutation raises `TypeError`. Regression tests cover
tampering via a recorded audit entry and via the originally supplied dict.

## ADR-009 — Pinned toolchain and clean-room release validation (V002 review Findings 4–6, 9–10)

**Context.** V002 configured pytest/coverage/ruff/mypy but declared no
installable dependency contract; the review environment could not run the full
ladder; the G11 "smoke" ran only validator+manifest+pytest; two G11 scripts
existed; the artifact version was hard-coded in packaging logic.

**Decision.** (a) `platform/requirements-dev.txt` is the authoritative pinned
toolchain, mirrored in `[project.optional-dependencies].dev`. (b) One canonical
release gate, `scripts/gates/g11_release.py`: bootstrap a fresh venv from the
pins, run the COMPLETE ladder (`run_gates.py release`) in a pristine staged
copy, regenerate+verify the release manifest, build the ZIP twice
deterministically, then extract the exact final ZIP and run the full release
ladder inside the extraction. (c) `run_gates.py` gains build/release modes;
release mode requires the incoming manifest to verify BEFORE anything runs and
performs no regeneration, so drift can never be silently absorbed
(this control would have flagged the V002 stray `g11_package_release.py`).
(d) The artifact version is read from the root `ARTIFACT-VERSION` file.

**Consequences.** "Clean checkout reproduces the ladder" is now a tested claim
with pip-freeze evidence, not an environment assumption. Final-ZIP validation
results live next to the ZIP, since they cannot be stored inside the archive
whose bytes they describe.

## ADR-010 — Audit trust boundary (V003 review Findings 1–2)

**Context.** `AuditLog` is exported from `aumnity_kernel.__all__` and is
therefore a published surface, yet V003's `entries_for` bound only the
organisation id (a forged `TenantContext(Org-A, Principal-B)` read Org-A
history) and `record` accepted arbitrary envelopes (foreign-actor injection).
The claim "audit actor can never be foreign" held only for events emitted via
`WorkObjectRegistry`. The review demanded an explicit trust-model decision, not
a convenient point fix.

**Decision.** Model A, applied consistently: `AuditLog` is a PROTECTED
application service exactly like `WorkObjectRegistry`. It depends on
`PrincipalDirectory`; `entries_for(context)` binds the acting principal before
returning anything; `record(context, event)` binds the context, requires
`event.organisation_id == context.organisation_id`, and proves
`event.actor_principal_id` is a member of that organisation. This gives product
modules a safe tenant-bound event-recording contract. The raw `AuditSink` port
remains the infrastructure-trusted persistence boundary: it stays out of the
kernel `__all__`, is never handed to untrusted application code, and adapters
alone implement it. Violations raise `TenantIsolationError` uniformly.

**Consequences.** Breaking signature change (`record` takes context;
constructor takes the directory). Cross-module audit publication now cannot
forge another tenant's actor/org combination by construction. TEN-001,
DW-FR-013 and SaaS-002 evidence now includes the audit boundary.

## ADR-011 — Tenant bootstrap atomicity (V003 review Finding 3)

**Context.** ADR-007 stated `create_organisation` "atomically creates the
founding principal", but the implementation sequenced two independent
repository writes; the review injected a failing principal store and produced
an orphan organisation. Repository ports cannot honestly promise cross-write
atomicity.

**Decision.** Atomicity is placed where transactions actually exist: a
`TenantProvisioner` port with the contract "persist organisation AND founder
all-or-nothing; on failure neither remains visible". The registry constructs
both aggregates and makes ONE port call; it never sequences independent writes
for bootstrap. The in-memory adapter implements compensating rollback; the
future PostgreSQL adapter (INF-001) implements a database transaction. This
supersedes ADR-007's mechanism statement; the founding-principal semantics of
ADR-007 are unchanged.

**Consequences.** `OrganisationRegistry` gains a provisioner dependency
(breaking, no external consumer). A failure-injection regression proves no
partial tenant survives (RTM TEN-002). The claim is now backed by a port
contract an adapter can actually honour.

## ADR-012 — Non-mutating release validation (V003 review Finding 4)

**Context.** Release-mode gates wrote fresh `generated_at` evidence into
manifest-controlled files, so validating a released tree broke its own G01 on
the next run: validation was destructive and non-idempotent.

**Decision.** Shipped evidence inside the package is immutable. All
verification-time gate output is written to an external evidence directory
(`AUMNITY_EVIDENCE_DIR`; release mode defaults to a fresh temp dir). G11
step 5 proves the property: extract the final ZIP, digest every
manifest-controlled file, run the complete release ladder twice on the same
extraction with G01 verified after each run, digest again — both ladders must
pass and the digests must be identical, with no regeneration or cleanup.

**Consequences.** Release validation is read-only and repeatable by anyone,
any number of times. Build mode still writes into `platform/evidence/` (that
is how shipped evidence is produced) and regenerates the manifest at the end.

## ADR-013 — Public kernel boundary classification (V004 review Finding 1)

**Context.** `OrganisationRegistry` sat in `aumnity_kernel.__all__` with an
unscoped `get_organisation(organisation_id)`; the review read another tenant's
organisation name through the published surface. The V004 signature contract
introspected only `WorkObjectRegistry` (plus a separate AuditLog test), so the
drift escaped — exactly what the contract exists to prevent.

**Decision.** Every published name is explicitly classified, and the
classification is machine-checked (contract test
`TestPublicBoundaryInventory`): PROTECTED SERVICES (`WorkObjectRegistry`,
`AuditLog`, `OrganisationDirectory`) whose every public method must take
`TenantContext` first; VALUE TYPES; POLICY TYPES. TRUSTED, UNPUBLISHED
boundaries (`PlatformProvisioning`, `AuditSink`, `TenantProvisioner`) must NOT
appear in `__all__`. `OrganisationRegistry` is split accordingly:
`OrganisationDirectory` (published, protected) exposes `get_organisation(context)`
returning only the CALLER'S OWN organisation — no arbitrary-id lookup exists on
the published surface, making the exploit impossible by construction — plus
`create_principal` and `require_member`. `PlatformProvisioning` (trusted
platform-operator boundary, unpublished, like `AuditSink` under ADR-010) owns
`create_organisation`, which is unscoped by nature since it runs before any
tenant context exists. An unclassified export, a stale classification, or a
protected method without leading context fails G05.

**Consequences.** Breaking: `OrganisationRegistry` removed from the API
(0.3.0 → 0.4.0, no external consumer). Admin operations are now structurally
distinguishable from tenant services. Future exports must be classified to
ship.

## ADR-014 — Audit actor attribution semantics (V004 review Finding 3)

**Context.** ADR-010 blocked cross-tenant audit forgery, but a same-tenant
principal could still record an immutable event attributing an action to a
colleague: the envelope's single `actor_principal_id` field carried no
recorder/actor/delegation distinction, and V004's own regression exercised that
pattern as "valid".

**Decision.** `actor_principal_id` MEANS the authenticated acting caller.
`AuditLog.record` therefore requires `event.actor_principal_id ==
context.principal_id` (the bound context principal); a mismatch raises
`ValidationError` as an attribution-integrity violation. This single rule
subsumes the foreign-actor and unknown-actor cases (neither can equal a proven
member). Recording on behalf of another actor — recorder vs causal actor vs
on-behalf-of delegation — is a real future need and is DECLARED (RTM AUD-004)
as an explicit provenance contract with its own authorization, not an overload
of one field. This is deliberately NOT parked under SEC-001: the audit-integrity
consequence of deferral (no delegated recording exists at all until AUD-004
lands) is documented here.

**Consequences.** Services emit as themselves; `WorkObjectRegistry` already
complies by construction. Same-tenant impersonation is regression-tested from
the review's exact scenario.

## ADR-015 — Current-document version labels (V004 review Finding 4)

**Context.** V004 shipped current headings claiming V003/V002 (`platform/README.md`,
`12-adr/ADR-INDEX.md`, `00-control/READING-MAP.md`) while ARTIFACT-VERSION was
V004; G10's C7 pattern was too narrow to notice — the same class V003 Finding 5
was meant to eliminate, so that finding was only partially fixed.

**Decision.** Current, non-baseline navigational/metadata surfaces
(`platform/README.md`, `12-adr/ADR-INDEX.md`, everything under `00-control/`,
and the RTM heading) must be version-neutral or carry exactly
ARTIFACT-VERSION; G10 C7 enforces this for heading lines and reading-map
entries. Inherently historical records (CHANGELOG sections, per-release review
findings and handoffs, defect-log rows, ADR bodies describing which release a
decision responded to) legitimately carry old versions and are exempt by
scope, not by pattern-narrowness.

**Consequences.** A release that forgets to update current labels fails G10
instead of shipping; the three V004 stale headings are corrected and covered.
