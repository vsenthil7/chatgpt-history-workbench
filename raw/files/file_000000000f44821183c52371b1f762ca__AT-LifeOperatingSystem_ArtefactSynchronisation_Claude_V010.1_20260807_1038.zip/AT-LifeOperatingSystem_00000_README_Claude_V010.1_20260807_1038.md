# AT-Life Operating System (AT-LOS) - V010.1

**Release:** `AT-LifeOperatingSystem_ArtefactSynchronisation_Claude_V010.1_20260807_1038`
**Prepared by:** Claude · **07-Aug-2026 10:38 BST**
**Zero new architecture decisions except one forced by contradiction (ADR-011).**

## First: you were right about AT-056, and I was wrong

I framed the measurement as competing with engineering. It doesn't. AT-056 is calendar-bound; Sprint 2 is engineering work. **Both start today.** The urgency was real, the framing was not. Logged in Lessons Learned.

## 13 findings. All 13 verified. All 13 real.

The two that mattered:

**`READ_THIS_FIRST.md` contradicted itself in adjacent lines** — "only `at-cli` may import an adapter", immediately followed by "only `at-store` and `at-cli` may". It also still told developers to add packages to `LAYERS` in the test file, which V010 had explicitly moved to `architecture.toml`. The first file a new engineer reads, pointing at the wrong source.

**The Test Strategy workbook was still V009 throughout** — 58 tests, 14 guards, 4 mutants, RTM stopping at 19, and an Artifact Authority sheet naming V009 artefacts as current.

So my V010 claim — *"a new engineer gets one consistent answer"* — was false. Again.

## Why this kept happening, and the structural fix

V008 guarded the README. Then the **architecture document** drifted. V009's ADR-009 generated the architecture document. Then the **onboarding file and the test workbook** drifted.

Each fix protected one artefact and left the rest.

**`tools/consistency_check.py`** now derives every cross-document figure **from the code** — platform and package versions, collected tests, guard count, mutant count, on-disk packages, ADR range, the adapter-consumer rule — and asserts every document against it. Blocking CI job and a test (RTM-23).

It failed on its own first run, because adding it changed the test count the documents quoted. Then it caught ADR-011 not being referenced in the README. That is the behaviour I wanted: a claim can no longer go stale quietly, including a claim about the checking.

## ADR-011 — one authority, ordered

Three absolute rules were in force at once: *tests win*, *the manifest is the single source*, *Project Memory wins*. Each defensible alone; together, no answer.

```
code → architecture.toml → tests → generated docs → written docs → Project Memory
```

**Project Memory cannot override machine-verified implementation state.** It stays authoritative for what code cannot answer — why a decision was taken, what is deferred, what must not be built.

## Also corrected

Adapter rule stated identically everywhere · defect log row 5 now carries the V010 resolution with the old one labelled superseded · "four mutants" → six · README ADR range → 001..011 · Hallucination Register refs `0.1.0` → `0.3.0`, evidence recomputed to 39 parser and 10 store tests · Project Memory index no longer opens with "V007 — Sixteen registers" · Sprint Tracker column O explicitly labelled *evidence at completion — historical*, so old totals can't be read as current.

## Both workbooks regenerated from code-derived facts

Not retyped. The Test Strategy workbook's figures come from `consistency_check.facts()` at build time.

## Prove it

```bash
cd at-platform
python -m pytest -q                            # 68 passed, 1 skipped, 100% coverage
ruff check packages tests tools verification   # clean
mypy --strict packages/*/src                   # clean
python tools/mutation_regression.py            # 6/6 killed
python tools/consistency_check.py              # all artefacts consistent
python tools/gen_architecture.py               # regenerates identically
```

Real exports: **500 events, 0 issues, re-ingest added 0, 2 contents, 2 ingestions.**

## Completion test

Give a fresh AI only this zip. *What exists? Where does `at-identity` go? What may it import? Who may import an adapter? Current package version? How many tests, guards, mutants? Which file is authoritative?*

Every artefact now leads to the same answer, and a gate fails the build if that stops being true.

## Start Sprint 2

`at-identity` → `at-consent` → `at-evidence` → `at-questions`, `at-commitments`, `at-timeline`.

Architecture is **frozen by default, not absolutely**: reopen only for a contradiction that implementation uncovers, and then only the affected module.

## Still not done

RTM-14, RTM-15 unenforced · `at-store` in-memory, not durable (S1-20) · ingestion not streaming (S1-24) · no GDPR basis, no consent · every L2+ module is a contract on paper.

**AT-056 starts today, alongside the code.**
