# AT-LOS V010.1 Change Log

Synchronisation correction. **Zero new architecture decisions** except ADR-011, which was forced by a genuine contradiction between three existing rules.

## Verified

13 findings raised by independent review. All 13 verified against the actual files before acceptance. None rejected. Running total across V008, V009 and V010 reviews: **33 findings raised, 33 confirmed, 0 rejected.**

## Repository

- `READ_THIS_FIRST.md`: removed the contradictory line permitting `at-store` to import adapters; removed the stale instruction to edit `LAYERS` in the test file; added the ADR-011 precedence.
- `docs/ARCHITECTURE.md`: two remaining `LAYERS` instructions replaced with `architecture.toml`; regenerated.
- `docs/TEST_STRATEGY.md`: "Four mutants" → six.
- `README.md`: ADR range → 001..011; precedence section added.
- **`tools/consistency_check.py`** (new): derives platform and package versions, collected tests, guard count, mutant count, on-disk packages, ADR range and the adapter-consumer rule from code, then asserts every document. Blocking CI job and RTM-23.
- **ADR-011** (new): authority precedence, and cross-artifact claims derived rather than typed.
- CI gains a `consistency` job that also runs `gen_architecture.py` and fails on any diff.

Gates: **68 passed, 1 skipped, 259 statements, 0 missed, 100%**; ruff clean; mypy --strict clean; 6/6 mutants killed; consistency clean.

## Workbooks

- **Test Strategy regenerated at V010.1 from code-derived facts.** V010 shipped it still reporting V009 state. Now: correct counts, RTM-01..23 with the 20a/b/c split, six mutants, a 33-row defect log spanning three reviews, and an Artifact Authority sheet rebuilt on the ADR-011 precedence.
- Defect log row for adapter isolation now records the V010 resolution (**only orchestration**) and labels the V009 wording superseded.
- **Project Memory**: index heading corrected from "V007 — Sixteen registers" to V010.1 / 15 registers across 16 worksheets; implementation refs `0.1.0`/`0.2.0` → `0.3.0`; evidence recomputed (39 parser, 10 store, 20 guards, 6 mutants); Sprint Tracker column O relabelled *evidence at completion — historical*; S1-25 and S1-26 added; D-046 logged; three Lessons entries.
- **Project Memory Standard V010.1**: 18 rules, precedence first, plus rule 17 (figures derived, not typed) and rule 18 (completion evidence is historical).

## Conceded

AT-056 and Sprint 2 are not alternatives. The measurement is calendar-bound; the engineering is not. Both start today. Recorded in Lessons Learned as a framing error on my part.

## Not done

No feature work. No identity, consent or evidence started. Durable persistence (S1-20) and streaming ingestion (S1-24) planned. RTM-14 and RTM-15 unenforced.
