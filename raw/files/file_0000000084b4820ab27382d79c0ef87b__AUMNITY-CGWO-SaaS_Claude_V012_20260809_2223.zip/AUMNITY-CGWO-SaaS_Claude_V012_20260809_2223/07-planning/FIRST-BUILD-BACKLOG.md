# First Build Backlog

## B001 — Baseline acceptance — DONE (V002)
- Read all starter documents and the complete preserved baseline.
- Inventory contradictions/duplicates/stale names before deleting anything.
- Record architecture decisions rather than silently normalising history.

## B002 — Declare the first implementation slice — DONE (V002, domain core)
Turn the bounded architecture into a testable domain core with explicit contracts to AUMNITY Platform and UraiFlow, beginning with capacity/availability and planning state transitions.

## B003 — Tests first as contracts — PARTIAL (V002; see handoff deviation note)
Declare RTM rows, contract tests and architecture/tenant guards before implementation. Establish red evidence, then implement to green.

## B004 — Evidence-producing CI — PARTIAL (V002: evidence scripts exist; no CI pipeline yet)
Make test counts, coverage, mutation, package inventory and docs consistency machine-readable so narrative docs do not drift.

## B005 — Review package — DONE (this ZIP)
Create the next `<Product>_Claude_VNNN_YYYYMMDD_HHMM.zip` with complete source/tests/docs/evidence for independent ChatGPT review.

## V003 correction cycle — DONE
Independent review findings F01–F12 on V002 addressed; see `00-control/RELEASE-NOTES-V003.md`, ADR-007..009 and `tests/test_review_regressions.py`. Aggregate capacity governance (CapacityLedger, DOM-006) and event persistence remain the top declared debts before persistence/API work.

## V004 hardening cycle — DONE
Independent review findings F13–F19 on V003 addressed: runtime type integrity across the domain trust boundary (ADR-010), explicit wire decoding, creation-vs-rehydration factories, strict unit-tested mutation gate and structured error identity (ADR-011). See `00-control/RELEASE-NOTES-V004.md`. Feature expansion (persistence/API/matching/CapacityLedger) remains deliberately blocked pending baseline acceptance.

## V005 trust-boundary cycle — DONE
Independent review findings F20–F26 on V004 addressed: canonical primitive trust model with exact-type guards (ADR-012) closing the demonstrated cross-tenant subtype bypass, hostile-int invariant bypasses and datetime/date smuggling; explicit ASCII wire-integer grammar; construction-origin claims corrected to convention; version-drift rule added to the consistency validator. Feature expansion remains deliberately blocked pending baseline acceptance.

## V006 trust-boundary cycle — DONE
Independent review findings F27–F29 on V005 addressed: canonical object boundaries (ADR-013) closing the lying-TenantContext cross-tenant bypass and lying-window acceptance, canonicalised isolation operands, and strict explicit wire grammars replacing permissive fromisoformat/int() delegation. Feature expansion remains deliberately blocked pending baseline acceptance.

## V007 trust-model cycle — DONE
Independent review findings F30–F33 on V006 addressed root-cause-first: authorization trust boundary (ADR-014) replaces object-identity-as-authority, closing the object.__setattr__ mutation bypass (F30) and lying-aggregate-subclass bypass (F32); single semantic wire-integer magnitude bound on both paths (F31); current-cycle handoff machine rule + regression (F33). The domain-core authorization decision is enforced; authenticated identity remains an explicit service-layer deferral. Feature expansion still deliberately blocked pending baseline acceptance.

## V008 review cycle — DONE
Independent review findings F34–F37 on V007 addressed: retired overclaim wording removed from the live surface, authorization-policy vs authenticated-authority language corrected, canonical release identity made a single machine-readable source, and aggregate provenance named as an explicit service-layer prerequisite rather than a domain claim. See `00-control/RELEASE-NOTES-V008.md`.

## V009 review cycle — DONE
Independent review findings F38–F41 on V008 addressed: authentication wording, authorization container contract (F39), generic versioned-artifact identity rule (F40) and honest governance scoping of what a structural validator can prove (F41). See `00-control/RELEASE-NOTES-V009.md`.

## V010 review cycle — DONE
Independent review findings F42–F44 on V009 addressed: aggregate operation-argument hygiene (F42), manifest closure over the shipped managed set (F43) and unconditional release-mode package-root identity (F44). See `00-control/RELEASE-NOTES-V010.md`.

## V011 review cycle — DONE
Independent review findings F45–F47 on V010 addressed: the aggregate guard was corrected to read the REAL runtime type so spoofed `__class__` impostors are refused (F45, ADR-010 Amendment A2), the manifest exclusion policy became an explicit named allowlist (F46) and manifest `bytes` metadata became verified rather than decorative (F47). See `00-control/RELEASE-NOTES-V011.md`.

## V012 closure cycle — DONE
Independent review findings F48–F53 on V011 addressed: excluded-name manifest bypass and unbound baseline manifest (F48), symlink substitution plus the missing ZIP-envelope gate (F49), fail-open authorization on non-boolean port decisions (F50, ADR-016), strict manifest schema validation (F51), governance-document staleness with a machine rule to prevent recurrence (F52) and the wire-integer leading-zero grammar contradiction (F53, ADR-013 Amendment A1). See `00-control/RELEASE-NOTES-V012.md`. Feature expansion remains deliberately blocked pending baseline acceptance; the intended next tranche is the service-layer vertical slice.
