"""Canonical manifest inclusion/exclusion policy (F43/F46/F48/F49 — single source).

Both `gen_manifest.py` (which WRITES the manifest) and `validate_consistency.py`
(which CHECKS it) import from here, so "what should be in the manifest" is
defined in exactly one place and the two tools cannot drift.

Design history:
- F43 (V009): hash-only validation was one-way; the set had to be CLOSED so an
  unmanifested `EXTRA.txt` fails.
- F46 (V010): a generic dot-directory exclusion let `.evil/payload.py` hide;
  replaced by an explicit named allowlist.
- F48 (V011): the explicit NAMES were still excluded ANYWHERE in the tree, so
  `.evil/PACKAGE-MANIFEST.json`, `.evil/.coverage`, `.evil/.DS_Store` and
  `.git/hooks/post-checkout` were all invisible, AND the preserved baseline's
  own nested `PACKAGE-MANIFEST.json` was excluded from the outer manifest so it
  could be tampered undetected. Two root causes are fixed here:
    1. ONLY the exact ROOT self-referential manifest is unmanaged (a manifest
       cannot hash itself). EVERY other file — including nested manifests such
       as the baseline's — is managed, hashed and bound by the outer manifest.
    2. Development/cache/VCS artifacts are no longer SILENTLY excluded by name.
       They are FORBIDDEN in a release tree: `is_forbidden_release_artifact()`
       names them, and release-mode validation REJECTS their presence rather
       than ignoring them. Development trees (`--dev`) tolerate them and drop
       them from the managed set, because --dev explicitly relaxes release
       integrity. A clean release tree contains none of them.
- F49 (V011): traversal/verification followed symlinks, so a managed source
  file could be replaced by a symlink to excluded bytes. `managed_files()` now
  rejects symlinks/non-regular files using NON-following inspection, and the
  validator binds file kind per entry.
"""

from __future__ import annotations

import stat
from pathlib import Path

#: Canonical manifest schema constants — the SINGLE source used by both the
#: generator and the strict schema validator (F51), so they cannot drift.
MANIFEST_SCHEMA = "aumnity-package-manifest/1"
MANIFEST_PROJECT = "AUMNITY CGWO SaaS"
MANIFEST_TOP_KEYS = ("schema", "project", "release", "generated", "file_count", "files")
MANIFEST_FILE_KEYS = ("path", "bytes", "sha256")

#: The ONLY unmanaged path: the root manifest cannot hash itself. Compared
#: EXACTLY against the repo-relative path — a nested `PACKAGE-MANIFEST.json`
#: (e.g. the baseline's) is managed and bound (F48).
ROOT_MANIFEST = Path("PACKAGE-MANIFEST.json")

#: Development/build/cache/VCS directories. FORBIDDEN in a release tree (their
#: presence is a release-mode error, F48); tolerated and unmanaged under --dev.
FORBIDDEN_DIRS = {
    "mutants",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    ".mypy_cache",
    ".mutmut-cache",
    ".hypothesis",
    ".git",
    ".venv",
    ".idea",
    ".vscode",
}
#: Development/tooling files, matched by basename anywhere. Same treatment.
FORBIDDEN_FILES = {".coverage", ".DS_Store"}


def is_forbidden_release_artifact(rel: Path) -> bool:
    """True if `rel` is a dev/cache/VCS artifact that must NOT ship in a release."""
    if any(part in FORBIDDEN_DIRS for part in rel.parts):
        return True
    return rel.name in FORBIDDEN_FILES


def is_managed(rel: Path) -> bool:
    """True if the repo-relative path should appear in the manifest.

    Managed = every file EXCEPT the exact root manifest and forbidden dev/cache
    artifacts. Forbidden artifacts are excluded here so the managed set stays
    clean; their PRESENCE is separately rejected in release mode by the
    validator (they are not meant to ship at all).
    """
    if rel == ROOT_MANIFEST:
        return False
    return not is_forbidden_release_artifact(rel)


def _is_regular_nonsymlink(path: Path) -> bool:
    """Regular file AND not a symlink, using NON-following inspection (F49).

    `Path.is_file()` follows symlinks, so a symlink to a regular file reports
    True. `lstat` inspects the link itself; a symlink is never a managed file.
    """
    if path.is_symlink():
        return False
    try:
        return stat.S_ISREG(path.lstat().st_mode)
    except OSError:
        return False


def managed_files(root: Path) -> list[str]:
    """The canonical sorted list of managed repo-relative POSIX paths.

    Symlinks and non-regular files are never managed (F49): a release ships
    only real regular files, and a manifest entry must denote real bytes at a
    real path, not bytes reached by following a link.
    """
    managed: list[str] = []
    for path in sorted(root.rglob("*")):
        if not _is_regular_nonsymlink(path):
            continue
        rel = path.relative_to(root)
        if is_managed(rel):
            managed.append(rel.as_posix())
    return managed


def forbidden_release_artifacts(root: Path) -> list[str]:
    """Present paths that are dev/cache/VCS artifacts (must not ship, F48).

    Includes symlinks and other non-regular entries anywhere in the tree, since
    a release ships only real regular files (F49).
    """
    found: list[str] = []
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if path.is_symlink():
            found.append(rel.as_posix())
            continue
        if not path.is_dir() and is_forbidden_release_artifact(rel):
            found.append(rel.as_posix())
    return found
