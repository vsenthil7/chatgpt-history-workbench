#!/usr/bin/env python3
"""Verify a release ZIP ENVELOPE before it is shipped (V011 review, F49).

Why this exists: every other gate runs on an EXTRACTED tree, so nothing could
see the archive itself. A ZIP can carry an extra sibling entry outside the
canonical package root, an unsafe absolute/`..` path, a duplicate entry, a
symlink, or a case-fold collision — and the extracted-package validator would
still pass, because it can only see what landed inside the root it was pointed
at. This script closes that gap by reconciling the ARCHIVE against the manifest
it contains.

Checks (all fail-closed):
  1. CRC integrity of every entry (`ZipFile.testzip`).
  2. Exactly ONE top-level package root; no sibling entries beside it.
  3. No unsafe paths: absolute, drive-lettered, backslash-separated, or
     containing a `..` component.
  4. No duplicate entry names.
  5. No case-fold or Unicode-NFC normalisation collisions (two entries that
     would overwrite each other on a case-insensitive or normalising
     filesystem).
  6. No symlinks or non-regular entries (F49) — a release ships real files.
  7. The root manifest exists in the archive, and the archive's regular-file
     set reconciles EXACTLY with the manifest's managed set (no unmanifested
     archive member, no manifest entry absent from the archive).
  8. Every archive member's bytes hash to the manifest's recorded SHA-256 and
     match its recorded size — verified from the ARCHIVE, not from disk.

Usage: python3 scripts/verify_release_zip.py <release.zip>
Exit code 0 = PASS, 1 = violations, 2 = usage error.
"""

from __future__ import annotations

import hashlib
import json
import stat
import sys
import unicodedata
import zipfile
from pathlib import PurePosixPath

sys.dont_write_bytecode = True

MANIFEST_NAME = "PACKAGE-MANIFEST.json"


def _is_symlink(info: zipfile.ZipInfo) -> bool:
    """True if the entry records a symlink in its external attributes."""
    return stat.S_ISLNK(info.external_attr >> 16)


def _is_regular(info: zipfile.ZipInfo) -> bool:
    """True if the entry is a regular file (not a dir, symlink or device).

    Only a POSITIVELY declared non-regular type is rejected. Many ZIP writers
    (including `ZipFile.writestr`) leave the file-type bits of the external
    attributes unset, so an absent S_IFMT must be read as "unspecified,
    therefore an ordinary file" rather than as "not regular" — otherwise every
    entry written by such a tool would be spuriously refused.
    """
    if info.is_dir():
        return False
    fmt = stat.S_IFMT(info.external_attr >> 16)
    if fmt == 0:
        return True
    return fmt == stat.S_IFREG


def _unsafe(name: str) -> bool:
    if name.startswith(("/", "\\")) or "\\" in name:
        return True
    if len(name) > 1 and name[1] == ":":  # drive letter
        return True
    return ".." in PurePosixPath(name).parts


def verify(zip_path: str) -> list[str]:
    errors: list[str] = []
    with zipfile.ZipFile(zip_path) as zf:
        infos = zf.infolist()
        names = [i.filename for i in infos]

        # 1. CRC integrity
        bad = zf.testzip()
        if bad is not None:
            errors.append(f"ZIP CRC failure in entry: {bad}")

        # 3. unsafe paths
        for name in names:
            if _unsafe(name):
                errors.append(f"unsafe ZIP path: {name!r}")

        # 4. duplicates
        seen: set[str] = set()
        for name in names:
            if name in seen:
                errors.append(f"duplicate ZIP entry: {name}")
            seen.add(name)

        # 5. case-fold / NFC normalisation collisions
        folded: dict[str, str] = {}
        for name in names:
            key = unicodedata.normalize("NFC", name).casefold()
            if key in folded and folded[key] != name:
                errors.append(f"case-fold/normalisation collision: {name!r} vs {folded[key]!r}")
            folded.setdefault(key, name)

        # 6. symlinks / non-regular entries
        for info in infos:
            if _is_symlink(info):
                errors.append(f"ZIP contains a symlink: {info.filename} (F49)")
            elif not info.is_dir() and not _is_regular(info):
                errors.append(f"ZIP contains a non-regular entry: {info.filename} (F49)")

        # 2. exactly one top-level root, no siblings
        roots = {PurePosixPath(n).parts[0] for n in names if PurePosixPath(n).parts}
        if len(roots) != 1:
            errors.append(
                f"ZIP must contain exactly ONE top-level package root, found: {sorted(roots)}"
            )
            return errors
        root = next(iter(roots))
        for name in names:
            parts = PurePosixPath(name).parts
            if len(parts) == 1 and not name.endswith("/"):
                errors.append(f"sibling entry outside the package root: {name}")

        # 7/8. reconcile the ARCHIVE against the manifest it carries
        manifest_name = f"{root}/{MANIFEST_NAME}"
        if manifest_name not in seen:
            errors.append(f"archive has no root manifest at {manifest_name}")
            return errors
        try:
            manifest = json.loads(zf.read(manifest_name).decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            errors.append(f"archive manifest is not valid UTF-8 JSON: {exc}")
            return errors

        if manifest.get("release") != root:
            errors.append(
                f"manifest release {manifest.get('release')!r} != ZIP package root {root!r}"
            )

        listed = {e["path"]: e for e in manifest.get("files", []) if isinstance(e, dict)}
        archive_files = {
            PurePosixPath(i.filename).relative_to(root).as_posix()
            for i in infos
            if _is_regular(i) and not _is_symlink(i) and PurePosixPath(i.filename).parts[0] == root
        }
        archive_files.discard(MANIFEST_NAME)  # the manifest cannot list itself

        for extra in sorted(archive_files - set(listed)):
            errors.append(f"archive member missing from manifest: {extra} (F43/F48)")
        for missing in sorted(set(listed) - archive_files):
            errors.append(f"manifest entry absent from archive: {missing}")

        for rel in sorted(archive_files & set(listed)):
            data = zf.read(f"{root}/{rel}")
            entry = listed[rel]
            if hashlib.sha256(data).hexdigest() != entry.get("sha256"):
                errors.append(f"archive hash mismatch: {rel}")
            if len(data) != entry.get("bytes"):
                errors.append(
                    f"archive bytes mismatch: {rel} lists {entry.get('bytes')} but archive "
                    f"member is {len(data)} (F47)"
                )
    return errors


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: verify_release_zip.py <release.zip>")
        return 2
    errors = verify(argv[1])
    if errors:
        print("RELEASE ZIP: FAIL")
        for e in errors:
            print(" -", e)
        return 1
    print("RELEASE ZIP: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
