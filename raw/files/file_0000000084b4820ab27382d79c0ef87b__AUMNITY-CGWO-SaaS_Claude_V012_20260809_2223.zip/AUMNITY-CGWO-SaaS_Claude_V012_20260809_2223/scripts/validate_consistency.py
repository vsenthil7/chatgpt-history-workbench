#!/usr/bin/env python3
"""Machine-detectable contradiction checks for the CGWO repository (DOC-001, ADR-004).

Checks: required files; ADR status headers; canonical-scope single source of truth;
superseded/tenant-specific vocabulary placement; manifest hash integrity; evidence
presence and gate-status cross-reference.
Exit code 0 = PASS, 1 = violations found.
"""

from __future__ import annotations

import hashlib
import json
import re
import stat
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
# Do not emit __pycache__ for the sibling script imports below: this validator
# inspects its own tree for forbidden build artifacts (F48/F49), and a pyc it
# wrote itself would be a self-inflicted false failure.
sys.dont_write_bytecode = True
from manifest_policy import (
    MANIFEST_FILE_KEYS,
    MANIFEST_PROJECT,
    MANIFEST_SCHEMA,
    MANIFEST_TOP_KEYS,
    forbidden_release_artifacts,
)
from manifest_policy import managed_files as _managed_files

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

REQUIRED = [
    "00-control/PROJECT-START.md",
    "00-control/READING-MAP.md",
    "00-control/RELEASE-NOTES-V002.md",
    "00-control/RELEASE-IDENTITY.json",
    "CLAUDE.md",
    "01-product/CANONICAL-SCOPE.md",
    "01-product/PRODUCT-BOUNDARY-AND-SAAS.md",
    "02-architecture/MODULARITY-AND-REUSE.md",
    "02-architecture/PLATFORM-PRIMITIVES-CONTRACT.md",
    "02-architecture/INTEGRATION-BOUNDARIES.md",
    "03-engineering/ENGINEERING-OPERATING-SYSTEM.md",
    "04-testing/TESTING-STRATEGY.md",
    "05-quality/QUALITY-GATES.md",
    "05-quality/GATE-STATUS-V002.md",
    "06-traceability/RTM.md",
    "07-planning/FIRST-BUILD-BACKLOG.md",
    "08-ai/CHATGPT-REVIEW-HANDOFF.md",
    "08-ai/CLAUDE-V002-HANDOFF.md",
    "09-governance/VERSIONING-AND-PACKAGING.md",
    "evidence/test-summary.json",
]
for rel in REQUIRED:
    if not (ROOT / rel).is_file():
        errors.append(f"missing required file: {rel}")

# --- ADR status headers -------------------------------------------------------
ADR_DIR = ROOT / "11-decisions"
adr_files = sorted(ADR_DIR.glob("ADR-*.md")) if ADR_DIR.is_dir() else []
if not adr_files:
    errors.append("no ADR files found in 11-decisions/")
STATUS_RE = re.compile(r"^Status:\s*(ACCEPTED|PROPOSED|SUPERSEDED|REJECTED)", re.MULTILINE)
for adr in adr_files:
    if not STATUS_RE.search(adr.read_text(encoding="utf-8")):
        errors.append(f"{adr.relative_to(ROOT)}: missing/invalid 'Status:' header")

# --- Canonical scope: defined once, referenced elsewhere ----------------------
DEFINING = Path("01-product/CANONICAL-SCOPE.md")
REFERENCING = [
    "00-control/PROJECT-START.md",
    "01-product/PRODUCT-BOUNDARY-AND-SAAS.md",
    "02-architecture/MODULARITY-AND-REUSE.md",
]
scope_text = (ROOT / DEFINING).read_text(encoding="utf-8") if (ROOT / DEFINING).is_file() else ""
for scope_id in ("CGWO-SCOPE-1", "CGWO-NOTOWNED-1"):
    if f"## {scope_id}" not in scope_text:
        errors.append(f"{DEFINING}: canonical id {scope_id} not defined")
    for rel in REFERENCING:
        f = ROOT / rel
        if (
            f.is_file()
            and scope_id == "CGWO-SCOPE-1"
            and scope_id not in f.read_text(encoding="utf-8")
        ):
            errors.append(f"{rel}: does not reference {scope_id}")

# --- Vocabulary placement (ADR-002, tenant neutrality) ------------------------
SELF = Path(__file__).resolve()
# Enforcement points necessarily name the tokens they forbid.
ENFORCEMENT_FILES = {
    "scripts/validate_consistency.py",
    "tests/test_architecture_guard.py",
}
EXEMPT_PREFIXES = ("10-baseline/", "11-decisions/", "evidence/provenance/")
SUPERSEDED = [re.compile(p) for p in (r"\bTEE\b", r"\bfounder\b", r"body/mind")]
PILOT = re.compile(r"\bIPBS\b")
PILOT_DOC_ALLOWLIST = {
    "00-control/PROJECT-START.md",  # names IPBS as tenant/pilot, per SaaS rule
    "00-control/RELEASE-NOTES-V002.md",
    "00-control/RELEASE-NOTES-V003.md",
    "00-control/RELEASE-NOTES-V004.md",
    "00-control/RELEASE-NOTES-V005.md",
    "00-control/RELEASE-NOTES-V006.md",
    "00-control/RELEASE-NOTES-V007.md",
    "00-control/RELEASE-NOTES-V008.md",
    "00-control/RELEASE-NOTES-V009.md",
    "00-control/RELEASE-NOTES-V010.md",
    "01-product/CANONICAL-SCOPE.md",  # states the exclusion itself
    "01-product/PRODUCT-BOUNDARY-AND-SAAS.md",
    "02-architecture/INTEGRATION-BOUNDARIES.md",
    "07-planning/FIRST-BUILD-BACKLOG.md",
    "08-ai/CLAUDE-V002-HANDOFF.md",
    "08-ai/CLAUDE-V003-HANDOFF.md",
    "08-ai/CLAUDE-V004-HANDOFF.md",
    "08-ai/CLAUDE-V005-HANDOFF.md",
    "08-ai/CLAUDE-V006-HANDOFF.md",
    "08-ai/CLAUDE-V007-HANDOFF.md",
    "08-ai/CLAUDE-V008-HANDOFF.md",
    "08-ai/CLAUDE-V009-HANDOFF.md",
    "08-ai/CLAUDE-V010-HANDOFF.md",
    "CLAUDE.md",
}
for path in sorted(ROOT.rglob("*")):
    if not path.is_file() or path.resolve() == SELF:
        continue
    rel = path.relative_to(ROOT).as_posix()
    if (
        rel in ENFORCEMENT_FILES
        or rel.startswith(EXEMPT_PREFIXES)
        or rel.startswith(("mutants/", "."))
        or "__pycache__" in rel
    ):
        continue
    if path.suffix not in {".md", ".py", ".json", ".ini", ".cfg", ".txt"}:
        continue
    text = path.read_text(encoding="utf-8", errors="ignore")
    in_code = rel.startswith(("src/", "tests/"))
    for rx in SUPERSEDED:
        if rx.search(text):
            errors.append(
                f"{rel}: superseded vocabulary '{rx.pattern}' outside baseline/ADRs (ADR-002)"
            )
    if PILOT.search(text) and (
        in_code or (not rel.startswith(("src/", "tests/")) and rel not in PILOT_DOC_ALLOWLIST)
    ):
        errors.append(f"{rel}: pilot-tenant name outside allowlisted pilot/evidence docs")

# --- Manifest integrity: CLOSED over the shipped managed set (F43/F46/F47) ----
# Not just "every listed file still hashes" (one-way, V009 review F43) but also
# "every shipped managed file is listed", plus no duplicates and an accurate
# file_count. Membership uses the SHARED policy in manifest_policy.py, so the
# validator and gen_manifest.py cannot disagree about what "managed" means.
# The policy's exclusions are an explicit named allowlist — no generic hidden-
# directory rule (F46) — and every entry's `bytes` metadata is verified against
# the real file size, not silently ignored (F47).
# --- Manifest integrity: CLOSED over the shipped managed set (F43/F46/F47/F48/F49/F51)
# Not just "every listed file still hashes" (one-way, V009 review F43) but also
# "every shipped managed file is listed", plus no duplicates and an accurate
# file_count. Membership uses the SHARED policy in manifest_policy.py, so the
# validator and gen_manifest.py cannot disagree about what "managed" means.
# Only the EXACT root manifest is unmanaged (F48 — nested manifests are bound);
# dev/cache/VCS artifacts are REJECTED in release mode rather than silently
# excluded (F48); symlinks/non-regular files are rejected via non-following
# inspection (F49); every entry's bytes is verified (F47) and the manifest
# schema/keys/grammar are strictly validated (F51).
_HEX64_RE = re.compile(r"[0-9a-f]{64}")
_ISO_UTC_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\+00:00|Z)")
_release_mode = "--dev" not in sys.argv and not ROOT.name.endswith("_WIP")
if "--skip-manifest" not in sys.argv:
    mf = ROOT / "PACKAGE-MANIFEST.json"
    if mf.is_file():
        manifest = json.loads(mf.read_text(encoding="utf-8"))

        # (0) STRICT SCHEMA (F51): exact top-level keys, no unknowns, correct
        #     constant values and timestamp grammar; exact per-file keys/types
        #     and path/sha256 grammar. Machine-generated metadata that the gate
        #     does not validate is not permitted to exist.
        top_keys = set(manifest.keys())
        if top_keys != set(MANIFEST_TOP_KEYS):
            missing = sorted(set(MANIFEST_TOP_KEYS) - top_keys)
            unknown = sorted(top_keys - set(MANIFEST_TOP_KEYS))
            errors.append(
                f"manifest top-level keys invalid (F51): missing={missing} unknown={unknown}"
            )
        if manifest.get("schema") != MANIFEST_SCHEMA:
            errors.append(
                f"manifest schema '{manifest.get('schema')}' != '{MANIFEST_SCHEMA}' (F51)"
            )
        if manifest.get("project") != MANIFEST_PROJECT:
            errors.append(
                f"manifest project '{manifest.get('project')}' != '{MANIFEST_PROJECT}' (F51)"
            )
        generated = manifest.get("generated")
        if type(generated) is not str or _ISO_UTC_RE.fullmatch(generated) is None:
            errors.append(
                f"manifest 'generated' is not an ISO-8601 UTC timestamp (F51): {generated!r}"
            )
        if type(manifest.get("file_count")) is not int:
            errors.append("manifest file_count must be an int (F51)")
        if type(manifest.get("release")) is not str or not manifest.get("release"):
            errors.append("manifest release must be a non-empty str (F51)")

        entries = manifest.get("files", [])
        if type(entries) is not list:
            errors.append("manifest 'files' must be a list (F51)")
            entries = []
        for entry in entries:
            if type(entry) is not dict or set(entry.keys()) != set(MANIFEST_FILE_KEYS):
                errors.append(f"manifest entry has invalid keys (F51): {entry!r}")
                continue
            if (
                type(entry["path"]) is not str
                or type(entry["bytes"]) is not int
                or type(entry["sha256"]) is not str
            ):
                errors.append(f"manifest entry has wrong field types (F51): {entry!r}")
                continue
            rel_path = entry["path"]
            if rel_path.startswith("/") or ".." in Path(rel_path).parts or "\\" in rel_path:
                errors.append(
                    f"manifest entry path is not a safe relative POSIX path (F51): {rel_path}"
                )
            if _HEX64_RE.fullmatch(entry["sha256"]) is None:
                errors.append(
                    f"manifest entry sha256 is not 64 lowercase hex chars (F51): {rel_path}"
                )

        listed_paths = [
            entry["path"]
            for entry in entries
            if type(entry) is dict and type(entry.get("path")) is str
        ]

        # (F48/F49) FORBIDDEN ARTIFACTS: in release mode, dev/cache/VCS artifacts
        #     and ANY symlink must not be present — reject rather than ignore.
        if _release_mode:
            for art in forbidden_release_artifacts(ROOT):
                errors.append(
                    f"forbidden dev/cache/VCS artifact or symlink present in release tree: "
                    f"{art} (F48/F49); it must not ship — regenerate a clean package"
                )

        # (a) hashes AND sizes of listed files, with file-KIND binding (F49):
        #     the entry must be a REAL regular file, never a symlink whose bytes
        #     merely happen to match. Non-following lstat inspection.
        for entry in entries:
            if type(entry) is not dict or type(entry.get("path")) is not str:
                continue
            p = ROOT / entry["path"]
            if p.is_symlink():
                errors.append(
                    f"manifest entry is a symlink, not a regular file: {entry['path']} (F49)"
                )
                continue
            if not p.is_file():
                errors.append(f"manifest lists missing file: {entry['path']}")
                continue
            try:
                is_reg = stat.S_ISREG(p.lstat().st_mode)
            except OSError:
                is_reg = False
            if not is_reg:
                errors.append(f"manifest entry is not a regular file: {entry['path']} (F49)")
                continue
            if hashlib.sha256(p.read_bytes()).hexdigest() != entry["sha256"]:
                errors.append(f"manifest hash mismatch: {entry['path']}")
            if entry.get("bytes") != p.stat().st_size:
                errors.append(
                    f"manifest bytes mismatch: {entry['path']} lists "
                    f"{entry.get('bytes')} but file is {p.stat().st_size} (F47)"
                )

        # (b) duplicate entries
        seen: set[str] = set()
        for path_str in listed_paths:
            if path_str in seen:
                errors.append(f"duplicate manifest entry: {path_str} (F43)")
            seen.add(path_str)

        # (c) file_count matches unique entries
        if manifest.get("file_count") != len(seen):
            errors.append(
                f"manifest file_count {manifest.get('file_count')} != unique entries "
                f"{len(seen)} (F43)"
            )

        # (d) CLOSED SET: every shipped managed file is listed, and every listed
        #     path is a real managed file (no stale/foreign entries).
        actual_managed = set(_managed_files(ROOT))
        listed_set = set(listed_paths)
        unmanifested = sorted(actual_managed - listed_set)
        for path_str in unmanifested:
            errors.append(
                f"shipped managed file missing from manifest: {path_str} (F43); "
                f"the manifest must be closed over the shipped set"
            )
        stale = sorted(listed_set - actual_managed)
        for path_str in stale:
            errors.append(f"manifest lists a non-managed/foreign path: {path_str} (F43)")
    else:
        errors.append("PACKAGE-MANIFEST.json missing")

# --- Evidence and gate-status cross-checks ------------------------------------
summary_path = ROOT / "evidence/test-summary.json"
if summary_path.is_file():
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    if summary.get("tests_passed", 0) <= 0 or summary.get("tests_failed", 1) != 0:
        errors.append("evidence/test-summary.json does not record a fully passing suite")
    for key in ("coverage_line_percent", "coverage_branch_percent"):
        if summary.get(key) != 100.0:
            errors.append(f"evidence: {key} is not 100 (G04)")
# --- Stale-version rule (V004 review, F26): current canonical docs must not
# embed "as of V00N" implementation-status references; history files may.
STALE_VERSION_RE = re.compile(r"as of V\d+")
CANONICAL_DOC_DIRS = ("01-product/", "02-architecture/")
CANONICAL_DOC_FILES = {"06-traceability/RTM.md", "00-control/READING-MAP.md"}
for path in sorted(ROOT.rglob("*.md")):
    rel = path.relative_to(ROOT).as_posix()
    is_canonical = rel.startswith(CANONICAL_DOC_DIRS) or rel in CANONICAL_DOC_FILES
    if is_canonical and STALE_VERSION_RE.search(path.read_text(encoding="utf-8")):
        errors.append(
            f"{rel}: stale 'as of V00N' status reference in a current canonical doc (F26); point at an RTM row instead"
        )

# --- Overclaim heuristic (V003 review): strong bypass-immunity claims must be
# backed by the adversarial construction suite actually attacking raw values.
OVERCLAIM_PHRASES = ("every construction path", "cannot be bypassed")
rtm_text = (
    (ROOT / "06-traceability/RTM.md").read_text(encoding="utf-8")
    if (ROOT / "06-traceability/RTM.md").is_file()
    else ""
)
if any(phrase in rtm_text for phrase in OVERCLAIM_PHRASES):
    adversarial = ROOT / "tests/test_adversarial_construction.py"
    if not adversarial.is_file():
        errors.append(
            "RTM claims construction-path immunity but tests/test_adversarial_construction.py is missing"
        )
    else:
        attack_text = adversarial.read_text(encoding="utf-8")
        if 'state="X"' not in attack_text or '"EXECUTION"' not in attack_text:
            errors.append(
                "adversarial suite no longer contains the raw-value attack payloads backing the RTM immunity claim"
            )

# --- Canonical release identity (V007 review, F36) ----------------------------
# ONE machine-readable source of truth (00-control/RELEASE-IDENTITY.json) defines
# the release series. Every other representation is DERIVED and must MATCH it.
# Release identity is never inferred from the artefacts being checked (the V007
# rule used max(RELEASE-NOTES-V*.md), so a stray higher-numbered file became the
# apparent authority — the exact spoof the reviewer asked us to close).
identity_path = ROOT / "00-control/RELEASE-IDENTITY.json"
series: str | None = None
if not identity_path.is_file():
    errors.append("missing canonical release identity: 00-control/RELEASE-IDENTITY.json (F36)")
else:
    try:
        identity = json.loads(identity_path.read_text(encoding="utf-8"))
        series = identity["series"]
        core_version = identity["core_version"]
    except (json.JSONDecodeError, KeyError) as exc:
        errors.append(f"RELEASE-IDENTITY.json is malformed (F36): {exc}")
        series = None

if series is not None:
    if not re.fullmatch(r"V\d+", series):
        errors.append(f"RELEASE-IDENTITY.json series '{series}' is not of the form V<n> (F36)")

    canonical_n = int(series[1:])

    # 1. GENERIC versioned-artifact rule (F40): for EVERY series-numbered
    #    artifact family — release notes, gate statuses, handoffs — the
    #    canonical series' file must exist and NO file numbered ABOVE the
    #    canonical series may exist. A stray/future gate or handoff is a spoof
    #    just as a stray/future release note is; the V008 rule only covered
    #    release notes, so future gates/handoffs slipped through.
    VERSIONED_ARTIFACTS = (
        ("00-control", "RELEASE-NOTES-V{n}.md", r"RELEASE-NOTES-V(\d+)\.md"),
        ("05-quality", "GATE-STATUS-V{n}.md", r"GATE-STATUS-V(\d+)\.md"),
        ("08-ai", "CLAUDE-V{n}-HANDOFF.md", r"CLAUDE-V(\d+)-HANDOFF\.md"),
    )
    for subdir, current_tmpl, pattern in VERSIONED_ARTIFACTS:
        rx = re.compile(pattern)
        found = []
        for f in sorted((ROOT / subdir).glob("*")):
            m = rx.fullmatch(f.name)
            if m:
                found.append(int(m.group(1)))
        current_name = current_tmpl.format(n=canonical_n)
        if canonical_n not in found:
            errors.append(
                f"missing canonical-series artifact {subdir}/{current_name} (F40); "
                f"identity says {series} but the file is absent"
            )
        future = sorted(n for n in found if n > canonical_n)
        if future:
            future_names = [current_tmpl.format(n=n) for n in future]
            errors.append(
                f"{subdir}: artifacts newer than canonical {series} present: {future_names} "
                f"(F40); release identity must not be spoofed by a stray/future artifact"
            )

    # 2. The manifest 'release' string must embed the canonical series.
    mf_path = ROOT / "PACKAGE-MANIFEST.json"
    if mf_path.is_file():
        try:
            release_str = json.loads(mf_path.read_text(encoding="utf-8")).get("release", "")
        except json.JSONDecodeError:
            release_str = ""
        if f"_{series}_" not in release_str and not release_str.endswith(f"_{series}"):
            errors.append(
                f"manifest release '{release_str}' does not match canonical series {series} (F36)"
            )

    # 3. The actual package ROOT (directory name) must embed the canonical
    #    series and agree with the manifest release (F40/F44). RELEASE-IDENTITY
    #    calls the directory name a derived representation that must match, so in
    #    RELEASE-VALIDATION mode this is enforced UNCONDITIONALLY — an arbitrary
    #    name like "BADNAME" is a failure, not a reason to skip the check (V009
    #    review F44). Development trees pass --dev (or a *_WIP name) to opt out
    #    explicitly, rather than the validator silently inferring dev mode from
    #    an unexpected directory name.
    root_name = ROOT.name
    dev_mode = "--dev" in sys.argv or root_name.endswith("_WIP")
    if not dev_mode:
        if f"_{series}_" not in root_name and not root_name.endswith(f"_{series}"):
            errors.append(
                f"package root '{root_name}' does not embed canonical series {series} "
                f"(F40/F44); pass --dev for development trees"
            )
        mf_path2 = ROOT / "PACKAGE-MANIFEST.json"
        if mf_path2.is_file():
            try:
                mrel = json.loads(mf_path2.read_text(encoding="utf-8")).get("release", "")
            except json.JSONDecodeError:
                mrel = ""
            if mrel and mrel != root_name:
                errors.append(
                    f"manifest release '{mrel}' != package root directory '{root_name}' (F40/F44)"
                )

    # 4. pyproject version must equal the canonical core_version.
    pyproject_path = ROOT / "pyproject.toml"
    if pyproject_path.is_file():
        pv = re.search(r'(?m)^version\s*=\s*"([^"]+)"', pyproject_path.read_text(encoding="utf-8"))
        if pv and pv.group(1) != core_version:
            errors.append(
                f"pyproject version '{pv.group(1)}' != canonical core_version "
                f"'{core_version}' (F36)"
            )

    # 5. Current-cycle rule (F33, now anchored to canonical identity): the RTM
    #    AI-001 row must reference the CANONICAL series' handoff.
    rtm_path = ROOT / "06-traceability/RTM.md"
    if rtm_path.is_file():
        ai_rows = [
            line
            for line in rtm_path.read_text(encoding="utf-8").splitlines()
            if line.startswith("| AI-001 ")
        ]
        expected_handoff = f"CLAUDE-{series}-HANDOFF.md"
        if not ai_rows:
            errors.append("RTM has no AI-001 row for the current-cycle check (F33)")
        elif expected_handoff not in ai_rows[0]:
            errors.append(
                f"RTM AI-001 does not reference the canonical current-cycle handoff "
                f"{expected_handoff} (F33/F36)"
            )

    # 6. Current-document freshness rule (V011 review, F52): READING-MAP is a
    #    navigational INDEX, so when it names version-numbered artefacts it must
    #    name the CANONICAL series' ones. Through V011 it still pointed readers
    #    at V007's gate status, release notes and handoff, and omitted the
    #    ACCEPTED ADR-015 — a reader following the map would have reasoned about
    #    a superseded release and missed the trust model entirely. A structural
    #    rule cannot prove a document is semantically current (F41 honesty), but
    #    it CAN prove the map does not point at a superseded series artefact and
    #    does not omit the newest accepted decision.
    reading_map = ROOT / "00-control/READING-MAP.md"
    if reading_map.is_file():
        map_text = reading_map.read_text(encoding="utf-8")
        for tmpl in ("GATE-STATUS-V{n}.md", "RELEASE-NOTES-V{n}.md", "CLAUDE-V{n}-HANDOFF.md"):
            rx = re.compile(tmpl.format(n=r"(\d+)"))
            for m in rx.finditer(map_text):
                if int(m.group(1)) != canonical_n:
                    errors.append(
                        f"00-control/READING-MAP.md references superseded artefact "
                        f"{m.group(0)} but canonical series is {series} (F52)"
                    )
        accepted_nums = []
        for adr in adr_files:
            am = re.match(r"ADR-(\d+)", adr.name)
            if am and re.search(
                r"^Status:\s*ACCEPTED", adr.read_text(encoding="utf-8"), re.MULTILINE
            ):
                accepted_nums.append(int(am.group(1)))
        if accepted_nums:
            highest_adr = f"ADR-{max(accepted_nums):03d}"
            if highest_adr not in map_text:
                errors.append(
                    f"00-control/READING-MAP.md does not mention the highest ACCEPTED "
                    f"decision {highest_adr} (F52)"
                )

if series is not None:
    gate_status = ROOT / f"05-quality/GATE-STATUS-{series}.md"
    if gate_status.is_file() and "evidence/test-summary.json" not in gate_status.read_text(
        encoding="utf-8"
    ):
        errors.append(
            f"GATE-STATUS-{series}.md must reference evidence/test-summary.json, not hand-typed counts"
        )

# --- Retired-overclaim phrase rule (V007 review, F34) -------------------------
# The domain core enforces authorization POLICY, not authenticated authority.
# Phrases that claim the domain core owns an authenticated security decision, or
# that a supplied object cannot be forged, are retired from CURRENT canonical
# docs and current code. History (baseline/ADR bodies/old handoffs/old gates)
# may quote them; the machine rule keeps them out of the live surface.
RETIRED_PHRASES = (
    "no mutated or lying object can forge",
    "authenticated entitlement set",
    "the real security decision",
    "domain-core AUTHORIZATION check",
)
OVERCLAIM_EXEMPT_PREFIXES = (
    "10-baseline/",
    "11-decisions/",  # ADR bodies quote the retired wording while correcting it
    "evidence/",
    "00-control/RELEASE-NOTES-",  # release notes are historical records
)
OVERCLAIM_EXEMPT_FILES = {
    "scripts/validate_consistency.py",  # this rule names the phrases it forbids
}
# Older-version gate statuses and handoffs are historical; only the CURRENT
# series' gate/handoff are held to the retired-phrase rule.
for path in sorted(ROOT.rglob("*.md")):
    rel = path.relative_to(ROOT).as_posix()
    if rel.startswith(OVERCLAIM_EXEMPT_PREFIXES) or rel in OVERCLAIM_EXEMPT_FILES:
        continue
    # Skip superseded-version gate/handoff history (keep only current series).
    m = re.search(r"(?:GATE-STATUS|CLAUDE)-V(\d+)", path.name)
    if m and series is not None and int(m.group(1)) != int(series[1:]):
        continue
    lowered = path.read_text(encoding="utf-8", errors="ignore").lower()
    for phrase in RETIRED_PHRASES:
        if phrase.lower() in lowered:
            errors.append(
                f"{rel}: retired overclaim phrase '{phrase}' in a current doc (F34); "
                f"the domain core enforces authorization POLICY, not authenticated authority"
            )
for src_path in sorted((ROOT / "src").rglob("*.py")):
    rel = src_path.relative_to(ROOT).as_posix()
    lowered = src_path.read_text(encoding="utf-8", errors="ignore").lower()
    for phrase in RETIRED_PHRASES:
        if phrase.lower() in lowered:
            errors.append(f"{rel}: retired overclaim phrase '{phrase}' in current code (F34)")

# --- ADR-014 F35 contradiction regression (V007 review, F35) ------------------
# SCOPE (F41, honest): this is a SPECIFIC STRUCTURAL REGRESSION for the exact
# F35 defect, NOT a general "accepted ADRs never contradict their release"
# validator. A text validator cannot semantically prove architectural
# consistency; independent review remains the semantic gate (see RTM DOC-004,
# G10). This rule deterministically catches the ONE known contradiction:
# ADR-014 re-asserting the withdrawn "private consistency tag" without its
# Amendment A1, or that tag reappearing in tenancy.py.
adr014 = ROOT / "11-decisions/ADR-014-authorization-trust-boundary.md"
if adr014.is_file():
    adr_text = adr014.read_text(encoding="utf-8")
    handoff7 = ROOT / "08-ai/CLAUDE-V007-HANDOFF.md"
    handoff_says_not_shipped = handoff7.is_file() and "NOT shipped" in handoff7.read_text(
        encoding="utf-8"
    )
    asserts_tag = "private consistency tag" in adr_text
    has_amendment = "Amendment A1" in adr_text
    if asserts_tag and handoff_says_not_shipped and not has_amendment:
        errors.append(
            "ADR-014 asserts a 'private consistency tag' the handoff says was NOT shipped, "
            "with no amendment resolving it (F35): an ACCEPTED ADR must match the release"
        )
    # The integrity tag must not actually exist in code while being called dead.
    if "consistency_tag" in (ROOT / "src/cgwo_core/tenancy.py").read_text(encoding="utf-8"):
        errors.append(
            "tenancy.py contains a consistency_tag the architecture says is not shipped (F35)"
        )

if errors:
    print("CONSISTENCY: FAIL")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("CONSISTENCY: PASS")
