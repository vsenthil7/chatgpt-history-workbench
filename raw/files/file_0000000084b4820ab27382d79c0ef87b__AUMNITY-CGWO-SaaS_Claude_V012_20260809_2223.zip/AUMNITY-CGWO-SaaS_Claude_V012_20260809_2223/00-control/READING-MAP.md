# Reading Map

Version-numbered entries below are written as `V<current>` placeholders resolved
against the ONE canonical source, `00-control/RELEASE-IDENTITY.json` (ADR-009,
review F36). The machine rule in `scripts/validate_consistency.py` checks that
this map points at the CANONICAL series' artefacts, so it cannot silently rot
into naming a superseded release the way it did through V011 (review F52).

1. `00-control/PROJECT-START.md`
2. `01-product/PRODUCT-BOUNDARY-AND-SAAS.md`
3. `02-architecture/MODULARITY-AND-REUSE.md`
4. `03-engineering/ENGINEERING-OPERATING-SYSTEM.md`
5. `04-testing/TESTING-STRATEGY.md`
6. `05-quality/QUALITY-GATES.md`
7. `06-traceability/RTM.md`
8. `07-planning/FIRST-BUILD-BACKLOG.md`
9. `11-decisions/` — ADR-001 through ADR-016, including the ACCEPTED trust-model
   decision ADR-015 and the fail-closed port contract ADR-016. Read `ADR-015`
   before reasoning about anything security-shaped: it defines what the domain
   core does and does NOT claim.
10. `05-quality/GATE-STATUS-V012.md` and `00-control/RELEASE-NOTES-V012.md`
    (earlier equivalents preserved as history)
11. `CLAUDE.md` when implementing
12. `08-ai/CHATGPT-REVIEW-HANDOFF.md` and `08-ai/CLAUDE-V012-HANDOFF.md` before packaging
13. `10-baseline/` for prior detailed product material
