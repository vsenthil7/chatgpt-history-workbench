# ADR-016 — Fail-closed enforcement of the authorization port's return contract

Status: ACCEPTED
Date: 2026-08-09
Responds to: independent review of V011, finding F50.

## Context

`AuthorizationPort` declares `def is_entitled(self, tenant_id: str) -> bool`. Through V011 the gate consumed that declaration as `if not authz.is_entitled(checked):`, which asks Python for a *truthiness* verdict rather than binding the *declared type*. `isinstance(authz, AuthorizationPort)` is a `runtime_checkable` structural Protocol check: it confirms the attribute EXISTS, not that it is callable, and never constrains what it returns.

The V011 review demonstrated the consequences against the shipped package. A provider returning a truthy non-boolean — `object()`, or the string `"false"` — **authorized the operation**. A provider whose `is_entitled` was a non-callable attribute raised a raw `TypeError`. A provider that raised, or returned an object whose `__bool__` raised, leaked a raw `ConnectionError`/`RuntimeError` straight through the authorization gate. The `"false"` case is the sharpest: a provider serialising its decision as a string, or returning an HTTP response wrapper, reads as ALLOW.

This is not the recurring "prove the capability is genuine" question. ADR-015 settled that: no in-process Python object can prove authority, and the trust root is the service boundary (G08 RED half). ADR-016 addresses a different and strictly smaller question — given that the domain core has decided to *trust* the supplied port, must it also *believe an ill-typed answer from it*? A security gate that resolves ambiguity by truthiness fails OPEN, and failing open on a malformed decision is a defect regardless of who supplied the port.

## Decisions

1. **The decision is taken exactly once.** `assert_authorized` calls `is_entitled` a single time and binds the result. Two calls would permit a TOCTOU divergence between the checked value and the used value, and would double-charge a remote entitlement service.
2. **The declared return type is enforced exactly**: `type(decision) is bool`. Consistent with ADR-012's canonical-primitive stance, this is an exact-type check, not `isinstance` — and it is deliberately applied to falsy non-booleans (`0`, `""`, `[]`, `None`) as well as truthy ones, so the rule is a type contract rather than a truthiness coincidence that merely happens to deny. A non-boolean decision raises `AUTHZ_DECISION_NOT_BOOL`.
3. **Type is checked BEFORE truthiness.** A hostile or faulty `__bool__` is therefore never invoked, so it cannot raise through the gate.
4. **Port and provider failures fail CLOSED with stable codes**: a non-callable `is_entitled` raises `AUTHZ_PORT_UNUSABLE`; any non-`DomainError` exception from the provider is chained into a controlled `AUTHZ_PROVIDER_ERROR`. A controlled `DomainError` raised BY the port surfaces unchanged, because it is already a denial-shaped, stable signal.

## Alternatives considered

- **Keep truthiness and document the expectation.** Rejected: the repository's whole review history is that documented expectations at trust boundaries get violated, and here the failure direction is ALLOW.
- **Coerce with `bool(decision)`.** Rejected: it *formalises* the fail-open behaviour — `bool("false")` is `True` — and invokes hostile `__bool__`.
- **Validate the port at construction/injection instead.** Rejected as insufficient on its own: a structural Protocol cannot constrain a return value, which is only observable per call, and a port may decide dynamically.
- **Treat a malformed decision as DENY silently.** Rejected: it hides a provider defect. A distinct controlled error is both fail-closed and diagnosable.

## Consequences

- A conforming provider sees no behaviour change: exact `True` allows, exact `False` denies.
- A non-conforming provider now fails loudly and closed instead of silently authorizing. This is a deliberate, breaking tightening of the port contract.
- Three new stable error codes join the identity matrix; the reviewer's exact payloads are permanent regressions in `tests/test_authz.py`, including an assertion that the hostile `__bool__` is never invoked and that the provider is called exactly once.
- **Scope honesty, unchanged:** this does NOT make the domain core a trust root and does not narrow G08's RED half. It enforces a declared interface contract. Authenticated identity binding and authoritative aggregate provenance remain service-layer prerequisites (ADR-015, RTM SEC-003).
