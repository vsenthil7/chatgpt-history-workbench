"""F43/F46/F47/F48/F49/F51 regressions: package-manifest integrity is CLOSED
over the shipped set, with only the ROOT manifest unmanaged, dev artifacts
REJECTED, symlinks refused and the schema strictly validated.

Cumulative review history anchored here:
- F43 (V009): hash-only validation is one-way; an unmanifested EXTRA.txt passed.
- F46 (V010): a generic dot-directory exclusion hid `.evil/payload.py`.
- F47 (V010): the `bytes` field was generated but never checked.
- F48 (V011): excluded NAMES applied anywhere, so `.evil/PACKAGE-MANIFEST.json`,
  `.evil/.coverage`, `.evil/.DS_Store` and `.git/hooks/post-checkout` were all
  invisible, and the preserved baseline's own nested manifest was unbound and
  could be tampered undetected.
- F49 (V011): traversal/verification followed symlinks, so a managed source file
  could be replaced by a symlink to excluded payload bytes.
- F51 (V011): schema/project/generated and unknown fields were unvalidated.

These tests exercise the SHIPPED validator against a temporary copy so every
closure rule is anchored end-to-end, and assert the generator and validator
share one membership policy.
"""

import json
import shutil
import subprocess
import sys
from pathlib import Path


def _repo_root() -> Path:
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "00-control/RELEASE-IDENTITY.json").is_file():
            return parent
    return here.parents[1]


ROOT = _repo_root()
sys.path.insert(0, str(ROOT / "scripts"))
from manifest_policy import (
    FORBIDDEN_DIRS,
    FORBIDDEN_FILES,
    ROOT_MANIFEST,
    is_forbidden_release_artifact,
    is_managed,
)


def _copy_package(tmp_path: Path) -> Path:
    dest = tmp_path / ROOT.name
    # Dev/cache artifacts must not ship (F48); skip them at copy time, sourced
    # from the SHARED policy so this helper cannot drift from it. symlinks=False
    # so a symlink in the live tree would be copied as its target's bytes rather
    # than silently reproducing a link the release forbids anyway (F49).
    shutil.copytree(
        ROOT,
        dest,
        symlinks=False,
        ignore=shutil.ignore_patterns(*FORBIDDEN_DIRS, *FORBIDDEN_FILES),
    )
    return dest


def _regen_manifest(pkg: Path) -> None:
    """Regenerate the copy's manifest with the SHIPPED generator so each attack
    test is HERMETIC: it starts from a provably consistent copy and then makes
    exactly one adversarial change, ensuring the validator failure it asserts
    has exactly one cause (and the pass-control genuinely passes) regardless of
    whether the LIVE tree's manifest is momentarily stale mid-gate-pipeline."""
    subprocess.run(
        [sys.executable, "scripts/gen_manifest.py"],
        cwd=pkg,
        capture_output=True,
        text=True,
        check=True,
    )


def _run_validator(pkg: Path, *extra: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "scripts/validate_consistency.py", *extra],
        cwd=pkg,
        capture_output=True,
        text=True,
        check=False,
    )


def test_manifest_matches_shared_policy():
    """The manifest's file set equals the shared policy's managed set (F43)."""
    sys.path.insert(0, str(ROOT / "scripts"))
    from manifest_policy import managed_files

    manifest = json.loads((ROOT / "PACKAGE-MANIFEST.json").read_text(encoding="utf-8"))
    listed = {e["path"] for e in manifest["files"]}
    assert listed == set(managed_files(ROOT))
    assert manifest["file_count"] == len(listed)


def test_unmanifested_file_fails_validation(tmp_path):
    """The exact F43 attack: an extra file added after manifest generation."""
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    (pkg / "EXTRA.txt").write_text("junk\n")
    result = _run_validator(pkg)  # full manifest check (no --skip-manifest)
    assert result.returncode != 0
    assert "F43" in result.stdout
    assert "EXTRA.txt" in result.stdout


def test_duplicate_manifest_entry_fails(tmp_path):
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    mf = pkg / "PACKAGE-MANIFEST.json"
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    manifest["files"].append(dict(manifest["files"][0]))  # duplicate first entry
    mf.write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F43" in result.stdout


def test_wrong_file_count_fails(tmp_path):
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    mf = pkg / "PACKAGE-MANIFEST.json"
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    manifest["file_count"] = manifest["file_count"] + 100
    mf.write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F43" in result.stdout


# --- F46: exclusions are an EXPLICIT allowlist — hidden dirs are not a bypass --
def test_f46_policy_manages_arbitrary_hidden_paths():
    """Unit anchor for the policy itself: known named caches are excluded,
    but an ARBITRARY hidden directory is MANAGED — the excluded universe is a
    reviewed allowlist, never an adversary-chosen naming convention."""
    # Known build/cache directories stay excluded.
    assert not is_managed(Path(".pytest_cache/v/cache/lastfailed"))
    assert not is_managed(Path(".ruff_cache/CACHEDIR.TAG"))
    assert not is_managed(Path("mutants/src/cgwo_core/plan_item.py"))
    assert not is_managed(Path("src/__pycache__/x.pyc"))
    # The F46 attack surface: arbitrary hidden paths ARE managed.
    assert is_managed(Path(".evil/payload.py"))
    assert is_managed(Path(".hidden-file"))
    assert is_managed(Path("src/.sneaky/mod.py"))


def test_f46_unmanifested_hidden_file_fails_validation(tmp_path):
    """The exact F46 attack: `.evil/payload.py` added after manifest
    generation must fail closed-set validation, exactly as EXTRA.txt does."""
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    evil = pkg / ".evil"
    evil.mkdir()
    (evil / "payload.py").write_text("payload\n")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert ".evil/payload.py" in result.stdout
    assert "F43" in result.stdout  # reported through the closed-set rule


# --- F47: manifest `bytes` metadata is VERIFIED, not decorative ---------------
def test_f47_falsified_bytes_fails_validation(tmp_path):
    """The exact F47 attack: a false `bytes` value with the file and its
    SHA-256 untouched must fail — the schema carries no unverified metadata."""
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    mf = pkg / "PACKAGE-MANIFEST.json"
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    manifest["files"][0]["bytes"] = manifest["files"][0]["bytes"] + 999
    mf.write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "bytes mismatch" in result.stdout
    assert "F47" in result.stdout


def test_f47_correct_bytes_pass(tmp_path):
    """Control: the untampered copy (correct bytes everywhere) passes, so the
    F47 rule rejects only genuine mismatches."""
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    result = _run_validator(pkg)
    assert result.returncode == 0, result.stdout


# --- F48: only the ROOT manifest is unmanaged; dev artifacts are REJECTED -----
def test_f48_policy_manages_nested_manifests_and_excluded_names_everywhere():
    """Unit anchor: the ONLY unmanaged path is the exact root manifest. Names
    that were previously excluded anywhere in the tree are managed when they
    appear under any other path, so a hidden directory cannot launder a
    payload by borrowing an excluded basename."""
    assert not is_managed(ROOT_MANIFEST)  # a manifest cannot hash itself
    # The V011 bypass set — all managed now.
    assert is_managed(Path(".evil/PACKAGE-MANIFEST.json"))
    assert is_managed(Path("10-baseline/pkg/PACKAGE-MANIFEST.json"))
    assert is_managed(Path("src/.sneaky/mod.py"))
    assert is_managed(Path(".evil/payload.py"))


def test_f48_dev_and_vcs_artifacts_are_forbidden_not_ignored():
    """Dev/cache/VCS artifacts are release-FORBIDDEN, not silently excluded."""
    for rel in (
        Path(".git/hooks/post-checkout"),
        Path(".pytest_cache/v/cache/lastfailed"),
        Path("mutants/src/x.py"),
        Path("src/__pycache__/x.pyc"),
        Path(".evil/.coverage"),
        Path(".evil/.DS_Store"),
    ):
        assert is_forbidden_release_artifact(rel), rel
        assert not is_managed(rel), rel
    # Ordinary release content is neither forbidden nor unmanaged.
    assert not is_forbidden_release_artifact(Path("src/cgwo_core/plan_item.py"))


def test_f48_hidden_dir_borrowing_excluded_basename_fails(tmp_path):
    """The exact F48 attack: `.evil/PACKAGE-MANIFEST.json` added after manifest
    generation must FAIL closed-set validation."""
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    evil = pkg / ".evil"
    evil.mkdir()
    (evil / "PACKAGE-MANIFEST.json").write_text("payload\n")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert ".evil/PACKAGE-MANIFEST.json" in result.stdout


def test_f48_vcs_artifact_present_fails_release_validation(tmp_path):
    """`.git/hooks/post-checkout` is rejected as a forbidden release artifact
    rather than silently ignored."""
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    hooks = pkg / ".git" / "hooks"
    hooks.mkdir(parents=True)
    (hooks / "post-checkout").write_text("payload\n")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "forbidden" in result.stdout
    assert ".git/hooks/post-checkout" in result.stdout
    assert "F48" in result.stdout


def test_f48_tampered_nested_baseline_manifest_fails(tmp_path):
    """The preserved baseline's own nested manifest is BOUND by the outer
    manifest, so tampering with it is detected."""
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    nested = sorted(p for p in (pkg / "10-baseline").rglob("PACKAGE-MANIFEST.json") if p.is_file())
    assert nested, "the preserved baseline should carry its own manifest"
    nested[0].write_text(nested[0].read_text(encoding="utf-8") + "TAMPER\n", encoding="utf-8")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "hash mismatch" in result.stdout


# --- F49: symlinks are refused; manifest entries bind file KIND ---------------
def test_f49_symlinked_managed_file_fails(tmp_path):
    """The exact F49 attack: replace a managed source file with a symlink to
    payload bytes stored under an excluded path, leaving the manifest alone.
    Following the link would still hash correctly, so the validator must bind
    the file KIND using non-following inspection."""
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    target = pkg / "src/cgwo_core/__init__.py"
    payload_dir = pkg / "stash"
    payload_dir.mkdir()
    payload = payload_dir / "payload"
    payload.write_bytes(target.read_bytes())
    target.unlink()
    target.symlink_to(Path("../../stash/payload"))
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "symlink" in result.stdout
    assert "F49" in result.stdout


def test_f49_policy_never_manages_symlinks(tmp_path):
    """managed_files() uses non-following inspection: a symlink is never a
    managed file, even when it resolves to a real regular file."""
    sys.path.insert(0, str(ROOT / "scripts"))
    from manifest_policy import managed_files

    root = tmp_path / "tree"
    (root / "sub").mkdir(parents=True)
    real = root / "sub" / "real.py"
    real.write_text("x = 1\n")
    link = root / "sub" / "link.py"
    link.symlink_to(real)
    managed = managed_files(root)
    assert "sub/real.py" in managed
    assert "sub/link.py" not in managed


# --- F51: manifest schema/metadata is strictly validated ----------------------
def _tamper_manifest(pkg: Path, **changes):
    mf = pkg / "PACKAGE-MANIFEST.json"
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    manifest.update(changes)
    mf.write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")


def test_f51_false_schema_fails(tmp_path):
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    _tamper_manifest(pkg, schema="TOTALLY-FAKE")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F51" in result.stdout


def test_f51_false_project_fails(tmp_path):
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    _tamper_manifest(pkg, project="not-cgwo")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F51" in result.stdout


def test_f51_bad_generated_timestamp_fails(tmp_path):
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    _tamper_manifest(pkg, generated="not-a-timestamp")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F51" in result.stdout


def test_f51_unknown_top_level_key_fails(tmp_path):
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    _tamper_manifest(pkg, injected_assertion="all gates green")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F51" in result.stdout


def test_f51_unknown_per_file_key_fails(tmp_path):
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    mf = pkg / "PACKAGE-MANIFEST.json"
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    manifest["files"][0]["injected"] = "verified"
    mf.write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F51" in result.stdout


def test_f51_bad_sha256_grammar_fails(tmp_path):
    pkg = _copy_package(tmp_path)
    _regen_manifest(pkg)
    mf = pkg / "PACKAGE-MANIFEST.json"
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    manifest["files"][0]["sha256"] = "NOTHEX"
    mf.write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F51" in result.stdout
