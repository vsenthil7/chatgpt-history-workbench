"""F49 regressions: the release ZIP ENVELOPE is verified, not just the extracted tree.

Every other gate runs on an EXTRACTED package, so nothing could see the archive
itself: an extra sibling entry beside the package root, an unsafe path, a
duplicate name, a symlink or a case-fold collision all survived, because the
extracted-package validator can only see what landed inside the root it was
pointed at. `scripts/verify_release_zip.py` reconciles the ARCHIVE against the
manifest it carries. These tests build small adversarial archives and assert the
shipped verifier rejects each one, plus a positive control proving a clean
archive passes (so the rules reject attacks rather than everything).
"""

import hashlib
import json
import sys
import zipfile
from pathlib import Path

import pytest


def _repo_root() -> Path:
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "00-control/RELEASE-IDENTITY.json").is_file():
            return parent
    return here.parents[1]


ROOT = _repo_root()
sys.path.insert(0, str(ROOT / "scripts"))
from verify_release_zip import verify

PKG = "AUMNITY-CGWO-SaaS_Claude_V999_20260101_0000"


def _entry(rel: str, data: bytes) -> dict:
    return {
        "path": rel,
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
    }


def _build_zip(
    tmp_path: Path,
    members: dict[str, bytes] | None = None,
    *,
    manifest_overrides: dict | None = None,
    manifest_files: list[dict] | None = None,
    extra_raw: dict[str, bytes] | None = None,
    symlinks: dict[str, str] | None = None,
    root: str = PKG,
) -> Path:
    """Build a minimal but STRUCTURALLY VALID release archive, then apply the
    caller's single deviation. Each test changes exactly one thing so the
    failure it asserts has exactly one cause."""
    members = {"src/mod.py": b"x = 1\n", "README.md": b"# pkg\n"} if members is None else members
    files = (
        manifest_files
        if manifest_files is not None
        else [_entry(rel, data) for rel, data in sorted(members.items())]
    )
    manifest = {
        "schema": "aumnity-package-manifest/1",
        "project": "AUMNITY CGWO SaaS",
        "release": root,
        "generated": "2026-01-01T00:00:00+00:00",
        "file_count": len(files),
        "files": files,
    }
    manifest.update(manifest_overrides or {})
    zip_path = tmp_path / "release.zip"
    with zipfile.ZipFile(zip_path, "w") as zf:
        for rel, data in members.items():
            zf.writestr(f"{root}/{rel}", data)
        zf.writestr(f"{root}/PACKAGE-MANIFEST.json", json.dumps(manifest, indent=1) + "\n")
        for name, data in (extra_raw or {}).items():
            zf.writestr(name, data)
        for name, target in (symlinks or {}).items():
            info = zipfile.ZipInfo(name)
            info.external_attr = 0o120777 << 16  # S_IFLNK
            zf.writestr(info, target)
    return zip_path


def test_clean_archive_passes(tmp_path):
    """Positive control: a well-formed archive reconciles cleanly."""
    assert verify(str(_build_zip(tmp_path))) == []


def test_sibling_entry_outside_package_root_rejected(tmp_path):
    """The F49 envelope gap: an extra entry BESIDE the root is invisible to the
    extracted-tree validator."""
    errors = verify(str(_build_zip(tmp_path, extra_raw={"payload.sh": b"rm -rf /\n"})))
    assert any("exactly ONE top-level package root" in e or "sibling" in e for e in errors)


def test_second_package_root_rejected(tmp_path):
    errors = verify(str(_build_zip(tmp_path, extra_raw={"OTHER-ROOT/file.txt": b"x\n"})))
    assert any("ONE top-level package root" in e for e in errors)


def test_unsafe_traversal_path_rejected(tmp_path):
    errors = verify(str(_build_zip(tmp_path, extra_raw={f"{PKG}/../escape.txt": b"x\n"})))
    assert any("unsafe ZIP path" in e for e in errors)


def test_absolute_path_rejected(tmp_path):
    errors = verify(str(_build_zip(tmp_path, extra_raw={"/etc/passwd": b"x\n"})))
    assert any("unsafe ZIP path" in e for e in errors)


def test_symlink_entry_rejected(tmp_path):
    errors = verify(str(_build_zip(tmp_path, symlinks={f"{PKG}/link.py": "src/mod.py"})))
    assert any("symlink" in e and "F49" in e for e in errors)


def test_case_fold_collision_rejected(tmp_path):
    """Two entries differing only by case would overwrite each other on a
    case-insensitive filesystem, so the extracted tree would not match the ZIP."""
    errors = verify(str(_build_zip(tmp_path, extra_raw={f"{PKG}/src/MOD.py": b"evil\n"})))
    assert any("collision" in e for e in errors)


def test_unmanifested_archive_member_rejected(tmp_path):
    errors = verify(str(_build_zip(tmp_path, extra_raw={f"{PKG}/EXTRA.txt": b"junk\n"})))
    assert any("missing from manifest" in e for e in errors)


def test_manifest_entry_absent_from_archive_rejected(tmp_path):
    files = [
        _entry("src/mod.py", b"x = 1\n"),
        _entry("README.md", b"# pkg\n"),
        _entry("ghost.py", b"never shipped\n"),
    ]
    errors = verify(str(_build_zip(tmp_path, manifest_files=files)))
    assert any("absent from archive" in e for e in errors)


def test_archive_hash_mismatch_rejected(tmp_path):
    """Bytes are hashed FROM THE ARCHIVE, so a tampered member is caught even
    though the on-disk extracted tree would be regenerated later."""
    files = [_entry("src/mod.py", b"DIFFERENT\n"), _entry("README.md", b"# pkg\n")]
    errors = verify(str(_build_zip(tmp_path, manifest_files=files)))
    assert any("hash mismatch" in e for e in errors)


def test_archive_bytes_mismatch_rejected(tmp_path):
    data = b"x = 1\n"
    entry = _entry("src/mod.py", data)
    entry["bytes"] = entry["bytes"] + 50  # size lies, hash still correct
    errors = verify(
        str(_build_zip(tmp_path, manifest_files=[entry, _entry("README.md", b"# pkg\n")]))
    )
    assert any("bytes mismatch" in e and "F47" in e for e in errors)


def test_manifest_release_must_equal_package_root(tmp_path):
    errors = verify(str(_build_zip(tmp_path, manifest_overrides={"release": "SOMETHING-ELSE"})))
    assert any("!= ZIP package root" in e for e in errors)


def test_missing_root_manifest_rejected(tmp_path):
    zip_path = tmp_path / "nomanifest.zip"
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.writestr(f"{PKG}/src/mod.py", b"x = 1\n")
    errors = verify(str(zip_path))
    assert any("no root manifest" in e for e in errors)


def test_unparseable_manifest_rejected(tmp_path):
    zip_path = tmp_path / "badjson.zip"
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.writestr(f"{PKG}/src/mod.py", b"x = 1\n")
        zf.writestr(f"{PKG}/PACKAGE-MANIFEST.json", b"{not json")
    errors = verify(str(zip_path))
    assert any("not valid UTF-8 JSON" in e for e in errors)


@pytest.mark.parametrize("argv,expected", [(["prog"], 2), (["prog", "a", "b"], 2)])
def test_cli_usage_error(argv, expected):
    from verify_release_zip import main

    assert main(argv) == expected


def test_cli_pass_and_fail(tmp_path, capsys):
    from verify_release_zip import main

    clean = _build_zip(tmp_path)
    assert main(["prog", str(clean)]) == 0
    assert "RELEASE ZIP: PASS" in capsys.readouterr().out

    dirty = _build_zip(tmp_path, extra_raw={f"{PKG}/EXTRA.txt": b"junk\n"})
    assert main(["prog", str(dirty)]) == 1
    assert "RELEASE ZIP: FAIL" in capsys.readouterr().out
