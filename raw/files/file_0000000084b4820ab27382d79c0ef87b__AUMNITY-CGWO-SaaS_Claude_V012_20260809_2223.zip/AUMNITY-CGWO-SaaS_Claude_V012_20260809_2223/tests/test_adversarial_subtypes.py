"""Adversarial subtype/spoof attacks (ADR-012, review findings F20–F24).

Every attack here is taken from, or extends, the independent V004 review:
hostile ``str`` subclasses overriding equality and ``strip`` (the
demonstrated cross-tenant bypass), hostile ``int`` subclasses overriding
comparisons (negative-capacity construction), ``datetime.datetime`` smuggled
into date-only fields (uncontrolled TypeError), spoofed ``__class__``
objects, enum subclass attempts, and non-canonical wire integers. Canonical
exact-type guards must reject them all with controlled DomainErrors.
"""

from datetime import date, datetime

import pytest
from tests._authz import ALL_TENANTS_AUTHZ as AUTHZ

from cgwo_core.allocation import (
    AllocationInvariantError,
    AllocationState,
    CapacityAllocation,
)
from cgwo_core.capacity import (
    AvailabilityDeclaration,
    CapacityInvariantError,
    CapacityType,
    CapacityWindow,
)
from cgwo_core.contracts import ContractViolationError, parse_wire_int
from cgwo_core.errors import INVALID_WIRE_INT, WRONG_RUNTIME_TYPE, DomainError
from cgwo_core.plan_item import PlanItem, PlanItemInvariantError
from cgwo_core.tenancy import MissingTenantContextError, TenantContext

D1, D5 = date(2026, 8, 1), date(2026, 8, 5)
WINDOW = CapacityWindow(
    tenant_id="t1",
    resource_ref="actor-1",
    period_start=D1,
    period_end=D5,
    available_minutes=600,
)


class EqualEverything(str):
    """The review's F20 attack: a tenant id that claims equality with anything."""

    def __eq__(self, other: object) -> bool:
        return True

    def __ne__(self, other: object) -> bool:
        return False

    __hash__ = str.__hash__


class FakeNonBlank(str):
    """The review's F21 attack: an empty string whose strip() lies."""

    def strip(self) -> str:  # type: ignore[override]
        return "notblank"


class EvilInt(int):
    """The review's F22 attack: an int that defeats ordering guards."""

    def __lt__(self, other: object) -> bool:
        return False

    def __le__(self, other: object) -> bool:
        return False

    def __gt__(self, other: object) -> bool:
        return True

    def __ge__(self, other: object) -> bool:
        return True


class SpoofedStr:
    """isinstance() consults __class__; type() does not. Prove we use type()."""

    @property
    def __class__(self) -> type:  # type: ignore[override]
        return str


class SpoofedCapacityType:
    @property
    def __class__(self) -> type:  # type: ignore[override]
        return CapacityType

    value = "EXECUTION"


def assert_wrong_type(excinfo):
    assert isinstance(excinfo.value, DomainError)
    assert excinfo.value.code == WRONG_RUNTIME_TYPE


# --- F20: cross-tenant bypass must be impossible ------------------------------
def test_f20_hostile_equality_tenant_id_cannot_enter_the_domain():
    with pytest.raises(MissingTenantContextError) as excinfo:
        TenantContext(EqualEverything("attacker"))
    assert_wrong_type(excinfo)


def test_f20_cross_tenant_denial_cannot_be_reached_with_hostile_ids():
    """The full review scenario: no TenantContext carrying a hostile id can
    exist, so no tenant-isolation comparison is ever asked to handle one."""
    for hostile in (EqualEverything("attacker"), FakeNonBlank("")):
        with pytest.raises(MissingTenantContextError):
            TenantContext(hostile)


def test_f20_aggregates_reject_hostile_tenant_ids_directly():
    with pytest.raises(PlanItemInvariantError) as excinfo:
        PlanItem(tenant_id=EqualEverything("attacker"), work_object_ref="wo-1")
    assert_wrong_type(excinfo)
    with pytest.raises(CapacityInvariantError) as excinfo:
        CapacityWindow(
            tenant_id=EqualEverything("attacker"),
            resource_ref="a",
            period_start=D1,
            period_end=D5,
            available_minutes=60,
        )
    assert_wrong_type(excinfo)


# --- F21: strip()-liars must be rejected --------------------------------------
def test_f21_fake_non_blank_tenant_id_rejected():
    with pytest.raises(MissingTenantContextError) as excinfo:
        TenantContext(FakeNonBlank(""))
    assert_wrong_type(excinfo)


def test_f21_fake_non_blank_rejected_on_all_reference_fields():
    with pytest.raises(PlanItemInvariantError):
        PlanItem(tenant_id="t1", work_object_ref=FakeNonBlank(""))
    with pytest.raises(AllocationInvariantError):
        CapacityAllocation.create("t1", WINDOW, FakeNonBlank(""), 30)
    with pytest.raises(CapacityInvariantError):
        CapacityWindow(
            tenant_id="t1",
            resource_ref=FakeNonBlank(""),
            period_start=D1,
            period_end=D5,
            available_minutes=60,
        )


# --- F22: comparison-defeating ints must be rejected --------------------------
def test_f22_negative_capacity_window_attack_rejected():
    with pytest.raises(CapacityInvariantError) as excinfo:
        CapacityWindow(
            tenant_id="t1",
            resource_ref="a",
            period_start=D1,
            period_end=D5,
            available_minutes=EvilInt(-50),
        )
    assert_wrong_type(excinfo)


def test_f22_negative_allocation_attack_rejected():
    with pytest.raises(AllocationInvariantError) as excinfo:
        CapacityAllocation(
            tenant_id="t1",
            window=WINDOW,
            plan_item_ref="p",
            allocated_minutes=EvilInt(-10),
            consumed_minutes=0,
        )
    assert_wrong_type(excinfo)


def test_f22_evil_int_rejected_in_consume():
    reserved = (
        CapacityAllocation.create("t1", WINDOW, "p", 30)
        .transition(AllocationState.RESERVED, AUTHZ, TenantContext("t1"))
        .allocation
    )
    with pytest.raises(AllocationInvariantError) as excinfo:
        reserved.consume(EvilInt(10), AUTHZ, TenantContext("t1"))
    assert_wrong_type(excinfo)


# --- F23: datetime must not pass as date --------------------------------------
def test_f23_datetime_period_start_rejected():
    with pytest.raises(CapacityInvariantError) as excinfo:
        CapacityWindow(
            tenant_id="t1",
            resource_ref="a",
            period_start=datetime(2026, 1, 1, 8, 0),  # noqa: DTZ001
            period_end=D5,
            available_minutes=60,
        )
    assert_wrong_type(excinfo)
    assert excinfo.value.fields["actual"] == "datetime"


def test_f23_datetime_period_end_rejected_before_any_comparison():
    """The review's uncontrolled-TypeError case: date < datetime never runs."""
    with pytest.raises(CapacityInvariantError) as excinfo:
        CapacityWindow(
            tenant_id="t1",
            resource_ref="a",
            period_start=date(2026, 1, 1),
            period_end=datetime(2026, 1, 2, 12, 0),  # noqa: DTZ001
            available_minutes=60,
        )
    assert_wrong_type(excinfo)


def test_f23_double_datetime_window_rejected():
    with pytest.raises(CapacityInvariantError) as excinfo:
        CapacityWindow(
            tenant_id="t1",
            resource_ref="a",
            period_start=datetime(2026, 1, 1, 8, 0),  # noqa: DTZ001
            period_end=datetime(2026, 1, 1, 9, 0),  # noqa: DTZ001
            available_minutes=60,
        )
    assert_wrong_type(excinfo)


def test_f23_datetime_declared_on_rejected():
    with pytest.raises(CapacityInvariantError) as excinfo:
        AvailabilityDeclaration(
            tenant_id="t1",
            resource_ref="actor-1",
            window=WINDOW,
            declared_on=datetime(2026, 8, 1, 7, 30),  # noqa: DTZ001
        )
    assert_wrong_type(excinfo)


# --- Spoofed __class__ and enum subclassing -----------------------------------
def test_spoofed_class_str_rejected():
    with pytest.raises(MissingTenantContextError) as excinfo:
        TenantContext(SpoofedStr())
    assert_wrong_type(excinfo)
    assert excinfo.value.fields["actual"] == "SpoofedStr"


def test_spoofed_class_enum_rejected():
    with pytest.raises(CapacityInvariantError) as excinfo:
        CapacityWindow(
            tenant_id="t1",
            resource_ref="a",
            period_start=D1,
            period_end=D5,
            available_minutes=60,
            capacity_type=SpoofedCapacityType(),
        )
    assert_wrong_type(excinfo)


def test_enum_classes_with_members_cannot_be_subclassed():
    with pytest.raises(TypeError):

        class HostileCapacityType(CapacityType):  # type: ignore[misc]
            pass


def test_canonical_values_produced_by_wire_parsers_are_exact():
    decoded = parse_wire_int("45", "minutes")
    assert type(decoded) is int


# --- F24/F53: canonical ASCII wire-integer grammar (no leading zeros) ---------
@pytest.mark.parametrize(
    "raw",
    [
        "１２３",
        "١٢٣",
        "+12",
        "-5",
        " 12 ",
        "12 ",
        " 12",
        "1_000",
        "12.0",
        "0x1A",
        "",
        # F53: leading zeros are non-canonical and rejected consistently by
        # FORMAT, independent of length — "0012" and "00000000000001" alike.
        "01",
        "007",
        "0012",
        "00000000000001",
    ],
)
def test_f24_non_canonical_wire_integers_rejected(raw):
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_int(raw, "minutes")
    assert excinfo.value.code == INVALID_WIRE_INT
    assert excinfo.value.fields == {"field": "minutes", "value": raw}


@pytest.mark.parametrize("raw,expected", [("0", 0), ("12", 12), ("1000", 1000), (45, 45)])
def test_f24_canonical_wire_integers_accepted(raw, expected):
    assert parse_wire_int(raw, "minutes") == expected
