"""Authorization-policy enforcement tests (ADR-014 as amended, ADR-015).

The authz boundary is authorization-POLICY enforcement: the domain core
consults the supplied capability and honours deny/allow, but does not
establish that the capability is genuine or authenticated (that is the
service-layer trust root, G08 RED half). These tests exercise the port, the
reference context and the assertion, including the wrong-type and
blank-principal guards. The trust-boundary limits themselves (F34/F37) are
documented executably in tests/test_trust_boundary.py.
"""

import pytest

from cgwo_core.authz import (
    AuthorizationError,
    AuthorizationPort,
    StaticAuthorizationContext,
    assert_authorized,
)
from cgwo_core.errors import (
    AUTHZ_DECISION_NOT_BOOL,
    AUTHZ_PORT_UNUSABLE,
    AUTHZ_PROVIDER_ERROR,
    FIELD_BLANK,
    NOT_ENTITLED,
    WRONG_RUNTIME_TYPE,
    DomainError,
)


def ctx(*tenants):
    return StaticAuthorizationContext("principal-1", frozenset(tenants))


def test_principal_is_exposed():
    assert ctx("t1").principal == "principal-1"


def test_is_entitled_membership():
    c = ctx("t1", "t2")
    assert c.is_entitled("t1") is True
    assert c.is_entitled("t2") is True
    assert c.is_entitled("t3") is False


def test_static_context_satisfies_the_port_protocol():
    assert isinstance(ctx("t1"), AuthorizationPort)


def test_assert_authorized_allows_entitled_tenant():
    assert_authorized(ctx("t1"), "t1")  # no raise


def test_assert_authorized_denies_unentitled_tenant():
    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(ctx("t1"), "t2")
    assert isinstance(excinfo.value, DomainError)
    assert excinfo.value.code == NOT_ENTITLED
    assert excinfo.value.fields == {"tenant_id": "t2"}


def test_assert_authorized_rejects_non_port_authz():
    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(object(), "t1")  # type: ignore[arg-type]
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    assert excinfo.value.fields == {
        "field": "authz",
        "expected": "AuthorizationPort",
        "actual": "object",
    }


def test_assert_authorized_rejects_non_str_tenant():
    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(ctx("t1"), 5)  # type: ignore[arg-type]
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    assert excinfo.value.fields == {
        "field": "tenant_id",
        "expected": "str",
        "actual": "int",
    }


@pytest.mark.parametrize("bad", ["", "   "])
def test_blank_principal_rejected(bad):
    with pytest.raises(AuthorizationError) as excinfo:
        StaticAuthorizationContext(bad, frozenset({"t1"}))
    assert excinfo.value.code == FIELD_BLANK
    assert excinfo.value.fields == {"field": "principal"}


def test_non_str_principal_rejected():
    with pytest.raises(AuthorizationError) as excinfo:
        StaticAuthorizationContext(5, frozenset({"t1"}))  # type: ignore[arg-type]
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    assert excinfo.value.fields == {
        "field": "principal",
        "expected": "str",
        "actual": "int",
    }


def test_non_str_entitlement_member_rejected():
    with pytest.raises(AuthorizationError) as excinfo:
        StaticAuthorizationContext("p", {5})  # type: ignore[arg-type]
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    assert excinfo.value.fields == {
        "field": "entitlement",
        "expected": "str",
        "actual": "int",
    }


def test_entitlements_accept_set_or_frozenset():
    assert StaticAuthorizationContext("p", {"t1"}).is_entitled("t1")
    assert StaticAuthorizationContext("p", frozenset({"t1"})).is_entitled("t1")


def test_is_entitled_rejects_non_str_query():
    with pytest.raises(AuthorizationError) as excinfo:
        ctx("t1").is_entitled(5)  # type: ignore[arg-type]
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    assert excinfo.value.fields == {
        "field": "tenant_id",
        "expected": "str",
        "actual": "int",
    }


class DuckPort:
    """A structural AuthorizationPort implementation (protocol, not subclass)."""

    principal = "duck"

    def is_entitled(self, tenant_id: str) -> bool:
        return tenant_id == "allowed"


def test_duck_typed_port_is_accepted():
    assert_authorized(DuckPort(), "allowed")
    with pytest.raises(AuthorizationError):
        assert_authorized(DuckPort(), "denied")


# --- F39: constructor container-contract hygiene ------------------------------
# The declared entitlements API is exact set/frozenset. Wrong containers must
# raise a CONTROLLED AuthorizationError (WRONG_RUNTIME_TYPE), never an incidental
# Python TypeError, and a raw string must NOT be silently accepted as a set of
# characters. This is ordinary contract validation, not tamper resistance (F34).


@pytest.mark.parametrize(
    ("bad_container", "actual_name"),
    [
        (None, "NoneType"),
        (123, "int"),
        ("tenant-a", "str"),  # previously accepted as frozenset({'t','e','n','a','-'})
        (["tenant-a"], "list"),
        (("tenant-a",), "tuple"),
        ({"tenant-a": 1}, "dict"),
    ],
)
def test_entitlements_wrong_container_raises_controlled_error(bad_container, actual_name):
    with pytest.raises(AuthorizationError) as excinfo:
        StaticAuthorizationContext("p", bad_container)  # type: ignore[arg-type]
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    assert excinfo.value.fields["field"] == "entitlements"
    assert excinfo.value.fields["expected"] == "set or frozenset"
    assert excinfo.value.fields["actual"] == actual_name


def test_entitlements_raw_string_is_not_iterated_into_characters():
    """The specific F39 surprise: 'tenant-a' must be rejected, not split."""
    with pytest.raises(AuthorizationError):
        StaticAuthorizationContext("p", "tenant-a")  # type: ignore[arg-type]


def test_entitlements_hostile_member_in_valid_container_still_rejected():
    with pytest.raises(AuthorizationError) as excinfo:
        StaticAuthorizationContext("p", {5})  # type: ignore[arg-type]
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    assert excinfo.value.fields["field"] == "entitlement"


def test_entitlements_accepts_exact_set_and_frozenset():
    assert StaticAuthorizationContext("p", {"t1"}).is_entitled("t1")
    assert StaticAuthorizationContext("p", frozenset({"t2"})).is_entitled("t2")


# --- F50: the port's DECLARED return contract is enforced, FAIL-CLOSED --------
# The V011 review defeated the gate with providers that structurally satisfy the
# Protocol but violate its declared `-> bool` return type. V011 did
# `if not authz.is_entitled(...)`, so a truthy non-bool (object(), the string
# "false") AUTHORIZED the operation, a non-callable attribute raised a raw
# TypeError, and a raising provider or raising __bool__ leaked a raw exception
# through the security gate. This is NOT the domain proving the provider is
# genuine (still the service-layer trust root, ADR-015) — it is the domain
# refusing to gamble on an ill-typed decision. Every deviation is now a stable
# controlled denial, and the decision is taken exactly once.


class _ConformingPort:
    """Structurally satisfies AuthorizationPort (principal + is_entitled)."""

    @property
    def principal(self) -> str:
        return "impostor-principal"


def _port_returning(value):
    class Port(_ConformingPort):
        def is_entitled(self, tenant_id):
            return value

    return Port()


@pytest.mark.parametrize(
    "decision,label",
    [
        (object(), "truthy object"),
        ("false", "truthy 'false' string"),
        ("", "falsy string"),
        ([], "empty list"),
        ([1], "non-empty list"),
        (1, "int 1"),
        (0, "int 0"),
        (None, "None"),
    ],
)
def test_f50_non_boolean_decision_fails_closed(decision, label):
    """ANY non-bool decision is refused — including falsy ones, so the rule is
    a type contract rather than a truthiness coincidence that happens to deny."""
    port = _port_returning(decision)
    assert isinstance(port, AuthorizationPort)  # structurally conforming
    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(port, "t1")
    assert excinfo.value.code == AUTHZ_DECISION_NOT_BOOL
    assert excinfo.value.fields["actual"] == type(decision).__name__


def test_f50_raising_bool_never_reaches_truthiness():
    """A decision object whose __bool__ raises is rejected on TYPE first, so the
    hostile __bool__ is never invoked and cannot leak a raw RuntimeError."""
    invoked = []

    class Evil:
        def __bool__(self):
            invoked.append(True)
            raise RuntimeError("boom")

    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(_port_returning(Evil()), "t1")
    assert excinfo.value.code == AUTHZ_DECISION_NOT_BOOL
    assert invoked == []


def test_f50_provider_exception_fails_closed():
    class Raising(_ConformingPort):
        def is_entitled(self, tenant_id):
            raise ConnectionError("entitlement backend unreachable")

    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(Raising(), "t1")
    assert excinfo.value.code == AUTHZ_PROVIDER_ERROR
    assert type(excinfo.value.__cause__) is ConnectionError


def test_f50_non_callable_is_entitled_fails_closed():
    class NonCallable(_ConformingPort):
        is_entitled = True  # attribute exists, so the Protocol check passes

    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(NonCallable(), "t1")
    assert excinfo.value.code == AUTHZ_PORT_UNUSABLE
    # The diagnostic names WHICH part of the contract failed, so an operator
    # can tell an unusable port from a denied tenant without reading source.
    assert excinfo.value.fields == {"reason": "is_entitled is not callable"}
    assert "is_entitled is not callable" in str(excinfo.value)


def test_f50_raising_is_entitled_property_fails_closed():
    """A member implemented as a RAISING PROPERTY passes the conformance check
    — runtime_checkable isinstance inspects class attributes and does not
    invoke descriptors — and then explodes on ACCESS, before any call. The
    fetch is therefore guarded too, so this cannot leak a raw exception."""

    class ExplodingMember:
        @property
        def principal(self) -> str:
            return "p"

        @property
        def is_entitled(self):
            raise RuntimeError("member access exploded")

    port = ExplodingMember()
    assert isinstance(port, AuthorizationPort)  # conformance does not invoke it
    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(port, "t1")  # type: ignore[arg-type]
    assert excinfo.value.code == AUTHZ_PORT_UNUSABLE
    assert excinfo.value.fields == {"reason": "is_entitled is not accessible"}
    assert type(excinfo.value.__cause__) is RuntimeError


def test_f50_absent_is_entitled_attribute_fails_closed():
    """A port missing `is_entitled` entirely must also fail CLOSED, via the
    same controlled path — the lookup default must be a non-callable sentinel,
    never something that could be mistaken for a decision."""

    class Absent:
        @property
        def principal(self) -> str:
            return "p"

    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(Absent(), "t1")  # type: ignore[arg-type]
    assert excinfo.value.code in (AUTHZ_PORT_UNUSABLE, WRONG_RUNTIME_TYPE)


def test_f50_port_domain_error_surfaces_unchanged():
    """A controlled DomainError raised BY the port is already denial-shaped and
    surfaces as itself, rather than being masked as a provider fault."""

    class DomainRaising(_ConformingPort):
        def is_entitled(self, tenant_id):
            raise AuthorizationError(NOT_ENTITLED, "denied by port", tenant_id=tenant_id)

    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(DomainRaising(), "t1")
    assert excinfo.value.code == NOT_ENTITLED


def test_f50_decision_is_taken_exactly_once():
    """The gate must not call the provider twice (no double-charging a remote
    entitlement service, and no TOCTOU window between two decisions)."""
    calls = []

    class Counting(_ConformingPort):
        def is_entitled(self, tenant_id):
            calls.append(tenant_id)
            return True

    assert_authorized(Counting(), "t1")
    assert calls == ["t1"]


def test_f50_exact_booleans_still_allow_and_deny():
    """The contract accepts only real bools — and both still behave correctly."""
    assert assert_authorized(_port_returning(True), "t1") is None
    with pytest.raises(AuthorizationError) as excinfo:
        assert_authorized(_port_returning(False), "t1")
    assert excinfo.value.code == NOT_ENTITLED
