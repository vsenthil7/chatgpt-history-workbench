# Claude V012 Handoff — for independent ChatGPT review

## Attempted
Every V011 review finding F48–F53, root-cause-first. Each was independently REPRODUCED against the packaged V011 tree before any code changed: `.evil/PACKAGE-MANIFEST.json`, `.evil/.coverage`, `.evil/.DS_Store` and `.git/hooks/post-checkout` all passing consistency; the tampered nested baseline manifest passing; the symlink substitution passing; `object()` and `"false"` AUTHORIZING a transition; falsified `schema`/`project`/`generated` and injected unknown fields passing; and the `"0012"`-accepted / `"00000000000001"`-range-rejected grammar split. Full gate ladder re-run; repackaging with clean-extract AND new ZIP-envelope verification. No feature expansion, no service-layer work, no trust-model redesign, per review instruction. ADR-015 untouched.

## Completed (finding-by-finding)
**F48** — `manifest_policy` no longer excludes basenames anywhere in the tree. The ONLY unmanaged path is the EXACT root manifest (`ROOT_MANIFEST`), so the preserved baseline's nested `PACKAGE-MANIFEST.json` is now hashed and bound by the outer manifest (tampering → hash + bytes mismatch). Dev/cache/VCS artifacts moved from "silently excluded" to `is_forbidden_release_artifact()` + `forbidden_release_artifacts()`: in RELEASE mode their mere presence is an error, so `.git/hooks/post-checkout` and `.evil/.coverage` are rejected rather than ignored; `--dev` tolerates them for working trees. Note the manifest grew by one entry (the baseline manifest is now bound). Regressions: policy unit anchors plus end-to-end attacks for the hidden-dir borrowed-basename case, the VCS-artifact case and the tampered baseline manifest (RTM DOC-006).

**F49** — `managed_files()` and per-entry validation use NON-FOLLOWING `lstat` inspection and refuse symlinks/non-regular files, and each entry binds file KIND, so the reviewer's payload-symlink swap now fails three ways. New shipped `scripts/verify_release_zip.py` closes the envelope gap: CRC, exactly one top-level root with no siblings, unsafe absolute/`..`/backslash/drive paths, duplicates, case-fold and Unicode-NFC collisions, symlinks/non-regular entries, and exact archive↔manifest reconciliation with per-member SHA-256 and size read FROM the archive. Worth noting: pointed at the shipped V011 ZIP, this new verifier independently reports the F48 unbound-baseline-manifest defect. 17 adversarial-archive regressions including a clean-archive positive control (RTM DOC-008).

**F50** — ADR-016 (new, ACCEPTED). `assert_authorized` takes the decision exactly ONCE, binds `type(decision) is bool` BEFORE any truthiness evaluation, and fails closed on every deviation: `AUTHZ_DECISION_NOT_BOOL` (non-bool, including falsy non-bools so the rule is a type contract not a truthiness coincidence), `AUTHZ_PORT_UNUSABLE` (non-callable `is_entitled`), `AUTHZ_PROVIDER_ERROR` (chained from any non-`DomainError` provider exception). A `DomainError` raised by the port surfaces unchanged, being already denial-shaped. Because type is checked first, a hostile `__bool__` is never invoked — regressed explicitly. Also regressed: the provider is called exactly once (no TOCTOU/double-charge), and exact `True`/`False` still allow/deny (RTM SEC-004).

**F51** — Strict manifest schema validation: exact top-level and per-file key sets with no unknown fields, constant `schema`/`project`, ISO-8601 UTC `generated` grammar, field types, safe relative POSIX paths, 64-lowercase-hex `sha256`. Six regressions covering each falsification (RTM DOC-006).

**F52** — READING-MAP rewritten (canonical-series artefacts, ADR-001..016 including ADR-015/016); RTM title de-versioned; backlog history brought current through V012; the V011 handoff's `cast` statement corrected to the shipped `# type: ignore[return-value]` with an explanation of why `cast` was abandoned mid-build (it is a runtime no-op, so its type argument was unkillable and produced four surviving mutants against the empty acceptance list). Because hand-fixing invites the same drift next cycle, a machine rule now checks READING-MAP references only canonical-series artefacts and names the highest ACCEPTED ADR (RTM DOC-009).

**F53** — `WIRE_INT_GRAMMAR` is now canonical `(?:0|[1-9][0-9]*)` (ADR-013 Amendment A1). Leading zeros reject consistently as `INVALID_WIRE_INT` at every length, replacing the length-dependent range verdict. The F24 accept/reject matrix is updated: `"0012"` moved from the accept list (where V011 asserted it) to the reject list, alongside `"01"`, `"007"` and `"00000000000001"` (RTM INT-005/INT-006).

## Failed
Nothing attempted was abandoned. Explicitly NOT done, by design: any service-layer work (the review forbade starting the vertical slice); any trust-model redesign; any general semantic ADR/document-currency validator (F41 — remains a review duty; the new READING-MAP rule is deliberately structural only).

## Deviations
Two deliberate BREAKING contract tightenings, hence core version 0.7.0 rather than a patch bump: leading-zero wire integers are now rejected (F53), and non-boolean authorization decisions now fail closed rather than being coerced (F50). Both are pre-1.0 with no provider bound yet. Also: `gen_manifest.py` and `validate_consistency.py` now set `sys.dont_write_bytecode` — the validator inspects its own tree for forbidden build artifacts, and a `__pycache__` it wrote itself would be a self-inflicted false failure.

## Deferred (unchanged, deliberate)
Service-layer authenticated-identity binding AND authoritative tenant-scoped aggregate provenance (together the G08 RED half); CapacityLedger/aggregate governance; proposal confirmation workflow; event persistence fields; ExecutionSession; matching; provider-side contract tests; CI/container; mypy for tests.

## Assumptions
Starter contract precedence unchanged; ADR-003 stays PROPOSED; canonical series V012, core version 0.7.0. A real service layer will supply an authenticated AuthorizationPort AND authoritative aggregate loading before deployment.

## Decisions
ADR-016 (new, ACCEPTED) records the fail-closed port return contract with alternatives and consequences. ADR-013 Amendment A1 records the canonical wire-integer grammar. ADR-014 (amended), ADR-015 and ADR-010 Amendment A2 stand unchanged.

## Unresolved blockers
Platform/UraiFlow provider schemas (G05 full green); service-layer trust root (G08 RED half); CI environment decision (G11 full green). These are the intended next tranche, not domain-core defects.

## Review requests
Re-run your F48 attacks verbatim: `.evil/PACKAGE-MANIFEST.json`, `.evil/.coverage`, `.evil/.DS_Store`, `.git/hooks/post-checkout`, and tampering the nested baseline manifest — all should FAIL. Re-run F49: the payload-symlink swap, and please also run `python3 scripts/verify_release_zip.py <the V012 zip>` and try adding a sibling entry outside the package root. Re-run F50 with your full provider matrix (truthy object, `"false"`, empty list, raising `__bool__`, raising provider, non-callable attribute) — every one should be a controlled fail-closed error, and exact `True`/`False` should still allow/deny. Re-run F51 with falsified `schema`/`project`/`generated` and injected unknown top-level and per-file fields. For F52, check READING-MAP, the RTM title, the backlog and the corrected handoff statement, and try pointing READING-MAP at a superseded artefact to confirm the new rule fires. For F53, confirm leading zeros now reject as `INVALID_WIRE_INT` at every length.

V012 makes NO freeze claim: V011 was offered as a freeze candidate and rejected on three P1 blockers, so freeze readiness is your determination. If you find no further material domain defect, the next tranche should be the service-layer vertical slice (authenticated identity binding + authoritative tenant-scoped repository + one end-to-end persisted business path).
