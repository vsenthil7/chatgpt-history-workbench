# Claude V011 Handoff — for independent ChatGPT review

## Attempted
Every V010 review finding F45–F47, root-cause-first; each finding was independently REPRODUCED against the packaged V010 tree before any code changed (spoofed-`__class__` raw AttributeError at all four sites; `.evil/payload.py` passing consistency in a correctly named release copy; falsified `bytes` passing). Full gate ladder re-run; repackaging with clean-extract verification. No feature expansion and NO trust-model redesign, per review instruction. ADR-015 untouched. Offered as the second candidate domain-baseline freeze.

## Completed (finding-by-finding)
F45 — `require_aggregate` mechanism corrected from `isinstance(value, expected_cls)` to `issubclass(type(value), expected_cls)` (ADR-010 Amendment A2). `type()` reads the real type slot, immune to spoofed `__class__`; genuine subclasses are still ADMITTED because their true type inherits the aggregate class, so the F32 lying-subclass-reaches-authorization semantics are byte-for-byte preserved; a `__class__` impostor is now rejected with a controlled `WRONG_RUNTIME_TYPE` naming its REAL type (e.g. `actual: 'Impostor'`), before any attribute read. The four-way contract — normal instance PASS / genuine subclass PASS / plain str/None/object rejected / spoofed-`__class__` impostor rejected — is regressed at ALL FOUR sites (`transition_plan_item`, `transition_allocation`, `consume_allocation`, `windows_overlap` both arguments) in `tests/test_adversarial_objects.py`; the plain-malformed leg additionally stays anchored in the guard-site matrix with exact error identity. mypy strict note: `issubclass(type(v), …)` does not narrow, so the guard returns under a targeted `# type: ignore[return-value]`, documented as sound because the runtime check is STRICTER than isinstance narrowing. (Corrected in V012 per review F52: this line previously described an explicit `typing.cast`, which was the FIRST attempt and was replaced during the V011 build — `cast` is a runtime no-op, so its type argument was unkillable by any test and produced four surviving mutants against ADR-011's empty acceptance list. The shipped V011 source says so explicitly; the handoff had not been updated to match.) (RTM DOM-008/DOM-014).

F46 — The generic `part.startswith(".")` exclusion is REMOVED from `scripts/manifest_policy.py`. Exclusions are an explicit named allowlist: `mutants`, `__pycache__`, `.pytest_cache`, `.ruff_cache`, `.mypy_cache`, `.mutmut-cache`, `.hypothesis`, `.git`, `.venv` (directories) and `PACKAGE-MANIFEST.json`, `.coverage`, `.DS_Store` (basenames). Any other path — hidden or not — is managed and must be manifested or validation FAILS. The policy docstring states that any future intentionally shipped hidden directory must be named explicitly, never admitted generically. Regressions: the exact `.evil/payload.py` attack now fails closed-set validation; unit anchors prove named caches stay excluded while `.evil/payload.py`, `.hidden-file` and `src/.sneaky/mod.py` are managed. The closure-test copy helper now sources its ignore list from the SHARED policy so it cannot drift (RTM DOC-006).

F47 — `validate_consistency.py` now verifies `entry["bytes"] == p.stat().st_size` for every manifest entry (the field is kept and validated rather than removed: byte size is useful integrity metadata once actually checked). Regressions: falsified `bytes` with file+SHA-256 untouched FAILS with an explicit "bytes mismatch … (F47)" error; an untampered control copy PASSES (RTM DOC-006).

## Failed
Nothing attempted was abandoned. Explicitly NOT done, by design: any trust-model redesign; exact `type(value) is` for aggregates (would break F32 subclass-admission and wrongly convert hygiene into provenance); a generic semantic ADR-consistency validator (F41 — remains a review duty).

## Deviations
None new. `require_aggregate` still deliberately differs from `require_exact_instance` (subclass-admitting real-type check vs exact canonical type) because its purpose remains API hygiene, not the exact-canonical-type trust stance used for value objects.

## Deferred (unchanged, deliberate)
Service-layer authenticated-identity binding AND authoritative tenant-scoped aggregate provenance (together the G08 RED half); CapacityLedger/aggregate governance; proposal confirmation workflow; event persistence fields; ExecutionSession; matching; provider-side contract tests; CI/container; mypy for tests.

## Assumptions
Starter contract precedence unchanged; ADR-003 stays PROPOSED; canonical series V011, core version 0.6.4. A real service layer will supply an authenticated AuthorizationPort AND authoritative aggregate loading before deployment.

## Decisions
No new ADR. F45 is recorded as ADR-010 Amendment A2 (mechanism correction with alternatives and consequences); F46/F47 are governance-rule corrections within DOC-006. ADR-014 (amended) and ADR-015 stand unchanged.

## Unresolved blockers
Platform/UraiFlow provider schemas (G05 full green); service-layer trust root (G08 RED half); CI environment decision (G11 full green). These are the intended next tranche, not domain-core defects.

## Review requests
Re-run your F45 probes verbatim: the `Spoof`/`SpoofAllocation`/`SpoofWindow` `__class__`-property impostors against `transition_plan_item`, `transition_allocation`, `consume_allocation` and `windows_overlap` (both argument positions) — all should raise controlled `WRONG_RUNTIME_TYPE` naming the impostor's real type, never AttributeError; confirm a GENUINE subclass is still admitted and a lying subclass still reaches authorization and is denied there. Re-run your F46 attack: add `.evil/payload.py` (and any other arbitrary hidden path) to a correctly named release copy without regenerating the manifest — validation should FAIL; confirm known caches (`.pytest_cache` etc.) remain excluded. Re-run your F47 attack: falsify any entry's `bytes` while leaving the file and hash untouched — validation should FAIL with a bytes-mismatch error. If F45–F47 are clean and you find no further material domain defect, per your own instruction please freeze the domain baseline so the next tranche can begin the service-layer vertical slice (authenticated identity binding + authoritative tenant-scoped repository + one end-to-end persisted business path).
