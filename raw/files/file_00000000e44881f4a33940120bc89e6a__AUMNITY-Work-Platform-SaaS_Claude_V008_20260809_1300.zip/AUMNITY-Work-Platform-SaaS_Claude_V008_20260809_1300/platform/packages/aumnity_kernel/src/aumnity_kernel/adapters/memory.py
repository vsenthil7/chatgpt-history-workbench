"""Deterministic in-memory adapters for kernel ports (ADR-002/ADR-003).

These are the default adapters for tests and for the future modular-monolith
bootstrap until the PostgreSQL adapter (deferred, RTM INF-001) exists.
"""

import threading
from collections.abc import Callable, Iterable
from dataclasses import replace
from typing import TypeVar

from aumnity_contracts import (
    ConcurrencyError,
    EventEnvelope,
    EvidenceId,
    OrganisationId,
    PrincipalId,
    ValidationError,
    WorkObjectId,
)

from aumnity_kernel.evidence import EvidenceRecord
from aumnity_kernel.identity import Principal
from aumnity_kernel.organisation import Organisation
from aumnity_kernel.workobject.model import WorkObject


class _SerialisationDomainMember:
    """Mixin: a store belongs to at most ONE serialisation domain (ADR-021).

    The domain is machine-derived, never injected: transactional adapters read
    it FROM their participating stores, so two transaction boundaries over the
    same stores cannot acquire independent locks — the V007 review executed
    exactly that construction (two UoWs, same stores, different mutexes) and
    reproduced the V006 lost-commit race through it.
    """

    _domain: "TransactionMutex | None" = None

    def bind_domain(self, domain: "TransactionMutex") -> None:
        if self._domain is not None and self._domain is not domain:
            raise ValidationError(
                "store already belongs to a different serialisation domain (ADR-021)"
            )
        self._domain = domain

    def serialisation_domain(self) -> "TransactionMutex":
        if self._domain is None:
            raise ValidationError(
                "store has no serialisation domain; bind it (bind_serialisation_domain "
                "or InMemoryPlatformStores) before transactional use (ADR-021)"
            )
        return self._domain


class TransactionMutex:
    """Serialises in-memory transactions over one shared store composition
    (ADR-019, V006 review F1).

    The V006 whole-store snapshot/rollback was only sound if no other
    transaction could commit between a transaction's snapshot and its restore;
    without a lock, a failed transaction's rollback erased a concurrent
    successful commit (executed by the review). Under this mutex a
    transaction's snapshot → operation → commit/rollback is one critical
    section, so that interleaving cannot exist. Same-thread re-entry (a
    transaction nested inside another over the same stores) is rejected
    explicitly rather than deadlocking: nesting is not a supported contract.
    Every transactional adapter composed over the same stores — the unit of
    work AND the tenant provisioner — must share one mutex instance.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._owner: int | None = None

    def __enter__(self) -> "TransactionMutex":
        if self._owner == threading.get_ident():
            raise ValidationError("transactions over the same stores cannot nest (ADR-019)")
        self._lock.acquire()
        self._owner = threading.get_ident()
        return self

    def __exit__(self, *exc_info: object) -> None:
        self._owner = None
        self._lock.release()


class InMemoryOrganisationRepository(_SerialisationDomainMember):
    def __init__(self) -> None:
        self._items: dict[OrganisationId, Organisation] = {}

    def add(self, organisation: Organisation) -> None:
        if organisation.organisation_id in self._items:
            raise ValidationError(f"duplicate organisation id: {organisation.organisation_id}")
        self._items[organisation.organisation_id] = organisation

    def get(self, organisation_id: OrganisationId) -> Organisation | None:
        return self._items.get(organisation_id)

    def snapshot(self) -> dict[OrganisationId, Organisation]:
        """Adapter-level transaction API (ADR-011/ADR-013): copy of full state."""
        return dict(self._items)

    def restore(self, state: dict[OrganisationId, Organisation]) -> None:
        """Replace full state wholesale. Non-raising by construction: a dict
        rebind cannot fail partway, so rollback itself cannot corrupt state."""
        self._items = dict(state)


class InMemoryPrincipalRepository(_SerialisationDomainMember):
    def __init__(self) -> None:
        self._items: dict[PrincipalId, Principal] = {}

    def add(self, principal: Principal) -> None:
        if principal.principal_id in self._items:
            raise ValidationError(f"duplicate principal id: {principal.principal_id}")
        self._items[principal.principal_id] = principal

    def get(self, principal_id: PrincipalId) -> Principal | None:
        return self._items.get(principal_id)

    def snapshot(self) -> dict[PrincipalId, Principal]:
        """Adapter-level transaction API (ADR-011/ADR-013): copy of full state."""
        return dict(self._items)

    def restore(self, state: dict[PrincipalId, Principal]) -> None:
        """Replace full state wholesale; non-raising by construction."""
        self._items = dict(state)


class InMemoryTenantProvisioner:
    """Atomic bootstrap over the two in-memory stores (ADR-011, hardened per
    V004 review Finding 2).

    Transaction model: snapshot BOTH stores through their explicit adapter
    transaction API, attempt both writes, and on ANY failure — whether a store
    raised before or after mutating itself — restore BOTH snapshots wholesale,
    then re-raise the original failure. From an observer's perspective the
    provision either fully happened or never happened; no orphan organisation
    and no orphan principal can survive any failure path.

    Rollback contract (explicitly defined, not pretended away): `restore`
    replaces internal state by rebinding a dict, which cannot fail partway, so
    compensation itself is non-raising for the shipped adapter. A future
    transactional adapter (PostgreSQL, INF-001) replaces this whole class with
    a database transaction.
    """

    def __init__(
        self,
        organisations: InMemoryOrganisationRepository,
        principals: InMemoryPrincipalRepository,
    ) -> None:
        # ADR-021: domain derived from the stores, never injected.
        domain = organisations.serialisation_domain()
        if principals.serialisation_domain() is not domain:
            raise ValidationError(
                "participating stores belong to different serialisation domains (ADR-021)"
            )
        self._organisations = organisations
        self._principals = principals
        self._mutex = domain

    def provision(self, organisation: Organisation, founder: Principal) -> None:
        # ADR-019: same whole-store rollback technique, same race — so the same
        # serialisation applies; compositions sharing stores share the mutex.
        with self._mutex:
            organisations_before = self._organisations.snapshot()
            principals_before = self._principals.snapshot()
            try:
                self._organisations.add(organisation)
                self._principals.add(founder)
            except Exception:
                self._organisations.restore(organisations_before)
                self._principals.restore(principals_before)
                raise


class InMemoryWorkObjectRepository(_SerialisationDomainMember):
    """Stores defensive copies so callers cannot mutate persisted state in place.

    ADR-017 (V005 review F5/F6): `create` rejects duplicate ids — a colliding
    id generator can never silently overwrite an aggregate, least of all one
    belonging to another tenant — and `update` uses expected-version
    (optimistic concurrency): the losing concurrent writer gets
    ConcurrencyError instead of silently erasing the winner's change.
    """

    def __init__(self) -> None:
        self._items: dict[WorkObjectId, WorkObject] = {}

    def create(self, work_object: WorkObject) -> None:
        if work_object.work_object_id in self._items:
            raise ValidationError(f"duplicate work object id: {work_object.work_object_id}")
        self._items[work_object.work_object_id] = replace(work_object)

    def update(self, work_object: WorkObject, *, expected_version: int) -> None:
        stored = self._items.get(work_object.work_object_id)
        if stored is None:
            raise ValidationError(
                f"cannot update unknown work object: {work_object.work_object_id}"
            )
        if stored.version != expected_version:
            raise ConcurrencyError(
                f"stale write: stored version {stored.version} != expected {expected_version}"
            )
        self._items[work_object.work_object_id] = replace(work_object)

    def snapshot(self) -> dict[WorkObjectId, WorkObject]:
        return {key: replace(value) for key, value in self._items.items()}

    def restore(self, state: dict[WorkObjectId, WorkObject]) -> None:
        self._items = {key: replace(value) for key, value in state.items()}

    def get(self, work_object_id: WorkObjectId) -> WorkObject | None:
        found = self._items.get(work_object_id)
        return replace(found) if found is not None else None

    def children_of(self, parent_id: WorkObjectId) -> Iterable[WorkObject]:
        return tuple(replace(item) for item in self._items.values() if item.parent_id == parent_id)


class InMemoryEvidenceRepository(_SerialisationDomainMember):
    def __init__(self) -> None:
        self._items: dict[EvidenceId, EvidenceRecord] = {}

    def add(self, record: EvidenceRecord) -> None:
        """Evidence is immutable: a duplicate id would REPLACE a record via the
        dict key even though the dataclass is frozen — rejected (ADR-017)."""
        if record.evidence_id in self._items:
            raise ValidationError(f"duplicate evidence id: {record.evidence_id}")
        self._items[record.evidence_id] = record

    def snapshot(self) -> dict[EvidenceId, EvidenceRecord]:
        return dict(self._items)

    def restore(self, state: dict[EvidenceId, EvidenceRecord]) -> None:
        self._items = dict(state)

    def get(self, evidence_id: EvidenceId) -> EvidenceRecord | None:
        return self._items.get(evidence_id)


class InMemoryAuditSink(_SerialisationDomainMember):
    """Append-only event store; no update or delete API exists by design.

    snapshot/restore participate in the command unit of work (ADR-016) only;
    they are adapter transaction plumbing, not an update/delete capability.
    """

    def __init__(self) -> None:
        self._events: list[EventEnvelope] = []

    def append(self, event: EventEnvelope) -> None:
        self._events.append(event)

    def all_events(self) -> Iterable[EventEnvelope]:
        return tuple(self._events)

    def snapshot(self) -> list[EventEnvelope]:
        return list(self._events)

    def restore(self, state: list[EventEnvelope]) -> None:
        self._events = list(state)


_T = TypeVar("_T")


class InMemoryUnitOfWork:
    """Atomic command boundary over work objects, evidence and audit (ADR-016).

    Same transaction model as InMemoryTenantProvisioner: snapshot every
    participating store, run the command, and on ANY failure restore ALL
    snapshots wholesale and re-raise — so a fault in the mandatory audit append
    (V005 review F1) rolls the already-persisted work object and evidence back
    out, and the caller's observed failure matches reality: nothing happened.
    Restore is wholesale state replacement and non-raising by construction; a
    transactional persistence adapter (INF-001) replaces this class with a
    database transaction.
    """

    def __init__(
        self,
        work_objects: InMemoryWorkObjectRepository,
        evidence: InMemoryEvidenceRepository,
        audit_sink: InMemoryAuditSink,
    ) -> None:
        # ADR-021: the serialisation domain is DERIVED from the participating
        # stores; it cannot be injected. All participants must share one bound
        # domain, so independently locked transaction boundaries over the same
        # stores are impossible by construction.
        domain = work_objects.serialisation_domain()
        for participant in (evidence, audit_sink):
            if participant.serialisation_domain() is not domain:
                raise ValidationError(
                    "participating stores belong to different serialisation domains (ADR-021)"
                )
        self._work_objects = work_objects
        self._evidence = evidence
        self._audit_sink = audit_sink
        self._mutex = domain

    def run(self, operation: Callable[[], _T]) -> _T:
        # ADR-019: the whole transaction is one critical section, so no other
        # transaction's commit can fall between this snapshot and a rollback —
        # a failed transaction can therefore never erase a committed one.
        with self._mutex:
            work_objects_before = self._work_objects.snapshot()
            evidence_before = self._evidence.snapshot()
            events_before = self._audit_sink.snapshot()
            try:
                return operation()
            except Exception:
                self._work_objects.restore(work_objects_before)
                self._evidence.restore(evidence_before)
                self._audit_sink.restore(events_before)
                raise


def bind_serialisation_domain(
    *stores: _SerialisationDomainMember, domain: TransactionMutex | None = None
) -> TransactionMutex:
    """Bind stores into ONE serialisation domain (creating it if needed).

    Binding a store that already belongs to a DIFFERENT domain raises — the
    machine enforcement of "same transactional resources ⇒ same serialisation
    domain" (ADR-021). Rebinding into the same domain is idempotent.
    """
    resolved = domain if domain is not None else TransactionMutex()
    for store in stores:
        store.bind_domain(resolved)
    return resolved


class InMemoryPlatformStores:
    """Composition root: ALL in-memory stores under ONE serialisation domain
    (ADR-021). It owns the repositories and the lock and manufactures the
    transactional adapters, so the unit of work and the tenant provisioner can
    never accidentally form separate serialisation domains over shared
    transactional resources.
    """

    def __init__(self) -> None:
        self.organisations = InMemoryOrganisationRepository()
        self.principals = InMemoryPrincipalRepository()
        self.work_objects = InMemoryWorkObjectRepository()
        self.evidence = InMemoryEvidenceRepository()
        self.audit_sink = InMemoryAuditSink()
        self.domain = bind_serialisation_domain(
            self.organisations,
            self.principals,
            self.work_objects,
            self.evidence,
            self.audit_sink,
        )

    def unit_of_work(self) -> InMemoryUnitOfWork:
        return InMemoryUnitOfWork(self.work_objects, self.evidence, self.audit_sink)

    def tenant_provisioner(self) -> InMemoryTenantProvisioner:
        return InMemoryTenantProvisioner(self.organisations, self.principals)
