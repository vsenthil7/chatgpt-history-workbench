#!/usr/bin/env python3
"""Generate BUILD-REPORT-V007.md directly from machine-readable evidence
(ADR-0012 §6; V003 review P1-2, preferred option B).

Every volatile fact (test counts, coverage, mutation accounting, gate results)
is read from `evidence/` — never typed by hand — so the report cannot drift
from the evidence. `--check` regenerates the volatile section and fails on any
difference (this is how G10 verifies the report mechanically).
"""
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence"
REPORT = ROOT / "BUILD-REPORT-V007.md"
MARKER_BEGIN = "<!-- MACHINE-GENERATED FACTS: BEGIN (scripts/gen_build_report.py) -->"
MARKER_END = "<!-- MACHINE-GENERATED FACTS: END -->"


def _read(name: str) -> str:
    path = EVIDENCE / name
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def _grep(pattern: str, text: str, default: str = "NOT FOUND") -> str:
    match = re.search(pattern, text)
    return match.group(1) if match else default


def _manifest_status() -> str:
    """Derive the manifest fact by RUNNING the check, never by reading
    `evidence/G01-manifest-check.txt` (V007 P0-5).

    That evidence file is self-referential and is deliberately excluded from the
    shipped payload, so deriving the fact from it made the build report
    irreproducible from a clean extraction — G10 then failed on the very
    artifact that shipped a PASS result. Running the check is reproducible
    everywhere the payload exists.

    The check is run over the payload EXCLUDING this build report itself: the
    report records the manifest status, and the manifest covers the report, so
    including it would make the fact depend on its own text (a fixed-point that
    cannot converge). Drift confined to the report alone is therefore not a
    manifest failure for this fact; any other drift is.
    """
    result = subprocess.run(
        [sys.executable, "scripts/gen_manifest.py", "--check"],
        cwd=ROOT, capture_output=True, text=True, check=False,
    )
    if result.returncode == 0:
        return "PASS"
    problems = [
        line.strip() for line in (result.stdout + result.stderr).splitlines()
        if line.strip().startswith("-")
    ]
    others = [p for p in problems if REPORT.name not in p]
    return "PASS" if problems and not others else "see evidence"


def _mutation_scope() -> str:
    """Machine-derived mutation SCOPE (V007 P1-5): the number of source files
    configured for mutation versus the total number of source modules, so the
    0-logic-survivor claim is never mistaken for whole-package coverage."""
    cfg = (ROOT / "setup.cfg").read_text(encoding="utf-8")
    match = re.search(r"paths_to_mutate\s*=\s*(.+)", cfg)
    targets = [t for t in (match.group(1).split(",") if match else []) if t.strip()]
    total = sum(1 for _ in (ROOT / "src" / "uraiflow").rglob("*.py"))
    return f"{len(targets)} of {total} source modules (trust-bearing core)"


def facts() -> str:
    tests = _read("G03-tests.txt")
    coverage = _read("G04-coverage.txt")
    mutation_json = _read("G07-mutation.json")
    mutation = json.loads(mutation_json)["summary"] if mutation_json else {}
    ruff = _read("G02-ruff.txt")
    mypy = _read("G02-mypy.txt")
    manifest_status = _manifest_status()
    rtm = _read("G09-rtm.txt")
    passed = _grep(r"(\d+) passed", tests)
    line_cov = _grep(r"TOTAL\s+\d+\s+\d+\s+\d+\s+\d+\s+(\d+%)", coverage)
    lines = [
        MARKER_BEGIN,
        "| Fact | Machine-derived value | Evidence |",
        "|---|---|---|",
        f"| Tests | {passed} passed, 0 failed | `evidence/G03-tests.txt` |",
        (f"| Coverage (line+branch, fail-under=100) | {line_cov} | "
         f"`evidence/G04-coverage.txt` |"),
        (f"| Mutation total | {mutation.get('total', 'NOT RUN')} | "
         f"`evidence/G07-mutation.json` |"),
        (f"| Mutation accounting | {mutation.get('accounting', 'NOT RUN')} | "
         f"`evidence/G07-mutation.json` |"),
        (f"| Logic survivors | {mutation.get('logic_survivors', 'NOT RUN')} | "
         f"`evidence/G07-mutation-summary.txt` |"),
        # V007 P1-5: state the SCOPE explicitly so "0 logic survivors" is never
        # read as covering every module in the package.
        (f"| Mutation scope | {_mutation_scope()} | "
         f"`setup.cfg` (paths_to_mutate) |"),
        (f"| ruff | {'PASS' if 'All checks passed' in ruff else 'see evidence'} | "
         f"`evidence/G02-ruff.txt` |"),
        (f"| mypy | {'PASS' if 'no issues found' in mypy else 'see evidence'} | "
         f"`evidence/G02-mypy.txt` |"),
        (f"| Manifest contract | {manifest_status} | "
         f"`scripts/gen_manifest.py --check` (run live; V007 P0-5) |"),
        (f"| G09 RTM | {'PASS' if 'PASS' in rtm else 'see evidence'} | "
         f"`evidence/G09-rtm.txt` |"),
        MARKER_END,
    ]
    return "\n".join(lines)


def main(argv: list[str]) -> int:
    if not REPORT.is_file():
        print(f"missing {REPORT.name}; create the narrative shell first",
              file=sys.stderr)
        return 1
    text = REPORT.read_text(encoding="utf-8")
    if MARKER_BEGIN not in text or MARKER_END not in text:
        print("report is missing the machine-generated markers", file=sys.stderr)
        return 1
    begin = text.index(MARKER_BEGIN)
    end = text.index(MARKER_END) + len(MARKER_END)
    regenerated = text[:begin] + facts() + text[end:]
    if "--check" in argv:
        if regenerated != text:
            print("G10 build-report drift: machine facts do not match evidence",
                  file=sys.stderr)
            return 1
        print("build report facts match evidence")
        return 0
    REPORT.write_text(regenerated, encoding="utf-8")
    print(f"{REPORT.name}: machine facts regenerated from evidence")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
