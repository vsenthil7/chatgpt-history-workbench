#!/usr/bin/env python3
"""G10 — machine docs-consistency validator (ADR-0012 §6; V003 review P1-2).

Detects:
 * product-version mismatch (pyproject vs manifest generator vs manifest);
 * stale product names in current docs;
 * ADR references (in current RTM / quality docs / build report) that do not
   exist on disk;
 * RTM test/evidence references that do not exist (delegated to G09 logic);
 * manually maintained volatile counts in CURRENT-release narrative docs —
   test/mutation/coverage/manifest counts belong to machine evidence or to
   the machine-generated section of the build report, never to prose
   (historical, superseded documents are frozen history and exempt);
 * build-report drift: the machine-generated facts section must regenerate
   byte-identically from evidence (scripts/gen_build_report.py --check).

Evidence: evidence/G10-docs-consistency.txt (and exit code).
"""
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence"
ADR_DIR = ROOT / "02-architecture" / "adr"

# Current-release narrative docs governed by the "no manual volatile counts"
# rule. Historical build reports / RTMs are frozen history and exempt.
CURRENT_NARRATIVE = [
    "05-quality/QUALITY-GATES.md",
    "09-governance/RELEASE-PROCEDURE.md",
    "06-traceability/RTM-V007.md",
    "CLAUDE.md",
    "02-architecture/MODULARITY-AND-REUSE.md",
]
# Measured volatile results (counts of tests passed, mutants, killed, measured
# coverage figures, manifest file counts). Policy TARGETS such as the phrase
# "100% line+branch" coverage requirement are configuration, not measurement,
# and are allowed in prose.
_VOLATILE = re.compile(
    r"\b\d+\s+(?:tests?\s+)?passed\b"
    r"|\b\d+\s+mutants?\b"
    r"|\b\d+\s+(?:mutants?\s+)?killed\b"
    r"|\bcoverage(?:\s+achieved|\s+measured|:\s*\d)\s*\d*(?:\.\d+)?%?"
    r"|\b\d+\s+files?\b.{0,20}manifest"
    r"|manifest.{0,20}\b\d+\s+files?\b",
    re.IGNORECASE,
)


def _pyproject_version() -> str:
    text = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    return re.search(r'version\s*=\s*"([^"]+)"', text).group(1)


def _manifest_generator_version() -> str:
    text = (ROOT / "scripts" / "gen_manifest.py").read_text(encoding="utf-8")
    return re.search(r'PRODUCT_VERSION\s*=\s*"([^"]+)"', text).group(1)


def validate() -> list[str]:
    problems: list[str] = []
    # 1. version consistency
    py_version = _pyproject_version()
    gen_version = _manifest_generator_version()
    if py_version != gen_version:
        problems.append(
            f"version mismatch: pyproject {py_version} != manifest generator "
            f"{gen_version}"
        )
    manifest_path = ROOT / "PACKAGE-MANIFEST.json"
    if manifest_path.is_file():
        recorded = re.search(
            r'"product_version":\s*"([^"]+)"', manifest_path.read_text()
        )
        if recorded and recorded.group(1) != py_version:
            problems.append(
                f"version mismatch: manifest {recorded.group(1)} != "
                f"pyproject {py_version}"
            )
    # 2. stale product names
    for doc in CURRENT_NARRATIVE:
        path = ROOT / doc
        if not path.is_file():
            problems.append(f"expected current doc missing: {doc}")
            continue
        text = path.read_text(encoding="utf-8")
        for stale in ("WorkforceFlow", "UraiFlow-Legacy"):
            if stale in text:
                problems.append(f"{doc}: stale product name '{stale}'")
        # 3. manual volatile counts in current narrative docs
        for match in _VOLATILE.finditer(text):
            problems.append(
                f"{doc}: manually quoted volatile count {match.group(0)!r} "
                f"(belongs in machine evidence)"
            )
        # 4. ADR references resolve
        for adr in set(re.findall(r"ADR-\d{4}", text)):
            if not list(ADR_DIR.glob(f"{adr}-*.md")):
                problems.append(f"{doc}: references nonexistent {adr}")
    # 5. build report: volatile facts only inside the machine-generated section,
    #    and that section must regenerate identically from evidence
    report = ROOT / "BUILD-REPORT-V007.md"
    if not report.is_file():
        problems.append("BUILD-REPORT-V007.md missing")
    else:
        text = report.read_text(encoding="utf-8")
        begin = text.find("<!-- MACHINE-GENERATED FACTS: BEGIN")
        end = text.find("<!-- MACHINE-GENERATED FACTS: END -->")
        if begin == -1 or end == -1:
            problems.append("BUILD-REPORT-V007.md lacks machine-generated markers")
        else:
            narrative_only = text[:begin] + text[end:]
            for match in _VOLATILE.finditer(narrative_only):
                problems.append(
                    f"BUILD-REPORT-V007.md: volatile count {match.group(0)!r} "
                    f"outside the machine-generated section"
                )
        check = subprocess.run(
            [sys.executable, "scripts/gen_build_report.py", "--check"],
            cwd=ROOT, capture_output=True, text=True, check=False,
        )
        if check.returncode != 0:
            problems.append(
                "build report drift: machine facts do not regenerate "
                "identically from evidence"
            )
    # 6. ZIP/package naming policy present in release procedure
    procedure = ROOT / "09-governance" / "RELEASE-PROCEDURE.md"
    if procedure.is_file() and "UraiFlow-SaaS_Claude_" not in procedure.read_text():
        problems.append("RELEASE-PROCEDURE.md: package naming policy missing")
    return problems


def main() -> int:
    problems = validate()
    EVIDENCE.mkdir(exist_ok=True)
    if problems:
        report = "G10 docs-consistency FAIL:\n" + "\n".join(
            f" - {p}" for p in problems
        ) + "\n"
        (EVIDENCE / "G10-docs-consistency.txt").write_text(report, encoding="utf-8")
        print(report, file=sys.stderr)
        return 1
    report = (
        "G10 docs-consistency PASS: versions consistent, no stale product "
        "names, all ADR references resolve, no manually quoted volatile "
        "counts in current narrative docs, build-report facts regenerate "
        "identically from machine evidence\n"
    )
    (EVIDENCE / "G10-docs-consistency.txt").write_text(report, encoding="utf-8")
    print(report.strip())
    return 0


if __name__ == "__main__":
    sys.exit(main())
