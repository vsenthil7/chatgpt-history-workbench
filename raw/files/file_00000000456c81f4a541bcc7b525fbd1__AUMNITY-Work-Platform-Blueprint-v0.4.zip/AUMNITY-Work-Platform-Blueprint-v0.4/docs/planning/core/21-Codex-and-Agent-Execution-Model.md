# AUMNITY Work Platform Codex and Agent Execution Model

## Rules

- one module/sprint at a time
- RTM before code
- explicit domain terms
- state-machine tests
- no silent scope changes
- session handoff folders
- evidence-indexed completion
- architecture decisions recorded
- UraiFlow contracts reused, not duplicated
- unknown business rules become change requests, not guesses

## Repository

```text
/apps
/services
/packages
/domain
/infrastructure
/docs
/sprints
/sessions
/evidence
```
