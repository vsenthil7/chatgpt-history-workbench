# AUMNITY Work Platform Documentation Index

- `product/` — vision, scope, users, modules, roadmap and commercial model
- `architecture/` — Work Object model, data, events, workflows and diagram
- `planning/core/` — sprint tracker, RTM, build boundary and execution control
- `planning/modules/` — module planners
- `planning/sprint-context/` — sprint-specific context packs
- `help/` — operator, worker, reviewer and UraiFlow bridge guidance
- `governance/` — risks, decisions, version history and naming status
