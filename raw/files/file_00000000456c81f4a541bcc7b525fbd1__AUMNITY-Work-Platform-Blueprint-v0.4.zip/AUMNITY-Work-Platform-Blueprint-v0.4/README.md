# AUMNITY Work Platform Blueprint

This is the parent work-platform blueprint. **The product name is not yet approved.**

## Hierarchy

```text
AUMNITY                    Umbrella programme/company identity
└── Work platform          Product category; final product name pending
    ├── UraiFlow           Interview/conversation product module
    └── Future modules     Support, sales, recruitment, operations, etc.
```

## Documentation structure

All controlled documents are under `docs/`.

```text
docs/
├── product/
├── architecture/
├── planning/
│   ├── core/
│   ├── modules/
│   └── sprint-context/
├── help/
├── api/
├── testing/
├── operations/
└── governance/
```

The root is reserved for the repository README, manifests and future code folders.
