# Independent Review Findings — V012 (ChatGPT freeze-oriented deep review, 2026-08-09 15:46) and dispositions in V013

Source: full-package review and adversarial probes against the extracted
`AUMNITY-Work-Platform-SaaS_Claude_V012_20260809_1538.zip`
(sha256 `865c36dbcc2a79fae6579ffdfa4dcb5ab8f3d426b664f65beed122e26652a444`).
Rule applied: no finding may silently disappear. Dispositions in this file
were verified against the verbatim review text (DEF-037 packaging rule).

The review independently confirmed both V011 findings genuinely fixed: the
nested store scope is a mechanical mutation boundary (the exact
Organisation/Principal probe rejected at the write, zero nested effects), the
immediate-parent subset rule works, bare sections grant no mutation rights,
and the release sidecar machine-derives the headline numbers (V011 F2
CLOSED). The review's environmental note — G07 aborting outside a clean venv
for lack of `ruff` — was correctly identified by the reviewer as not a
package failure (the clean-venv release evidence shows G07 PASS twice).
Freeze decision: NO — one transaction-mode capability defect remained.

| # | Finding | Disposition | Where |
|---|---|---|---|
| F1 | BLOCKER: `UnitOfWork.read()` was not read-only when it joined an ambient WRITE transaction. Top-level reads began the domain with `writable=False`, but the joined path was `if owned: return operation()`, so a read inside a write transaction inherited the parent's `_writable=True`. Executed against shipped V012: `uow.run(lambda: uow.read(lambda: organisations.add(org)))` — no rejection, the Organisation persisted. The same read callback was read-only at top level and writable when nested, contradicting the UnitOfWork port contract and the ENFORCED RD-001 invariant; ADR-025 scoped stores but transaction mode was still one outermost boolean. | **FIXED (mode joined the frame model, architectural)** | ADR-026: every transaction frame carries `{declared stores, READ|WRITE}`; the global `_writable` boolean is eliminated; a joined `read()` pushes a READ frame so read-only is context-independent; `writable_by_current_thread()` answers for the CURRENT frame; a WRITE frame cannot be pushed under a READ frame (no escalation). No service-specific patch, exactly as the review directed. The review's exact regression (`write UoW → nested read() → mutation attempt` raises ValidationError, zero mutation) plus WRITE→READ legitimacy, WRITE→nested-WRITE subset preservation, READ→WRITE escalation rejection, and the public-operation internal-read path are permanent regressions: `TestReadFrameModeRegression`; DEF-041; RTM RD-003. Recorded as a new ADR/defect — ADR-023/ADR-025 history untouched (ADR-025 status annotated "frame model extended by ADR-026"). |

Preserved as the review directed: all V012 scope-stack work (ADR-025), the
machine-derived G11 release summary (DEF-040), ADR-024 savepoints, the
historical review ledgers, baseline byte-identity, and OD-001 OPEN. The
review asked that V013 not broaden into new platform functionality; V013
contains this fix and its evidence only. Freeze remains the reviewer's call;
the next review is intended as a strict freeze/no-freeze decision.
