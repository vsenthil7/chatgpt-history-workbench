"""Tenant isolation and cross-tenant denial tests (RTM: SaaS-001/SaaS-002, DW-FR-013).

Gate G08 evidence: every protected read/write path denies cross-tenant access.
"""

import contextlib
from dataclasses import replace
from datetime import UTC, datetime

import pytest
from aumnity_contracts import (
    ConcurrencyError,
    EventEnvelope,
    EvidenceId,
    NotFoundError,
    OrganisationId,
    PolicyViolationError,
    PrincipalId,
    SequenceIdGenerator,
    TenantContext,
    TenantIsolationError,
    TickingClock,
    ValidationError,
    WorkObjectId,
)
from aumnity_kernel import AuditLog, CriticalWorkEvidencePolicy
from aumnity_kernel.adapters.memory import (
    InMemoryAuditSink,
    InMemoryEvidenceRepository,
    InMemoryOrganisationRepository,
    InMemoryPlatformStores,
    InMemoryPrincipalRepository,
    InMemoryTenantProvisioner,
    InMemoryUnitOfWork,
    InMemoryWorkObjectRepository,
    TransactionMutex,
    bind_serialisation_domain,
)
from aumnity_kernel.evidence import EvidenceKind, EvidenceRecord
from aumnity_kernel.identity import Principal, PrincipalKind
from aumnity_kernel.organisation import (
    Organisation,
    OrganisationDirectory,
    PlatformProvisioning,
)
from aumnity_kernel.workobject.model import Priority, RiskLevel, WorkObject
from aumnity_kernel.workobject.service import WorkObjectRegistry
from aumnity_kernel.workobject.state import WorkObjectState

pytestmark = pytest.mark.isolation


def _create(registry: WorkObjectRegistry, tenant: TenantContext) -> WorkObjectId:
    return registry.create(
        tenant,
        title="Alpha-only record",
        purpose="Isolation subject",
        work_type="generic.task",
        priority=Priority.NORMAL,
        risk_level=RiskLevel.LOW,
        owner_id=tenant.principal_id,
    ).work_object_id


def test_cross_tenant_read_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.get(tenant_b, wid)


def test_cross_tenant_transition_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.mark_ready(tenant_b, wid)


def test_cross_tenant_evidence_attachment_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.attach_evidence(
            tenant_b,
            wid,
            kind=EvidenceKind.DOCUMENT,
            uri="evidence/steal.pdf",
            content_sha256="feed",
            source_system="MANUAL",
            source_reference="steal-1",
        )


def test_cross_tenant_decomposition_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    parent = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.create(
            tenant_b,
            title="Hostile child",
            purpose="Attach to foreign parent",
            work_type="generic.task",
            priority=Priority.NORMAL,
            risk_level=RiskLevel.LOW,
            owner_id=tenant_b.principal_id,
            parent_id=parent,
        )


def test_cross_tenant_children_listing_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    parent = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.children(tenant_b, parent)


def test_cross_tenant_evidence_listing_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.evidence_for(tenant_b, wid)


def test_audit_trail_is_tenant_filtered(
    registry: WorkObjectRegistry,
    tenant_a: TenantContext,
    tenant_b: TenantContext,
    audit: AuditLog,
) -> None:
    _create(registry, tenant_a)
    _create(registry, tenant_b)
    a_entries = audit.entries_for(tenant_a)
    b_entries = audit.entries_for(tenant_b)
    assert {e.organisation_id for e in a_entries} == {tenant_a.organisation_id}
    assert {e.organisation_id for e in b_entries} == {tenant_b.organisation_id}


def test_unknown_id_is_not_found_not_isolation(
    registry: WorkObjectRegistry, tenant_a: TenantContext
) -> None:
    """ADR-006: distinct internal types; edge maps both to one external shape."""
    with pytest.raises(NotFoundError):
        registry.get(tenant_a, WorkObjectId("wob-never-existed"))


class TestPrincipalBindingRegression:
    """Regressions for V002 review Findings 1 and 2 (ChatGPT, 2026-08-08).

    ChatGPT reproduced foreign owner/assignee acceptance and mismatched
    TenantContext acceptance against the delivered V002 package. Every exploit
    reproduced there must fail here permanently.
    """

    def test_foreign_owner_rejected(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        with pytest.raises(TenantIsolationError):
            registry.create(
                tenant_a,
                title="Injection attempt",
                purpose="owner from another organisation",
                work_type="TASK",
                priority=Priority.NORMAL,
                risk_level=RiskLevel.LOW,
                owner_id=tenant_b.principal_id,
            )

    def test_foreign_assignee_rejected(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        wid = _create(registry, tenant_a)
        registry.mark_ready(tenant_a, wid)
        registry.mark_assignable(tenant_a, wid)
        with pytest.raises(TenantIsolationError):
            registry.assign(tenant_a, wid, tenant_b.principal_id)
        # denial left no partial state behind
        assert registry.get(tenant_a, wid).assignee_id is None

    def test_mismatched_context_principal_rejected_on_create(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            registry.create(
                forged,
                title="Forged context",
                purpose="principal from another organisation",
                work_type="TASK",
                priority=Priority.NORMAL,
                risk_level=RiskLevel.LOW,
                owner_id=tenant_b.principal_id,
            )

    def test_cross_tenant_acting_principal_rejected_on_read(
        self,
        registry: WorkObjectRegistry,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        wid = _create(registry, tenant_a)
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            registry.get(forged, wid)

    def test_unknown_acting_principal_rejected(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        ghost = TenantContext(tenant_a.organisation_id, PrincipalId("prn-nonexistent"))
        with pytest.raises(TenantIsolationError):
            registry.get(ghost, WorkObjectId("wob-000001"))

    def test_same_tenant_owner_and_assignee_accepted(
        self,
        registry: WorkObjectRegistry,
        directory: OrganisationDirectory,
        tenant_a: TenantContext,
    ) -> None:
        colleague = directory.create_principal(tenant_a, PrincipalKind.HUMAN, "Colleague")
        wo = registry.create(
            tenant_a,
            title="Legitimate work",
            purpose="same-organisation principals",
            work_type="TASK",
            priority=Priority.NORMAL,
            risk_level=RiskLevel.LOW,
            owner_id=colleague.principal_id,
        )
        registry.mark_ready(tenant_a, wo.work_object_id)
        registry.mark_assignable(tenant_a, wo.work_object_id)
        assigned = registry.assign(tenant_a, wo.work_object_id, colleague.principal_id)
        assert assigned.owner_id == colleague.principal_id
        assert assigned.assignee_id == colleague.principal_id

    def test_rejected_operation_writes_no_audit_event(
        self,
        registry: WorkObjectRegistry,
        audit: AuditLog,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        """Audit actor can never be foreign: binding fails before any emit."""
        before = len(audit.entries_for(tenant_a))
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            registry.create(
                forged,
                title="No audit trace expected",
                purpose="rejected before emit",
                work_type="TASK",
                priority=Priority.NORMAL,
                risk_level=RiskLevel.LOW,
                owner_id=tenant_a.principal_id,
            )
        entries = audit.entries_for(tenant_a)
        assert len(entries) == before
        member_ids = {tenant_a.principal_id}
        assert all(e.actor_principal_id in member_ids for e in entries)


class TestAuditImmutabilityRegression:
    """Regression for V002 review Finding 3: recorded history cannot be tampered."""

    def test_recorded_payload_rejects_mutation(
        self, registry: WorkObjectRegistry, audit: AuditLog, tenant_a: TenantContext
    ) -> None:
        wid = _create(registry, tenant_a)
        registry.mark_ready(tenant_a, wid)
        entry = audit.entries_for(tenant_a)[0]
        with pytest.raises(TypeError):
            entry.payload["k"] = "tampered"  # type: ignore[index]
        assert "k" not in audit.entries_for(tenant_a)[0].payload

    def test_caller_supplied_payload_dict_is_decoupled(self, tenant_a: TenantContext) -> None:
        source = {"key": "original"}
        event = EventEnvelope(
            event_type="Probe",
            organisation_id=tenant_a.organisation_id,
            actor_principal_id=tenant_a.principal_id,
            subject_id="wob-000001",
            subject_version=1,
            occurred_at=datetime(2026, 1, 1, tzinfo=UTC),
            payload=source,
        )
        source["key"] = "tampered"
        source["new"] = "injected"
        assert dict(event.payload) == {"key": "original"}


class TestAuditBoundaryRegression:
    """Regressions for V003 review Findings 1–2 (ChatGPT, 2026-08-08 23:01).

    The published AuditLog is a protected boundary (ADR-010): forged contexts
    can neither read nor write, and an audit actor can never be foreign AT THIS
    BOUNDARY, not merely for events emitted via WorkObjectRegistry.
    """

    @staticmethod
    def _event(org: TenantContext, actor: PrincipalId, event_type: str = "Probe") -> EventEnvelope:
        return EventEnvelope(
            event_type=event_type,
            organisation_id=org.organisation_id,
            actor_principal_id=actor,
            subject_id="wob-000001",
            subject_version=1,
            occurred_at=datetime(2026, 1, 1, tzinfo=UTC),
        )

    def test_forged_context_audit_read_rejected(
        self,
        registry: WorkObjectRegistry,
        audit: AuditLog,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        """The exact V003 exploit: TenantContext(Org-A, Principal-B) read Org-A history."""
        _create(registry, tenant_a)
        assert len(audit.entries_for(tenant_a)) == 1  # legitimate read works
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            audit.entries_for(forged)

    def test_foreign_actor_audit_write_rejected(
        self, audit: AuditLog, tenant_a: TenantContext, tenant_b: TenantContext
    ) -> None:
        """The exact V003 exploit: Org-A event carrying Org-B's principal as actor.

        Under ADR-014 the attribution rule (actor == bound acting principal)
        rejects this before any membership question arises: a foreign actor can
        never equal a proven member, so the denial subsumes isolation.
        """
        injected = self._event(tenant_a, tenant_b.principal_id, "Injected")
        with pytest.raises(ValidationError, match="must be the acting principal"):
            audit.record(tenant_a, injected)
        assert audit.entries_for(tenant_a) == ()

    def test_unknown_actor_audit_write_rejected(
        self, audit: AuditLog, tenant_a: TenantContext
    ) -> None:
        with pytest.raises(ValidationError, match="must be the acting principal"):
            audit.record(tenant_a, self._event(tenant_a, PrincipalId("prn-nonexistent")))
        assert audit.entries_for(tenant_a) == ()

    def test_forged_context_audit_write_rejected(
        self, audit: AuditLog, tenant_a: TenantContext, tenant_b: TenantContext
    ) -> None:
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            audit.record(forged, self._event(tenant_a, tenant_a.principal_id))
        assert audit.entries_for(tenant_a) == ()

    def test_cross_organisation_event_write_rejected(
        self, audit: AuditLog, tenant_a: TenantContext, tenant_b: TenantContext
    ) -> None:
        """A member of Org-A cannot record an event stamped for Org-B."""
        with pytest.raises(TenantIsolationError):
            audit.record(tenant_a, self._event(tenant_b, tenant_b.principal_id))
        assert audit.entries_for(tenant_b) == ()

    def test_valid_same_tenant_write_and_read(
        self,
        audit: AuditLog,
        directory: OrganisationDirectory,
        tenant_a: TenantContext,
    ) -> None:
        """ADR-014: a principal records AS ITSELF under its own context."""
        colleague = directory.create_principal(tenant_a, PrincipalKind.SERVICE, "Recorder")
        colleague_context = TenantContext(tenant_a.organisation_id, colleague.principal_id)
        audit.record(
            colleague_context,
            self._event(colleague_context, colleague.principal_id, "ServiceEvent"),
        )
        entries = audit.entries_for(tenant_a)
        assert [e.event_type for e in entries] == ["ServiceEvent"]
        assert entries[0].actor_principal_id == colleague.principal_id

    def test_same_tenant_actor_impersonation_rejected(
        self,
        audit: AuditLog,
        directory: OrganisationDirectory,
        tenant_a: TenantContext,
    ) -> None:
        """The exact V004 review Finding 3 scenario: founder context, colleague actor."""
        colleague = directory.create_principal(tenant_a, PrincipalKind.SERVICE, "Recorder")
        with pytest.raises(ValidationError, match="must be the acting principal"):
            audit.record(tenant_a, self._event(tenant_a, colleague.principal_id, "Forged"))
        assert audit.entries_for(tenant_a) == ()

    def test_no_cross_tenant_event_disclosure(
        self,
        registry: WorkObjectRegistry,
        audit: AuditLog,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        _create(registry, tenant_a)
        _create(registry, tenant_b)
        for context in (tenant_a, tenant_b):
            entries = audit.entries_for(context)
            assert entries
            assert {e.organisation_id for e in entries} == {context.organisation_id}


class TestTenantBootstrapAtomicityRegression:
    """Regressions for V003 Finding 3 and V004 Finding 2 (ADR-011).

    All four failure shapes ChatGPT demanded: each store failing BEFORE and
    AFTER its own write. After any failure, observers must see neither an
    organisation nor a principal.
    """

    @staticmethod
    def _bootstrap_under(
        organisations: InMemoryOrganisationRepository,
        principals: InMemoryPrincipalRepository,
        clock: TickingClock,
        ids: SequenceIdGenerator,
    ) -> PlatformProvisioning:
        return PlatformProvisioning(
            provisioner=InMemoryTenantProvisioner(*_bound_pair(organisations, principals)),
            clock=clock,
            ids=ids,
        )

    @staticmethod
    def _assert_no_partial_tenant(
        organisations: InMemoryOrganisationRepository,
        principals: InMemoryPrincipalRepository,
    ) -> None:
        assert organisations.get(OrganisationId("org-000001")) is None
        assert principals.get(PrincipalId("prn-000002")) is None

    @pytest.mark.parametrize("when", ["before write", "after write"])
    def test_principal_store_failure_leaves_no_partial_tenant(
        self, clock: TickingClock, ids: SequenceIdGenerator, when: str
    ) -> None:
        organisations = InMemoryOrganisationRepository()

        class FailingPrincipalRepository(InMemoryPrincipalRepository):
            def add(self, principal: Principal) -> None:
                if when == "after write":
                    super().add(principal)  # the harder V004-review shape
                raise RuntimeError(f"principal persistence failed {when}")

        principals = FailingPrincipalRepository()
        provisioning = self._bootstrap_under(organisations, principals, clock, ids)
        with pytest.raises(RuntimeError, match="principal persistence failed"):
            provisioning.create_organisation("Doomed Org", "Doomed Founder", PrincipalKind.HUMAN)
        self._assert_no_partial_tenant(organisations, principals)

    @pytest.mark.parametrize("when", ["before write", "after write"])
    def test_organisation_store_failure_leaves_no_partial_tenant(
        self, clock: TickingClock, ids: SequenceIdGenerator, when: str
    ) -> None:
        class FailingOrganisationRepository(InMemoryOrganisationRepository):
            def add(self, organisation: Organisation) -> None:
                if when == "after write":
                    super().add(organisation)
                raise RuntimeError(f"organisation persistence failed {when}")

        organisations = FailingOrganisationRepository()
        principals = InMemoryPrincipalRepository()
        provisioning = self._bootstrap_under(organisations, principals, clock, ids)
        with pytest.raises(RuntimeError, match="organisation persistence failed"):
            provisioning.create_organisation("Doomed Org", "Doomed Founder", PrincipalKind.HUMAN)
        self._assert_no_partial_tenant(organisations, principals)

    def test_successful_bootstrap_persists_both(
        self, provisioning: PlatformProvisioning, directory: OrganisationDirectory
    ) -> None:
        org, founder = provisioning.create_organisation(
            "Whole Org", "Whole Founder", PrincipalKind.HUMAN
        )
        context = TenantContext(org.organisation_id, founder.principal_id)
        assert directory.get_organisation(context) == org
        assert directory.require_member(context, founder.principal_id) == founder


class TestOrganisationBoundaryRegression:
    """Regression for V004 review Finding 1: cross-tenant organisation metadata."""

    def test_cross_tenant_organisation_read_impossible_by_construction(
        self, directory: OrganisationDirectory, tenant_a: TenantContext
    ) -> None:
        """The published surface has NO arbitrary-id organisation lookup at all;
        `get_organisation` takes only a bound TenantContext."""
        import inspect

        parameters = list(inspect.signature(directory.get_organisation).parameters)
        assert parameters == ["context"]
        assert directory.get_organisation(tenant_a).organisation_id == tenant_a.organisation_id

    def test_forged_context_organisation_read_rejected(
        self,
        directory: OrganisationDirectory,
        tenant_a: TenantContext,
        tenant_b: TenantContext,
    ) -> None:
        forged = TenantContext(tenant_a.organisation_id, tenant_b.principal_id)
        with pytest.raises(TenantIsolationError):
            directory.get_organisation(forged)

    def test_trusted_provisioning_is_not_published(self) -> None:
        import aumnity_kernel

        assert "PlatformProvisioning" not in aumnity_kernel.__all__
        assert "OrganisationRegistry" not in aumnity_kernel.__all__


def _bound_pair(
    organisations: InMemoryOrganisationRepository, principals: InMemoryPrincipalRepository
) -> tuple[InMemoryOrganisationRepository, InMemoryPrincipalRepository]:
    bind_serialisation_domain(organisations, principals)
    return organisations, principals


def _hostile_registry(
    work_objects: InMemoryWorkObjectRepository,
    evidence: InMemoryEvidenceRepository,
    audit_sink: InMemoryAuditSink,
    directory: OrganisationDirectory,
    clock: TickingClock,
    ids: SequenceIdGenerator,
) -> WorkObjectRegistry:
    """Registry over caller-supplied (possibly hostile/faulty) adapters."""
    bind_serialisation_domain(work_objects, evidence, audit_sink)
    return WorkObjectRegistry(
        work_objects=work_objects,
        evidence=evidence,
        audit=AuditLog(
            audit_sink,
            principals=directory,
            unit_of_work=InMemoryUnitOfWork(audit_sink),
        ),
        completion_policy=CriticalWorkEvidencePolicy(),
        principals=directory,
        unit_of_work=InMemoryUnitOfWork(work_objects, evidence, audit_sink),
        clock=clock,
        ids=ids,
    )


class TestCommandAtomicityRegression:
    """Regression for V005 review F1 (ADR-016/DEF-020): domain writes and the
    mandatory audit append commit atomically; a fault-injected audit sink must
    leave NO persisted work object, evidence or event behind."""

    class FailingAppendSink(InMemoryAuditSink):
        def __init__(self) -> None:
            super().__init__()
            self.fail = False

        def append(self, event: EventEnvelope) -> None:
            if self.fail:
                raise RuntimeError("audit persistence failed")
            super().append(event)

    @pytest.fixture()
    def rig(
        self,
        directory: OrganisationDirectory,
        provisioning: PlatformProvisioning,
        clock: TickingClock,
        ids: SequenceIdGenerator,
    ) -> tuple[
        WorkObjectRegistry, "TestCommandAtomicityRegression.FailingAppendSink", TenantContext
    ]:
        sink = self.FailingAppendSink()
        work_objects = InMemoryWorkObjectRepository()
        evidence = InMemoryEvidenceRepository()
        registry = _hostile_registry(work_objects, evidence, sink, directory, clock, ids)
        org, founder = provisioning.create_organisation(
            "Atomic Org", "Founder", PrincipalKind.HUMAN
        )
        return registry, sink, TenantContext(org.organisation_id, founder.principal_id)

    def test_create_rolls_back_when_audit_append_fails(self, rig) -> None:  # type: ignore[no-untyped-def]
        registry, sink, tenant = rig
        sink.fail = True
        with pytest.raises(RuntimeError, match="audit persistence failed"):
            _create(registry, tenant)
        # The exact V005 probe asserted an orphan work object survived; now:
        with pytest.raises(NotFoundError):
            registry.get(tenant, WorkObjectId("wob-000003"))
        sink.fail = False
        assert (
            AuditLog(
                sink, principals=registry._principals, unit_of_work=InMemoryUnitOfWork(sink)
            ).entries_for(tenant)
            == ()
        )

    def test_transition_rolls_back_when_audit_append_fails(self, rig) -> None:  # type: ignore[no-untyped-def]
        registry, sink, tenant = rig
        wid = _create(registry, tenant)
        before = registry.get(tenant, wid)
        sink.fail = True
        with pytest.raises(RuntimeError, match="audit persistence failed"):
            registry.mark_ready(tenant, wid)
        sink.fail = False
        after = registry.get(tenant, wid)
        assert after.state is before.state
        assert after.version == before.version
        assert after.history == before.history

    def test_attach_evidence_rolls_back_when_audit_append_fails(self, rig) -> None:  # type: ignore[no-untyped-def]
        registry, sink, tenant = rig
        wid = _create(registry, tenant)
        before = registry.get(tenant, wid)
        sink.fail = True
        with pytest.raises(RuntimeError, match="audit persistence failed"):
            registry.attach_evidence(
                tenant,
                wid,
                kind=EvidenceKind.DOCUMENT,
                uri="evidence/x.pdf",
                content_sha256="feed",
                source_system="MANUAL",
                source_reference="ref-x",
            )
        sink.fail = False
        after = registry.get(tenant, wid)
        assert after.evidence_ids == before.evidence_ids
        assert after.version == before.version
        assert registry.evidence_for(tenant, wid) == ()


class TestDefectiveAdapterRevalidationRegression:
    """Regressions for V005 review F2/F3 (ADR-002 addendum/DEF-021/DEF-022):
    the kernel revalidates EVERY repository-returned aggregate, so hostile or
    defective adapters fail closed instead of leaking."""

    def test_hostile_children_returning_foreign_work_object_fails_closed(
        self,
        directory: OrganisationDirectory,
        provisioning: PlatformProvisioning,
        clock: TickingClock,
        ids: SequenceIdGenerator,
        tenant_b: TenantContext,
        registry: WorkObjectRegistry,
    ) -> None:
        """The exact V005 F2 probe: children_of returns an Org-B object."""
        foreign_id = _create(registry, tenant_b)
        foreign = registry.get(tenant_b, foreign_id)

        class HostileWorkObjectRepository(InMemoryWorkObjectRepository):
            def children_of(self, parent_id: WorkObjectId):  # type: ignore[no-untyped-def]
                return (replace(foreign),)

        work_objects = HostileWorkObjectRepository()
        hostile = _hostile_registry(
            work_objects, InMemoryEvidenceRepository(), InMemoryAuditSink(), directory, clock, ids
        )
        org, founder = provisioning.create_organisation("A Org", "Founder", PrincipalKind.HUMAN)
        tenant = TenantContext(org.organisation_id, founder.principal_id)
        parent_id = _create(hostile, tenant)
        with pytest.raises(TenantIsolationError):
            hostile.children(tenant, parent_id)

    def test_hostile_children_returning_unrelated_same_tenant_object_fails_closed(
        self,
        directory: OrganisationDirectory,
        provisioning: PlatformProvisioning,
        clock: TickingClock,
        ids: SequenceIdGenerator,
    ) -> None:
        class HostileWorkObjectRepository(InMemoryWorkObjectRepository):
            def children_of(self, parent_id: WorkObjectId):  # type: ignore[no-untyped-def]
                # returns a same-tenant object that is NOT a child of parent_id
                return tuple(
                    replace(item) for item in self._items.values() if item.parent_id is None
                )

        work_objects = HostileWorkObjectRepository()
        hostile = _hostile_registry(
            work_objects, InMemoryEvidenceRepository(), InMemoryAuditSink(), directory, clock, ids
        )
        org, founder = provisioning.create_organisation("A Org", "Founder", PrincipalKind.HUMAN)
        tenant = TenantContext(org.organisation_id, founder.principal_id)
        parent_id = _create(hostile, tenant)
        with pytest.raises(TenantIsolationError, match="parentage"):
            hostile.children(tenant, parent_id)

    def test_hostile_evidence_repository_mismatches_fail_closed(
        self,
        directory: OrganisationDirectory,
        provisioning: PlatformProvisioning,
        clock: TickingClock,
        ids: SequenceIdGenerator,
        tenant_b: TenantContext,
        registry: WorkObjectRegistry,
    ) -> None:
        foreign_wid = _create(registry, tenant_b)
        foreign_record = registry.attach_evidence(
            tenant_b,
            foreign_wid,
            kind=EvidenceKind.DOCUMENT,
            uri="evidence/foreign.pdf",
            content_sha256="dead",
            source_system="MANUAL",
            source_reference="ref-f",
        )

        class HostileEvidenceRepository(InMemoryEvidenceRepository):
            def get(self, evidence_id):  # type: ignore[no-untyped-def]
                return foreign_record  # wrong record, wrong tenant

        work_objects = InMemoryWorkObjectRepository()
        hostile = _hostile_registry(
            work_objects, HostileEvidenceRepository(), InMemoryAuditSink(), directory, clock, ids
        )
        org, founder = provisioning.create_organisation("A Org", "Founder", PrincipalKind.HUMAN)
        tenant = TenantContext(org.organisation_id, founder.principal_id)
        wid = _create(hostile, tenant)
        poisoned = replace(hostile.get(tenant, wid), evidence_ids=(EvidenceId("evd-x"),))
        InMemoryUnitOfWork(work_objects).run(
            lambda: work_objects.update(poisoned, expected_version=1)
        )
        with pytest.raises(TenantIsolationError):
            hostile.evidence_for(tenant, wid)

    def test_hostile_organisation_repository_wrong_row_fails_closed(
        self,
        provisioning: PlatformProvisioning,
        clock: TickingClock,
        ids: SequenceIdGenerator,
    ) -> None:
        org_b = Organisation(
            organisation_id=OrganisationId("org-other"),
            name="Other Org",
            created_at=datetime(2026, 1, 1, tzinfo=UTC),
        )

        class HostileOrganisationRepository(InMemoryOrganisationRepository):
            def get(self, organisation_id):  # type: ignore[no-untyped-def]
                return org_b  # wrong organisation for any requested id

        organisations = HostileOrganisationRepository()
        principals = InMemoryPrincipalRepository()
        bind_serialisation_domain(organisations, principals)
        hostile_directory = OrganisationDirectory(
            organisations=organisations,
            principals=principals,
            unit_of_work=InMemoryUnitOfWork(organisations, principals),
            clock=clock,
            ids=ids,
        )
        founder = Principal(
            principal_id=PrincipalId("prn-real"),
            organisation_id=OrganisationId("org-real"),
            kind=PrincipalKind.HUMAN,
            display_name="Founder",
        )
        InMemoryUnitOfWork(principals).run(lambda: principals.add(founder))
        context = TenantContext(OrganisationId("org-real"), founder.principal_id)
        with pytest.raises(TenantIsolationError, match="identity mismatch"):
            hostile_directory.get_organisation(context)

    def test_hostile_principal_repository_wrong_row_not_membership_proof(
        self,
        provisioning: PlatformProvisioning,
        clock: TickingClock,
        ids: SequenceIdGenerator,
    ) -> None:
        """The exact V005 F3 probe: repo returns the founder for 'not-real'."""
        org, founder = provisioning.create_organisation("A Org", "Founder", PrincipalKind.HUMAN)

        class HostilePrincipalRepository(InMemoryPrincipalRepository):
            def get(self, principal_id):  # type: ignore[no-untyped-def]
                return founder  # any id "resolves" to the founder

        organisations = InMemoryOrganisationRepository()
        hostile_principals = HostilePrincipalRepository()
        bind_serialisation_domain(organisations, hostile_principals)
        hostile_directory = OrganisationDirectory(
            organisations=organisations,
            principals=hostile_principals,
            unit_of_work=InMemoryUnitOfWork(organisations, hostile_principals),
            clock=clock,
            ids=ids,
        )
        context = TenantContext(org.organisation_id, PrincipalId("prn-not-real"))
        with pytest.raises(TenantIsolationError, match="not accessible"):
            hostile_directory.require_member(context, PrincipalId("prn-not-real"))

    def test_hostile_principal_repository_foreign_row_not_membership_proof(
        self,
        provisioning: PlatformProvisioning,
        clock: TickingClock,
        ids: SequenceIdGenerator,
        tenant_b: TenantContext,
        directory: OrganisationDirectory,
    ) -> None:
        foreign = directory.require_member(tenant_b, tenant_b.principal_id)

        class HostilePrincipalRepository(InMemoryPrincipalRepository):
            def get(self, principal_id):  # type: ignore[no-untyped-def]
                return foreign

        org, _founder = provisioning.create_organisation("A Org", "Founder", PrincipalKind.HUMAN)
        organisations = InMemoryOrganisationRepository()
        hostile_principals = HostilePrincipalRepository()
        bind_serialisation_domain(organisations, hostile_principals)
        hostile_directory = OrganisationDirectory(
            organisations=organisations,
            principals=hostile_principals,
            unit_of_work=InMemoryUnitOfWork(organisations, hostile_principals),
            clock=clock,
            ids=ids,
        )
        context = TenantContext(org.organisation_id, PrincipalId("prn-whatever"))
        with pytest.raises(TenantIsolationError, match="not accessible"):
            hostile_directory.require_member(context, PrincipalId("prn-whatever"))


class TestVerifiedEvidenceCompletionRegression:
    """Regression for V005 review F4 (DEF-023): completion depends on VERIFIED
    evidence, never on a bare id list."""

    @staticmethod
    def _drive_to_approved(
        registry: WorkObjectRegistry, tenant: TenantContext, risk: RiskLevel
    ) -> WorkObjectId:
        wo = registry.create(
            tenant,
            title="Critical deliverable",
            purpose="verified evidence gating",
            work_type="TASK",
            priority=Priority.NORMAL,
            risk_level=risk,
            owner_id=tenant.principal_id,
        )
        wid = wo.work_object_id
        for step in (
            registry.mark_ready,
            registry.mark_assignable,
            lambda t, w: registry.assign(t, w, t.principal_id),
            registry.start_work,
            registry.submit_output,
            registry.request_review,
            registry.approve,
        ):
            step(tenant, wid)
        return wid

    def test_dangling_evidence_id_blocks_critical_completion(
        self,
        directory: OrganisationDirectory,
        provisioning: PlatformProvisioning,
        clock: TickingClock,
        ids: SequenceIdGenerator,
    ) -> None:
        """The exact V005 F4 probe: evidence_ids=('dangling',), no record."""

        class VanishingEvidenceRepository(InMemoryEvidenceRepository):
            def get(self, evidence_id):  # type: ignore[no-untyped-def]
                return None  # every reference dangles

        work_objects = InMemoryWorkObjectRepository()
        registry = _hostile_registry(
            work_objects, VanishingEvidenceRepository(), InMemoryAuditSink(), directory, clock, ids
        )
        org, founder = provisioning.create_organisation("A Org", "Founder", PrincipalKind.HUMAN)
        tenant = TenantContext(org.organisation_id, founder.principal_id)
        wid = self._drive_to_approved(registry, tenant, RiskLevel.CRITICAL)
        current = registry.get(tenant, wid)
        dangling = replace(current, evidence_ids=(EvidenceId("dangling"),))
        InMemoryUnitOfWork(work_objects).run(
            lambda: work_objects.update(dangling, expected_version=current.version)
        )
        with pytest.raises(PolicyViolationError, match="cannot be verified"):
            registry.complete(tenant, wid)

    def test_verified_evidence_permits_critical_completion(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        wid2 = registry.create(
            tenant_a,
            title="Critical with evidence",
            purpose="happy path",
            work_type="TASK",
            priority=Priority.NORMAL,
            risk_level=RiskLevel.CRITICAL,
            owner_id=tenant_a.principal_id,
        ).work_object_id
        registry.attach_evidence(
            tenant_a,
            wid2,
            kind=EvidenceKind.DOCUMENT,
            uri="evidence/proof.pdf",
            content_sha256="beef",
            source_system="MANUAL",
            source_reference="ref-p",
        )
        for step in (
            registry.mark_ready,
            registry.mark_assignable,
            lambda t, w: registry.assign(t, w, t.principal_id),
            registry.start_work,
            registry.submit_output,
            registry.request_review,
            registry.approve,
        ):
            step(tenant_a, wid2)
        completed = registry.complete(tenant_a, wid2)
        assert completed.state.value == "COMPLETED"


class TestPersistenceIntegrityRegression:
    """Regressions for V005 review F5/F6 (ADR-017/DEF-024/DEF-025)."""

    def test_duplicate_work_object_id_rejected(self, tenant_a: TenantContext) -> None:
        repo = InMemoryWorkObjectRepository()
        bind_serialisation_domain(repo)
        first = _model_work_object(tenant_a)

        def create_then_collide() -> None:
            repo.create(first)
            with pytest.raises(ValidationError, match="duplicate work object id"):
                repo.create(_model_work_object(tenant_a))

        InMemoryUnitOfWork(repo).run(create_then_collide)

    def test_duplicate_evidence_id_rejected(self, tenant_a: TenantContext) -> None:
        repo = InMemoryEvidenceRepository()
        bind_serialisation_domain(repo)
        record = EvidenceRecord(
            evidence_id=EvidenceId("evd-1"),
            organisation_id=tenant_a.organisation_id,
            work_object_id=WorkObjectId("wob-1"),
            kind=EvidenceKind.DOCUMENT,
            uri="evidence/a.pdf",
            content_sha256="aa",
            submitted_by=tenant_a.principal_id,
            submitted_at=datetime(2026, 1, 1, tzinfo=UTC),
            source_system="MANUAL",
            source_reference="r",
        )

        def add_then_collide() -> None:
            repo.add(record)
            with pytest.raises(ValidationError, match="duplicate evidence id"):
                repo.add(record)

        InMemoryUnitOfWork(repo).run(add_then_collide)

    def test_duplicate_principal_and_organisation_ids_rejected(
        self, tenant_a: TenantContext, directory: OrganisationDirectory
    ) -> None:
        principal = directory.require_member(tenant_a, tenant_a.principal_id)
        organisation = directory.get_organisation(tenant_a)

        def collide_both() -> None:
            with pytest.raises(ValidationError, match="duplicate principal id"):
                directory._principals.add(principal)
            with pytest.raises(ValidationError, match="duplicate organisation id"):
                directory._organisations.add(organisation)

        InMemoryUnitOfWork(directory._principals, directory._organisations).run(collide_both)

    def test_stale_write_raises_concurrency_error(self, tenant_a: TenantContext) -> None:
        """The V005 F6 lost-update scenario: two writers, both read version 1."""
        repo = InMemoryWorkObjectRepository()
        bind_serialisation_domain(repo)
        base = _model_work_object(tenant_a)
        uow = InMemoryUnitOfWork(repo)
        uow.run(lambda: repo.create(base))
        writer_one = replace(repo.get(base.work_object_id), title="first change", version=2)
        writer_two = replace(repo.get(base.work_object_id), title="second change", version=2)

        def race() -> None:
            repo.update(writer_one, expected_version=1)
            with pytest.raises(ConcurrencyError, match="stale write"):
                repo.update(writer_two, expected_version=1)

        uow.run(race)
        assert repo.get(base.work_object_id).title == "first change"

    def test_update_of_unknown_work_object_rejected(self, tenant_a: TenantContext) -> None:
        repo = InMemoryWorkObjectRepository()
        bind_serialisation_domain(repo)
        with pytest.raises(ValidationError, match="unknown work object"):
            InMemoryUnitOfWork(repo).run(
                lambda: repo.update(_model_work_object(tenant_a), expected_version=1)
            )


def _model_work_object(tenant: TenantContext) -> WorkObject:
    from aumnity_kernel.workobject.state import WorkObjectState

    return WorkObject(
        work_object_id=WorkObjectId("wob-1"),
        organisation_id=tenant.organisation_id,
        title="T",
        purpose="P",
        work_type="TASK",
        state=WorkObjectState.DRAFT,
        priority=Priority.NORMAL,
        risk_level=RiskLevel.LOW,
        requester_id=tenant.principal_id,
        owner_id=tenant.principal_id,
        created_at=datetime(2026, 1, 1, tzinfo=UTC),
        updated_at=datetime(2026, 1, 1, tzinfo=UTC),
    )


class TestTransactionSerialisationRegression:
    """Regressions for V006 review F1 (ADR-019/DEF-027): a failed transaction
    can never erase a concurrent committed transaction."""

    def test_failed_transaction_cannot_erase_concurrent_commit(
        self,
        directory: OrganisationDirectory,
        provisioning: PlatformProvisioning,
        clock: TickingClock,
        ids: SequenceIdGenerator,
    ) -> None:
        """Deterministic two-thread choreography of the review's exact probe:
        A begins → B attempts (must WAIT, not interleave) → A fails and rolls
        back → B commits → B's result survives."""
        import threading

        work_objects = InMemoryWorkObjectRepository()
        evidence = InMemoryEvidenceRepository()
        sink = InMemoryAuditSink()
        bind_serialisation_domain(work_objects, evidence, sink)
        registry = WorkObjectRegistry(
            work_objects=work_objects,
            evidence=evidence,
            audit=AuditLog(sink, principals=directory, unit_of_work=InMemoryUnitOfWork(sink)),
            completion_policy=CriticalWorkEvidencePolicy(),
            principals=directory,
            unit_of_work=InMemoryUnitOfWork(work_objects, evidence, sink),
            clock=clock,
            ids=ids,
        )
        org, founder = provisioning.create_organisation("Race Org", "Founder", PrincipalKind.HUMAN)
        tenant = TenantContext(org.organisation_id, founder.principal_id)
        wid = _create(registry, tenant)

        a_inside = threading.Event()
        a_release = threading.Event()
        a_error: list[BaseException] = []
        # A SECOND, independently constructed UoW over the same stores — the
        # exact V007-review probe. ADR-021 makes it share the derived domain.
        uow = InMemoryUnitOfWork(work_objects, evidence, sink)
        assert uow._mutex is registry._unit_of_work._mutex  # same domain, by construction

        def transaction_a() -> None:
            def operation() -> None:
                a_inside.set()
                assert a_release.wait(timeout=10)
                raise RuntimeError("transaction A fails after B tried to interleave")

            try:
                uow.run(operation)
            except RuntimeError as error:
                a_error.append(error)

        thread_a = threading.Thread(target=transaction_a)
        thread_a.start()
        assert a_inside.wait(timeout=10)

        # B attempts the V006-probe interleaving: commit while A holds its
        # snapshot. Under ADR-019 it must BLOCK instead.
        thread_b = threading.Thread(target=lambda: registry.mark_ready(tenant, wid))
        thread_b.start()
        thread_b.join(timeout=0.3)
        assert thread_b.is_alive(), "B must be serialised behind A, not interleaved"

        a_release.set()
        thread_a.join(timeout=10)
        thread_b.join(timeout=10)
        assert a_error and not thread_a.is_alive() and not thread_b.is_alive()

        # The V006 defect produced DRAFT/version 1 here; B's commit must survive.
        final = registry.get(tenant, wid)
        assert final.state is WorkObjectState.READY
        assert final.version == 2

    def test_nested_transaction_over_covered_stores_joins_enclosing(
        self, registry: WorkObjectRegistry, tenant_a: TenantContext
    ) -> None:
        """ADR-022 evolves the V006 nesting contract: a coordinator invoked
        while a transaction is active JOINS it when the enclosing snapshot
        covers its stores — required so the published AuditLog write path can
        participate inside registry commands. The enclosing rollback then
        protects the joined writes (proven by the command-atomicity suite,
        where audit failure rolls the whole command back)."""
        uow = registry._unit_of_work
        observed: list[str] = []

        def nested() -> str:
            return uow.run(lambda: observed.append("joined") or "ok")

        assert uow.run(nested) == "ok"
        assert observed == ["joined"]

    def test_nested_transaction_over_uncovered_stores_rejected(self) -> None:
        """Joining is permitted ONLY under coverage: a nested coordinator whose
        stores the enclosing transaction did not snapshot is rejected, because
        the enclosing rollback could not protect its writes."""
        stores = InMemoryPlatformStores()
        command_uow = stores.unit_of_work()  # covers wo/evidence/sink
        identity_uow = stores.identity_unit_of_work()  # org/principals
        with pytest.raises(ValidationError, match="outside the enclosing"):
            command_uow.run(lambda: identity_uow.run(lambda: None))

    def test_bare_domain_reentry_rejected(self) -> None:
        stores = InMemoryPlatformStores()
        stores.domain.begin(())
        try:
            with pytest.raises(ValidationError, match="cannot nest"):
                stores.domain.begin(())
        finally:
            stores.domain.end()

    def test_provisioner_shares_serialisation_with_unit_of_work(
        self, clock: TickingClock, ids: SequenceIdGenerator
    ) -> None:
        """Compositions over shared stores share the mutex: a provision nested
        inside a unit-of-work transaction is rejected, not raced."""
        stores = InMemoryPlatformStores()
        provisioner = stores.tenant_provisioner()
        uow = stores.unit_of_work()
        assert provisioner._mutex is uow._mutex  # one domain owns all resources
        org = Organisation(
            organisation_id=OrganisationId("org-x"),
            name="X",
            created_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        founder = Principal(
            principal_id=PrincipalId("prn-x"),
            organisation_id=OrganisationId("org-x"),
            kind=PrincipalKind.HUMAN,
            display_name="X",
        )
        # the command transaction does not cover org/principal stores, so the
        # provision cannot join it and is rejected (ADR-022 coverage rule)
        with pytest.raises(ValidationError, match="outside the enclosing"):
            uow.run(lambda: provisioner.provision(org, founder))


class TestAggregateReferenceIntegrityRegression:
    """Regressions for V006 review F3 (ADR-020/DEF-029): the defective-adapter
    invariant covers the WHOLE aggregate — embedded principal references are
    validated before disclosure."""

    def test_hostile_repository_foreign_embedded_references_fail_closed(
        self,
        directory: OrganisationDirectory,
        provisioning: PlatformProvisioning,
        clock: TickingClock,
        ids: SequenceIdGenerator,
        tenant_b: TenantContext,
    ) -> None:
        """The exact V006 probe: correct id + correct org, foreign
        requester/owner/assignee — previously disclosed, now fails closed."""
        org, founder = provisioning.create_organisation("A Org", "Founder", PrincipalKind.HUMAN)
        tenant = TenantContext(org.organisation_id, founder.principal_id)
        poisoned = WorkObject(
            work_object_id=WorkObjectId("wob-poisoned"),
            organisation_id=tenant.organisation_id,
            title="Poisoned",
            purpose="foreign embedded refs",
            work_type="TASK",
            state=WorkObjectState.DRAFT,
            priority=Priority.NORMAL,
            risk_level=RiskLevel.LOW,
            requester_id=tenant_b.principal_id,
            owner_id=tenant_b.principal_id,
            created_at=datetime(2026, 1, 1, tzinfo=UTC),
            updated_at=datetime(2026, 1, 1, tzinfo=UTC),
            assignee_id=tenant_b.principal_id,
        )

        class HostileWorkObjectRepository(InMemoryWorkObjectRepository):
            def get(self, work_object_id):  # type: ignore[no-untyped-def]
                return replace(poisoned, work_object_id=work_object_id)

        hostile = _hostile_registry(
            HostileWorkObjectRepository(),
            InMemoryEvidenceRepository(),
            InMemoryAuditSink(),
            directory,
            clock,
            ids,
        )
        with pytest.raises(TenantIsolationError, match="not accessible"):
            hostile.get(tenant, WorkObjectId("wob-poisoned"))

    def test_hostile_evidence_foreign_submitter_fails_closed(
        self,
        directory: OrganisationDirectory,
        provisioning: PlatformProvisioning,
        clock: TickingClock,
        ids: SequenceIdGenerator,
        tenant_b: TenantContext,
    ) -> None:
        org, founder = provisioning.create_organisation("A Org", "Founder", PrincipalKind.HUMAN)
        tenant = TenantContext(org.organisation_id, founder.principal_id)
        work_objects = InMemoryWorkObjectRepository()

        class HostileEvidenceRepository(InMemoryEvidenceRepository):
            def get(self, evidence_id):  # type: ignore[no-untyped-def]
                stored = super().get(evidence_id)
                if stored is None:
                    return None
                return EvidenceRecord(
                    evidence_id=stored.evidence_id,
                    organisation_id=stored.organisation_id,
                    work_object_id=stored.work_object_id,
                    kind=stored.kind,
                    uri=stored.uri,
                    content_sha256=stored.content_sha256,
                    submitted_by=tenant_b.principal_id,  # foreign submitter
                    submitted_at=stored.submitted_at,
                    source_system=stored.source_system,
                    source_reference=stored.source_reference,
                )

        hostile = _hostile_registry(
            work_objects, HostileEvidenceRepository(), InMemoryAuditSink(), directory, clock, ids
        )
        wid = _create(hostile, tenant)
        hostile.attach_evidence(
            tenant,
            wid,
            kind=EvidenceKind.DOCUMENT,
            uri="evidence/x.pdf",
            content_sha256="ff",
            source_system="MANUAL",
            source_reference="r",
        )
        with pytest.raises(TenantIsolationError, match="not accessible"):
            hostile.evidence_for(tenant, wid)


class TestSerialisationDomainConstructionInvariant:
    """Regressions for V007 review F1 (ADR-021/DEF-030): 'same transactional
    resources ⇒ same serialisation domain' is machine-enforced at
    construction, not a programmer convention."""

    def test_independently_locked_uows_over_same_stores_are_impossible(self) -> None:
        """The exact V007 probe construction: two UoWs over the same stores.
        Different mutexes can no longer be injected — no mutex parameter
        exists — and both derive the SAME domain from the stores."""
        work_objects = InMemoryWorkObjectRepository()
        evidence = InMemoryEvidenceRepository()
        sink = InMemoryAuditSink()
        bind_serialisation_domain(work_objects, evidence, sink)
        uow_a = InMemoryUnitOfWork(work_objects, evidence, sink)
        uow_b = InMemoryUnitOfWork(work_objects, evidence, sink)
        assert uow_a._mutex is uow_b._mutex

    def test_unbound_stores_are_rejected_at_construction(self) -> None:
        with pytest.raises(ValidationError, match="no serialisation domain"):
            InMemoryUnitOfWork(
                InMemoryWorkObjectRepository(),
                InMemoryEvidenceRepository(),
                InMemoryAuditSink(),
            )
        with pytest.raises(ValidationError, match="no serialisation domain"):
            InMemoryTenantProvisioner(
                InMemoryOrganisationRepository(), InMemoryPrincipalRepository()
            )

    def test_mixed_domain_stores_are_rejected_at_construction(self) -> None:
        work_objects = InMemoryWorkObjectRepository()
        evidence = InMemoryEvidenceRepository()
        sink = InMemoryAuditSink()
        bind_serialisation_domain(work_objects, evidence)
        bind_serialisation_domain(sink)  # a different domain
        with pytest.raises(ValidationError, match="different serialisation domains"):
            InMemoryUnitOfWork(work_objects, evidence, sink)
        organisations = InMemoryOrganisationRepository()
        principals = InMemoryPrincipalRepository()
        bind_serialisation_domain(organisations)
        bind_serialisation_domain(principals)  # a different domain
        with pytest.raises(ValidationError, match="different serialisation domains"):
            InMemoryTenantProvisioner(organisations, principals)

    def test_store_cannot_be_bound_into_a_second_domain(self) -> None:
        store = InMemoryWorkObjectRepository()
        domain = bind_serialisation_domain(store)
        # idempotent rebind into the SAME domain is fine
        assert bind_serialisation_domain(store, domain=domain) is domain
        with pytest.raises(ValidationError, match="different serialisation domain"):
            bind_serialisation_domain(store)

    def test_composition_root_gives_one_domain_to_all_adapters(self) -> None:
        stores = InMemoryPlatformStores()
        assert stores.unit_of_work()._mutex is stores.tenant_provisioner()._mutex
        assert stores.domain is stores.unit_of_work()._mutex


class TestWritePathParticipationRegression:
    """Regressions for V008 review F1/F2 (ADR-022/DEF-032/DEF-033): every
    mutation of transactional stores participates in the serialisation regime,
    so no published write can be erased by a concurrent rollback, and future
    bypass paths fail mechanically at the adapter."""

    def test_failed_provisioning_cannot_erase_concurrent_create_principal(
        self, clock: TickingClock, ids: SequenceIdGenerator
    ) -> None:
        """The exact V008 executed exploit, through the PUBLIC
        OrganisationDirectory.create_principal path: A provisions and fails
        mid-flight while B creates a principal for an existing tenant. Under
        ADR-022, B is serialised behind A; A's rollback restores only pre-A
        state; B then commits and SURVIVES (the V008 defect erased it)."""
        import threading

        stores = InMemoryPlatformStores()
        provisioning = PlatformProvisioning(
            provisioner=stores.tenant_provisioner(), clock=clock, ids=ids
        )
        directory = OrganisationDirectory(
            organisations=stores.organisations,
            principals=stores.principals,
            unit_of_work=stores.identity_unit_of_work(),
            clock=clock,
            ids=ids,
        )
        org, founder = provisioning.create_organisation(
            "Existing Org", "Founder", PrincipalKind.HUMAN
        )
        tenant = TenantContext(org.organisation_id, founder.principal_id)

        a_inside = threading.Event()
        a_release = threading.Event()

        class PausingFailingPrincipalRepository(InMemoryPrincipalRepository):
            def add(self, principal: Principal) -> None:
                super().add(principal)  # founder write lands, THEN failure
                a_inside.set()
                assert a_release.wait(timeout=10)
                raise RuntimeError("provisioning adapter failure after founder write")

        failing_principals = PausingFailingPrincipalRepository()
        failing_principals._items = dict(stores.principals._items)
        bind_serialisation_domain(failing_principals, domain=stores.domain)
        failing_provisioner = InMemoryTenantProvisioner(stores.organisations, failing_principals)
        failing_provisioning = PlatformProvisioning(
            provisioner=failing_provisioner, clock=clock, ids=ids
        )

        a_error: list[BaseException] = []

        def transaction_a() -> None:
            try:
                failing_provisioning.create_organisation(
                    "Doomed Org", "Doomed", PrincipalKind.HUMAN
                )
            except RuntimeError as error:
                a_error.append(error)

        created: list[Principal] = []
        thread_a = threading.Thread(target=transaction_a)
        thread_a.start()
        assert a_inside.wait(timeout=10)

        thread_b = threading.Thread(
            target=lambda: created.append(
                directory.create_principal(tenant, PrincipalKind.HUMAN, "Survivor")
            )
        )
        thread_b.start()
        thread_b.join(timeout=0.3)
        assert thread_b.is_alive(), "B must be serialised behind A's transaction, not interleaved"

        a_release.set()
        thread_a.join(timeout=10)
        thread_b.join(timeout=10)
        assert a_error and created

        # V008's executed result was `created principal survives rollback: False`.
        survivor = directory.require_member(tenant, created[0].principal_id)
        assert survivor.display_name == "Survivor"

    def test_direct_store_mutation_outside_transaction_rejected(self) -> None:
        """The mechanical guard for future services (ADR-022): a write path
        that skips the transaction regime fails at the adapter immediately."""
        stores = InMemoryPlatformStores()
        principal = Principal(
            principal_id=PrincipalId("prn-bypass"),
            organisation_id=OrganisationId("org-bypass"),
            kind=PrincipalKind.HUMAN,
            display_name="Bypass",
        )
        with pytest.raises(ValidationError, match="outside its serialisation domain"):
            stores.principals.add(principal)
        with pytest.raises(ValidationError, match="outside its serialisation domain"):
            stores.audit_sink.append(
                EventEnvelope(
                    event_type="Bypass",
                    organisation_id=OrganisationId("org-bypass"),
                    actor_principal_id=PrincipalId("prn-bypass"),
                    subject_id="wob-1",
                    subject_version=1,
                    occurred_at=datetime(2026, 1, 1, tzinfo=UTC),
                )
            )
        with pytest.raises(ValidationError, match="outside its serialisation domain"):
            stores.work_objects.create(
                _model_work_object(
                    TenantContext(OrganisationId("org-bypass"), PrincipalId("prn-bypass"))
                )
            )

    def test_failed_binding_leaves_prior_bindings_unchanged(self) -> None:
        """DEF-033: binding preflights the whole set — a conflict anywhere
        leaves EVERY participant's prior binding exactly as it was."""
        unbound = InMemoryWorkObjectRepository()
        conflicting = InMemoryEvidenceRepository()
        original_domain = bind_serialisation_domain(conflicting)
        with pytest.raises(ValidationError, match="different serialisation domain"):
            bind_serialisation_domain(unbound, conflicting)
        assert unbound._domain is None  # NOT bound by the failed call
        assert conflicting.serialisation_domain() is original_domain


class TestTransactionEdgeBranches:
    """Branch-completion tests for the ADR-021/022 transaction machinery."""

    def test_direct_bind_into_second_domain_rejected(self) -> None:
        store = InMemoryWorkObjectRepository()
        bind_serialisation_domain(store)
        with pytest.raises(ValidationError, match="different serialisation domain"):
            store.bind_domain(TransactionMutex())

    def test_provision_joins_covering_identity_transaction(
        self, clock: TickingClock, ids: SequenceIdGenerator
    ) -> None:
        """A provision nested inside a transaction that COVERS its stores joins
        it (ADR-022) — the enclosing rollback then protects both writes."""
        stores = InMemoryPlatformStores()
        provisioner = stores.tenant_provisioner()
        identity_uow = stores.identity_unit_of_work()
        org = Organisation(
            organisation_id=OrganisationId("org-joined"),
            name="Joined",
            created_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        founder = Principal(
            principal_id=PrincipalId("prn-joined"),
            organisation_id=OrganisationId("org-joined"),
            kind=PrincipalKind.HUMAN,
            display_name="Joined Founder",
        )
        identity_uow.run(lambda: provisioner.provision(org, founder))
        assert stores.organisations.get(OrganisationId("org-joined")) == org

        # and the enclosing rollback protects a joined provision:
        org2 = Organisation(
            organisation_id=OrganisationId("org-rolled"),
            name="Rolled",
            created_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        founder2 = Principal(
            principal_id=PrincipalId("prn-rolled"),
            organisation_id=OrganisationId("org-rolled"),
            kind=PrincipalKind.HUMAN,
            display_name="Rolled Founder",
        )

        def provision_then_fail() -> None:
            provisioner.provision(org2, founder2)
            raise RuntimeError("enclosing failure after joined provision")

        with pytest.raises(RuntimeError):
            identity_uow.run(provision_then_fail)
        assert stores.organisations.get(OrganisationId("org-rolled")) is None
        assert stores.principals.get(PrincipalId("prn-rolled")) is None

    def test_unit_of_work_requires_at_least_one_store(self) -> None:
        with pytest.raises(ValidationError, match="at least one participating store"):
            InMemoryUnitOfWork()


class TestConsistentReadRegression:
    """Regressions for V009 review F1 (ADR-023/DEF-034): multi-store reads are
    single consistent transactions — a writer's commit can never land between
    a read's constituent loads."""

    def test_torn_evidence_read_impossible(
        self, clock: TickingClock, ids: SequenceIdGenerator
    ) -> None:
        """The exact executed V009 probe as deterministic choreography: a
        reader inside evidence_for pauses between the parent load and the
        record loads; a concurrent attach_evidence MUST wait (asserted), so
        the reader's view is exactly the pre-attach state — never a mix."""
        import threading

        reader_inside = threading.Event()
        reader_release = threading.Event()
        pause_armed = threading.Event()

        class PausingEvidenceRepository(InMemoryEvidenceRepository):
            def get(self, evidence_id):  # type: ignore[no-untyped-def]
                if pause_armed.is_set():
                    reader_inside.set()
                    assert reader_release.wait(timeout=10)
                return super().get(evidence_id)

        stores = InMemoryPlatformStores()
        pausing_evidence = PausingEvidenceRepository()
        bind_serialisation_domain(pausing_evidence, domain=stores.domain)
        directory = OrganisationDirectory(
            organisations=stores.organisations,
            principals=stores.principals,
            unit_of_work=stores.identity_unit_of_work(),
            clock=clock,
            ids=ids,
        )
        provisioning = PlatformProvisioning(
            provisioner=stores.tenant_provisioner(), clock=clock, ids=ids
        )
        audit = AuditLog(
            stores.audit_sink, principals=directory, unit_of_work=stores.audit_unit_of_work()
        )
        registry = WorkObjectRegistry(
            work_objects=stores.work_objects,
            evidence=pausing_evidence,
            audit=audit,
            completion_policy=CriticalWorkEvidencePolicy(),
            principals=directory,
            unit_of_work=InMemoryUnitOfWork(
                stores.work_objects, pausing_evidence, stores.audit_sink
            ),
            clock=clock,
            ids=ids,
        )
        org, founder = provisioning.create_organisation("Read Org", "Founder", PrincipalKind.HUMAN)
        tenant = TenantContext(org.organisation_id, founder.principal_id)
        wid = _create(registry, tenant)
        first = registry.attach_evidence(
            tenant,
            wid,
            kind=EvidenceKind.DOCUMENT,
            uri="evidence/first.pdf",
            content_sha256="01",
            source_system="MANUAL",
            source_reference="r1",
        )

        observed: list[tuple[EvidenceRecord, ...]] = []
        pause_armed.set()
        reader = threading.Thread(
            target=lambda: observed.append(registry.evidence_for(tenant, wid))
        )
        reader.start()
        assert reader_inside.wait(timeout=10)

        def attach_second() -> None:
            pause_armed.clear()  # the writer's own later reads shouldn't pause
            registry.attach_evidence(
                tenant,
                wid,
                kind=EvidenceKind.DOCUMENT,
                uri="evidence/second.pdf",
                content_sha256="02",
                source_system="MANUAL",
                source_reference="r2",
            )

        writer = threading.Thread(target=attach_second)
        writer.start()
        writer.join(timeout=0.3)
        assert writer.is_alive(), "writer must wait behind the read transaction, not interleave"

        reader_release.set()
        reader.join(timeout=10)
        writer.join(timeout=10)

        # The reader saw EXACTLY the pre-attach state: one record, matching
        # the parent version it read — never the executed V009 mixed view.
        assert [r.evidence_id for r in observed[0]] == [first.evidence_id]
        assert [r.evidence_id for r in registry.evidence_for(tenant, wid)] == [
            first.evidence_id,
            registry.get(tenant, wid).evidence_ids[1],
        ]

    def test_mutation_inside_read_transaction_rejected(self) -> None:
        """Read transactions grant no mutation rights (ADR-023): a read path
        that tries to write fails mechanically at the adapter."""
        stores = InMemoryPlatformStores()
        uow = stores.unit_of_work()
        target = _model_work_object(TenantContext(OrganisationId("org-r"), PrincipalId("prn-r")))
        with pytest.raises(ValidationError, match="WRITE transaction"):
            uow.read(lambda: stores.work_objects.create(target))


class TestValidateWriteAtomicityRegression:
    """Regression for V009 review F2 (ADR-023/DEF-035): validation and write
    execute in ONE transaction — no observable point exists where the check
    has passed but the write has not begun."""

    def test_create_principal_validation_and_write_are_one_critical_section(
        self, clock: TickingClock, ids: SequenceIdGenerator
    ) -> None:
        import threading

        inside_validation = threading.Event()
        release_validation = threading.Event()
        pause_armed = threading.Event()

        class PausingPrincipalRepository(InMemoryPrincipalRepository):
            def get(self, principal_id):  # type: ignore[no-untyped-def]
                if pause_armed.is_set():
                    pause_armed.clear()
                    inside_validation.set()
                    assert release_validation.wait(timeout=10)
                return super().get(principal_id)

        pausing_principals = PausingPrincipalRepository()
        organisations = InMemoryOrganisationRepository()
        bind_serialisation_domain(organisations, pausing_principals)
        directory = OrganisationDirectory(
            organisations=organisations,
            principals=pausing_principals,
            unit_of_work=InMemoryUnitOfWork(organisations, pausing_principals),
            clock=clock,
            ids=ids,
        )
        provisioning = PlatformProvisioning(
            provisioner=InMemoryTenantProvisioner(organisations, pausing_principals),
            clock=clock,
            ids=ids,
        )
        org, founder = provisioning.create_organisation("Race Org", "Founder", PrincipalKind.HUMAN)
        tenant = TenantContext(org.organisation_id, founder.principal_id)

        created: list[Principal] = []
        pause_armed.set()
        creator = threading.Thread(
            target=lambda: created.append(
                directory.create_principal(tenant, PrincipalKind.HUMAN, "Atomic")
            )
        )
        creator.start()
        assert inside_validation.wait(timeout=10)

        # A competing transaction over the same stores must WAIT while the
        # creator sits between validation and write — the V009 TOCTOU window.
        competing_done = threading.Event()

        def competing_provision() -> None:
            try:
                provisioning.create_organisation("Late Org", "Late", PrincipalKind.HUMAN)
            finally:
                competing_done.set()

        competitor = threading.Thread(target=competing_provision)
        competitor.start()
        competitor.join(timeout=0.3)
        assert competitor.is_alive(), "competitor must be excluded from the validate→write window"

        release_validation.set()
        creator.join(timeout=10)
        competitor.join(timeout=10)
        assert created and competing_done.is_set()
        assert directory.require_member(tenant, created[0].principal_id).display_name == "Atomic"


class TestJoinedTransactionSavepointRegression:
    """Regressions for the ACTUAL V009 review F1 (ADR-024/DEF-036), reproduced
    against V010 by the V010 review: a joined operation whose failure is
    CAUGHT by the outer operation must leave zero nested effects — savepoint
    semantics. (V009/V010 committed the partial nested write: the orphan
    organisation survived.)"""

    def test_caught_joined_provision_failure_leaves_no_orphan_organisation(
        self, clock: TickingClock, ids: SequenceIdGenerator
    ) -> None:
        """The exact executed probe: seed prn-dup; outer identity UoW; nested
        provision writes org-new then fails on the duplicate founder; outer
        CATCHES and returns normally; outer commits. org-new must not exist;
        the pre-existing principal must be unchanged; outer work must survive."""
        stores = InMemoryPlatformStores()
        provisioner = stores.tenant_provisioner()
        identity_uow = stores.identity_unit_of_work()
        seeded = Principal(
            principal_id=PrincipalId("prn-dup"),
            organisation_id=OrganisationId("org-base"),
            kind=PrincipalKind.HUMAN,
            display_name="Seeded",
        )
        stores.identity_unit_of_work().run(lambda: stores.principals.add(seeded))

        outer_org = Organisation(
            organisation_id=OrganisationId("org-outer"),
            name="Outer Work",
            created_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        doomed_org = Organisation(
            organisation_id=OrganisationId("org-new"),
            name="Doomed",
            created_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        duplicate_founder = Principal(
            principal_id=PrincipalId("prn-dup"),  # collides with the seed
            organisation_id=OrganisationId("org-new"),
            kind=PrincipalKind.HUMAN,
            display_name="Duplicate",
        )
        caught: list[BaseException] = []

        def outer() -> str:
            stores.organisations.add(outer_org)  # outer work BEFORE the join
            try:
                provisioner.provision(doomed_org, duplicate_founder)
            except ValidationError as error:
                caught.append(error)  # outer catches and continues
            return "outer-ok"

        assert identity_uow.run(outer) == "outer-ok"
        assert caught and "duplicate principal id" in str(caught[0])
        # V010's executed result was `org survived? True`; savepoint fixes it:
        assert stores.organisations.get(OrganisationId("org-new")) is None
        assert stores.principals.get(PrincipalId("prn-dup")) == seeded
        # and the savepoint did NOT erase the outer transaction's own work:
        assert stores.organisations.get(OrganisationId("org-outer")) == outer_org

    def test_caught_joined_multiwrite_failure_leaves_zero_nested_effects(
        self, clock: TickingClock, ids: SequenceIdGenerator
    ) -> None:
        """Generic joined-UoW regression: nested write #1 succeeds, write #2
        raises, outer catches, outer completes — the nested operation leaves
        ZERO effects while outer writes survive."""
        stores = InMemoryPlatformStores()
        outer_uow = stores.identity_unit_of_work()
        nested_uow = InMemoryUnitOfWork(stores.organisations, stores.principals)

        outer_org = Organisation(
            organisation_id=OrganisationId("org-kept"),
            name="Kept",
            created_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        nested_org = Organisation(
            organisation_id=OrganisationId("org-nested"),
            name="Nested",
            created_at=datetime(2026, 1, 1, tzinfo=UTC),
        )

        def nested() -> None:
            stores.organisations.add(nested_org)  # write #1 lands
            raise RuntimeError("write #2 fails")  # write #2 fails

        def outer() -> str:
            stores.organisations.add(outer_org)
            with contextlib.suppress(RuntimeError):  # caught: the dangerous case
                nested_uow.run(nested)
            return "done"

        assert outer_uow.run(outer) == "done"
        assert stores.organisations.get(OrganisationId("org-nested")) is None
        assert stores.organisations.get(OrganisationId("org-kept")) == outer_org

    def test_joined_success_still_commits_with_outer(self) -> None:
        """Savepoints must not break the join contract: a SUCCESSFUL joined
        operation's writes commit with the outer transaction."""
        stores = InMemoryPlatformStores()
        outer_uow = stores.identity_unit_of_work()
        nested_uow = InMemoryUnitOfWork(stores.organisations, stores.principals)
        org = Organisation(
            organisation_id=OrganisationId("org-joined-ok"),
            name="Joined OK",
            created_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        outer_uow.run(lambda: nested_uow.run(lambda: stores.organisations.add(org)))
        assert stores.organisations.get(OrganisationId("org-joined-ok")) == org


class TestNestedScopeMutationBoundaryRegression:
    """Regressions for the V011 review F1 (ADR-025/DEF-039): the CURRENTLY
    ACTIVE transaction scope's declared store set is itself a machine-enforced
    mutation boundary. V011 authorised writes from the ambient writable
    transaction, so a nested {Organisation} scope could write a Principal the
    outer transaction covered; the nested savepoint held no Principal
    snapshot, and the write survived the outer commit (executed leak)."""

    @staticmethod
    def _organisation(org_id: str) -> Organisation:
        return Organisation(
            organisation_id=OrganisationId(org_id),
            name="Scope Test",
            created_at=datetime(2026, 1, 1, tzinfo=UTC),
        )

    @staticmethod
    def _principal(prn_id: str, org_id: str) -> Principal:
        return Principal(
            principal_id=PrincipalId(prn_id),
            organisation_id=OrganisationId(org_id),
            kind=PrincipalKind.HUMAN,
            display_name="Scope Test",
        )

    def test_nested_scope_rejects_write_to_undeclared_ancestor_covered_store(self) -> None:
        """The exact executed V011 probe: outer {Organisation, Principal};
        nested {Organisation} writes an Organisation then a Principal and the
        outer catches the failure and commits. The Principal mutation must be
        rejected AT THE WRITE (the ambient transaction covering the store is
        not authority), and neither nested effect may survive."""
        stores = InMemoryPlatformStores()
        outer_uow = stores.identity_unit_of_work()  # {Organisation, Principal}
        nested_uow = InMemoryUnitOfWork(stores.organisations)  # {Organisation} only
        nested_org = self._organisation("org-nested-scope")
        leaked = self._principal("prn-scope-leak", "org-nested-scope")
        rejections: list[BaseException] = []

        def nested() -> None:
            stores.organisations.add(nested_org)  # inside the nested savepoint
            stores.principals.add(leaked)  # NOT declared by the nested scope

        def outer() -> str:
            try:
                nested_uow.run(nested)
            except ValidationError as error:  # outer catches and continues
                rejections.append(error)
            return "outer-ok"

        assert outer_uow.run(outer) == "outer-ok"
        assert rejections and "CURRENT transaction scope" in str(rejections[0])
        # V011's executed result was `nested principal survived? True`:
        assert stores.organisations.get(OrganisationId("org-nested-scope")) is None
        assert stores.principals.get(PrincipalId("prn-scope-leak")) is None

    def test_nested_scope_leak_impossible_even_when_nested_catches_rejection(self) -> None:
        """Variant: the nested operation catches the rejection itself and
        fails later — the savepoint restores its declared writes, and the
        undeclared store was never mutated at all."""
        stores = InMemoryPlatformStores()
        outer_uow = stores.identity_unit_of_work()
        nested_uow = InMemoryUnitOfWork(stores.organisations)
        nested_org = self._organisation("org-nested-caught")
        leaked = self._principal("prn-leak-caught", "org-nested-caught")

        def nested() -> None:
            stores.organisations.add(nested_org)
            with pytest.raises(ValidationError, match="CURRENT transaction scope"):
                stores.principals.add(leaked)
            raise RuntimeError("nested fails after the rejected write")

        def outer() -> None:
            with contextlib.suppress(RuntimeError):
                nested_uow.run(nested)

        outer_uow.run(outer)
        assert stores.organisations.get(OrganisationId("org-nested-caught")) is None
        assert stores.principals.get(PrincipalId("prn-leak-caught")) is None

    def test_child_coordinator_cannot_borrow_ancestor_scope(self) -> None:
        """A second child coordinator on a store OUTSIDE the immediate parent
        scope must be rejected even though the outermost transaction covers
        that store — nested-declared ⊆ IMMEDIATE-parent-declared (ADR-025),
        not ⊆ outermost coverage. Otherwise a successful child write would
        escape a later parent-savepoint rollback."""
        stores = InMemoryPlatformStores()
        outer_uow = stores.identity_unit_of_work()  # {Organisation, Principal}
        parent_uow = InMemoryUnitOfWork(stores.organisations)  # {Organisation}
        child_uow = InMemoryUnitOfWork(stores.principals)  # outside the parent
        escapee = self._principal("prn-escape", "org-base")

        def parent() -> None:
            with pytest.raises(ValidationError, match="outside the enclosing"):
                child_uow.run(lambda: stores.principals.add(escapee))

        outer_uow.run(lambda: parent_uow.run(parent))
        assert stores.principals.get(PrincipalId("prn-escape")) is None

    def test_parent_scope_authority_restored_after_nested_exit(self) -> None:
        """Scope stack correctness: the outer transaction writes a Principal
        before AND after a nested {Organisation} join, and everything commits
        — leaving a nested scope restores the parent's full authority."""
        stores = InMemoryPlatformStores()
        outer_uow = stores.identity_unit_of_work()
        nested_uow = InMemoryUnitOfWork(stores.organisations)
        before = self._principal("prn-before", "org-base")
        after = self._principal("prn-after", "org-base")
        nested_org = self._organisation("org-inside")

        def outer() -> None:
            stores.principals.add(before)
            nested_uow.run(lambda: stores.organisations.add(nested_org))
            stores.principals.add(after)

        outer_uow.run(outer)
        assert stores.principals.get(PrincipalId("prn-before")) == before
        assert stores.organisations.get(OrganisationId("org-inside")) == nested_org
        assert stores.principals.get(PrincipalId("prn-after")) == after

    def test_base_transaction_scope_is_also_a_mutation_boundary(self) -> None:
        """No nesting required: an un-nested unit of work's snapshot set is
        exactly its declared stores, so writing any other store escapes its
        own rollback identically and is rejected at the write."""
        stores = InMemoryPlatformStores()
        base_uow = InMemoryUnitOfWork(stores.organisations)
        stray = self._principal("prn-stray", "org-base")
        with pytest.raises(ValidationError, match="CURRENT transaction scope"):
            base_uow.run(lambda: stores.principals.add(stray))
        assert stores.principals.get(PrincipalId("prn-stray")) is None

    def test_bare_critical_section_grants_no_mutation_rights(self) -> None:
        """ADR-025 closes the tooling loophole too: a bare critical section
        holds the domain lock with an EMPTY declared scope — no savepoint
        exists that could protect a write, so no write is permitted."""
        repo = InMemoryWorkObjectRepository()
        domain = bind_serialisation_domain(repo)
        with domain, pytest.raises(ValidationError, match="CURRENT transaction scope"):
            repo.create(
                _model_work_object(TenantContext(OrganisationId("org-a"), PrincipalId("prn-a")))
            )

    def test_bare_critical_section_accepts_no_coordinator_join(self) -> None:
        """A coordinator cannot join a bare section: its declared stores are
        never a subset of the empty scope, so the bare section can never
        become an ambient-permission source for nested writes."""
        stores = InMemoryPlatformStores()
        stores.domain.begin(())
        try:
            with pytest.raises(ValidationError, match="outside the enclosing"):
                stores.unit_of_work().run(lambda: None)
        finally:
            stores.domain.end()


class TestReadFrameModeRegression:
    """Regressions for the V012 review F1 (ADR-026/DEF-041): transaction MODE
    is a property of the CURRENT frame, never of the outermost lock. V012's
    joined read executed its callback directly under the ambient WRITE frame,
    so `read()` was read-only at top level but writable when nested inside a
    write transaction — the executed probe persisted an Organisation from
    inside a read callback, contradicting the UnitOfWork port contract and
    the ENFORCED RD-001 invariant."""

    @staticmethod
    def _organisation(org_id: str) -> Organisation:
        return Organisation(
            organisation_id=OrganisationId(org_id),
            name="Mode Test",
            created_at=datetime(2026, 1, 1, tzinfo=UTC),
        )

    def test_mutation_inside_read_joined_into_write_rejected(self) -> None:
        """The exact executed V012 probe: a write transaction invokes read(),
        and the read callback attempts a mutation of a store the AMBIENT
        write transaction fully covers. The mutation must be rejected and
        nothing may persist. (V012's executed result:
        MUTATION_ALLOWED_IN_NESTED_READ True.)"""
        stores = InMemoryPlatformStores()
        uow = InMemoryUnitOfWork(stores.organisations)
        org = self._organisation("org-read-leak")
        with pytest.raises(ValidationError, match="WRITE transaction"):
            uow.run(lambda: uow.read(lambda: stores.organisations.add(org)))
        assert stores.organisations.get(OrganisationId("org-read-leak")) is None

    def test_read_leak_impossible_even_when_write_operation_catches(self) -> None:
        """Variant: the write operation catches the rejection and commits
        normally — the read callback's attempted mutation still left nothing."""
        stores = InMemoryPlatformStores()
        uow = InMemoryUnitOfWork(stores.organisations)
        leaked = self._organisation("org-read-caught")
        kept = self._organisation("org-write-kept")

        def outer() -> None:
            stores.organisations.add(kept)
            with pytest.raises(ValidationError, match="WRITE transaction"):
                uow.read(lambda: stores.organisations.add(leaked))

        uow.run(outer)
        assert stores.organisations.get(OrganisationId("org-read-caught")) is None
        assert stores.organisations.get(OrganisationId("org-write-kept")) == kept

    def test_write_authority_restored_after_joined_read_exits(self) -> None:
        """Frame stack correctness: a legitimate joined read works inside a
        write transaction (observing the transaction's own uncommitted
        writes), and popping the READ frame restores the parent's WRITE
        authority for subsequent writes."""
        stores = InMemoryPlatformStores()
        uow = InMemoryUnitOfWork(stores.organisations)
        first = self._organisation("org-before-read")
        second = self._organisation("org-after-read")

        def outer() -> bool:
            stores.organisations.add(first)
            observed = uow.read(lambda: stores.organisations.get(OrganisationId("org-before-read")))
            stores.organisations.add(second)
            return observed is not None

        assert uow.run(outer) is True
        assert stores.organisations.get(OrganisationId("org-before-read")) == first
        assert stores.organisations.get(OrganisationId("org-after-read")) == second

    def test_read_scope_cannot_escalate_to_nested_write(self) -> None:
        """READ → nested WRITE is rejected at construction of the nested
        frame: a read scope confers no authority for a nested coordinator to
        begin writing (ADR-026)."""
        stores = InMemoryPlatformStores()
        uow = InMemoryUnitOfWork(stores.organisations)
        nested = InMemoryUnitOfWork(stores.organisations)
        stray = self._organisation("org-escalated")
        with pytest.raises(ValidationError, match="READ scope"):
            uow.read(lambda: nested.run(lambda: stores.organisations.add(stray)))
        assert stores.organisations.get(OrganisationId("org-escalated")) is None

    def test_nested_write_on_valid_subset_still_works_under_write(self) -> None:
        """ADR-026 must not narrow ADR-025: WRITE → nested WRITE over a valid
        subset of the immediate parent scope still commits."""
        stores = InMemoryPlatformStores()
        outer_uow = stores.identity_unit_of_work()
        inner_uow = InMemoryUnitOfWork(stores.organisations)
        org = self._organisation("org-mode-subset")
        outer_uow.run(lambda: inner_uow.run(lambda: stores.organisations.add(org)))
        assert stores.organisations.get(OrganisationId("org-mode-subset")) == org

    def test_public_mutating_operation_with_internal_reads_still_works(
        self, provisioning: PlatformProvisioning, directory: OrganisationDirectory
    ) -> None:
        """Public kernel mutating operations internally call read() from
        within their write transaction (membership validation, ADR-023);
        those joined reads must keep functioning while conferring no mutation
        authority. create_principal validates via read-wrapped lookups inside
        its identity write transaction and must still succeed end-to-end."""
        org, founder = provisioning.create_organisation(
            "Read Mode Org", "Founder", PrincipalKind.HUMAN
        )
        context = TenantContext(org.organisation_id, founder.principal_id)
        created = directory.create_principal(context, PrincipalKind.HUMAN, "Second")
        assert directory.require_member(context, created.principal_id) == created
