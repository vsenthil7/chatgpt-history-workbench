# ADR-0019 — Adapter commit-outcome model (committed / not-committed / unknown)

Status: ACCEPTED (V007) · Amends: ADR-0017 · Drives: P0-2 of the V006 review

## Context
ADR-0017 introduced `UncertainCommit` for the case where `adapter.commit()`
RETURNED an invalid receipt. But V006 still treated every *exception* from
`commit()` as a clean, side-effect-free failure. The reviewer's adapter wrote to
the external system and then raised `TimeoutError("response lost after remote
commit")`; V006 compensated the earlier commits and reported `ROLLED_BACK` while
the external effect still existed — the same false-recovery class ADR-0017 was
meant to close.

A commit attempt has three possible outcomes, and an exception does not
distinguish them:

```
committed            — receipt returned and validated
definitely NOT committed — the adapter can prove no remote write occurred
outcome UNKNOWN      — anything else (timeout, reset, interruption)
```

## Decision
The default for a failed commit is **UNKNOWN**, not "not committed".

* Any exception from `adapter.commit()` records an `UncertainCommit` (built from
  trusted request-side data) and emits `record.commit_outcome_unknown` with
  `external_effect: "uncertain"`. The proposal cannot then reach `ROLLED_BACK`.
* An adapter may raise `NoExternalEffectError` (a `CommitError` subclass) ONLY
  when it can guarantee the remote system was not modified — e.g. a
  pre-dispatch validation failure, a refused connection before send, or an
  atomic transaction that provably rolled back. That case keeps the clean,
  compensable path and `ROLLED_BACK` remains correct.

This is fail-safe: an adapter author who does nothing gets the conservative
(uncertain) treatment, and must opt in explicitly to the stronger claim.

## Consequences
* A timeout after a remote write now yields `COMPENSATION_FAILED` with an
  uncertain commit for operator reconciliation.
* Existing fixtures that modelled clean pre-dispatch failures were updated to
  raise `NoExternalEffectError`, making their (previously implicit) claim
  explicit and checkable.
* Combined with ADR-0017 and the guarded `Proposal.mark_rolled_back()`,
  `ROLLED_BACK` now means: no committed external effect is unaccounted for, on
  every path — commit, compensation and operator recovery.
