# ADR-0018 — Deep immutability and the confirmed snapshot

Status: ACCEPTED (V007) · Drives: P0-4, P1-1, P1-2 of the V006 independent review

## Context
V006 pinned *identities* but not the *structures* hanging off them. The reviewer
demonstrated three consequences:

* **P0-4** — the central product promise is "propose → human confirms → commit
  the approved content". But `Proposal.items`, `ProposalItem` and
  `ProposalItem.fields` were publicly mutable, and commit read the LIVE items.
  Confirming `approved` and then writing `NOT_APPROVED` committed the tampered
  value with `status=COMMITTED, failure=None`.
* **P1-1** — the pinned adapter descriptor's `required_fields` was a plain dict,
  so the registered contract could be rewritten after registration.
* **P1-2** — stored lineage payloads were mutable, so audit evidence
  (operator id, resolution evidence) could be rewritten after append.

The common root cause: a security or approval decision was recorded against a
container that remained writable afterwards.

## Decision
1. Introduce `FrozenMapping` in `core/primitives.py`: a deeply-immutable,
   hashable read-only mapping that recursively freezes nested mappings,
   sequences and sets, with no mutation API.
2. `AdapterDescriptor.required_fields` and `LineageEvent.payload` are frozen at
   construction.
3. Confirmation captures a `ConfirmedSnapshot`: a frozen tuple of
   `ConfirmedItem` (whose `fields` are a `FrozenMapping`) plus a canonical
   SHA-256 `content_hash` over the approved content.
4. `Proposal.commit_snapshot()` returns that snapshot ONLY after verifying that
   a snapshot rebuilt from the live confirmed items has the same
   `content_hash`; a mismatch raises `RevalidationRequiredError`.
5. Commit binds to the returned snapshot's items — it never reads the live
   mutable items.
6. Any edit (`edit_item`) or rejection clears the snapshot, so the proposal must
   be revalidated and re-confirmed, producing a NEW content hash.

## Consequences
* Post-confirmation tampering can no longer reach an adapter; the exact
  reviewer sequence now raises at commit.
* Directly writing `status`/`decision` does not fabricate a snapshot, so commit
  still refuses — confirmation cannot be bypassed by field writes.
* Lineage payload sequences are now tuples (they are frozen); payload assertions
  compare against tuples.
* Pinned descriptors are contract-stable for the life of the registration.
