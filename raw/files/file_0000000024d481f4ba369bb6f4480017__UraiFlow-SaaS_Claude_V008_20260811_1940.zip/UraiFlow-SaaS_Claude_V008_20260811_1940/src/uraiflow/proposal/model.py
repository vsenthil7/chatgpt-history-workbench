"""Proposal aggregate and state machine (ADR-0001, amended by ADR-0007;
command eligibility and atomicity per ADR-0006)."""
import hashlib
import json
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from uraiflow.core.errors import (
    InvalidTransitionError,
    RevalidationRequiredError,
    TrustBoundaryViolation,
)
from uraiflow.core.primitives import FrozenMapping, canonical_identifier, freeze_mapping
from uraiflow.extraction.model import CandidateRecord


class ProposalStatus(Enum):
    PROPOSED = "PROPOSED"
    ROUTED = "ROUTED"
    VALIDATED = "VALIDATED"
    NEEDS_CLARIFICATION = "NEEDS_CLARIFICATION"
    AWAITING_CONFIRMATION = "AWAITING_CONFIRMATION"
    CONFIRMED = "CONFIRMED"
    PARTIALLY_CONFIRMED = "PARTIALLY_CONFIRMED"
    REJECTED = "REJECTED"
    COMMITTING = "COMMITTING"
    COMMITTED = "COMMITTED"
    COMMIT_FAILED = "COMMIT_FAILED"
    COMPENSATING = "COMPENSATING"
    COMPENSATION_FAILED = "COMPENSATION_FAILED"
    ROLLED_BACK = "ROLLED_BACK"
    MANUALLY_RESOLVED = "MANUALLY_RESOLVED"


_TRANSITIONS: dict[ProposalStatus, frozenset[ProposalStatus]] = {
    ProposalStatus.PROPOSED: frozenset({ProposalStatus.ROUTED}),
    ProposalStatus.ROUTED: frozenset(
        {ProposalStatus.VALIDATED, ProposalStatus.NEEDS_CLARIFICATION}
    ),
    ProposalStatus.VALIDATED: frozenset({ProposalStatus.AWAITING_CONFIRMATION}),
    ProposalStatus.NEEDS_CLARIFICATION: frozenset(),
    ProposalStatus.AWAITING_CONFIRMATION: frozenset(
        {
            ProposalStatus.CONFIRMED,
            ProposalStatus.PARTIALLY_CONFIRMED,
            ProposalStatus.REJECTED,
        }
    ),
    ProposalStatus.CONFIRMED: frozenset({ProposalStatus.COMMITTING}),
    ProposalStatus.PARTIALLY_CONFIRMED: frozenset({ProposalStatus.COMMITTING}),
    ProposalStatus.REJECTED: frozenset(),
    ProposalStatus.COMMITTING: frozenset(
        {ProposalStatus.COMMITTED, ProposalStatus.COMMIT_FAILED}
    ),
    ProposalStatus.COMMITTED: frozenset(),
    ProposalStatus.COMMIT_FAILED: frozenset({ProposalStatus.COMPENSATING}),
    ProposalStatus.COMPENSATING: frozenset(
        {ProposalStatus.ROLLED_BACK, ProposalStatus.COMPENSATION_FAILED}
    ),
    # ADR-0013: COMPENSATION_FAILED is recoverable by an authorised operator —
    # a successful rollback retry reaches ROLLED_BACK; a manual resolution with
    # recorded evidence reaches the terminal MANUALLY_RESOLVED state.
    ProposalStatus.COMPENSATION_FAILED: frozenset(
        {ProposalStatus.ROLLED_BACK, ProposalStatus.MANUALLY_RESOLVED}
    ),
    ProposalStatus.ROLLED_BACK: frozenset(),
    ProposalStatus.MANUALLY_RESOLVED: frozenset(),
}

# ADR-0006 eligibility table: the only state in which humans may operate on content.
_COMMANDABLE = frozenset({ProposalStatus.AWAITING_CONFIRMATION})
_VALIDATABLE = frozenset(
    {ProposalStatus.ROUTED, ProposalStatus.AWAITING_CONFIRMATION}
)


class ItemDecision(Enum):
    PENDING = "PENDING"
    CONFIRMED = "CONFIRMED"
    REJECTED = "REJECTED"


@dataclass
class ProposalItem:
    """One candidate record inside a proposal plus its human decision state."""

    record_id: str
    record_type: str
    fields: dict[str, Any]
    confidence: float
    source_text: str
    decision: ItemDecision = field(default=ItemDecision.PENDING)
    validation_errors: tuple[str, ...] = field(default=())

    @classmethod
    def from_candidate(cls, candidate: CandidateRecord) -> "ProposalItem":
        return cls(
            record_id=candidate.record_id,
            record_type=candidate.record_type,
            fields=dict(candidate.fields),
            confidence=candidate.confidence,
            source_text=candidate.source_text,
        )

    def as_candidate(self) -> CandidateRecord:
        return CandidateRecord(
            record_id=self.record_id,
            record_type=self.record_type,
            fields=dict(self.fields),
            confidence=self.confidence,
            source_text=self.source_text,
        )


@dataclass(frozen=True)
class ConfirmedItem:
    """A deeply-immutable snapshot of one confirmed record (ADR-0018, V007
    P0-4). Its ``fields`` are frozen so the approved content cannot be mutated
    after confirmation."""

    record_id: str
    record_type: str
    fields: FrozenMapping
    source_text: str

    def as_candidate(self) -> CandidateRecord:
        return CandidateRecord(
            record_id=self.record_id,
            record_type=self.record_type,
            fields=dict(self.fields),
            confidence=1.0,  # confirmed content is authoritative
            source_text=self.source_text,
        )


@dataclass(frozen=True)
class ConfirmedSnapshot:
    """The exact human-approved content, captured at confirmation time and used
    verbatim at commit (ADR-0018, V007 P0-4).

    ``content_hash`` is a canonical hash of the confirmed items; it versions the
    approval so that a later re-confirmation (after an edit) produces a
    different hash. Commit binds to THIS snapshot, never to the live mutable
    proposal items, so post-confirmation tampering cannot reach the adapter.
    """

    items: tuple[ConfirmedItem, ...]
    content_hash: str

    @staticmethod
    def _hash_items(items: tuple[ConfirmedItem, ...]) -> str:
        payload = [
            {
                "record_id": i.record_id,
                "record_type": i.record_type,
                "fields": {k: i.fields[k] for k in sorted(i.fields)},
                "source_text": i.source_text,
            }
            for i in items
        ]
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    @classmethod
    def build(cls, items: Iterable["ProposalItem"]) -> "ConfirmedSnapshot":
        frozen = tuple(
            ConfirmedItem(
                record_id=i.record_id,
                record_type=i.record_type,
                fields=freeze_mapping(i.fields),
                source_text=i.source_text,
            )
            for i in items
        )
        return cls(items=frozen, content_hash=cls._hash_items(frozen))


@dataclass
class Proposal:
    """The reviewable unit UraiFlow offers to the human before any commit.

    All content-mutating operations are aggregate commands that validate state
    eligibility and argument validity *before* any mutation (ADR-0006); a failed
    command leaves the aggregate logically unchanged.
    """

    proposal_id: str
    tenant_id: str
    capture_id: str
    transcript_id: str
    items: list[ProposalItem]
    status: ProposalStatus = field(default=ProposalStatus.PROPOSED)
    needs_revalidation: bool = field(default=False)
    # ADR-0013: validated receipts whose rollback failed; structured evidence
    # for operator recovery (never reconstructed from lineage text). Typed as a
    # tuple of adapter CommitReceipt objects; kept opaque to the aggregate.
    unrecovered_receipts: tuple[Any, ...] = field(default=())
    # ADR-0018 (V007 P0-4): the exact human-approved content, captured at
    # confirmation. Commit binds to this snapshot, not the live mutable items,
    # and any post-confirmation edit clears it (forcing reconfirmation).
    confirmed_snapshot: Any = field(default=None)
    # ADR-0013/§P0-1: operations whose external side effect may have occurred
    # but whose receipt could not be trusted (invalid receipt). These are
    # NOT trusted commit evidence; they mark the aggregate as un-reconcilable
    # so it can never falsely reach ROLLED_BACK.
    uncertain_commits: tuple[Any, ...] = field(default=())

    # ADR-0015: aggregate IDENTITY is immutable and canonical; aggregate STATE
    # (items, status, decisions) is mutable. Identity fields are canonicalised
    # once at construction and are write-once thereafter, so tenant ownership
    # cannot be reassigned by mutating the field (the V005 P0-3 exploit).
    _IDENTITY_FIELDS = ("proposal_id", "tenant_id", "capture_id", "transcript_id")

    def __post_init__(self) -> None:
        for name in self._IDENTITY_FIELDS:
            object.__setattr__(
                self, name,
                canonical_identifier(getattr(self, name), field=name),
            )
        object.__setattr__(self, "_identity_frozen", True)

    def __setattr__(self, name: str, value: Any) -> None:
        if name in self._IDENTITY_FIELDS and getattr(
            self, "_identity_frozen", False
        ):
            raise TrustBoundaryViolation(
                f"proposal identity field '{name}' is immutable (ADR-0015); "
                f"tenant/aggregate ownership cannot be reassigned after creation"
            )
        object.__setattr__(self, name, value)

    # -- state machine --

    def advance(self, to: ProposalStatus) -> None:
        if to not in _TRANSITIONS[self.status]:
            raise InvalidTransitionError(
                f"proposal {self.proposal_id}: {self.status.value} -> {to.value} not allowed"
            )
        self.status = to

    def _require_commandable(self, command: str) -> None:
        if self.status not in _COMMANDABLE:
            raise InvalidTransitionError(
                f"proposal {self.proposal_id}: {command} not allowed in "
                f"state {self.status.value}"
            )

    def _require_ready_to_confirm(self, to_confirm: Iterable[ProposalItem]) -> None:
        if self.needs_revalidation:
            raise RevalidationRequiredError(
                f"proposal {self.proposal_id} was edited and must be revalidated "
                "before confirmation"
            )
        invalid = [i.record_id for i in to_confirm if i.validation_errors]
        if invalid:
            raise InvalidTransitionError(
                f"proposal {self.proposal_id}: items {invalid} have validation "
                "errors and cannot be confirmed"
            )

    def _items_by_id(self, record_ids: Iterable[str]) -> list[ProposalItem]:
        index = {item.record_id: item for item in self.items}
        wanted = list(record_ids)
        unknown = [record_id for record_id in wanted if record_id not in index]
        if unknown:
            raise KeyError(
                f"proposal {self.proposal_id} has no items {unknown}"
            )
        return [index[record_id] for record_id in wanted]

    # -- aggregate commands (ADR-0006) --

    def confirm_all(self) -> None:
        self._require_commandable("confirm_all")
        self._require_ready_to_confirm(self.items)
        for item in self.items:
            item.decision = ItemDecision.CONFIRMED
        self._capture_confirmed_snapshot()
        self.advance(ProposalStatus.CONFIRMED)

    def confirm_selected(self, record_ids: Iterable[str]) -> None:
        self._require_commandable("confirm_selected")
        selected = self._items_by_id(record_ids)
        self._require_ready_to_confirm(selected)
        selected_ids = {item.record_id for item in selected}
        for item in self.items:
            item.decision = (
                ItemDecision.CONFIRMED
                if item.record_id in selected_ids
                else ItemDecision.REJECTED
            )
        self._capture_confirmed_snapshot()
        if len(selected_ids) == len(self.items):
            self.advance(ProposalStatus.CONFIRMED)
        elif selected_ids:
            self.advance(ProposalStatus.PARTIALLY_CONFIRMED)
        else:
            self.advance(ProposalStatus.REJECTED)

    def _capture_confirmed_snapshot(self) -> None:
        """Freeze the exact confirmed content (ADR-0018, V007 P0-4)."""
        confirmed = tuple(
            i for i in self.items if i.decision is ItemDecision.CONFIRMED
        )
        object.__setattr__(
            self, "confirmed_snapshot", ConfirmedSnapshot.build(confirmed)
        )

    def reject_all(self) -> None:
        self._require_commandable("reject_all")
        for item in self.items:
            item.decision = ItemDecision.REJECTED
        object.__setattr__(self, "confirmed_snapshot", None)
        self.advance(ProposalStatus.REJECTED)

    def edit_item(self, record_id: str, fields: Mapping[str, Any]) -> None:
        self._require_commandable("edit_item")
        (item,) = self._items_by_id([record_id])
        item.fields = dict(fields)
        item.validation_errors = ()
        self.needs_revalidation = True
        # ADR-0018 (V007 P0-4): editing content invalidates any confirmation;
        # the proposal must be revalidated and re-confirmed, producing a new
        # snapshot hash.
        object.__setattr__(self, "confirmed_snapshot", None)

    def apply_validation(self, results: Mapping[str, tuple[str, ...]]) -> None:
        """Record adapter contract-validation results (pipeline-only entry point)."""
        if self.status not in _VALIDATABLE:
            raise InvalidTransitionError(
                f"proposal {self.proposal_id}: validation results not applicable "
                f"in state {self.status.value}"
            )
        for item in self.items:
            item.validation_errors = tuple(results.get(item.record_id, ()))
        self.needs_revalidation = False

    def confirmed_items(self) -> tuple[ProposalItem, ...]:
        return tuple(i for i in self.items if i.decision is ItemDecision.CONFIRMED)

    def commit_snapshot(self) -> "ConfirmedSnapshot":
        """Return the confirmed snapshot to commit, after verifying the live
        items still match it (ADR-0018, V007 P0-4).

        Commit MUST use the returned snapshot's content, never the live mutable
        items. If the live confirmed content no longer matches the snapshot
        hash — i.e. the items were tampered with after confirmation — this
        raises, forcing revalidation/reconfirmation rather than committing
        unapproved content.
        """
        snapshot = self.confirmed_snapshot
        if snapshot is None:
            raise RevalidationRequiredError(
                f"proposal {self.proposal_id} has no confirmed snapshot; it must "
                f"be confirmed before commit"
            )
        live = ConfirmedSnapshot.build(self.confirmed_items())
        if live.content_hash != snapshot.content_hash:
            raise RevalidationRequiredError(
                f"proposal {self.proposal_id}: confirmed content changed after "
                f"confirmation (snapshot {snapshot.content_hash[:12]} != live "
                f"{live.content_hash[:12]}); revalidation and reconfirmation "
                f"are required before commit"
            )
        return snapshot

    def mark_rolled_back(self) -> None:
        """Guarded terminal transition to ROLLED_BACK (ADR-0017, V007 P0-1).

        The aggregate itself makes ROLLED_BACK impossible while ANY external
        effect remains unaccounted for: neither unrecovered receipts nor
        uncertain commits may exist. This closes the recovery-path hole where a
        service cleared to ROLLED_BACK by checking only unrecovered_receipts.
        """
        if self.unrecovered_receipts:
            raise InvalidTransitionError(
                f"proposal {self.proposal_id}: cannot mark ROLLED_BACK while "
                f"{len(self.unrecovered_receipts)} unrecovered receipt(s) remain"
            )
        if self.uncertain_commits:
            raise InvalidTransitionError(
                f"proposal {self.proposal_id}: cannot mark ROLLED_BACK while "
                f"{len(self.uncertain_commits)} uncertain commit(s) remain "
                f"unreconciled"
            )
        self.advance(ProposalStatus.ROLLED_BACK)

    # -- compensation recovery bookkeeping (ADR-0013; pipeline/recovery only) --

    def record_unrecovered(self, receipts: tuple[Any, ...]) -> None:
        """Record the receipts left unrecovered by a failed compensation."""
        if self.status is not ProposalStatus.COMPENSATION_FAILED:
            raise InvalidTransitionError(
                f"proposal {self.proposal_id}: unrecovered receipts only apply "
                f"to COMPENSATION_FAILED, not {self.status.value}"
            )
        self.unrecovered_receipts = tuple(receipts)

    def record_uncertain(self, uncertain: tuple[Any, ...]) -> None:
        """Record operations whose external effect may have occurred but whose
        receipt was untrusted (ADR-0017). Only valid in COMPENSATION_FAILED —
        an uncertain commit is by definition unreconciled."""
        if self.status is not ProposalStatus.COMPENSATION_FAILED:
            raise InvalidTransitionError(
                f"proposal {self.proposal_id}: uncertain commits only apply "
                f"to COMPENSATION_FAILED, not {self.status.value}"
            )
        self.uncertain_commits = tuple(uncertain)
