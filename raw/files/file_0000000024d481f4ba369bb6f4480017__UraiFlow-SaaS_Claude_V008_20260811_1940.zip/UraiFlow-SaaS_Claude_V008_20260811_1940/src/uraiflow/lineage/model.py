"""Immutable lineage/audit events — the cross-aggregate evidence chain.

Linkage contract (ADR-0008): aggregates are linked by id references inside event
payloads (e.g. ``proposal.created`` carries ``capture_id`` and ``transcript_id``);
this payload-reference model is canonical and test-enforced.

ADR-0014 (extended in V006 for P1-1): a LineageEvent is a trust-boundary
structure. Its identity fields (``event_id``, ``tenant_id``, ``subject_id``,
``kind``) are canonicalised to exact built-in ``str`` at construction, so a
hostile ``str`` subclass cannot make one event match an unrelated subject or
tenant via spoofed equality once stored.
"""
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from uraiflow.core.primitives import canonical_identifier, freeze_mapping


@dataclass(frozen=True)
class LineageEvent:
    """One append-only fact about a subject, scoped to a tenant."""

    event_id: str
    tenant_id: str
    subject_id: str
    kind: str
    payload: Mapping[str, Any]
    occurred_at: datetime

    def __post_init__(self) -> None:
        for name in ("event_id", "tenant_id", "subject_id", "kind"):
            object.__setattr__(
                self, name,
                canonical_identifier(getattr(self, name), field=f"lineage {name}"),
            )
        if not isinstance(self.occurred_at, datetime):
            raise TypeError(
                f"lineage occurred_at must be a datetime; got "
                f"{type(self.occurred_at).__name__}"
            )
        # ADR-0018 (V007 P1-2): the audit payload is deeply frozen so stored
        # operator/evidence values cannot be rewritten after append or read.
        object.__setattr__(self, "payload", freeze_mapping(self.payload))
