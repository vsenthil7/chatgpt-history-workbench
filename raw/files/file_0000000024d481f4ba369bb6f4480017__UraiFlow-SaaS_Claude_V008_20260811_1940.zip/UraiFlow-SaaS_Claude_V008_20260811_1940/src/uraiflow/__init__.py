"""UraiFlow — reusable conversation-to-structured-action SaaS core.

Boundary: UraiFlow proposes; the owning domain validates and commits.
"""
__version__ = "0.13.0.dev0"
