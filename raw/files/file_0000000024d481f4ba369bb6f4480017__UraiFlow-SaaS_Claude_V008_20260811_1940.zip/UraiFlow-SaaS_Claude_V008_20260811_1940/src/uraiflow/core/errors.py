"""Domain error taxonomy shared across UraiFlow modules."""


class UraiFlowError(Exception):
    """Base class for all UraiFlow domain errors."""


class TrustBoundaryViolation(UraiFlowError, ValueError):
    """A security-relevant value crossed a trust boundary in non-canonical
    form (e.g. a hostile str subclass, a duck-typed impostor object, or an
    empty identifier). Also a ValueError: it reports an invalid value at
    construction/validation time (ADR-0014)."""


class TenantIsolationError(UraiFlowError):
    """An operation attempted to cross a tenant boundary."""


class InvalidTransitionError(UraiFlowError):
    """A state machine transition was not permitted."""


class RoutingError(UraiFlowError):
    """No (or ambiguous) route/provider exists for a request."""


class AdapterContractError(UraiFlowError):
    """A target-system adapter was used outside its declared contract."""


class CommitError(UraiFlowError):
    """A target-system commit failed at the adapter."""


class NoExternalEffectError(CommitError):
    """An adapter raised this to PROVE a failed commit produced NO external
    side effect (ADR-0019, V007 P0-2).

    The commit path treats any OTHER exception from ``adapter.commit()`` as an
    UNKNOWN outcome (the external effect may have happened) and records an
    UncertainCommit. An adapter may raise ``NoExternalEffectError`` ONLY when it
    can guarantee the remote system was not modified (e.g. a pre-dispatch
    validation failure, or an atomic transaction that provably rolled back), in
    which case the operation is safely compensable/rollbackable as before.
    """


class RevalidationRequiredError(UraiFlowError):
    """A proposal was edited and must be revalidated before confirmation."""


class AuthorizationError(UraiFlowError):
    """The acting principal is not authorised for a protected operation."""
