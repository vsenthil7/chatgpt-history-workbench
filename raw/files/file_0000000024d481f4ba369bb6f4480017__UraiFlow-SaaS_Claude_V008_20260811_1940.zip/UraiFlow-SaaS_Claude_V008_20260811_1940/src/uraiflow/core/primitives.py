"""Canonical exact-type primitives at trust boundaries (ADR-0014).

The V004 independent review demonstrated that identifier comparison, hashing
and set membership can be spoofed by hostile ``str`` subclasses overriding
``__eq__``/``__ne__``/``__hash__``/``strip``. Every identity value that
participates in a security-relevant decision (tenant isolation, adapter
resolution, receipt binding, operator authorisation, lineage scoping) must
therefore be canonicalised to an EXACT built-in ``str`` before it is stored or
compared — subclasses are rejected outright, benign or not, because
"benign" cannot be established from inside the type.

The exact-type test uses ``type(value) is str`` and runs BEFORE any method of
the incoming object is invoked, so a hostile object gets no code execution on
the comparison path.
"""
from collections.abc import Iterator, Mapping
from typing import Any

from uraiflow.core.errors import TrustBoundaryViolation


def canonical_identifier(value: object, *, field: str) -> str:
    """Return *value* as a canonical plain ``str`` identifier.

    Raises :class:`TrustBoundaryViolation` when *value* is not an exact
    built-in ``str`` (subclasses included) or is empty/whitespace-only.
    The returned value is whitespace-stripped and guaranteed to be of exact
    type ``str``, safe for ``==``, ``hash()`` and dict/set membership.
    """
    if type(value) is not str:  # exact type; NEVER isinstance (ADR-0014 §2)
        raise TrustBoundaryViolation(
            f"{field} must be an exact built-in str; got "
            f"{type(value).__name__} (str subclasses are rejected at trust "
            f"boundaries)"
        )
    cleaned = value.strip()
    if not cleaned:
        raise TrustBoundaryViolation(f"{field} must be a non-empty identifier")
    return cleaned


def require_exact_type(value: object, expected: type, *, boundary: str) -> None:
    """Reject objects that are not exactly *expected* at a trust boundary.

    Duck-typed impostors (and subclasses) of security-bearing structures such
    as ``TenantContext`` or ``CommitReceipt`` must not be accepted where the
    genuine, canonicalising type is required.
    """
    if type(value) is not expected:
        raise TrustBoundaryViolation(
            f"{boundary} requires an exact {expected.__name__}; got "
            f"{type(value).__name__}"
        )


class FrozenMapping(Mapping[str, Any]):
    """A deeply-immutable, hashable read-only mapping (ADR-0018, V007 P0-4/P1-1).

    Trust-boundary structures (pinned adapter descriptors, confirmed proposal
    snapshots, lineage payloads) must not expose a mutable container that a
    caller can rewrite after the security decision was made. ``FrozenMapping``
    copies its input, recursively freezes nested mappings and list/tuple
    values, and offers no mutation API. It is hashable so snapshots can be
    versioned by content hash.
    """

    __slots__ = ("_data", "_hash")

    _data: dict[str, Any]
    _hash: int | None

    def __init__(self, data: Mapping[str, Any]) -> None:
        frozen: dict[str, Any] = {}
        for key, value in data.items():
            frozen[key] = _freeze_value(value)
        object.__setattr__(self, "_data", frozen)
        object.__setattr__(self, "_hash", None)

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __iter__(self) -> "Iterator[str]":
        return iter(self._data)

    def __len__(self) -> int:
        return len(self._data)

    def __hash__(self) -> int:
        if self._hash is None:
            computed = hash(tuple(sorted((k, self._data[k]) for k in self._data)))
            object.__setattr__(self, "_hash", computed)
            return computed
        return self._hash

    def __repr__(self) -> str:
        return f"FrozenMapping({dict(self._data)!r})"


def _freeze_value(value: Any) -> Any:
    """Recursively convert a value into an immutable, hashable form."""
    if isinstance(value, FrozenMapping):
        return value
    if isinstance(value, Mapping):
        return FrozenMapping(value)
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_value(item) for item in value)
    if isinstance(value, (set, frozenset)):
        return frozenset(_freeze_value(item) for item in value)
    return value


def freeze_mapping(data: Mapping[str, Any]) -> FrozenMapping:
    """Return *data* as a deeply-immutable :class:`FrozenMapping`."""
    return FrozenMapping(data)
