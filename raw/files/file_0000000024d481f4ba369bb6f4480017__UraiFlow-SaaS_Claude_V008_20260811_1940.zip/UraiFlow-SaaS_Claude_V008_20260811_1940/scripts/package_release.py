#!/usr/bin/env python3
"""Deterministic release packager + external attestation (ADR-0012; V003
review P0-4/P0-5/P0-6). Packaging is executable policy, not prose.

Pipeline (single controlled operation):
 1. construct the payload from an explicit governed allowlist policy;
 2. reject any excluded/unexpected material (fail-closed);
 3. regenerate the manifest over the exact frozen payload;
 4. validate the complete manifest contract (scripts/gen_manifest.py --check);
 5. build a deterministic ZIP (sorted entries, fixed timestamps/permissions);
 6. rebuild from the same frozen payload and prove byte-identical output;
 7. compute the final ZIP SHA-256 — the ZIP is never modified afterwards;
 8. extract that exact ZIP into a fresh location, create a clean venv,
    install the artifact into it, and run the smoke suite from that venv;
 9. emit UraiFlow-SaaS_Claude_<version>_ATTESTATION.md OUTSIDE the ZIP,
    binding every verification result to the final ZIP SHA-256.

Usage: python scripts/package_release.py --version V004 [--out DIR]
"""
import argparse
import hashlib
import json
import platform
import re
import shutil
import subprocess
import sys
import zipfile
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# ---- governed payload policy (ADR-0012 §2) ----------------------------------
# Explicit allowlist of top-level payload entries. Anything else at top level
# is unexpected and fails packaging.
ALLOWED_TOP_LEVEL = {
    "00-control", "01-product", "02-architecture", "03-engineering",
    "04-testing", "05-quality", "06-traceability", "07-planning", "08-ai",
    "09-governance", "10-baseline", "evidence", "scripts", "src", "tests",
    "BUILD-REPORT-V002.md", "BUILD-REPORT-V003.md", "BUILD-REPORT-V004.md",
    "BUILD-REPORT-V005.md", "BUILD-REPORT-V006.md", "BUILD-REPORT-V007.md",
    "CLAUDE.md", "PACKAGE-MANIFEST.json", "pyproject.toml", "setup.cfg",
}
# Generated/build/test material that must never enter a release payload.
EXCLUDED_NAMES = {
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".coverage",
    "build", "dist", ".tox", ".nox",  # standard build artefact directories
    ".mutmut-cache", ".venv", "venv", ".git", ".hypothesis", ".DS_Store",
}
REPORT_NAME = "BUILD-REPORT-V007.md"
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}

# ---- RECURSIVE governed payload policy (ADR-0012 §1, V008 UF-V007-B1-002) ---
# Top-level approval alone is NOT a governed allowlist: it permits anything
# recursively underneath an approved directory unless a denylist happens to
# catch it (the reviewer shipped `src/customer-secrets.env` through the V007
# packager this way). Every payload file must now match an EXPLICIT rule for
# its governed area; anything unmatched aborts packaging fail-closed.
#
# Each entry maps an approved top-level directory to the set of file suffixes
# governed for that area. Adding a new file KIND to a release is therefore a
# deliberate policy change here, reviewable in the diff.
PAYLOAD_POLICY: dict[str, set[str]] = {
    "00-control": {".md"},
    "01-product": {".md"},
    "02-architecture": {".md"},
    "03-engineering": {".md"},
    "04-testing": {".md"},
    "05-quality": {".md"},
    "06-traceability": {".md"},
    "07-planning": {".md"},
    "08-ai": {".md"},
    "09-governance": {".md"},
    # preserved historical baseline material (input, not executable authority)
    "10-baseline": {".md", ".json", ".html", ".css"},
    "evidence": {".txt", ".json"},
    "scripts": {".py"},
    "src": {".py"},
    "tests": {".py"},
}
# Defence in depth only — a denylist can never substitute for the policy above.
# These name fragments are refused even inside an otherwise governed suffix.
SECRET_NAME_PATTERNS = (
    ".env", "secret", "credential", "password", "passwd", "token",
    "private-key", "privatekey", "id_rsa", ".pem", ".pfx", ".p12", ".keystore",
)


def classify_payload_file(rel: Path) -> str | None:
    """Return None if *rel* is governed for the payload, else the reason it is
    refused. Fail-closed: anything not explicitly matched is refused."""
    parts = rel.parts
    lowered = rel.name.lower()
    for pattern in SECRET_NAME_PATTERNS:
        if pattern in lowered:
            return f"matches a prohibited secret-like name pattern '{pattern}'"
    if len(parts) == 1:
        # top-level file: must be named exactly in the allowlist
        if rel.name in ALLOWED_TOP_LEVEL:
            return None
        return "is an ungoverned top-level file"
    area = parts[0]
    if area not in PAYLOAD_POLICY:
        return f"is inside '{area}', which governs no file types"
    allowed = PAYLOAD_POLICY[area]
    if rel.suffix not in allowed:
        return (
            f"has suffix '{rel.suffix or '(none)'}' which is not governed for "
            f"'{area}' (governed: {', '.join(sorted(allowed))})"
        )
    return None


# Self-referential gate-run evidence: these record the RESULT of checking the
# manifest / summarise the gate run that ENDS with manifest generation, so they
# cannot be inside the manifest they attest (V006 P1-2). They are per-run
# artifacts, not part of the release payload — excluding them keeps the shipped
# ZIP fully manifest-consistent (no untracked files, the P0-4 invariant). The
# gate results are still attested by this ZIP's SHA-256 in the external
# attestation, and remain in the working tree's evidence/ for local inspection.
EXCLUDED_PAYLOAD_FILES = {
    Path("evidence/G01-manifest-check.txt"),
    Path("evidence/release-gates-summary.json"),
}


def _is_excluded(rel: Path) -> bool:
    if any(part in EXCLUDED_NAMES for part in rel.parts):
        return True
    if rel.suffix in EXCLUDED_SUFFIXES:
        return True
    if rel in EXCLUDED_PAYLOAD_FILES:
        return True
    # egg-info directories are build products at ANY depth (pip install -e
    # places src/<pkg>.egg-info; the V004 packager originally checked only the
    # first path component and shipped it untracked — the exact P0-4 shape)
    return any(part.endswith(".egg-info") for part in rel.parts)


def _run(cmd, cwd, env=None):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True,
                          check=False, env=env)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_payload(source: Path, payload: Path) -> list[Path]:
    """Copy the governed payload; fail on unexpected top-level material."""
    unexpected = sorted(
        entry.name for entry in source.iterdir()
        if entry.name not in ALLOWED_TOP_LEVEL
        and entry.name not in EXCLUDED_NAMES
        and not entry.name.endswith(".egg-info")
        and not (entry.name.startswith("UraiFlow-SaaS_Claude_")  # prior artifacts
                 and (entry.suffix == ".zip" or "ATTESTATION" in entry.name))
        and entry.name != "dist"
    )
    if unexpected:
        raise SystemExit(
            f"packaging policy violation: unexpected top-level entries "
            f"{unexpected} (extend ALLOWED_TOP_LEVEL deliberately or remove)"
        )
    files: list[Path] = []
    refused: list[str] = []
    for entry in sorted(source.rglob("*")):
        rel = entry.relative_to(source)
        if rel.parts[0] not in ALLOWED_TOP_LEVEL:
            continue
        if _is_excluded(rel):
            continue
        if entry.is_file():
            # RECURSIVE governed check (UF-V007-B1-002): being under an
            # approved directory is NOT sufficient — the file must match an
            # explicit rule for its area, or packaging aborts.
            reason = classify_payload_file(rel)
            if reason is not None:
                refused.append(f"{rel}: {reason}")
                continue
            destination = payload / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(entry, destination)
            files.append(rel)
    if refused:
        raise SystemExit(
            "packaging policy violation: ungoverned file(s) inside approved "
            "directories — the payload allowlist is recursive and fail-closed. "
            "Either govern the file type in PAYLOAD_POLICY deliberately, or "
            "remove the file:\n  " + "\n  ".join(refused)
        )
    return files


def verify_payload_clean(payload: Path) -> None:
    """Fail-closed proof that no excluded material entered the payload."""
    dirty = sorted(
        str(p.relative_to(payload))
        for p in payload.rglob("*")
        if _is_excluded(p.relative_to(payload))
    )
    if dirty:
        raise SystemExit(f"payload contains excluded material: {dirty[:20]}")


def deterministic_zip(payload: Path, zip_path: Path, arcroot: str) -> str:
    """Deterministic ZIP: sorted entries, fixed timestamp, fixed permissions."""
    fixed_time = (2026, 1, 1, 0, 0, 0)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(payload.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(payload)
            info = zipfile.ZipInfo(f"{arcroot}/{rel.as_posix()}", date_time=fixed_time)
            info.external_attr = 0o644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
    return _sha256(zip_path)


# Executed inside the clean venv: proves the artifact imports from its INSTALLED
# location with no PYTHONPATH, and that dist metadata agrees with the package.
_INSTALLED_IMPORT_PROBE = (
    "import os, uraiflow, importlib.metadata as md;"
    "assert not os.environ.get('PYTHONPATH'), 'PYTHONPATH is set';"
    "assert 'site-packages' in uraiflow.__file__, uraiflow.__file__;"
    "assert md.version('uraiflow') == uraiflow.__version__;"
    "print('installed', uraiflow.__version__, uraiflow.__file__)"
)


def verify_release_handoff(out_dir: Path) -> list[str]:
    """G12 release-handoff gate (UF-V007-B1-001).

    A release handoff is the PAIR of artifacts required by
    `09-governance/RELEASE-PROCEDURE.md` and ADR-0012 §3:

        <release>.zip
        <release>_ATTESTATION.md

    Returns a list of problems (empty when the handoff is complete and the
    SHA-256 recorded in the attestation equals the hash of the actual ZIP
    bytes). The manifest deliberately cannot hash itself, so this pairing is
    the ONLY thing binding the complete final artifact — shipping the ZIP
    without its attestation leaves the release chain unverifiable.
    """
    problems: list[str] = []
    zips = sorted(out_dir.glob("*.zip"))
    attestations = sorted(out_dir.glob("*_ATTESTATION.md"))
    if not zips:
        problems.append("release handoff is missing the .zip artifact")
    if not attestations:
        problems.append(
            "release handoff is missing the external _ATTESTATION.md artifact")
    if problems:
        return problems
    for zip_path in zips:
        expected_name = f"{zip_path.stem}_ATTESTATION.md"
        matching = [a for a in attestations if a.name == expected_name]
        if not matching:
            problems.append(
                f"no attestation named '{expected_name}' accompanies "
                f"'{zip_path.name}'")
            continue
        recorded = re.findall(r"[0-9a-f]{64}", matching[0].read_text("utf-8"))
        actual = _sha256(zip_path)
        if not recorded:
            problems.append(
                f"attestation '{matching[0].name}' records no SHA-256")
        elif actual not in recorded:
            problems.append(
                f"SHA-256 disagreement for '{zip_path.name}': actual bytes "
                f"hash to {actual}, which the attestation does not record")
    return problems


def smoke_extracted(zip_path: Path, workdir: Path) -> dict:
    """Extract the EXACT final ZIP into a fresh directory, create a CLEAN
    virtual environment, INSTALL the artifact into it, and run the canonical
    gates from that environment (ADR-0009; UF-V007-B1-003).

    The previous design ran the gates against the source tree with
    ``PYTHONPATH=src`` and the builder's interpreter. That could certify a ZIP
    that is not independently installable: broken packaging metadata, missing
    runtime dependency declarations, or modules available only on the builder's
    machine would all pass. The artifact must prove it installs and imports
    with ``PYTHONPATH`` UNSET.
    """
    extract_dir = workdir / "smoke-extract"
    if extract_dir.exists():
        shutil.rmtree(extract_dir)
    extract_dir.mkdir(parents=True)
    with zipfile.ZipFile(zip_path) as archive:
        archive.extractall(extract_dir)
    (tree,) = [p for p in extract_dir.iterdir() if p.is_dir()]

    venv_dir = workdir / "smoke-venv"
    if venv_dir.exists():
        shutil.rmtree(venv_dir)
    steps: dict = {}

    # A deliberately minimal environment: no PYTHONPATH, so nothing can be
    # imported from the source tree by accident.
    base_env = {"PATH": "/usr/bin:/bin:/usr/local/bin", "HOME": str(workdir)}

    def record(name: str, command: str, result) -> None:
        steps[name] = {
            "command": command,
            "exit_code": result.returncode,
            "tail": (result.stdout + result.stderr).strip().splitlines()[-1:],
        }
        if result.returncode != 0:
            raise SystemExit(
                f"extracted-ZIP smoke step '{name}' failed "
                f"(exit {result.returncode}):\n"
                f"{(result.stdout + result.stderr)[-2000:]}"
            )

    # 1. fresh virtual environment
    record("venv_create",
           f"{sys.executable} -m venv {venv_dir.name}",
           _run([sys.executable, "-m", "venv", str(venv_dir)],
                cwd=workdir, env=base_env))
    vpy = venv_dir / "bin" / "python"

    # 2. governed build/review dependencies only
    record("install_build_deps",
           f"{vpy.name} -m pip install setuptools wheel pytest",
           _run([str(vpy), "-m", "pip", "install", "-q",
                 "setuptools", "wheel", "pytest"], cwd=workdir, env=base_env))

    # 3. install the EXTRACTED ARTIFACT itself. The build backend writes
    #    `build/` and `*.egg-info` into its source directory, so we install
    #    from a COPY: the tree the integrity gates run against must remain
    #    byte-identical to the shipped payload.
    install_src = workdir / "smoke-install-src"
    if install_src.exists():
        shutil.rmtree(install_src)
    shutil.copytree(tree, install_src)
    record("install_artifact",
           f"{vpy.name} -m pip install --no-build-isolation .  "
           f"(from a copy of the extracted artifact)",
           _run([str(vpy), "-m", "pip", "install", "-q",
                 "--no-build-isolation", "."], cwd=install_src, env=base_env))
    shutil.rmtree(install_src)

    # 4. the artifact must import from the INSTALLED location with no
    #    PYTHONPATH, and report matching metadata
    record("installed_import_without_pythonpath",
           f"{vpy.name} -c \"import uraiflow; ...\"  (PYTHONPATH unset)",
           _run([str(vpy), "-c", _INSTALLED_IMPORT_PROBE],
                cwd=workdir, env=base_env))

    # 5. canonical gates, run from the extracted tree using the INSTALLED
    #    environment (still no PYTHONPATH)
    for name, cmd in (
        ("pytest", [str(vpy), "-m", "pytest", "-p", "no:cacheprovider"]),
        ("starter_validator", [str(vpy), "scripts/validate_starter.py"]),
        ("manifest_check", [str(vpy), "scripts/gen_manifest.py", "--check"]),
        # V007 P0-5: the mandatory documentation gates must be reproducible
        # from the EXACT shipped artifact. The packager FAILS if either fails.
        ("G09_rtm", [str(vpy), "scripts/validate_rtm.py"]),
        ("G10_docs_consistency",
         [str(vpy), "scripts/validate_docs_consistency.py"]),
    ):
        record(name, " ".join([vpy.name, *cmd[1:]]),
               _run(cmd, cwd=tree, env=base_env))

    steps["_environment"] = {
        "builder_python": sys.version.split()[0],
        "venv_python": str(vpy),
        "pythonpath": "UNSET (artifact installed, not source-imported)",
    }
    shutil.rmtree(extract_dir)
    shutil.rmtree(venv_dir)
    return steps


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", required=True, help="e.g. V004")
    parser.add_argument("--out", default=str(ROOT / "dist"))
    args = parser.parse_args()

    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M")
    base = f"UraiFlow-SaaS_Claude_{args.version}_{stamp}"
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    workdir = out / "work"
    if workdir.exists():
        shutil.rmtree(workdir)
    payload = workdir / "payload" / base
    payload.mkdir(parents=True)

    print("1/9 constructing governed payload...")
    build_payload(ROOT, payload)
    print("2/9 verifying payload cleanliness (fail-closed)...")
    verify_payload_clean(payload)

    print("3/9 regenerating manifest over the exact payload...")
    # V007 P0-5: the build report's manifest fact is derived by RUNNING the
    # check, so it must be regenerated INSIDE the payload — otherwise the report
    # carries the working tree's transient value and G10 fails on clean
    # extraction (the exact V006 defect). Report and manifest are mutually
    # dependent (the report records manifest status; the manifest covers the
    # report), so we iterate to a fixed point: regenerate the report, regenerate
    # the manifest, repeat until the report stops changing.
    for _ in range(4):
        before = (payload / REPORT_NAME).read_text(encoding="utf-8")
        # manifest FIRST so the report's live check sees a payload whose only
        # possible drift is the report itself
        gen = _run([sys.executable, "scripts/gen_manifest.py"], cwd=payload)
        if gen.returncode != 0:
            raise SystemExit(f"manifest generation failed: {gen.stderr}")
        rep = _run([sys.executable, "scripts/gen_build_report.py"], cwd=payload)
        if rep.returncode != 0:
            raise SystemExit(f"build report regeneration failed: {rep.stderr}")
        # regenerate the manifest again to cover the (possibly rewritten) report
        gen = _run([sys.executable, "scripts/gen_manifest.py"], cwd=payload)
        if gen.returncode != 0:
            raise SystemExit(f"manifest generation failed: {gen.stderr}")
        if (payload / REPORT_NAME).read_text(encoding="utf-8") == before:
            break
    else:
        raise SystemExit(
            "build report / manifest did not converge to a fixed point; "
            "the report's machine facts keep changing across regeneration"
        )
    print("4/9 validating complete manifest contract...")
    chk = _run([sys.executable, "scripts/gen_manifest.py", "--check"], cwd=payload)
    if chk.returncode != 0:
        raise SystemExit(f"manifest contract check failed:\n{chk.stdout}{chk.stderr}")
    manifest = json.loads((payload / "PACKAGE-MANIFEST.json").read_text())

    print("5/9 building deterministic ZIP...")
    zip_path = out / f"{base}.zip"
    sha_first = deterministic_zip(payload, zip_path, base)
    print("6/9 rebuilding from frozen payload; proving byte-identical output...")
    rebuild_path = workdir / f"{base}.rebuild.zip"
    sha_second = deterministic_zip(payload, rebuild_path, base)
    if sha_first != sha_second:
        raise SystemExit(
            f"non-deterministic build: {sha_first} != {sha_second}"
        )
    rebuild_path.unlink()

    print(f"7/9 final ZIP SHA-256: {sha_first} (ZIP is now frozen)")
    print("8/9 extracting the exact final ZIP and running smoke...")
    smoke = smoke_extracted(zip_path, workdir)
    sha_after_smoke = _sha256(zip_path)
    if sha_after_smoke != sha_first:
        raise SystemExit("ZIP was modified after its hash was calculated")

    print("9/9 writing external attestation...")
    payload_count = sum(1 for p in payload.rglob("*") if p.is_file())
    if payload_count != manifest["file_count"] + 1:  # +1 = the manifest itself
        on_disk = {str(p.relative_to(payload))
                   for p in payload.rglob("*") if p.is_file()}
        covered = {e["path"] for e in manifest["files"]} | {"PACKAGE-MANIFEST.json"}
        raise SystemExit(
            "packaging integrity violation: payload/manifest count mismatch; "
            f"untracked in payload: {sorted(on_disk - covered)[:20]}; "
            f"missing from payload: {sorted(covered - on_disk)[:20]}"
        )
    tool_versions = {}
    for tool in ("pytest", "ruff", "mypy"):
        result = _run([sys.executable, "-m", tool, "--version"], cwd=ROOT)
        tool_versions[tool] = (result.stdout + result.stderr).strip().splitlines()[0]
    # mutmut has no --version flag; read installed metadata instead
    from importlib.metadata import version as _pkg_version
    tool_versions["mutmut"] = f"mutmut {_pkg_version('mutmut')}"
    attestation_path = out / f"{base}_ATTESTATION.md"
    now = datetime.now(UTC).isoformat(timespec="seconds")
    smoke_env = smoke.pop("_environment", {})
    smoke_lines = "\n".join(
        f"| {name} | `{info['command']}` | {info['exit_code']} | "
        f"{' '.join(info['tail'])} |"
        for name, info in smoke.items()
    )
    smoke_lines += (
        f"\n\n**Clean-environment verification (ADR-0009, UF-V007-B1-003):** the "
        f"exact final ZIP was extracted to a fresh directory, a NEW virtual "
        f"environment was created, and the artifact was INSTALLED into it with "
        f"`pip install`. Every gate above ran from that installed environment "
        f"with `PYTHONPATH` **{smoke_env.get('pythonpath', 'UNSET')}** — the "
        f"artifact is proven independently installable and importable, not "
        f"merely runnable from its own source tree. "
        f"Builder Python {smoke_env.get('builder_python', '?')}; "
        f"venv interpreter `{smoke_env.get('venv_python', '?')}`."
    )
    attestation_path.write_text(f"""# UraiFlow Release Attestation — {base}

This attestation is generated by `scripts/package_release.py` (ADR-0012) and
lives OUTSIDE the ZIP so the complete final artifact is hash-attested without
self-reference. **All results below were executed over the artifact whose
SHA-256 is stated, not a candidate/build tree.**

## Artifact identity
| Field | Value |
|---|---|
| ZIP filename | `{base}.zip` |
| **Final ZIP SHA-256** | `{sha_first}` |
| Product version | `{manifest["product_version"]}` |
| Build timestamp (UTC) | `{now}` |
| Payload file count (on disk) | {payload_count} |
| Manifest-covered file count | {manifest["file_count"]} + PACKAGE-MANIFEST.json itself |
| Unexpected/excluded payload files | 0 (fail-closed policy verified) |

## Deterministic rebuild

**Scope of this claim (V007 P2-3):** determinism here means *same frozen
payload → byte-identical ZIP*. The ZIP itself uses fixed entry order,
timestamps and permissions, so re-zipping the identical payload always
reproduces this hash. It does NOT mean a later end-to-end run of
`package_release.py` reproduces this hash: such a run regenerates evidence and
report timestamps, changing the payload and therefore the hash. To verify this
artifact, hash the received ZIP and compare with the value below.
| Build | SHA-256 |
|---|---|
| First build | `{sha_first}` |
| Second build (same frozen payload) | `{sha_second}` |
| Byte-identical | {"YES" if sha_first == sha_second else "NO"} |
| ZIP unmodified after hashing | YES (re-hashed post-smoke: `{sha_after_smoke}`) |

## Exact packaging command
```
python scripts/package_release.py --version {args.version}
```

## Clean-extraction smoke over the final ZIP (SHA-256 `{sha_first[:16]}…`)

Each command below was executed with the working directory set to the extracted
package root (the single top-level directory inside the ZIP), using a CLEAN
virtual environment into which this exact artifact was installed. ``PYTHONPATH``
was left UNSET throughout, so nothing is imported from the source tree — a
reviewer can reproduce each step verbatim from a clean extraction:
create a venv, ``pip install setuptools wheel pytest``, ``pip install
--no-build-isolation .`` from the extracted root, then run the commands below.

| Step | Command | Exit | Result tail |
|---|---|---|---|
{smoke_lines}

## Environment
| Component | Version |
|---|---|
| Python | {platform.python_version()} ({platform.system()} {platform.machine()}) |
| pytest | {tool_versions["pytest"]} |
| ruff | {tool_versions["ruff"]} |
| mypy | {tool_versions["mypy"]} |
| mutmut | {tool_versions["mutmut"]} |

## Gate evidence references (inside the ZIP, manifest-protected)
- Manifest contract: full-contract `gen_manifest.py --check` above (the
  self-referential `evidence/G01-manifest-check.txt` and
  `evidence/release-gates-summary.json` are deliberately NOT shipped — they
  record the result of checking the manifest, so they live in the working tree
  only; this ZIP's SHA-256 is their attestation, V006 P1-2)
- Tests/coverage: `evidence/G03-tests.txt`, `evidence/G04-coverage.txt`
- Static: `evidence/G02-ruff.txt`, `evidence/G02-mypy.txt`
- Contracts/architecture/tenant: `evidence/G05-contracts.txt`, `evidence/G06-architecture.txt`, `evidence/G08-tenant-security.txt`
- Mutation (fail-closed): `evidence/G07-mutation.json`, `evidence/G07-mutation-summary.txt`
- RTM: `evidence/G09-rtm.txt` · Docs consistency: `evidence/G10-docs-consistency.txt`
- Packaging/smoke (this document): `G11` — the attestation itself is the G11 evidence
""", encoding="utf-8")
    shutil.rmtree(workdir)
    # G12 (UF-V007-B1-001): a release is the verified PAIR. Refuse to report
    # success unless both artifacts exist and the attestation's recorded
    # SHA-256 equals the hash of the actual ZIP bytes.
    handoff_problems = verify_release_handoff(out)
    if handoff_problems:
        raise SystemExit(
            "release handoff verification (G12) failed:\n  "
            + "\n  ".join(handoff_problems))
    print("G12 handoff: PASS — zip + attestation present, recorded SHA-256 "
          "matches the actual ZIP bytes")
    print(f"DONE\n  zip:         {zip_path}\n  attestation: {attestation_path}\n"
          f"  sha256:      {sha_first}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
