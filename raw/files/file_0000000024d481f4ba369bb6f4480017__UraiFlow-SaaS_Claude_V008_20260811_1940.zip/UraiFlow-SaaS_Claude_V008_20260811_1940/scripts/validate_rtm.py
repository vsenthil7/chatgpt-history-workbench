#!/usr/bin/env python3
"""G09 — machine RTM completeness validator (ADR-0012 §5; V003 review P1-1,
V004 review P0-4/P1-1).

Validates the current RTM (06-traceability/RTM-V007.md):
 * requirement IDs are unique;
 * statuses come from the governed vocabulary;
 * every ENFORCED row references at least one existing test/gate/evidence
   artifact;
 * every ``tests/<file>.py::test_name`` reference resolves to a real test
   function IN THAT EXACT FILE (V004 review P0-4: a name that exists only in a
   different file is NOT resolvable);
 * bare, unqualified ``::test_name`` references (no file) are rejected;
 * every referenced ``evidence/`` artifact exists (same-run outputs excepted);
 * every referenced ADR exists in 02-architecture/adr.

The evidence line reports the count of rows actually validated (V004 review
P1-1: it must never say "0 data rows checked" for a populated RTM).

Evidence: evidence/G09-rtm.txt (and exit code).
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RTM = ROOT / "06-traceability" / "RTM-V007.md"
ADR_DIR = ROOT / "02-architecture" / "adr"
EVIDENCE = ROOT / "evidence"
VALID_STATUSES = {"ENFORCED", "ACTIVE", "PLANNED", "SUPERSEDED"}
SAME_RUN_OUTPUTS = {
    "evidence/G01-manifest-check.txt",
    "evidence/G09-rtm.txt",
    "evidence/G10-docs-consistency.txt",
    "evidence/release-gates-summary.json",
}

_ROW = re.compile(r"^\|\s*(?P<id>[A-Z]{2,5}-[0-9.]+[a-z]?(?:\s*\[[^\]]+\])?)\s*\|")


def _test_functions() -> dict[str, set[str]]:
    functions: dict[str, set[str]] = {}
    for test_file in sorted((ROOT / "tests").glob("test_*.py")):
        text = test_file.read_text()
        names = set(re.findall(r"^def (test_\w+)", text, re.MULTILINE))
        names |= set(re.findall(r"^    def (test_\w+)", text, re.MULTILINE))
        functions[f"tests/{test_file.name}"] = names
    return functions


def _parse_rows(text: str) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    for line in text.splitlines():
        match = _ROW.match(line)
        if match and not match.group("id").startswith("ID"):
            rows.append((match.group("id").split("[")[0].strip(), line))
    return rows


def validate() -> tuple[list[str], int]:
    problems: list[str] = []
    if not RTM.is_file():
        return [f"RTM file missing: {RTM}"], 0
    text = RTM.read_text(encoding="utf-8")
    functions = _test_functions()

    rows = _parse_rows(text)
    if not rows:
        return ["no requirement rows found in RTM"], 0

    seen: set[str] = set()
    for row_id, line in rows:
        if row_id in seen:
            problems.append(f"duplicate requirement ID: {row_id}")
        seen.add(row_id)
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        status = cells[-1]
        if status not in VALID_STATUSES:
            problems.append(f"{row_id}: invalid status {status!r}")

        # References are only recognised inside backticked code spans, so that
        # descriptive prose mentioning a format like `file.py::test_name` in the
        # requirement text is never treated as a (broken) reference. Concatenate
        # the backticked spans of the row and scan those.
        code_spans = " ".join(re.findall(r"`([^`]*)`", line))

        # Fully-qualified references resolve as a (file, test) pair. Accept an
        # optional pytest class segment: tests/x.py::TestClass::test_name.
        qualified = set(
            re.findall(
                r"(tests/test_\w+\.py)::(?:[A-Za-z_]\w*::)?(test_\w+)", code_spans
            )
        )
        bare_files = set(re.findall(r"tests/test_\w+\.py(?!::)", code_spans))
        # A ::test_name is "bare" only if not preceded by a .py file or a
        # ClassName (i.e. not part of a file.py::Class::test node id). Strip all
        # resolved node ids first, then look for any leftover ::test_name.
        stripped = re.sub(
            r"tests/test_\w+\.py::(?:[A-Za-z_]\w*::)?test_\w+", "", code_spans
        )
        bare_names = set(re.findall(r"::(test_\w+)", stripped))
        evidence_refs = set(
            re.findall(r"evidence/[A-Za-z0-9._-]+\.(?:txt|json|md)", code_spans)
        )
        adr_refs = set(re.findall(r"ADR-\d{4}", line))

        referenced_files = {f for f, _ in qualified} | bare_files
        for test_file in referenced_files:
            if test_file not in functions:
                problems.append(
                    f"{row_id}: referenced test file missing: {test_file}"
                )
        for test_file, test_name in qualified:
            if test_file in functions and test_name not in functions[test_file]:
                problems.append(
                    f"{row_id}: {test_name} does not exist in {test_file} "
                    f"(exact file::test resolution)"
                )
        for test_name in bare_names:
            problems.append(
                f"{row_id}: under-specified test reference '::{test_name}' "
                f"(must be tests/<file>.py::{test_name})"
            )
        for ref in evidence_refs:
            if ref in SAME_RUN_OUTPUTS:
                continue
            if not (ROOT / ref.rstrip(".,;")).is_file():
                problems.append(f"{row_id}: referenced evidence missing: {ref}")
        for adr in adr_refs:
            if not list(ADR_DIR.glob(f"{adr}-*.md")):
                problems.append(f"{row_id}: referenced ADR does not exist: {adr}")

        if status == "ENFORCED" and not (
            referenced_files or qualified or evidence_refs
            or "scripts/" in line or "pyproject" in line
        ):
            problems.append(
                f"{row_id}: ENFORCED but references no test/gate/evidence artifact"
            )
    return problems, len(rows)


def main() -> int:
    problems, row_count = validate()
    EVIDENCE.mkdir(exist_ok=True)
    if problems:
        report = "G09 RTM FAIL:\n" + "\n".join(f" - {p}" for p in problems) + "\n"
        (EVIDENCE / "G09-rtm.txt").write_text(report, encoding="utf-8")
        print(report, file=sys.stderr)
        return 1
    try:
        shown = RTM.relative_to(ROOT)
    except ValueError:
        shown = RTM
    report = (
        f"G09 RTM PASS: {shown} — all requirement rows have "
        f"unique IDs, governed statuses, and resolvable test/evidence/ADR "
        f"references ({row_count} data rows checked)\n"
    )
    (EVIDENCE / "G09-rtm.txt").write_text(report, encoding="utf-8")
    print(report.strip())
    return 0


if __name__ == "__main__":
    sys.exit(main())
