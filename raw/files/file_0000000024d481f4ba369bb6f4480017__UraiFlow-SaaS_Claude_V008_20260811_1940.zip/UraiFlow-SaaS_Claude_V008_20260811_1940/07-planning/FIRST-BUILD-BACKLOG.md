# First Build Backlog

## B001 — Baseline acceptance
- Read all starter documents and the complete preserved baseline.
- Inventory contradictions/duplicates/stale names before deleting anything.
- Record architecture decisions rather than silently normalising history.

## B002 — Declare the first implementation slice
Preserve the proposal/confirmation boundary and build the first production-grade vertical slice: input → transcript/provider abstraction → structured proposal → confirmation → adapter contract, with full lineage.

## B003 — Tests first as contracts
Declare RTM rows, contract tests and architecture/tenant guards before implementation. Establish red evidence, then implement to green.

## B004 — Evidence-producing CI
Make test counts, coverage, mutation, package inventory and docs consistency machine-readable so narrative docs do not drift.

## B005 — Review package
Create the next `<Product>_Claude_VNNN_YYYYMMDD_HHMM.zip` with complete source/tests/docs/evidence for independent ChatGPT review.

---

## Status after V002 (Claude build, 2026-08-08)
- **B001 — DONE.** `00-control/B001-BASELINE-ACCEPTANCE.md` (inventory I-01…I-05); nothing deleted from baseline.
- **B002 — DONE.** Slice declared via ADR-0001…0004 + RTM-V002 SLICE-001…007, then implemented in `src/uraiflow/`.
- **B003 — DONE.** Red state recorded (`evidence/B003-red-state.txt`) before implementation; green + coverage evidence in `evidence/B003-green-tests-coverage.txt`.
- **B004 — PARTIAL.** Test/coverage/manifest evidence machine-generated; mutation gate deferred (EX-001); no CI pipeline definition yet.
- **B005 — DONE for V002.** This ZIP is the review package.

## V003 backlog (next)
1. Mutation testing gate (QA-002/G07): wire mutmut or equivalent, set threshold, triage survivors. **← exact next item**
2. NEEDS_CLARIFICATION re-clarification loop (currently terminal per ADR-0001).
3. Persistence adapter behind LineageStore/proposal repository protocols (still in-memory).
4. CI pipeline definition executing gates G01–G11.
5. First real transcription provider adapter behind `TranscriptionProvider` (benchmark plan in baseline doc 34).

---

## Status after V003 (Claude corrective build, 2026-08-08)
V003 was the architecture/invariant-hardening release driven by the ChatGPT V002 deep
review. All P0 findings (P0-1..P0-9) FIXED; P1-1..P1-6 FIXED (P1-2 evidenced by the
extracted-ZIP smoke test in the build report). Dispositions: `BUILD-REPORT-V003.md`.
- Domain boundary repaired (ADR-0005): generic rule engine in core; workforce rules are a fixture.
- Proposal invariants aggregate-owned and atomic (ADR-0006).
- Commit/compensation hardened: exception normalisation, COMPENSATING/COMPENSATION_FAILED, rollback preflight, registry descriptor validation (ADR-0007).
- Lineage payload-reference model formalised; `parent_event_id` removed (ADR-0008).
- Installable packaging, canonical gate runner, release sequencing (ADR-0009).
- Mutation gate live (`scripts/run_mutation_gate.py`): 0 logic survivors required; survivors individually verified and dispositioned.

## V004 backlog (recommended order)
1. **COMPENSATION_FAILED operator recovery workflow** — currently terminal; define retry/manual-resolution commands, evidence and authorization. **← exact next item**
2. NEEDS_CLARIFICATION recovery loop (re-extraction / human clarification back to AWAITING_CONFIRMATION).
3. Persistence adapters behind LineageStore/proposal repository protocols (still in-memory).
4. CI pipeline definition executing run_gates + mutation gate + packaging/smoke automatically (G11 automation).
5. First real transcription provider adapter behind `TranscriptionProvider` (baseline doc 34 benchmark plan); extraction schema configuration surface for tenants (building on ADR-0005).

## V004 (this iteration) — release-integrity hardening
Executed per the V003 independent review: P0-1..P0-6 and P1-1..P1-6 all
dispositioned (see `BUILD-REPORT-V007.md`). COMPENSATION_FAILED operator
recovery implemented on structured unrecovered receipts (ADR-0013).

## V005 candidates (in recommended order)
1. NEEDS_CLARIFICATION recovery workflow.
2. Persistence (durable proposal/lineage store behind current contracts).
3. CI orchestration of release gates + packaging.
4. Real transcription provider + tenant extraction configuration.
5. Role-based operator authorisation for recovery.
