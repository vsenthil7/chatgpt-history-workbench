"""RTM: SLICE-005..007, INV-005..008, CMP-001..003 — confirmation service,
end-to-end slice, edit/revalidation lifecycle (ADR-0006), adapter-boundary error
normalisation, governed compensation and rollback preflight (ADR-0007)."""
from datetime import UTC, datetime

import pytest
from fixtures.workforce_rules import REQUIRED_FIELDS, build_extractor

from uraiflow.adapters.inmemory import InMemoryTargetAdapter
from uraiflow.confirmation.service import ConfirmationService
from uraiflow.core.clock import FixedClock
from uraiflow.core.errors import (
    AdapterContractError,
    InvalidTransitionError,
    NoExternalEffectError,
    RevalidationRequiredError,
    TenantIsolationError,
)
from uraiflow.core.tenancy import TenantContext
from uraiflow.lineage.store import LineageStore
from uraiflow.pipeline.orchestrator import ConversationToActionPipeline
from uraiflow.proposal.model import ProposalStatus
from uraiflow.routing.registry import AdapterRegistry
from uraiflow.transcription.provider import DeterministicEchoProvider
from uraiflow.transcription.selector import ProviderSelector

T0 = datetime(2026, 8, 8, 12, 0, tzinfo=UTC)
CTX_A = TenantContext(tenant_id="tenant-a", actor_id="user-1")
CTX_B = TenantContext(tenant_id="tenant-b", actor_id="user-2")
SAMPLE = (
    "I spoke to Auditor for 20 minutes, follow up on Monday, "
    "and tomorrow I am available ten to one."
)


class DomainFailingAdapter(InMemoryTargetAdapter):
    """Fails commit BEFORE any external write, proving no side effect occurred
    (raises NoExternalEffectError so the outcome is a clean, compensable
    failure — ADR-0019, V007 P0-2)."""

    def commit(self, ctx, record, idempotency_key):
        raise NoExternalEffectError(f"{self.descriptor().name}: simulated outage")


class InfraFailingAdapter(InMemoryTargetAdapter):
    """Fails commit BEFORE dispatch with an infrastructure error but proves no
    remote write happened (ADR-0019). A bare exception without this proof would
    correctly be treated as an UNKNOWN outcome; this fixture models the
    provably-clean case."""

    def commit(self, ctx, record, idempotency_key):
        raise NoExternalEffectError("target system unreachable before dispatch")


class UnknownOutcomeAdapter(InMemoryTargetAdapter):
    """Performs the external write, then raises a generic exception so the
    outcome is UNKNOWN (ADR-0019, V007 P0-2): the remote system may have
    committed. Must yield COMPENSATION_FAILED with an uncertain commit."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.effects: list[str] = []

    def commit(self, ctx, record, idempotency_key):
        self.effects.append(record.record_id)
        raise TimeoutError("response lost after remote commit")


class RollbackFailingAdapter(InMemoryTargetAdapter):
    """Commits fine but rollback explodes with an SDK-style error (P0-7)."""

    def rollback(self, ctx, receipt):
        raise ConnectionError("rollback connection reset")


def _build(main_cls=InMemoryTargetAdapter, follow_cls=InMemoryTargetAdapter,
           main_rollback=True):
    lineage = LineageStore()
    clock = FixedClock(T0)
    registry = AdapterRegistry()
    main = main_cls(
        name="target-main",
        schema_version="1.0",
        required_fields={k: REQUIRED_FIELDS[k] for k in ("time_entry", "availability")},
        supports_rollback=main_rollback,
    )
    follow = follow_cls(
        name="target-follow",
        schema_version="1.0",
        required_fields={"follow_up": REQUIRED_FIELDS["follow_up"]},
    )
    registry.register(main)
    registry.register(follow)
    selector = ProviderSelector(
        providers={"echo": DeterministicEchoProvider("echo")},
        tenant_policy={},
        default_provider="echo",
    )
    pipeline = ConversationToActionPipeline(
        selector=selector,
        extractor=build_extractor(),
        registry=registry,
        lineage=lineage,
        clock=clock,
    )
    confirmation = ConfirmationService(lineage=lineage, clock=clock)
    return pipeline, confirmation, lineage, main, follow


# ---------------- ingest ----------------

def test_ingest_produces_awaiting_confirmation_proposal():
    pipeline, _, lineage, _, _ = _build()
    proposal = pipeline.ingest(CTX_A, source_ref="call-1", content=SAMPLE)
    assert proposal.status is ProposalStatus.AWAITING_CONFIRMATION
    assert sorted(i.record_type for i in proposal.items) == [
        "availability", "follow_up", "time_entry",
    ]
    kinds = [e.kind for e in lineage.for_subject(CTX_A, proposal.proposal_id)]
    assert kinds == ["proposal.created", "proposal.routed", "proposal.validated"]


def test_ingest_without_candidates_goes_to_needs_clarification():
    pipeline, _, lineage, _, _ = _build()
    proposal = pipeline.ingest(CTX_A, source_ref="call-2", content="nice weather today")
    assert proposal.status is ProposalStatus.NEEDS_CLARIFICATION
    kinds = [e.kind for e in lineage.for_subject(CTX_A, proposal.proposal_id)]
    assert kinds == ["proposal.created", "proposal.needs_clarification"]


def test_ingest_with_invalid_candidate_goes_to_needs_clarification():
    lineage = LineageStore()
    clock = FixedClock(T0)
    registry = AdapterRegistry()
    registry.register(
        InMemoryTargetAdapter(
            name="strict",
            schema_version="1.0",
            required_fields={
                "follow_up": ("note", "owner"),
                "time_entry": REQUIRED_FIELDS["time_entry"],
                "availability": REQUIRED_FIELDS["availability"],
            },
        )
    )
    pipeline = ConversationToActionPipeline(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={},
            default_provider="echo",
        ),
        extractor=build_extractor(),
        registry=registry,
        lineage=lineage,
        clock=clock,
    )
    proposal = pipeline.ingest(CTX_A, source_ref="call-3", content="please follow up")
    assert proposal.status is ProposalStatus.NEEDS_CLARIFICATION
    assert proposal.items[0].validation_errors != ()


# ---------------- confirmation service ----------------

def test_confirm_all_and_commit_end_to_end_with_lineage():
    pipeline, confirmation, lineage, main, follow = _build()
    proposal = pipeline.ingest(CTX_A, source_ref="call-4", content=SAMPLE)
    confirmation.confirm_all(CTX_A, proposal)
    assert proposal.status is ProposalStatus.CONFIRMED
    outcome = pipeline.commit(CTX_A, proposal)
    assert proposal.status is ProposalStatus.COMMITTED
    assert len(outcome.receipts) == 3 and outcome.failure is None
    assert main.committed_count(CTX_A) == 2
    assert follow.committed_count(CTX_A) == 1
    kinds = [e.kind for e in lineage.for_subject(CTX_A, proposal.proposal_id)]
    assert kinds[-1] == "proposal.committed"
    assert kinds.count("record.committed") == 3


def test_confirm_selected_commits_only_selected():
    pipeline, confirmation, _, _, follow = _build()
    proposal = pipeline.ingest(CTX_A, source_ref="call-5", content=SAMPLE)
    keep = [i.record_id for i in proposal.items if i.record_type == "time_entry"]
    confirmation.confirm_selected(CTX_A, proposal, keep)
    assert proposal.status is ProposalStatus.PARTIALLY_CONFIRMED
    outcome = pipeline.commit(CTX_A, proposal)
    assert len(outcome.receipts) == 1
    assert follow.committed_count(CTX_A) == 0


def test_reject_all_is_terminal_and_uncommittable():
    pipeline, confirmation, _, _, _ = _build()
    proposal = pipeline.ingest(CTX_A, source_ref="call-6", content=SAMPLE)
    confirmation.reject_all(CTX_A, proposal)
    assert proposal.status is ProposalStatus.REJECTED
    with pytest.raises(InvalidTransitionError):
        pipeline.commit(CTX_A, proposal)


def test_service_confirm_on_rejected_proposal_fails_without_mutation():
    pipeline, confirmation, _, _, _ = _build()
    proposal = pipeline.ingest(CTX_A, source_ref="call-6b", content=SAMPLE)
    confirmation.reject_all(CTX_A, proposal)
    decisions_before = [i.decision for i in proposal.items]
    with pytest.raises(InvalidTransitionError):
        confirmation.confirm_all(CTX_A, proposal)
    assert [i.decision for i in proposal.items] == decisions_before
    assert proposal.status is ProposalStatus.REJECTED


def test_confirmation_denies_foreign_tenant():
    pipeline, confirmation, _, _, _ = _build()
    proposal = pipeline.ingest(CTX_A, source_ref="call-8", content=SAMPLE)
    with pytest.raises(TenantIsolationError):
        confirmation.confirm_all(CTX_B, proposal)


def test_commit_denies_foreign_tenant():
    pipeline, confirmation, _, _, _ = _build()
    proposal = pipeline.ingest(CTX_A, source_ref="call-9", content=SAMPLE)
    confirmation.confirm_all(CTX_A, proposal)
    with pytest.raises(TenantIsolationError):
        pipeline.commit(CTX_B, proposal)


# ---------------- edit / revalidation lifecycle (ADR-0006) ----------------

def test_edit_blocks_confirmation_until_revalidated():
    pipeline, confirmation, lineage, main, _ = _build()
    proposal = pipeline.ingest(CTX_A, source_ref="call-7", content=SAMPLE)
    target = next(i for i in proposal.items if i.record_type == "time_entry")
    confirmation.edit(CTX_A, proposal, target.record_id, {"contact": "Auditor", "minutes": 25})
    with pytest.raises(RevalidationRequiredError):
        confirmation.confirm_selected(CTX_A, proposal, [target.record_id])
    pipeline.revalidate(CTX_A, proposal)
    confirmation.confirm_selected(CTX_A, proposal, [target.record_id])
    pipeline.commit(CTX_A, proposal)
    stored = main.stored_record(CTX_A, f"{proposal.proposal_id}:{target.record_id}")
    assert stored.fields["minutes"] == 25
    kinds = [e.kind for e in lineage.for_subject(CTX_A, proposal.proposal_id)]
    assert "proposal.item_edited" in kinds and "proposal.revalidated" in kinds


def test_invalid_edit_cannot_be_confirmed_after_revalidation():
    pipeline, confirmation, _, _, _ = _build()
    proposal = pipeline.ingest(CTX_A, source_ref="call-7b", content=SAMPLE)
    target = next(i for i in proposal.items if i.record_type == "time_entry")
    confirmation.edit(CTX_A, proposal, target.record_id, {"contact": "", "minutes": 25})
    pipeline.revalidate(CTX_A, proposal)
    assert proposal.status is ProposalStatus.AWAITING_CONFIRMATION
    with pytest.raises(InvalidTransitionError):
        confirmation.confirm_selected(CTX_A, proposal, [target.record_id])
    others = [i.record_id for i in proposal.items if i.record_id != target.record_id]
    confirmation.confirm_selected(CTX_A, proposal, others)
    assert proposal.status is ProposalStatus.PARTIALLY_CONFIRMED


def test_revalidate_denies_foreign_tenant():
    pipeline, _confirmation, _, _, _ = _build()
    proposal = pipeline.ingest(CTX_A, source_ref="call-7c", content=SAMPLE)
    with pytest.raises(TenantIsolationError):
        pipeline.revalidate(CTX_B, proposal)


# ---------------- commit hardening (ADR-0007) ----------------

def test_domain_failure_compensates_and_rolls_back():
    pipeline, confirmation, lineage, main, _ = _build(follow_cls=DomainFailingAdapter)
    proposal = pipeline.ingest(CTX_A, source_ref="call-10", content=SAMPLE)
    confirmation.confirm_all(CTX_A, proposal)
    outcome = pipeline.commit(CTX_A, proposal)
    assert proposal.status is ProposalStatus.ROLLED_BACK
    assert outcome.receipts == () and outcome.compensation_failures == ()
    assert "simulated outage" in outcome.failure
    assert main.committed_count(CTX_A) == 0
    kinds = [e.kind for e in lineage.for_subject(CTX_A, proposal.proposal_id)]
    assert "proposal.commit_failed" in kinds
    assert "proposal.compensating" in kinds
    assert kinds[-1] == "proposal.rolled_back"


def test_infrastructure_exception_is_normalised_and_compensated():
    pipeline, confirmation, _lineage, main, _ = _build(follow_cls=InfraFailingAdapter)
    proposal = pipeline.ingest(CTX_A, source_ref="call-11", content=SAMPLE)
    confirmation.confirm_all(CTX_A, proposal)
    outcome = pipeline.commit(CTX_A, proposal)
    assert proposal.status is ProposalStatus.ROLLED_BACK  # proven no side effect
    assert "NoExternalEffectError" in outcome.failure
    assert main.committed_count(CTX_A) == 0


def test_exception_after_remote_side_effect_is_recorded_as_uncertain():
    """V007 P0-2: a generic exception AFTER the external write is an UNKNOWN
    outcome; the proposal must reach COMPENSATION_FAILED with an uncertain
    commit, never a false ROLLED_BACK."""
    pipeline, confirmation, _lineage, _main, follow = _build(
        follow_cls=UnknownOutcomeAdapter
    )
    proposal = pipeline.ingest(CTX_A, source_ref="call-11b", content=SAMPLE)
    confirmation.confirm_all(CTX_A, proposal)
    outcome = pipeline.commit(CTX_A, proposal)
    assert follow.effects != []  # the external write happened
    assert proposal.status is ProposalStatus.COMPENSATION_FAILED
    assert proposal.status is not ProposalStatus.ROLLED_BACK
    assert outcome.recovery is not None
    assert outcome.recovery.uncertain_commits != ()
    assert proposal.uncertain_commits == outcome.recovery.uncertain_commits


def test_rollback_failure_yields_compensation_failed_with_evidence():
    pipeline, confirmation, lineage, main, _ = _build(
        main_cls=RollbackFailingAdapter, follow_cls=InfraFailingAdapter
    )
    proposal = pipeline.ingest(CTX_A, source_ref="call-12", content=SAMPLE)
    confirmation.confirm_all(CTX_A, proposal)
    outcome = pipeline.commit(CTX_A, proposal)
    assert proposal.status is ProposalStatus.COMPENSATION_FAILED
    assert outcome.receipts == ()
    assert outcome.failure is not None
    # commit order is proposal order: time_entry (commits) -> follow_up (fails);
    # exactly one committed record then requires compensation, and its rollback fails.
    assert len(outcome.compensation_failures) == 1
    assert "ConnectionError" in outcome.compensation_failures[0]
    assert main.committed_count(CTX_A) == 1  # honestly still committed
    kinds = [e.kind for e in lineage.for_subject(CTX_A, proposal.proposal_id)]
    assert kinds.count("record.rollback_failed") == 1
    assert kinds[-1] == "proposal.compensation_failed"


def test_preflight_refuses_multi_record_commit_without_rollback_support():
    pipeline, confirmation, lineage, main, _ = _build(main_rollback=False)
    proposal = pipeline.ingest(CTX_A, source_ref="call-13", content=SAMPLE)
    confirmation.confirm_all(CTX_A, proposal)
    with pytest.raises(AdapterContractError):
        pipeline.commit(CTX_A, proposal)
    assert proposal.status is ProposalStatus.CONFIRMED  # unchanged
    assert main.committed_count(CTX_A) == 0
    kinds = [e.kind for e in lineage.for_subject(CTX_A, proposal.proposal_id)]
    assert kinds[-1] == "proposal.commit_preflight_failed"


def test_single_record_commit_allowed_without_rollback_support():
    pipeline, confirmation, _, main, _ = _build(main_rollback=False)
    proposal = pipeline.ingest(
        CTX_A, source_ref="call-14", content="I spoke to Priya for 15 minutes."
    )
    confirmation.confirm_all(CTX_A, proposal)
    outcome = pipeline.commit(CTX_A, proposal)
    assert proposal.status is ProposalStatus.COMMITTED
    assert len(outcome.receipts) == 1
    assert main.committed_count(CTX_A) == 1


# ---------------- lineage reference contract (ADR-0008) ----------------

def test_lineage_payload_references_link_capture_transcript_proposal():
    pipeline, _, lineage, _, _ = _build()
    proposal = pipeline.ingest(CTX_A, source_ref="call-15", content=SAMPLE)
    created = lineage.for_subject(CTX_A, proposal.proposal_id)[0]
    assert created.payload["capture_id"] == proposal.capture_id
    assert created.payload["transcript_id"] == proposal.transcript_id
    tr_events = lineage.for_subject(CTX_A, proposal.transcript_id)
    assert tr_events[0].payload["capture_id"] == proposal.capture_id
    assert lineage.for_subject(CTX_A, proposal.capture_id)
