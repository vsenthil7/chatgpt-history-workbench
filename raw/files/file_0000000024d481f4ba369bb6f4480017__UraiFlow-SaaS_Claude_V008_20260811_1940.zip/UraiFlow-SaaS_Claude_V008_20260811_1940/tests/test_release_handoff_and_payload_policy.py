"""Phase 2 Batch 1 regressions (UF-V007-B1-001..005).

Each test is the permanent regression the reviewer required for a Batch 1
finding, asserting the invariant rather than the symptom.
"""
import hashlib
import importlib.util
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


def _load(script: str):
    spec = importlib.util.spec_from_file_location(
        script, ROOT / "scripts" / f"{script}.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


packager = _load("package_release")


# ------------------------------------------------- UF-V007-B1-001 (BLOCKER)


class TestReleaseHandoffPair:
    """A release handoff is the PAIR (zip, attestation) and the attestation's
    recorded SHA-256 must equal the hash of the actual ZIP bytes."""

    def _write_pair(self, tmp_path: Path, *, zip_bytes: bytes,
                    recorded_sha: str) -> Path:
        out = tmp_path / "out"
        out.mkdir()
        base = "UraiFlow-SaaS_Claude_V007_20260101_0000"
        (out / f"{base}.zip").write_bytes(zip_bytes)
        (out / f"{base}_ATTESTATION.md").write_text(
            f"| **Final ZIP SHA-256** | `{recorded_sha}` |\n", encoding="utf-8")
        return out

    def test_matching_pair_verifies(self, tmp_path: Path) -> None:
        payload = b"artifact-bytes"
        out = self._write_pair(
            tmp_path, zip_bytes=payload,
            recorded_sha=hashlib.sha256(payload).hexdigest())
        assert packager.verify_release_handoff(out) == []

    def test_missing_attestation_fails(self, tmp_path: Path) -> None:
        payload = b"artifact-bytes"
        out = self._write_pair(
            tmp_path, zip_bytes=payload,
            recorded_sha=hashlib.sha256(payload).hexdigest())
        next(out.glob("*_ATTESTATION.md")).unlink()
        problems = packager.verify_release_handoff(out)
        assert problems and any("attestation" in p.lower() for p in problems)

    def test_missing_zip_fails(self, tmp_path: Path) -> None:
        payload = b"artifact-bytes"
        out = self._write_pair(
            tmp_path, zip_bytes=payload,
            recorded_sha=hashlib.sha256(payload).hexdigest())
        next(out.glob("*.zip")).unlink()
        problems = packager.verify_release_handoff(out)
        assert problems and any("zip" in p.lower() for p in problems)

    def test_hash_disagreement_fails(self, tmp_path: Path) -> None:
        out = self._write_pair(
            tmp_path, zip_bytes=b"artifact-bytes", recorded_sha="0" * 64)
        problems = packager.verify_release_handoff(out)
        assert problems and any("sha-256" in p.lower() for p in problems)

    def test_tampered_zip_after_attestation_fails(self, tmp_path: Path) -> None:
        payload = b"artifact-bytes"
        out = self._write_pair(
            tmp_path, zip_bytes=payload,
            recorded_sha=hashlib.sha256(payload).hexdigest())
        next(out.glob("*.zip")).write_bytes(payload + b"TAMPER")
        assert packager.verify_release_handoff(out) != []


# ---------------------------------------------------- UF-V007-B1-002 (HIGH)


class TestRecursivePayloadPolicy:
    """Top-level approval is not a governed allowlist: every file inside an
    approved directory must match an explicit rule."""

    @pytest.mark.parametrize("rel", [
        "src/customer-secrets.env",
        "src/.env",
        "src/private-key.pem",
        "src/unexpected-secret.env",
        "tests/customer-production-export.csv",
        "tests/production-data.csv",
        "evidence/raw-provider-secret.txt",
        "evidence/private.pem",
        "09-governance/internal-passwords.txt",
        "src/uraiflow/nested/deep/token.json",
    ])
    def test_ungoverned_nested_file_is_refused(self, rel: str) -> None:
        assert packager.classify_payload_file(Path(rel)) is not None

    @pytest.mark.parametrize("rel", [
        "src/uraiflow/core/primitives.py",
        "tests/test_something.py",
        "scripts/gen_manifest.py",
        "evidence/G03-tests.txt",
        "evidence/G07-mutation.json",
        "02-architecture/adr/ADR-0001-x.md",
        "10-baseline/docs/thing.md",
        "CLAUDE.md",
        "pyproject.toml",
    ])
    def test_governed_file_is_accepted(self, rel: str) -> None:
        assert packager.classify_payload_file(Path(rel)) is None

    def test_ungoverned_top_level_file_is_refused(self) -> None:
        assert packager.classify_payload_file(Path("notes.md")) is not None

    def test_build_payload_aborts_on_nested_ungoverned_file(
        self, tmp_path: Path
    ) -> None:
        """The reviewer's exact reproduction, end to end: an ungoverned file
        under an approved directory must abort packaging, not be copied."""
        source = tmp_path / "source"
        (source / "src" / "uraiflow").mkdir(parents=True)
        (source / "src" / "uraiflow" / "__init__.py").write_text("x = 1\n")
        (source / "src" / "customer-secrets.env").write_text("TOKEN=super-secret\n")
        (source / "CLAUDE.md").write_text("# doc\n")
        payload = tmp_path / "payload"
        payload.mkdir()
        with pytest.raises(SystemExit) as exc:
            packager.build_payload(source, payload)
        assert "customer-secrets.env" in str(exc.value)
        # and nothing leaked into the payload
        assert not (payload / "src" / "customer-secrets.env").exists()

    def test_build_payload_accepts_a_fully_governed_tree(
        self, tmp_path: Path
    ) -> None:
        source = tmp_path / "source"
        (source / "src" / "uraiflow").mkdir(parents=True)
        (source / "src" / "uraiflow" / "__init__.py").write_text("x = 1\n")
        (source / "CLAUDE.md").write_text("# doc\n")
        payload = tmp_path / "payload"
        payload.mkdir()
        files = packager.build_payload(source, payload)
        assert Path("src/uraiflow/__init__.py") in files
        assert (payload / "CLAUDE.md").is_file()


# ---------------------------------------------------- UF-V007-B1-003 (HIGH)


class TestInstallBasedSmoke:
    """The extracted-ZIP verification must install the artifact into a clean
    environment, not import it from the source tree via PYTHONPATH."""

    def test_smoke_creates_a_venv_and_installs_the_artifact(self) -> None:
        source = (ROOT / "scripts" / "package_release.py").read_text("utf-8")
        assert '"-m", "venv"' in source
        assert '"pip", "install"' in source
        assert "--no-build-isolation" in source

    def test_smoke_never_sets_pythonpath(self) -> None:
        """PYTHONPATH must not be injected into the smoke environment."""
        source = (ROOT / "scripts" / "package_release.py").read_text("utf-8")
        smoke = source[source.index("def smoke_extracted"):]
        smoke = smoke[:smoke.index("\ndef ")]
        assert '"PYTHONPATH":' not in smoke

    def test_installed_import_probe_rejects_a_set_pythonpath(
        self, tmp_path: Path
    ) -> None:
        """The probe must fail if PYTHONPATH is set, proving it really tests an
        installed package rather than a source import."""
        result = subprocess.run(
            [sys.executable, "-c", packager._INSTALLED_IMPORT_PROBE],
            cwd=tmp_path, capture_output=True, text=True,
            env={"PATH": "/usr/bin:/bin:/usr/local/bin",
                 "HOME": str(tmp_path), "PYTHONPATH": str(ROOT / "src")},
            check=False)
        assert result.returncode != 0
        assert "PYTHONPATH is set" in (result.stdout + result.stderr)

    def test_pyproject_declares_installable_package_metadata(self) -> None:
        """A broken/absent packaging config would make the install step fail;
        pin the metadata the install depends on."""
        text = (ROOT / "pyproject.toml").read_text("utf-8")
        assert re.search(r'^name = "uraiflow"', text, re.MULTILINE)
        assert re.search(r'^version = "', text, re.MULTILINE)
        assert "[build-system]" in text


# -------------------------------------------------- UF-V007-B1-004 (MEDIUM)


class TestManifestStatusNeverFakesPass:
    """A failing manifest check is never reported as PASS."""

    def _tree(self, tmp_path: Path) -> Path:
        tree = tmp_path / "tree"
        shutil.copytree(
            ROOT, tree,
            ignore=shutil.ignore_patterns(
                "__pycache__", ".mutmut-cache", ".pytest_cache", ".mypy_cache",
                ".ruff_cache", "dist", "*.pyc", ".coverage", "*.egg-info"))
        return tree

    def _run(self, tree: Path, *args: str) -> int:
        return subprocess.run(
            [sys.executable, *args], cwd=tree, capture_output=True,
            text=True, check=False).returncode

    def test_tampered_report_fails_all_three_checks(self, tmp_path: Path) -> None:
        tree = self._tree(tmp_path)
        # converge to a clean fixed point first
        self._run(tree, "scripts/gen_manifest.py")
        self._run(tree, "scripts/gen_build_report.py")
        self._run(tree, "scripts/gen_manifest.py")
        assert self._run(tree, "scripts/gen_manifest.py", "--check") == 0

        report = next(tree.glob("BUILD-REPORT-V*.md"))
        report.write_text(report.read_text("utf-8") + "TAMPERED NARRATIVE LINE\n",
                          encoding="utf-8")

        assert self._run(tree, "scripts/gen_manifest.py", "--check") != 0
        assert self._run(tree, "scripts/gen_build_report.py", "--check") != 0
        assert self._run(tree, "scripts/validate_docs_consistency.py") != 0

    def test_manifest_status_has_no_pass_branch_for_failure(self) -> None:
        source = (ROOT / "scripts" / "gen_build_report.py").read_text("utf-8")
        body = source[source.index("def _manifest_status"):]
        body = body[:body.index("\ndef ")]
        # the only "PASS" returned must be under the returncode == 0 branch
        after_failure = body[body.index("problems = ["):]
        assert '"PASS"' not in after_failure


# ----------------------------------------------------- UF-V007-B1-005 (LOW)


class TestManifestCoverageClaims:
    """ADR wording must not claim the manifest covers EVERY package file: it
    cannot hash itself; the external attestation binds the complete ZIP."""

    def test_adr_0003_qualifies_self_reference(self) -> None:
        adr = next((ROOT / "02-architecture" / "adr").glob("ADR-0003-*.md"))
        text = adr.read_text("utf-8")
        assert "PACKAGE-MANIFEST.json" in text
        assert "attestation" in text.lower()

    def test_no_current_adr_overclaims_total_coverage(self) -> None:
        """Detect the stale phrasing the reviewer flagged, in any current ADR."""
        offenders = []
        for adr in (ROOT / "02-architecture" / "adr").glob("*.md"):
            text = adr.read_text("utf-8")
            for match in re.finditer(
                r"every file in the package|hash for every file", text
            ):
                window = text[match.start():match.start() + 400]
                if "PACKAGE-MANIFEST.json" not in window:
                    offenders.append(f"{adr.name}: {match.group(0)}")
        assert offenders == [], f"unqualified coverage claims: {offenders}"
