"""V004 P0-1 / P0-2 regressions (ADR-0010).

P0-1: adapter identity must be a globally unambiguous machine identity
(`adapter_id`), separate from the human-readable display name. Compensation
must bind receipts back to the exact adapter identity that produced them.

P0-2: a CommitReceipt returned by an adapter is untrusted until validated
against the invoked adapter, tenant, record and idempotency key.
"""
from datetime import UTC, datetime

import pytest

from uraiflow.adapters.contract import (
    AdapterDescriptor,
    CommitReceipt,
    validate_commit_receipt,
    validate_descriptor,
)
from uraiflow.adapters.inmemory import InMemoryTargetAdapter
from uraiflow.core.clock import FixedClock
from uraiflow.core.errors import (
    AdapterContractError,
    NoExternalEffectError,
    RoutingError,
    TrustBoundaryViolation,
)
from uraiflow.core.tenancy import TenantContext
from uraiflow.extraction.model import CandidateRecord
from uraiflow.extraction.rules import (
    ConfigurableRuleExtractor,
    ExtractionRule,
    FieldSpec,
)
from uraiflow.lineage.store import LineageStore
from uraiflow.pipeline.orchestrator import ConversationToActionPipeline
from uraiflow.proposal.model import ProposalStatus
from uraiflow.routing.registry import AdapterRegistry
from uraiflow.transcription.provider import DeterministicEchoProvider
from uraiflow.transcription.selector import ProviderSelector

T0 = datetime(2026, 8, 9, 8, 0, tzinfo=UTC)
CTX = TenantContext(tenant_id="t1", actor_id="user-1")


def _adapter(adapter_id: str, name: str, record_type: str) -> InMemoryTargetAdapter:
    return InMemoryTargetAdapter(
        adapter_id=adapter_id,
        name=name,
        schema_version="1.0",
        required_fields={record_type: ("title",)},
    )


def _descriptor(**overrides) -> AdapterDescriptor:
    base = {
        "adapter_id": "adp.test",
        "name": "test",
        "schema_version": "1.0",
        "accepted_record_types": ("a",),
        "required_fields": {"a": ("title",)},
        "supports_rollback": True,
    }
    base.update(overrides)
    return AdapterDescriptor(**base)


def _record(record_id: str = "rec-1", record_type: str = "a") -> CandidateRecord:
    return CandidateRecord(
        record_id=record_id,
        record_type=record_type,
        fields={"title": "x"},
        confidence=0.9,
        source_text="x",
    )


def _receipt(**overrides) -> CommitReceipt:
    base = {
        "receipt_id": "rcpt-1",
        "adapter_id": "adp.test",
        "adapter_name": "test",
        "tenant_id": "t1",
        "record_id": "rec-1",
        "idempotency_key": "prop:rec-1",
        "target_ref": "test/row-1",
    }
    base.update(overrides)
    return CommitReceipt(**base)


# ---------------------------------------------------------------- P0-1: identity


class TestAdapterMachineIdentity:
    def test_duplicate_display_names_with_distinct_ids_register(self) -> None:
        registry = AdapterRegistry()
        a = _adapter("adp.a", "dup", "a")
        b = _adapter("adp.b", "dup", "b")
        registry.register(a)
        registry.register(b)  # display-name duplication must not affect identity
        assert registry.resolve("a").adapter is a
        assert registry.resolve("b").adapter is b
        assert registry.resolve_by_id("adp.a").adapter is a
        assert registry.resolve_by_id("adp.b").adapter is b

    def test_duplicate_adapter_id_rejected(self) -> None:
        registry = AdapterRegistry()
        registry.register(_adapter("adp.same", "one", "a"))
        with pytest.raises(RoutingError, match="adapter identity 'adp.same'"):
            registry.register(_adapter("adp.same", "two", "b"))
        # rejection must be atomic: nothing from the failed adapter is routed
        with pytest.raises(RoutingError):
            registry.resolve("b")

    def test_record_type_conflict_rejected_atomically(self) -> None:
        registry = AdapterRegistry()
        registry.register(_adapter("adp.a", "one", "a"))
        conflicted = InMemoryTargetAdapter(
            adapter_id="adp.c",
            name="two",
            schema_version="1.0",
            required_fields={"b": ("title",), "a": ("title",)},
        )
        with pytest.raises(RoutingError, match="already routed"):
            registry.register(conflicted)
        # atomicity: the non-conflicting type of the failed adapter is NOT routed
        with pytest.raises(RoutingError):
            registry.resolve("b")
        # and its identity is not registered
        with pytest.raises(RoutingError):
            registry.resolve_by_id("adp.c")

    def test_resolve_by_unknown_id_fails(self) -> None:
        registry = AdapterRegistry()
        with pytest.raises(RoutingError, match="no registered adapter"):
            registry.resolve_by_id("adp.ghost")

    def test_compensation_binds_to_exact_adapter_identity(self) -> None:
        """The exact ChatGPT reproduction: same display name, different adapters.

        A receipt produced by adapter B must be rolled back through adapter B,
        never through same-named adapter A.
        """
        registry = AdapterRegistry()
        adapter_a = _adapter("adp.a", "dup", "task")
        adapter_b = _adapter("adp.b", "dup", "note")
        registry.register(adapter_a)
        registry.register(adapter_b)

        extractor = _extractor(("task", "task"), ("note", "note"))
        failing = _FailingAdapter("adp.fail", "dup", "boom")
        registry.register(failing)
        extractor = _extractor(("task", "task"), ("note", "note"), ("boom", "boom"))
        pipeline = _pipeline(registry, extractor)
        proposal = pipeline.ingest(
            CTX, source_ref="s", content="task: alpha\nnote: beta\nboom: crash"
        )
        proposal.confirm_all()
        outcome = pipeline.commit(CTX, proposal)
        assert outcome.failure is not None
        # both successful commits were compensated through their OWN adapters
        assert outcome.compensation_failures == ()
        assert adapter_a.committed_count(CTX) == 0
        assert adapter_b.committed_count(CTX) == 0
        assert proposal.status is ProposalStatus.ROLLED_BACK

    def test_receipt_carries_adapter_id(self) -> None:
        adapter = _adapter("adp.a", "dup", "a")
        receipt = adapter.commit(CTX, _record(), idempotency_key="k1")
        assert receipt.adapter_id == "adp.a"


class _FailingAdapter:
    """Adapter that accepts a record type but always fails on commit."""

    def __init__(self, adapter_id: str, name: str, record_type: str) -> None:
        self._descriptor = AdapterDescriptor(
            adapter_id=adapter_id,
            name=name,
            schema_version="1.0",
            accepted_record_types=(record_type,),
            required_fields={record_type: ("title",)},
            supports_rollback=True,
        )

    def descriptor(self) -> AdapterDescriptor:
        return self._descriptor

    def validate(self, record):
        from uraiflow.adapters.contract import standard_validate

        return standard_validate(self._descriptor, record)

    def preview(self, ctx, record):
        return {}

    def commit(self, ctx, record, idempotency_key):
        # fails BEFORE any external write and proves it, so this is a clean
        # compensable failure (ADR-0019, V007 P0-2)
        raise NoExternalEffectError("target system unavailable")

    def rollback(self, ctx, receipt) -> None:
        return None


# --------------------------------------------------------- descriptor hardening


class TestDescriptorInvariants:
    def test_empty_adapter_id_rejected_at_construction(self) -> None:
        """ADR-0014: an empty machine identity cannot even be constructed."""
        with pytest.raises(TrustBoundaryViolation, match="adapter_id"):
            _descriptor(adapter_id="  ")

    def test_adapter_id_syntax_enforced(self) -> None:
        with pytest.raises(AdapterContractError, match="machine identity"):
            validate_descriptor(_descriptor(adapter_id="Bad Id!"))

    def test_duplicate_accepted_record_types_rejected(self) -> None:
        with pytest.raises(AdapterContractError, match="duplicate accepted record type"):
            validate_descriptor(
                _descriptor(
                    accepted_record_types=("a", "a"),
                    required_fields={"a": ("title",)},
                )
            )

    def test_required_fields_key_not_in_accepted_types_rejected(self) -> None:
        with pytest.raises(AdapterContractError, match="not an accepted record type"):
            validate_descriptor(
                _descriptor(required_fields={"a": ("title",), "ghost": ("x",)})
            )

    def test_duplicate_required_field_names_rejected(self) -> None:
        with pytest.raises(AdapterContractError, match="duplicate required field"):
            validate_descriptor(_descriptor(required_fields={"a": ("title", "title")}))


# ------------------------------------------------------ P0-2: receipt validation


class TestCommitReceiptValidation:
    def test_valid_receipt_accepted(self) -> None:
        validate_commit_receipt(
            _descriptor(), CTX, _record(), "prop:rec-1", _receipt()
        )

    @pytest.mark.parametrize(
        ("override", "match"),
        [
            ({"adapter_id": "adp.other"}, "adapter identity"),
            ({"tenant_id": "t2"}, "tenant"),
            ({"record_id": "rec-9"}, "record"),
            ({"idempotency_key": "prop:rec-9"}, "idempotency"),
        ],
    )
    def test_mismatched_receipt_rejected(self, override: dict, match: str) -> None:
        with pytest.raises(AdapterContractError, match=match):
            validate_commit_receipt(
                _descriptor(), CTX, _record(), "prop:rec-1", _receipt(**override)
            )

    @pytest.mark.parametrize("field", ["receipt_id", "target_ref"])
    def test_empty_receipt_identifiers_rejected_at_construction(
        self, field: str
    ) -> None:
        """ADR-0014: empty receipt identifiers are unconstructable."""
        with pytest.raises(TrustBoundaryViolation, match=field):
            _receipt(**{field: " "})

    def test_hostile_adapter_receipt_triggers_governed_compensation(self) -> None:
        """A receipt lying about its tenant fails the commit. The earlier
        genuine commit is compensated; the offending adapter's commit already
        returned, so its external effect is UNCERTAIN — the aggregate must NOT
        claim ROLLED_BACK, it must reach COMPENSATION_FAILED with the uncertain
        commit recorded (ADR-0017, V006 P0-1)."""
        registry = AdapterRegistry()
        honest = _adapter("adp.honest", "honest", "task")
        hostile = _HostileReceiptAdapter("adp.liar", "liar", "note")
        registry.register(honest)
        registry.register(hostile)
        extractor = _extractor(("task", "task"), ("note", "note"))
        pipeline = _pipeline(registry, extractor)
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
        proposal.confirm_all()
        outcome = pipeline.commit(CTX, proposal)
        assert outcome.failure is not None
        assert "tenant" in outcome.failure
        assert honest.committed_count(CTX) == 0  # earlier genuine commit rolled back
        # the offending commit is UNCERTAIN, not silently discarded:
        assert proposal.status is ProposalStatus.COMPENSATION_FAILED
        assert outcome.recovery is not None
        assert outcome.recovery.contract_violations != ()
        assert outcome.recovery.uncertain_commits != ()
        uncertain = outcome.recovery.uncertain_commits[0]
        assert uncertain.adapter_id == "adp.liar"  # bound to the INVOKED identity
        assert uncertain.tenant_id == "t1"          # trusted request-side tenant
        assert proposal.uncertain_commits == outcome.recovery.uncertain_commits


class _HostileReceiptAdapter:
    """Adapter whose receipt describes a different tenant."""

    def __init__(self, adapter_id: str, name: str, record_type: str) -> None:
        self._descriptor = AdapterDescriptor(
            adapter_id=adapter_id,
            name=name,
            schema_version="1.0",
            accepted_record_types=(record_type,),
            required_fields={record_type: ("title",)},
            supports_rollback=True,
        )

    def descriptor(self) -> AdapterDescriptor:
        return self._descriptor

    def validate(self, record):
        from uraiflow.adapters.contract import standard_validate

        return standard_validate(self._descriptor, record)

    def preview(self, ctx, record):
        return {}

    def commit(self, ctx, record, idempotency_key):
        return CommitReceipt(
            receipt_id="rcpt-lie",
            adapter_id=self._descriptor.adapter_id,
            adapter_name=self._descriptor.name,
            tenant_id="another-tenant",
            record_id=record.record_id,
            idempotency_key=idempotency_key,
            target_ref="liar/row",
        )

    def rollback(self, ctx, receipt) -> None:
        return None


def _extractor(*pairs: tuple[str, str]) -> ConfigurableRuleExtractor:
    rules = tuple(
        ExtractionRule(
            record_type=record_type,
            pattern=rf"{keyword}:\s*(?P<title>\S+)",
            confidence=0.9,
            fields=(FieldSpec(name="title", source="group:title"),),
        )
        for record_type, keyword in pairs
    )
    return ConfigurableRuleExtractor(rules=rules)


def _pipeline(registry: AdapterRegistry, extractor) -> ConversationToActionPipeline:
    clock = FixedClock(T0)
    selector = ProviderSelector(
        providers={"echo": DeterministicEchoProvider("echo")},
        tenant_policy={},
        default_provider="echo",
    )
    return ConversationToActionPipeline(
        selector=selector,
        extractor=extractor,
        registry=registry,
        lineage=LineageStore(),
        clock=clock,
    )


class _CountingAdapter(InMemoryTargetAdapter):
    """Counts commit invocations (G07 mutant 178 kill: fail-fast proof)."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.commit_calls = 0

    def commit(self, ctx, record, idempotency_key):
        self.commit_calls += 1
        return super().commit(ctx, record, idempotency_key)


class TestReceiptViolationFailFast:
    def test_invalid_receipt_stops_all_further_commits(self) -> None:
        """After a receipt contract violation the commit loop must STOP:
        no later record may be committed at all (not committed-then-rolled-back).
        Pins mutant 178 (break→continue in the commit loop)."""
        registry = AdapterRegistry()
        hostile = _HostileReceiptAdapter("adp.liar", "liar", "note")
        later = _CountingAdapter(
            adapter_id="adp.later",
            name="later",
            schema_version="1.0",
            required_fields={"task": ("title",)},
        )
        registry.register(hostile)
        registry.register(later)
        # rule order makes the hostile "note" record FIRST in the proposal
        pipeline = _pipeline(registry, _extractor(("note", "note"), ("task", "task")))
        proposal = pipeline.ingest(CTX, source_ref="s", content="note: b\ntask: a")
        proposal.confirm_all()
        outcome = pipeline.commit(CTX, proposal)
        assert outcome.failure is not None
        assert later.commit_calls == 0  # never invoked after the violation
        assert outcome.recovery is not None
        assert outcome.recovery.committed_receipts == ()  # nothing validated before it
        # the hostile commit already returned → its effect is uncertain, so the
        # aggregate cannot claim ROLLED_BACK (ADR-0017).
        assert proposal.status is ProposalStatus.COMPENSATION_FAILED
        assert outcome.recovery.uncertain_commits != ()
