"""V007 review reproductions (executed-exploit regressions).

Each test is the reviewer's exact V006 probe, asserting the invariant now holds.

  P0-1  retry_rollback must not clear/ignore uncertain commits
  P0-2  an exception AFTER an external write is an UNKNOWN outcome
  P0-3  duplicate display names cannot mask a non-rollback adapter
  P0-4  post-confirmation content changes cannot be committed
  P1-1  the pinned registered descriptor is deeply immutable
  P1-2  lineage payload cannot change after append or read
  P1-3  runtime version matches pyproject/manifest
"""
from datetime import UTC, datetime

import pytest

import uraiflow
from uraiflow.adapters.contract import AdapterDescriptor, CommitReceipt
from uraiflow.adapters.inmemory import InMemoryTargetAdapter
from uraiflow.core.clock import FixedClock
from uraiflow.core.errors import (
    AdapterContractError,
    InvalidTransitionError,
    NoExternalEffectError,
    RevalidationRequiredError,
)
from uraiflow.core.primitives import FrozenMapping, freeze_mapping
from uraiflow.core.tenancy import TenantContext
from uraiflow.extraction.rules import ConfigurableRuleExtractor, ExtractionRule, FieldSpec
from uraiflow.lineage.model import LineageEvent
from uraiflow.lineage.store import LineageStore
from uraiflow.pipeline.orchestrator import ConversationToActionPipeline, ProposalStatus
from uraiflow.proposal.model import (
    ConfirmedSnapshot,
    ItemDecision,
    Proposal,
    ProposalItem,
)
from uraiflow.recovery.service import RecoveryService
from uraiflow.routing.registry import AdapterRegistry
from uraiflow.transcription.provider import DeterministicEchoProvider
from uraiflow.transcription.selector import ProviderSelector

T0 = datetime(2026, 1, 1, tzinfo=UTC)
CTX = TenantContext("tenant-a", "actor")


def _ext(*pairs):
    return ConfigurableRuleExtractor(rules=tuple(
        ExtractionRule(
            record_type=rt, pattern=rf"{kw}:\s*(?P<title>\S+)", confidence=0.9,
            fields=(FieldSpec(name="title", source="group:title"),),
        )
        for rt, kw in pairs
    ))


def _pipe(registry, extractor, lineage=None):
    return ConversationToActionPipeline(
        selector=ProviderSelector(
            providers={"echo": DeterministicEchoProvider("echo")},
            tenant_policy={}, default_provider="echo"),
        extractor=extractor, registry=registry,
        lineage=lineage or LineageStore(), clock=FixedClock(T0))


def _proposal(tenant="tenant-a"):
    return Proposal(
        proposal_id="prop-1", tenant_id=tenant, capture_id="cap-1",
        transcript_id="tr-1",
        items=[ProposalItem("rec-0", "task", {"title": "x"}, 0.9, "s")])


# --------------------------------------------------------------- P0-1


class _SideEffectBadReceipt(InMemoryTargetAdapter):
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.effects: list[str] = []

    def commit(self, ctx, record, idempotency_key):
        self.effects.append(record.record_id)
        return CommitReceipt(
            receipt_id="rx", adapter_id=self.descriptor().adapter_id,
            adapter_name=self.descriptor().name, tenant_id="WRONG",
            record_id=record.record_id, idempotency_key=idempotency_key,
            target_ref="ext")


def _uncertain_proposal():
    registry = AdapterRegistry()
    adapter = _SideEffectBadReceipt(
        adapter_id="adp.e", name="e", schema_version="1.0",
        required_fields={"task": ("title",)})
    registry.register(adapter)
    lineage = LineageStore()
    pipeline = _pipe(registry, _ext(("task", "task")), lineage)
    proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
    proposal.confirm_all()
    pipeline.commit(CTX, proposal)
    return proposal, registry, lineage, adapter


class TestP01RetryCannotIgnoreUncertain:
    def test_retry_rollback_cannot_clear_or_ignore_uncertain_commits(self) -> None:
        proposal, registry, lineage, adapter = _uncertain_proposal()
        assert proposal.status is ProposalStatus.COMPENSATION_FAILED
        assert proposal.uncertain_commits != ()
        service = RecoveryService(
            registry=registry, lineage=lineage, clock=FixedClock(T0),
            authorized_operators=frozenset({"actor"}))
        service.retry_rollback(CTX, proposal)
        # the external effect still exists → must NOT be ROLLED_BACK
        assert adapter.effects != []
        assert proposal.status is not ProposalStatus.ROLLED_BACK
        assert proposal.status is ProposalStatus.COMPENSATION_FAILED
        assert proposal.uncertain_commits != ()

    def test_retry_emits_blocked_event_when_uncertain_remains(self) -> None:
        proposal, registry, lineage, _ = _uncertain_proposal()
        service = RecoveryService(
            registry=registry, lineage=lineage, clock=FixedClock(T0),
            authorized_operators=frozenset({"actor"}))
        service.retry_rollback(CTX, proposal)
        kinds = [e.kind for e in lineage.for_subject(CTX, proposal.proposal_id)]
        assert "recovery.retry_blocked_uncertain" in kinds

    def test_mark_rolled_back_refuses_while_uncertain(self) -> None:
        proposal = _proposal()
        proposal.status = ProposalStatus.COMPENSATION_FAILED
        proposal.record_uncertain(("some-uncertain",))
        with pytest.raises(InvalidTransitionError, match="uncertain commit"):
            proposal.mark_rolled_back()

    def test_mark_rolled_back_refuses_while_unrecovered(self) -> None:
        proposal = _proposal()
        proposal.status = ProposalStatus.COMPENSATION_FAILED
        proposal.record_unrecovered(("some-receipt",))
        with pytest.raises(InvalidTransitionError, match="unrecovered receipt"):
            proposal.mark_rolled_back()


# --------------------------------------------------------------- P0-2


class _WriteThenRaise(InMemoryTargetAdapter):
    """External write succeeds, then the response is lost."""

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.effects: list[str] = []

    def commit(self, ctx, record, idempotency_key):
        self.effects.append(record.record_id)
        raise TimeoutError("response lost after remote commit")


class _CleanFailure(InMemoryTargetAdapter):
    def commit(self, ctx, record, idempotency_key):
        raise NoExternalEffectError("refused before dispatch")


class TestP02UnknownOutcome:
    def test_exception_after_remote_side_effect_is_recorded_as_uncertain(self) -> None:
        registry = AdapterRegistry()
        adapter = _WriteThenRaise(
            adapter_id="adp.t", name="t", schema_version="1.0",
            required_fields={"task": ("title",)})
        registry.register(adapter)
        pipeline = _pipe(registry, _ext(("task", "task")))
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
        proposal.confirm_all()
        outcome = pipeline.commit(CTX, proposal)
        assert adapter.effects != []                      # the write happened
        assert proposal.status is not ProposalStatus.ROLLED_BACK
        assert proposal.status is ProposalStatus.COMPENSATION_FAILED
        assert outcome.recovery is not None
        assert len(outcome.recovery.uncertain_commits) == 1
        uc = outcome.recovery.uncertain_commits[0]
        assert uc.adapter_id == "adp.t"
        assert uc.tenant_id == "tenant-a"

    def test_unknown_outcome_emits_lineage_event(self) -> None:
        registry = AdapterRegistry()
        registry.register(_WriteThenRaise(
            adapter_id="adp.t", name="t", schema_version="1.0",
            required_fields={"task": ("title",)}))
        lineage = LineageStore()
        pipeline = _pipe(registry, _ext(("task", "task")), lineage)
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
        proposal.confirm_all()
        pipeline.commit(CTX, proposal)
        events = {e.kind: e.payload
                  for e in lineage.for_subject(CTX, proposal.proposal_id)}
        assert "record.commit_outcome_unknown" in events
        assert events["record.commit_outcome_unknown"]["external_effect"] == "uncertain"

    def test_proven_no_effect_remains_cleanly_rolled_back(self) -> None:
        """An adapter that PROVES no external write occurred keeps the clean
        compensable path (ADR-0019): ROLLED_BACK is still correct there."""
        registry = AdapterRegistry()
        registry.register(InMemoryTargetAdapter(
            adapter_id="adp.ok", name="ok", schema_version="1.0",
            required_fields={"task": ("title",)}))
        registry.register(_CleanFailure(
            adapter_id="adp.clean", name="clean", schema_version="1.0",
            required_fields={"note": ("title",)}))
        pipeline = _pipe(registry, _ext(("task", "task"), ("note", "note")))
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
        proposal.confirm_all()
        outcome = pipeline.commit(CTX, proposal)
        assert proposal.status is ProposalStatus.ROLLED_BACK
        assert outcome.recovery is not None
        assert outcome.recovery.uncertain_commits == ()


# --------------------------------------------------------------- P0-3


class _NoRollbackAdapter(InMemoryTargetAdapter):
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.effects: list[str] = []

    def descriptor(self):
        b = super().descriptor()
        return AdapterDescriptor(
            adapter_id=b.adapter_id, name=b.name, schema_version=b.schema_version,
            accepted_record_types=b.accepted_record_types,
            required_fields=b.required_fields, supports_rollback=False)

    def commit(self, ctx, record, idempotency_key):
        self.effects.append(record.record_id)
        return super().commit(ctx, record, idempotency_key)


class TestP03DuplicateDisplayName:
    def test_duplicate_display_name_cannot_mask_nonrollback_adapter(self) -> None:
        registry = AdapterRegistry()
        first = _NoRollbackAdapter(
            adapter_id="adp.nonrollback", name="same-display",
            schema_version="1.0", required_fields={"task": ("title",)})
        second = InMemoryTargetAdapter(
            adapter_id="adp.second", name="same-display",
            schema_version="1.0", required_fields={"note": ("title",)})
        registry.register(first)
        registry.register(second)
        pipeline = _pipe(registry, _ext(("task", "task"), ("note", "note")))
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
        proposal.confirm_all()
        # preflight must REFUSE: one adapter identity cannot roll back
        with pytest.raises(AdapterContractError, match="rollback support"):
            pipeline.commit(CTX, proposal)
        assert first.effects == []  # nothing was committed

    def test_preflight_reports_adapter_ids_not_names(self) -> None:
        registry = AdapterRegistry()
        registry.register(_NoRollbackAdapter(
            adapter_id="adp.norb", name="dup", schema_version="1.0",
            required_fields={"task": ("title",)}))
        registry.register(InMemoryTargetAdapter(
            adapter_id="adp.ok", name="dup", schema_version="1.0",
            required_fields={"note": ("title",)}))
        lineage = LineageStore()
        pipeline = _pipe(registry, _ext(("task", "task"), ("note", "note")), lineage)
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
        proposal.confirm_all()
        with pytest.raises(AdapterContractError):
            pipeline.commit(CTX, proposal)
        payload = next(
            e.payload for e in lineage.for_subject(CTX, proposal.proposal_id)
            if e.kind == "proposal.commit_preflight_failed")
        assert payload["adapter_ids_without_rollback"] == ("adp.norb",)


# --------------------------------------------------------------- P0-4


def _confirmed_pipeline():
    registry = AdapterRegistry()
    adapter = InMemoryTargetAdapter(
        adapter_id="adp.x", name="x", schema_version="1.0",
        required_fields={"task": ("title",)})
    registry.register(adapter)
    pipeline = _pipe(registry, _ext(("task", "task")))
    proposal = pipeline.ingest(CTX, source_ref="s", content="task: approved")
    proposal.confirm_all()
    return pipeline, proposal, adapter


class TestP04ConfirmedSnapshot:
    def test_post_confirmation_content_change_cannot_be_committed(self) -> None:
        pipeline, proposal, adapter = _confirmed_pipeline()
        proposal.items[0].fields["title"] = "NOT_APPROVED"
        with pytest.raises(RevalidationRequiredError, match="changed after"):
            pipeline.commit(CTX, proposal)
        assert adapter.committed_count(CTX) == 0

    def test_commit_uses_exact_confirmed_snapshot_version(self) -> None:
        _p, proposal, _ = _confirmed_pipeline()
        snapshot = proposal.confirmed_snapshot
        assert isinstance(snapshot, ConfirmedSnapshot)
        assert len(snapshot.content_hash) == 64  # sha256 hex
        # the snapshot equals a freshly built one from the live confirmed items
        rebuilt = ConfirmedSnapshot.build(proposal.confirmed_items())
        assert rebuilt.content_hash == snapshot.content_hash

    def test_editing_invalidates_confirmation_and_requires_reconfirm(self) -> None:
        _p, proposal, _ = _confirmed_pipeline()
        proposal.status = ProposalStatus.AWAITING_CONFIRMATION  # commandable again
        proposal.edit_item("rec-0" if proposal.items[0].record_id == "rec-0"
                           else proposal.items[0].record_id, {"title": "edited"})
        assert proposal.confirmed_snapshot is None
        assert proposal.needs_revalidation is True
        with pytest.raises(RevalidationRequiredError):
            proposal.commit_snapshot()

    def test_reconfirmation_produces_a_new_snapshot_hash(self) -> None:
        _p, proposal, _ = _confirmed_pipeline()
        first = proposal.confirmed_snapshot.content_hash
        proposal.status = ProposalStatus.AWAITING_CONFIRMATION
        proposal.edit_item(proposal.items[0].record_id, {"title": "different"})
        proposal.needs_revalidation = False  # revalidated
        proposal.confirm_all()
        assert proposal.confirmed_snapshot.content_hash != first

    def test_confirmed_item_fields_are_frozen(self) -> None:
        _p, proposal, _ = _confirmed_pipeline()
        item = proposal.confirmed_snapshot.items[0]
        assert isinstance(item.fields, FrozenMapping)
        with pytest.raises(TypeError):
            item.fields["title"] = "hacked"  # type: ignore[index]

    def test_reject_all_clears_the_snapshot(self) -> None:
        _p, proposal, _ = _confirmed_pipeline()
        proposal.status = ProposalStatus.AWAITING_CONFIRMATION
        proposal.reject_all()
        assert proposal.confirmed_snapshot is None

    def test_commit_snapshot_requires_confirmation(self) -> None:
        proposal = _proposal()
        with pytest.raises(RevalidationRequiredError, match="no confirmed snapshot"):
            proposal.commit_snapshot()

    def test_direct_status_and_decision_writes_cannot_bypass_confirmation(self) -> None:
        """Forcing status/decision by direct write does not fabricate a
        confirmed snapshot, so commit still refuses."""
        registry = AdapterRegistry()
        registry.register(InMemoryTargetAdapter(
            adapter_id="adp.x", name="x", schema_version="1.0",
            required_fields={"task": ("title",)}))
        pipeline = _pipe(registry, _ext(("task", "task")))
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
        proposal.items[0].decision = ItemDecision.CONFIRMED   # direct write
        proposal.status = ProposalStatus.CONFIRMED            # direct write
        with pytest.raises(RevalidationRequiredError):
            pipeline.commit(CTX, proposal)


# --------------------------------------------------------------- P1-1 / P1-2


class TestDeepImmutability:
    def test_registered_descriptor_is_deeply_immutable(self) -> None:
        registry = AdapterRegistry()
        registry.register(InMemoryTargetAdapter(
            adapter_id="adp.x", name="x", schema_version="1.0",
            required_fields={"task": ("title",)}))
        descriptor = registry.resolve_by_id("adp.x").descriptor
        assert isinstance(descriptor.required_fields, FrozenMapping)
        with pytest.raises(TypeError):
            descriptor.required_fields["task"] = ("HIJACKED",)  # type: ignore[index]
        assert descriptor.required_fields["task"] == ("title",)

    def test_lineage_payload_cannot_change_after_append_or_read(self) -> None:
        store = LineageStore()
        store.append(CTX, LineageEvent(
            event_id="e", tenant_id="tenant-a", subject_id="subj", kind="k",
            payload={"operator": "op-1", "evidence": "ticket"}, occurred_at=T0))
        got = store.for_subject(CTX, "subj")[0]
        with pytest.raises(TypeError):
            got.payload["evidence"] = "TAMPERED"  # type: ignore[index]
        assert store.for_subject(CTX, "subj")[0].payload["evidence"] == "ticket"

    def test_nested_payload_structures_are_frozen(self) -> None:
        store = LineageStore()
        store.append(CTX, LineageEvent(
            event_id="e2", tenant_id="tenant-a", subject_id="subj2", kind="k",
            payload={"nested": {"a": 1}, "items": [1, 2]}, occurred_at=T0))
        got = store.for_subject(CTX, "subj2")[0]
        assert isinstance(got.payload["nested"], FrozenMapping)
        assert got.payload["items"] == (1, 2)  # list frozen to tuple
        with pytest.raises(TypeError):
            got.payload["nested"]["a"] = 99  # type: ignore[index]


class TestFrozenMappingPrimitive:
    def test_freeze_is_idempotent(self) -> None:
        first = freeze_mapping({"a": 1})
        assert freeze_mapping(first) is not None
        assert dict(freeze_mapping({"n": first})["n"]) == {"a": 1}

    def test_sets_are_frozen(self) -> None:
        frozen = freeze_mapping({"s": {1, 2}})
        assert frozen["s"] == frozenset({1, 2})

    def test_len_iter_and_repr(self) -> None:
        frozen = freeze_mapping({"a": 1, "b": 2})
        assert len(frozen) == 2
        assert sorted(frozen) == ["a", "b"]
        assert "FrozenMapping" in repr(frozen)

    def test_hashable_and_cached(self) -> None:
        frozen = freeze_mapping({"a": 1})
        assert hash(frozen) == hash(frozen)  # second call hits the cache

    def test_equal_content_hashes_equal(self) -> None:
        assert hash(freeze_mapping({"a": 1})) == hash(freeze_mapping({"a": 1}))


# --------------------------------------------------------------- P1-3


def test_runtime_version_matches_pyproject_and_manifest() -> None:
    """V007 P1-3: the runtime package version must not drift from packaging."""
    import pathlib
    import re
    root = pathlib.Path(__file__).resolve().parents[1]
    pyproject = (root / "pyproject.toml").read_text(encoding="utf-8")
    declared = re.search(r'^version = "([^"]+)"', pyproject, re.MULTILINE).group(1)
    assert uraiflow.__version__ == declared


def test_current_document_references_exist() -> None:
    """V007 P2-1/P2-2: every markdown reference from a CURRENT document to a
    build report, RTM or ADR file must resolve to a file that exists.

    Historical material under 10-baseline/ is preserved input and is excluded.
    """
    import pathlib
    import re
    root = pathlib.Path(__file__).resolve().parents[1]
    pattern = re.compile(r"`((?:BUILD-REPORT|RTM)[A-Za-z0-9._-]*\.md)`")
    missing: list[str] = []
    for doc in root.rglob("*.md"):
        rel = doc.relative_to(root)
        if rel.parts[0] == "10-baseline":
            continue
        text = doc.read_text(encoding="utf-8")
        for name in set(pattern.findall(text)):
            candidates = [root / name, root / "06-traceability" / name]
            if not any(c.is_file() for c in candidates):
                missing.append(f"{rel} -> {name}")
    assert missing == [], f"references to absent documents: {sorted(missing)}"


def test_reading_map_points_at_the_current_rtm() -> None:
    """V007 P2-1: the reading map must not send builders to the starter stub."""
    import pathlib
    root = pathlib.Path(__file__).resolve().parents[1]
    text = (root / "00-control" / "READING-MAP.md").read_text(encoding="utf-8")
    assert "RTM-V007.md" in text


# --------------------------------------------- V007 mutation-kill regressions


class TestConfirmedSnapshotInvariants:
    """Kill mutants in the new confirmed-snapshot machinery (G07)."""

    def _snapshot(self):
        item = ProposalItem("rec-0", "task", {"title": "x", "a": "1"}, 0.9, "src")
        item.decision = ItemDecision.CONFIRMED
        return ConfirmedSnapshot.build([item])

    def test_confirmed_item_and_snapshot_are_frozen(self) -> None:
        from dataclasses import FrozenInstanceError
        snap = self._snapshot()
        with pytest.raises(FrozenInstanceError):
            snap.content_hash = "x"          # type: ignore[misc]
        with pytest.raises(FrozenInstanceError):
            snap.items[0].record_id = "y"    # type: ignore[misc]

    def test_confirmed_item_candidate_confidence_is_one(self) -> None:
        """Confirmed content is authoritative: confidence is exactly 1.0."""
        candidate = self._snapshot().items[0].as_candidate()
        assert candidate.confidence == 1.0

    def test_hash_covers_every_content_field(self) -> None:
        """Each of record_id / record_type / fields / source_text must affect
        the content hash (kills the hash-payload key mutants)."""
        base = self._snapshot().content_hash

        def h(record_id="rec-0", record_type="task", fields=None, source="src"):
            item = ProposalItem(
                record_id, record_type, fields or {"title": "x", "a": "1"},
                0.9, source)
            item.decision = ItemDecision.CONFIRMED
            return ConfirmedSnapshot.build([item]).content_hash

        assert h(record_id="rec-9") != base
        assert h(record_type="note") != base
        assert h(fields={"title": "CHANGED", "a": "1"}) != base
        assert h(source="other") != base

    def test_hash_is_canonical_and_order_independent(self) -> None:
        """Field insertion order must not change the hash (kills sort_keys and
        separators mutants, which would make the hash order/format dependent)."""
        def h(fields):
            item = ProposalItem("rec-0", "task", fields, 0.9, "src")
            item.decision = ItemDecision.CONFIRMED
            return ConfirmedSnapshot.build([item]).content_hash

        assert h({"title": "x", "a": "1"}) == h({"a": "1", "title": "x"})

    def test_content_hash_is_pinned_to_an_exact_value(self) -> None:
        """The confirmed-content hash is a STABLE contract: the approval version
        must not silently change meaning. Pinning the exact digest kills any
        mutation of the hash payload keys or the JSON canonicalisation
        arguments, which would otherwise only shift hashes relative to each
        other and stay invisible to comparative assertions."""
        item = ProposalItem("rec-0", "task", {"title": "x", "a": "1"}, 0.9, "src")
        item.decision = ItemDecision.CONFIRMED
        assert ConfirmedSnapshot.build([item]).content_hash == (
            "f884cab7b1e1c3312a0bf0bbe3e294b65107fc9f8ec2feeda6ff486680c1b4c6"
        )

    def test_hash_is_stable_sha256_hex(self) -> None:
        snap = self._snapshot()
        assert len(snap.content_hash) == 64
        assert set(snap.content_hash) <= set("0123456789abcdef")
        # rebuilding from equivalent content reproduces the same hash
        assert self._snapshot().content_hash == snap.content_hash

    def test_drift_message_shows_twelve_hex_characters(self) -> None:
        """The revalidation message shows a 12-char hash prefix of each side."""
        pipeline, proposal, _ = _confirmed_pipeline()
        expected = proposal.confirmed_snapshot.content_hash[:12]
        proposal.items[0].fields["title"] = "NOT_APPROVED"
        with pytest.raises(RevalidationRequiredError) as exc:
            pipeline.commit(CTX, proposal)
        message = str(exc.value)
        assert f"snapshot {expected} !=" in message
        live = ConfirmedSnapshot.build(proposal.confirmed_items()).content_hash
        assert f"live {live[:12]})" in message


class TestCommitFailFastAndPayloadKeys:
    def test_invalid_receipt_stops_further_commits(self) -> None:
        """A receipt contract violation must BREAK the commit loop, never
        continue to the next record (mutant 245)."""
        registry = AdapterRegistry()
        bad = _SideEffectBadReceipt(
            adapter_id="adp.bad", name="bad", schema_version="1.0",
            required_fields={"task": ("title",)})
        later = InMemoryTargetAdapter(
            adapter_id="adp.later", name="later", schema_version="1.0",
            required_fields={"note": ("title",)})
        registry.register(bad)
        registry.register(later)
        pipeline = _pipe(registry, _ext(("task", "task"), ("note", "note")))
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
        proposal.confirm_all()
        pipeline.commit(CTX, proposal)
        assert later.committed_count(CTX) == 0  # never reached

    def test_receipt_invalid_event_payload_keys(self) -> None:
        registry = AdapterRegistry()
        registry.register(_SideEffectBadReceipt(
            adapter_id="adp.bad", name="bad", schema_version="1.0",
            required_fields={"task": ("title",)}))
        lineage = LineageStore()
        pipeline = _pipe(registry, _ext(("task", "task")), lineage)
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
        proposal.confirm_all()
        pipeline.commit(CTX, proposal)
        payload = next(
            e.payload for e in lineage.for_subject(CTX, proposal.proposal_id)
            if e.kind == "record.commit_receipt_invalid")
        assert set(payload) == {"record_id", "error", "external_effect"}

    def test_retry_blocked_event_payload_keys(self) -> None:
        proposal, registry, lineage, _ = _uncertain_proposal()
        RecoveryService(
            registry=registry, lineage=lineage, clock=FixedClock(T0),
            authorized_operators=frozenset({"actor"})).retry_rollback(CTX, proposal)
        payload = next(
            e.payload for e in lineage.for_subject(CTX, proposal.proposal_id)
            if e.kind == "recovery.retry_blocked_uncertain")
        assert set(payload) == {"operator_id", "uncertain_commits"}
        assert payload["operator_id"] == "actor"
        assert payload["uncertain_commits"] == 1


def test_frozen_mapping_repr_names_the_type() -> None:
    frozen = freeze_mapping({"a": 1})
    assert repr(frozen) == "FrozenMapping({'a': 1})"


class TestUnknownOutcomeEventAndFailFast:
    """Kill mutants in the P0-2 unknown-outcome block (G07 241/242/245)."""

    def _registry_with_write_then_raise_first(self):
        class _CountingAdapter(InMemoryTargetAdapter):
            """Records every commit INVOCATION, so fail-fast can be asserted on
            'was it called at all', not on the post-compensation count (which is
            zero either way)."""

            def __init__(self, *a, **k):
                super().__init__(*a, **k)
                self.commit_calls = 0

            def commit(self, ctx, record, idempotency_key):
                self.commit_calls += 1
                return super().commit(ctx, record, idempotency_key)

        registry = AdapterRegistry()
        first = _WriteThenRaise(
            adapter_id="adp.unknown", name="unknown", schema_version="1.0",
            required_fields={"task": ("title",)})
        later = _CountingAdapter(
            adapter_id="adp.later", name="later", schema_version="1.0",
            required_fields={"note": ("title",)})
        registry.register(first)
        registry.register(later)
        return registry, first, later

    def test_unknown_outcome_event_payload_keys(self) -> None:
        registry, _first, _later = self._registry_with_write_then_raise_first()
        lineage = LineageStore()
        pipeline = _pipe(registry, _ext(("task", "task")), lineage)
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a")
        proposal.confirm_all()
        pipeline.commit(CTX, proposal)
        payload = next(
            e.payload for e in lineage.for_subject(CTX, proposal.proposal_id)
            if e.kind == "record.commit_outcome_unknown")
        # exact key set: renaming any key breaks the evidence contract
        assert set(payload) == {"record_id", "error", "external_effect"}
        assert payload["record_id"] == proposal.items[0].record_id
        assert "TimeoutError" in payload["error"]

    def test_unknown_outcome_stops_all_further_commits(self) -> None:
        """An UNKNOWN outcome must BREAK the commit loop: continuing would
        commit further records after an unreconciled external effect."""
        registry, first, later = self._registry_with_write_then_raise_first()
        pipeline = _pipe(registry, _ext(("task", "task"), ("note", "note")))
        proposal = pipeline.ingest(CTX, source_ref="s", content="task: a\nnote: b")
        proposal.confirm_all()
        pipeline.commit(CTX, proposal)
        assert first.effects != []          # the unknown write happened
        # fail-fast: the next adapter was never INVOKED. (Asserting the
        # committed COUNT would not distinguish break from continue, because a
        # later commit would be compensated back to zero anyway.)
        assert later.commit_calls == 0
