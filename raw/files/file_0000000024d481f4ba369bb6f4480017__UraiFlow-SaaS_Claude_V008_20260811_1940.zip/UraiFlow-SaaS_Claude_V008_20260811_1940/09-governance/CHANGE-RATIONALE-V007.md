# Change Rationale — V007

Driver: the independent ChatGPT deep review of
`UraiFlow-SaaS_Claude_V006_20260809_1642.zip`, which verified the ZIP's physical
integrity and the shipped suite but reproduced five release-blocking defects
(P0-1..P0-5) plus five P1 and three P2 findings. This iteration is
correction-only: persistence, real providers, role-based recovery and new
workflow features remain deferred.

## What changed and why

1. **Recovery truthfulness (P0-1, ADR-0017/0019).** `retry_rollback` cleared to
   `ROLLED_BACK` whenever the unrecovered-receipt set emptied, ignoring
   `uncertain_commits`. The aggregate now owns the rule: `mark_rolled_back()`
   refuses while EITHER unrecovered receipts or uncertain commits remain, and
   every path (commit, compensation, operator recovery) goes through it.

2. **Commit-outcome model (P0-2, ADR-0019).** An exception from
   `adapter.commit()` was treated as "definitely not committed". It is now
   UNKNOWN by default and records an `UncertainCommit`; an adapter must raise
   `NoExternalEffectError` to claim, checkably, that no remote write occurred.
   A timeout after a successful remote write no longer yields a false rollback.

3. **Atomicity preflight (P0-3).** Rollback capability was keyed by display
   name, which ADR-0010 explicitly permits to be duplicated, so a second
   adapter could mask a non-rollback first one. Preflight now keys by
   `adapter_id`; names are secondary evidence only.

4. **Confirmation integrity (P0-4, ADR-0018).** Commit read the live, mutable
   proposal items, so content approved by a human could be changed before
   commit. Confirmation now captures a deeply-immutable `ConfirmedSnapshot`
   with a SHA-256 content hash; commit binds to that snapshot and refuses if
   the live content no longer matches; edits invalidate confirmation.

5. **Final-artifact gate evidence (P0-5).** The build report derived its
   manifest fact from `evidence/G01-manifest-check.txt`, which packaging
   removes — so the shipped ZIP carried a manifest-protected PASS for a gate
   that failed on clean extraction. The fact is now derived by running the
   check, and the packager runs G09 and G10 against the exact extracted final
   ZIP, failing if either fails.

6. **Deep immutability (P1-1, P1-2, ADR-0018).** New `FrozenMapping` primitive;
   pinned descriptor contracts and lineage audit payloads are frozen at any
   nesting depth.

7. **Honesty of reported facts (P1-3, P1-4, P1-5, P2-3).** Runtime
   `__version__` now tracks pyproject (test-enforced); evidence is regenerated
   in-run; the build report states mutation SCOPE (configured modules vs total);
   the attestation scopes its determinism claim to "same frozen payload".

8. **Document accuracy (P2-1, P2-2).** The reading map points at the current
   RTM, and a test walks every current document to prove no reference to an
   absent build report or RTM remains.

## Version
0.12.0.dev0 → 0.13.0.dev0.

## Governance
All findings are pinned as executed-probe regressions in
`tests/test_v007_review_reproductions.py` and recorded in RTM-V007
(SEC-009..014, GTE-010/011, DOC-002/003). No prior-version corrections were
rolled back. V007 is handed back for independent review; it is not
self-certified.
