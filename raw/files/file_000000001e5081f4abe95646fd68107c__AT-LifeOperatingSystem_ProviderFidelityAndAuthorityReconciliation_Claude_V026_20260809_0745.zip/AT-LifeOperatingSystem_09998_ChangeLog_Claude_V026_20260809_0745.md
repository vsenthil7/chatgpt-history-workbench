# AT-LOS V026 Change Log

**Release type:** provider-neutral source fidelity and authority reconciliation. ADR-026, amending ADR-025 and ADR-019. Response to the V025 independent deep review: both new blockers, both governance blockers, and all authority contradictions.

## at-ingest-llm-export

**ChatGPT** — nested contract validated before use: `message`, `author`, `content`, `parts`, `role` each type-checked; malformed shapes are named `ParseIssue`s, never `AttributeError`s. Node ordering is defensive (the V025 sort key crashed on a malformed node before validation ran); a non-numeric `create_time` orders deterministically and is reported.

**Claude** — the ChatGPT-strength contract: non-text blocks preserved as original JSON in `structured_content`, including beside a top-level `text` field; structured-only messages reported as unreadable-as-text; `content` not a list, `text`/`sender` not strings → issues, never empty successful Events.

**Perplexity** — `str()` coercion removed; the string contract is validated and violations are issues stating the value was not coerced.

**Shared** — the provider-neutral invariant stated in the module docstring and enforced by a cross-provider adversarial test: every unit is an Event or a ParseIssue; coverage drops on rejection; no repr-of-structure text.

## Documents and guards

RTM-116 (provider-neutral invariant) · RTM-117 (malformed nested structure is reported) · RTM-118 (Claude structured preservation) · RTM-119 (Perplexity contract validated). 28 mutation cases — 3 new mutants re-create the V025 review findings, all killed. 21 new tests; 424 passing, 100% line and branch on 1321 statements / 380 branches.

`release_check` now scans the **shipped outer Markdown** for RTM-112/113 claims — the V025 Standard restated the false publication-boundary rule precisely because the guard saw only repository files. `ArtifactAuthority` and `ManualTestIndex` sheets removed from the historical audit exemption. MT-003, MT-004 and EXT-UAT-001 wording states local test scope, never platform-wide absence.

## Workbooks

Hallucination Register: package row reconciled to 6 coded modules. Sprint Tracker: S1-10 Superseded (S1-20), S2-04 Superseded (S2-10), **S2-01 reverted to Planned** with the misfiled identity evidence recorded. Test Strategy: `07_NonFunctional` durable persistence Implemented; `09_ArtifactAuthority` V026 / ADR-001..026; `10_DerivedFacts`, `03_ArchitectureRTM`, `05_MutationResults` regenerated from machine sources; new `19_ProviderNeutralFidelity` sheet. `06_DocumentationMap` unchanged — correctly Partial.

## Decisions

D-102 provider-neutral fidelity; nested contracts validated · D-103 release gate audits shipped artefacts; manual tests state local limits · D-104 one current state per capability; completion evidence belongs to its task

## Standard

D-070's mechanism claim explicitly superseded in the V026 Standard. ADR-018 untouched — historical.

## Open

DQ-004, DQ-012, DQ-013, DQ-014, **DQ-016 (Partial — no external publication until a real exclusion mechanism and output test exist)** · `at-evidence` may begin after independent V026 review confirms the provider-neutral contract · **AT-056 Not started**.
