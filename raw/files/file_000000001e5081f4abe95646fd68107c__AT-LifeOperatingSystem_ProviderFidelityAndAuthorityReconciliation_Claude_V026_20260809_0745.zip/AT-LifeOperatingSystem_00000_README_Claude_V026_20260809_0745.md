# AT-Life Operating System (AT-LOS) - V026

**Release:** `AT-LifeOperatingSystem_ProviderFidelityAndAuthorityReconciliation_Claude_V026_20260809_0745`
**Prepared by:** Claude · **09-Aug-2026 07:45 BST**

```
V026 — ProviderFidelityAndAuthorityReconciliation

pytest                 424 passed, 1 skipped
coverage               1321 statements, 380 branches, 100% line and branch
architecture guards    54 collected
integration (real venv) 2 collected
mutation regression    28/28 killed (3 new V025-blocker mutants)
RTM                    116 passing + 1 skipped + 2 not enforced = 119
modules / products     11 declared, 2 product applications
test suites            17 built, 4 declared not built (3 internal, 1 external)
documentation          47 pages, 2 publication profiles
packages measured      at-cli, at-identity, at-ingest-core, at-ingest-llm-export, at-ingest-whatsapp, at-store
platform version       0.17.0

Facts measured: outcomes=True coverage=True
```

## Your verdict was right, and the asymmetry was the lesson

V025 said *"the canonical Event preserves the source completely enough to know
what was there"*. That was true for the provider that had been reviewed hardest,
and false for the other two the adapter claims. Your rejection of that sentence
stands: it was a ChatGPT claim wearing an adapter's clothes.

**All six findings reproduced exactly as you described before anything was
changed**, then fixed, then re-verified:

**1. Malformed nested ChatGPT structure crashed with raw `AttributeError`.**
`"message": "bad"`, `"author": "bad"`, `"content": "bad"` — all three of your
cases, plus two more the fix surfaced (`parts` non-list, `role` non-string), and
a fourth crash site the review did not reach: the **node sort key** called
`.get()` on the message *before* any validation ran, so a malformed node crashed
ordering itself. Every nested field is now type-validated before it is relied
on; each bad shape is a named `ParseIssue`; the rest of the conversation still
parses. (ADR-026, RTM-117)

**2. Claude structured content silently vanished.** Your image-block fixture now
yields `structured_content: [{"type":"image","asset":"file123","meta":{"x":1}}]`
— the original JSON, untruncated, uncoerced, exactly the ChatGPT contract. This
also holds when a top-level `text` field sits *beside* the `content` list, which
real Claude exports have: taking the text no longer throws away the blocks next
to it. (RTM-118)

**3. Claude `content = "bad"` no longer becomes a successful empty Event.**
`content` must be a list of blocks, `text` and `sender` must be strings; each
violation is a reported issue. **Unknown is not empty.**

**4. Perplexity `str()` coercion is gone.** A non-string query or answer is a
`ParseIssue` naming the type and stating the value was not coerced. No Event
ever again carries `"{'text': 'question'}"` as its text. (RTM-119)

**5. The invariant is now stated once and enforced provider-neutrally.**

> Every source unit is an Event or a ParseIssue. What we understand is
> preserved. What we don't understand is reported. Nothing disappears, nothing
> is guessed, and malformed input never crashes through an implementation
> detail.

A shared test runs adversarial fixtures through all three providers and asserts
`candidate_units == events + issues`, coverage below 100% on any rejection, and
no repr-of-structure text. (RTM-116) Three new mutants re-create your three
findings; all are killed.

## The governance blocker: RTM-113 was scanning the wrong side of the boundary

The V025 Standard restated the false MkDocs rule **because RTM-113 scanned
repository files while the Standard ships outside the repository.** That gap is
closed structurally, not by editing one sentence: `release_check` now scans the
shipped outer Markdown for the RTM-112/113 claims, and the `ArtifactAuthority`
and `ManualTestIndex` sheets — exempt as "historical" through V025, which is
exactly where the V018 authority rows and "none exist" wording hid — are audited
as the current-state sheets they are. (D-103)

The V026 Standard supersedes D-070's mechanism claim explicitly. **DQ-016 stays
Partial**; nothing is published until a real allowlist/exclusion/output test
exists.

## Authority reconciliation, per your items 7–15

- Hallucination Register package row: **6 of 11 modules coded**, matching the
  generated facts, with the drift recorded in the row itself.
- **S1-10 → Superseded** by S1-20 (durable SQLite since V020).
- **S2-04 → Superseded** by S2-10 (at-identity Done).
- **S2-01 → Planned.** Its Done state carried S2-10's identity evidence; the
  misfiling is recorded on the row and in D-104. The tracker no longer says the
  work about to start is finished.
- Test Strategy `07_NonFunctional`: durable persistence **Implemented**.
  `09_ArtifactAuthority`: **V026 workbooks, ADR-001..026**. `02_ManualTestIndex`
  MT-004/MT-003/EXT-UAT-001: limits stated locally ("this test does not
  exercise…"), never as platform absence. `06_DocumentationMap` untouched —
  your wording, kept.
- MT-003, MT-004 and EXT-UAT-001 Markdown corrected in the repository —
  EXT-UAT-001 also claimed the platform stores nothing while its own Step 5
  demonstrates SQLite persistence.

## What this release claims, narrowly

The provider-neutral fidelity contract holds for the three supported providers
**against the synthetic adversarial fixtures now in the suite**. It has not been
validated against a wider corpus of real exports, and it does not add providers.
`at-evidence` remains **not started**: it may begin once your independent review
of V026 confirms the contract — the metadata says exactly that, not "fidelity is
closed".

## Next

Your V026 deep review. Then `at-evidence`. `at-consent` still needs **DQ-012 and
DQ-013** from you. **AT-056 remains Not started.**
