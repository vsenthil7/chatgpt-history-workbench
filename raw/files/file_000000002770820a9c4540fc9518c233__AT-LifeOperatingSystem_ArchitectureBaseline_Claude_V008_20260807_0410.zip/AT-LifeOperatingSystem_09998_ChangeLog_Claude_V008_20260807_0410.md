# AT-LOS V008 Change Log

## Audit findings (10 gaps, called out not silently fixed)

- **GAP-01 Critical.** ADR-001 and the V006 design document claimed CI enforcement of dependency direction and domain leakage. No CI existed; there was no `.github` directory.
- **GAP-02 High.** The first run of the new guard test found a real domain leak: `at-ingest-core` named a real person in a docstring.
- **GAP-03.** The V006 README listed 6 package directories and 1 app directory that do not exist on disk.
- **GAP-04.** Root `pyproject.toml` hardcoded `pythonpath` for exactly two packages.
- **GAP-05.** Package lists disagreed between the V006 sprint planner (12) and README (8).
- **GAP-06.** The Project Memory Standard was still the V005 twelve-register document.
- **GAP-07 High.** No module boundary specification existed; `at-conversation` had no recorded home.
- **GAP-08 High.** No canonical contracts. Field-level schemas existed for 4 objects, absent for 8.
- **GAP-09.** No technology decision record.
- **GAP-10.** Four RTM rules remain unenforced.

## Added - code

- `tests/architecture/test_boundaries.py`: 9 guard tests — layer declaration, downward-only imports, no app imports, no domain leakage, deterministic core, declared dependencies, no cycles, README accuracy.
- `.github/workflows/ci.yml`: runs pytest on push and pull request.
- `conftest.py`: discovers `packages/*/src` dynamically, so adding a package needs no root edit.
- `docs/ARCHITECTURE.md`: 275 lines. System context, module catalogue, dependency matrix with Mermaid diagram, 12 canonical contracts, 11 flows, logical storage model, extension model, error model, privacy architecture, SaaS compatibility, RTM, completion gate.
- `READ_THIS_FIRST.md`: onboarding for a new engineer or AI session.
- `docs/adr/ADR-004-architecture-guards.md`.

Test suite: **24 passed, 1 skipped**, 0.07s, no network.

## Corrected

- ADR-001 enforcement claim, with a dated note recording that it was false between V006 and V008.
- README rewritten to separate on-disk from planned. RTM-08 now fails the build on recurrence.
- `at-ingest-core` docstring domain leak.
- Project Memory Standard rewritten to V008: 16 registers, 15 rules.

## Added - documentation

- Architecture Baseline workbook, 9 sheets.
- `14_SprintTracker` gains Repository, Package/Module, Shared vs Product, Layer, Depends on, Contract in→out, ADR/Decision, Test/RTM ID. 31 rows.
- `08_Reconciliation`: every item from every register mapped to its current home.

## Decisions

D-027 architecture rules are tests, not prose · D-028 the guard-test layer map is the authoritative dependency spec · D-029 architecture lives outside Project Memory, not as a 17th register · D-030 logical storage model decided, physical engine deferred (DQ-004)

## Not done, deliberately

- No product feature was built. Only structural safeguards.
- No package published to PyPI (D-025).
- Flutter, PostgreSQL, Kafka, vector DB, microservices remain deferred with triggers in `07_TechDecisionRecord`.
- `at-conversation` recorded as UNDECIDED rather than resolved.
- ChatGPT's proposed `16_ModuleCatalogue` register was **not** added to Project Memory (D-029).

## Unchanged

V004 decision memo, evidence register, consultant analysis. V001 charter, methodology, naming and versioning standard. **AT-056 still Not started, day 2.**
