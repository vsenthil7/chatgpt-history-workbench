# AT-Life Operating System (AT-LOS) - V008

**Release:** `AT-LifeOperatingSystem_ArchitectureBaseline_Claude_V008_20260807_0410`
**Prepared by:** Claude · **07-Aug-2026 04:10 BST**
**Internal codename:** AT-LOS · **Public brand:** undecided and blocked (D-022)

## Purpose

Make the architecture explicit enough that months of coding can proceed without rediscovering where code belongs — and enforce it with tests rather than prose.

## The audit came first, and it found things

**Ten gaps, in `09_V007GapAnalysis`.** Two matter most:

**GAP-01.** ADR-001 and the V006 design document both stated that CI enforced dependency direction and domain-leakage rules. **There was no CI.** No `.github` directory existed. My own documents asserted an enforcement mechanism that was never built — the exact D-018 failure the Hallucination Register exists to prevent.

**GAP-02.** The moment the guard tests were actually written, one failed. `at-ingest-core` — the package most likely to be reused by IPBS — named a real person in a docstring. Fixed, and RTM-03 now fails the build on recurrence.

That pair is the strongest argument for ADR-004: an architecture rule that is not a test is a wish.

## What was built

**9 architecture guard tests + CI.** `python -m pytest -q` → **24 passed, 1 skipped.**

| Enforced | Rule |
|---|---|
| RTM-01 | Downward-only dependencies |
| RTM-03 | No domain vocabulary in shared packages |
| RTM-04 | Deterministic core — no network, model or randomness |
| RTM-05 | No event without a `SourceRef` |
| RTM-06 | Packages declare their dependencies |
| RTM-07 | No import cycles |
| RTM-08 | Documentation cannot claim absent code |
| RTM-09 | A new package must declare its layer |
| RTM-10, RTM-11 | No silent loss; stable unique IDs |

**11 of 15 enforced.** RTM-12 to RTM-15 are marked **NOT ENFORCED** with the task that closes each. Stated, not hidden.

## Architecture Baseline workbook

`01_ModuleCatalogue` (14 modules: layer, type, shared vs product, responsibility, **must-not-do**, inputs, outputs, prohibited deps, second consumer) · `02_DependencyMatrix` · `03_Contracts` (12 objects with ID strategy, invariants, who may create them) · `04_BoundaryRegister` · `05_ProcessingFlows` (11) · `06_ArchitectureRTM` · `07_TechDecisionRecord` (17 topics) · `08_Reconciliation` · `09_V007GapAnalysis`

`at-conversation` is now recorded — as explicitly **UNDECIDED**. Package versus service was discussed for hours across V002–V003 and had no home anywhere. It now has one, and the honest answer is that the question must not be settled until diarisation exists.

## Sprint Tracker upgraded, not replaced

`14_SprintTracker` gains seven columns: Repository · Package/Module · Shared vs Product · Layer · Depends on · Contract in→out · ADR/Decision · Test/RTM ID.

31 rows, 10 Done. `08_Reconciliation` proves no task from any register disappeared.

## Where architecture lives — and why not in Project Memory

ChatGPT proposed a `16_ModuleCatalogue` register. I deliberately did not add it. D-023 caps governance at sixteen registers, and **architecture is engineering documentation, not governance** (D-029). It lives in the Architecture Baseline workbook and `docs/ARCHITECTURE.md`, beside the code it describes, where it can be tested.

## Decisions

D-027 architecture rules are tests · D-028 the layer map in the guard tests is authoritative · D-029 architecture lives outside Project Memory · D-030 logical storage model decided, physical engine deferred

## Completion gate

`docs/ARCHITECTURE.md` §L answers all sixteen questions from the artefacts alone, with no reliance on chat history.

**Verdict: development-ready for Sprints 1–2. Not architecture-complete.** Four RTM rules unenforced; every module beyond L0/L1 is a contract on paper.

## Read in this order

1. `at-platform/READ_THIS_FIRST.md` — what exists, what does not, where code goes
2. `at-platform/docs/ARCHITECTURE.md` — the authoritative spec
3. `00040_ArchitectureBaseline` — catalogue, contracts, RTM, gap analysis
4. `00020_ProjectMemory` — `14_SprintTracker` and `10_HallucinationRegister`

## Unchanged, and it matters

**AT-056 has still not started. Day 2.**

V008 added specification and enforcement, no product capability. The risk is logged against V008 in `08_LessonsLearned`: architecture can become the next substitute for building. The measurement burns calendar time nothing else recovers.
