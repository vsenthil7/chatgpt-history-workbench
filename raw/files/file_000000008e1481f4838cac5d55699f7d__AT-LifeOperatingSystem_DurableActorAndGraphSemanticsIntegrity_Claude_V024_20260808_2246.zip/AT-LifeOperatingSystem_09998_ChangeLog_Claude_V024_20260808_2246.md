# AT-LOS V024 Change Log

**Release type:** durable actor and graph semantics. ADR-024, amending ADR-023 and ADR-020. **Store schema v1 → v2.**

## at-store

`author_label_kind` persisted; `SCHEMA_VERSION = 2`; a v1 database is refused, not reinterpreted. Contract suite extended with a `HUMAN + ROLE_ONLY` author and a cross-restart re-import idempotency test.

## at-ingest-core

`Event.meta` rejects tuples (type-unstable through storage) and non-finite floats.

## at-ingest-llm-export

`on_current_branch` is `True | False | None`. Unknown `current_node`, dangling parents and parent cycles become `ParseIssue`s. Structured content preserved in `meta.structured_content`, not merely counted.

## at-identity

`observe()` requires a typed `Participant`; `link()` still accepts a string for a deliberate operator decision.

## Architecture and tests

Purity guards derived from `deterministic`, `filesystem`, `network` and `model_calls` flags in `architecture.toml` — `at-identity` correctly declared non-deterministic. SQLite connection leaks fixed; `ResourceWarning` and `PytestUnraisableExceptionWarning` are errors. RTM-104 to RTM-111. 23 mutation cases.

## Documents

TEST_STRATEGY no longer claims no code beyond L0/L1 · READ_THIS_FIRST no longer attributes the WhatsApp 500-event verification to the LLM adapter · external troubleshooting distinguishes `acceptance` from `import --database` · external results page is source-unit aware · Project Memory current state reconciled (AT-004, AT-014) · S2-13 and S2-15 marked superseded/narrowed · the false "excluded by not being navigated to" rule removed from the Standard.

## Decisions

D-093 storage must carry the contract · D-094 type-stable values · D-095 unknown is not True · D-096 typed automatic paths · D-097 declared purity

## Open

External documentation publication boundary (Partial, since V018) · DQ-004, DQ-012, DQ-013, DQ-014 · **AT-056 Not started**.
