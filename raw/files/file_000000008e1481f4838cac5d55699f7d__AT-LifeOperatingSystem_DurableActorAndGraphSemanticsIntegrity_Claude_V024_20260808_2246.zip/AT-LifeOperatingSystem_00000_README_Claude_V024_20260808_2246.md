# AT-Life Operating System (AT-LOS) - V024

**Release:** `AT-LifeOperatingSystem_DurableActorAndGraphSemanticsIntegrity_Claude_V024_20260808_2246`
**Prepared by:** Claude · **08-Aug-2026 22:46 BST**

```
V024 — DurableActorAndGraphSemanticsIntegrity

pytest                 396 passed, 1 skipped
coverage               1247 statements, 338 branches, 100% line and branch
architecture guards    52 collected
integration (real venv) 2 collected
mutation regression    23/23 killed
RTM                    108 passing + 1 skipped + 2 not enforced = 111
modules / products     11 declared, 2 product applications
test suites            17 built, 4 declared not built (3 internal, 1 external)
documentation          45 pages, 2 publication profiles
packages measured      at-cli, at-identity, at-ingest-core, at-ingest-llm-export, at-ingest-whatsapp, at-store
platform version       0.15.0

Facts measured: outcomes=True coverage=True
```

## The blocker you found

**ADR-023 held only until an Event touched SQLite.** `label_kind` was not
persisted, so a Claude `human` author came back as `DISPLAY_NAME` and became
identity-bearing again after a restart.

The visible consequence was worse: importing the supplied Claude fixture **twice**
raised `EventCollisionError` — contradicting the CLI's own printed promise that a
second run adds nothing. You reproduced it against my own fixture, again.

`author_label_kind` is persisted. Adding it **changed what an Event record means**,
so the store schema is now **v2** and a v1 database is refused rather than
reinterpreted.

**Why 102 store tests missed it:** the round-trip test built `Participant("Alice")`
— `HUMAN + DISPLAY_NAME`, exactly the case storage could already carry.
`LabelKind` arrived in V023 and the test was not extended. That is the **third**
blocker from the same pattern, and the Standard now says a new canonical field is
added to persistence and the round-trip test in the same change.

## Five more

**`Event.meta` is type-stable.** Tuples returned from SQLite as lists, so
`restored != original`. Rejected, with the reason. Non-finite floats too.

**Unknown is not True.** `on_current_branch` was `True` for *every* node when no
`current_node` was named — two alternative siblings cannot both be on the branch.
Now `True | False | None`. And an unknown current node, a dangling parent or a
cycle becomes a visible `ParseIssue`.

**A count is not fidelity.** Mixed text + structured content kept only
`structured_parts=1`; the asset reference is now preserved in
`meta.structured_content`.

**`observe("human")` bypassed every rule.** `observe()` requires a typed
`Participant`; `link()` still takes a string, because there an operator is
deliberately asserting a display name.

**Purity guards are derived from `architecture.toml`**, not hard-coded — the
V019 gap. The widened guard immediately found something true: **`at-identity` is
not deterministic**, because person ids are random. The manifest now says so.

## The warning claim I got wrong

I said the suite was `ResourceWarning`-clean. It wasn't. The filter never fired
because a leaked connection surfaces at finalisation wrapped as
`PytestUnraisableExceptionWarning`. The leaks are fixed at source —
`with sqlite3.connect(...)` commits but does **not** close — and both warnings
are errors now.

Project Memory current state is **reconciled**, not appended to: `AT-004` and
`AT-014` no longer say Planned in one register and Done in another.

## Still open

The external documentation publication boundary, since V018. The governing text
no longer claims the mechanism works.

## at-evidence

Both durable-semantics blockers are closed. `at-consent` still needs **DQ-012 and
DQ-013** from you.

**AT-056 remains Not started.**
