VoiceBridge CTI (MoPr11) — product map figures
Document: claude_v001_MoPr11-voicebridge_salesforce_productmap_20260920_1232
Describes: voicebridge-cti v0.28.0, package hash f0f4eb4ab67d, 20 September 2026.

fig1_product_map      What the product is: Salesforce org | our service | the outside world.
fig2_call_journey     One call end to end, and the single step that is missing.
fig3_completion       Completion by capability: code status vs live evidence, with the blocker per row.
fig4_timeline         Fifteen shipped releases, nine planned ones and what blocks each.
fig5_decisions        The eight open decisions and exactly what each unlocks.

.svg  vector, hand-authored, no external references — scales to any size, edits in any vector tool,
      and prints cleanly in greyscale (every status is written in words as well as coloured).
.png  2x raster (approx 3700px wide for fig1) for slides and documents that cannot take SVG.

Status vocabulary used on every figure:
  Built and proven      evidence exists today and you can re-run it (a test, a gate, the evidence pack)
  Built, unproven live  fully tested, but every counterparty was a double we wrote
  Not built             does not exist; the blocking decision is named on the box
  Not ours              Salesforce's, a vendor's or the operator's component
