"""F33 regression: RTM current-cycle handoff must match the package version.

The V006 review found the RTM's AI-001 row still calling the V005 handoff the
"current cycle" while the package was V006, and the consistency gate passed
anyway. This test (and the matching rule in validate_consistency.py) tie the
current-cycle handoff reference to the real release so that class of stale
status cannot pass silently again.
"""

import re
import tomllib
from pathlib import Path


def _repo_root() -> Path:
    """Resolve the real repository root, even when pytest is invoked from the
    mutation harness's mutants/ sandbox (where the tests dir is mirrored but
    the doc tree is not). Walk up until a release-notes file is found."""
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "00-control").is_dir() and any(
            (parent / "00-control").glob("RELEASE-NOTES-V*.md")
        ):
            return parent
    return here.parents[1]


ROOT = _repo_root()


def _package_major_version() -> str:
    """Derive the release series ('V006', 'V007', ...) from the release dir."""
    # The release directory name embeds the version, e.g.
    # AUMNITY-CGWO-SaaS_Claude_V007_YYYYMMDD_HHMM. During development the tree
    # may be named ..._WIP; fall back to the highest RELEASE-NOTES file.
    notes = sorted(ROOT.glob("00-control/RELEASE-NOTES-V*.md"))
    assert notes, "no release notes found"
    versions = [re.search(r"V(\d+)", p.name).group(1) for p in notes]
    return "V" + max(versions, key=int)


def test_rtm_current_cycle_references_current_handoff():
    version = _package_major_version()
    rtm = (ROOT / "06-traceability/RTM.md").read_text(encoding="utf-8")
    ai_row = next(line for line in rtm.splitlines() if line.startswith("| AI-001 "))
    handoff = f"CLAUDE-{version}-HANDOFF.md"
    assert handoff in ai_row, (
        f"RTM AI-001 must reference the current-cycle handoff {handoff}; row was: {ai_row}"
    )


def test_current_handoff_file_exists():
    version = _package_major_version()
    assert (ROOT / f"08-ai/CLAUDE-{version}-HANDOFF.md").is_file()


def test_pyproject_version_is_present_and_valid():
    _package_major_version()  # ensures release notes exist and parse
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    # 0.x series: V00N maps to minor version (V007 -> 0.6.0 etc. is not strict,
    # so we only assert the version is a valid, present string). The strict
    # cross-check that matters for F33 is handoff correspondence above.
    assert isinstance(pyproject["project"]["version"], str)
    assert pyproject["project"]["version"]
