#!/usr/bin/env python3
"""Machine-detectable contradiction checks for the CGWO repository (DOC-001, ADR-004).

Checks: required files; ADR status headers; canonical-scope single source of truth;
superseded/tenant-specific vocabulary placement; manifest hash integrity; evidence
presence and gate-status cross-reference.
Exit code 0 = PASS, 1 = violations found.
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

REQUIRED = [
    "00-control/PROJECT-START.md",
    "00-control/READING-MAP.md",
    "00-control/RELEASE-NOTES-V002.md",
    "CLAUDE.md",
    "01-product/CANONICAL-SCOPE.md",
    "01-product/PRODUCT-BOUNDARY-AND-SAAS.md",
    "02-architecture/MODULARITY-AND-REUSE.md",
    "02-architecture/PLATFORM-PRIMITIVES-CONTRACT.md",
    "02-architecture/INTEGRATION-BOUNDARIES.md",
    "03-engineering/ENGINEERING-OPERATING-SYSTEM.md",
    "04-testing/TESTING-STRATEGY.md",
    "05-quality/QUALITY-GATES.md",
    "05-quality/GATE-STATUS-V002.md",
    "06-traceability/RTM.md",
    "07-planning/FIRST-BUILD-BACKLOG.md",
    "08-ai/CHATGPT-REVIEW-HANDOFF.md",
    "08-ai/CLAUDE-V002-HANDOFF.md",
    "09-governance/VERSIONING-AND-PACKAGING.md",
    "evidence/test-summary.json",
]
for rel in REQUIRED:
    if not (ROOT / rel).is_file():
        errors.append(f"missing required file: {rel}")

# --- ADR status headers -------------------------------------------------------
ADR_DIR = ROOT / "11-decisions"
adr_files = sorted(ADR_DIR.glob("ADR-*.md")) if ADR_DIR.is_dir() else []
if not adr_files:
    errors.append("no ADR files found in 11-decisions/")
STATUS_RE = re.compile(r"^Status:\s*(ACCEPTED|PROPOSED|SUPERSEDED|REJECTED)", re.MULTILINE)
for adr in adr_files:
    if not STATUS_RE.search(adr.read_text(encoding="utf-8")):
        errors.append(f"{adr.relative_to(ROOT)}: missing/invalid 'Status:' header")

# --- Canonical scope: defined once, referenced elsewhere ----------------------
DEFINING = Path("01-product/CANONICAL-SCOPE.md")
REFERENCING = [
    "00-control/PROJECT-START.md",
    "01-product/PRODUCT-BOUNDARY-AND-SAAS.md",
    "02-architecture/MODULARITY-AND-REUSE.md",
]
scope_text = (ROOT / DEFINING).read_text(encoding="utf-8") if (ROOT / DEFINING).is_file() else ""
for scope_id in ("CGWO-SCOPE-1", "CGWO-NOTOWNED-1"):
    if f"## {scope_id}" not in scope_text:
        errors.append(f"{DEFINING}: canonical id {scope_id} not defined")
    for rel in REFERENCING:
        f = ROOT / rel
        if (
            f.is_file()
            and scope_id == "CGWO-SCOPE-1"
            and scope_id not in f.read_text(encoding="utf-8")
        ):
            errors.append(f"{rel}: does not reference {scope_id}")

# --- Vocabulary placement (ADR-002, tenant neutrality) ------------------------
SELF = Path(__file__).resolve()
# Enforcement points necessarily name the tokens they forbid.
ENFORCEMENT_FILES = {
    "scripts/validate_consistency.py",
    "tests/test_architecture_guard.py",
}
EXEMPT_PREFIXES = ("10-baseline/", "11-decisions/", "evidence/provenance/")
SUPERSEDED = [re.compile(p) for p in (r"\bTEE\b", r"\bfounder\b", r"body/mind")]
PILOT = re.compile(r"\bIPBS\b")
PILOT_DOC_ALLOWLIST = {
    "00-control/PROJECT-START.md",  # names IPBS as tenant/pilot, per SaaS rule
    "00-control/RELEASE-NOTES-V002.md",
    "00-control/RELEASE-NOTES-V003.md",
    "00-control/RELEASE-NOTES-V004.md",
    "00-control/RELEASE-NOTES-V005.md",
    "00-control/RELEASE-NOTES-V006.md",
    "00-control/RELEASE-NOTES-V007.md",
    "01-product/CANONICAL-SCOPE.md",  # states the exclusion itself
    "01-product/PRODUCT-BOUNDARY-AND-SAAS.md",
    "02-architecture/INTEGRATION-BOUNDARIES.md",
    "07-planning/FIRST-BUILD-BACKLOG.md",
    "08-ai/CLAUDE-V002-HANDOFF.md",
    "08-ai/CLAUDE-V003-HANDOFF.md",
    "08-ai/CLAUDE-V004-HANDOFF.md",
    "08-ai/CLAUDE-V005-HANDOFF.md",
    "08-ai/CLAUDE-V006-HANDOFF.md",
    "08-ai/CLAUDE-V007-HANDOFF.md",
    "CLAUDE.md",
}
for path in sorted(ROOT.rglob("*")):
    if not path.is_file() or path.resolve() == SELF:
        continue
    rel = path.relative_to(ROOT).as_posix()
    if (
        rel in ENFORCEMENT_FILES
        or rel.startswith(EXEMPT_PREFIXES)
        or rel.startswith(("mutants/", "."))
        or "__pycache__" in rel
    ):
        continue
    if path.suffix not in {".md", ".py", ".json", ".ini", ".cfg", ".txt"}:
        continue
    text = path.read_text(encoding="utf-8", errors="ignore")
    in_code = rel.startswith(("src/", "tests/"))
    for rx in SUPERSEDED:
        if rx.search(text):
            errors.append(
                f"{rel}: superseded vocabulary '{rx.pattern}' outside baseline/ADRs (ADR-002)"
            )
    if PILOT.search(text) and (
        in_code or (not rel.startswith(("src/", "tests/")) and rel not in PILOT_DOC_ALLOWLIST)
    ):
        errors.append(f"{rel}: pilot-tenant name outside allowlisted pilot/evidence docs")

# --- Manifest hash integrity --------------------------------------------------
if "--skip-manifest" not in sys.argv:
    mf = ROOT / "PACKAGE-MANIFEST.json"
    if mf.is_file():
        manifest = json.loads(mf.read_text(encoding="utf-8"))
        for entry in manifest.get("files", []):
            p = ROOT / entry["path"]
            if not p.is_file():
                errors.append(f"manifest lists missing file: {entry['path']}")
            elif hashlib.sha256(p.read_bytes()).hexdigest() != entry["sha256"]:
                errors.append(f"manifest hash mismatch: {entry['path']}")
    else:
        errors.append("PACKAGE-MANIFEST.json missing")

# --- Evidence and gate-status cross-checks ------------------------------------
summary_path = ROOT / "evidence/test-summary.json"
if summary_path.is_file():
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    if summary.get("tests_passed", 0) <= 0 or summary.get("tests_failed", 1) != 0:
        errors.append("evidence/test-summary.json does not record a fully passing suite")
    for key in ("coverage_line_percent", "coverage_branch_percent"):
        if summary.get(key) != 100.0:
            errors.append(f"evidence: {key} is not 100 (G04)")
# --- Stale-version rule (V004 review, F26): current canonical docs must not
# embed "as of V00N" implementation-status references; history files may.
STALE_VERSION_RE = re.compile(r"as of V\d+")
CANONICAL_DOC_DIRS = ("01-product/", "02-architecture/")
CANONICAL_DOC_FILES = {"06-traceability/RTM.md", "00-control/READING-MAP.md"}
for path in sorted(ROOT.rglob("*.md")):
    rel = path.relative_to(ROOT).as_posix()
    is_canonical = rel.startswith(CANONICAL_DOC_DIRS) or rel in CANONICAL_DOC_FILES
    if is_canonical and STALE_VERSION_RE.search(path.read_text(encoding="utf-8")):
        errors.append(
            f"{rel}: stale 'as of V00N' status reference in a current canonical doc (F26); point at an RTM row instead"
        )

# --- Overclaim heuristic (V003 review): strong bypass-immunity claims must be
# backed by the adversarial construction suite actually attacking raw values.
OVERCLAIM_PHRASES = ("every construction path", "cannot be bypassed")
rtm_text = (
    (ROOT / "06-traceability/RTM.md").read_text(encoding="utf-8")
    if (ROOT / "06-traceability/RTM.md").is_file()
    else ""
)
if any(phrase in rtm_text for phrase in OVERCLAIM_PHRASES):
    adversarial = ROOT / "tests/test_adversarial_construction.py"
    if not adversarial.is_file():
        errors.append(
            "RTM claims construction-path immunity but tests/test_adversarial_construction.py is missing"
        )
    else:
        attack_text = adversarial.read_text(encoding="utf-8")
        if 'state="X"' not in attack_text or '"EXECUTION"' not in attack_text:
            errors.append(
                "adversarial suite no longer contains the raw-value attack payloads backing the RTM immunity claim"
            )

gate_status = ROOT / "05-quality/GATE-STATUS-V007.md"
if gate_status.is_file() and "evidence/test-summary.json" not in gate_status.read_text(
    encoding="utf-8"
):
    errors.append(
        "GATE-STATUS-V002.md must reference evidence/test-summary.json, not hand-typed counts"
    )

# --- Current-cycle rule (V006 review, F33): the RTM AI-001 row must reference
# the current release series' handoff, derived from the newest release notes.
release_notes = sorted((ROOT / "00-control").glob("RELEASE-NOTES-V*.md"))
if release_notes:
    series = "V" + max((re.search(r"V(\d+)", p.name).group(1) for p in release_notes), key=int)
    rtm_path = ROOT / "06-traceability/RTM.md"
    if rtm_path.is_file():
        ai_rows = [
            line
            for line in rtm_path.read_text(encoding="utf-8").splitlines()
            if line.startswith("| AI-001 ")
        ]
        expected_handoff = f"CLAUDE-{series}-HANDOFF.md"
        if not ai_rows:
            errors.append("RTM has no AI-001 row for the current-cycle check (F33)")
        elif expected_handoff not in ai_rows[0]:
            errors.append(
                f"RTM AI-001 does not reference the current-cycle handoff "
                f"{expected_handoff} (F33 stale-status blind spot)"
            )
        if not (ROOT / f"08-ai/{expected_handoff}").is_file():
            errors.append(f"current-cycle handoff missing: 08-ai/{expected_handoff}")

if errors:
    print("CONSISTENCY: FAIL")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("CONSISTENCY: PASS")
