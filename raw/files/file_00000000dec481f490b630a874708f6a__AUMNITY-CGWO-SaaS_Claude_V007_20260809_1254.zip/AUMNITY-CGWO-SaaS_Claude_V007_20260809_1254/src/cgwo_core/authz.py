"""Authorization trust boundary (ADR-014, review findings F30/F32).

The V006 review proved that an in-process Python object — even a genuine,
exact-typed, frozen dataclass — cannot be a tenant-authorization anchor:
``object.__setattr__`` mutates a genuine instance after validation, and a
hostile ``__getattribute__`` subclass lies about attributes. Therefore
tenant AUTHORITY must never be inferred from the contents of a domain object
the caller supplied.

This module defines the boundary where authority is established instead.
``AuthorizationContext`` carries an authenticated ``principal`` and the
*entitlements* (tenant ids the principal may act for) that a trusted
service/identity layer has already established. The domain core consumes this
port; it does not implement authentication. ``StaticAuthorizationContext`` is
a reference implementation whose entitlements are fixed at construction from
trusted caller input — suitable for tests and as a contract, NOT a production
identity system.

Crucially, authorization is decided by membership in the authenticated
entitlement set, which a caller-supplied ``TenantContext`` value cannot
change: relabeling a value object does not grant authority.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from cgwo_core.errors import (
    F_TENANT_ID,
    FIELD_BLANK,
    NOT_ENTITLED,
    WRONG_RUNTIME_TYPE,
    DomainError,
    build,
)
from cgwo_core.validation import require_str


class AuthorizationError(DomainError):
    """Raised when an authenticated principal is not entitled to a tenant."""


@runtime_checkable
class AuthorizationPort(Protocol):
    """The contract a real service authorization layer implements.

    Implementations bind ``principal`` and ``entitlements`` to authenticated
    identity/claims. The domain core only asks: is ``tenant_id`` among the
    entitlements of this authenticated principal?
    """

    @property
    def principal(self) -> str: ...

    def is_entitled(self, tenant_id: str) -> bool: ...


class StaticAuthorizationContext:
    """Reference AuthorizationContext with fixed entitlements (ADR-014).

    Entitlements are frozen at construction. There is no setter; a relabeled
    ``TenantContext`` or a mutated aggregate cannot alter what this principal
    is entitled to. Not a production identity system — a contract/reference.
    """

    __slots__ = ("_entitlements", "_principal")

    _principal: str
    _entitlements: frozenset[str]

    def __init__(self, principal: str, entitlements: frozenset[str] | set[str]) -> None:
        checked_principal = require_str(principal, "principal", AuthorizationError)
        if not checked_principal.strip():
            raise build(AuthorizationError, FIELD_BLANK, field="principal")
        # Copy into a frozenset of exact-str entitlements; reject hostile members.
        checked = frozenset(
            require_str(entry, "entitlement", AuthorizationError) for entry in entitlements
        )
        self._principal = checked_principal
        self._entitlements = checked

    @property
    def principal(self) -> str:
        return self._principal

    def is_entitled(self, tenant_id: str) -> bool:
        # Exact-str comparison against the authenticated entitlement set.
        checked = require_str(tenant_id, F_TENANT_ID, AuthorizationError)
        return checked in self._entitlements


def assert_authorized(authz: AuthorizationPort, tenant_id: str) -> None:
    """Deny an operation unless the authenticated principal is entitled.

    This is the real security decision (ADR-014). It depends only on the
    authenticated entitlement set, never on a caller-supplied domain object's
    attributes, so post-construction mutation or a lying subclass cannot
    manufacture authority.
    """
    if not isinstance(authz, AuthorizationPort):
        raise build(
            AuthorizationError,
            WRONG_RUNTIME_TYPE,
            field="authz",
            expected="AuthorizationPort",
            actual=type(authz).__name__,
        )
    checked = require_str(tenant_id, F_TENANT_ID, AuthorizationError)
    if not authz.is_entitled(checked):
        raise build(AuthorizationError, NOT_ENTITLED, tenant_id=checked)
