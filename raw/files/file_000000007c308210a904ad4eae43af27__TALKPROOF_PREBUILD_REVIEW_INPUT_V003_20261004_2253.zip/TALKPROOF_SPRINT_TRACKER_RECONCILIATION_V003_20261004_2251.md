# TalkProof — SPRINT TRACKER RECONCILIATION — V003

| Field | Value |
|---|---|
| **Created** | 2026-10-04 22:51 (Europe/London) |
| **Version** | V003 (supersedes V002 and V001 of the same name; both retained unchanged) |
| **Status** | RECONCILIATION RECORD — classifies every implementation gap against the EXISTING tracker; proposes tracker corrections; creates no sprint and no ticket ID (proposed ticket labels are marked PROPOSED) |
| **Source artifacts** | docs/92_planning/SPRINT_TRACKER.md (read in full: header, index S01–S59 + Q01–Q07, A-series block, every S/Q section, enhancement backlog); TRACEABILITY.md (§1–5, sprint completion status, A-series chronology); _plan_S45..S59 files; V6 Parts 38–41 (CD-01..17, G-rows); project ways-of-working (close from lowest number; plan-first; commit-first) |
| **Scope** | Every implementation gap classified into the five PO categories; duplicates; dependency order; tracker inconsistencies found while reading |
| **Explicit exclusions** | No new sprint number; no ticket executed; no code |
| **Decisions consumed** | D-01, D-03, D-04, D-05, D-07, D-08, D-10, D-11, D-12, D-13, D-17, D-19, D-20, D-22, D-23, D-24, D-25, D-26 |
| **Unresolved items** | Items blocked on D-06/D-16/D-18/D-21 are classified category 5 or 4-conditional; PO to accept the proposed tracker corrections |
| **Change / provenance** | V002: docs-only correction pass authorised by the PO 22:43 after independent review R-01..R-10 (see "V002 change note" at the end). V001 created in the 2026-10-04 pre-build pass authorised by the Product Owner decision record of 22:02; author: Claude (builder); no source artefact modified; no code changed; no V7 created. |

## 0. Did the backend ZIP contain the complete tracker?

Yes. `docs/92_planning/SPRINT_TRACKER.md` (272,802 bytes; header with the timing standard; index of S01–S59 and Q01–Q07; April-pilot A00–A34 block; one section per sprint; Q-series; enhancement backlog "(none yet)") and `TRACEABILITY.md` (101,216 bytes; BR-01..BR-19; RT-01..RT-59; forward/reverse trace; sprint completion status S01–S46, S59, Q04–Q07; A-series chronology) were both read in full. Also present and read: `_plan_S45_M27…`, `_plan_S46_M28…`, `_plan_S47_M29…`, `_plan_S59_I02…`, `_plan_reslice_microsprints_S46plus.md`, `talkproof_sprint_traceability.xlsx` (not opened; the .md files are canonical per the tracker header).

## 1. Tracker inconsistencies found while reading (corrections proposed; tracker owner applies)

| # | Where | Finding | Proposed correction |
|---|---|---|---|
| TC-1 | Index row S47 | Status "☐ TODO", but the S47 section records **M29-T01 ☑ DONE 2026-06-29 `38b4c12`** and the ZIP contains `services/transcription/base.py` (T01). T02 (`WhisperAdapter`) is **not** in the ZIP. | Index S47 → "◐ IN-PROGRESS 1/5 (M29-T01 done)"; Started = 2026-06-29. |
| TC-2 | TRACEABILITY "Sprint completion status" | No rows for S47–S58 (S59 present). | Add S47–S58 rows mirroring the index (S52–S55 SUPERSEDED). |
| TC-3 | S12 completion note vs tickets | M11-T06 "Tamper-proof certification (hash + RFC3161 timestamp / blockchain anchor)" is ☑, but the note says anchoring "populates `anchor_tx_id` at deployment via BYO provider" and TSA is absent in code (V6 row 17 D1, row 18 D2; CD-13). The ticket is marked done for work that was carried forward. | Re-mark M11-T06 as "◐ PARTIAL — hash only; TSA/anchor/per-call PDF carried forward (CD-13)" and add a D-actual note per CR-01 principle. Same for M11-T05 (per-call certified PDF absent; PDF is campaign-level). |
| TC-4 | S21 completion note | `require_consent` → 451 is described as built; it has no production caller (CD-08); DNC absent (G36). | Mark M20-T0x consent enforcement "◐ PARTIAL — service exists, not wired to call/message paths". |
| TC-5 | S20 | Resilience primitives "built"; nothing wrapped (G28). | Mark M19 resilience ticket "◐ PARTIAL — primitives only". |
| TC-6 | S23 | "AIInteractionLedger persists every governed AI interaction" — true for M07 only; orchestrator calls bypass (CD-11). | Mark M22-T0x "◐ PARTIAL — M07 only; orchestrator not ledgered". |
| TC-7 | S13 | "BYO-carrier abstraction (twilio/telnyx/vonage/exotel)" — all `_dial`/`_provision_number` are fakes (G14/G15). | Add note "seam only; no real carrier adapter". |
| TC-8 | S06 | "Fernet-encrypted keys… ProviderRouter" — vault write-only, router results discarded (CD-04). | Mark M05-T03 router "◐ PARTIAL — resolve path unused". |
| TC-9 | S33 | "Introduced the storage writer the codebase was missing" — adapters exist, no production writer (CD-10). | Mark M23 "◐ PARTIAL — no production caller". |
| TC-10 | S45 EPIC row | Status "☐ EPIC (re-sliced → S46–S51 + S43 + S33)" — correct; add that S46 is the only closed child. | Note only. |
| TC-11 | Q01 | Route-coverage hardening lists webhooks 57 %, scim 80 %, billing 89 % (June) — superseded by current 99.74 % with 23 uncovered lines (CD-17). | Refresh Q01 scope to the E-01 §J list of 23 lines or close as superseded. |
| TC-12 | Enhancement backlog | Empty — no staging feedback ever recorded (consistent with EV-04: no deployment). | Note only. |

None of these changes a requirement or a D-level; they align the tracker with code facts (BR-11 principle).

## 2. Gap classification — the five PO categories

**Category 1 — EXISTING SPRINT, incomplete implementation**

| Gap (V6 ref) | Sprint / ticket(s) | What remains | Blocked by |
|---|---|---|---|
| Transcription adapter + config-driven engine (CD-09, G11/G12, row 15) | S47 M29-T02..T05 | WhisperAdapter (byte-identical), registry + resolver wiring, Google STT real adapter, cost hook; diarisation/confidence columns | none |
| Reviewer roster abstraction (row 14, G03/G04) | S48 M30-T01..T06 | adapters, roster from config, per-language mix, **T05 must implement FR-040 as written (D-04)**, CD-16 fix | none |
| Keys → vault (CD-04, G04, row 8) | S49 M31-T01..T05 | ProviderRouter.resolve for all pipeline keys; remove `os.environ` reads; metering/spend cap | none (security — first) |
| Voting strategy (row 14) | S50 M32-T01..T05 | interface + strategies; HUMAN_REVIEW path per D-04 | none |
| Certification provider abstraction (rows 17–18) | S51 M33-T01..T05 | interface, IOTA adapter (declare dep, CD-06), **TSA adapter (T04)**, provider via config | **D-06 and D-16 for the ordering/record format; T01–T02 (interface + IOTA adapter + CD-06) can proceed** |
| Pipeline config E2E + `PIPELINE_CONFIGURABILITY.md` | S45 close | after children | S47–S51 |
| Storage writer wired to recording path (CD-10, row 24/43) | S33 M23 (re-open) | production caller in orchestrator `_download_recording`; Object Lock (NFR-045) | none for writer; Object Lock needs infra (EV-04) |
| Consent enforcement + DNC (CD-08, G36, row 38) | S21 M20 (re-open) | wire `require_consent` to call/message initiation; DNC list; consent id into evidence | none |
| Rate limiting conformance (CD-08, row 40) | S21 M20 | the existing `RateLimitMiddleware` is an in-process fixed-window counter keyed by client IP with a single default limit of 100 and no `Retry-After` — **non-conformant to FR-080 and must NOT merely be wired**; WP-10 must implement the complete FR-080 contract: Redis token bucket, 100 req/min per authenticated user keyed per-tenant-per-user, 20 req/min per IP unauthenticated, `Retry-After` on 429, health/metrics exempt, exact security headers incl. HSTS 63072000, Flutter 429 backoff (R-04/R-05) | Redis available in the test environment (declared in compose) |
| SLA escalation caller (CD-08, row 10) | S07 M06 | scheduler/worker calls escalation | none (Phase-1 poll acceptable) |
| Resilience wrapping (G28, row 35) | S20 M19 | wrap provider calls in CircuitBreaker per NFR-046 | none |
| SIEM exporter caller (CD-08, row 7) | S05 M04 | schedule/trigger export | none |
| Tier A RLS policies + migration (row 1) | S02 M01 | policies, session variable event, dual-layer test (NFR-038) | none |
| Per-call certificate: anchor + PDF + TSA in issue flow (CD-13, rows 16–20) | S12 M11-T05/T06 (re-open) | per lifecycle | **D-06 (ordering), D-16 (record), S51 adapters** |
| WhatsApp outbound Graph adapter + inbound contract conformance (row 44, EV-03) | S34 M24 | real `_send` from Meta Graph docs; add Meta GET `hub.verify_token` handshake (absent); inbound POST: accept only `sha256=<hex>` (code currently also accepts a bare digest, `routes/webhooks.py:57`); add the missing negative contract test (bare digest rejected). Inbound stays D3 until the strict-format conformance + negative test exist (V6-09; tally unchanged) | **PD-A (BRD OOS-02 vs tracker BR-14 authority) — R-06**; Meta sandbox for D4 |
| Telegram (G27) | S56 M38 | all | none (P2 backlog; BR-19 tracker-only — PD-A) |
| Consensus dedup (G48 note) | S57 M39 | helper | none |
| Cost model doc | S58 M40 | docs | none; E-05 data later |
| Flutter iOS/desktop targets, native plugins (CD-14, rows 31/32) | S17/S19/S29 (re-open) | `ios/`, desktop targets, plugins | Flutter SDK + signing (BRD C-05) |
| WebSocket transport / LiveKit / push dispatch (rows 26, 28, 30) | S14/S15/S16 | real transports | none (P2) |

**Category 2 — EXISTING SPRINT, conformance defect (requirement unchanged; code must conform)**

| Defect | Sprint | Requirement / decision |
|---|---|---|
| CD-01 Exotel attr + relative callback | S43 | FR-056, BR-16 |
| CD-02 Stripe signature scheme | S09 | FR-042 |
| CD-03 OIDC/SAML validation | S03 | FR-015/016 |
| CD-05 `dev-secret` defaults | S21/S34/S09 | NFR-025 |
| CD-06 `iota_client` undeclared | S51-T02 | NFR-023 |
| CD-07 audit chain race | S05 | FR-022/NFR-034 |
| CD-11 orchestrator ledger bypass; model version | S23 | M22 scope, NFR-065 (independent of D-18) |
| CD-12 blocking sleeps | S12/S45 | NFR-001 |
| CD-16 Gemini tokens; fence stripping | S48 | FR-040, NFR-065 |
| D-01 HS256 → RS256 | S03 | FR-012/NFR-014 |
| D-08 lockout 15→30 min; impersonation 60→120 min | S03, S10 | FR-011, FR-045 |
| D-05 persisted vocabulary | S48/S44 | FR-040 |
| D-04 one-failure tolerance; 30-s timeout | S48 | FR-040/053 |
| CD-17 coverage gate red | S24 policy | NFR-057 / D-11 — NFR-057 = 80 % requirement floor; `fail_under=100` is the existing stricter engineering policy and stays unless the PO changes that policy; the conformance action is to cover the 23 lines (R-09 of the review) |
| **HSTS header `max-age=31536000` (code `core/security_middleware.py:24`) vs FR-080 `max-age=63072000; includeSubDomains`** — missed in V001 | S21 M20 | FR-080 (R-05) |
| Rate limiter is an in-process fixed-window counter keyed by client IP, single default limit 100, no `Retry-After` (`core/security_middleware.py:4,38-65`) vs FR-080 (Redis token bucket; 100/min authenticated per tenant-per-user; 20/min unauthenticated per IP; `Retry-After`; health/metrics exempt) | S21 M20 | FR-080 (R-04) — wiring the existing limiter does not conform |
| CD-14 README stale | docs | G51 |

**Category 3 — EXISTING SPRINT, verification/evidence missing (code may be right; D-level cannot rise without evidence)**

| Item | Sprint | Evidence needed (EV) |
|---|---|---|
| Live model/Whisper responses (rows 14/15) | S12/S48 | EV-01 recorded live run |
| Exotel webhook semantics, recording URL (rows 22/23/46) | S43/S31 | EV-02 carrier docs + staging capture |
| Meta inbound with real secret; outbound (row 44) | S34 | EV-03 |
| Deployment logs, RLS dump, buckets (rows 1, 7, 43) | ops | EV-04 |
| Flutter `integration_test`, admin Playwright (rows 31–33) | S29/S30/S32/S36, S28/S35 | EV-05 live-stack run logs |
| Tracker/traceability quotations line-revalidation | docs | EV-06 |
| DR restore test record; `backup.sh` (row 36) | S20 | EV-07 |
| E-02 token-level (real TSA) | S51-T04 | staging TSA call |

**Category 4 — NEW APPROVED REQUIREMENT requiring future sprint work** (only requirements that exist by an approved PO decision; CRs are not here until governance issues IDs)

| Requirement (provenance) | Nearest existing sprint home | New sprint needed? |
|---|---|---|
| RC-11 provider configuration through the product (D-13) | S45 EPIC + S35 (admin tenant-config page) | **No** — S45 children + S35 extension |
| RC-10 FR-054(1) evidence bindings (D-12) | S12 M11 (re-open) | **No** — S12 extension; ordering after D-06 |
| RC-02 provider-neutral anchor (D-03) / RC-05 carrier (D-07) | S51 / S43 | **No** |
| RC-15 cross-tenant constraint (D-19), RC-16 training gate (D-20), RC-14 autonomy policy (D-17) | none (constraints) | **No** — no code |

**Category 5 — DEFERRED / NOT APPROVED**

| Item | Why |
|---|---|
| All CR-01..CR-23 implementation | selection ≠ approval; IDs not issued |
| Lifecycle (ERS, two timestamps, status service, verifier) | D-06/D-16/D-18/D-21 open |
| CR-10, 16–22 | deferred by D-22 |
| Celery Phase 2 | AD-4 |
| Graph DB | D-24 (after E-03) |
| AI pentest | D-25 |
| Scorecard customer-facing | D-23 |
| S39 repo-split/coordination model | tracker: ◐ DECIDED, blocked on team onboarding (project rule: not to be force-executed) |
| S56 Telegram | P2 backlog; BR-19 is tracker-only until PD-A |

## 3. Duplicate work identified

| Duplicate | Resolution |
|---|---|
| M27-T09 vs S57 M39 (consensus dedup) | tracker already routes to S57 — keep |
| S52–S55 vs S44 M26-T01..T08 | tracker marks S52–S55 SUPERSEDED — keep |
| S45 M27-T01 vs S46 M28 | S46 done; M27-T01 satisfied — note in S45 |
| CR-03 adapter standard vs G45 vs S45 children | CR-03 is the standard; S47–S51 are the adapters; no duplicate ticket — the standard governs their acceptance |
| CR-15 vs CD-11 | CD-11 is S23 conformance now; CR-15 extends later — not the same ticket |
| CR-12 verifier vs FR-055 "Verify Now" vs `verify_certificate` endpoint | three layers of one capability; S12/S17 own FR-055; CR-12 adds the standalone artefact |
| Q01 route coverage vs CD-17 | same objective; Q01 scope stale (TC-11) |

## 4. Dependency order (lowest sprint number first where independent — project rule)

1. Conformance on closed platform sprints with no decision dependency: S02 (RLS), S03 (D-01, D-08, CD-03), S05 (CD-07, SIEM caller), S06 (CD-04 read path), S07 (SLA caller), S09 (CD-02, CD-05), S10 (D-08), S20 (wrapping), S21 (consent/DNC, FR-080-conformant rate limiting, HSTS, CD-05), S23 (CD-11), S33 (writer). S34 (handshake, strict signature format + negative test, CD-05 secret default) — code conformance is decision-free, but S34's **authority** is blocked on PD-A (R-06); only the CD-05 secret-default removal proceeds under NFR-025.
   The tracker corrections TC-1..TC-12 are **documentation reconciliation after PO acceptance**, not a build item (R-07).
2. S45 children in tracker order: S47 (T02–T05) → S48 (incl. D-04/D-05/CD-16) → S49 (keys) → S50 → S51 T01–T02 (+CD-06) → S43 CD-01.
3. S51 T03–T05 (TSA + provider-from-config + lifecycle) and S12 M11-T05/T06 re-open — **after D-06 and D-16**.
4. S45 close (E2E config, `PIPELINE_CONFIGURABILITY.md`).
5. S56, S57, S58, Q01 refresh — P2, any time after 1–2.
6. Frontend re-opens (S17/S19/S29) — after a Flutter SDK verification environment and signing certificates exist.
7. Evidence runs (category 3) — as soon as a staging environment exists (EV-04).

## 5. Totals
Category 1: 20 items · Category 2: 17 (V002: + HSTS, + FR-080 limiter non-conformance) · Category 3: 8 · Category 4: 4 (0 new sprints) · Category 5: 9 · Tracker corrections proposed: 12 · New sprint numbers created: **0** · Ticket IDs created: **0** (conformance tickets to be added by the tracker owner inside the existing sprints, numbered by the tracker owner).


---
## V002 change note
R-03: WhatsApp row restated with the full inbound facts (bare digest accepted, negative test missing, GET handshake absent); D3 inbound and the tally unchanged per V6-09. R-04: FR-080 limiter non-conformance registered. R-05: HSTS 31536000 vs 63072000 registered. R-06: S34 authority blocked on PD-A. R-07: TC-1..TC-12 moved out of build sequencing. WP-22/D-11: engineering gate not to be lowered; cover the lines. Category 2 count 15 → 17.


---
## V003 change note
Final-gate residual 1: the stale Category-1 row "wire RateLimitMiddleware / none" conflicted with the corrected R-04 finding; replaced with the consistent statement that the existing in-process fixed-window/IP limiter is non-conformant and WP-10 must implement the complete FR-080 Redis token-bucket contract. No other change.
