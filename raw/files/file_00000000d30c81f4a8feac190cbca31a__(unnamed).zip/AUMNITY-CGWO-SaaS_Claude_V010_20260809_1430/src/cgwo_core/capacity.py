"""Availability declarations and capacity windows (ADR-002 capacity types).

Protected operation vs pure value calculation (ADR-009): value-object
construction and pure comparisons such as :func:`windows_overlap` operate on
already-authorised objects and take no ``TenantContext``; operations that
*reveal or mutate* aggregate data across a boundary (e.g.
``AvailabilityDeclaration.guarded_window``) require an explicit context.
Runtime type integrity per ADR-010: enum/date/int/str fields reject malformed
runtime values at construction, so identity comparisons inside pure functions
are safe.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from enum import Enum

from cgwo_core.authz import AuthorizationPort
from cgwo_core.errors import (
    AVAILABLE_MINUTES_NEGATIVE,
    DECLARATION_RESOURCE_MISMATCH,
    DECLARATION_TENANT_MISMATCH,
    F_AVAILABLE_MINUTES,
    F_CAPACITY_TYPE,
    F_DECLARED_ON,
    F_ONE,
    F_OTHER,
    F_PERIOD_END,
    F_PERIOD_START,
    F_RESOURCE_REF,
    F_TENANT_ID,
    F_WINDOW,
    FIELD_BLANK,
    PERIOD_ORDER,
    DomainError,
    build,
)
from cgwo_core.tenancy import TenantContext, assert_tenant_operation
from cgwo_core.validation import (
    require_aggregate,
    require_date,
    require_enum,
    require_exact_instance,
    require_int,
    require_str,
)


class CapacityType(str, Enum):
    """Generalised capacity kinds per ADR-002. Tenants may extend by policy later."""

    EXECUTION = "EXECUTION"
    SUPERVISORY = "SUPERVISORY"


class CapacityInvariantError(DomainError):
    """Raised when a capacity value object violates a domain invariant."""


def _validate_window(
    tenant_id: object,
    resource_ref: object,
    period_start: object,
    period_end: object,
    available_minutes: object,
    capacity_type: object,
) -> None:
    checked_tenant = require_str(tenant_id, F_TENANT_ID, CapacityInvariantError)
    if not checked_tenant.strip():
        raise build(CapacityInvariantError, FIELD_BLANK, field=F_TENANT_ID)
    checked_resource = require_str(resource_ref, F_RESOURCE_REF, CapacityInvariantError)
    if not checked_resource.strip():
        raise build(CapacityInvariantError, FIELD_BLANK, field=F_RESOURCE_REF)
    checked_start = require_date(period_start, F_PERIOD_START, CapacityInvariantError)
    checked_end = require_date(period_end, F_PERIOD_END, CapacityInvariantError)
    if checked_end < checked_start:
        raise build(CapacityInvariantError, PERIOD_ORDER)
    checked_minutes = require_int(available_minutes, F_AVAILABLE_MINUTES, CapacityInvariantError)
    if checked_minutes < 0:
        raise build(CapacityInvariantError, AVAILABLE_MINUTES_NEGATIVE)
    require_enum(capacity_type, CapacityType, F_CAPACITY_TYPE, CapacityInvariantError)


def windows_overlap(one: CapacityWindow, other: CapacityWindow) -> bool:
    """Pure value comparison (ADR-009): do two windows compete for capacity?

    Windows in different tenants never compete; this is a domain fact about
    capacity pools, not an access-control decision. Enum identity comparison
    is safe because construction rejects non-enum capacity types (ADR-010).

    Both arguments are runtime-validated as CapacityWindow before any attribute
    read (F42): a malformed argument raises a controlled DomainError, not an
    incidental AttributeError. This is API/invariant hygiene, not security.
    """
    require_aggregate(one, CapacityWindow, F_ONE, CapacityInvariantError)
    require_aggregate(other, CapacityWindow, F_OTHER, CapacityInvariantError)
    if one.tenant_id != other.tenant_id:
        return False
    if one.resource_ref != other.resource_ref:
        return False
    if one.capacity_type is not other.capacity_type:
        return False
    return one.period_start <= other.period_end and other.period_start <= one.period_end


@dataclass(frozen=True, slots=True)
class CapacityWindow:
    """Realistic effort available for one resource, period and capacity type."""

    tenant_id: str
    resource_ref: str
    period_start: date
    period_end: date
    available_minutes: int
    capacity_type: CapacityType = CapacityType.EXECUTION

    def __post_init__(self) -> None:
        _validate_window(
            self.tenant_id,
            self.resource_ref,
            self.period_start,
            self.period_end,
            self.available_minutes,
            self.capacity_type,
        )

    def overlaps(self, other: CapacityWindow) -> bool:
        """Pure value comparison; see :func:`windows_overlap` (ADR-009)."""
        return windows_overlap(self, other)


def _validate_declaration(
    tenant_id: object, resource_ref: object, window: object, declared_on: object
) -> None:
    checked_tenant = require_str(tenant_id, F_TENANT_ID, CapacityInvariantError)
    checked_resource = require_str(resource_ref, F_RESOURCE_REF, CapacityInvariantError)
    checked_window = require_exact_instance(
        window, CapacityWindow, F_WINDOW, CapacityInvariantError
    )
    require_date(declared_on, F_DECLARED_ON, CapacityInvariantError)
    if checked_tenant != checked_window.tenant_id:
        raise build(CapacityInvariantError, DECLARATION_TENANT_MISMATCH)
    if checked_resource != checked_window.resource_ref:
        raise build(CapacityInvariantError, DECLARATION_RESOURCE_MISMATCH)


@dataclass(frozen=True, slots=True)
class AvailabilityDeclaration:
    """A resource's statement of expected contribution for a window."""

    tenant_id: str
    resource_ref: str
    window: CapacityWindow
    declared_on: date

    def __post_init__(self) -> None:
        _validate_declaration(self.tenant_id, self.resource_ref, self.window, self.declared_on)

    def guarded_window(self, authz: AuthorizationPort, ctx: TenantContext) -> CapacityWindow:
        """Protected operation (ADR-009/ADR-014): reveal the window to an
        authorized principal operating within the owning tenant."""
        assert_tenant_operation(authz, ctx, self.tenant_id)
        return self.window
