"""Canonical manifest inclusion/exclusion policy (F43 — single source of truth).

Both `gen_manifest.py` (which WRITES the manifest) and `validate_consistency.py`
(which CHECKS it) import `managed_files` from here, so the set of files that
"should be in the manifest" is defined in exactly one place and the two tools
cannot drift. The V009 review (F43) showed hash-only validation is one-way: it
proved every LISTED file still hashed correctly but never proved every SHIPPED
managed file was LISTED, so an unmanifested `EXTRA.txt` passed. Closing the set
requires both tools to agree on membership, which is what this module provides.
"""

from __future__ import annotations

from pathlib import Path

# Directories whose entire subtree is never managed (build/test caches).
EXCLUDE_DIRS = {"mutants", "__pycache__", ".pytest_cache", ".ruff_cache"}
# Files excluded by basename anywhere in the tree. The outer manifest cannot
# hash itself; a nested baseline manifest is the baseline's own concern; the
# coverage db is a build artifact.
EXCLUDE_FILES = {"PACKAGE-MANIFEST.json", ".coverage"}


def is_managed(rel: Path) -> bool:
    """Return True if the repo-relative path should appear in the manifest."""
    if any(part in EXCLUDE_DIRS or part.startswith(".") for part in rel.parts):
        return False
    return rel.name not in EXCLUDE_FILES


def managed_files(root: Path) -> list[str]:
    """The canonical sorted list of managed repo-relative POSIX paths."""
    managed: list[str] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if is_managed(rel):
            managed.append(rel.as_posix())
    return managed
