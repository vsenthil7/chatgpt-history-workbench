"""F43 regression: package-manifest integrity is CLOSED over the shipped set.

The V009 review showed hash-only validation is one-way — it proved every listed
file still hashed correctly but never that every shipped managed file was
listed, so an unmanifested EXTRA.txt passed. These tests exercise the SHIPPED
validator against a temporary copy so the closed-set rule itself is anchored,
and assert the generator and validator share one membership policy.
"""

import json
import shutil
import subprocess
import sys
from pathlib import Path


def _repo_root() -> Path:
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "00-control/RELEASE-IDENTITY.json").is_file():
            return parent
    return here.parents[1]


ROOT = _repo_root()


def _copy_package(tmp_path: Path) -> Path:
    dest = tmp_path / ROOT.name
    shutil.copytree(ROOT, dest)
    for junk in ("mutants", ".pytest_cache", ".ruff_cache", ".mypy_cache"):
        p = dest / junk
        if p.is_dir():
            shutil.rmtree(p)
    return dest


def _run_validator(pkg: Path, *extra: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "scripts/validate_consistency.py", *extra],
        cwd=pkg,
        capture_output=True,
        text=True,
        check=False,
    )


def test_manifest_matches_shared_policy():
    """The manifest's file set equals the shared policy's managed set (F43)."""
    sys.path.insert(0, str(ROOT / "scripts"))
    from manifest_policy import managed_files

    manifest = json.loads((ROOT / "PACKAGE-MANIFEST.json").read_text(encoding="utf-8"))
    listed = {e["path"] for e in manifest["files"]}
    assert listed == set(managed_files(ROOT))
    assert manifest["file_count"] == len(listed)


def test_unmanifested_file_fails_validation(tmp_path):
    """The exact F43 attack: an extra file added after manifest generation."""
    pkg = _copy_package(tmp_path)
    (pkg / "EXTRA.txt").write_text("junk\n")
    result = _run_validator(pkg)  # full manifest check (no --skip-manifest)
    assert result.returncode != 0
    assert "F43" in result.stdout
    assert "EXTRA.txt" in result.stdout


def test_duplicate_manifest_entry_fails(tmp_path):
    pkg = _copy_package(tmp_path)
    mf = pkg / "PACKAGE-MANIFEST.json"
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    manifest["files"].append(dict(manifest["files"][0]))  # duplicate first entry
    mf.write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F43" in result.stdout


def test_wrong_file_count_fails(tmp_path):
    pkg = _copy_package(tmp_path)
    mf = pkg / "PACKAGE-MANIFEST.json"
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    manifest["file_count"] = manifest["file_count"] + 100
    mf.write_text(json.dumps(manifest, indent=1) + "\n", encoding="utf-8")
    result = _run_validator(pkg)
    assert result.returncode != 0
    assert "F43" in result.stdout
