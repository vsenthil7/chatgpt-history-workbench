"""One named regression test per machine-testable ChatGPT V002 review finding.

Each test cites its finding ID; several overlap deliberately with the broader
suites so the review trail stays legible even if those suites are refactored.
"""

from datetime import date

import pytest

from cgwo_core import (
    CONSUMER_CONTRACT_VERSION,
    AllocationState,
    CapacityAllocation,
    CapacityWindow,
    PlanItem,
    PlanItemState,
    TenantContext,
    windows_overlap,
)
from cgwo_core.allocation import ALLOWED_TRANSITIONS, AllocationInvariantError
from cgwo_core.tenancy import MissingTenantContextError

CTX = TenantContext(tenant_id="t1")
WINDOW = CapacityWindow(
    tenant_id="t1",
    resource_ref="actor-1",
    period_start=date(2026, 8, 1),
    period_end=date(2026, 8, 5),
    available_minutes=600,
)


def test_f01_reserved_with_consumption_is_unconstructible():
    with pytest.raises(AllocationInvariantError):
        CapacityAllocation(
            tenant_id="t1",
            window=WINDOW,
            plan_item_ref="pi-1",
            allocated_minutes=120,
            consumed_minutes=500,
            state=AllocationState.RESERVED,
        )


def test_f01_consumed_requires_full_consumption():
    with pytest.raises(AllocationInvariantError):
        CapacityAllocation(
            tenant_id="t1",
            window=WINDOW,
            plan_item_ref="pi-1",
            allocated_minutes=120,
            consumed_minutes=0,
            state=AllocationState.CONSUMED,
        )


def test_f01_overrun_requires_over_consumption():
    with pytest.raises(AllocationInvariantError):
        CapacityAllocation(
            tenant_id="t1",
            window=WINDOW,
            plan_item_ref="pi-1",
            allocated_minutes=120,
            consumed_minutes=50,
            state=AllocationState.OVERRUN,
        )


def test_f01_proposed_must_be_unconsumed():
    with pytest.raises(AllocationInvariantError):
        CapacityAllocation(
            tenant_id="t1",
            window=WINDOW,
            plan_item_ref="pi-1",
            allocated_minutes=120,
            consumed_minutes=25,
            state=AllocationState.PROPOSED,
        )


def test_f02_single_allocation_cannot_exceed_window():
    small = CapacityWindow(
        tenant_id="t1",
        resource_ref="actor-1",
        period_start=date(2026, 8, 1),
        period_end=date(2026, 8, 1),
        available_minutes=60,
    )
    with pytest.raises(AllocationInvariantError):
        CapacityAllocation(
            tenant_id="t1",
            window=small,
            plan_item_ref="pi-1",
            allocated_minutes=600,
        )


def test_f02_aggregate_capacity_governance_still_declared_only():
    """Guards the honesty of the deferral: no ledger/aggregate API exists yet.

    When a CapacityLedger (RTM DOM-006) is implemented, this test must be
    replaced by its real contract tests.
    """
    import cgwo_core

    assert not hasattr(cgwo_core, "CapacityLedger")


def test_f03_change_reason_survives_transition():
    reason = "resource off sick; replanned to Thursday"
    change = PlanItem(tenant_id="t1", work_object_ref="wo-1").transition(
        PlanItemState.DEFERRED, CTX, change_reason=reason
    )
    assert change.change_reason == reason


def test_f04_change_records_carry_domain_facts_not_just_names():
    change = CapacityAllocation(
        tenant_id="t1",
        window=WINDOW,
        plan_item_ref="pi-1",
        allocated_minutes=120,
    ).transition(AllocationState.RESERVED, CTX)
    assert change.event_type == "CapacityReserved"
    assert change.tenant_id == "t1"
    assert change.previous_state is AllocationState.PROPOSED
    assert change.new_state is AllocationState.RESERVED
    assert change.allocated_minutes == 120


def test_f05_blank_organisation_id_is_rejected():
    with pytest.raises(MissingTenantContextError):
        TenantContext(tenant_id="t1", organisation_id=" ")


def test_f06_overlap_is_a_pure_value_comparison():
    other = CapacityWindow(
        tenant_id="t2",
        resource_ref="actor-1",
        period_start=date(2026, 8, 1),
        period_end=date(2026, 8, 5),
        available_minutes=600,
    )
    assert windows_overlap(WINDOW, other) is False


def test_f01_lifecycle_table_cannot_reach_quantity_states():
    reachable = set().union(*ALLOWED_TRANSITIONS.values())
    assert AllocationState.CONSUMED not in reachable
    assert AllocationState.OVERRUN not in reachable


def test_f12_consumer_contract_is_versioned():
    assert CONSUMER_CONTRACT_VERSION.startswith("cgwo-consumer-v")
