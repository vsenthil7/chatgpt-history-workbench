"""Adversarial runtime-type attacks (ADR-010, review findings F13/F14).

Every payload here is either taken verbatim from the independent V003 review
or extends the same attack class: raw strings where enums belong, wrong enum
families, non-str references, bools where ints belong, strings where dates
belong. Malformed values must raise controlled DomainErrors at construction —
never construct successfully, and never surface later as AttributeError.
"""

from datetime import date

import pytest

from cgwo_core.allocation import AllocationInvariantError, AllocationState, CapacityAllocation
from cgwo_core.capacity import (
    AvailabilityDeclaration,
    CapacityInvariantError,
    CapacityType,
    CapacityWindow,
)
from cgwo_core.errors import WRONG_RUNTIME_TYPE, DomainError
from cgwo_core.plan_item import (
    ChangeReasonRequiredError,
    InvalidTransitionError,
    PlanItem,
    PlanItemInvariantError,
    PlanItemState,
)
from cgwo_core.tenancy import MissingTenantContextError, TenantContext

CTX = TenantContext(tenant_id="t1")
WINDOW = CapacityWindow(
    tenant_id="t1",
    resource_ref="actor-1",
    period_start=date(2026, 8, 1),
    period_end=date(2026, 8, 5),
    available_minutes=600,
)


def assert_wrong_type(excinfo, field=None, expected=None):
    assert isinstance(excinfo.value, DomainError)
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    if field is not None:
        assert excinfo.value.fields["field"] == field
    if expected is not None:
        assert excinfo.value.fields["expected"] == expected


# --- F13 payload 1: PlanItem with raw string state ---------------------------
def test_f13_plan_item_rejects_raw_string_state():
    with pytest.raises(PlanItemInvariantError) as excinfo:
        PlanItem(tenant_id="t1", work_object_ref="wo1", state="COMPLETED")  # type: ignore[arg-type]
    assert_wrong_type(excinfo, field="state", expected="PlanItemState")


# --- F13 payload 2: CapacityWindow with raw string capacity type -------------
def test_f13_capacity_window_rejects_raw_string_type():
    with pytest.raises(CapacityInvariantError) as excinfo:
        CapacityWindow(
            tenant_id="t1",
            resource_ref="a",
            period_start=date(2026, 8, 1),
            period_end=date(2026, 8, 5),
            available_minutes=60,
            capacity_type="EXECUTION",  # type: ignore[arg-type]
        )
    assert_wrong_type(excinfo, field="capacity_type", expected="CapacityType")


def test_f13_str_vs_enum_windows_can_no_longer_fake_non_overlap():
    """The V003 review's semantic bug: a str-typed window dodged overlap.

    Now the malformed window cannot exist at all, so the pure comparison can
    never be reached with mixed representations of the same capacity type.
    """
    with pytest.raises(CapacityInvariantError):
        CapacityWindow(
            tenant_id="t1",
            resource_ref="actor-1",
            period_start=date(2026, 8, 1),
            period_end=date(2026, 8, 5),
            available_minutes=600,
            capacity_type="EXECUTION",  # type: ignore[arg-type]
        )


# --- F14 payload: the reviewer's exact allocation construction ----------------
def test_f14_reviewer_allocation_payload_is_unconstructible():
    with pytest.raises(AllocationInvariantError) as excinfo:
        CapacityAllocation(
            tenant_id="t1",
            window=WINDOW,
            plan_item_ref="p",
            allocated_minutes=30,
            consumed_minutes=999,
            state="X",  # type: ignore[arg-type]
        )
    assert_wrong_type(excinfo, field="state", expected="AllocationState")


@pytest.mark.parametrize(
    "state",
    ["PROPOSED", "", 3, None, PlanItemState.STARTED, object()],
)
def test_f14_every_non_enum_allocation_state_rejected(state):
    with pytest.raises(AllocationInvariantError) as excinfo:
        CapacityAllocation(
            tenant_id="t1",
            window=WINDOW,
            plan_item_ref="p",
            allocated_minutes=30,
            consumed_minutes=0,
            state=state,
        )
    assert_wrong_type(excinfo)


@pytest.mark.parametrize(
    "state",
    ["CANDIDATE", 0, None, AllocationState.PROPOSED],
)
def test_f13_every_non_enum_plan_item_state_rejected(state):
    with pytest.raises(PlanItemInvariantError) as excinfo:
        PlanItem(tenant_id="t1", work_object_ref="wo1", state=state)
    assert_wrong_type(excinfo)


# --- Transition targets and operation arguments -------------------------------
def test_raw_string_transition_target_is_a_controlled_error():
    with pytest.raises(InvalidTransitionError) as excinfo:
        PlanItem.create("t1", "wo1").transition("WEEK_PLANNED", CTX)  # type: ignore[arg-type]
    assert_wrong_type(excinfo, field="target", expected="PlanItemState")


def test_raw_string_allocation_target_is_a_controlled_error():
    alloc = CapacityAllocation.create("t1", WINDOW, "p", 30)
    with pytest.raises(InvalidTransitionError) as excinfo:
        alloc.transition("RESERVED", CTX)  # type: ignore[arg-type]
    assert_wrong_type(excinfo, field="target", expected="AllocationState")


def test_non_str_change_reason_is_a_controlled_error():
    with pytest.raises(ChangeReasonRequiredError) as excinfo:
        PlanItem.create("t1", "wo1").transition(PlanItemState.DEFERRED, CTX, change_reason=5)  # type: ignore[arg-type]
    assert_wrong_type(excinfo, field="change_reason", expected="str")


def test_non_context_ctx_is_a_controlled_error():
    with pytest.raises(MissingTenantContextError) as excinfo:
        PlanItem.create("t1", "wo1").transition(PlanItemState.WEEK_PLANNED, "t1")  # type: ignore[arg-type]
    assert_wrong_type(excinfo, field="ctx", expected="TenantContext")


# --- Non-str references, bool-as-int, string dates ----------------------------
def test_non_str_tenant_id_rejected_everywhere():
    with pytest.raises(MissingTenantContextError) as excinfo:
        TenantContext(tenant_id=123)  # type: ignore[arg-type]
    assert_wrong_type(excinfo, field="tenant_id", expected="str")
    with pytest.raises(CapacityInvariantError) as excinfo:
        CapacityWindow(
            tenant_id=123,  # type: ignore[arg-type]
            resource_ref="a",
            period_start=date(2026, 8, 1),
            period_end=date(2026, 8, 5),
            available_minutes=60,
        )
    assert_wrong_type(excinfo)


def test_bool_is_not_an_acceptable_minutes_value():
    with pytest.raises(CapacityInvariantError) as excinfo:
        CapacityWindow(
            tenant_id="t1",
            resource_ref="a",
            period_start=date(2026, 8, 1),
            period_end=date(2026, 8, 5),
            available_minutes=True,  # type: ignore[arg-type]
        )
    assert_wrong_type(excinfo, field="available_minutes", expected="int")
    with pytest.raises(AllocationInvariantError) as excinfo:
        CapacityAllocation.create("t1", WINDOW, "p", True)  # type: ignore[arg-type]
    assert_wrong_type(excinfo, field="allocated_minutes", expected="int")


def test_string_dates_rejected():
    with pytest.raises(CapacityInvariantError) as excinfo:
        CapacityWindow(
            tenant_id="t1",
            resource_ref="a",
            period_start="2026-08-01",  # type: ignore[arg-type]
            period_end=date(2026, 8, 5),
            available_minutes=60,
        )
    assert_wrong_type(excinfo, field="period_start", expected="datetime.date")


def test_non_window_window_rejected():
    with pytest.raises(AllocationInvariantError) as excinfo:
        CapacityAllocation.create("t1", {"available_minutes": 600}, "p", 30)  # type: ignore[arg-type]
    assert_wrong_type(excinfo, field="window", expected="CapacityWindow")
    with pytest.raises(CapacityInvariantError) as excinfo:
        AvailabilityDeclaration(
            tenant_id="t1",
            resource_ref="a",
            window="not-a-window",  # type: ignore[arg-type]
            declared_on=date(2026, 8, 1),
        )
    assert_wrong_type(excinfo, field="window", expected="CapacityWindow")


def test_bool_consume_minutes_rejected():
    alloc = (
        CapacityAllocation.create("t1", WINDOW, "p", 30)
        .transition(AllocationState.RESERVED, CTX)
        .allocation
    )
    with pytest.raises(AllocationInvariantError) as excinfo:
        alloc.consume(True, CTX)  # type: ignore[arg-type]
    assert_wrong_type(excinfo, field="minutes", expected="int")


def test_valid_enum_instances_still_construct():
    item = PlanItem(tenant_id="t1", work_object_ref="wo1", state=PlanItemState.COMPLETED)
    assert item.state is PlanItemState.COMPLETED
    window = CapacityWindow(
        tenant_id="t1",
        resource_ref="a",
        period_start=date(2026, 8, 1),
        period_end=date(2026, 8, 5),
        available_minutes=60,
        capacity_type=CapacityType.SUPERVISORY,
    )
    assert window.capacity_type is CapacityType.SUPERVISORY
