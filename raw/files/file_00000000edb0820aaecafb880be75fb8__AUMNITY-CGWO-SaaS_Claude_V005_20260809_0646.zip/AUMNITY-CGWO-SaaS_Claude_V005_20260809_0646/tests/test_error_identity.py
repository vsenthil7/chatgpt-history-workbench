"""Structured error identity (ADR-011, review finding F19).

The tested contract is the exception TYPE plus stable CODE (and structured
facts where relevant). Human-readable prose is rendered from the registry in
`cgwo_core.errors.MESSAGES` and asserted via the registry — never hardcoded —
so wording can evolve in one place without breaking tests.
"""

from datetime import date

import pytest
from tests.test_allocation import allocation
from tests.test_capacity import window

from cgwo_core import errors
from cgwo_core.allocation import AllocationInvariantError
from cgwo_core.allocation import AllocationState as A
from cgwo_core.capacity import AvailabilityDeclaration, CapacityInvariantError
from cgwo_core.contracts import ContractViolationError, TimeRecordProposal
from cgwo_core.errors import MESSAGES, DomainError
from cgwo_core.plan_item import (
    ChangeReasonRequiredError,
    InvalidTransitionError,
    PlanItem,
    PlanItemInvariantError,
)
from cgwo_core.plan_item import PlanItemState as S
from cgwo_core.tenancy import (
    CrossTenantAccessError,
    MissingTenantContextError,
    TenantContext,
    assert_same_tenant,
)

CTX = TenantContext(tenant_id="t1")


def expect(exc_cls, code):
    """pytest.raises wrapper asserting stable error identity."""

    class _Ctx:
        def __enter__(self):
            self.inner = pytest.raises(exc_cls)
            self.excinfo = self.inner.__enter__()
            return self.excinfo

        def __exit__(self, *exc):
            handled = self.inner.__exit__(*exc)
            if handled:
                raised = self.excinfo.value
                assert isinstance(raised, DomainError)
                assert raised.code == code, f"expected code {code}, got {raised.code}"
            return handled

    return _Ctx()


def test_every_code_has_a_message_template():
    codes = {
        name: value
        for name, value in vars(errors).items()
        if name.isupper()
        and isinstance(value, str)
        and not name.startswith(("F_", "EXPECTED_"))
        and name != "MESSAGES"
    }
    assert set(codes.values()) == set(MESSAGES)


def test_structured_fields_travel_on_the_error():
    with pytest.raises(AllocationInvariantError) as excinfo:
        allocation(A.PROPOSED, consumed=5)
    assert excinfo.value.fields == {"state": "PROPOSED"}


def test_message_renders_from_registry():
    with pytest.raises(AllocationInvariantError) as excinfo:
        allocation(A.PROPOSED, consumed=5)
    assert str(excinfo.value) == MESSAGES[errors.STATE_REQUIRES_ZERO_CONSUMPTION].format(
        state="PROPOSED"
    )


def test_tenancy_identity():
    with expect(MissingTenantContextError, errors.FIELD_BLANK):
        TenantContext(tenant_id=" ")
    with expect(MissingTenantContextError, errors.ORGANISATION_ID_BLANK):
        TenantContext(tenant_id="t1", organisation_id=" ")
    with expect(CrossTenantAccessError, errors.CROSS_TENANT):
        assert_same_tenant(CTX, "t2")
    with expect(MissingTenantContextError, errors.WRONG_RUNTIME_TYPE):
        assert_same_tenant("t1", "t1")  # type: ignore[arg-type]


def test_capacity_identity():
    with expect(CapacityInvariantError, errors.FIELD_BLANK):
        window(tenant_id=" ")
    with expect(CapacityInvariantError, errors.FIELD_BLANK):
        window(resource_ref=" ")
    with expect(CapacityInvariantError, errors.PERIOD_ORDER):
        window(period_end=date(2026, 7, 31))
    with expect(CapacityInvariantError, errors.AVAILABLE_MINUTES_NEGATIVE):
        window(available_minutes=-1)
    with expect(CapacityInvariantError, errors.DECLARATION_TENANT_MISMATCH):
        AvailabilityDeclaration(
            tenant_id="t2",
            resource_ref="actor-1",
            window=window(),
            declared_on=date(2026, 8, 1),
        )
    with expect(CapacityInvariantError, errors.DECLARATION_RESOURCE_MISMATCH):
        AvailabilityDeclaration(
            tenant_id="t1",
            resource_ref="actor-2",
            window=window(),
            declared_on=date(2026, 8, 1),
        )


def test_plan_item_identity():
    with expect(PlanItemInvariantError, errors.FIELD_BLANK):
        PlanItem(tenant_id=" ", work_object_ref="wo-1")
    with expect(PlanItemInvariantError, errors.FIELD_BLANK):
        PlanItem(tenant_id="t1", work_object_ref=" ")
    with expect(InvalidTransitionError, errors.TRANSITION_NOT_ALLOWED):
        PlanItem.create("t1", "wo-1").transition(S.STARTED, CTX)
    with expect(ChangeReasonRequiredError, errors.CHANGE_REASON_REQUIRED):
        PlanItem.create("t1", "wo-1").transition(S.DEFERRED, CTX)


def test_allocation_identity():
    with expect(AllocationInvariantError, errors.ALLOCATION_TENANT_MISMATCH):
        allocation(tenant_id="t2")
    with expect(AllocationInvariantError, errors.FIELD_BLANK):
        allocation(plan_item_ref=" ")
    with expect(AllocationInvariantError, errors.ALLOCATED_MINUTES_NON_POSITIVE):
        allocation(allocated=0)
    with expect(AllocationInvariantError, errors.CONSUMED_MINUTES_NEGATIVE):
        allocation(consumed=-1)
    with expect(AllocationInvariantError, errors.ALLOCATION_EXCEEDS_WINDOW):
        allocation(allocated=601)
    with expect(AllocationInvariantError, errors.STATE_REQUIRES_ZERO_CONSUMPTION):
        allocation(A.RESERVED, consumed=5)
    with expect(AllocationInvariantError, errors.CONSUMING_BOUND_VIOLATED):
        allocation(A.CONSUMING, consumed=120)
    with expect(AllocationInvariantError, errors.PARTIAL_BOUND_VIOLATED):
        allocation(A.PARTIALLY_CONSUMED, consumed=0)
    with expect(AllocationInvariantError, errors.CONSUMED_MUST_EQUAL_ALLOCATED):
        allocation(A.CONSUMED, consumed=119)
    with expect(AllocationInvariantError, errors.OVERRUN_REQUIRES_EXCESS):
        allocation(A.OVERRUN, consumed=120)
    with expect(InvalidTransitionError, errors.TRANSITION_NOT_ALLOWED):
        allocation().transition(A.CONSUMING, CTX)
    with expect(InvalidTransitionError, errors.CONSUME_FROM_INVALID_STATE):
        allocation().consume(10, CTX)
    with expect(AllocationInvariantError, errors.CONSUME_NON_POSITIVE):
        allocation(A.RESERVED).consume(0, CTX)


def test_contract_identity():
    with expect(ContractViolationError, errors.FIELD_BLANK):
        TimeRecordProposal(tenant_id=" ", resource_ref="a", work_object_ref="w", minutes=1)
    with expect(ContractViolationError, errors.CONTRACT_MINUTES_NON_POSITIVE):
        TimeRecordProposal(tenant_id="t1", resource_ref="a", work_object_ref="w", minutes=0)
