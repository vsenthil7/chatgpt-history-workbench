# Quality Gates — mandatory release ladder

A release is not review-ready until all applicable gates are green and evidence is attached.

| Gate | Minimum evidence |
|---|---|
| G01 Repository/manifest | package validator + manifest checksum pass |
| G02 Formatting/lint/type | project-standard static gates pass |
| G03 Unit/domain | all tests pass |
| G04 Coverage | 100% line + branch target or approved exception |
| G05 Contract/integration | all bounded-context contracts pass |
| G06 Architecture | dependency/ownership/tenant guards pass |
| G07 Mutation | defined mutation threshold; critical regressions killed |
| G08 Security | authz + tenant-isolation tests pass |
| G09 RTM | every enforced requirement maps to evidence/test |
| G10 Docs consistency | versions/counts/names/ADRs/manifests cross-check |
| G11 Packaging | clean checkout/reproducible build/package smoke test |
| G12 Independent review | ChatGPT review findings resolved or explicitly accepted |

Never update quoted test counts manually in narrative documents. Generate or validate them from machine-readable evidence.
