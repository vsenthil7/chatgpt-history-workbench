# ADR-010 — Runtime type integrity, wire decoding, and construction semantics

Status: ACCEPTED — AMENDED by ADR-012 (V005)
Date: 2026-08-08
Responds to: independent review of V003, findings F13, F14, F15 and F16.

## Context
Python type annotations are not runtime constraints. The V003 domain accepted raw strings where enums belong (`PlanItem(state="COMPLETED")`, `CapacityWindow(capacity_type="EXECUTION")`, `CapacityAllocation(state="X")`), which later crashed with incidental `AttributeError`s and — worse — let two windows of the same conceptual capacity type dodge overlap detection because identity comparison saw a str and an enum. ADR-007's "every construction path" claim was therefore false at the type level. Separately, `AvailabilityProposal` let raw wire values leak into domain objects, and nothing distinguished creating a new aggregate from reloading a persisted one.

## Decisions
1. **The domain is strict**: every enum-, date-, int-, str- and aggregate-typed field is validated for its runtime type on every construction path and on every operation argument (transition targets, consume minutes, change reasons, tenant contexts). Malformed values raise controlled `DomainError`s with `WRONG_RUNTIME_TYPE` identity — never incidental `AttributeError`/`KeyError`. `bool` is rejected where `int` is required; `datetime.datetime` is accepted where `date` is required (subclass).
2. **Domain constructors never normalise raw values.** External/wire representations enter ONLY through explicit parsers: `contracts.from_wire` factories and the `parse_wire_*` functions, which decode supported raw values (ISO date strings, decimal integer strings, enum value strings) and reject unknown or malformed input deterministically. Incidental dataclass construction is not the wire contract.
3. **Creation vs rehydration is explicit** (F16): `PlanItem.create` / `CapacityAllocation.create` are the only ways to obtain genuinely new aggregates and always start them in the module's `INITIAL_STATE` (CANDIDATE / PROPOSED, zero consumption). `rehydrate` (or equivalent direct construction) is for trusted persistence reload; it is deliberately the same fully-validated code path, so nothing rehydrated can violate an invariant either. Call sites must state their intent through the named factories.
4. Enum identity comparisons inside pure functions (e.g. `windows_overlap`) are now provably safe because mixed representations cannot construct.

## Consequences
- The reviewer's exact adversarial payloads are named regression tests (`tests/test_adversarial_construction.py`); a guard-site matrix (`tests/test_guard_site_matrix.py`) asserts the full structured identity of every raise site.
- RTM DOM-005 may again claim "every construction path" — now including the type level — and a consistency-validator heuristic ties that phrase to the presence of the adversarial suite.
- Domain core version bumped to 0.3.0 (pre-1.0 breaking change: stricter constructors).

---
**Amendment (V005, ADR-012):** the V004 review (findings F20–F23) proved this ADR's `isinstance`-based guards and its "`datetime.datetime` accepted where `date` is required" clause insufficient against hostile subclasses and mixed date/datetime comparisons. ADR-012 supersedes those two aspects with the canonical-primitive exact-type rule. Decisions 2–4 (wire-only decoding, create/rehydrate semantics, safe enum identity) stand, with F25 narrowing decision 3's lifecycle-origin claim to API convention (see ADR-012).
