"""Canonical-primitive runtime guards for domain trust boundaries (ADR-012).

Python type annotations are not runtime constraints, and ``isinstance`` is
too permissive for untrusted values: hostile subclasses of ``str``/``int``
can override equality, comparison and ``.strip()`` to defeat security and
invariant checks (V004 review findings F20–F22), ``isinstance`` itself
consults a spoofable ``__class__``, and ``datetime.datetime`` slips through
``isinstance(x, date)`` while breaking date-only semantics (F23).

The domain therefore stores ONLY canonical primitives, enforced with exact
type checks (``type(value) is ...``), which read the real type slot and are
immune to ``__class__`` spoofing:

* exact built-in ``str`` — no subclasses, so no hostile ``__eq__``/``strip``
* exact built-in ``int`` — ``bool`` excluded by construction
* exact ``datetime.date`` — ``datetime.datetime`` excluded by design
* exact enum member type — Enum classes with members cannot be subclassed,
  and the exact-type rule additionally defeats spoofed ``__class__`` objects

Raw wire values are normalised only in explicit parsers
(``contracts.from_wire`` / ``parse_wire_*``), which emit canonical values.
"""

from __future__ import annotations

from datetime import date
from enum import Enum

from cgwo_core.errors import (
    EXPECTED_DATE,
    EXPECTED_INT,
    EXPECTED_STR,
    WRONG_RUNTIME_TYPE,
    DomainError,
    build,
)


def require_str(value: object, field: str, exc_cls: type[DomainError]) -> str:
    if type(value) is not str:
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=EXPECTED_STR,
            actual=type(value).__name__,
        )
    return value


def require_optional_str(value: object, field: str, exc_cls: type[DomainError]) -> str | None:
    if value is None:
        return None
    return require_str(value, field, exc_cls)


def require_int(value: object, field: str, exc_cls: type[DomainError]) -> int:
    if type(value) is not int:
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=EXPECTED_INT,
            actual=type(value).__name__,
        )
    return value


def require_date(value: object, field: str, exc_cls: type[DomainError]) -> date:
    if type(value) is not date:
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=EXPECTED_DATE,
            actual=type(value).__name__,
        )
    return value


def require_enum[E: Enum](
    value: object, enum_cls: type[E], field: str, exc_cls: type[DomainError]
) -> E:
    if type(value) is not enum_cls:
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=enum_cls.__name__,
            actual=type(value).__name__,
        )
    return value
