"""Explicit tenant context for every protected operation (SaaS-002, ADR-006, ADR-009).

Isolation boundary (ADR-009): ``tenant_id`` is THE enforced isolation boundary.
``organisation_id`` is an optional sub-scope reference (Platform-owned semantics);
it is validated for well-formedness but is not an independently enforced security
boundary in the domain core. Runtime type integrity per ADR-010.
"""

from __future__ import annotations

from dataclasses import dataclass

from cgwo_core.errors import (
    CROSS_TENANT,
    EXPECTED_TENANT_CONTEXT,
    F_CTX,
    F_ORGANISATION_ID,
    F_TENANT_ID,
    FIELD_BLANK,
    ORGANISATION_ID_BLANK,
    WRONG_RUNTIME_TYPE,
    DomainError,
    build,
)
from cgwo_core.validation import require_optional_str, require_str


class TenantIsolationError(DomainError):
    """Base class for tenant-isolation failures."""


class MissingTenantContextError(TenantIsolationError):
    """Raised when a protected operation lacks a usable tenant context."""


class CrossTenantAccessError(TenantIsolationError):
    """Raised when a tenant context touches another tenant's aggregate."""


def _validate_context(tenant_id: object, organisation_id: object) -> None:
    checked_tenant = require_str(tenant_id, F_TENANT_ID, MissingTenantContextError)
    if not checked_tenant.strip():
        raise build(MissingTenantContextError, FIELD_BLANK, field=F_TENANT_ID)
    checked_org = require_optional_str(
        organisation_id, F_ORGANISATION_ID, MissingTenantContextError
    )
    if checked_org is not None and not checked_org.strip():
        raise build(MissingTenantContextError, ORGANISATION_ID_BLANK)


@dataclass(frozen=True, slots=True)
class TenantContext:
    """Opaque Platform tenancy references; CGWO validates presence, not shape."""

    tenant_id: str
    organisation_id: str | None = None

    def __post_init__(self) -> None:
        _validate_context(self.tenant_id, self.organisation_id)


def assert_same_tenant(ctx: TenantContext, owner_tenant_id: str) -> None:
    """Deny cross-tenant access to an aggregate owned by ``owner_tenant_id``."""
    if not isinstance(ctx, TenantContext):
        raise build(
            MissingTenantContextError,
            WRONG_RUNTIME_TYPE,
            field=F_CTX,
            expected=EXPECTED_TENANT_CONTEXT,
            actual=type(ctx).__name__,
        )
    if ctx.tenant_id != owner_tenant_id:
        raise build(CrossTenantAccessError, CROSS_TENANT)
