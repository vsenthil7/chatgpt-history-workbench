# VALIDATED — evidence criteria (defined V002)

Current maturity, stated honestly: this package is a **tenant-pilot requirements-discovery baseline**. The workbook contains zero operational transaction rows (machine-verified), no user has run the workflow, and no product contract has been exercised. Nothing in this package is, or may be described as, completed live tenant validation. No tenant validation data may ever be fabricated to advance a register entry.

A register entry may move to `VALIDATED` only when ALL of the following exist and are referenced from the entry's evidence field:

1. **Product version reference** — the owning product release implementing the requirement (entry already IMPLEMENTED).
2. **Tenant contract/fixture exercise** — an acceptance or contract test, owned by this pilot package, exercising the product's published contract with IPBS tenant configuration/fixtures (permitted pilot content per TENANT-PILOT-PROMOTION-RULE.md), executed with machine-captured results.
3. **Representative usage evidence** — real IPBS operational records or a documented representative scenario executed by an IPBS user, with dates and actors.
4. **Usability/friction findings** — recorded observations from that usage (including "none"), feeding the register as new OBSERVED entries where applicable.
5. **Recorded acceptance** — a named IPBS acceptor, date, and outcome (accept / accept-with-conditions / reject), stored under `13-evidence/`.

Partial evidence keeps the entry at IMPLEMENTED with a note; the validator refuses VALIDATED without an evidence reference.

## V004 — machine-enforced schemas (ADR-0007)

Evidence-class files are JSON under `13-evidence/validation/`, validated semantically (not merely for existence — the V003 empty-file attack is closed, negative test E1):

| Class | Required machine-checked content |
|---|---|
| ACCEPTANCE | rpr_id (must match), tenant, acceptor, acceptor_role, date, outcome ∈ {ACCEPT, ACCEPT-WITH-CONDITIONS} (REJECT can never support VALIDATED), product+version equal to the implementation fields |
| USAGE | rpr_id, tenant, scenario/session, actor, date, product+version equal to implementation fields, result. Fabricated usage is prohibited; the named actor/date/version make any fabrication auditable |
| FINDINGS | rpr_id, source_usage resolving to an existing USAGE evidence file, findings list or explicit reviewed "NONE", reviewed_by, date |
| CONTRACT-TEST | rpr_id, product, contract_version equal to implementation field, test_id, date, result=PASS, artifact reference |

Additionally VALIDATED requires the durable lifecycle history (PROMOTED with BACKLOG:, IMPLEMENTED with PRODUCT-RELEASE:/CONTRACT: provenance) per ADR-0007 — a status cell edit cannot reach VALIDATED (negative tests L1–L8, R13).

## V005 — tenant binding and temporal policy (ADR-0007 amendment)

ACCEPTANCE and USAGE must carry `tenant` equal to the canonical `tenant_id` (`09-governance/TENANT-IDENTITY.json`); dates must parse as real ISO calendar dates; and temporal consistency is machine-enforced: acceptance/usage ≥ IMPLEMENTED instant, findings ≥ their source usage, VALIDATED event ≥ all evidence it relies on. Contract tests may legitimately pre-date the formal release (documented policy) but never post-date the VALIDATED event. Attacks T1–T4, D1–D2, TE1–TE3 are permanent regression tests.
