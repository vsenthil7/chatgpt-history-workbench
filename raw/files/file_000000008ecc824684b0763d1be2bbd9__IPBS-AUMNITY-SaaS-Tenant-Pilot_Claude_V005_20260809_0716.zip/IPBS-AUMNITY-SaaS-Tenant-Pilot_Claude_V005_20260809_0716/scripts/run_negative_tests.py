#!/usr/bin/env python3
"""V005 validation attack suite (V004 suite retained + tenant/date/time/temporal/registry/actor hardening attacks from the V004 review, each independently reproduced there).
P0 is a POSITIVE future-lifecycle simulation: it constructs a fully legitimate
VALIDATED state for RPR-020 (complete event history with stage evidence, external
provenance against the product registry, four schema-valid tenant evidence files)
and must PASS — proving the register can genuinely advance (no hard-coded ceiling).
Every other test perturbs one aspect of a valid or baseline state and must FAIL.
Classes: R register/model · M integrity · L lifecycle-history · E evidence-semantics
· P provenance/registry."""
import csv, json, os, re, shutil, subprocess, sys
from pathlib import Path
SRC = Path(sys.argv[1]).resolve()
ENV = dict(os.environ, BUILD_TIMESTAMP='2026-08-09T06:40:00+01:00')
CSVP = '12-requirements/promotion-register.csv'
EVP = '12-requirements/lifecycle-events.csv'
MDP = '12-requirements/REQUIREMENT-PROMOTION-REGISTER.md'
ART = 'AUMNITY-CGWO-SaaS_Claude_V014_20260901_1200'

def mutate_csv(root, rid, **changes):
    p = root / CSVP
    with p.open(encoding='utf-8') as f:
        rd = csv.DictReader(f); fields = rd.fieldnames; rows = list(rd)
    for r in rows:
        if r['id'] == rid: r.update(changes)
    with p.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)

def set_status_table(root, counts):
    p = root / MDP; t = p.read_text(encoding='utf-8')
    rows = ''.join(f'| {k} | {v} |\n' for k, v in counts.items())
    t = re.sub(r'(\| Status \| Entries \|\n\|---\|---\|\n)(\|[^\n]*\|\n)+', r'\1' + rows, t)
    p.write_text(t, encoding='utf-8')

def add_events(root, evs):
    with (root / EVP).open('a', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        for e in evs: w.writerow(e)

def write_ev(root, name, data):
    d = root / '13-evidence/validation'; d.mkdir(parents=True, exist_ok=True)
    (d / name).write_text(json.dumps(data, indent=1), encoding='utf-8')
    return f'13-evidence/validation/{name}'

def make_valid_validated(root):
    """Construct the fully legitimate future state the lifecycle is designed to reach."""
    usage = write_ev(root, 'RPR-020-usage.json', dict(
        rpr_id='RPR-020', tenant='IPBS', scenario='Weekly review over live CGWO data, calendar week 36',
        actor='IPBS Operations Lead', date='2026-09-05', product='AUMNITY-CGWO-SaaS', version=ART,
        result='Review metrics computed from execution events; rollover analysis completed'))
    acc = write_ev(root, 'RPR-020-acceptance.json', dict(
        rpr_id='RPR-020', tenant='IPBS', acceptor='IPBS Managing Director', acceptor_role='Tenant acceptor',
        date='2026-09-06', outcome='ACCEPT', product='AUMNITY-CGWO-SaaS', version=ART))
    fnd = write_ev(root, 'RPR-020-findings.json', dict(
        rpr_id='RPR-020', source_usage=usage, findings='NONE', reviewed_by='IPBS Operations Lead', date='2026-09-06'))
    ct = write_ev(root, 'RPR-020-contract-test.json', dict(
        rpr_id='RPR-020', product='AUMNITY-CGWO-SaaS', contract_version='cgwo.review.v1',
        test_id='CT-REVIEW-001', date='2026-09-04', result='PASS',
        artifact='cgwo-contract-tests_V014 run 2026-09-04T10:00'))
    impl_ev = (f'PRODUCT-RELEASE:AUMNITY-CGWO-SaaS@{ART}; CONTRACT:cgwo.review.v1; '
               f'RTM:AUMNITY-CGWO-SaaS:CGWO-RTM-042')
    mutate_csv(root, 'RPR-020', status='VALIDATED',
               implementation_product='AUMNITY-CGWO-SaaS', implementation_version=ART,
               implementation_contract_version='cgwo.review.v1', implementation_evidence=impl_ev,
               validation_evidence=('WB:09_Weekly_Review; F:F-13; '
                                    f'ACCEPTANCE:FILE:{acc}; USAGE:FILE:{usage}; '
                                    f'FINDINGS:FILE:{fnd}; CONTRACT-TEST:FILE:{ct}'))
    add_events(root, [
        ('E9001', 'RPR-020', 'PROMOTED', '2026-08-20T10:00:00+01:00', 'BACKLOG:AUMNITY-CGWO-SaaS:CGWO-BKL-042', 'Human-PO'),
        ('E9002', 'RPR-020', 'IMPLEMENTED', '2026-09-01T12:00:00+01:00', impl_ev, 'Human-PO'),
        ('E9003', 'RPR-020', 'VALIDATED', '2026-09-06T17:00:00+01:00',
         f'ACCEPTANCE:FILE:{acc}; USAGE:FILE:{usage}; FINDINGS:FILE:{fnd}; CONTRACT-TEST:FILE:{ct}', 'IPBS-acceptor')])
    set_status_table(root, {'CLASSIFIED': 24, 'PROPOSED': 4, 'VALIDATED': 1})

def patch_ev_json(root, name, **changes):
    p = root / '13-evidence/validation' / name
    d = json.loads(p.read_text(encoding='utf-8')); d.update(changes)
    p.write_text(json.dumps(d, indent=1), encoding='utf-8')

def edit_event(root, eid, field, value):
    p = root / EVP
    with p.open(encoding='utf-8') as f:
        rd = csv.DictReader(f); fields = rd.fieldnames; rows = list(rd)
    for e in rows:
        if e['event_id'] == eid: e[field] = value
    with p.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)

def add_registry_row(root, row):
    with (root / '09-governance/EXTERNAL-PRODUCT-REGISTRY.csv').open('a', encoding='utf-8', newline='') as f:
        csv.writer(f).writerow(row)

def write_adr(root, name, status, extra=''):
    (root / f'02-architecture/ADR/{name}.md').write_text(
        f'# {name}\n\n**Status:** {status} · test fixture\n{extra}\n', encoding='utf-8')

def retarget_product(root, pid, contract_ns):
    art = 'v1.0.0'
    mutate_csv(root, 'RPR-020', implementation_product=pid, implementation_version=art,
               implementation_contract_version=f'{contract_ns}.review.v1',
               implementation_evidence=f'PRODUCT-RELEASE:{pid}@{art}; CONTRACT:{contract_ns}.review.v1; RTM:{pid}:REQ-1')
    edit_event(root, 'E9002', 'evidence', f'PRODUCT-RELEASE:{pid}@{art}; CONTRACT:{contract_ns}.review.v1; RTM:{pid}:REQ-1')
    for n, ch in [('RPR-020-acceptance.json', dict(product=pid, version=art)),
                  ('RPR-020-usage.json', dict(product=pid, version=art)),
                  ('RPR-020-contract-test.json', dict(product=pid, contract_version=f'{contract_ns}.review.v1'))]:
        patch_ev_json(root, n, **ch)

IMPL_OK = dict(implementation_product='AUMNITY-CGWO-SaaS', implementation_version='v1.2.0',
               implementation_contract_version='cgwo.execution.v3',
               implementation_evidence='FILE:11-analysis/workbook-inventory.json')

tests = []
def T(cls, name, mutate, expect_fail=True):
    tests.append((cls, name, mutate, expect_fail))

# --- P0 positive future-capability simulation ---------------------------------
T('P0', 'POSITIVE: fully legitimate VALIDATED state passes (lifecycle is reachable)',
  make_valid_validated, expect_fail=False)

# --- R register/model (from V003, retained) -----------------------------------
T('R', 'R1  ADR-gated RPR marked CLASSIFIED', lambda rt: mutate_csv(rt, 'RPR-006', owner='PLATFORM', decision_scope='', candidate_owners='', status='CLASSIFIED'))
T('R', 'R2  gated RPR IMPLEMENTED while ADR PROPOSED', lambda rt: (mutate_csv(rt, 'RPR-017', status='IMPLEMENTED', **IMPL_OK), set_status_table(rt, {'CLASSIFIED': 25, 'PROPOSED': 3, 'IMPLEMENTED': 1})))
T('R', 'R3  gated RPR VALIDATED while ADR PROPOSED', lambda rt: (mutate_csv(rt, 'RPR-050', status='VALIDATED', **IMPL_OK), set_status_table(rt, {'CLASSIFIED': 25, 'PROPOSED': 3, 'VALIDATED': 1})))
T('R', 'R4  IMPLEMENTED without implementation fields', lambda rt: (mutate_csv(rt, 'RPR-020', status='IMPLEMENTED'), set_status_table(rt, {'CLASSIFIED': 24, 'PROPOSED': 4, 'IMPLEMENTED': 1})))
T('R', 'R5  implementation_product = the pilot itself', lambda rt: (mutate_csv(rt, 'RPR-020', status='IMPLEMENTED', **{**IMPL_OK, 'implementation_product': 'IPBS-Tenant-Pilot'}), set_status_table(rt, {'CLASSIFIED': 24, 'PROPOSED': 4, 'IMPLEMENTED': 1})))
T('R', 'R6  implementation fields populated at CLASSIFIED', lambda rt: mutate_csv(rt, 'RPR-001', implementation_version='v1.0.0'))
T('R', 'R7  WB evidence cites nonexistent column', lambda rt: mutate_csv(rt, 'RPR-013', validation_evidence='WB:04_Weekly_Plan:No_Such_Column'))
T('R', 'R8  FORMULA flag on non-formula column', lambda rt: mutate_csv(rt, 'RPR-013', validation_evidence='WB:04_Weekly_Plan:Sequence:FORMULA'))
T('R', 'R9  FILE evidence wrong exact path', lambda rt: mutate_csv(rt, 'RPR-021', validation_evidence='F:F-06; FILE:13-evidence/workbook-inventory.json'))
T('R', 'R10 UNRESOLVED without candidate_owners', lambda rt: mutate_csv(rt, 'RPR-003', candidate_owners=''))
T('R', 'R11 narrative owner count drift', lambda rt: (rt / MDP).write_text((rt / MDP).read_text().replace('| PLATFORM | 6 |', '| PLATFORM | 7 |')))
T('R', 'R12 workbook DV-count drift in analysis', lambda rt: (rt / '11-analysis/BASELINE-ANALYSIS.md').write_text((rt / '11-analysis/BASELINE-ANALYSIS.md').read_text().replace('**22** DataValidation objects', '**27** DataValidation objects')))
T('R', 'R13 status/narrative VALIDATED without any history (bare cell edit)', lambda rt: (mutate_csv(rt, 'RPR-019', status='VALIDATED', **IMPL_OK), set_status_table(rt, {'CLASSIFIED': 24, 'PROPOSED': 4, 'VALIDATED': 1})))

# --- L lifecycle history (Blocker 1) ------------------------------------------
T('L', 'L1  CLASSIFIED→IMPLEMENTED with no PROMOTED history', lambda rt: (make_valid_validated(rt), mutate_csv(rt, 'RPR-020', status='IMPLEMENTED'), edit_event(rt, 'E9001', 'event', 'OBSERVED'), set_status_table(rt, {'CLASSIFIED': 24, 'PROPOSED': 4, 'IMPLEMENTED': 1})))
T('L', 'L2  the V003 attack: CLASSIFIED→VALIDATED, valid-looking files, NO event history', lambda rt: (make_valid_validated(rt), (rt / EVP).write_text('\n'.join((rt / EVP).read_text().splitlines()[:-3]) + '\n')))
T('L', 'L3  PROMOTED→VALIDATED skipping IMPLEMENTED event', lambda rt: (make_valid_validated(rt), edit_event(rt, 'E9002', 'event', 'PROMOTED'), edit_event(rt, 'E9002', 'rpr_id', 'RPR-019')))
T('L', 'L4  promotion evidence stripped after the fact (BACKLOG deleted from history)', lambda rt: (make_valid_validated(rt), edit_event(rt, 'E9001', 'evidence', 'reference removed')))
T('L', 'L5  implementation provenance stripped from history', lambda rt: (make_valid_validated(rt), edit_event(rt, 'E9002', 'evidence', 'FILE:11-analysis/workbook-inventory.json')))
T('L', 'L6  event timestamps out of order (VALIDATED before IMPLEMENTED)', lambda rt: (make_valid_validated(rt), edit_event(rt, 'E9003', 'timestamp', '2026-08-31T09:00:00+01:00')))
T('L', 'L7  duplicate lifecycle event (second PROMOTED)', lambda rt: (make_valid_validated(rt), add_events(rt, [('E9004', 'RPR-020', 'PROMOTED', '2026-09-07T10:00:00+01:00', 'BACKLOG:AUMNITY-CGWO-SaaS:CGWO-BKL-042', 'Human-PO')])))
T('L', 'L8  status is not the latest event (silent regression)', lambda rt: (make_valid_validated(rt), mutate_csv(rt, 'RPR-020', status='IMPLEMENTED'), set_status_table(rt, {'CLASSIFIED': 24, 'PROPOSED': 4, 'IMPLEMENTED': 1})))

# --- E evidence semantics (Blocker 2) ------------------------------------------
T('E', 'E1  zero-byte ACCEPTANCE file (the empty-file attack)', lambda rt: (make_valid_validated(rt), (rt / '13-evidence/validation/RPR-020-acceptance.json').write_bytes(b'')))
T('E', 'E2  malformed ACCEPTANCE JSON', lambda rt: (make_valid_validated(rt), (rt / '13-evidence/validation/RPR-020-acceptance.json').write_text('not json {')))
T('E', 'E3  ACCEPTANCE bound to a different RPR', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-acceptance.json', rpr_id='RPR-999')))
T('E', 'E4  REJECT outcome presented as VALIDATED evidence', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-acceptance.json', outcome='REJECT')))
T('E', 'E5  USAGE product/version mismatch', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-usage.json', version='v9.9.9')))
T('E', 'E6  FINDINGS referencing nonexistent usage evidence', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-findings.json', source_usage='13-evidence/validation/does-not-exist.json')))
T('E', 'E7  CONTRACT-TEST result FAIL', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-contract-test.json', result='FAIL')))
T('E', 'E8  CONTRACT-TEST wrong contract version', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-contract-test.json', contract_version='cgwo.review.v9')))

# --- P provenance / registry (Blocker 3 + point 7) ------------------------------
T('P', 'P1  the V003 attack: generic FILE as implementation evidence', lambda rt: (make_valid_validated(rt), mutate_csv(rt, 'RPR-020', implementation_evidence='FILE:11-analysis/workbook-inventory.json')))
T('P', 'P2  PRODUCT-RELEASE artifact != implementation_version', lambda rt: (make_valid_validated(rt), mutate_csv(rt, 'RPR-020', implementation_evidence=f'PRODUCT-RELEASE:AUMNITY-CGWO-SaaS@v9.9.9; CONTRACT:cgwo.review.v1; RTM:AUMNITY-CGWO-SaaS:CGWO-RTM-042')))
T('P', 'P3  unapproved product not in the governance registry', lambda rt: (make_valid_validated(rt), mutate_csv(rt, 'RPR-020', implementation_product='AUMNITY-Capability-SaaS', implementation_evidence=f'PRODUCT-RELEASE:AUMNITY-Capability-SaaS@{ART}; CONTRACT:cgwo.review.v1; RTM:AUMNITY-Capability-SaaS:X-1')))

# --- T tenant binding (V004 review blocker 1) -----------------------------------
T('T', 'T1  ACCEPTANCE tenant = OTHER-TENANT (exact reproduced attack)', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-acceptance.json', tenant='OTHER-TENANT')))
T('T', 'T2  USAGE tenant = OTHER-TENANT', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-usage.json', tenant='OTHER-TENANT')))
T('T', 'T3  blank tenant', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-acceptance.json', tenant='')))
T('T', 'T4  tenant case/identity mismatch (ipbs vs IPBS)', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-usage.json', tenant='ipbs')))
# --- D real-date parsing (blocker 2) ---------------------------------------------
T('D', 'D1  ACCEPTANCE date 2026-99-99 (exact reproduced attack)', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-acceptance.json', date='2026-99-99')))
T('D', 'D2  USAGE date 2026-02-30 (impossible leap-style date)', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-usage.json', date='2026-02-30')))
T('D', 'D3  event timestamp not ISO-8601', lambda rt: (make_valid_validated(rt), edit_event(rt, 'E9002', 'timestamp', 'not-a-time')))
T('D', 'D4  naive event timestamp (no timezone)', lambda rt: (make_valid_validated(rt), edit_event(rt, 'E9002', 'timestamp', '2026-09-01T12:00:00')))
# --- Z instant chronology (blocker 3) --------------------------------------------
T('Z', 'Z1  offset inversion: IMPLEMENTED -12:00 vs VALIDATED +14:00 (exact reproduced attack)', lambda rt: (make_valid_validated(rt), edit_event(rt, 'E9002', 'timestamp', '2026-09-01T12:00:00-12:00'), edit_event(rt, 'E9003', 'timestamp', '2026-09-01T12:30:00+14:00'), patch_ev_json(rt, 'RPR-020-acceptance.json', date='2026-09-02'), patch_ev_json(rt, 'RPR-020-usage.json', date='2026-09-02'), patch_ev_json(rt, 'RPR-020-findings.json', date='2026-09-02')))
# --- TE evidence temporal policy (point 4) ---------------------------------------
T('TE', 'TE1 ACCEPTANCE dated before implementation (exact reproduced attack)', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-acceptance.json', date='2026-08-01')))
T('TE', 'TE2 FINDINGS dated before their source USAGE', lambda rt: (make_valid_validated(rt), patch_ev_json(rt, 'RPR-020-findings.json', date='2026-09-02')))
T('TE', 'TE3 VALIDATED event before its own evidence', lambda rt: (make_valid_validated(rt), edit_event(rt, 'E9003', 'timestamp', '2026-09-04T08:00:00+01:00')))
# --- G registry authority (blocker 5) --------------------------------------------
T('G', 'G1  Fake-SaaS ACTIVE with STARTER (exact reproduced attack)', lambda rt: (make_valid_validated(rt), add_registry_row(rt, ['Fake-SaaS', 'ACTIVE', 'STARTER', '^v?[0-9]+\\.[0-9]+\\.[0-9]+$', 'fake', '2026-08-09', '']), retarget_product(rt, 'Fake-SaaS', 'fake')))
T('G', 'G2  product ACTIVE citing PROPOSED ADR-0002', lambda rt: (make_valid_validated(rt), add_registry_row(rt, ['Fake-SaaS', 'ACTIVE', 'ADR-0002', '^v?[0-9]+\\.[0-9]+\\.[0-9]+$', 'fake', '2026-08-09', '']), retarget_product(rt, 'Fake-SaaS', 'fake')))
T('G', 'G3  product citing bootstrap ADR-0008 without being in its list', lambda rt: (make_valid_validated(rt), add_registry_row(rt, ['Fake-SaaS', 'ACTIVE', 'ADR-0008', '^v?[0-9]+\\.[0-9]+\\.[0-9]+$', 'fake', '2026-08-09', '']), retarget_product(rt, 'Fake-SaaS', 'fake')))
T('G+', 'G4  POSITIVE: new product with its own ACCEPTED approving ADR passes', lambda rt: (make_valid_validated(rt), write_adr(rt, 'ADR-0090-approve-new-saas', 'ACCEPTED', 'Approves-product: New-SaaS'), add_registry_row(rt, ['New-SaaS', 'ACTIVE', 'ADR-0090', '^v?[0-9]+\\.[0-9]+\\.[0-9]+$', 'new', '2026-08-09', '']), retarget_product(rt, 'New-SaaS', 'new')), expect_fail=False)
# --- A actor minimal (point 7) ---------------------------------------------------
T('A', 'A1  blank recorded_by on a lifecycle event', lambda rt: (make_valid_validated(rt), edit_event(rt, 'E9002', 'recorded_by', '')))

# --- M integrity (from V003, retained) ------------------------------------------
integrity = [('M1  corrupted payload file', '11-analysis/BASELINE-ANALYSIS.md', 'corrupt'),
             ('M2  corrupted evidence file', '13-evidence/validate_register.txt', 'corrupt'),
             ('M3  unexpected file injected', '13-evidence/injected.txt', 'add')]

results, all_ok = [], True
for cls, name, mutate, expect_fail in tests:
    tmp = Path('/tmp/negtest'); shutil.rmtree(tmp, ignore_errors=True); shutil.copytree(SRC, tmp)
    mutate(tmp)
    r = subprocess.run([sys.executable, str(tmp / 'scripts/validate_register.py')], capture_output=True, text=True)
    failed = r.returncode != 0
    ok = failed == expect_fail
    first = next((l.strip() for l in r.stdout.splitlines() if l.startswith(' -')), r.stdout.splitlines()[0][:100] if r.stdout else '')
    results.append((cls, name, ok, first)); all_ok &= ok
for name, target, mode in integrity:
    tmp = Path('/tmp/negtest'); shutil.rmtree(tmp, ignore_errors=True); shutil.copytree(SRC, tmp)
    subprocess.run([sys.executable, str(tmp / 'scripts/generate_manifest.py')], env=ENV, capture_output=True)
    tp = tmp / target
    if mode == 'corrupt': tp.write_bytes(tp.read_bytes() + b'X')
    else: tp.write_text('injected after manifest\n')
    r = subprocess.run([sys.executable, str(tmp / 'scripts/validate_manifest.py')], capture_output=True, text=True)
    ok = r.returncode != 0
    first = next((l.strip() for l in r.stdout.splitlines() if l.startswith(' -')), '')
    results.append(('M', name, ok, first)); all_ok &= ok

shutil.rmtree('/tmp/negtest', ignore_errors=True)
counts = {}
POSITIVE = {'P0', 'G+'}
for cls, name, ok, msg in results:
    tag = 'PASS-AS-EXPECTED' if (cls in POSITIVE and ok) else ('DETECTED' if ok else 'MISSED  ')
    print(f'[{tag}] {name}: {msg}')
    counts[cls] = counts.get(cls, 0) + (1 if ok else 0)
pos_ok = counts.get('P0', 0) + counts.get('G+', 0)
neg_total = sum(v for k, v in counts.items() if k not in POSITIVE)
n_neg = len([x for x in results if x[0] not in POSITIVE])
print(f"RESULT: positive simulations {pos_ok}/2 PASSED (P0 future lifecycle; G4 ADR-approved new product); "
      f"negative tests {neg_total}/{n_neg} DETECTED "
      f"(R={counts.get('R',0)}/13 model, L={counts.get('L',0)}/8 history, E={counts.get('E',0)}/8 evidence-semantics, "
      f"P={counts.get('P',0)}/3 provenance, T={counts.get('T',0)}/4 tenant, D={counts.get('D',0)}/4 dates, "
      f"Z={counts.get('Z',0)}/1 instant-chronology, TE={counts.get('TE',0)}/3 temporal-policy, "
      f"G={counts.get('G',0)}/3 registry-authority, A={counts.get('A',0)}/1 actor, M={counts.get('M',0)}/3 integrity)")
sys.exit(0 if all_ok else 1)
