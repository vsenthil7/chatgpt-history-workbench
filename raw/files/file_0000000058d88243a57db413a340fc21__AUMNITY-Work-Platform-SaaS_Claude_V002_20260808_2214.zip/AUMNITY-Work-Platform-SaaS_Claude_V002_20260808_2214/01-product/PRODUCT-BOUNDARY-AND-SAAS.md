# Product Boundary and SaaS Model

## Boundary
Own the reusable SaaS platform primitives and shared contracts: Organisation/Tenant, Identity, Actor/Resource, Work Object, Capability, Evidence, Policy, Workflow, Audit, Integration and shared domain contracts. Do not absorb bounded product logic that belongs in CGWO or UraiFlow.

## Not owned
CGWO planning algorithms; UraiFlow capture/transcription/extraction; tenant-specific IPBS workflows/data; payroll/accounting/CRM unless explicitly created later as bounded products.

## Commercial/operating model
Products are reusable SaaS. IPBS is currently one tenant/user and may sell, support or implement the product. Other AT/WE companies and external customers may later become tenants, operators, implementation partners or channels. Product ownership and domain code therefore cannot be tied to IPBS.

## Tenant-neutral design
Use organisation/tenant configuration, policy, adapters and feature entitlements instead of customer-specific branches. A customer name may appear in pilot fixtures/docs, never as a reusable domain assumption.
