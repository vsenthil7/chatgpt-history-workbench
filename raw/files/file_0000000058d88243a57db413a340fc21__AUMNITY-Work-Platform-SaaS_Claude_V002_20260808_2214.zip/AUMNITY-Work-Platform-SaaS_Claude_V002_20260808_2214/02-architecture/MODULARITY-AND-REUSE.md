# Modularity and Reuse Architecture

## Ownership for this package
Own the reusable SaaS platform primitives and shared contracts: Organisation/Tenant, Identity, Actor/Resource, Work Object, Capability, Evidence, Policy, Workflow, Audit, Integration and shared domain contracts. Do not absorb bounded product logic that belongs in CGWO or UraiFlow.

## Dependency principle
Depend on stable contracts at bounded-context edges. Do not reach into another module's persistence model or copy its domain rules. Shared core must remain smaller than the products that consume it.

## Placement test
Before adding a significant component, classify it as: tenant configuration/data; bounded-product domain logic; shared platform primitive; integration adapter; or cross-cutting infrastructure. If ownership is unclear, create an ADR before code.

## SaaS guard
Protected operations must carry explicit tenant/organisation context and be tested for cross-tenant denial. Avoid global mutable tenant state.
