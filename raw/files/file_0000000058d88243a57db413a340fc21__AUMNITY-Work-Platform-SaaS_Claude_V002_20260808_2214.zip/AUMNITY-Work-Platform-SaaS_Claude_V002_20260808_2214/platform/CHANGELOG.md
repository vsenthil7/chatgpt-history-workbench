# Changelog — AUMNITY Work Platform (product code)

## 0.1.0 — 2026-08-08 (Claude build V002)
First implementation slice (ADR-003):
- `aumnity_contracts`: typed IDs, TenantContext, EventEnvelope, error taxonomy,
  deterministic clock/id providers, standardised source-system constants.
- `aumnity_kernel`: Organisation registry, Principal identity, Work Object
  registry with the baseline lifecycle state machine, versioning, recursive
  decomposition, minimal assignment, immutable evidence with completion policy,
  append-only tenant-scoped audit.
- In-memory adapters for all kernel ports.
- Quality gates G01–G10 as runnable evidence-producing scripts.
No public contract existed before this version; nothing is breaking.
