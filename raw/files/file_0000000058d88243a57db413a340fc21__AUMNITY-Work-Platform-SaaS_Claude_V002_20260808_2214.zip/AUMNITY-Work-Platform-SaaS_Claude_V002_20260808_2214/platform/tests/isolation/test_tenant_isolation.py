"""Tenant isolation and cross-tenant denial tests (RTM: SaaS-001/SaaS-002, DW-FR-013).

Gate G08 evidence: every protected read/write path denies cross-tenant access.
"""

import pytest
from aumnity_contracts import (
    NotFoundError,
    TenantContext,
    TenantIsolationError,
    WorkObjectId,
)
from aumnity_kernel import AuditLog
from aumnity_kernel.evidence import EvidenceKind
from aumnity_kernel.workobject.model import Priority, RiskLevel
from aumnity_kernel.workobject.service import WorkObjectRegistry

pytestmark = pytest.mark.isolation


def _create(registry: WorkObjectRegistry, tenant: TenantContext) -> WorkObjectId:
    return registry.create(
        tenant,
        title="Alpha-only record",
        purpose="Isolation subject",
        work_type="generic.task",
        priority=Priority.NORMAL,
        risk_level=RiskLevel.LOW,
        owner_id=tenant.principal_id,
    ).work_object_id


def test_cross_tenant_read_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.get(tenant_b, wid)


def test_cross_tenant_transition_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.mark_ready(tenant_b, wid)


def test_cross_tenant_evidence_attachment_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.attach_evidence(
            tenant_b,
            wid,
            kind=EvidenceKind.DOCUMENT,
            uri="evidence/steal.pdf",
            content_sha256="feed",
            source_system="MANUAL",
            source_reference="steal-1",
        )


def test_cross_tenant_decomposition_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    parent = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.create(
            tenant_b,
            title="Hostile child",
            purpose="Attach to foreign parent",
            work_type="generic.task",
            priority=Priority.NORMAL,
            risk_level=RiskLevel.LOW,
            owner_id=tenant_b.principal_id,
            parent_id=parent,
        )


def test_cross_tenant_children_listing_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    parent = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.children(tenant_b, parent)


def test_cross_tenant_evidence_listing_denied(
    registry: WorkObjectRegistry, tenant_a: TenantContext, tenant_b: TenantContext
) -> None:
    wid = _create(registry, tenant_a)
    with pytest.raises(TenantIsolationError):
        registry.evidence_for(tenant_b, wid)


def test_audit_trail_is_tenant_filtered(
    registry: WorkObjectRegistry,
    tenant_a: TenantContext,
    tenant_b: TenantContext,
    audit: AuditLog,
) -> None:
    _create(registry, tenant_a)
    _create(registry, tenant_b)
    a_entries = audit.entries_for(tenant_a)
    b_entries = audit.entries_for(tenant_b)
    assert {e.organisation_id for e in a_entries} == {tenant_a.organisation_id}
    assert {e.organisation_id for e in b_entries} == {tenant_b.organisation_id}


def test_unknown_id_is_not_found_not_isolation(
    registry: WorkObjectRegistry, tenant_a: TenantContext
) -> None:
    """ADR-006: distinct internal types; edge maps both to one external shape."""
    with pytest.raises(NotFoundError):
        registry.get(tenant_a, WorkObjectId("wob-never-existed"))
