"""Contract tests for the kernel's published surface (RTM: ARC-002; gate G05).

These freeze the shapes that CGWO, UraiFlow and future adapters depend on.
Breaking any assertion here is a breaking contract change requiring a version
rationale and migration note (09-governance/VERSIONING-AND-PACKAGING.md).
"""

import inspect

import aumnity_contracts
import aumnity_kernel
import pytest
from aumnity_kernel.workobject.service import WorkObjectRegistry
from aumnity_kernel.workobject.state import (
    BLOCKABLE_STATES,
    EVIDENCE_OPEN_STATES,
    TERMINAL_STATES,
    WorkObjectState,
    allowed_targets,
)

pytestmark = pytest.mark.contract


def test_contracts_public_api_is_stable() -> None:
    assert set(aumnity_contracts.__all__) == {
        "SOURCE_SYSTEM_URAIFLOW",
        "Clock",
        "EventEnvelope",
        "EvidenceId",
        "IdGenerator",
        "InvalidTransitionError",
        "NotFoundError",
        "OrganisationId",
        "PlatformError",
        "PolicyViolationError",
        "PrincipalId",
        "SequenceIdGenerator",
        "TenantContext",
        "TenantIsolationError",
        "TickingClock",
        "ValidationError",
        "WorkObjectId",
        "require_identifier",
    }


def test_kernel_public_api_is_stable() -> None:
    assert set(aumnity_kernel.__all__) == {
        "AuditLog",
        "CompletionPolicy",
        "CriticalWorkEvidencePolicy",
        "EvidenceRecord",
        "Organisation",
        "OrganisationRegistry",
        "Principal",
        "PrincipalKind",
        "RiskLevel",
        "WorkObject",
        "WorkObjectRegistry",
        "WorkObjectState",
    }


def test_every_state_has_a_transition_rule() -> None:
    for state in WorkObjectState:
        targets = allowed_targets(state)
        assert isinstance(targets, frozenset)


def test_terminal_states_have_no_targets() -> None:
    for state in TERMINAL_STATES:
        assert allowed_targets(state) == frozenset()


def test_non_terminal_states_have_targets() -> None:
    for state in WorkObjectState:
        if state not in TERMINAL_STATES:
            assert allowed_targets(state), f"{state} has no exit and is not declared terminal"


def test_core_lifecycle_path_is_reachable() -> None:
    """The baseline doc 04 core path must remain valid end to end."""
    path = [
        WorkObjectState.DRAFT,
        WorkObjectState.READY,
        WorkObjectState.ASSIGNABLE,
        WorkObjectState.ASSIGNED,
        WorkObjectState.IN_PROGRESS,
        WorkObjectState.OUTPUT_SUBMITTED,
        WorkObjectState.REVIEW,
        WorkObjectState.APPROVED,
        WorkObjectState.COMPLETED,
    ]
    for current, target in zip(path[:-1], path[1:], strict=True):
        assert target in allowed_targets(current), f"core path broken at {current} -> {target}"


def test_protected_operations_take_tenant_context_first() -> None:
    """SaaS-002: every public registry operation carries explicit tenant context."""
    for name, member in inspect.getmembers(WorkObjectRegistry, inspect.isfunction):
        if name.startswith("_"):
            continue
        parameters = list(inspect.signature(member).parameters)
        assert parameters[0] == "self" and parameters[1] == "context", (
            f"WorkObjectRegistry.{name} must take TenantContext as its first argument"
        )


def test_event_envelope_field_contract() -> None:
    fields = set(aumnity_contracts.EventEnvelope.__dataclass_fields__)
    assert fields == {
        "event_type",
        "organisation_id",
        "actor_principal_id",
        "subject_id",
        "subject_version",
        "occurred_at",
        "payload",
    }


def test_full_transition_table_matches_baseline_specification() -> None:
    """Baseline doc 04/09 restated as the complete expected transition map.

    This pins every allowed transition; any table drift (including a single
    dropped target) is a contract break. Mutation gate G07 relies on this test.
    """
    st = WorkObjectState
    expected: dict[WorkObjectState, set[WorkObjectState]] = {
        st.DRAFT: {st.READY, st.CANCELLED},
        st.READY: {st.ASSIGNABLE, st.BLOCKED, st.CANCELLED},
        st.ASSIGNABLE: {st.ASSIGNED, st.BLOCKED, st.CANCELLED},
        st.ASSIGNED: {st.IN_PROGRESS, st.BLOCKED, st.CANCELLED},
        st.IN_PROGRESS: {st.OUTPUT_SUBMITTED, st.PAUSED, st.BLOCKED, st.CANCELLED},
        st.PAUSED: {st.IN_PROGRESS, st.CANCELLED},
        st.BLOCKED: {st.READY, st.ASSIGNABLE, st.ASSIGNED, st.IN_PROGRESS, st.CANCELLED},
        st.OUTPUT_SUBMITTED: {st.REVIEW, st.CANCELLED},
        st.REVIEW: {st.APPROVED, st.REJECTED, st.REWORK},
        st.REWORK: {st.IN_PROGRESS},
        st.APPROVED: {st.COMPLETED},
        st.REJECTED: {st.ARCHIVED},
        st.COMPLETED: {st.ARCHIVED},
        st.CANCELLED: {st.ARCHIVED},
        st.ARCHIVED: set(),
    }
    for state in WorkObjectState:
        assert allowed_targets(state) == frozenset(expected[state]), state


def test_membership_sets_match_baseline_specification() -> None:
    """Pins BLOCKABLE_STATES, EVIDENCE_OPEN_STATES and TERMINAL_STATES exactly."""
    s = WorkObjectState
    assert frozenset({s.READY, s.ASSIGNABLE, s.ASSIGNED, s.IN_PROGRESS}) == BLOCKABLE_STATES
    assert (
        frozenset(
            {
                s.DRAFT,
                s.READY,
                s.ASSIGNABLE,
                s.ASSIGNED,
                s.IN_PROGRESS,
                s.OUTPUT_SUBMITTED,
                s.REVIEW,
                s.REWORK,
                s.PAUSED,
                s.BLOCKED,
            }
        )
        == EVIDENCE_OPEN_STATES
    )
    assert frozenset({s.ARCHIVED}) == TERMINAL_STATES
