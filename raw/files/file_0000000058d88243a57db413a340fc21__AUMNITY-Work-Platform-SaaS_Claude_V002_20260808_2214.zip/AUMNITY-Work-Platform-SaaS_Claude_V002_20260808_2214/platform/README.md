# AUMNITY Work Platform — product code (V002 slice)

Reusable multi-tenant SaaS platform kernel. Tenant-neutral by construction:
no customer, tenant or withdrawn module names may appear in `packages/`
(enforced by gate G06).

## Layout
- `packages/aumnity_contracts/` — pure shared contracts (typed IDs, TenantContext,
  events, errors, deterministic providers). Imports nothing from the kernel.
- `packages/aumnity_kernel/` — domain kernel (organisation, identity, work object
  lifecycle, evidence, policy, audit) behind ports; `adapters/memory.py` provides
  in-memory adapters. Kernel domain never imports adapters.
- `tests/` — `unit/`, `contract/` (marker `contract`), `isolation/` (marker
  `isolation`).
- `scripts/gates/` — evidence-producing quality gates G01–G11; evidence lands in
  `evidence/`.

## Running (Python 3.12; pytest, coverage, ruff, mypy installed)
From this `platform/` directory:

```bash
export PYTHONHASHSEED=0
export PYTHONPATH=packages/aumnity_contracts/src:packages/aumnity_kernel/src
python3 -m pytest -q                       # full suite
python3 scripts/gates/run_gates.py         # gate ladder G02..G10 + G01 manifest
python3 scripts/gates/g11_package_release.py  # reproducible release ZIP + smoke test
```

Every gate writes machine-readable evidence to `evidence/`; `gate_ladder.json`
records the ordered run. Claims about tests/coverage/mutation are only valid when
backed by these files.

Version: see `VERSION` (must match `pyproject.toml` and `CHANGELOG.md`; gate G10).
