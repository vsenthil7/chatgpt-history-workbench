"""Explicit tenant context (ADR-002).

Every protected platform operation receives a TenantContext as its first
argument. There is no ambient/global tenant state.
"""

from dataclasses import dataclass

from aumnity_contracts.ids import OrganisationId, PrincipalId, require_identifier


@dataclass(frozen=True, slots=True)
class TenantContext:
    """Identifies the organisation boundary and the acting principal."""

    organisation_id: OrganisationId
    principal_id: PrincipalId

    def __post_init__(self) -> None:
        require_identifier(self.organisation_id, "organisation_id")
        require_identifier(self.principal_id, "principal_id")
