"""Typed identifiers shared across the platform.

Identifiers are opaque non-empty strings. No identifier encodes a customer,
company or environment assumption; generation strategy is injected (providers).
"""

from typing import NewType

from aumnity_contracts.errors import ValidationError

OrganisationId = NewType("OrganisationId", str)
PrincipalId = NewType("PrincipalId", str)
WorkObjectId = NewType("WorkObjectId", str)
EvidenceId = NewType("EvidenceId", str)

_MAX_IDENTIFIER_LENGTH = 128


def require_identifier(value: str, field: str) -> str:
    """Validate an opaque identifier: non-empty, stripped, bounded length."""
    if not isinstance(value, str):  # defensive: kernel is typed, edges may not be
        raise ValidationError(f"{field} must be a string")
    trimmed = value.strip()
    if not trimmed:
        raise ValidationError(f"{field} must be a non-empty string")
    if trimmed != value:
        raise ValidationError(f"{field} must not have surrounding whitespace")
    if len(value) > _MAX_IDENTIFIER_LENGTH:
        raise ValidationError(f"{field} must be at most {_MAX_IDENTIFIER_LENGTH} characters")
    return value
