"""aumnity_contracts: pure shared contracts for the AUMNITY Work Platform SaaS.

This package must never depend on aumnity_kernel, any adapter, any framework,
or any tenant-specific artefact. It defines the vocabulary that bounded product
modules (CGWO, UraiFlow, ...) and the platform kernel share.
"""

from aumnity_contracts.errors import (
    InvalidTransitionError,
    NotFoundError,
    PlatformError,
    PolicyViolationError,
    TenantIsolationError,
    ValidationError,
)
from aumnity_contracts.events import EventEnvelope
from aumnity_contracts.ids import (
    EvidenceId,
    OrganisationId,
    PrincipalId,
    WorkObjectId,
    require_identifier,
)
from aumnity_contracts.providers import Clock, IdGenerator, SequenceIdGenerator, TickingClock
from aumnity_contracts.source_systems import SOURCE_SYSTEM_URAIFLOW
from aumnity_contracts.tenant import TenantContext

__all__ = [
    "SOURCE_SYSTEM_URAIFLOW",
    "Clock",
    "EventEnvelope",
    "EvidenceId",
    "IdGenerator",
    "InvalidTransitionError",
    "NotFoundError",
    "OrganisationId",
    "PlatformError",
    "PolicyViolationError",
    "PrincipalId",
    "SequenceIdGenerator",
    "TenantContext",
    "TenantIsolationError",
    "TickingClock",
    "ValidationError",
    "WorkObjectId",
    "require_identifier",
]
