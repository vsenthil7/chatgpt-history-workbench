"""Registered source-system identifiers for cross-module evidence lineage.

ISS-003: the withdrawn source-system identifier from the baseline data model
(doc 08) is replaced by the standardised name below (governance doc 30).
Modules must use these constants, never string literals.
"""

SOURCE_SYSTEM_URAIFLOW = "URAIFLOW"
