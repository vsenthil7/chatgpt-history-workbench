"""Injectable providers: clock and id generation.

Determinism rule: production adapters may use real clocks/UUIDs; the default
test suite must inject deterministic implementations (no real-clock or random
dependence in tests).
"""

from datetime import UTC, datetime, timedelta
from typing import Protocol


class Clock(Protocol):
    """Source of the current instant."""

    def now(self) -> datetime:
        """Return the current instant as an aware UTC datetime."""
        ...


class IdGenerator(Protocol):
    """Source of new opaque identifiers."""

    def new_id(self, prefix: str) -> str:
        """Return a new unique identifier carrying a human-readable prefix."""
        ...


class TickingClock:
    """Deterministic clock advancing a fixed step per call (test/default adapter)."""

    def __init__(self, start: datetime | None = None, step_seconds: int = 1) -> None:
        self._current = start if start is not None else datetime(2026, 1, 1, tzinfo=UTC)
        self._step = timedelta(seconds=step_seconds)

    def now(self) -> datetime:
        value = self._current
        self._current = self._current + self._step
        return value


class SequenceIdGenerator:
    """Deterministic sequential id generator (test/default adapter)."""

    def __init__(self) -> None:
        self._counter = 0

    def new_id(self, prefix: str) -> str:
        self._counter += 1
        return f"{prefix}-{self._counter:06d}"
