"""Platform error taxonomy (ADR-006).

The HTTP/transport edge (not part of this slice) MUST map TenantIsolationError
to the same external representation as NotFoundError so resource existence is
not leaked across tenants; internally the types stay distinct for audit.
"""


class PlatformError(Exception):
    """Base class for all platform-defined errors."""


class ValidationError(PlatformError):
    """Input failed structural validation."""


class NotFoundError(PlatformError):
    """The addressed record does not exist within the caller's tenant scope."""


class TenantIsolationError(PlatformError):
    """The addressed record exists but belongs to another organisation."""


class InvalidTransitionError(PlatformError):
    """A work-object state transition is not permitted from the current state."""


class PolicyViolationError(PlatformError):
    """A governing policy rejected the requested operation."""
