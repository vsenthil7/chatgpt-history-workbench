"""Work Object registry sub-package."""
