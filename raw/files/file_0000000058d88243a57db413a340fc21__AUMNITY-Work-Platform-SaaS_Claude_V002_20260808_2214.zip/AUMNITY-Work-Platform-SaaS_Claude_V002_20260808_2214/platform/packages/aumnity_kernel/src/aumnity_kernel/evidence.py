"""Immutable evidence records (baseline: evidence over claims)."""

from dataclasses import dataclass
from datetime import datetime
from enum import Enum

from aumnity_contracts import (
    EvidenceId,
    OrganisationId,
    PrincipalId,
    WorkObjectId,
    require_identifier,
)


class EvidenceKind(Enum):
    DOCUMENT = "DOCUMENT"
    AUDIO = "AUDIO"
    TRANSCRIPT = "TRANSCRIPT"
    CODE = "CODE"
    TEST_RESULT = "TEST_RESULT"
    APPROVAL = "APPROVAL"
    CUSTOMER_MESSAGE = "CUSTOMER_MESSAGE"
    SCREENSHOT = "SCREENSHOT"
    DATA_EXTRACT = "DATA_EXTRACT"
    EXTERNAL_SOURCE = "EXTERNAL_SOURCE"


@dataclass(frozen=True, slots=True)
class EvidenceRecord:
    """A frozen reference to a source artefact proving work or a decision.

    content_sha256 fixes the artefact content; source_system/source_reference
    preserve lineage (e.g. a UraiFlow session id) without coupling the kernel
    to any capture module implementation.
    """

    evidence_id: EvidenceId
    organisation_id: OrganisationId
    work_object_id: WorkObjectId
    kind: EvidenceKind
    uri: str
    content_sha256: str
    submitted_by: PrincipalId
    submitted_at: datetime
    source_system: str
    source_reference: str

    def __post_init__(self) -> None:
        require_identifier(self.evidence_id, "evidence_id")
        require_identifier(self.organisation_id, "organisation_id")
        require_identifier(self.work_object_id, "work_object_id")
        require_identifier(self.uri, "uri")
        require_identifier(self.content_sha256, "content_sha256")
        require_identifier(self.submitted_by, "submitted_by")
        require_identifier(self.source_system, "source_system")
        require_identifier(self.source_reference, "source_reference")
