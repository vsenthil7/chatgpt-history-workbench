"""Completion policies (baseline evidence rule).

"No critical Work Object completes without required evidence."
Policies are pure and side-effect free; the registry enforces them.
"""

from typing import Protocol

from aumnity_kernel.workobject.model import RiskLevel, WorkObject


class CompletionPolicy(Protocol):
    """Decides whether a work object may complete."""

    def violations(self, work_object: WorkObject) -> tuple[str, ...]:
        """Return zero or more violation messages; empty means permitted."""
        ...


class CriticalWorkEvidencePolicy:
    """Default platform policy: critical-risk work requires at least one evidence record."""

    def violations(self, work_object: WorkObject) -> tuple[str, ...]:
        if work_object.risk_level is RiskLevel.CRITICAL and not work_object.evidence_ids:
            return ("critical work object requires at least one evidence record",)
        return ()
