"""Adapters implementing kernel ports. V002 ships deterministic in-memory adapters."""
