"""aumnity_kernel: minimum shared platform kernel (V002 slice, ADR-003).

Owns reusable platform primitives only: Organisation, Principal identity,
Work Object registry, Evidence, completion Policy and Audit. Bounded product
logic (CGWO planning, UraiFlow capture) must not be added here.
"""

from aumnity_kernel.audit import AuditLog
from aumnity_kernel.evidence import EvidenceRecord
from aumnity_kernel.identity import Principal, PrincipalKind
from aumnity_kernel.organisation import Organisation, OrganisationRegistry
from aumnity_kernel.policy import CompletionPolicy, CriticalWorkEvidencePolicy
from aumnity_kernel.workobject.model import RiskLevel, WorkObject
from aumnity_kernel.workobject.service import WorkObjectRegistry
from aumnity_kernel.workobject.state import WorkObjectState

__all__ = [
    "AuditLog",
    "CompletionPolicy",
    "CriticalWorkEvidencePolicy",
    "EvidenceRecord",
    "Organisation",
    "OrganisationRegistry",
    "Principal",
    "PrincipalKind",
    "RiskLevel",
    "WorkObject",
    "WorkObjectRegistry",
    "WorkObjectState",
]
