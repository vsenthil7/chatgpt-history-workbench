"""Work Object lifecycle state machine (baseline doc 04/09).

CRITICAL DOMAIN MODULE — mutation gate target (QA-002).

Core path:
DRAFT -> READY -> ASSIGNABLE -> ASSIGNED -> IN_PROGRESS -> OUTPUT_SUBMITTED
-> REVIEW -> APPROVED -> COMPLETED
Alternative states: BLOCKED, PAUSED, REJECTED, REWORK, CANCELLED, ARCHIVED.

BLOCKED remembers the state it interrupted; unblocking returns there.
Every transition is policy-validated, audit-recorded and versioned (registry).
"""

from enum import Enum

from aumnity_contracts import InvalidTransitionError


class WorkObjectState(Enum):
    DRAFT = "DRAFT"
    READY = "READY"
    ASSIGNABLE = "ASSIGNABLE"
    ASSIGNED = "ASSIGNED"
    IN_PROGRESS = "IN_PROGRESS"
    OUTPUT_SUBMITTED = "OUTPUT_SUBMITTED"
    REVIEW = "REVIEW"
    APPROVED = "APPROVED"
    COMPLETED = "COMPLETED"
    BLOCKED = "BLOCKED"
    PAUSED = "PAUSED"
    REJECTED = "REJECTED"
    REWORK = "REWORK"
    CANCELLED = "CANCELLED"
    ARCHIVED = "ARCHIVED"


#: States from which block() may be called; unblock() returns to the remembered state.
BLOCKABLE_STATES: frozenset[WorkObjectState] = frozenset(
    {
        WorkObjectState.READY,
        WorkObjectState.ASSIGNABLE,
        WorkObjectState.ASSIGNED,
        WorkObjectState.IN_PROGRESS,
    }
)

#: States in which evidence may still be attached.
EVIDENCE_OPEN_STATES: frozenset[WorkObjectState] = frozenset(
    {
        WorkObjectState.DRAFT,
        WorkObjectState.READY,
        WorkObjectState.ASSIGNABLE,
        WorkObjectState.ASSIGNED,
        WorkObjectState.IN_PROGRESS,
        WorkObjectState.OUTPUT_SUBMITTED,
        WorkObjectState.REVIEW,
        WorkObjectState.REWORK,
        WorkObjectState.PAUSED,
        WorkObjectState.BLOCKED,
    }
)

#: Terminal states: no further transitions.
TERMINAL_STATES: frozenset[WorkObjectState] = frozenset({WorkObjectState.ARCHIVED})

_ALLOWED: dict[WorkObjectState, frozenset[WorkObjectState]] = {
    WorkObjectState.DRAFT: frozenset({WorkObjectState.READY, WorkObjectState.CANCELLED}),
    WorkObjectState.READY: frozenset(
        {WorkObjectState.ASSIGNABLE, WorkObjectState.BLOCKED, WorkObjectState.CANCELLED}
    ),
    WorkObjectState.ASSIGNABLE: frozenset(
        {WorkObjectState.ASSIGNED, WorkObjectState.BLOCKED, WorkObjectState.CANCELLED}
    ),
    WorkObjectState.ASSIGNED: frozenset(
        {WorkObjectState.IN_PROGRESS, WorkObjectState.BLOCKED, WorkObjectState.CANCELLED}
    ),
    WorkObjectState.IN_PROGRESS: frozenset(
        {
            WorkObjectState.OUTPUT_SUBMITTED,
            WorkObjectState.PAUSED,
            WorkObjectState.BLOCKED,
            WorkObjectState.CANCELLED,
        }
    ),
    WorkObjectState.PAUSED: frozenset({WorkObjectState.IN_PROGRESS, WorkObjectState.CANCELLED}),
    WorkObjectState.BLOCKED: frozenset(set(BLOCKABLE_STATES) | {WorkObjectState.CANCELLED}),
    WorkObjectState.OUTPUT_SUBMITTED: frozenset(
        {WorkObjectState.REVIEW, WorkObjectState.CANCELLED}
    ),
    WorkObjectState.REVIEW: frozenset(
        {WorkObjectState.APPROVED, WorkObjectState.REJECTED, WorkObjectState.REWORK}
    ),
    WorkObjectState.REWORK: frozenset({WorkObjectState.IN_PROGRESS}),
    WorkObjectState.APPROVED: frozenset({WorkObjectState.COMPLETED}),
    WorkObjectState.REJECTED: frozenset({WorkObjectState.ARCHIVED}),
    WorkObjectState.COMPLETED: frozenset({WorkObjectState.ARCHIVED}),
    WorkObjectState.CANCELLED: frozenset({WorkObjectState.ARCHIVED}),
    WorkObjectState.ARCHIVED: frozenset(),
}


def assert_transition(current: WorkObjectState, target: WorkObjectState) -> None:
    """Raise InvalidTransitionError unless current -> target is permitted."""
    if target not in _ALLOWED[current]:
        raise InvalidTransitionError(f"transition not permitted: {current.value} -> {target.value}")


def allowed_targets(current: WorkObjectState) -> frozenset[WorkObjectState]:
    """Return the permitted target states from the given state."""
    return _ALLOWED[current]
