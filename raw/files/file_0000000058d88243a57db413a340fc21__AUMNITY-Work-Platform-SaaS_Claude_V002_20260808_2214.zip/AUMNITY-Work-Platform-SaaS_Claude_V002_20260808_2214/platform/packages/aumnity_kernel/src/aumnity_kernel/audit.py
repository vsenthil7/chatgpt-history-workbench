"""Append-only, tenant-scoped audit trail over event envelopes."""

from aumnity_contracts import EventEnvelope, TenantContext

from aumnity_kernel.ports import AuditSink


class AuditLog:
    """Kernel-facing audit API.

    Writes are append-only; reads are tenant-filtered inside this class so a
    defective sink cannot leak another organisation's entries (ADR-002).
    """

    def __init__(self, sink: AuditSink) -> None:
        self._sink = sink

    def record(self, event: EventEnvelope) -> None:
        self._sink.append(event)

    def entries_for(self, context: TenantContext) -> tuple[EventEnvelope, ...]:
        return tuple(
            event
            for event in self._sink.all_events()
            if event.organisation_id == context.organisation_id
        )
