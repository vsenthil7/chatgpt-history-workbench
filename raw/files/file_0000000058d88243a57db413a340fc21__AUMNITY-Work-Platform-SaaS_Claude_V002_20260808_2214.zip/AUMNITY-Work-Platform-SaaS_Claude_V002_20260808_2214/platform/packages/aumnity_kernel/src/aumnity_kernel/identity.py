"""Principal identity: who can act inside an organisation boundary.

Humans, AI agents and services are all principals (baseline: humans, AI and
teams are actors; the richer Actor/Capability model is deferred to D02).
"""

from dataclasses import dataclass
from enum import Enum

from aumnity_contracts import OrganisationId, PrincipalId, require_identifier


class PrincipalKind(Enum):
    HUMAN = "HUMAN"
    AI = "AI"
    SERVICE = "SERVICE"


@dataclass(frozen=True, slots=True)
class Principal:
    """An identity permitted to act within exactly one organisation."""

    principal_id: PrincipalId
    organisation_id: OrganisationId
    kind: PrincipalKind
    display_name: str

    def __post_init__(self) -> None:
        require_identifier(self.principal_id, "principal_id")
        require_identifier(self.organisation_id, "organisation_id")
        require_identifier(self.display_name, "display_name")
