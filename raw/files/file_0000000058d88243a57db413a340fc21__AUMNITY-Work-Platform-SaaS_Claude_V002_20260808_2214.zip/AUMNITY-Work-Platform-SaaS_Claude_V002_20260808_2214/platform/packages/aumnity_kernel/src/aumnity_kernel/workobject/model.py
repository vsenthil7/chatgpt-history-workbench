"""Work Object aggregate: minimum field set from baseline doc 04 (V002 subset).

Deliberately excluded in this slice (deferred, declared in the RTM):
SLA policy, cost/budget, consent flags, inputs/outputs/deliverables tables,
review/approval policy references beyond the default completion policy.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from aumnity_contracts import (
    EvidenceId,
    OrganisationId,
    PrincipalId,
    ValidationError,
    WorkObjectId,
    require_identifier,
)

from aumnity_kernel.workobject.state import WorkObjectState


class RiskLevel(Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class Priority(Enum):
    LOW = "LOW"
    NORMAL = "NORMAL"
    HIGH = "HIGH"
    URGENT = "URGENT"


@dataclass(slots=True)
class WorkObject:
    """Smallest governed unit of work: purpose, state, owner, evidence, outcome."""

    work_object_id: WorkObjectId
    organisation_id: OrganisationId
    title: str
    purpose: str
    work_type: str
    state: WorkObjectState
    priority: Priority
    risk_level: RiskLevel
    requester_id: PrincipalId
    owner_id: PrincipalId
    created_at: datetime
    updated_at: datetime
    version: int = 1
    parent_id: WorkObjectId | None = None
    assignee_id: PrincipalId | None = None
    blocked_from: WorkObjectState | None = None
    completed_at: datetime | None = None
    evidence_ids: tuple[EvidenceId, ...] = ()
    history: tuple[tuple[int, str, datetime], ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        require_identifier(self.work_object_id, "work_object_id")
        require_identifier(self.organisation_id, "organisation_id")
        require_identifier(self.title, "title")
        require_identifier(self.purpose, "purpose")
        require_identifier(self.work_type, "work_type")
        require_identifier(self.requester_id, "requester_id")
        require_identifier(self.owner_id, "owner_id")
        if self.version < 1:
            raise ValidationError("version must be >= 1")
