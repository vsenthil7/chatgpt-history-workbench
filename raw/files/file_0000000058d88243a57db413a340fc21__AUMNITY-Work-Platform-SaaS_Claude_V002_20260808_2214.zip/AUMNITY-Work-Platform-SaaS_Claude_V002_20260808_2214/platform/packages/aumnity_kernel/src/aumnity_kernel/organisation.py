"""Organisation (tenant) primitive and registry."""

from dataclasses import dataclass
from datetime import datetime

from aumnity_contracts import (
    Clock,
    IdGenerator,
    NotFoundError,
    OrganisationId,
    PrincipalId,
    TenantContext,
    ValidationError,
    require_identifier,
)

from aumnity_kernel.identity import Principal, PrincipalKind
from aumnity_kernel.ports import OrganisationRepository, PrincipalRepository


@dataclass(frozen=True, slots=True)
class Organisation:
    """A tenant boundary: company, team, NGO, partner or client."""

    organisation_id: OrganisationId
    name: str
    created_at: datetime

    def __post_init__(self) -> None:
        require_identifier(self.organisation_id, "organisation_id")
        require_identifier(self.name, "name")


class OrganisationRegistry:
    """Creates organisations and their principals.

    Organisation creation is a platform-operator action and is the only
    operation in the kernel that does not take a TenantContext (there is no
    tenant yet). Principal creation is tenant-scoped.
    """

    def __init__(
        self,
        organisations: OrganisationRepository,
        principals: PrincipalRepository,
        clock: Clock,
        ids: IdGenerator,
    ) -> None:
        self._organisations = organisations
        self._principals = principals
        self._clock = clock
        self._ids = ids

    def create_organisation(self, name: str) -> Organisation:
        organisation = Organisation(
            organisation_id=OrganisationId(self._ids.new_id("org")),
            name=name,
            created_at=self._clock.now(),
        )
        self._organisations.add(organisation)
        return organisation

    def get_organisation(self, organisation_id: OrganisationId) -> Organisation:
        found = self._organisations.get(organisation_id)
        if found is None:
            raise NotFoundError(f"organisation not found: {organisation_id}")
        return found

    def create_principal(
        self, context: TenantContext, kind: PrincipalKind, display_name: str
    ) -> Principal:
        self.get_organisation(context.organisation_id)
        principal = Principal(
            principal_id=PrincipalId(self._ids.new_id("prn")),
            organisation_id=context.organisation_id,
            kind=kind,
            display_name=display_name,
        )
        self._principals.add(principal)
        return principal

    def require_principal(self, context: TenantContext, principal_id: PrincipalId) -> Principal:
        """Load a principal, enforcing the tenant boundary in the kernel (ADR-002)."""
        found = self._principals.get(principal_id)
        if found is None:
            raise NotFoundError(f"principal not found: {principal_id}")
        if found.organisation_id != context.organisation_id:
            raise ValidationError("principal belongs to another organisation")
        return found
