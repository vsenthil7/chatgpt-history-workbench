#!/usr/bin/env python3
"""Run the full applicable gate ladder in order, capturing evidence for each.

Order: G02 static -> G03 unit -> G04 coverage -> G05 contract -> G08 isolation
-> G06 architecture -> G07 mutation -> G09 RTM -> G10 docs -> G01 manifest
(G01 last so the manifest covers freshly generated evidence).
G11 packaging and G12 independent review are performed by the release procedure.
"""

import subprocess
import sys
from pathlib import Path

from _common import EVIDENCE_DIR, PLATFORM_ROOT, write_evidence

ENV = {
    "PYTHONHASHSEED": "0",
    "PYTHONDONTWRITEBYTECODE": "1",
    "PATH": "/usr/local/bin:/usr/bin:/bin",
    "PYTHONPATH": "packages/aumnity_contracts/src:packages/aumnity_kernel/src",
    "HOME": "/tmp",
}
GATES_DIR = Path(__file__).resolve().parent


def _run(name: str, command: list[str], evidence_file: str | None = None) -> dict[str, object]:
    run = subprocess.run(command, cwd=PLATFORM_ROOT, capture_output=True, text=True, env=ENV)
    record = {
        "gate": name,
        "command": " ".join(command),
        "returncode": run.returncode,
        "status": "PASS" if run.returncode == 0 else "FAIL",
    }
    if evidence_file:
        EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
        (EVIDENCE_DIR / evidence_file).write_text(
            run.stdout + ("\n--- stderr ---\n" + run.stderr if run.stderr else "")
        )
        record["evidence"] = f"evidence/{evidence_file}"
    print(f"{name}: {record['status']}  ({record['command']})")
    return record


def main() -> int:
    py = sys.executable
    results = [
        _run(
            "G02-ruff-lint",
            [py, "-m", "ruff", "check", "packages", "tests", "scripts"],
            "g02_ruff_lint.txt",
        ),
        _run(
            "G02-ruff-format",
            [py, "-m", "ruff", "format", "--check", "packages", "tests"],
            "g02_ruff_format.txt",
        ),
        _run("G02-mypy", [py, "-m", "mypy"], "g02_mypy.txt"),
        _run(
            "G03-unit",
            [py, "-m", "pytest", "tests/unit", "-q", "-p", "no:cacheprovider"],
            "g03_unit.txt",
        ),
        _run(
            "G04-coverage",
            [
                py,
                "-m",
                "pytest",
                "-q",
                "-p",
                "no:cacheprovider",
                "--cov",
                "--cov-report=term-missing",
                "--cov-report=json:evidence/g04_coverage.json",
            ],
            "g04_coverage.txt",
        ),
        _run(
            "G05-contract",
            [py, "-m", "pytest", "tests/contract", "-q", "-p", "no:cacheprovider"],
            "g05_contract.txt",
        ),
        _run(
            "G08-isolation",
            [py, "-m", "pytest", "tests/isolation", "-q", "-p", "no:cacheprovider"],
            "g08_isolation.txt",
        ),
        _run("G06-architecture", [py, str(GATES_DIR / "g06_architecture_guard.py")]),
        _run("G07-mutation", [py, str(GATES_DIR / "g07_mutation_gate.py")]),
        _run("G09-rtm", [py, str(GATES_DIR / "g09_rtm_gate.py")]),
        _run("G10-docs", [py, str(GATES_DIR / "g10_docs_gate.py")]),
        _run("G01-manifest-generate", [py, str(GATES_DIR / "g01_validate_package.py"), "generate"]),
        _run("G01-manifest-verify", [py, str(GATES_DIR / "g01_validate_package.py")]),
    ]
    overall = "PASS" if all(r["status"] == "PASS" for r in results) else "FAIL"
    write_evidence("gate_ladder", {"status": overall, "results": results})
    print(f"\nGATE LADDER: {overall}")
    return 0 if overall == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
