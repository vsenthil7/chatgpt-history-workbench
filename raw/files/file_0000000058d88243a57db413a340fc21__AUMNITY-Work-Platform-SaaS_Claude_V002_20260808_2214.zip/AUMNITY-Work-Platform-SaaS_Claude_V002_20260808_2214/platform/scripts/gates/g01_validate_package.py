#!/usr/bin/env python3
"""G01 — repository/manifest gate (resolves ISS-001/ISS-009).

Modes:
  generate  — write PACKAGE-MANIFEST.json at the repo root covering every file
  verify    — recompute every hash/size and detect missing or unlisted files
Exit 0 only when verification is clean.
"""

import hashlib
import json
import sys
from pathlib import Path

from _common import REPO_ROOT, write_evidence

MANIFEST_NAME = "PACKAGE-MANIFEST.json"
EXCLUDED_PARTS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".coverage"}
# Declared (never silent) exclusions: files written BY manifest verification or
# BY packaging itself cannot be captured by the manifest they invalidate.
SELF_REFERENTIAL_EVIDENCE = {
    "platform/evidence/g01_manifest.json",
    "platform/evidence/gate_ladder.json",
    "platform/evidence/g11_packaging.json",
}


def _inventory() -> list[dict[str, object]]:
    entries = []
    for path in sorted(REPO_ROOT.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(REPO_ROOT)
        if rel.name == MANIFEST_NAME and rel.parent == Path("."):
            continue
        if any(part in EXCLUDED_PARTS for part in rel.parts):
            continue
        if rel.as_posix() in SELF_REFERENTIAL_EVIDENCE:
            continue
        data = path.read_bytes()
        entries.append(
            {
                "path": rel.as_posix(),
                "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
            }
        )
    return entries


def generate() -> int:
    manifest = {
        "schema": "aumnity-platform-manifest/v1",
        "project": "AUMNITY Work Platform SaaS",
        "declared_exclusions": sorted(SELF_REFERENTIAL_EVIDENCE),
        "files": _inventory(),
    }
    (REPO_ROOT / MANIFEST_NAME).write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"G01 generate: wrote {len(manifest['files'])} entries")
    return 0


def verify() -> int:
    manifest_path = REPO_ROOT / MANIFEST_NAME
    if not manifest_path.is_file():
        print("G01 FAIL: manifest missing")
        write_evidence("g01_manifest", {"status": "FAIL", "reason": "manifest missing"})
        return 1
    listed = {e["path"]: e for e in json.loads(manifest_path.read_text())["files"]}
    actual = {e["path"]: e for e in _inventory()}
    missing = sorted(set(listed) - set(actual))
    unlisted = sorted(set(actual) - set(listed))
    mismatched = sorted(p for p in set(listed) & set(actual) if listed[p] != actual[p])
    status = "PASS" if not (missing or unlisted or mismatched) else "FAIL"
    write_evidence(
        "g01_manifest",
        {
            "status": status,
            "entries": len(listed),
            "missing": missing,
            "unlisted": unlisted,
            "mismatched": mismatched,
        },
    )
    print(
        f"G01 {status}: {len(listed)} entries, missing={missing}, "
        f"unlisted={unlisted}, mismatched={mismatched}"
    )
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    sys.exit(generate() if "generate" in sys.argv else verify())
