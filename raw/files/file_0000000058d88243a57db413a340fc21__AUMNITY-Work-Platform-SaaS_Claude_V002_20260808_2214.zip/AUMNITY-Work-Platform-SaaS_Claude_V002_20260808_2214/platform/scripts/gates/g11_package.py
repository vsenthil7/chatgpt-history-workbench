#!/usr/bin/env python3
"""G11 — packaging gate: clean-checkout smoke test + reproducible ZIP build.

Steps:
  1. Stage a pristine copy of the repository (caches stripped).
  2. Smoke-test the staged copy as a reviewer would: starter validator,
     manifest verification and the full test suite, all from the copy.
  3. Record evidence, regenerate the manifest so it covers this evidence.
  4. Build the release ZIP twice with normalised metadata; hashes must match.

The final ZIP's own SHA-256 cannot live inside the ZIP; it is printed for the
release report. Everything else is recorded in evidence/g11_packaging.json.
"""

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

from _common import REPO_ROOT, write_evidence

EXCLUDED_PARTS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
ENV = {
    "PYTHONHASHSEED": "0",
    "PATH": "/usr/local/bin:/usr/bin:/bin",
    "HOME": "/tmp",
}


def _stage(destination: Path) -> None:
    shutil.copytree(
        REPO_ROOT,
        destination,
        ignore=shutil.ignore_patterns(*EXCLUDED_PARTS, ".coverage"),
    )


def _smoke(staged: Path) -> list[dict[str, object]]:
    platform = staged / "platform"
    env = {**ENV, "PYTHONPATH": "packages/aumnity_contracts/src:packages/aumnity_kernel/src"}
    checks = [
        (
            "starter-validator",
            [sys.executable, str(staged / "scripts/validate_starter.py")],
            staged,
        ),
        (
            "manifest-verify",
            [sys.executable, str(platform / "scripts/gates/g01_validate_package.py")],
            platform,
        ),
        (
            "full-test-suite",
            [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"],
            platform,
        ),
    ]
    results = []
    for name, command, cwd in checks:
        run = subprocess.run(command, cwd=cwd, capture_output=True, text=True, env=env)
        results.append(
            {
                "check": name,
                "command": " ".join(command),
                "returncode": run.returncode,
                "status": "PASS" if run.returncode == 0 else "FAIL",
                "tail": run.stdout.strip().splitlines()[-2:] if run.stdout.strip() else [],
            }
        )
    return results


def _build_zip(staged: Path, target: Path) -> str:
    files = sorted(
        p
        for p in staged.rglob("*")
        if p.is_file() and not any(part in EXCLUDED_PARTS for part in p.parts)
    )
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            info = zipfile.ZipInfo(
                f"{target.stem}/{path.relative_to(staged).as_posix()}",
                date_time=(2026, 8, 8, 0, 0, 0),
            )
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
    return hashlib.sha256(target.read_bytes()).hexdigest()


def main() -> int:
    zip_name = sys.argv[1]
    output_dir = Path(sys.argv[2])
    with tempfile.TemporaryDirectory() as tmp:
        staged = Path(tmp) / "staged"
        _stage(staged)
        smoke = _smoke(staged)
        smoke_status = "PASS" if all(c["status"] == "PASS" for c in smoke) else "FAIL"
        write_evidence(
            "g11_packaging",
            {
                "status": smoke_status,
                "smoke_checks": smoke,
                "reproducibility": "double-build hash comparison performed after "
                "manifest regeneration; matching hashes reported by this gate's stdout "
                "and the release report (the ZIP hash cannot be stored inside the ZIP)",
            },
        )
        if smoke_status != "PASS":
            print("G11 FAIL: smoke test failed")
            print(json.dumps(smoke, indent=2))
            return 1
    # Manifest must cover the fresh g11 evidence before the final build.
    gates_dir = Path(__file__).resolve().parent
    subprocess.run(
        [sys.executable, str(gates_dir / "g01_validate_package.py"), "generate"],
        cwd=REPO_ROOT,
        check=True,
        env=ENV,
    )
    with tempfile.TemporaryDirectory() as tmp:
        staged = Path(tmp) / "staged"
        _stage(staged)
        first = _build_zip(staged, output_dir / zip_name)
        second_target = Path(tmp) / zip_name
        second = _build_zip(staged, second_target)
    reproducible = first == second
    print(f"G11 smoke: PASS; reproducible build: {'PASS' if reproducible else 'FAIL'}")
    print(f"zip: {output_dir / zip_name}")
    print(f"sha256(build-1): {first}")
    print(f"sha256(build-2): {second}")
    return 0 if reproducible else 1


if __name__ == "__main__":
    sys.exit(main())
