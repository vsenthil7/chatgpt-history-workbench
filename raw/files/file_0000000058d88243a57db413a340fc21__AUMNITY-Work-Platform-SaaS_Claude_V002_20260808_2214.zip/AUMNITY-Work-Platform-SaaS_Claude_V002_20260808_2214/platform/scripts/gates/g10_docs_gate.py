#!/usr/bin/env python3
"""G10 — documentation consistency gate.

Checks (all machine-verifiable, no manual counts):
  C1 product version string identical in pyproject.toml, VERSION and CHANGELOG.
  C2 narrative docs contain no hard-coded test counts (pattern '<N> tests pass');
     counts must live only in generated evidence.
  C3 every ADR listed in ADR-INDEX exists in that file (single-file index).
  C4 all relative doc links in new authoritative docs resolve
     (10-baseline/ is preserved history and exempt: ISS-002).
"""

import re
import sys
import tomllib

from _common import PLATFORM_ROOT, REPO_ROOT, write_evidence

NEW_DOC_DIRS = ["00-control", "05-quality", "06-traceability", "08-ai", "11-issues", "12-adr"]


def main() -> int:
    failures: list[str] = []

    pyproject = tomllib.loads((PLATFORM_ROOT / "pyproject.toml").read_text())
    project_version = pyproject["project"]["version"]
    version_file = (PLATFORM_ROOT / "VERSION").read_text().strip()
    changelog = (PLATFORM_ROOT / "CHANGELOG.md").read_text()
    if version_file != project_version:
        failures.append(f"C1 VERSION={version_file} != pyproject={project_version}")
    if f"## {project_version}" not in changelog:
        failures.append(f"C1 CHANGELOG has no section for {project_version}")

    count_pattern = re.compile(r"\b\d+\s+tests?\s+pass", re.IGNORECASE)
    for directory in NEW_DOC_DIRS:
        for doc in sorted((REPO_ROOT / directory).rglob("*.md")):
            if count_pattern.search(doc.read_text()):
                failures.append(f"C2 hard-coded test count in {doc.relative_to(REPO_ROOT)}")

    adr_index = (REPO_ROOT / "12-adr" / "ADR-INDEX.md").read_text()
    for adr_id in re.findall(r"\| (ADR-\d+) \|", adr_index):
        if f"## {adr_id}" not in adr_index:
            failures.append(f"C3 {adr_id} listed but has no section")

    link_pattern = re.compile(r"\]\(((?!http)[^)#]+)\)")
    for directory in NEW_DOC_DIRS:
        for doc in sorted((REPO_ROOT / directory).rglob("*.md")):
            for link in link_pattern.findall(doc.read_text()):
                target = (doc.parent / link).resolve()
                if not target.exists():
                    failures.append(f"C4 broken link in {doc.relative_to(REPO_ROOT)}: {link}")

    status = "PASS" if not failures else "FAIL"
    write_evidence(
        "g10_docs",
        {"status": status, "project_version": project_version, "failures": failures},
    )
    print(f"G10 {status}: {len(failures)} failure(s)")
    for failure in failures:
        print(" -", failure)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
