"""Shared helpers for quality gates: locate roots, write machine-readable evidence."""

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

PLATFORM_ROOT = Path(__file__).resolve().parents[2]
REPO_ROOT = PLATFORM_ROOT.parent
EVIDENCE_DIR = PLATFORM_ROOT / "evidence"
GATES_DIR = PLATFORM_ROOT / "scripts" / "gates"


def write_evidence(gate: str, result: dict[str, Any]) -> None:
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    result = {"gate": gate, "generated_at": datetime.now(UTC).isoformat(), **result}
    (EVIDENCE_DIR / f"{gate}.json").write_text(json.dumps(result, indent=2) + "\n")
