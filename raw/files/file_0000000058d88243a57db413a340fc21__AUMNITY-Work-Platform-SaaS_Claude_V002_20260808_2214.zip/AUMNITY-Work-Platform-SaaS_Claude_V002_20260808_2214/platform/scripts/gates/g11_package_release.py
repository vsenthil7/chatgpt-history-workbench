#!/usr/bin/env python3
"""G11 — packaging gate: reproducible complete release ZIP + clean-room smoke test.

Procedure (recorded in evidence):
  1. Build the release ZIP twice from the repo tree with normalised metadata
     (fixed mtime 2026-08-08 00:00, sorted entries, no extra attrs); the two
     archives must be byte-identical (sha256 equal) -> reproducibility proven.
  2. Extract the ZIP into a clean temp dir; run G01 manifest verification and
     the full pytest suite inside the extraction -> completeness proven.
  3. Write evidence, regenerate the manifest so it covers this evidence file,
     and rebuild the final ZIP once with the identical deterministic procedure.
     The final archive therefore contains the evidence describing step 1-2; its
     own sha256 is printed and written next to the ZIP in dist/.

Excluded from the archive: caches, coverage db, dist/ itself.
"""

import hashlib
import subprocess
import sys
import tempfile
import zipfile
from datetime import UTC, datetime
from pathlib import Path

from _common import GATES_DIR, REPO_ROOT, write_evidence

DIST = REPO_ROOT.parent / "dist"
STAMP = datetime.now(UTC).strftime("%Y%m%d_%H%M")
ZIP_NAME = f"AUMNITY-Work-Platform-SaaS_Claude_V002_{STAMP}.zip"
FIXED_DATE = (2026, 8, 8, 0, 0, 0)
EXCLUDED_PARTS = {
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".coverage",
    "dist",
}
ENV = {
    "PYTHONHASHSEED": "0",
    "PYTHONDONTWRITEBYTECODE": "1",
    "PATH": "/usr/local/bin:/usr/bin:/bin",
    "PYTHONPATH": "packages/aumnity_contracts/src:packages/aumnity_kernel/src",
    "HOME": "/tmp",
}


def _files() -> list[Path]:
    out = []
    for path in sorted(REPO_ROOT.rglob("*")):
        rel = path.relative_to(REPO_ROOT)
        if any(part in EXCLUDED_PARTS for part in rel.parts):
            continue
        if path.is_file():
            out.append(path)
    return out


def _build(target: Path) -> str:
    root = f"AUMNITY-Work-Platform-SaaS_Claude_V002_{STAMP}"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in _files():
            arcname = f"{root}/{path.relative_to(REPO_ROOT).as_posix()}"
            info = zipfile.ZipInfo(arcname, date_time=FIXED_DATE)
            info.external_attr = 0o644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(info, path.read_bytes())
    return hashlib.sha256(target.read_bytes()).hexdigest()


def _smoke(zip_path: Path) -> dict[str, object]:
    with tempfile.TemporaryDirectory() as tmp:
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(tmp)
        extracted_root = next(Path(tmp).iterdir())
        platform_dir = extracted_root / "platform"
        manifest = subprocess.run(
            [sys.executable, str(platform_dir / "scripts" / "gates" / "g01_validate_package.py")],
            cwd=platform_dir,
            capture_output=True,
            text=True,
            env=ENV,
        )
        tests = subprocess.run(
            [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"],
            cwd=platform_dir,
            capture_output=True,
            text=True,
            env=ENV,
        )
        return {
            "manifest_verify_returncode": manifest.returncode,
            "manifest_verify_tail": manifest.stdout.strip().splitlines()[-1:],
            "pytest_returncode": tests.returncode,
            "pytest_tail": tests.stdout.strip().splitlines()[-1:],
        }


def main() -> int:
    DIST.mkdir(exist_ok=True)
    build_a = DIST / "verify_a.zip"
    build_b = DIST / "verify_b.zip"
    sha_a = _build(build_a)
    sha_b = _build(build_b)
    reproducible = sha_a == sha_b
    smoke = _smoke(build_a)
    smoke_ok = smoke["manifest_verify_returncode"] == 0 and smoke["pytest_returncode"] == 0
    status = "PASS" if (reproducible and smoke_ok) else "FAIL"
    write_evidence(
        "g11_packaging",
        {
            "status": status,
            "procedure": __doc__.strip().splitlines()[0],
            "verification_build_sha256": {"a": sha_a, "b": sha_b},
            "reproducible": reproducible,
            "smoke": smoke,
            "note": (
                "final ZIP is rebuilt after this evidence + manifest regeneration "
                "using the identical deterministic procedure; its sha256 is in "
                "dist/<zip>.sha256"
            ),
        },
    )
    build_a.unlink()
    build_b.unlink()
    if status != "PASS":
        print(f"G11 FAIL: reproducible={reproducible} smoke={smoke}")
        return 1
    # Manifest now must cover the fresh g11 evidence, then final build.
    regen = subprocess.run(
        [sys.executable, str(GATES_DIR / "g01_validate_package.py"), "generate"],
        capture_output=True,
        text=True,
        env=ENV,
    )
    if regen.returncode != 0:
        print("G11 FAIL: manifest regeneration failed")
        return 1
    final = DIST / ZIP_NAME
    sha_final = _build(final)
    (DIST / f"{ZIP_NAME}.sha256").write_text(sha_final + "\n")
    print(f"G11 PASS: reproducible build verified; smoke test green; {final.name}")
    print(f"sha256 {sha_final}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
