# Architecture Decision Records — V002

| ADR | Title | Status |
|---|---|---|
| ADR-001 | Repository layout, language and toolchain for the platform kernel | ACCEPTED |
| ADR-002 | Explicit tenant context and ports-and-adapters isolation model | ACCEPTED |
| ADR-003 | V002 first-slice scope: shared kernel only | ACCEPTED |
| ADR-004 | Deterministic in-repo mutation gate instead of external mutation tool | ACCEPTED |
| ADR-005 | RTM unification and baseline reference corrections | ACCEPTED |
| ADR-006 | Domain error taxonomy and edge mapping for tenant isolation | ACCEPTED |

---

## ADR-001 — Repository layout, language and toolchain
**Context.** The starter demands deterministic builds, 100% line+branch coverage on
executable product packages, architecture guards and machine-readable evidence. The
baseline recommends Python services (FastAPI later).
**Decision.** `platform/` is the product code root. Two packages:
`packages/aumnity_contracts` (pure shared contracts: IDs, tenant context, events, errors,
clock/id-generation protocols — no dependency on any other package) and
`packages/aumnity_kernel` (platform primitives: Organisation, Principal, Work Object
registry, Evidence, Policy, Audit; depends only on `aumnity_contracts`). Python 3.12,
pytest + coverage (branch), ruff, mypy (strict). All quality gates are runnable scripts
under `platform/scripts/gates/` producing JSON/text evidence under `platform/evidence/`.
`PYTHONHASHSEED=0` for gate runs; release ZIP built with normalised mtimes for
reproducibility.
**Consequences.** No web framework or database dependency in V002; the kernel is
importable by future `services/platform_api` without modification.

## ADR-002 — Explicit tenant context and ports-and-adapters
**Context.** SaaS guard: "Protected operations must carry explicit tenant/organisation
context and be tested for cross-tenant denial. Avoid global mutable tenant state."
**Decision.** Every protected kernel operation takes a `TenantContext`
(organisation id + acting principal id) as its first argument. Repositories and the audit
log are ports (Protocols) with in-memory adapters in V002. Repository reads are
tenant-filtered inside the kernel service, never left to the adapter alone: the service
re-checks `organisation_id` on every loaded aggregate and raises `TenantIsolationError`
on mismatch, so a defective adapter cannot silently leak. There is no module-level
mutable tenant state anywhere.
**Consequences.** A PostgreSQL adapter later implements the same ports and inherits the
same contract tests (deferred: RTM row INF-001).

## ADR-003 — V002 first-slice scope
**Context.** First build objective: "harden the platform boundary, define
tenant/organisation semantics and shared contracts, then build the minimum shared kernel
demanded by real bounded modules — not a speculative mega-core." Baseline minimum build
boundary and Brutal Readiness Audit both restrict initial scope.
**Decision.** V002 implements exactly: Organisation registry; Principal identity
(HUMAN/AI/SERVICE); Work Object registry with the baseline lifecycle state machine,
version increments, recursive decomposition (parent/child in same organisation),
minimal assignment-to-principal, immutable evidence attachment with SHA-256 content
reference, evidence-gated completion policy for critical work, and an append-only,
tenant-scoped audit trail emitting the baseline event names. Explicitly deferred with
declared RTM rows: Actor/Capability/Capacity (D02/D03), review-as-work-object (D04),
knowledge/handover (D05), UraiFlow bridge implementation (D06 — the source-system
constant and evidence linkage fields exist as contract only), SLA timers, AI gateway,
service catalogue, pricing, persistence adapter, HTTP edge, Playwright (no
browser-visible journey exists yet, so the Playwright obligation is not triggered).
**Consequences.** CGWO and UraiFlow consume the kernel through its public service API and
events; no bounded-product logic entered the kernel.

## ADR-004 — Deterministic in-repo mutation gate
**Context.** QA-002 requires mutation testing for critical domain/policy logic with
attached evidence. External mutation tools introduce nondeterminism and environment
coupling that conflict with the deterministic-build rule in this sandboxed pipeline.
**Decision.** `g07_mutation_gate.py` performs AST-based mutations (comparison-operator
swaps, boolean-operator swaps, constant flips, arithmetic swaps) over the declared
critical modules (`workobject/state.py`, `policy.py`), runs the fast unit suite per
mutant, and writes a machine-readable kill report. Threshold: 100% of generated mutants
killed; any survivor fails the gate and becomes explicit work.
**Limitation (honest).** The operator set is narrower than a full mutation tool; this is
recorded, not hidden. Adopting `mutmut` in CI proper is a declared follow-up (RTM QA-002
note).
**Consequences.** Mutation evidence is reproducible byte-for-byte across runs.

## ADR-005 — RTM unification and baseline reference corrections
**Context.** ISS-002/ISS-004: two unlinked RTMs and broken renamed references.
**Decision.** `06-traceability/RTM.md` (starter location) is the single authoritative
RTM. Baseline DW-FR-001…015 are imported into it with per-row status; the baseline RTM
file remains untouched under `10-baseline/` and is superseded by reference. Baseline
broken links are documented in `11-issues/BASELINE-ISSUES.md`; baseline files are never
edited, honouring the baseline-preservation rule.
**Consequences.** One requirement namespace; G09 enforces that every ENFORCED row maps to
collectable test node IDs.

## ADR-006 — Error taxonomy and isolation edge mapping
**Context.** Cross-tenant access must be denied and testable, but a public API must not
leak resource existence.
**Decision.** Kernel raises typed errors: `TenantIsolationError` (cross-tenant access),
`NotFoundError`, `InvalidTransitionError`, `PolicyViolationError`, `ValidationError`,
all subclassing `PlatformError`. The future HTTP edge MUST map `TenantIsolationError`
to the same external representation as `NotFoundError` (404) to avoid existence leaks;
inside the trust boundary the distinct type keeps isolation failures observable and
auditable. This mapping obligation is recorded as contract, tested at the edge when the
edge exists (deferred RTM row API-001).
