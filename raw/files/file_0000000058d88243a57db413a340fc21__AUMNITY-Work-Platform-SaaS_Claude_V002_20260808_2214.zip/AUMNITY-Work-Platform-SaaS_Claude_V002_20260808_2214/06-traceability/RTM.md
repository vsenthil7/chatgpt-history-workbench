# Requirement Traceability Matrix — authoritative (V002)

Per ADR-005 this file is the single authoritative RTM. Baseline rows DW-FR-001…015
(`10-baseline/.../18-Requirement-Traceability-Matrix.md`) are imported below; the
baseline file is preserved unedited and superseded by reference.

Status values: ENFORCED (implemented + gate/test evidence, checked by G09),
PARTIAL (subset implemented; remainder declared), DECLARED (requirement accepted,
not yet implemented), DEFERRED (deliberately out of current scope), ACTIVE (process
rule in continuous use).

| ID | Requirement | Owner | Enforcement | Evidence/Test | Status |
|---|---|---|---|---|---|
| ARC-001 | Product code remains within declared bounded ownership | Architecture | architecture guard | `scripts/gates/g06_architecture_guard.py` `evidence/g06_architecture.json` | ENFORCED |
| ARC-002 | Cross-product reuse occurs through published contracts, not copied logic | Architecture | contract tests + dependency guard | `tests/contract/test_public_contracts.py` `evidence/g06_architecture.json` | ENFORCED |
| SaaS-001 | Reusable product code is tenant-neutral | Platform/Product | tenant-leak token guard | `scripts/gates/g06_architecture_guard.py` `evidence/g06_architecture.json` | ENFORCED |
| SaaS-002 | Tenant/org context is explicit at protected boundaries | Platform/Product | isolation tests + signature contract | `tests/isolation/test_tenant_isolation.py` `tests/contract/test_public_contracts.py` | ENFORCED |
| QA-001 | New executable packages meet line+branch coverage policy (100%) | Engineering | coverage gate | `evidence/g04_coverage.json` `evidence/g04_coverage.txt` | ENFORCED |
| QA-002 | Critical domain/policy behavior is mutation tested | Engineering | mutation gate (scoped operators, ADR-004) | `scripts/gates/g07_mutation_gate.py` `evidence/g07_mutation.json` | ENFORCED |
| QA-003 | Escaped defects receive regression tests | Engineering | review/CI process | `evidence/defect-log.md` | ACTIVE |
| DOC-001 | Version, package, test-count and ADR references are consistency checked | Governance | docs gate | `scripts/gates/g10_docs_gate.py` `evidence/g10_docs.json` | ENFORCED |
| AI-001 | Claude build → independent ChatGPT ZIP review loop is used for releases | Governance | release checklist | `evidence/gate_ladder.json` | ACTIVE |
| DW-FR-001 | Create/version Work Object | Work Object registry (kernel) | unit tests + coverage | `tests/unit/test_workobject_lifecycle.py` | ENFORCED |
| DW-FR-002 | Recursive decomposition (parent/child, same organisation) | Work Object registry (kernel) | unit + isolation tests | `tests/unit/test_workobject_lifecycle.py` `tests/isolation/test_tenant_isolation.py` | ENFORCED |
| DW-FR-003 | Assign to human/AI/team with capability matching | Assignment module (deferred D02/D03) | minimal direct assignment only | `tests/unit/test_workobject_lifecycle.py` | PARTIAL |
| DW-FR-004 | Capture capacity/availability | Capacity module (deferred D03) | none yet | none yet | DECLARED |
| DW-FR-005 | Attach immutable evidence | Evidence (kernel) | unit tests, frozen dataclass | `tests/unit/test_workobject_lifecycle.py` `tests/unit/test_kernel_primitives.py` | ENFORCED |
| DW-FR-006 | Review as Work Object | Review module (deferred D04) | lifecycle REVIEW states only | `tests/unit/test_workobject_lifecycle.py` | PARTIAL |
| DW-FR-007 | Approval policy | Governance/kernel policy | completion policy only | `tests/unit/test_kernel_primitives.py` | PARTIAL |
| DW-FR-008 | Knowledge/handover | Knowledge module (deferred D05) | none yet | none yet | DECLARED |
| DW-FR-009 | SLA/priority | SLA module (deferred) | priority field only | none yet | DECLARED |
| DW-FR-010 | UraiFlow bridge | Integration (deferred D06) | source-system contract only | `tests/unit/test_contracts.py` | PARTIAL |
| DW-FR-011 | Provider-neutral AI gateway | AI gateway (deferred) | none yet | none yet | DECLARED |
| DW-FR-012 | Audit/version history | Audit (kernel) | unit tests, append-only sink | `tests/unit/test_workobject_lifecycle.py` `tests/unit/test_kernel_primitives.py` | ENFORCED |
| DW-FR-013 | Organisation isolation | Identity/tenancy (kernel) | isolation suite | `tests/isolation/test_tenant_isolation.py` | ENFORCED |
| DW-FR-014 | Service catalogue | Operations (blocked by market evidence) | none | none | DEFERRED |
| DW-FR-015 | Commercial model / pricing | Pricing (blocked by market evidence) | none | none | DEFERRED |
| SEC-001 | Role/permission authorization beyond tenant boundary | Platform (declared) | acting principal carried, not yet permission-checked | none yet | DECLARED |
| INF-001 | PostgreSQL persistence adapter honouring kernel ports | Infrastructure (declared) | ports defined | `tests/contract/test_public_contracts.py` | DECLARED |
| API-001 | HTTP edge maps TenantIsolationError to NotFound externally (ADR-006) | Platform API (declared) | contract recorded in ADR-006 | none yet | DECLARED |
