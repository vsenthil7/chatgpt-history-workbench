#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, sys
ROOT=Path(__file__).resolve().parents[1]
required=[
 '00-control/PROJECT-START.md','00-control/READING-MAP.md','CLAUDE.md',
 '03-engineering/ENGINEERING-OPERATING-SYSTEM.md','04-testing/TESTING-STRATEGY.md',
 '05-quality/QUALITY-GATES.md','06-traceability/RTM.md',
 '08-ai/CHATGPT-REVIEW-HANDOFF.md','09-governance/VERSIONING-AND-PACKAGING.md'
]
missing=[p for p in required if not (ROOT/p).is_file()]
if missing:
 print('MISSING:', *missing, sep='\n - '); sys.exit(1)
start=(ROOT/'00-control/PROJECT-START.md').read_text(encoding='utf-8')
for marker in ['Project name:', 'First page name:', 'SaaS ownership rule']:
 if marker not in start:
  print('PROJECT-START missing marker:',marker); sys.exit(2)
print('starter package contract: PASS')
