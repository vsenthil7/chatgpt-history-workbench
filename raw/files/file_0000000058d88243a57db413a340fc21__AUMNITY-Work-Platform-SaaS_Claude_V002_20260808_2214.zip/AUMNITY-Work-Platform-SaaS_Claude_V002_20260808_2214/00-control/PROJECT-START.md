# Project Start

**Project name:** AUMNITY Work Platform SaaS  
**First page name:** 00001-SaaS-Platform-Architecture-Baseline  
**Starter artifact:** AUMNITY-Work-Platform-SaaS_ChatGPT_V001_20260808_1318.zip  
**Created:** 08/08/2026 13:18 Europe/London

## SaaS ownership rule
This is a reusable SaaS product. IPBS may be a tenant/user and may sell/support it, but IPBS owns no generic product code.

## Product/pilot boundary
Own the reusable SaaS platform primitives and shared contracts: Organisation/Tenant, Identity, Actor/Resource, Work Object, Capability, Evidence, Policy, Workflow, Audit, Integration and shared domain contracts. Do not absorb bounded product logic that belongs in CGWO or UraiFlow.

## Explicitly not owned
CGWO planning algorithms; UraiFlow capture/transcription/extraction; tenant-specific IPBS workflows/data; payroll/accounting/CRM unless explicitly created later as bounded products.

## First build objective
Harden the platform boundary, define tenant/organisation semantics and shared contracts, then build the minimum shared kernel demanded by real bounded modules—not a speculative mega-core.

## Working pattern
Claude Code = implementation. ChatGPT = independent complete-ZIP review. Repeat version-by-version using evidence, not narrative confidence.

## Baseline preservation
The supplied pre-rebuild artifact is preserved under `10-baseline/`. It is historical/input evidence, not automatically authoritative when it conflicts with this starter contract or a later approved ADR.
