# AUMNITY Work Platform Version History v0.2

## v0.1

Created the first consolidated AUMNITY Work Platform parent-platform blueprint.

## v0.2

### Why changed

v0.1 described the platform but could still be misread as permission to build a broad system. It lacked a hard stop rule, decision authority, minimum build boundary and per-sprint context navigation.

### Added

- documentation stop rule
- frozen/open decision authority
- minimum build boundary
- document reading map
- per-sprint context packs
- explicit discovery gates

### Baseline status

v0.2 is frozen as a discovery/minimal-platform baseline. It is not a full product build specification.

## v0.3 — Standardised identity, visual architecture, help centre and SaaS structure

### Changes

- DWOS renamed to AUMNITY Work Platform.
- KuralFlow references renamed to UraiFlow.
- Numbered HTML architecture page added.
- User-flow help website added.
- Monorepo structure added.
- Product-company/service-company/SaaS relationship recorded.
- Preliminary name-conflict record added.
