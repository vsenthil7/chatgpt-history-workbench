# AUMNITY Work Platform Documentation Control and Stop Rule

AUMNITY Work Platform v0.2 is a **discovery and minimal-platform baseline**, not authorisation to build the entire platform.

## Stop rule

Documentation expansion stops after v0.2 until one of these supplies evidence:

- UraiFlow field usage,
- a paying/pilot client,
- operator workflow evidence,
- workforce-capacity experiment,
- or approved product/business decision.

## Codex rule

Codex may build only explicitly approved minimal sprints. It may not infer:

- marketplace,
- payroll,
- pricing,
- employment model,
- universal industry workflows,
- product-company structure,
- or autonomous assignment policy.

Unknown business choices remain open decisions.
