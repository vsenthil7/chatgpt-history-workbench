# v0.4 Repository and Name Correction

## Repository correction

All documents now reside under `docs/`, including module plans and sprint context packs.

## Name correction

“WorkCore” is withdrawn. Multiple active software and workforce products already use that exact name.

AUMNITY remains the umbrella identity only.

The parent product is temporarily described as:

**AUMNITY Work Platform — final product name pending**

This is a product category label, not a public brand.

## UraiFlow

UraiFlow remains a provisional module/product name until formal registry and trademark clearance.
