# AUMNITY Work Platform Risk, Assumption and Decision Register

## Key risks

- universal Work Object becomes too abstract
- scope expands into ERP
- marketplace vision precedes operator validation
- AI recommendations become opaque
- flexible labour model harms workers
- multi-tenancy added too late
- service-company and product-company responsibilities blur
- configuration complexity overwhelms SMEs

## Decisions

- operator-first validation
- modular monolith initially
- evidence/review first-class
- no covert surveillance
- UraiFlow is first reusable module
- Work Object progressive elaboration
- provider-neutral AI
- separate service and product boundaries

## Open assumptions

- one Work Object model can cover enough industries
- SMEs will pay for managed operations/platform
- workforce capacity can be reliably measured
- partner network can be governed consistently
