# AUMNITY Work Platform Decision Authority and Open Decisions

## Frozen principles

- Work Object is the core governed unit.
- Evidence, review and handover are first-class.
- Humans, AI and teams are actors.
- No covert surveillance.
- UraiFlow is the first source module.
- Operator-first validation.
- Modular architecture.
- AI outputs require lineage.

## Open business decisions

| ID | Decision | Evidence required |
|---|---|---|
| DW-OD-001 | First paying buyer | interviews/pilot |
| DW-OD-002 | First paid workflow | usage evidence |
| DW-OD-003 | Pricing | willingness-to-pay |
| DW-OD-004 | Service versus product company boundary | founder/legal/commercial decision |
| DW-OD-005 | Worker engagement/payment model | legal/operational design |
| DW-OD-006 | Work Object universal fields | field experiments |
| DW-OD-007 | Matching algorithm | capacity experiment |
| DW-OD-008 | Tenant model | client pipeline |
| DW-OD-009 | Review governance | pilot operation |
| DW-OD-010 | Partner governance | partner pilot |

Codex cannot decide these.
