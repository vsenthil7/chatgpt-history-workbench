# Name Standardisation and Search Record

## Former working name

DWOS — Distributed Work Operating System.

## Standardised name

**AUMNITY Work Platform**

## Reason

DWOS is already used by Dental Wings software and “Distributed Work Operating System” appears elsewhere. “WorkOS” is also an active enterprise software company and established category. AUMNITY Work Platform links the platform to the established AUMNITY programme and better distinguishes the product.

## Module naming

The former KuralFlow working name is standardised as **UraiFlow**.

## Limitation

The search was a preliminary internet conflict screen, not legal trademark clearance. Formal registry, company-name, domain and professional legal searches remain mandatory before public launch.
