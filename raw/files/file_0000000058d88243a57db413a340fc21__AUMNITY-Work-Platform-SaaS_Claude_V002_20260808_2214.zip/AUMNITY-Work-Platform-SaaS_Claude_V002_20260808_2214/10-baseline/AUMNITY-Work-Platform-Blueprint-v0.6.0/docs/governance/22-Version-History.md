# AUMNITY Work Platform Version History

## v0.1

First consolidated parent-platform blueprint created from the conversation.

It records:

- vision
- boundaries
- Work Object model
- actors
- modules
- architecture
- data
- events
- workflows
- capacity
- knowledge
- AI governance
- commercial/social model
- UraiFlow integration
- roadmap
- RTM
- risks
- brutal readiness audit
- agent execution model

## Naming issue

“AUMNITY Work Platform” and “DWAS” both appeared in speech. This package preserves **AUMNITY Work Platform** as the working name until a deliberate rename decision is recorded.

## v0.5 — Integrated engineering operating system (2026-07-17 23:49 BST)

**Why changed:** Development, testing, Git and CI must operate as one sprint loop and must not depend on chat memory.

**Changes:** Added `docs/engineering/`; updated every development sprint context with a mandatory entry gate; updated sprint tracker, Codex/agent execution model, document reading map, README and package manifest.

**Required behaviour:** Each sprint performs code, tests, fix loops, Git commits/pushes, remote CI verification, evidence and documentation before closure. The next sprint cannot start until the current sprint passes or receives an approved exception.
