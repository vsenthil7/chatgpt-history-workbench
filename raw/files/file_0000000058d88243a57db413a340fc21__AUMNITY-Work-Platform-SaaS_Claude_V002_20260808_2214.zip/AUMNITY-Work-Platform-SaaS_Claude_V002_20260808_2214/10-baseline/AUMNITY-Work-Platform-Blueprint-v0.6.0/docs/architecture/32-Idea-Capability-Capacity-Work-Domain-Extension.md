# Idea–Capability–Capacity–Work Domain Extension

## Purpose
Connect a continuous stream of business ideas to realistic execution without exceeding organisation, founder, body, mind or TEE capacity.

## Connected models
### Opportunity and Service Formation Model
Idea -> opportunity -> exploration -> service/product model -> readiness -> pilot -> approved/rejected/held.

### Actor Capability Development Model
Actor -> skill evidence -> demonstrated capability -> gap -> training/recruitment -> reassessment.

### Availability and Capacity Model
Monthly forecast -> weekly confirmation -> previous-day confirmation -> same-day adjustment -> reservation -> consumption/release.

### Adaptive Work Planning Model
Overall Planner -> Weekly Planner -> Daily Planner -> Daily Tracker -> Timesheet.

### Work–Resource Alignment Model
Required work + required capability + availability + free capacity + constraints -> proposed allocation -> approval -> reservation.

## Critical rule
A planner view is not the master record. One Work Object may have several plan items, capacity allocations, execution sessions and time entries. Planning history must not be overwritten.
