# AUMNITY Work Platform Data Model

## Core tables/entities

### organisations
### users
### actors
### actor_capabilities
### actor_availability
### capacity_windows

### work_objects
- id
- organisation_id
- parent_id
- work_type_id
- title
- purpose
- description
- state
- priority
- sla_policy_id
- requester_id
- owner_id
- due_at
- risk_level
- version

### work_object_assignments
### work_object_dependencies
### work_object_inputs
### work_object_deliverables
### work_object_evidence
### work_object_outputs
### work_object_reviews
### work_object_approvals
### work_object_events
### work_object_versions

### workflow_templates
### workflow_template_steps
### policies
### service_offerings
### client_contracts
### pricing_rules
### knowledge_objects
### handovers
### partner_organisations
### ai_provider_profiles
### processing_runs
### audit_events

## UraiFlow linkage

- source_system = KURALFLOW
- source_reference = interview/session ID
- evidence links to recording/transcript/export
