# AUMNITY Work Platform Events and State Machines

## Work Object events

- WorkObjectCreated
- WorkObjectDecomposed
- WorkObjectReady
- AssignmentRequested
- ActorMatched
- WorkObjectAssigned
- WorkStarted
- EvidenceAdded
- OutputSubmitted
- ReviewRequested
- ReviewCompleted
- ReworkRequested
- ApprovalGranted
- WorkCompleted
- WorkBlocked
- SLAAtRisk
- WorkCancelled

## Capacity events

- AvailabilityDeclared
- CapacityReserved
- CapacityReleased
- CapacityExceeded
- SkillVerified

## Knowledge events

- KnowledgeCaptured
- HandoverCreated
- KnowledgeLinked
- KnowledgeUpdated

## State-machine rule

Every transition is policy-validated, audit-recorded and versioned.
