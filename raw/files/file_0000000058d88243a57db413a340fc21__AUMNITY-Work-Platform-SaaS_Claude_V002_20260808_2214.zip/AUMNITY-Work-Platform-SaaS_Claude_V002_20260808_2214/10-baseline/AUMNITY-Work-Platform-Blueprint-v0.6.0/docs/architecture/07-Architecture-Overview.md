# AUMNITY Work Platform Architecture Overview

## Initial style

Modular platform with event-driven boundaries. Begin as a modular monolith for core consistency, extracting services when scale/ownership requires it.

## Layers

```text
Experience
- web
- mobile
- partner portals
- APIs

Application
- Work Object orchestration
- assignment
- capacity
- review
- knowledge
- service delivery

Domain
- Work Object
- Actor
- Capability
- Evidence
- Policy
- SLA
- Workflow

Infrastructure
- PostgreSQL
- object storage
- search
- event bus
- AI gateway
- integration connectors
- observability
```

## Recommended stack

- FastAPI/Python for domain/application services
- PostgreSQL
- object storage
- Redis/queue as required
- OpenSearch/Elasticsearch later for evidence/knowledge search
- Flutter/React clients as appropriate
- Docker/Kubernetes later
- provider-neutral AI gateway

## Multi-tenancy

Organisation-bound data isolation from the beginning. Commercial multi-tenant hardening may be phased.
