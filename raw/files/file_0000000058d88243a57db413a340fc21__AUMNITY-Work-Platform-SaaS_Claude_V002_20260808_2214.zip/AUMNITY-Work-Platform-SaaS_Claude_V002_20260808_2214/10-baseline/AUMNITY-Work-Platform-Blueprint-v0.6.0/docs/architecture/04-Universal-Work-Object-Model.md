# Universal Work Object Model

## Minimum fields

- id
- organisation
- title
- purpose
- work_type
- description
- state
- priority
- SLA
- requester
- owner
- assigned actors
- required capabilities
- expected deliverables
- dependencies
- parent/children
- inputs
- evidence
- outputs
- review policy
- approval policy
- due dates
- cost/budget
- risk
- consent/governance
- created/updated/completed timestamps
- version

## Recursive structure

A Work Object may contain:

- discovery,
- planning,
- execution,
- review,
- correction,
- approval,
- deployment,
- monitoring,
- and follow-up Work Objects.

## Core lifecycle

```text
DRAFT
→ READY
→ ASSIGNABLE
→ ASSIGNED
→ IN_PROGRESS
→ OUTPUT_SUBMITTED
→ REVIEW
→ APPROVED
→ COMPLETED
```

Alternative states:

- BLOCKED
- PAUSED
- REJECTED
- REWORK
- CANCELLED
- ARCHIVED

## Evidence rule

No critical Work Object completes without required evidence.

## Progressive elaboration

A Work Object may begin as a hypothesis and gain detail over time. Version history preserves why it changed.
