# Shared Record Proposal and Confirmation Contract

UraiFlow or another capture module may propose writes to one or more AUMNITY records from audio/transcript input.

## Mandatory sequence
Capture -> transcript -> extraction -> candidate records -> target resolution -> validation -> employee review -> confirmation -> atomic commit -> audit.

## Safety rules
- No silent creation of operational records from uncertain speech.
- Show source phrase, proposed field, target table/object and confidence.
- Allow confirm, edit, reject and defer.
- Multi-record writes use one transaction or compensating rollback.
- Preserve transcript lineage and confirmation identity.
