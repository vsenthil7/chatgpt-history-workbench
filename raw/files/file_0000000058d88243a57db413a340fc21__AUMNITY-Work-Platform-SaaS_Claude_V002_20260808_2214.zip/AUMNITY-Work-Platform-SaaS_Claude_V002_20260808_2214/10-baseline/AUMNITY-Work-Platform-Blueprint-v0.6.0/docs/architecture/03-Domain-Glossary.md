# AUMNITY Work Platform Domain Glossary

| Term | Definition |
|---|---|
| Work Object | Smallest governed unit of work with purpose, state, owner, evidence and outcome. |
| Parent Work Object | Work Object containing or depending on child Work Objects. |
| Child Work Object | Decomposed unit contributing to a parent. |
| Actor | Human, AI agent, team, partner or system that performs work. |
| Capability | Demonstrated ability to perform a work type. |
| Capacity | Available quantity of effort in a time window. |
| Availability | When an actor can accept work. |
| Assignment | Binding of Work Object to actor. |
| Evidence | Source artefact proving work or decision. |
| Deliverable | Expected output of a Work Object. |
| Review | Independent validation activity represented as work. |
| Approval | Authorised decision accepting/rejecting output. |
| SLA | Time/service commitment. |
| Priority | Relative urgency/importance. |
| Handover | Structured transfer of mission, decisions, evidence and open items. |
| Knowledge Object | Reusable knowledge linked to work. |
| Policy | Rule governing assignment, execution or review. |
| Workflow Template | Reusable pattern of Work Objects and transitions. |
| Service Offering | Commercially packaged capability delivered through AUMNITY Work Platform. |
| Organisation | Company, team, NGO, partner or client boundary. |
| UraiFlow Session | Conversation evidence source that can create Work Objects. |
