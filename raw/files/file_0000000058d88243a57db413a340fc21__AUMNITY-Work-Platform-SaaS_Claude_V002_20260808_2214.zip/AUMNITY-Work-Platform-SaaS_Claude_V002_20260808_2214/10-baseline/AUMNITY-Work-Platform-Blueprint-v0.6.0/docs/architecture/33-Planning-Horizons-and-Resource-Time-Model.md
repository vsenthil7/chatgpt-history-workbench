# Planning Horizons and Resource Time Model

## Planning horizons
- Overall: captured work with no near-term commitment.
- Monthly: portfolio and skill-capacity forecast.
- Weekly: provisional commitment and resource alignment.
- Previous day: tomorrow's realistic availability and plan review.
- Daily: current intention, explicitly changeable.
- Real time: actual execution, interruption and reallocation.

## Resource time concepts
Availability is when an Actor can contribute. Capacity is the realistic amount of effort. Readiness covers whether the Actor can safely and effectively perform the work. Reservation protects capacity for planned work. Consumption is actual effort.

## Founder/TEE capacity
An initiative may be technically resourced but unaffordable because founder decision, review or TEE supervision capacity is unavailable. This must be represented as a capacity requirement, not an informal afterthought.
