# Core Workflow Scenarios

## Flexible workforce assignment

```text
Client demand
→ Work Objects created
→ capabilities required
→ availability/capacity checked
→ actor matched
→ assignment offered
→ accepted
→ work performed
→ evidence submitted
→ review
→ completion/payment input
```

## AI-human collaboration

```text
Work Object classified
→ AI drafts/researches
→ human validates
→ correction/rework
→ final approval
→ evidence retained
```

## Discovery-to-service

```text
UraiFlow interview
→ pain point identified
→ follow-up Work Object
→ analysis
→ service proposal
→ onboarding
→ delivery workflow
```

## Review as work

Every review has:

- owner
- expected criteria
- evidence
- decision
- duration
- outcome
- and possible child rework.
