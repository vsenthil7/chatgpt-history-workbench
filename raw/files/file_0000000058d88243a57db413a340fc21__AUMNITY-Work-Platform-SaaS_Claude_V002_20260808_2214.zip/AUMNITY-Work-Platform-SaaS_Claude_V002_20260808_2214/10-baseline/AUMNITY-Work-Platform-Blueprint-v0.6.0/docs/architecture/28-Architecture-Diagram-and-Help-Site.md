# Architecture Diagram and Help Site

- Architecture: `docs/architecture/index.html`
- Help centre: `docs/help/index.html`

The architecture uses numbered components with matching explanations. Help pages document operator, worker, reviewer and UraiFlow bridge flows.
