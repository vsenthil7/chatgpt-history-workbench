# Documentation and Change Control

## Single-source principle

Shared procedures are maintained once under `docs/engineering/` and referenced by sprint trackers and context packs. Do not copy the entire lifecycle into every sprint document.

## When documentation must change

Update approved documentation when implementation reveals:

- a missing or conflicting requirement;
- an architecture, API, data, security or operational decision;
- a new dependency or environment constraint;
- a changed test or quality gate;
- a changed release, rollback or support procedure.

## Change process

1. Record the discovery.
2. Classify as clarification, defect, open decision or change request.
3. Identify impacted documents, sprints, requirements and tests.
4. Obtain the required decision authority.
5. Update the source document and version history.
6. Update references, RTM and affected context packs only where links or scope changed.
7. Review and approve before implementation continues when the change is material.

## Anti-hallucination rule

Coding agents must not fill gaps by inference where the result affects product behaviour, security, data, compliance, commercial rules or acceptance criteria. They must stop and request a documented decision.

## Context-efficiency rule

At project start, read the global baseline once. For each sprint, read this engineering entry point, the sprint context pack and only linked documents. Do not load the entire package unless conducting a full architecture review.
