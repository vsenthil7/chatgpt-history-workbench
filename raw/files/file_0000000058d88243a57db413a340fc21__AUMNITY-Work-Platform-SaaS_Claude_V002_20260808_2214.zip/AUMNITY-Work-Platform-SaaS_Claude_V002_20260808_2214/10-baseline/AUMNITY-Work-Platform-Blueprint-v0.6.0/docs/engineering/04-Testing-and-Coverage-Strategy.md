# Testing and Coverage Strategy

## Core rule

Every sprint creates and executes the tests necessary for its own scope. A later testing sprint may add broad release certification, but it cannot substitute for tests that should have accompanied earlier implementation.

## Required test layers

Apply as relevant:

- unit tests for domain rules, calculations and state transitions;
- component/widget tests for isolated UI behaviour;
- integration tests across application, service, database and messaging boundaries;
- API contract tests for request, response, error and compatibility behaviour;
- database migration, constraint, rollback and idempotency tests;
- functional tests mapped to acceptance criteria;
- negative tests for invalid, missing, duplicate, unauthorized and out-of-order inputs;
- permission and tenant-isolation tests;
- recovery and resilience tests for restarts, network loss, timeout and dependency failure;
- security tests and dependency/secret scans;
- Playwright end-to-end tests for browser-visible critical journeys;
- regression tests for every corrected defect where feasible.

## Coverage policy

The goal is not a cosmetic percentage. Mandatory targets are:

- 100% requirement traceability for in-scope sprint requirements;
- 100% acceptance-criterion mapping and execution;
- 100% planned critical-path execution;
- 100% planned negative-case execution;
- 100% planned Playwright scenario execution;
- configured code-coverage thresholds passing.

Business-domain and state-machine code should target 100% branch coverage. Repository-wide coverage may exclude generated code, framework bootstrap or unreachable platform glue only through documented, reviewed exclusions. Tests written only to inflate coverage are prohibited.

## Coverage evidence

Record statement, branch and function/method coverage as supported by the stack. Preserve threshold configuration, summaries and links to full CI artefacts. For critical domain rules, use mutation testing where practical to prove tests detect behavioural defects.

## Test data

Use deterministic, privacy-safe test data. Never use production personal data in automated tests. Version fixtures and builders with the contracts they validate.

## Defect severity gate

- Critical: blocks sprint and release.
- High: blocks sprint closure unless explicitly risk-accepted by authorized decision owner.
- Medium/Low: must be documented, assigned and evaluated against release criteria.
