# Development Lifecycle

## Principle

Development, testing, evidence, Git history and CI verification are one integrated activity. Testing is not a later phase and must not be deferred to a separate final sprint.

## Lifecycle states

`PLANNED → READY → IN DEVELOPMENT → LOCAL GATES PASSING → PUSHED → CI PASSING → DOCUMENTED → CLOSED`

Failure may move the sprint back to `IN DEVELOPMENT`; it must never be hidden by marking the sprint complete.

## Entry gate

Before coding, confirm:

- approved sprint ID and objective;
- in-scope and explicitly out-of-scope requirements;
- linked RTM rows and acceptance criteria;
- affected modules, data migrations, APIs and user journeys;
- required test types and test data;
- environment and dependency readiness;
- known risks and unresolved decisions;
- branch and evidence locations.

If any blocking item is missing, stop and raise an open decision rather than inventing an answer.

## Integrated implementation rule

For each production change, add or update the tests required to prove it. A feature commit without its necessary test coverage is incomplete. Tests may be committed in a following checkpoint commit, but the sprint cannot pass a quality gate until code and tests are present together in the branch.

## Failure loop

For every failure:

1. Preserve the command, environment, timestamp and output.
2. Classify failure as product defect, test defect, environment defect, data defect or documentation defect.
3. Identify root cause.
4. Correct the smallest appropriate unit.
5. Add or strengthen a regression test where relevant.
6. Rerun the failed test, its containing suite and affected regression suites.
7. Commit and push the correction.
8. Verify remote CI again.

## Exit gate

Sprint exit requires all planned scope delivered or explicitly deferred through approved change control, all mandatory tests passing, CI green, evidence recorded, documentation synchronized and no unresolved Critical or High defect.
