# Playwright and End-to-End Standards

## Scope

Playwright validates user-visible browser workflows and cross-layer integration. It complements unit and integration testing; it does not replace them.

## Sprint obligation

Any sprint that introduces or changes a browser-visible journey must create or update Playwright coverage in the same sprint. Critical journeys must include happy-path, negative, permission and recovery cases where applicable.

## Standards

- Use stable semantic locators such as role, label and test IDs; avoid brittle CSS chains.
- Isolate test data and make tests repeatable in parallel.
- Avoid fixed sleeps; wait on observable application conditions.
- Capture trace, screenshot and video on failure according to CI policy.
- Test supported browser/device profiles defined by the compatibility matrix.
- Validate accessibility-critical labels and keyboard flows where applicable.
- Keep secrets in CI secret stores, never in test code.
- Use API or fixture setup when it improves speed without bypassing the behaviour under test.

## Minimum scenario set

For each applicable feature:

1. primary successful journey;
2. required validation and malformed input;
3. authorization/role restriction;
4. duplicate or idempotency behaviour;
5. dependency/network failure or retry behaviour;
6. persistence and reload/resume behaviour;
7. audit/evidence visibility where required.

## Flakiness rule

A flaky test is a defect. Quarantine requires an owner, reason, expiry and linked corrective work. Re-running until green without root-cause analysis is prohibited.
