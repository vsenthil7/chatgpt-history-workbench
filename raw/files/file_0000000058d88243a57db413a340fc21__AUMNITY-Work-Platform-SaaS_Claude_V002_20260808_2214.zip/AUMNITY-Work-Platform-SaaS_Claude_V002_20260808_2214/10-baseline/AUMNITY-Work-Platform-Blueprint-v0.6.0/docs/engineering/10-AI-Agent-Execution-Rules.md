# AI and Coding-Agent Execution Rules

## Authority

An AI coding agent executes approved work; it does not become the product owner or architecture authority.

## Mandatory behaviour

- Read the engineering entry point and sprint context before coding.
- State scope, non-scope, assumptions, risks and open decisions.
- Map requirements to code and tests before implementation.
- Work one sprint and one approved slice at a time.
- Create tests with the implementation, not later.
- Preserve failure evidence and report honestly.
- Use meaningful Git commits and verify remote CI.
- Update documentation and RTM before closure.
- Stop when credentials, infrastructure, policy or product decisions are missing.

## Prohibited behaviour

- silently shrinking or expanding scope;
- inventing requirements, business rules or data contracts;
- marking compilation as completion;
- declaring tests passed without executing them;
- weakening or deleting tests merely to obtain green CI;
- excluding code from coverage without documented approval;
- bypassing protected checks or committing secrets;
- proceeding to the next sprint while the current sprint is failed or blocked.

## Required end-of-sprint report

The report records attempted, completed, failed and deferred work; files changed; requirements covered; tests created and executed; coverage; failures and fixes; commits and final SHA; push and CI status; documentation updates; known limitations; exceptions and final verdict.
