# Versioning and Release Process

## Documentation package versioning

Every approved package amendment creates a new version. Prior packages remain immutable. The changelog must state what changed, why, affected documents, compatibility impact and review status.

## Software versioning

Use the product's approved versioning policy. Every release must identify:

- product version and channel;
- source commit SHA and tag;
- build artefact hashes;
- schema/migration version;
- compatible client/server versions;
- configuration and dependency baseline;
- release notes and known issues;
- rollback target and procedure.

## Sprint-to-release traceability

Each release references included sprint IDs, RTM rows, test evidence and approved exceptions. A release may aggregate closed sprints, but it must not hide an incomplete sprint.

## Rollback

Rollback readiness includes application rollback, schema/data compatibility, configuration restoration, operational decision owner and validation steps. Irreversible changes require explicit approval and recovery planning before merge.
