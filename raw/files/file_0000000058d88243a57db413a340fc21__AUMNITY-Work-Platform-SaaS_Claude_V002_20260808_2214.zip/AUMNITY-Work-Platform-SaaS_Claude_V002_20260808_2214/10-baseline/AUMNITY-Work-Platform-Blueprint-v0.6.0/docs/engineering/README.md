# Engineering Documentation

Start with `00-Engineering-Operating-System.md` before every sprint.

This folder is the reusable engineering process layer. Sprint trackers and context packs reference these documents so the development procedure can be amended and versioned in one place without duplicating it across every sprint.

## Contents

- Engineering Operating System and precedence
- integrated development lifecycle
- sprint execution loop
- Git workflow and traceability
- testing and coverage strategy
- Playwright/E2E standards
- CI/CD gates
- Definition of Done and closure
- documentation/change control
- versioning/release process
- AI-agent execution rules
