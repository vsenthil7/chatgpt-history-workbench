# Sprint Execution Procedure

## Phase 0 — Prepare

- Read the mandatory engineering baseline and sprint context pack.
- Record sprint objective, scope, non-scope, dependencies and risks.
- Resolve document conflicts using the precedence rules.
- Create a sprint execution record and evidence directory.
- Establish requirement-to-code-to-test mappings before implementation.

## Phase 1 — Branch and baseline

- Synchronize with the approved base branch.
- Create the sprint branch using the Git workflow.
- Run the clean baseline build and test suite.
- Record pre-existing failures separately; do not attribute them to new work.

## Phase 2 — Implement in vertical slices

For each acceptance criterion:

1. Implement the smallest releasable behaviour.
2. Add unit/component tests for business and boundary logic.
3. Add integration/contract/database tests where system boundaries are touched.
4. Add functional, negative, permission, recovery and resilience tests as applicable.
5. Add or update Playwright end-to-end journeys for browser-visible behaviour.
6. Run affected suites immediately.
7. Commit a meaningful checkpoint when the slice is coherent.

## Phase 3 — Full local verification

Run all applicable gates:

- format and lint;
- compile/type check/static analysis;
- dependency, secret and security scans;
- unit/component tests;
- integration, API contract and database tests;
- functional and negative tests;
- Playwright end-to-end tests;
- coverage and mutation checks where required;
- production-like build and migration verification.

## Phase 4 — Push and remote verification

- Push the sprint branch.
- Verify CI against the exact pushed commit SHA.
- Where CI fails, preserve logs, fix, commit, push and rerun.
- Do not treat an unverified push as completion.

## Phase 5 — Documentation and evidence

Update:

- sprint tracker;
- RTM and acceptance mapping;
- ADR/open-decision records where required;
- API/data/schema documentation;
- operator/user/help documentation affected by the change;
- evidence index and test summary;
- known issues and release notes.

## Phase 6 — Closure

Produce a sprint implementation-and-test report containing scope, files changed, tests added, results, coverage, failures and fixes, commit list, branch and CI status, documentation changes, known limitations and final verdict.

The next sprint may start only after closure is approved or a formally recorded exception is granted.
