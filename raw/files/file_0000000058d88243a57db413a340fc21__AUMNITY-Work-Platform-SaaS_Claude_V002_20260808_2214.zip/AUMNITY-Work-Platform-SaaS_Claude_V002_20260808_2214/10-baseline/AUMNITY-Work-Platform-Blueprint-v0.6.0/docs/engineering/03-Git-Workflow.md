# Git Workflow and Traceability

## Objective

Git must provide a truthful, auditable history of engineering effort: what changed, why, which requirement it served, which tests proved it, what failed and how it was corrected.

## Branch model

Use one branch per sprint or approved change:

- `sprint/<sprint-id>-<short-scope>`
- `fix/<defect-id>-<short-description>`
- `hotfix/<incident-id>-<short-description>`

The approved base branch is protected. Direct unreviewed commits to the protected branch are prohibited.

## Commit principles

- Commit coherent checkpoints, not arbitrary time slices.
- Keep production code and its tests close in history.
- Never conceal failures by squashing away evidence before the sprint report is prepared.
- Never commit secrets, personal data, generated dependency folders or large transient test artefacts.
- Reference sprint ID and requirement/defect IDs where practical.

Recommended Conventional Commit forms:

- `feat(MS-02): implement resumable audio recording [REQ-AUD-03]`
- `test(MS-02): add crash-recovery and negative recording cases`
- `fix(MS-02): prevent duplicate media segment after restart`
- `docs(MS-02): update RTM, evidence and recovery runbook`

## Push and CI rule

After each meaningful integrated checkpoint or at minimum before a quality gate:

1. Push the branch.
2. Record commit SHA.
3. Verify CI against that SHA.
4. If failed, fix locally, commit, push and verify again.

The sprint report records all final commits and significant corrective commits. Git activity is evidence of work, but commit count alone is never used as a productivity score.

## Merge gate

Merge is allowed only when:

- required reviewers approve;
- protected checks pass;
- no unresolved Critical or High defect remains;
- RTM and documentation are synchronized;
- release/rollback implications are recorded;
- the sprint Definition of Done passes.

## Artefact storage

Store source, tests, CI configuration, reproducible scripts, evidence summaries and manifests in Git. Store heavy videos, traces, screenshots and binary reports as CI/release artefacts, retaining stable references and hashes in the repository.
