# Definition of Done and Sprint Closure

A sprint is done only when all applicable statements are true.

## Scope and traceability

- Approved sprint scope is delivered or formally deferred.
- Every in-scope requirement and acceptance criterion maps to implementation and tests.
- No undocumented design or business decision remains.

## Code and build

- Code is reviewed, maintainable and aligned with architecture.
- Clean checkout/build succeeds.
- Required migrations, configuration and seed paths work.
- No secret or prohibited data is committed.

## Testing

- All planned test layers are implemented and passing.
- Functional and negative cases pass.
- Playwright scenarios pass where applicable.
- Coverage thresholds pass without unjustified exclusions.
- Critical regression tests exist for corrected defects.
- No unresolved Critical or High defect remains, except an explicitly authorized High-risk acceptance.

## Git and CI

- Meaningful commits are pushed.
- Final commit SHA is recorded.
- Remote CI passes against the final SHA.
- Required review and branch-protection rules pass.

## Documentation and evidence

- RTM, sprint tracker and acceptance mappings are current.
- ADRs/open decisions and API/data/help/runbook documents are updated where affected.
- Test summaries, coverage, logs and artefact references are indexed.
- Release notes, known issues and rollback information are updated.
- Sprint implementation-and-test report is complete and truthful.

## Closure verdict

Allowed verdicts:

- `PASS — CLOSED`
- `FAIL — RETURN TO DEVELOPMENT`
- `BLOCKED — OPEN DECISION/DEPENDENCY`
- `EXCEPTION — AUTHORIZED WITH EXPIRY`

Only `PASS — CLOSED` normally permits the next sprint to begin.
