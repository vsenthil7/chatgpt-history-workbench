# CI/CD Quality Gates

## Principle

The exact pushed commit must pass remote automated gates before sprint closure or merge. Local success alone is insufficient.

## Pull-request gates

Configure as applicable:

- formatting and linting;
- compile/type/static checks;
- secret and dependency vulnerability scanning;
- unit/component tests;
- integration/API/database tests;
- functional and negative suites;
- Playwright end-to-end suites;
- code coverage threshold and exclusion validation;
- build/package verification;
- migration from clean database and upgrade-path validation;
- documentation link/manifest validation;
- artefact and evidence publication.

## Branch protection

Protected branches require successful checks and review. Required checks cannot be bypassed by a coding agent. Emergency override must be authorized, logged and followed by corrective verification.

## Failure handling

CI failure returns the sprint to development. Record failing SHA, job, command, logs, classification and fix. Push a new commit and rerun all affected gates. Never edit a report to claim success while CI remains red.

## Release gates

Before release, verify:

- immutable source SHA and version/tag;
- reproducible build artefacts and hashes;
- migration and rollback readiness;
- environment configuration validation;
- smoke and critical-path tests in release-like environment;
- release notes, known issues and operational runbook;
- approval and go/no-go evidence.
