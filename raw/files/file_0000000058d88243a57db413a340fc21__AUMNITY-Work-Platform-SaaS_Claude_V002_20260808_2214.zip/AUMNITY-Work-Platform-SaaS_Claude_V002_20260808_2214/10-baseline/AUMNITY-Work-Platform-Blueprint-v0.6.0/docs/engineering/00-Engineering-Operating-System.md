# Engineering Operating System

## Purpose

This document is the mandatory entry point for every development sprint. It defines how approved planning is converted into traceable, tested and releasable software. It applies to Codex, ChatGPT, Claude Code, other coding agents and human engineers.

## Non-negotiable lifecycle

Every sprint follows one closed loop:

1. Read the approved sprint context and linked documents.
2. Confirm entry criteria, scope, requirements, risks and open decisions.
3. Create or select the sprint branch.
4. Map every in-scope requirement and acceptance criterion to source files and test files before implementation.
5. Implement only approved sprint scope.
6. Create or update all applicable automated tests in the same sprint.
7. Run formatting, linting, type checks, static analysis, security checks, builds and tests.
8. Record failures and evidence; fix code or tests; rerun affected and regression suites.
9. Commit meaningful checkpoints and push the branch.
10. Verify remote CI. A local pass is not sufficient.
11. Repeat fix → commit → push → CI until all mandatory gates pass.
12. Update RTM, sprint tracker, ADRs, documentation, evidence index and release notes.
13. Close the sprint only after Definition of Done is satisfied.
14. Do not start the next sprint while the current sprint is failed, incomplete or undocumented, unless an explicit approved exception exists.

## Mandatory reading sequence for every sprint

1. This document.
2. `01-Development-Lifecycle.md`.
3. `02-Sprint-Execution-Procedure.md`.
4. `03-Git-Workflow.md`.
5. `04-Testing-and-Coverage-Strategy.md`.
6. `05-Playwright-and-E2E-Standards.md`.
7. `06-CI-CD-Quality-Gates.md`.
8. `07-Definition-of-Done-and-Sprint-Closure.md`.
9. The sprint tracker and corresponding sprint context pack.
10. Only the module, architecture, API, data, security and acceptance documents linked by that context pack.

## Source-of-truth rule

The approved documentation package is the implementation source of truth. Chat history, memory and ad-hoc prompts cannot override an approved document. Missing or conflicting requirements must become an open decision or change request; they must not be guessed.

## Change-control rule

The shared engineering process is referenced by sprint documents rather than duplicated into each sprint. Process changes are made here or in the linked engineering documents, versioned once, reviewed, and then inherited by all future sprints.

## Document precedence

1. Approved change decision / ADR.
2. Approved architecture, domain model, API and data contract.
3. Engineering Operating System and its linked procedures.
4. Sprint context pack and sprint tracker.
5. Module planner and acceptance criteria.
6. Execution prompt.
7. Chat instruction or coding-agent suggestion.

A lower-level source cannot silently override a higher-level source.
