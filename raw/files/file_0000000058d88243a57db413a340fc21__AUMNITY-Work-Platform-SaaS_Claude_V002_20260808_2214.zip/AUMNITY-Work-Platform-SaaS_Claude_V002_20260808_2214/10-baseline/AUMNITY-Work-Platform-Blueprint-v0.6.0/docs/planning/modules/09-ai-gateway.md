# Module Plan — AI Gateway

Provider capability registry, prompt/model lineage, routing and evaluation.
