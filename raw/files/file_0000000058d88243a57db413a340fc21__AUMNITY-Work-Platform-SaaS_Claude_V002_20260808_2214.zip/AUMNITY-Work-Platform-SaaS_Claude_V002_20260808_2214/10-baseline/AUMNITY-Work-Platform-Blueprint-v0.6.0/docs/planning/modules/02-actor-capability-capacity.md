# Module Plan — Actor, Capability and Capacity

Actors, skills, availability, reservations and matching inputs.
