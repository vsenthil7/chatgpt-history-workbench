# AUMNITY Work Platform Minimum Build Boundary

## Build now only

1. Work Object registry
2. actor/capability basics
3. evidence attachment
4. review/rework/approval
5. UraiFlow event bridge
6. simple operator queue
7. minimal capacity declaration

## Do not build now

- marketplace
- payroll
- billing engine
- complex pricing
- partner network
- advanced matching
- multi-industry templates
- autonomous workforce decisions
- full analytics platform
- Kubernetes/microservices
- portable reputation
- public self-service SaaS
