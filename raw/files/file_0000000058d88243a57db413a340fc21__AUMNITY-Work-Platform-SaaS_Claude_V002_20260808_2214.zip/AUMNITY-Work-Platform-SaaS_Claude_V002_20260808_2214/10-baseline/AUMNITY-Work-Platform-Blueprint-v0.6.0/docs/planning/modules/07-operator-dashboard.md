# Module Plan — Operator Dashboard

Work queues, capacity, SLA risk, review queue and evidence status.
