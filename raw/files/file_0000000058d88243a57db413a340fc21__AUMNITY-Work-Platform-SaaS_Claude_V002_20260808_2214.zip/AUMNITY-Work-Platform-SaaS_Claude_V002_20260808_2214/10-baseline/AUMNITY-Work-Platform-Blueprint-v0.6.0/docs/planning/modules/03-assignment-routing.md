# Module Plan — Assignment and Routing

Human/AI/team assignment, policy, offer/accept and fallback.
