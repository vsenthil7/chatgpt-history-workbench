# Module Plan — Service Catalogue

Offerings, workflow templates, client onboarding and delivery.
