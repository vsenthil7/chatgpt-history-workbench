# AUMNITY Work Platform Requirement Traceability Matrix

| Requirement | Domain/module | Planned evidence | Status |
|---|---|---|---|
| DW-FR-001 Create/version Work Object | Work Object registry | schema/state/unit/integration | NOT STARTED |
| DW-FR-002 Recursive decomposition | Work Object hierarchy | dependency/tree tests | NOT STARTED |
| DW-FR-003 Assign to human/AI/team | Assignment | matching/authorisation tests | NOT STARTED |
| DW-FR-004 Capture capacity/availability | Capacity | reservation/overbooking tests | NOT STARTED |
| DW-FR-005 Attach immutable evidence | Evidence | storage/audit tests | NOT STARTED |
| DW-FR-006 Review as Work Object | Review | review/rework E2E | NOT STARTED |
| DW-FR-007 Approval policy | Governance | policy transition tests | NOT STARTED |
| DW-FR-008 Knowledge/handover | Knowledge | handoff completeness tests | NOT STARTED |
| DW-FR-009 SLA/priority | SLA | timer/escalation tests | NOT STARTED |
| DW-FR-010 UraiFlow bridge | Integration | event/Work Object contract | NOT STARTED |
| DW-FR-011 Provider-neutral AI | AI gateway | adapter contracts | NOT STARTED |
| DW-FR-012 Audit/version history | Audit | immutable event tests | NOT STARTED |
| DW-FR-013 Organisation isolation | Identity | tenancy/security tests | NOT STARTED |
| DW-FR-014 Service catalogue | Operations | workflow template E2E | NOT STARTED |
| DW-FR-015 Commercial model | Pricing | pricing rule tests | NOT STARTED |
