# Module Plan — UraiFlow Bridge

Event contracts, evidence linkage and follow-up Work Objects.
