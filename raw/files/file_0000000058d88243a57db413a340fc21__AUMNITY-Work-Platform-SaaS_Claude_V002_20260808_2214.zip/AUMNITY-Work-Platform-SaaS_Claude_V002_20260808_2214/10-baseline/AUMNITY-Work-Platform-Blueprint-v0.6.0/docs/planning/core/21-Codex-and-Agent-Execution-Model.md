# AUMNITY Work Platform Codex and Agent Execution Model

## Rules

- one module/sprint at a time
- RTM before code
- explicit domain terms
- state-machine tests
- no silent scope changes
- session handoff folders
- evidence-indexed completion
- architecture decisions recorded
- UraiFlow contracts reused, not duplicated
- unknown business rules become change requests, not guesses

## Repository

```text
/apps
/services
/packages
/domain
/infrastructure
/docs
/sprints
/sessions
/evidence
```

## Integrated sprint execution

`docs/engineering/00-Engineering-Operating-System.md` is mandatory before each sprint. Code and tests are one delivery unit. Create all applicable unit, integration, contract, database, functional, negative, permission, recovery and Playwright tests in the same sprint. Commit meaningful checkpoints, push, verify CI against the pushed SHA, fix failures, commit and push again, and repeat until all gates pass. Do not begin the next sprint before closure or an approved exception.
