# Module Plan — Work Object Registry

Schema, versions, hierarchy, states, evidence references and APIs.
