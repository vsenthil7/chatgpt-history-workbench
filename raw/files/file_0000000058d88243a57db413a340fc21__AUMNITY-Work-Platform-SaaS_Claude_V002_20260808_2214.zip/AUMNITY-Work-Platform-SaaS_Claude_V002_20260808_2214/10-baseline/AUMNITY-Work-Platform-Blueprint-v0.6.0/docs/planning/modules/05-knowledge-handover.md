# Module Plan — Knowledge and Handover

Knowledge Objects, handover template, lineage and reuse.
