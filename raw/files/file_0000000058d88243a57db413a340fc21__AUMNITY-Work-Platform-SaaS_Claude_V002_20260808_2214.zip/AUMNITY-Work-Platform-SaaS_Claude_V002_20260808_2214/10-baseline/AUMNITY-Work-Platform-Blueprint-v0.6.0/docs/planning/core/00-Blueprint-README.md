# AUMNITY Work Platform Product Blueprint v0.2

**Working name:** AUMNITY Work Platform (AUMNITY Work Platform)  
**Naming note:** The conversation also used “DWAS”. This pack treats that as a naming inconsistency, not a confirmed rename.

## Purpose

AUMNITY Work Platform is the parent platform for discovering, representing, assigning, executing, reviewing, evidencing and improving work performed by humans, AI systems, teams and partner organisations.

UraiFlow is one reusable conversation-evidence module inside AUMNITY Work Platform.

## Documents

- vision and boundaries
- domain model
- universal Work Object
- users/roles
- modules
- architecture
- data model
- events/states
- workflows
- AI/human orchestration
- commercial and social-enterprise model
- UraiFlow integration
- roadmap
- RTM
- risks/assumptions/decisions
- Codex/agent execution model

## v0.2 control additions

Documents 23–27 and `docs/planning/sprint-context/` freeze the discovery boundary and prevent Codex from interpreting the blueprint as approval to build the entire platform.
