# AUMNITY Work Platform Document Reading Map

## Global baseline

- 00 README
- 01 Vision
- 02 Boundaries
- 03 Glossary
- 04 Work Object
- 07 Architecture
- 08 Data model
- 19 Risks/decisions
- 20 Brutal readiness
- 23 Stop rule
- 24 Decision authority
- 25 Minimum build boundary

## Per sprint

Read:

- sprint tracker
- RTM
- corresponding `docs/planning/sprint-context/Dxx.md`
- linked module planner
- only linked supporting documents

Do not load the entire blueprint for each coding session.

## Engineering baseline

Before the per-sprint reading list, always read `docs/engineering/00-Engineering-Operating-System.md` and follow its mandatory linked procedures. This reusable engineering layer is referenced rather than duplicated into every context pack.
