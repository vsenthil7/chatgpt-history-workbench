# Users, Roles and Actors

## Human roles

- requester
- worker
- reviewer
- approver
- team lead
- capacity manager
- client
- partner operator
- administrator
- auditor
- knowledge curator

## AI roles

- planner
- researcher
- drafter
- extractor
- classifier
- reviewer assistant
- scheduler
- routing assistant
- summariser
- coding agent

## Organisation roles

- service company
- software product company
- client organisation
- partner company
- workforce community
- training organisation

## Guardrail

AI may recommend and execute permitted low-risk work, but significant commercial, legal, employment and sensitive decisions require human oversight.
