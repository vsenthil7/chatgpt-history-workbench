# UraiFlow Integration with AUMNITY Work Platform

## UraiFlow owns

- interview/session
- recording
- segments
- transcript lineage
- structured answers
- conversation summary
- evidence exports

## AUMNITY Work Platform owns

- follow-up assignment
- ownership
- SLA
- review workflow
- service delivery
- capability/capacity matching
- broader knowledge and work lifecycle

## Bridge

UraiFlow emits events such as:

- InterviewCompleted
- ReviewRequired
- PainPointIdentified
- FollowUpCreated
- ExportFailed

AUMNITY Work Platform creates linked Work Objects with evidence references.
