# Commercial and Social-Enterprise Model

## Service-company role

Initial operator may deliver services using AUMNITY Work Platform.

## Product-company role

AUMNITY Work Platform may later become a separately commercialised platform.

## Workforce model

Supports:

- women with partial availability
- students
- retired professionals
- freelancers
- partner teams
- specialist reviewers
- AI agents

## Pricing possibilities

- per Work Object
- per capacity block
- per outcome
- subscription
- managed service
- platform plus service
- partner revenue share

## Social principle

Flexible work must not become hidden exploitation. Capacity, consent, payment and review effort must be visible.
