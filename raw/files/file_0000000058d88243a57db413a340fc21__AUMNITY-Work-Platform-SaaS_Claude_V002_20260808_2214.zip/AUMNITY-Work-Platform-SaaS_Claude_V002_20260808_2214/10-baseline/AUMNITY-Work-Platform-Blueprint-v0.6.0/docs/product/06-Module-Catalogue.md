# AUMNITY Work Platform Module Catalogue

## Core platform

1. Identity and organisation
2. Work Object registry
3. Workflow/template engine
4. Assignment and routing
5. Capacity and availability
6. Priority and SLA
7. Evidence and artefact store
8. Review and approval
9. Knowledge and handover
10. Audit and observability
11. Policy and governance
12. Integration gateway

## Operational modules

13. Client onboarding
14. Service catalogue
15. Workforce onboarding
16. Skills/capability profile
17. Scheduling
18. Quality assurance
19. Commercial/pricing
20. Partner management
21. Analytics
22. Training and simulation

## Reusable product modules

23. UraiFlow conversation intelligence
24. Callback/inbound queue
25. Transcript review
26. Recruitment workflow
27. Sales discovery
28. Support workflow
29. Document intake
30. Export/reporting
