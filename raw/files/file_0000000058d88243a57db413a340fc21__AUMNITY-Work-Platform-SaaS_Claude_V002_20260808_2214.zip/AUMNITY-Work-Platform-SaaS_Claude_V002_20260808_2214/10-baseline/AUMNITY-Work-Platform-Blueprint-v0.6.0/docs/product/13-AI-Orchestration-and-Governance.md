# AI Orchestration and Governance

## AI gateway

Provider-neutral services for:

- generation
- extraction
- transcription
- translation
- classification
- search/research
- code execution
- review support

## Controls

- provider capability registry
- model/prompt versioning
- cost limits
- privacy/data routing
- human approval
- audit
- fallback
- failure honesty
- evaluation suites

## Rule

AI output is an artefact with lineage, not an unquestioned fact.
