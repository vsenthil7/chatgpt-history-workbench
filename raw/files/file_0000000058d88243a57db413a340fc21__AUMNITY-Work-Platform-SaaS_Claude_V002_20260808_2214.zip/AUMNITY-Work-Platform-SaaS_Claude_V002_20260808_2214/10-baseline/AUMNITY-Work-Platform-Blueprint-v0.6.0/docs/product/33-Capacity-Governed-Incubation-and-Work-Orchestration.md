# Capacity-Governed Incubation and Work Orchestration

## Business problem
Ideas are easy to generate. The scarce resources are verified capability, availability, attention, supervision, money and TEE capacity.

## Decision outcomes
Do now; prototype; configure an existing product; research; train/recruit first; hold; stop.

## Platform role
AUMNITY provides shared Work Object, Actor, Capability, Capacity, Evidence, Policy, Workflow, Integration and Audit services. Product modules combine these services for a coherent user problem.
