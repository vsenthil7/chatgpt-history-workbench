# AUMNITY Work Platform Product Roadmap

## Phase 0 — Discovery foundation

- preserve hypotheses
- define Work Object
- validate service-company needs
- build UraiFlow

## Phase 1 — Operator MVP

- Work Object registry
- assignment
- evidence
- review
- capacity
- UraiFlow bridge
- simple dashboards

## Phase 2 — Managed-service platform

- client onboarding
- service catalogue
- SLA
- QA
- partner teams
- pricing
- analytics

## Phase 3 — Multi-organisation product

- tenant isolation
- configurable workflows
- integration marketplace
- policy engine
- advanced AI orchestration

## Phase 4 — Capacity network

- verified capability
- dynamic matching
- portable work reputation
- consent/payout
- partner ecosystem

Each phase requires market validation; later phases are not current commitments.
