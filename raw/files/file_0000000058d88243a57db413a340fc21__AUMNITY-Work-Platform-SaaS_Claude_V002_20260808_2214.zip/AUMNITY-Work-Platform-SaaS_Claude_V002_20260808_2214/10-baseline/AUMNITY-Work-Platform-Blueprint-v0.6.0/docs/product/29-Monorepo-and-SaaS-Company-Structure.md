# AUMNITY Work Platform Monorepo and SaaS Structure

## Repository

```text
aumnity-workcore/
├── apps/
│   ├── operator_web/
│   ├── worker_web/
│   ├── reviewer_web/
│   └── admin_web/
├── services/
│   ├── platform_api/
│   ├── worker_orchestrator/
│   ├── ai_gateway/
│   └── integration_gateway/
├── modules/
│   ├── work_objects/
│   ├── actors_capacity/
│   ├── assignment/
│   ├── evidence_review/
│   ├── knowledge_handover/
│   └── uraiflow_bridge/
├── packages/
│   ├── domain/
│   ├── contracts/
│   ├── policy/
│   └── shared_testkit/
├── infrastructure/
├── docs/
│   ├── architecture/
│   ├── help/
│   ├── planning/
│   ├── api/
│   └── adr/
├── sprints/
├── sessions/
├── tests/
└── evidence/
```

## Commercial relationship model

A separate software-product company may own and operate AUMNITY Work Platform as SaaS.

A service/IT company such as the future Evil-to-Evil team may be:

- implementation partner,
- support provider,
- enhancement vendor,
- sales/referral partner,
- and also a tenant/client using the platform for its own delivery.

The product company and service company must use written contracts, access boundaries, IP ownership, support SLAs and commercial transfer pricing rather than an informal mutual arrangement.

## Future SaaS work

Record but do not build immediately:

- tenant provisioning,
- subscription plans,
- usage metering,
- support entitlements,
- partner portal,
- reseller/referral model,
- billing,
- and customer success.

These remain roadmap items until buyer validation.
