# New Reusable Product Module Reference

Working architecture name: **Capacity-Governed Work Orchestration (CGWO)**.

This is intentionally an architecture name, not a final trademarked market name. It orchestrates ideas, service models, capability demand, resource pool development, availability, matching, planning, execution and review. The standalone module package v0.1.0 contains its product charter and boundary.
