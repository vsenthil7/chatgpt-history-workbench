# Capacity, Availability and Matching

## Inputs

- actor availability
- skill/capability
- verified experience
- location/language
- work preference
- current load
- SLA
- client constraints
- cost
- risk

## Matching output

- ranked candidate actors
- confidence/reason
- capacity reservation
- fallback actors
- human approval where required

## Principle

Do not sell work capacity that has not been measured and reserved.
