# AUMNITY Work Platform Scope and Boundaries

## In scope

- Work Object definition and lifecycle
- recursive decomposition
- assignment and routing
- human/AI execution
- evidence and artefacts
- review and approval
- knowledge and handover
- capacity/availability
- SLA/priority
- partner organisations
- service delivery
- analytics and learning
- integrations
- consent and governance

## Out of scope for initial platform

- payroll engine
- full ERP
- telecom carrier
- generic CRM replacement
- public labour marketplace at launch
- autonomous high-risk decision making
- covert employee surveillance
- activity scoring/bossware

## Principles

- outcome over activity
- consent over surveillance
- evidence over claims
- human control for significant decisions
- provider neutrality
- progressive elaboration
- modular evolution
