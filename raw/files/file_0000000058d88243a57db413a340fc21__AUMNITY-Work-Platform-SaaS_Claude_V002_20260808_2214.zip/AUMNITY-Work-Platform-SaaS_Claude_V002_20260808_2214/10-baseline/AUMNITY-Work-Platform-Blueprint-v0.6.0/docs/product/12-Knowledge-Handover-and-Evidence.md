# Knowledge, Handover and Evidence

## Handover structure

- mission
- current state
- confirmed decisions
- assumptions
- open questions
- rejected options
- dependencies
- evidence
- expected next output
- quality criteria
- change summary

## Evidence classes

- document
- audio
- transcript
- code
- test result
- approval
- customer message
- screenshot
- data extract
- external source

## Goal

A new human or AI actor should continue work without rereading an entire chat history.
