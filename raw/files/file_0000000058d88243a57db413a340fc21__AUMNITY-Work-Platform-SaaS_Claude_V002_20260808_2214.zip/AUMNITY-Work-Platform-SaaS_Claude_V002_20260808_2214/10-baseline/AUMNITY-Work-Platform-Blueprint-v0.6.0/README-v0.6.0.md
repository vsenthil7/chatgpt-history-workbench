# AUMNITY Work Platform Blueprint v0.6.0

This release extends v0.5 with capacity-governed idea incubation, service formation, resource capability development, multi-horizon availability, adaptive work planning, work-resource alignment, and UraiFlow-assisted structured record creation.

## Release boundary
- Platform architecture and common language only.
- IPBS-specific workbook implementation remains in its own pilot package.
- UraiFlow capture mechanics remain in the UraiFlow package.
- The new reusable product module is documented separately and referenced here.

## New platform concepts
1. Idea and Opportunity
2. Product/Service Model and Readiness
3. Capability Demand and Capability Gap
4. Monthly, weekly, previous-day and same-day availability
5. Capacity reservation and consumption
6. Overall, weekly and daily plan horizons
7. Execution session and timesheet evidence
8. Work-resource alignment
9. Founder/body/mind/TEE supervision capacity
10. Human-confirmed AI record proposals
