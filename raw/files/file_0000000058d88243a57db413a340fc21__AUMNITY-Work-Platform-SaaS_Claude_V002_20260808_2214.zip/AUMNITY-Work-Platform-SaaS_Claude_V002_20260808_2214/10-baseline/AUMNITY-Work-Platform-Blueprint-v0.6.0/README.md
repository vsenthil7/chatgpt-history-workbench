# AUMNITY Work Platform Blueprint

This is the parent work-platform blueprint. **The product name is not yet approved.**

## Hierarchy

```text
AUMNITY                    Umbrella programme/company identity
└── Work platform          Product category; final product name pending
    ├── UraiFlow           Interview/conversation product module
    └── Future modules     Support, sales, recruitment, operations, etc.
```

## Documentation structure

All controlled documents are under `docs/`.

```text
docs/
├── product/
├── architecture/
├── planning/
│   ├── core/
│   ├── modules/
│   └── sprint-context/
├── help/
├── api/
├── testing/
├── operations/
└── governance/
```

The root is reserved for the repository README, manifests and future code folders.

## Blueprint v0.5 change

Blueprint v0.5 adds `docs/engineering/`, a reusable engineering operating system. Every sprint now embeds the code → test → fix → commit → push → CI → document → close loop through references in the sprint tracker and every sprint context pack.
