# First Build Backlog

## B001 — Baseline acceptance
- Read all starter documents and the complete preserved baseline.
- Inventory contradictions/duplicates/stale names before deleting anything.
- Record architecture decisions rather than silently normalising history.

## B002 — Declare the first implementation slice
Harden the platform boundary, define tenant/organisation semantics and shared contracts, then build the minimum shared kernel demanded by real bounded modules—not a speculative mega-core.

## B003 — Tests first as contracts
Declare RTM rows, contract tests and architecture/tenant guards before implementation. Establish red evidence, then implement to green.

## B004 — Evidence-producing CI
Make test counts, coverage, mutation, package inventory and docs consistency machine-readable so narrative docs do not drift.

## B005 — Review package
Create the next `<Product>_Claude_VNNN_YYYYMMDD_HHMM.zip` with complete source/tests/docs/evidence for independent ChatGPT review.
