"""CGWO consumer-side boundary contracts (review findings F12, F15; G05 partial).

These are CGWO's *expected* inbound boundary shapes, versioned and owned by
CGWO as consumer contracts. They do NOT duplicate Platform-owned entities:
every foreign concept remains an opaque reference (ADR-006). UraiFlow record
proposals are inbound suggestions and never mutate CGWO state without a
confirmation step (confirmation workflow is DECLARED, not implemented).

Wire semantics (ADR-010, F15): plain constructors are strict — they require
already-decoded domain values (enum instances, ``date`` objects, real ints)
and reject raw wire values with controlled errors. External/raw input enters
ONLY through the explicit ``from_wire`` parsers, which normalise supported
raw representations and reject unknown or malformed values
deterministically. Incidental dataclass construction is not the wire format.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date

from cgwo_core.capacity import CapacityType, CapacityWindow
from cgwo_core.errors import (
    CONTRACT_MINUTES_NON_POSITIVE,
    F_AVAILABLE_MINUTES,
    F_MINUTES,
    F_NARRATIVE,
    F_PERIOD_END,
    F_PERIOD_START,
    F_RESOURCE_REF,
    F_SOURCE_SYSTEM,
    F_TENANT_ID,
    F_WORK_OBJECT_REF,
    FIELD_BLANK,
    INVALID_WIRE_DATE,
    INVALID_WIRE_INT,
    UNKNOWN_ENUM_VALUE,
    DomainError,
    build,
)
from cgwo_core.validation import require_int, require_str

CONSUMER_CONTRACT_VERSION = "cgwo-consumer-v1"

#: Canonical wire-integer grammar (ADR-012, review finding F24): ASCII decimal
#: digits only. No sign, no whitespace, no separators, no Unicode digit
#: classes, no decimal notation. Domain-level positivity/range rules apply
#: after decoding. Chosen for deterministic cross-language provider
#: compatibility; Python's permissive ``int()`` parsing is deliberately NOT
#: part of the contract.
WIRE_INT_GRAMMAR = r"[0-9]+"
_WIRE_INT_RE = re.compile(WIRE_INT_GRAMMAR)

#: Upper bound on wire-integer digit length (ADR-013, review finding F29).
#: CPython refuses int()->str conversions above ~4300 digits by default and
#: raises a raw ValueError; we reject over-long digit strings deterministically
#: with a controlled ContractViolationError well below any plausible legitimate
#: minute/quantity value, closing the DoS/uncontrolled-exception path.
WIRE_INT_MAX_DIGITS = 4300

#: Canonical wire-date grammar (ADR-013, review finding F29): strict
#: ``YYYY-MM-DD`` only. ``date.fromisoformat`` additionally accepts basic
#: ``YYYYMMDD``, ISO week dates (``YYYY-Www-D``) and more; those are NOT part
#: of ``cgwo-consumer-v1``. We validate the exact shape ourselves, then use
#: ``date`` construction for calendar correctness (rejecting e.g. month 13).
WIRE_DATE_GRAMMAR = r"[0-9]{4}-[0-9]{2}-[0-9]{2}"
_WIRE_DATE_RE = re.compile(WIRE_DATE_GRAMMAR)


class ContractViolationError(DomainError):
    """Raised when an inbound proposal violates the consumer contract."""


def _require_non_blank(value: object, field_name: str) -> str:
    checked = require_str(value, field_name, ContractViolationError)
    if not checked.strip():
        raise build(ContractViolationError, FIELD_BLANK, field=field_name)
    return checked


def parse_wire_capacity_type(value: object, field: str = "capacity_type") -> CapacityType:
    """Decode a wire capacity type; reject unknown or non-string values."""
    checked = require_str(value, field, ContractViolationError)
    try:
        return CapacityType(checked)
    except ValueError:
        raise build(
            ContractViolationError,
            UNKNOWN_ENUM_VALUE,
            field=field,
            value=checked,
            expected=CapacityType.__name__,
        ) from None


def parse_wire_date(value: object, field: str) -> date:
    """Decode a canonical ``YYYY-MM-DD`` wire date (ADR-013, F29).

    The grammar is enforced explicitly (``WIRE_DATE_GRAMMAR``) rather than
    delegated to ``date.fromisoformat``, which would also accept basic and
    week-date forms outside ``cgwo-consumer-v1``. Shape is checked first, then
    calendar validity (so ``2026-13-40`` is rejected too).
    """
    checked = require_str(value, field, ContractViolationError)
    if _WIRE_DATE_RE.fullmatch(checked) is None:
        raise build(ContractViolationError, INVALID_WIRE_DATE, field=field, value=checked)
    year, month, day = (int(part) for part in checked.split("-"))
    try:
        return date(year, month, day)
    except ValueError:
        raise build(ContractViolationError, INVALID_WIRE_DATE, field=field, value=checked) from None


def parse_wire_int(value: object, field: str) -> int:
    """Decode a canonical wire integer; grammar is ``[0-9]+`` (WIRE_INT_GRAMMAR).

    Accepts an exact ``int`` (bool excluded) or an exact ``str`` of ASCII
    decimal digits. Everything else — signs, whitespace, Unicode digits,
    separators, floats, bools — is rejected deterministically.
    """
    if type(value) is bool:
        raise build(
            ContractViolationError,
            INVALID_WIRE_INT,
            field=field,
            value=value,
        )
    if type(value) is int:
        return value
    checked = require_str(value, field, ContractViolationError)
    if _WIRE_INT_RE.fullmatch(checked) is None:
        raise build(ContractViolationError, INVALID_WIRE_INT, field=field, value=checked)
    if len(checked) > WIRE_INT_MAX_DIGITS:
        raise build(ContractViolationError, INVALID_WIRE_INT, field=field, value=checked)
    return int(checked)


@dataclass(frozen=True, slots=True)
class TimeRecordProposal:
    """Proposed time record (e.g. from UraiFlow) awaiting confirmation."""

    tenant_id: str
    resource_ref: str
    work_object_ref: str
    minutes: int
    narrative: str = ""
    source_system: str = "uraiflow"

    def __post_init__(self) -> None:
        _require_non_blank(self.tenant_id, F_TENANT_ID)
        _require_non_blank(self.resource_ref, F_RESOURCE_REF)
        _require_non_blank(self.work_object_ref, F_WORK_OBJECT_REF)
        require_str(self.narrative, F_NARRATIVE, ContractViolationError)
        _require_non_blank(self.source_system, F_SOURCE_SYSTEM)
        checked_minutes = require_int(self.minutes, F_MINUTES, ContractViolationError)
        if checked_minutes <= 0:
            raise build(ContractViolationError, CONTRACT_MINUTES_NON_POSITIVE)

    @classmethod
    def from_wire(
        cls,
        tenant_id: object,
        resource_ref: object,
        work_object_ref: object,
        minutes: object,
        narrative: object = "",
        source_system: object = "uraiflow",
    ) -> TimeRecordProposal:
        """Decode raw wire values into a validated proposal (ADR-010)."""
        return cls(
            tenant_id=_require_non_blank(tenant_id, F_TENANT_ID),
            resource_ref=_require_non_blank(resource_ref, F_RESOURCE_REF),
            work_object_ref=_require_non_blank(work_object_ref, F_WORK_OBJECT_REF),
            minutes=parse_wire_int(minutes, F_MINUTES),
            narrative=require_str(narrative, F_NARRATIVE, ContractViolationError),
            source_system=_require_non_blank(source_system, F_SOURCE_SYSTEM),
        )


@dataclass(frozen=True, slots=True)
class AvailabilityProposal:
    """Proposed availability declaration awaiting confirmation."""

    tenant_id: str
    resource_ref: str
    period_start: date
    period_end: date
    available_minutes: int
    capacity_type: CapacityType = CapacityType.EXECUTION
    source_system: str = "uraiflow"

    def __post_init__(self) -> None:
        _require_non_blank(self.source_system, F_SOURCE_SYSTEM)
        # Delegate the remaining shape rules — including runtime enum/date/int
        # validation — to the capacity invariants so the proposal can never
        # describe a window CGWO would reject (F15).
        self.to_window()

    @classmethod
    def from_wire(
        cls,
        tenant_id: object,
        resource_ref: object,
        period_start: object,
        period_end: object,
        available_minutes: object,
        capacity_type: object = CapacityType.EXECUTION.value,
        source_system: object = "uraiflow",
    ) -> AvailabilityProposal:
        """Decode raw wire values into a validated proposal (ADR-010, F15)."""
        return cls(
            tenant_id=_require_non_blank(tenant_id, F_TENANT_ID),
            resource_ref=_require_non_blank(resource_ref, F_RESOURCE_REF),
            period_start=parse_wire_date(period_start, F_PERIOD_START),
            period_end=parse_wire_date(period_end, F_PERIOD_END),
            available_minutes=parse_wire_int(available_minutes, F_AVAILABLE_MINUTES),
            capacity_type=parse_wire_capacity_type(capacity_type),
            source_system=_require_non_blank(source_system, F_SOURCE_SYSTEM),
        )

    def to_window(self) -> CapacityWindow:
        """The CapacityWindow this proposal would create once confirmed."""
        return CapacityWindow(
            tenant_id=self.tenant_id,
            resource_ref=self.resource_ref,
            period_start=self.period_start,
            period_end=self.period_end,
            available_minutes=self.available_minutes,
            capacity_type=self.capacity_type,
        )
