"""Explicit tenant context for every protected operation (SaaS-002, ADR-006, ADR-009).

Isolation boundary (ADR-009): ``tenant_id`` is THE enforced isolation boundary.
``organisation_id`` is an optional sub-scope reference (Platform-owned semantics);
it is validated for well-formedness but is not an independently enforced security
boundary in the domain core. Runtime type integrity per ADR-010.
"""

from __future__ import annotations

from dataclasses import dataclass

from cgwo_core.errors import (
    CROSS_TENANT,
    F_CTX,
    F_ORGANISATION_ID,
    F_OWNER_TENANT_ID,
    F_TENANT_ID,
    FIELD_BLANK,
    ORGANISATION_ID_BLANK,
    DomainError,
    build,
)
from cgwo_core.validation import (
    require_exact_instance,
    require_optional_str,
    require_str,
)


class TenantIsolationError(DomainError):
    """Base class for tenant-isolation failures."""


class MissingTenantContextError(TenantIsolationError):
    """Raised when a protected operation lacks a usable tenant context."""


class CrossTenantAccessError(TenantIsolationError):
    """Raised when a tenant context touches another tenant's aggregate."""


def _validate_context(tenant_id: object, organisation_id: object) -> None:
    checked_tenant = require_str(tenant_id, F_TENANT_ID, MissingTenantContextError)
    if not checked_tenant.strip():
        raise build(MissingTenantContextError, FIELD_BLANK, field=F_TENANT_ID)
    checked_org = require_optional_str(
        organisation_id, F_ORGANISATION_ID, MissingTenantContextError
    )
    if checked_org is not None and not checked_org.strip():
        raise build(MissingTenantContextError, ORGANISATION_ID_BLANK)


@dataclass(frozen=True, slots=True)
class TenantContext:
    """Opaque Platform tenancy references; CGWO validates presence, not shape."""

    tenant_id: str
    organisation_id: str | None = None

    def __post_init__(self) -> None:
        _validate_context(self.tenant_id, self.organisation_id)


def assert_same_tenant(ctx: TenantContext, owner_tenant_id: str) -> None:
    """Deny cross-tenant access to an aggregate owned by ``owner_tenant_id``.

    Both operands are canonicalised before comparison (ADR-013): ``ctx`` must
    be an EXACT ``TenantContext`` (no lying subclass, F27) and
    ``owner_tenant_id`` must be an exact ``str`` (no hostile-equality owner,
    F28). Only then is the isolation comparison trustworthy.
    """
    checked_ctx = require_exact_instance(ctx, TenantContext, F_CTX, MissingTenantContextError)
    checked_owner = require_str(owner_tenant_id, F_OWNER_TENANT_ID, CrossTenantAccessError)
    if checked_ctx.tenant_id != checked_owner:
        raise build(CrossTenantAccessError, CROSS_TENANT)
