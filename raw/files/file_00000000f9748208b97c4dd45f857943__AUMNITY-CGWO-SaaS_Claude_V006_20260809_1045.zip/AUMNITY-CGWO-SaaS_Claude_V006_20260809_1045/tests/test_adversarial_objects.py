"""Adversarial domain-OBJECT attacks (ADR-013, review findings F27, F28, F29).

V005 canonicalised primitive fields but still admitted hostile *objects* one
layer up: a ``TenantContext`` subclass whose ``__getattribute__`` lies about
``tenant_id`` (a working cross-tenant bypass, F27), a hostile-equality owner
identifier passed to ``assert_same_tenant`` and a ``CapacityWindow`` subclass
lying about tenant and capacity (F28), and wire parsers delegating to
permissive Python builtins (F29). Exact-instance guards and an explicit wire
grammar must defeat all of them with controlled DomainErrors.
"""

from datetime import date

import pytest

from cgwo_core.allocation import AllocationInvariantError, CapacityAllocation
from cgwo_core.capacity import CapacityInvariantError, CapacityWindow
from cgwo_core.contracts import (
    ContractViolationError,
    parse_wire_date,
    parse_wire_int,
)
from cgwo_core.errors import (
    INVALID_WIRE_DATE,
    INVALID_WIRE_INT,
    WRONG_RUNTIME_TYPE,
    DomainError,
)
from cgwo_core.tenancy import (
    CrossTenantAccessError,
    MissingTenantContextError,
    TenantContext,
    assert_same_tenant,
)

D1, D5 = date(2026, 8, 1), date(2026, 8, 5)
GOOD_WINDOW = CapacityWindow(
    tenant_id="t1",
    resource_ref="actor-1",
    period_start=D1,
    period_end=D5,
    available_minutes=600,
)


class LyingContext(TenantContext):
    """The review's F27 attack: stored tenant 'attacker', reports 'victim'."""

    def __getattribute__(self, name: str) -> object:
        if name == "tenant_id":
            return "victim"
        return super().__getattribute__(name)


class LyingWindow(CapacityWindow):
    """The review's F28 attack: lies about tenant and available capacity."""

    def __getattribute__(self, name: str) -> object:
        if name == "tenant_id":
            return "victim"
        if name == "available_minutes":
            return 1_000_000_000
        return super().__getattribute__(name)


class EqualEverything(str):
    def __eq__(self, other: object) -> bool:
        return True

    def __ne__(self, other: object) -> bool:
        return False

    __hash__ = str.__hash__


def assert_wrong_type(excinfo, field=None):
    assert isinstance(excinfo.value, DomainError)
    assert excinfo.value.code == WRONG_RUNTIME_TYPE
    if field is not None:
        assert excinfo.value.fields["field"] == field


# --- F27: lying TenantContext subclass ---------------------------------------
def test_f27_lying_context_rejected_by_assert_same_tenant():
    ctx = LyingContext("attacker")
    with pytest.raises(MissingTenantContextError) as excinfo:
        assert_same_tenant(ctx, "victim")
    assert_wrong_type(excinfo, field="ctx")


def test_f27_genuine_context_still_works():
    assert_same_tenant(TenantContext("t1"), "t1")
    with pytest.raises(CrossTenantAccessError):
        assert_same_tenant(TenantContext("t1"), "t2")


def test_f27_lying_context_actual_type_is_reported():
    with pytest.raises(MissingTenantContextError) as excinfo:
        assert_same_tenant(LyingContext("attacker"), "victim")
    assert excinfo.value.fields["actual"] == "LyingContext"


# --- F28: hostile owner id + lying window ------------------------------------
def test_f28_hostile_equality_owner_rejected():
    with pytest.raises(CrossTenantAccessError) as excinfo:
        assert_same_tenant(TenantContext("victim"), EqualEverything("attacker"))
    assert_wrong_type(excinfo, field="owner_tenant_id")


def test_f28_lying_window_rejected_by_allocation():
    evil = LyingWindow(
        tenant_id="attacker",
        resource_ref="a",
        period_start=D1,
        period_end=D5,
        available_minutes=1,
    )
    with pytest.raises(AllocationInvariantError) as excinfo:
        CapacityAllocation(
            tenant_id="victim",
            window=evil,
            plan_item_ref="p",
            allocated_minutes=100,
        )
    assert_wrong_type(excinfo, field="window")


def test_f28_lying_window_rejected_by_declaration():
    from cgwo_core.capacity import AvailabilityDeclaration

    evil = LyingWindow(
        tenant_id="attacker",
        resource_ref="a",
        period_start=D1,
        period_end=D5,
        available_minutes=1,
    )
    with pytest.raises(CapacityInvariantError) as excinfo:
        AvailabilityDeclaration(tenant_id="victim", resource_ref="a", window=evil, declared_on=D1)
    assert_wrong_type(excinfo, field="window")


def test_f28_genuine_window_still_constructs_allocation():
    alloc = CapacityAllocation(
        tenant_id="t1", window=GOOD_WINDOW, plan_item_ref="p", allocated_minutes=100
    )
    assert alloc.allocated_minutes == 100


# --- F29: wire grammar violations --------------------------------------------
@pytest.mark.parametrize(
    "raw",
    ["20260801", "2026-W31-6", "2026-215", "2026/08/01", "26-08-01", "2026-8-1", ""],
)
def test_f29_non_canonical_wire_dates_rejected(raw):
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_date(raw, "period_start")
    assert excinfo.value.code == INVALID_WIRE_DATE
    assert excinfo.value.fields == {"field": "period_start", "value": raw}


@pytest.mark.parametrize("raw", ["2026-13-01", "2026-02-30", "2026-00-10", "2026-01-00"])
def test_f29_calendar_invalid_dates_rejected_controlled(raw):
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_date(raw, "period_end")
    assert excinfo.value.code == INVALID_WIRE_DATE
    assert excinfo.value.fields == {"field": "period_end", "value": raw}


def test_f29_canonical_date_accepted():
    assert parse_wire_date("2026-08-01", "period_start") == D1


def test_f29_overlong_digit_string_rejected_controlled():
    overlong = "9" * 4301
    with pytest.raises(ContractViolationError) as excinfo:
        parse_wire_int(overlong, "minutes")
    assert excinfo.value.code == INVALID_WIRE_INT
    # Exact structured identity (kills field/value mutants on this branch);
    # and never a raw ValueError from int() conversion limits.
    assert excinfo.value.fields == {"field": "minutes", "value": overlong}


def test_f29_max_length_digit_string_still_parses():
    value = "1" + "0" * 4299  # exactly 4300 digits
    assert parse_wire_int(value, "minutes") == int(value)
