# AT-LOS V029 Change Log

**Release type:** lossless identity and presence semantics at the provider boundary. ADR-029, amending ADR-014, ADR-027 and ADR-028. Corrective only, responding to the V028 independent deep review (F01–F07). No feature tranche, no `at-evidence` code.

## at-ingest-llm-export

**Identity is lossless (F01).** Clean short conversation ids pass through unchanged; any id sanitisation or bounding would alter carries `~` + a 16-hex SHA-256 digest of the exact original. Truncation pairs, `a/b`↔`a-b`, Unicode, delimiter and 200-char cases assert locator **and** `Event.make_id` uniqueness. Event ids change only for previously-lossy ids.

**Presence is not truthiness (F02, F04, F05).** Absence/null = not supplied; `{}`/`""`/`0`/`False`/`[]` are present values validated in their own name. Present falsy `message` values are rejected units (`{}` proceeds and rejects on missing content). `sender`/`role` and `created_at`/`timestamp` fall back by presence: a present malformed primary is rejected under its own field, epoch zero is valid and never replaced, and `timestamp_field` records the actual supplying field. Conversation-id selection is presence-aware with diagnostics and a deterministic index fallback.

**Canonical safety at the boundary (F03).** `_non_finite_at()` walks parts/content where the value is in hand; NaN/±Infinity anywhere — including deep nesting — reject the unit with the source-array path and offending value, never a `ValueError` from Event construction. Non-string `current_node`/`parent` keys (which raised `TypeError: unhashable` — found beyond the review's probes) are diagnosed, never dereferenced.

**The class is banned (F06).** Architecture guard RTM-130 scans adapter code for `.get(...) or` fallbacks, `or {}`/`or []` defaults and truthiness absence tests; the remaining instances were refactored to explicit presence checks.

**The claim is the matrix (F07).** Generative hostile-value matrix (RTM-133): every provider field position × twenty hostile values, ~540 combinations per run, asserting no exception, exact accounting, located issues, canonical Events. The Standard's totality wording is narrowed to exactly this proven scope.

## RTM, tests, mutation

RTM-129 (lossless identity), RTM-130 (presence class ban), RTM-131 (canonical safety), RTM-132 (presence-aware schema fallback + field provenance), RTM-133 (hostile-value matrix). **133 rules: 129 + 1 + 3.** 34 new tests; 491 passing, 100% on 1406 statements / 422 branches; **42/42 mutants** including five re-creating F01–F05; `ruff` and `mypy --strict` clean via exact CI commands.

## Documents and workbooks

Standard: V028's "every JSON-representable value in every position" retracted and re-scoped to the matrix (D-116); four V029 rules added. Project Memory: V028 CURRENT COUNT demoted to historical; V029 CURRENT COUNT from `release_facts.json` with deterministic figures. Test Strategy: derived sheets regenerated (133 RTM, 42 mutants); new `22_V029ReviewDisposition` sheet with the full F01–F07 table.

## Decisions

D-113 lossless collision-resistant identity · D-114 presence is not truthiness; class ban · D-115 canonical representability at the boundary; non-string keys diagnosed · D-116 a claim is scoped by its matrix

## Open

DQ-004, DQ-012, DQ-013, DQ-014, **DQ-016 (RTM-120 NOT ENFORCED — no external publication)** · arbitrary-JSON property coverage and real LLM export corpus: named gaps · `at-evidence` after independent V029 review (the reviewer's stated ingestion-freeze candidate) · **AT-056 Not started**.
