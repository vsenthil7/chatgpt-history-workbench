# AT-Life Operating System (AT-LOS) - V029

**Release:** `AT-LifeOperatingSystem_ProviderIdentityAndTruthBoundaryClosure_Claude_V029_20260809_1430`
**Prepared by:** Claude · **09-Aug-2026 14:30 BST** · Corrective only — no feature tranche, **no `at-evidence` code**.

You named the root idea: *provider data must retain exact identity and exact presence semantics all the way from JSON to canonical Event.* V029 fixes that **as a class** — the five reproductions each fall out of two decisions (lossless identity, presence-not-truthiness), the class is guard-banned so it cannot return by location, and a generative matrix now scopes what "total" means.

## Gates — exact CI commands

```
DETERMINISTIC (the package claims, reproducible from the pristine repo zip):
  deterministic suite              490 collected: 489 passed, 1 by-design skip
  coverage                         1406 statements, 422 branches, 100% line and branch
  mutation regression              42/42 killed (5 new mutants re-create F01-F05)
  ruff / mypy --strict             clean (exact CI commands)
  release_check + package audit    0 failures; blocking build_release step

ENVIRONMENT-DEPENDENT:
  integration/bootstrap            2 collected; exact CI command → 2 passed here;
                                   your V028 environment's 1 passed / 1 skip is the
                                   declared per-environment model working
  Reference build environment      492 collected: 491 passed, 1 skipped

RTM   129 passing + 1 skipped + 3 not enforced (RTM-120, RTM-14, RTM-15) = 133
packages 0.20.0 · ADR-001..029
```

## F01 — identity is lossless (the one you'd hold the architecture for)

`_safe()` no longer decides identity. A clean, short conversation id passes through unchanged (V028 locators for clean ids are stable — most real ids change nothing). Any id that sanitisation or truncation **would** alter carries a 16-hex SHA-256 digest of the **exact original**, joined with `~` — a character the safe alphabet excludes, so clean and hashed forms cannot collide, and lossy ids sharing a preview differ in the digest. Your exact pairs re-run:

```
x…x48+A vs x…x48+B   → locators differ, Event ids differ
a/b     vs a-b       → locators differ, Event ids differ
```

Seven parametrised pairs (truncation, sanitisation, Unicode, delimiters, 200-char ids) assert **both** locator and `Event.make_id` uniqueness, plus digest-format and clean-id-stability tests. Mutant restoring the lossy path: killed. (ADR-029 D1, RTM-129)

## F02–F05 — presence is not truthiness, everywhere

One rule now governs the boundary (ADR-029 D2): **absence and JSON null mean "not supplied"; everything else is a present value validated in its own name.**

- **F02**: `if not message` is gone. `""`/`0`/`False`/`[]` → rejected units with `#message` locators; `{}` proceeds as an object and rejects on missing content; absence/null remain structural non-units. Full falsy matrix parametrised.
- **F03**: `_non_finite_at()` walks parts/content **at the boundary**; your NaN probe yields locator `…#message.content.parts`, raw `NaN`, reason naming `parts[1]` — the path indexes the **source array**, not the structured subset. Deep nesting covered (`parts[1].deep[0].x`); Claude blocks likewise. No ValueError reaches you from Event construction.
- **F04**: `sender`/`role` fall back by presence. `sender=[]` with a valid `role` → rejection at `#sender`, zero events — for all five of your falsy probes. `role` is used only when `sender` is absent or null.
- **F05**: epoch zero parses to `1970-01-01T00:00:00Z`, is never replaced by a coexisting `timestamp`, and `timestamp_field` now records the field that **actually** supplied the value — your provenance point — so a bad fallback timestamp reports `…#query#timestamp`, raw `"bad"`.

**F06 — the class, not the instances.** A new architecture guard (RTM-130) scans the adapter's code — comments excluded, they quote the banned patterns as history — for `.get(...) or` fallbacks, `or {}` / `or []` defaults and truthiness absence tests, and fails on any occurrence. The remaining two incidental instances were refactored to explicit presence checks, and conversation-id selection is now presence-aware too, with a diagnostic when a present candidate is unusable and the deterministic per-file index as the collision-free fallback.

**F07 — the claim is the matrix.** The Standard's "every JSON-representable value in every position" is retracted and replaced: the totality statement now cites the **generative hostile-value matrix** (RTM-133) — every mutable field position of every provider × twenty hostile values (NaN, ±Infinity, unhashable containers, falsy present values, deep nesting, Unicode, 300-char strings), ~540 combinations per run, asserting no exception, exact unit accounting, located issues, canonical Events. What the matrix does not cover — arbitrary-JSON property testing, real LLM exports — is a named gap, not an implied capability.

**Beyond your probes:** the class audit found two more escapes — a list-valued `current_node` or `parent` raised `TypeError: unhashable` at dict-membership tests, and present-falsy `current_node` (`""`, `0`, `False`) was treated as absent. Both fixed and tested: non-string graph keys are diagnosed, never dereferenced.

D-113–D-116 · ADR-029 · RTM-129–133 · 34 new tests (149 adapter tests total) · 5 new mutants · full disposition in Test Strategy sheet `22_V029ReviewDisposition`.

## What this release claims, exactly

Identity and presence closure holds for the hostile-value-matrix scope and the named adversarial classes, plus the real 500-event WhatsApp corpus. Event ids changed **only** for conversations whose ids were lossy under V028; clean ids kept their identity (recorded in ADR-029, acceptable only pre-evidence). Not claimed: arbitrary-JSON property coverage, real LLM provider exports — both named gaps. **No `at-evidence` code exists.** If your V029 review is clean, this is the ingestion-freeze candidate you described.

## Next

Your V029 review → ingestion freeze decision → `at-evidence`. `at-consent` still needs **DQ-012 and DQ-013**. **AT-056 remains Not started.**
