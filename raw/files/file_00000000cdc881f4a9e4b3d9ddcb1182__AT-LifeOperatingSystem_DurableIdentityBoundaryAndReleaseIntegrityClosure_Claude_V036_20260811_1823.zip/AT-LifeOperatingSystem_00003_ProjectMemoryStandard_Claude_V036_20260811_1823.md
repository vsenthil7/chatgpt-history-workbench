# Project Memory Standard

**AT-LOS | Claude | V036 | 11-Aug-2026 (18:23 BST)**
**Supersedes:** the V028 standard. **Fifteen registers across sixteen worksheets** — `00_Index` is not a register.

---

## 1. Authority precedence (ADR-011, D-046)

Three absolute "authority" rules were previously in force at once and gave no answer when all three were consulted. One ordered list replaces them:

```
1. the code                  what the packages actually do
2. architecture.toml         declared layers, imports, module state
3. executable tests          enforce 1 against 2
4. generated documents       docs/ARCHITECTURE.md §B §C - never hand-edited
5. hand-written documents    README, READ_THIS_FIRST, TEST_STRATEGY
6. Project Memory            decisions, planning, scope, capability claims
```

**Project Memory cannot override machine-verified implementation state.** If a register says Implemented and nothing is on disk, the register is wrong. Project Memory remains authoritative for what code cannot answer: why a decision was taken, what is deferred, what must not be built.

## 2. The fifteen registers

| Tab | Holds | Cannot hold |
|---|---|---|
| 01_ActiveSprint | Work being executed | Anything without a Decision Log reference |
| 02_NextSprint | Decided, not started | Anything without a named unblocker |
| 03_ParkingLot | Ideas kept, not worked | Anything without a trigger **and an expiry** |
| 04_ResearchRepository | Needs evidence before planning | Anything already decided |
| 05_DecisionLog | Every decision, reason, date, owner | Edits. Reversals are new rows |
| 06_DeferredDecisions | **CLOSED.** Migrated to 13_DecisionQueue | New rows of any kind |
| 07_Assumptions | Silent dependencies | Anything without a named failure consequence |
| 08_LessonsLearned | What each version got wrong | Praise |
| 09_FutureVision | Long-term IP | Dates |
| 10_HallucinationRegister | True state of every capability | Aspirational states |
| 11_VersionHistory | Added, removed, why, still open | Retrofitted entries |
| 12_Archive | Completed and rejected | Deletions |
| 13_DecisionQueue | Decisions needed, intentionally postponed | A row missing any of the five mandatory fields |
| 14_SprintTracker | Live task board with proof of completion | A Done row whose Register column says No |
| 15_NamingRegister | Naming candidates and rejections | A claim without a verification level and source |

## 3. Rules

1. **Nothing is deleted.** Completed and rejected work moves to Archive with a reason.
2. **Every parked idea carries a review trigger and an expiry.**
3. **Every register row has an owner.**
4. **Nothing enters Active Sprint without a Decision Log entry.**
5. **The Decision Log is append-only.** Reversals are new rows; the original is marked Superseded.
6. **Every architecture change states why**, in the Decision Log and an ADR.
7. **No capability may be described above its Hallucination Register state.**
8. **Version History is written at release**, never reconstructed later.
9. **One review per month**, not per version.
10. **External factual claims state their verification level and source** (D-026 as narrowed by D-035). Applies to claims about the outside world, not internal planning rows.
11. **A postponed decision needs five fields**: why it matters, trigger, owner, latest date, delay cost.
12. **A task is not Done until its Hallucination Register row carries an immutable implementation reference** (D-049) - a commit SHA where Git is available, otherwise a package version plus an ADR or RTM id. The rule does not say "commit hash" while storing something else.
13. **Fifteen registers is the ceiling** (D-023).
14. **Architecture lives in the repository, with one machine-readable source** — `architecture.toml` — from which documents are generated (D-039). Hand-editing a generated table fails the build.
15. **Precedence resolves disagreement** (§1), replacing the old absolute "test wins" and "Project Memory wins" rules.
16. **A capability state names what it is, not what it is intended to be** (D-040). A docstring guarantee that the code contradicts is the same failure: V012's `ImportOccurrence` said it "never deduplicates" while an identical tuple collapsed.
17. **Release figures are measured, never estimated** (D-052). Fact derivation refuses to produce numbers from a failing suite. V012 computed passed tests as collected-minus-one, so a red suite could still yield a clean-looking fact set.
18. **A concept name must not answer a question it cannot answer** (D-051). `owner_ref` read like a consent answer; it recorded who imported a file. Renaming it `importer_ref` was half the fix — the other half was building the second graph it was standing in for. An in-memory dictionary is not persistence. A regression harness is not a mutation baseline. Line coverage of existing code is not functional coverage (D-045).
19. **Figures that appear in more than one artefact are derived from code, not typed** (D-046, D-050). `tools/release_facts.py` derives them, `tools/release_check.py` asserts **defined machine-verifiable invariants and generated fact blocks** — not the semantics of every sentence, and `tools/build_release.py` writes `release_facts.json` from which the release workbooks are generated. Blocking gate (RTM-23).
20. **Evidence recorded at task completion is historical.** Sprint Tracker column O says what was true when a row closed. Current totals live in the Hallucination Register CURRENT COUNT row and the Test Strategy workbook's generated sheets (`10_DerivedFacts`, `03_ArchitectureRTM`, `05_MutationResults`, `01_TestingArchitecture`, `11_WhatIsCoded` module states), **written from `release_facts.json`, `architecture.toml`, `rtm.toml` and the mutation tool at release build**. Everything else in the workbooks is authored. V026 described a manually stale register cell as code-derived (F06); the release gate now fails any current-state cell presenting an older version as current, so a generated cell that was not regenerated cannot ship silently.

## 4. What this guards against

Six failures, all of which have happened here:

- **Rediscovery.** Q-001 raised as Critical in V002 and V003, left open in both.
- **Capability drift.** V003 discussed conversation reconstruction as if it were software.
- **Scope substitution.** Three packages in thirteen hours, one completed task — producing a package.
- **Asserted enforcement.** V006 said CI enforced the architecture rules; there was no CI. ADR-003 named `ruff` and `mypy --strict`; neither ran until V010.
- **Drift under a guard that did not cover it.** V008 guarded the README; in V009 the *authoritative* architecture document went a version stale.
- **Drift in the files that prevent drift.** V010 generated the architecture document, then shipped an onboarding file with two contradictory adapter rules and a test workbook still reporting V009 figures.
- **A gate described above what it checked.** V011's consistency checker scanned three regex patterns across four Markdown files and reported everything clean while five stale facts survived. Rules 17 and 18 exist because of this.

## 3a. Rules added in V035

**Changing every identity is a durable transition** (D-141). A schema number answers whether this code understands these tables; it cannot answer whether the ids inside them were derived the way this code derives them. Those are different questions, so the identity scheme carries its own persisted marker, checked by every durable store before any read or write. A database written under another scheme is refused, with re-derivation by re-ingest named as the remedy - and re-ingest is available precisely because ingestion is deterministic and idempotent.

**A refusal must not modify what it refuses** (D-142). Inspection is read-only and comes first, in one implementation used by every store, and every refusal path is asserted byte-for-byte. An empty pre-created file is still adopted; a populated file with no marker of its own and no sibling marker is not.

**Verified once is not verified** (D-143). A durable evidence database outlives the Event source it was written against, so every read verifies, not only every write. "Was true once" is not something a substrate may report as "is true".

**An actor id is issued, and who an actor is comes later** (D-144, D-145). Actor identity takes a namespaced opaque form that a display name cannot spell. Learning which person an actor is appends an assertion; it never edits, and never forks one act into two. And the claim is only what the code does: an actor reference is recorded, not authenticated.

**A canonical scheme must be implementable elsewhere** (D-146). Length prefixes count UTF-8 bytes, the grammar is written down in the machine source, and the top-level field collection must be a real list - a string quietly decomposing into characters is not arity.

**A wrong machine source is worse than a stale document** (D-147). Generated documents inherit their source faithfully, including its errors, so declared contract types are reconciled against actual exports, deleted type names are banned from current documents, and counts that mean different things are kept as different facts.

## 3a. Rules added in V034

**A rendering is not a serialization** (D-134). Identity keys are built by one canonical encoding - length-prefixed so no field can borrow characters from its neighbour, type-tagged so a string and a number never encode alike, domain-tagged and versioned so two record types cannot coincide. Joining fields with a display delimiter produced deterministic collisions that silently deleted the second record; that is closed everywhere a make_id exists, including Event.

**Proof is enforced at admission, not documented** (D-135). A digest supplied beside the quotation it describes is a commitment, not proof. Evidence stores hold a required Event source and verify every anchor against the authoritative Event on full provenance - id, exact SourceRef, instant, whole-text digest, span, characters - before storing anything. Saying "use the safe factory" was never enforcement.

**An identity alone never decides** (D-135). A store compares the whole record and raises when one identity holds two different records. The encoding closes today's collisions; the backstop makes the next derivation defect loud instead of invisible.

**One instant is one identity** (D-136). Every identity timestamp normalises to UTC before encoding, so a single act cannot become two because the caller spelled the offset differently.

**Authorship is typed and opaque** (D-137). Who performed an act is a stable workspace-scoped actor reference with an actor kind, not a display label anyone can spell four ways or write on another's behalf. Human, model, system and tool authorship are structurally distinct beneath everything that will read them.

**Gates must not name what they watch** (D-138, D-139, D-140). Reconcile every figure wherever it sits rather than in one named object; derive release timestamps from the build clock; and reject every spelling of a false current-state claim, not just the one word a previous defect happened to use.

## 3a. Rules added in V033

**What was said and who said it are never one identity** (D-130). The V032 review found all five model blockers shared one root: content and act fused into a single id, so the first record silenced every later legitimate act. The substrate now keeps three identities - verified anchors, deduplicated semantic contents, authored acts. One statement asserted by two people is one content and two assertions; one quote selected by three people is one evidence record and three observations. Who said something is first-class provenance.

**An anchor proves its quote** (D-129). The event id is enforced equal to the shared canonical derivation from the SourceRef beside it, the anchor carries the whole-Event-text digest and the exact span, and the excerpt is derived from what the anchors prove - an invented excerpt is unconstructible, and any holder of the Event can re-verify the quote independently, including detecting a same-locator edit.

**A revision is a new act** (D-131). Judgements are pure occurrences over kind, strength, basis, author and time: revising direct to indirect appends beside the original without a semantically false kind change, and the full judgement history of a pair is the record.

**Workspaces never leak** (D-132). Every engine retrieves the records an act references and refuses any act whose workspace differs from its targets' - the review's exact cross-workspace reproduction is a permanent regression in both engines.

**Outer figures are generated, never typed** (D-133). The outer README and ChangeLog carry the same generated FACTS block the repository documents use, and the blocking audit verifies it byte-for-byte against freshly derived facts. Prose states no gate figure; the block does. No new regex, no version blacklist.

## 3a. Rules added in V032

**The substrate records; it never interprets** (D-125). `at-evidence` is the first feature tranche since V023, built at the ingestion freeze. It keeps three attributable records - verbatim excerpts, authored claims, typed relationships - and refuses the rest: no computed confidence, no scores, no patterns, no conclusion about any person. Strength is declared by the relating author, and a non-direct strength requires a stated basis, so a later reader weighs the judgement instead of inheriting it. Interpretive layers come later, on top, attributably.

**Identity is derived; records are forever** (D-126). Content-derived deduplicating identity; a chosen id that mismatches content is unconstructible; identical re-records are idempotent; conflicting re-records are refused. The port is append-only - no update or delete exists to misuse - and a correction is a new record beside the old one.

**Lineage is self-standing and bidirectional** (D-127). Every piece of evidence carries the full SourceRef of every Event it draws on, so provenance survives alone, and the reverse walk (which evidence cites this Event) is a first-class query. Observed cannot exist without a SourceRef - AT-012's founding rule, enforced at construction. Records never cross a workspace boundary.

**Storage discipline is inherited, not retrofitted** (D-128). One port, two engines, one contract suite against both; schema version 1 refuses a mismatched database; every canonical field round-trips from the package's first release.

## 3a. Rules added in V031

**Partial projection preserves what it does not consume** (D-123). A provider content block partially interpreted into canonical fields has every remaining source field consumed, preserved in original structure, or explicitly diagnosed - never known-field-consumed plus sibling keys silently gone plus zero issues. For Claude textual blocks: keys exactly `{type?, text}` are the consumed projection, fully consumed by definition; any additional key means textual projection **and** whole-block preservation - which also puts the block back in front of the non-finite boundary walk, closing the blind spot where a NaN hidden in a sibling escaped it. The contract is mechanical, never a field list: preservation follows what the projection consumes, not the block's type label.

**A workbook's title is current state** (D-124). The generic `Index` exemption is removed from the historical-sheet list - an index sheet declares the workbook's own version, one of the most clearly current cells there is; historical rows inside one carry the structural HISTORICAL prefix. Because the stale scan's "current"-word precondition can never see a bare title, the invariant is positive and explicit: current workbook filename release equals declared `00_Index` title release, enforced in the package audit, with the exact two V030 defect titles as permanent negative regressions. Titles are populated from the release source at staging, never carried as copied literals.

## 3a. Rules added in V030

**Identity is unique within its source, by namespace and by enforcement** (D-117). Provider-supplied identity and synthetic fallback identity are disjoint namespaces (`conversation:id:` / `conversation:index:`), so no provider value can spell a fallback. A repeated provider id keeps a distinct deterministic occurrence identity and is a located diagnostic - a repeat is source data, not something to merge silently. Source-wide locator and Event-id uniqueness is enforced at Event emission: construction arguments are proof today; the runtime guard is the class defence for tomorrow.

**A relationship between two valid fields is also provider data** (D-118). Claude's `text` and `content` are dual representations of one utterance. Equal after the explicitly defined normalisation: consumed once. Disagreeing - including empty-versus-non-empty: both preserved (text canonical, content text in Event.meta) with a located diagnostic. A silent choice between two source representations is silent data loss with extra steps.

**Canonical identity width is settled before anything holds it** (D-119). 32 hex characters, 128 bits, platform-wide - event, registration, occurrence and decision identity, and the lossy-locator digest. Settled now because no downstream record holds these ids, so no migration exists to write; after at-evidence the same change is migration work. A truncated digest is collision-resistant, never "lossless".

**Deterministic and environment-dependent figures never share a heading** (D-120). The headline test and coverage facts derive from the deterministic suite; environment-dependent integration is collected, named, and reported separately on every generated surface - including the generated ones. A generator can re-create the exact ambiguity it was built to prevent; the rule lives in the generator's derivation, not only in prose discipline.

**A hostile suite has layers, and a claim names its layer** (D-121). Layer A: single-field hostile values (the generative matrix). Layer B: field-pair consistency - dual representations, `sender`/`role`, `created_at`/`timestamp` simultaneously present. Layer C: collection invariants - duplicate ids, fallback spellings, source-wide uniqueness sweeps. Layer D: property/fuzz over arbitrary JSON - a NAMED GAP alongside the real LLM export corpus. Single-field hostility cannot see relationships; that is a structural property of the matrix, not a test that was forgotten.

**A rule's wording never claims more than its test proves** (D-122). RTM-130 said "the class is banned" while its guard regex-checked four spellings. The behavioural presence tests are the normative proof; the syntax guard is the cheap secondary check, and the rule now says so. D-116 applied to the RTM itself.

**Recorded strict-JSON gap (non-blocking).** Python's `json.loads` keeps the last value for duplicate object keys, so a duplicated `mapping` is lost before the adapter sees the source. Recorded here and in metadata; addressed with `object_pairs_hook` or a strict parser only if real provider exports demonstrate the need. Per the V029 review: this must not generate a release on its own.

## 3a. Rules added in V029

**A lossy slug is never canonical identity** (D-113; scope corrected by D-117/D-119). V028's locator sanitisation truncated and substituted, so different conversations produced identical Event ids immediately before at-evidence starts holding them. An id that would be altered carries a digest of the exact original; the preview is for humans, the digest is the identity. The V029 wording called this encoding "lossless" and its index fallback "collision-free" - both disproven (V029 review F01/F03): a truncated digest is collision-resistant, never lossless, and a provider id can legitimately spell `conversation-0`. Identity uniqueness is a SOURCE property, not an encoding property.

**Presence is not truthiness** (D-114). `{}`, `""`, `0` and `False` are present values; epoch zero is a valid instant; absence and null mean not-supplied. A present malformed field is rejected in its own name, never silently rewritten into a fallback schema - and the supplying field is recorded, so provenance names what actually happened. The class is banned by guard, not patched by location.

**Canonical representability is checked where the value is in hand** (D-115). A non-finite number deep inside structured content becomes a rejection carrying the source-array path and the value - never a ValueError escaping from Event construction three layers later.

**A claim is scoped by its matrix** (D-116). "Every value in every position" was written while the tests covered named classes. The totality statement now cites the generative matrix that proves it, and what the matrix does not cover - arbitrary-JSON properties, real LLM exports - is a named gap, not an implied capability.

## 3a. Rules added in V028

**A boundary function is total, or the boundary is not a boundary** (D-109; scope corrected by D-116). V027 promised "reported issue, never an escaping exception" and held it only for the input states the tests had named. The V028 wording of this rule - "every JSON-representable value in every position" - itself exceeded its evidence (V028 review F07): ordinary falsy present values and structured NaN disproved it. The claim is now scoped by the generative hostile-value matrix (RTM-133): every provider field position crossed with the twenty-value hostile set, ~540 combinations per run, asserting no exception, exact accounting and located issues. That matrix is the totality claim; arbitrary-JSON property coverage remains a named open item.

**Validation and traversal must share one graph** (D-109). `_validate_graph` rejected a node and `_current_branch` walked it anyway. What validation rejected, nothing downstream may dereference.

**Missing, valid-empty and wrong-type are three states** (D-110). `conv.get(x) or {}` collapsed a wrong-type-but-falsy container into valid-empty at 0 issues, and iterated a truthy wrong type into per-character fictional units. At a trust boundary, no `or`-default may erase the distinction.

**Absent content is malformed; explicit emptiness is valid - both preserved** (D-110). Author plus timestamp with no content field consumed as `text=""` was the "unknown is not empty" violation in a new place. The export failing to say anything and the export saying "empty" are different facts.

**Gate classification is structural, never prose-inferred** (D-111). The V027 stale-version gate's marker list contained "snapshot" and skipped its own founding defect. Historical means the sheet is a historical register or the line carries the HISTORICAL label - and the exact V026 phrase is a permanent negative regression that must fail in every future release.

**A CI command is verified by executing that command** (D-111). The shipped bootstrap job named a pytest path that did not exist; the local suite passed by rootdir discovery and proved nothing about the CI command. Every workflow pytest path is guard-collected, and release gates run the exact CI commands.

**A machine-readable artefact is audited against itself** (D-111). V028's gate fails a metadata file whose prose contradicts its own counts or the RTM's NOT ENFORCED set.

**The unique current snapshot carries the deterministic figure** (D-112). An environment aggregate ("435 tests passing") is that environment's result; the register's current count states the deterministic claim and declares integration results per-environment.

**A superseded mechanism is annotated where it is written** (D-112). ADR-027 amending ADR-026 was not enough while ADR-026 still prescribed the deleted equality unmarked; two Accepted ADRs may never appear simultaneously normative.

## 3a. Rules added in V027

**A fidelity unit is provider-native and counted exactly once** (D-105). V026 incremented the candidate count once per extraction problem, so one node with several defects counted as several source messages and coverage measured diagnostic outcomes. Candidate units are distinct source units - a message-bearing node, a message, a query side, an answer side - and container diagnostics (a cycle, a dangling parent) count no unit at all.

**An invariant a test asserts must not be manufactured by the implementation** (D-105). RTM-116's `candidate == events + issues` held partly because the code added a candidate for every issue. The invariant that matters is representation: every unit consumed or explicitly rejected - and the count that matters is units, which can never exceed what the source contains.

**Sibling units fail independently** (D-105). A question and its answer are two utterances; a malformed answer rejected the whole entry in V026 and a perfectly valid query disappeared. One malformed sibling never discards a valid one.

**A rejection carries its source** (D-106). `ParseIssue.raw` was the conversation's top-level key names; the offending value was absent and the unit unidentifiable. A rejected unit's issue names the conversation, unit and field, and carries a bounded canonical representation of the value itself.

**A validation gate enumerates semantically, never by blacklist** (D-107). The stale-version check listed V010-V012, so a V025 "CURRENT COUNT" shipped inside V026 untouched. The gate now derives the current release and fails any older version presented as current.

**A rule's stated claim must not exceed its test** (D-107, restating D-065 where it was violated). RTM-62 said "publishes no internal page" while its test read navigation. The rule now claims navigation separation; output exclusion is RTM-120, NOT ENFORCED until a mechanism and a built-output test exist.

**Machine counts in prose are derived or absent** (D-107). "5 blocking jobs" and "thirteen mutants" survived to V026 against derived values of 6 and 28. Prose references the FACTS block, and the release gate fails any hand-typed count that disagrees with the facts.

**The shipped package is part of the release surface** (D-107). Eighteen `.ruff_cache` files shipped in the V026 repository zip. The gate opens every shipped archive and fails on tool, cache and editor state.

**Release results separate deterministic from environment-dependent gates** (D-108). Independent execution of pristine V026 produced one more skip than the declared aggregate. The deterministic suite, the guards and the mutation gate are universal claims; integration/bootstrap results are declared per-environment, and one environment's total is never presented as a package fact.

## 3a. Rules added in V026

**A guarantee claimed for an adapter is provider-neutral, or it is not the adapter's guarantee** (D-102). V025 held ChatGPT to the fidelity invariant and not Claude or Perplexity: Claude structured blocks vanished at 0 issues / 100% coverage, malformed nested ChatGPT structure raised raw `AttributeError`, and Perplexity `str()`-coerced structure into Python reprs. Every source unit is an Event or a ParseIssue for **every** supported provider; nothing is coerced, dropped or crashed through an implementation detail.

**A nested contract is validated before it is relied on** (D-102). Validating the container (nodes, parents, cycles) while calling `.get()` on unvalidated children moved the crash one level down, not away.

**The release gate audits the shipped authority artefacts, not only repository files** (D-103). The V025 Standard restated the superseded publication-boundary rule while RTM-113 scanned only repo files and passed. `release_check` now scans the outer Markdown, and ArtifactAuthority / ManualTestIndex sheets are current-state, no longer audit-exempt.

**A register may hold one current state per capability** (D-104). "4 of 11 packages" beside a generated "6 coded"; S1-10 Partial six releases after durable storage; S2-04 Planned beside a Done S2-10; S2-01 Done on evidence belonging to another task. Older rows are marked Superseded or corrected; they do not remain active.

**Completion evidence must belong to the task it closes** (D-104). S2-01 (six-status evidence model, `at-evidence`) was Done carrying identity-resolution accomplishments while `at-evidence` had no code — the planning artefact said the next package was already finished.

**A manual test states its own limits locally, never the platform's absence** (D-103). "Nothing is persisted" and "none exist" were platform-wide claims that went false the release a capability landed. The wording is "this procedure does not exercise X", which stays true.

## 3a. Rules added in V025

**Structural validity is a property of the structure, not of the path being walked** (D-098). Cycles were detected only along the selected branch, so a cycle elsewhere was invisible.

**Preservation means the whole value in its own shape** (D-099). Truncation belongs in a log line or a UI preview, never in canonical ingestion data. V023 kept a count; V024 kept 500 characters and called it preserved — the same silent loss in a new place.

**A capability sentence may not generalise over layers or modules** (D-100). A sentence asserting that nothing past L0/L1 was coded was true when written and false from V021, and survived several reconciliations because each fix targeted one phrase. Name the modules, or generate the section.

**A release may not describe a Partial mechanism as working** (D-101). The Standard, the Test Strategy workbook and ADR-018 called the publication boundary functional while the metadata called it open.

## 3b. Rules added in V024

**A contract that storage does not carry is not a contract** (D-093). `LabelKind` stopped `human` becoming a person until the Event touched SQLite, and storage handed it back identity-bearing. **When a canonical field is added, it is added to persistence and to the round-trip test in the same change** — and if persistence changes meaning, the schema version changes with it.

**Values must be type-stable, not merely serialisable** (D-094). A tuple returned from storage as a list, so `restored == original` failed.

**Unknown is not True** (D-095). Marking every alternative as on the current branch is a positive assertion, not an absence of one.

**Automatic paths must be typed; only a deliberate human decision may use a raw string** (D-096).

**A hard-coded guard list silently stops covering new code** (D-097). Purity properties are declared and the guards derived.

**Fix the leak, do not filter the warning.** V023 added a filter that never fired because the leak surfaced through a different wrapper class, and the claim shipped anyway.

## 3b. Rules added in V023

**A release note must be checked against the behaviour it describes, not the change that was intended.** V022's README announced that AI role labels no longer became people. `assistant` was fixed; `human` and `user` were not, and the claim shipped anyway.

**Human-authored does not imply human-identifiable** (D-088). Whether a person wrote something and whether the source says *which* person are different questions.

**A factual section that can drift is generated, not written** (D-091). Pattern-matching stale phrases could not keep pace with capability change.

**Manual evidence must not inherit claims from automated evidence** (D-092). MT-006 claimed a revocation it never performed; MT-007 claimed authority precedence it never attempted.

**A mutation case must be verified to change behaviour.** A mutant that disabled half a compound condition survived, which looked like a test gap and was not.

## 3b. Rules added in V022

**A safety check must not modify what it is protecting** (D-086). Both SQLite stores created their tables and *then* refused an unsupported schema version. The check damaged the file it existed to defend.

**A state change and its audit record commit together, or neither does** (D-085). An identity that exists with no decision explaining it is worse than no audit at all, because the log now looks complete.

**A contract suite must build a fully populated object.** Ninety-two contract tests passed while durable storage dropped two `Event` fields, because no test ever set them.

**Counting starts from the raw source, not from what the parser understood** (D-087). Anything the extractor failed to recognise disappeared before it could enter the denominator, so loss reported as 100% coverage.

**Do not move forward while a reproduced blocker stays open.** V019's and V020's defects were still reproducible in V021, now with another layer built on them.

## 3b. Rules added in V021

**Where a record concerns a real person, an honest gap beats a plausible guess** (D-080). A guess presented as a resolution becomes an assertion, and everything downstream inherits it. The platform lists unresolved names and waits.

**A human decision is not undone by an automatic one** (D-081). A rule or model may not overwrite a manual decision; it raises. And a manual decision must record who made it — an unattributed override is not an override.

**An injected test double can hide an untested production path.** Every identity test injected a deterministic id factory, so the real generator was never exercised; a mutant making every id identical survived 313 passing tests. Where a factory is injected for determinism, the real one needs its own test.

**A declaration that is true only because the code does not exist yet is a liability** (D-082). `person_id` was marked unimplemented to escape recomputation, and building `at-identity` made that false.

## 3b. Rules added in V020

**A replaceable component gets a port and one shared contract suite** (D-076). Two implementations that behave differently are not substitutes, and every test that passed against the easier one would silently mean less.

**The audit trail outlives the data it justified** (D-078). Purging removes events; the record of who imported what, and when they withdrew, is kept. That is what makes a deletion defensible rather than merely done.

**Do not keep a second copy of data you have no lawful basis for** (D-077). The platform records that content with a given hash was imported; it does not retain the bytes.

## 3b. Rules added in V019

**A measure correct for one source may be meaningless for another** (D-073). `line_coverage` was right for WhatsApp and nonsense for JSON. Coverage is now reported in the source's own unit, and the wrong-unit accessor **raises** rather than returning a plausible number.

**Controls exist to make capability safe, not to replace it.** V008 to V018 added eleven consecutive releases of controls over four packages. The framework is finished; it is now used. A release that adds only controls needs a reason.

## 3b. Rules added in V018

**Anything that can drift gets a machine source before it drifts, not after** (D-068). Architecture, identity and RTM each got a manifest only after a document had gone stale. Testing got `testing.toml` first.

**Verification and documentation separate internal from external audiences** (D-069). A customer must never need pytest, mutation testing or an architecture TOML to prove the product works. *D-070's original mechanism claim — that nav omission excludes internal material — is SUPERSEDED (D-101, D-103, V026): MkDocs builds pages omitted from `nav`, so nav omission is intent, not exclusion. The boundary is Partial (DQ-016) and no current rule may describe it as working. The intent stands: exclusion will be achieved without deletion or duplication once a real mechanism exists.*

**Every manual test states what it does not prove.** A passing test is routinely read as proof of something it never touched. MT-003 proves import provenance and proves nothing whatever about consent.

**External test material is synthetic** (D-071). Real exports are internal verification evidence, never committed, never sample fixtures.

**A missing test level stays visibly missing.** L5 system, L8 security, L9 performance and L10 UI/E2E are declared `Planned` with no path and no directory. An empty directory implies work that has not been done.

## 3b. Rules added in V017

**A rule's test must establish the whole claim the rule makes, not the part that was easy to write** (D-065). Three releases produced the same shape of mistake: RTM-24 asserted "exactly one SourceRegistration" while its test built one registration; RTM-47 asserted "exactly its documented components" while checking only that each listed component influenced the id; RTM-49 asserted "runs in a clean environment" while the test supplied the environment. **When a rule cannot be fully tested, narrow the rule — not the reading of it.**

**A structured registry must be enforced across all of it, or it is a document** (D-066). `identity.toml` declared four identities and one was linked to code. Ids are now recomputed from the file and compared to the implementation, for every identity marked implemented.

**An advertised workflow is proven in a real environment** (D-067). Not one the test constructs for itself, and never with the case skipped exactly where the environment is cleanest.

**A historical snapshot may not describe itself as current.** V016 relabelled a row `HISTORICAL SNAPSHOT (V015 - the only current snapshot)` — self-contradictory in one line, in the register that exists to prevent it.

## 3b. Rules added in V016

**Generation removes stale copies of a correct fact. It does not make the generator correct.** V015's FACTS generator hard-coded "the three implemented production packages" and listed four, propagating one wrong sentence into four authoritative documents identically.

**An allow-list states current dependencies, not future permission** (D-061). Authorising ten packages for a module that uses three, or letting a product import a delivery interface, is an architecture decision taken silently.

**An advertised command must be tested as a person would run it** (D-063). `python -m at_cli` appeared in three documents while a clean checkout answered `No module named at_cli`.

**Any figure worth stating twice is worth deriving once** (D-064). The V015 chat announcement said 99 passed and 328 statements; the package said 117 and 385.

**A tool must not be able to damage the source it tests.** A mutation run killed externally left a mutant in a reviewer's checkout. `try/finally` cannot catch `SIGKILL`, so the source is no longer written to at all.

## 3b. Rules added in V015

**A rule that keeps the architecture honest must be declared in the machine source, not described.** The single principle making this platform reusable — a generic package never depends on a product — existed only in prose for fifteen versions, because `architecture.toml` declared no product application at all (D-057).

**Documents do not contain typed figures** (D-058). Four consecutive releases leaked a stale or invalid number past an ever-cleverer regex. Documents now carry a generated FACTS block; regex only detects forbidden drift.

**A regression test must assert the specific failure it exists for.** The sentinel mutant survived twice because the test accepted either of two messages, so disabling sentinel detection still passed.

## 3b. Two rules added in V014

**A rule's test must construct the case that would break it.** RTM-24 claimed an Event resolves to exactly one `SourceRegistration`. It was false for two versions because the test created only one registration and therefore could not observe the ambiguity. A passing test is not evidence unless it could have failed.

**No release artefact may contain a not-measured value** (D-055). V013 shipped `Expected: **-1 passed, -1 skipped**` because an internal sentinel escaped into documents and every numeric check accepted only digits. Unmeasured values are now `None`, release builds refuse them, and a mutation case proves the gate fails.

## 4a. Release versioning (D-048)

Every released package takes the **next integer version**: V001, V002, ... V012. No decimal patch versions. The package released as `V010.1` is canonical project release **V011** and is retained unchanged by hash; it is not reissued. Release type - synchronisation, correction, feature - is recorded in the metadata and change log, never in the version number.

## 5. Review

**Next review due 06-Sep-2026**, with the 30-day measurement (D-010). It has not happened: as of release V036 (11-Aug-2026, from release metadata - a hand-maintained "today" shipped two days stale in V026, F13) AT-056 has not started. The V012 standard said "Reviewed 06-Sep-2026" — a future date written in the past tense, which is the same class of error as a capability described above its state.


## 3b. Rules added in V036

- **Quantified boundaries (ADR-036, D-148/D-149):** a durable-store rule
  quantifies over EVERYTHING it guards - every platform marker, the complete
  expected schema fingerprinted from the store's own creation script, every
  store sharing a file preflighted before the first write. A selectively
  applied check is a documented bypass (V035 review F02/F03).
- **Evidence derives from the thing claimed about (D-153/D-154/D-155):** a
  hand-maintained list beside a machine source is the F01 class wherever it
  appears - package tuples, expected tables, facts schemas, timestamps. A
  mutation kill exists only relative to a proven-green baseline; a release
  claim exists only relative to the re-extracted bytes that ship.
- **Retired names are findings (RTM-173):** a derived alias the facts no
  longer carry can never be reconciled, only trusted blindly; current
  machine authority may not contain one, and release references in current
  metadata name THIS release.
- **Governance evidence must render (RTM-174):** a worksheet demonstrating
  review closure that ships clipped is not evidence; readability is part of
  the blocking package audit.
