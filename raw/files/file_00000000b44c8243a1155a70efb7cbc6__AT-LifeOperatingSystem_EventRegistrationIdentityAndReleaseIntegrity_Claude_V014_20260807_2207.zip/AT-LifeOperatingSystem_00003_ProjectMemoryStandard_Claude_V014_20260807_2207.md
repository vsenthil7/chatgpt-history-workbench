# Project Memory Standard

**AT-LOS | Claude | V014 | 07-Aug-2026 22:07 BST**
**Supersedes:** the V013 standard, which duplicated rule numbers 17 and 18. **Fifteen registers across sixteen worksheets** — `00_Index` is not a register.

---

## 1. Authority precedence (ADR-011, D-046)

Three absolute "authority" rules were previously in force at once and gave no answer when all three were consulted. One ordered list replaces them:

```
1. the code                  what the packages actually do
2. architecture.toml         declared layers, imports, module state
3. executable tests          enforce 1 against 2
4. generated documents       docs/ARCHITECTURE.md §B §C - never hand-edited
5. hand-written documents    README, READ_THIS_FIRST, TEST_STRATEGY
6. Project Memory            decisions, planning, scope, capability claims
```

**Project Memory cannot override machine-verified implementation state.** If a register says Implemented and nothing is on disk, the register is wrong. Project Memory remains authoritative for what code cannot answer: why a decision was taken, what is deferred, what must not be built.

## 2. The fifteen registers

| Tab | Holds | Cannot hold |
|---|---|---|
| 01_ActiveSprint | Work being executed | Anything without a Decision Log reference |
| 02_NextSprint | Decided, not started | Anything without a named unblocker |
| 03_ParkingLot | Ideas kept, not worked | Anything without a trigger **and an expiry** |
| 04_ResearchRepository | Needs evidence before planning | Anything already decided |
| 05_DecisionLog | Every decision, reason, date, owner | Edits. Reversals are new rows |
| 06_DeferredDecisions | **CLOSED.** Migrated to 13_DecisionQueue | New rows of any kind |
| 07_Assumptions | Silent dependencies | Anything without a named failure consequence |
| 08_LessonsLearned | What each version got wrong | Praise |
| 09_FutureVision | Long-term IP | Dates |
| 10_HallucinationRegister | True state of every capability | Aspirational states |
| 11_VersionHistory | Added, removed, why, still open | Retrofitted entries |
| 12_Archive | Completed and rejected | Deletions |
| 13_DecisionQueue | Decisions needed, intentionally postponed | A row missing any of the five mandatory fields |
| 14_SprintTracker | Live task board with proof of completion | A Done row whose Register column says No |
| 15_NamingRegister | Naming candidates and rejections | A claim without a verification level and source |

## 3. Rules

1. **Nothing is deleted.** Completed and rejected work moves to Archive with a reason.
2. **Every parked idea carries a review trigger and an expiry.**
3. **Every register row has an owner.**
4. **Nothing enters Active Sprint without a Decision Log entry.**
5. **The Decision Log is append-only.** Reversals are new rows; the original is marked Superseded.
6. **Every architecture change states why**, in the Decision Log and an ADR.
7. **No capability may be described above its Hallucination Register state.**
8. **Version History is written at release**, never reconstructed later.
9. **One review per month**, not per version.
10. **External factual claims state their verification level and source** (D-026 as narrowed by D-035). Applies to claims about the outside world, not internal planning rows.
11. **A postponed decision needs five fields**: why it matters, trigger, owner, latest date, delay cost.
12. **A task is not Done until its Hallucination Register row carries an immutable implementation reference** (D-049) - a commit SHA where Git is available, otherwise a package version plus an ADR or RTM id. The rule does not say "commit hash" while storing something else.
13. **Fifteen registers is the ceiling** (D-023).
14. **Architecture lives in the repository, with one machine-readable source** — `architecture.toml` — from which documents are generated (D-039). Hand-editing a generated table fails the build.
15. **Precedence resolves disagreement** (§1), replacing the old absolute "test wins" and "Project Memory wins" rules.
16. **A capability state names what it is, not what it is intended to be** (D-040). A docstring guarantee that the code contradicts is the same failure: V012's `ImportOccurrence` said it "never deduplicates" while an identical tuple collapsed.
17. **Release figures are measured, never estimated** (D-052). Fact derivation refuses to produce numbers from a failing suite. V012 computed passed tests as collected-minus-one, so a red suite could still yield a clean-looking fact set.
18. **A concept name must not answer a question it cannot answer** (D-051). `owner_ref` read like a consent answer; it recorded who imported a file. Renaming it `importer_ref` was half the fix — the other half was building the second graph it was standing in for. An in-memory dictionary is not persistence. A regression harness is not a mutation baseline. Line coverage of existing code is not functional coverage (D-045).
19. **Figures that appear in more than one artefact are derived from code, not typed** (D-046, D-050). `tools/release_facts.py` derives them, `tools/release_check.py` asserts every current document, and `tools/build_release.py` writes `release_facts.json` from which the release workbooks are generated. Blocking gate (RTM-23).
20. **Evidence recorded at task completion is historical.** Sprint Tracker column O says what was true when a row closed. Current totals live in the Hallucination Register and the Test Strategy workbook, both derived from code.

## 4. What this guards against

Six failures, all of which have happened here:

- **Rediscovery.** Q-001 raised as Critical in V002 and V003, left open in both.
- **Capability drift.** V003 discussed conversation reconstruction as if it were software.
- **Scope substitution.** Three packages in thirteen hours, one completed task — producing a package.
- **Asserted enforcement.** V006 said CI enforced the architecture rules; there was no CI. ADR-003 named `ruff` and `mypy --strict`; neither ran until V010.
- **Drift under a guard that did not cover it.** V008 guarded the README; in V009 the *authoritative* architecture document went a version stale.
- **Drift in the files that prevent drift.** V010 generated the architecture document, then shipped an onboarding file with two contradictory adapter rules and a test workbook still reporting V009 figures.
- **A gate described above what it checked.** V011's consistency checker scanned three regex patterns across four Markdown files and reported everything clean while five stale facts survived. Rules 17 and 18 exist because of this.

## 3a. Two rules added in V014

**A rule's test must construct the case that would break it.** RTM-24 claimed an Event resolves to exactly one `SourceRegistration`. It was false for two versions because the test created only one registration and therefore could not observe the ambiguity. A passing test is not evidence unless it could have failed.

**No release artefact may contain a not-measured value** (D-055). V013 shipped `Expected: **-1 passed, -1 skipped**` because an internal sentinel escaped into documents and every numeric check accepted only digits. Unmeasured values are now `None`, release builds refuse them, and a mutation case proves the gate fails.

## 4a. Release versioning (D-048)

Every released package takes the **next integer version**: V001, V002, ... V012. No decimal patch versions. The package released as `V010.1` is canonical project release **V011** and is retained unchanged by hash; it is not reissued. Release type - synchronisation, correction, feature - is recorded in the metadata and change log, never in the version number.

## 5. Review

**Next review due 06-Sep-2026**, with the 30-day measurement (D-010). It has not happened: today is 07-Aug-2026 and AT-056 has not started. The V012 standard said "Reviewed 06-Sep-2026" — a future date written in the past tense, which is the same class of error as a capability described above its state.
