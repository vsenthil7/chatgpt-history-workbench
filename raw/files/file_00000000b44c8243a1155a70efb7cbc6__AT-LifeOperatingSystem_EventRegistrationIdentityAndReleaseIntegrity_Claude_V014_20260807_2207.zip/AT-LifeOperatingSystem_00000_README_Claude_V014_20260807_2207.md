# AT-Life Operating System (AT-LOS) - V014

**Release:** `AT-LifeOperatingSystem_EventRegistrationIdentityAndReleaseIntegrity_Claude_V014_20260807_2207`
**Prepared by:** Claude · **07-Aug-2026 22:07 BST**

## V013 was correctly rejected. 12 findings, all verified, all real.

Two were blockers, and both were mine.

### Blocker 1 — the release gate shipped a sentinel it could not see

V013's README and READ_THIS_FIRST shipped:

> Expected: **-1 passed, -1 skipped**

`-1` was the *not measured* sentinel I introduced to stop the fact-deriver recursing inside pytest. It leaked into documents, and every numeric check in my own gate accepted only digits — so nothing matched and the gate reported green.

Fixed three ways: the sentinel is `None`, not a number that can masquerade as one · `require_measured=True` makes `build_release.py` and `release_check.py` refuse unmeasured facts · sentinel-aware patterns, two tests (RTM-38, RTM-39) and a **mutation case** that proves the gate fails.

That mutant **survived on first run** — no test proved the gate caught a sentinel. Mutation testing again found what 99 passing tests did not.

### Blocker 2 — RTM-24 was false

ADR-013 put `origin_kind` into `SourceRegistration.registration_id` but not into `SourceRef`. So `registration_for_event()` took it as an **argument**, and the same Event resolved to a different registration depending on what the caller passed. I reproduced it exactly as reported.

RTM-24 claimed "an Event resolves to exactly one SourceRegistration". It didn't — and the test passed for two versions because it created only **one** registration and so could not see the ambiguity.

**ADR-014: identity comes from the Event, never from an argument.** `origin_kind` is in `SourceRef` and in `event_id`. The lookup takes no identity argument (RTM-34 asserts the signature). An adapter stamps its own origin kind (RTM-37).

### The two graphs had a back door

`SubjectRef.is_importer` came from `Participant.is_owner` — a display-name comparison in the parser — sitting beside an opaque `importer_ref`. That is the conflation ADR-013 removed, reintroduced one field lower. **Flag removed.** Only `at-identity` may connect a raw name to an importer.

### The method claimed more than it returned

`subjects_of_event()` returned the author and was described as *"whom is this event about"*. Renamed **`structural_participants_of_event()`**. **DQ-013** records the gap and, with DQ-012, blocks `at-consent`.

Also fixed: `architecture.toml` — the machine source itself — still said at-store "resolves an Event to its owners for consent" · `owner_ref` throughout the authoritative document · stale guard and store-test counts · duplicated Standard rules 17/18 · multiple rows labelled CURRENT COUNT.

## Gates

```
pytest                 99 passed, 1 skipped · 328 statements, 0 missed, 100%
architecture guards    24 collected
ruff / mypy --strict   clean
mutation regression    13/13 killed (pre-flight verified)
standalone install     3/3 clean venvs
release integrity      0 failures — measured facts required
real exports           500 events, 0 issues, 2 registrations, 2 occurrences
```

RTM: **36 passing + 1 skipped + 2 not enforced = 39.**

## Migration note

`event_id` changed for every event. No migration is needed because nothing is persisted — the store is in-memory. **That is precisely the cost of settling identity before Sprint 2 rather than after.**

## Sprint 2

`at-identity` and `at-evidence` can start. **`at-consent` is blocked on DQ-012 and DQ-013**, both of which need AT-052. Real dependencies, not more architecture.

## Still not done

RTM-14, RTM-15 unenforced · store not durable · ingestion not streaming · no GDPR basis, no consent.

**AT-056 remains Not started.** Unmoved without a date from you.
