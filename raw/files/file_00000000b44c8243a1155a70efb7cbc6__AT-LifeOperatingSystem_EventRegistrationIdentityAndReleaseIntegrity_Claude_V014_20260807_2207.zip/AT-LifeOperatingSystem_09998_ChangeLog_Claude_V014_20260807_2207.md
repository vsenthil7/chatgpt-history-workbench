# AT-LOS V014 Change Log

**Release type:** event/registration identity and release-gate integrity. One new ADR (014), which **amends** ADR-013.

## Verified

12 findings raised. All 12 verified against the code before acceptance. None rejected.
Cumulative across six reviews: **70 raised, 70 confirmed, 0 rejected.**

## ADR-014

- `origin_kind` added to `SourceRef` and to `event_id`. `registration_for_event()`, `importers_of_event()` and `orphaned_events()` take no identity argument (RTM-34).
- `at-ingest-whatsapp` exports `ORIGIN_KIND` and stamps it (RTM-37).
- `SubjectRef.is_importer` removed (RTM-36).
- `subjects_of_event()` → `structural_participants_of_event()`. DQ-013 opened.
- Sentinel is `None`; `require_measured=True` on release paths; sentinel-aware patterns; RTM-38, RTM-39 and two mutants.

## Corrected

`architecture.toml` at-store responsibility · `owner_ref` throughout ARCHITECTURE.md · RTM-25 wording and the stale test name · guard, parser and store counts · Standard rules 17/18 renumbered · historical CURRENT COUNT rows relabelled · per-sheet workbook stale-version detection.

## Gates

99 passed, 1 skipped · 328 statements, 0 missed, 100% · 24 guards · 13/13 mutants · ruff and mypy clean · 3/3 standalone · release integrity 0 failures · 500 events reproduced.

## Decisions

D-054 identity from the Event · D-055 no unmeasured value in a release artefact · D-056 at-store must not equate a raw author with an importer

## Not done

No feature work. `at-identity`, `at-consent`, `at-evidence` not started. **AT-056 remains Not started.**
