#!/usr/bin/env python3
"""Derive workbook facts by machine (review V001 point 1 / finding of 27-vs-22 drift).
Writes 11-analysis/workbook-inventory.json. All workbook counts quoted in documents
must come from this file; validate_register.py cross-checks key figures."""
from pathlib import Path
import json, re, sys

from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[1]
WB = ROOT / '10-baseline/IPBS-Adaptive-Work-and-Resource-Pilot-v0.1.0.xlsx'
OUT = ROOT / '11-analysis/workbook-inventory.json'

wb = load_workbook(WB, data_only=False)
inv = {'source': WB.name, 'sheets': [], 'totals': {}}
dv_total = 0
formula_cells_total = 0
inline_lists, central_refs = set(), set()

for name in wb.sheetnames:
    ws = wb[name]
    rows = list(ws.iter_rows(values_only=True))
    headers = [c for c in (rows[0] if rows else []) if c is not None]
    ncols = len(rows[0]) if rows else 0
    op_rows = 0          # rows with at least one constant (non-formula) value
    formula_ranges = {}  # header -> count of formula cells
    for r_i, row in enumerate(ws.iter_rows(min_row=2), start=2):
        has_const = False
        for cell in row:
            v = cell.value
            if v is None:
                continue
            if isinstance(v, str) and v.startswith('='):
                col_h = rows[0][cell.column - 1] if cell.column - 1 < ncols else cell.coordinate
                formula_ranges[str(col_h)] = formula_ranges.get(str(col_h), 0) + 1
                formula_cells_total += 1
            else:
                has_const = True
        if has_const:
            op_rows += 1
    dvs = []
    for dv in ws.data_validations.dataValidation:
        dv_total += 1
        f1 = dv.formula1 or ''
        kind = 'central-ref' if '99_Lists' in f1 else 'inline-list' if f1.startswith('"') else 'other'
        (central_refs if kind == 'central-ref' else inline_lists if kind == 'inline-list' else set()).add(f1)
        dvs.append({'ranges': str(dv.sqref), 'type': dv.type, 'formula1': f1, 'kind': kind})
    id_cols = [h for h in headers if isinstance(h, str) and (h.endswith('_ID') or h == 'Task_ID')]
    inv['sheets'].append({
        'name': name, 'max_row': ws.max_row, 'max_col': ws.max_column,
        'headers': [str(h) for h in headers],
        'operational_data_rows': op_rows,
        'preseeded_formula_cells_by_column': formula_ranges,
        'row_cap': ws.max_row - 1 if ws.max_row > 11 else None,
        'data_validations': dvs,
        'id_link_columns': id_cols,
    })

lists_sheet = wb['99_Lists']
central_taxonomies = [str(c) for c in next(lists_sheet.iter_rows(min_row=1, max_row=1, values_only=True)) if c]

inv['totals'] = {
    'sheet_count': len(wb.sheetnames),
    'dv_object_count': dv_total,
    'distinct_inline_list_definitions': len(inline_lists),
    'distinct_central_list_references': len(central_refs),
    'central_taxonomies_in_99_Lists': len(central_taxonomies),
    'central_taxonomy_names': central_taxonomies,
    'preseeded_formula_cells': formula_cells_total,
    'operational_data_rows_total': sum(s['operational_data_rows'] for s in inv['sheets']),
    'hard_row_caps': {s['name']: s['row_cap'] for s in inv['sheets'] if s['row_cap']},
}
OUT.write_text(json.dumps(inv, indent=2) + '\n', encoding='utf-8')
t = inv['totals']
print(f"workbook inventory derived: sheets={t['sheet_count']} dv_objects={t['dv_object_count']} "
      f"inline_lists={t['distinct_inline_list_definitions']} central_refs={t['distinct_central_list_references']} "
      f"central_taxonomies={t['central_taxonomies_in_99_Lists']} formula_cells={t['preseeded_formula_cells']} "
      f"operational_rows={t['operational_data_rows_total']}")
