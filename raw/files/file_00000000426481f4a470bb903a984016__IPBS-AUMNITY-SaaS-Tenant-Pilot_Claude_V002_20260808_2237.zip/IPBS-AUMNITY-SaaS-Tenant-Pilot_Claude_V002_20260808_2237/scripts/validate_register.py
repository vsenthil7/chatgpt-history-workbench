#!/usr/bin/env python3
"""G10 register/document consistency validation, V002 (substantially strengthened
per independent review point 13). Scope of PASS is exactly the checks listed in
the output — nothing broader is claimed.

Checks:
 1. CSV well-formedness, unique IDs, required fields.
 2. Owner / status / classification vocabulary validity.
 3. Owner↔classification mapping (1=PLATFORM 2=CGWO 3=URAIFLOW 4=TENANT-IPBS
    5=NEW-MODULE; CROSS-PRODUCT exempt but must be PROPOSED).
 4. NEW-MODULE ⇒ PROPOSED/PROMOTED; implementation_version empty for all
    (implementation inside the pilot is prohibited); VALIDATED forbidden
    without evidence reference (currently forbidden outright: no product exists).
 5. ADR gating: every `Gates:` line in every ADR is parsed; gated RPRs must be
    PROPOSED (or PROMOTED only if that ADR is ACCEPTED); every ADR referenced in
    CSV evidence must exist; PROPOSED entries must reference an existing ADR or
    CROSS-PRODUCT-DEPENDENCIES.md.
 6. Evidence references resolve: workbook sheet names against
    workbook-inventory.json; F-xx findings against BASELINE-ANALYSIS.md;
    file references against the tree.
 7. Narrative consistency: total, per-owner counts, per-status counts, and the
    listed PROPOSED ID set match the CSV exactly.
 8. RTM consistency: entry-count string matches CSV.
 9. Workbook-derived counts: analysis quotes match workbook-inventory.json
    (dv objects, sheets, formula cells, operational rows).
"""
from pathlib import Path
import csv, json, re, sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

VALID_OWNERS = {'PLATFORM', 'CGWO', 'URAIFLOW', 'TENANT-IPBS', 'NEW-MODULE', 'CROSS-PRODUCT'}
VALID_STATUS = {'OBSERVED', 'CLASSIFIED', 'PROPOSED', 'PROMOTED', 'IMPLEMENTED', 'VALIDATED'}
CLASS_OWNER = {'1': 'PLATFORM', '2': 'CGWO', '3': 'URAIFLOW', '4': 'TENANT-IPBS', '5': 'NEW-MODULE'}

# --- load artefacts -----------------------------------------------------------
rows = list(csv.DictReader((ROOT / '12-requirements/promotion-register.csv').open(encoding='utf-8')))
md = (ROOT / '12-requirements/REQUIREMENT-PROMOTION-REGISTER.md').read_text(encoding='utf-8')
analysis = (ROOT / '11-analysis/BASELINE-ANALYSIS.md').read_text(encoding='utf-8')
rtm = (ROOT / '06-traceability/RTM.md').read_text(encoding='utf-8')
inv = json.loads((ROOT / '11-analysis/workbook-inventory.json').read_text(encoding='utf-8'))
sheet_names = {s['name'] for s in inv['sheets']}
findings = set(re.findall(r'\| \**\s*(F-\d{2})\**', analysis))
adr_files = {p.stem.split('-')[0] + '-' + p.stem.split('-')[1]: p for p in (ROOT / '02-architecture/ADR').glob('ADR-*.md')}

# --- 1-4 row-level checks -----------------------------------------------------
ids = [r['id'] for r in rows]
if len(ids) != len(set(ids)):
    errors.append('duplicate register IDs')
by_owner, by_status, proposed_ids = {}, {}, []
for r in rows:
    rid = r['id']
    if not re.fullmatch(r'RPR-\d{3}', rid):
        errors.append(f'{rid}: malformed ID')
    for field in ('ipbs_observation', 'generic_requirement', 'validation_evidence'):
        if not r[field].strip():
            errors.append(f'{rid}: empty {field}')
    if r['owner'] not in VALID_OWNERS: errors.append(f"{rid}: invalid owner {r['owner']}")
    if r['status'] not in VALID_STATUS: errors.append(f"{rid}: invalid status {r['status']}")
    if r['classification'] not in CLASS_OWNER: errors.append(f"{rid}: invalid classification {r['classification']}")
    if r['owner'] == 'CROSS-PRODUCT':
        if r['status'] != 'PROPOSED':
            errors.append(f'{rid}: CROSS-PRODUCT requires PROPOSED, is {r["status"]}')
    elif r['owner'] == 'NEW-MODULE':
        if r['classification'] != '5':
            errors.append(f'{rid}: NEW-MODULE requires classification 5')
        if r['status'] not in {'PROPOSED', 'PROMOTED'}:
            errors.append(f'{rid}: NEW-MODULE requires PROPOSED/PROMOTED')
    else:
        if CLASS_OWNER[r['classification']] != r['owner']:
            errors.append(f"{rid}: classification {r['classification']} inconsistent with owner {r['owner']}")
    if r['implementation_version'].strip():
        errors.append(f'{rid}: implementation_version set — implementation inside the pilot is prohibited')
    if r['status'] == 'VALIDATED':
        errors.append(f'{rid}: VALIDATED impossible — no product implementation exists (see VALIDATION-EVIDENCE-CRITERIA.md)')
    by_owner[r['owner']] = by_owner.get(r['owner'], 0) + 1
    by_status[r['status']] = by_status.get(r['status'], 0) + 1
    if r['status'] == 'PROPOSED':
        proposed_ids.append(rid)

# --- 5 ADR gating -------------------------------------------------------------
adr_status, adr_gates = {}, {}
for adr_id, path in adr_files.items():
    text = path.read_text(encoding='utf-8')
    sm = re.search(r'\*\*Status:\*\* (\w+)', text)
    adr_status[adr_id] = sm.group(1) if sm else 'UNKNOWN'
    gated = set()
    for line in re.findall(r'^Gates: (.+)$', text, re.M):
        gated |= {g.strip() for g in line.split(',')}
    adr_gates[adr_id] = gated

row_by_id = {r['id']: r for r in rows}
for adr_id, gated in adr_gates.items():
    for rid in gated:
        r = row_by_id.get(rid)
        if r is None:
            errors.append(f'{adr_id} gates unknown entry {rid}')
        elif r['status'] == 'CLASSIFIED':
            errors.append(f'{rid}: gated by {adr_id} ({adr_status[adr_id]}) but marked CLASSIFIED')
        elif r['status'] == 'PROMOTED' and adr_status.get(adr_id) != 'ACCEPTED':
            errors.append(f'{rid}: PROMOTED while gating {adr_id} is {adr_status.get(adr_id)}')
for r in rows:
    for adr_ref in re.findall(r'ADR-\d{4}', r['validation_evidence']):
        if adr_ref not in adr_files:
            errors.append(f"{r['id']}: references missing {adr_ref}")
    if r['status'] == 'PROPOSED':
        has_gate = any(r['id'] in g for g in adr_gates.values())
        refs_dep = 'CROSS-PRODUCT-DEPENDENCIES' in r['validation_evidence'] or re.search(r'ADR-\d{4}', r['validation_evidence'])
        if not (has_gate or refs_dep):
            errors.append(f"{r['id']}: PROPOSED without ADR gate or dependency reference")

# --- 6 evidence resolution ----------------------------------------------------
for r in rows:
    ev = r['validation_evidence']
    for m_ in re.finditer(r'Workbook (\w+)', ev):
        if m_.group(1) not in sheet_names:
            errors.append(f"{r['id']}: evidence cites unknown workbook sheet {m_.group(1)}")
    for f_ in re.findall(r'F-\d{2}', ev):
        if f_ not in findings:
            errors.append(f"{r['id']}: evidence cites unknown finding {f_}")
    for fname in re.findall(r'([\w.-]+\.(?:md|json))', ev):
        if not list(ROOT.rglob(fname)):
            errors.append(f"{r['id']}: evidence cites missing file {fname}")

# --- 7 narrative consistency --------------------------------------------------
tm = re.search(r'\*\*Total\*\* \| \*\*(\d+)\*\*', md)
if not tm or int(tm.group(1)) != len(rows):
    errors.append(f'narrative total != CSV rows ({len(rows)})')
for owner, n in by_owner.items():
    label = re.escape(owner) + (r' \(proposed\)' if owner == 'NEW-MODULE' else '')
    if not re.search(rf'\| {label} \| {n} \|', md):
        errors.append(f'narrative owner count for {owner} != {n}')
for status, n in by_status.items():
    if not re.search(rf'\| {status} \| {n} \|', md):
        errors.append(f'narrative status count for {status} != {n}')
nm = re.search(r'PROPOSED entries: ([^.]+)\.', md)
if nm:
    listed = set(re.findall(r'RPR-\d{3}', nm.group(1)))
    if listed != set(proposed_ids):
        errors.append(f'narrative PROPOSED set {sorted(listed)} != CSV {sorted(proposed_ids)}')
else:
    errors.append('narrative missing PROPOSED-entries statement')

# --- 8 RTM --------------------------------------------------------------------
if f'({len(rows)} entries' not in rtm:
    errors.append(f'RTM entry-count string does not match CSV ({len(rows)})')

# --- 9 workbook-derived counts in analysis -------------------------------------
t = inv['totals']
for label, value in [('DataValidation objects', t['dv_object_count']),
                     ('sheets', t['sheet_count'])]:
    if f"**{value}**" not in analysis and f"{value} {label}" not in analysis:
        errors.append(f'analysis does not quote machine-derived count {value} for {label}')
if f"{t['preseeded_formula_cells']:,}" not in analysis.replace('1,507', '1,507'):
    if str(t['preseeded_formula_cells']) not in analysis and f"{t['preseeded_formula_cells']:,}" not in analysis:
        errors.append('analysis formula-cell count missing/mismatched')
if 'zero operational transaction rows' not in analysis and '0 operational transaction rows' not in analysis.lower():
    if '**0 operational transaction rows**' not in analysis:
        errors.append('analysis operational-row statement missing')

if errors:
    print('REGISTER/DOCS CONSISTENCY: FAIL')
    for e in errors: print(' -', e)
    sys.exit(1)
print(f'REGISTER/DOCS CONSISTENCY: PASS — scope: {len(rows)} entries; owners '
      + ', '.join(f'{k}={v}' for k, v in sorted(by_owner.items()))
      + '; statuses ' + ', '.join(f'{k}={v}' for k, v in sorted(by_status.items()))
      + f'; ADR gates enforced ({sum(len(g) for g in adr_gates.values())} gated refs across {len(adr_gates)} ADRs); '
        'evidence references resolved; narrative/RTM/workbook counts cross-checked. '
        'PASS covers exactly the checks listed in this script docstring, nothing broader.')
