# VALIDATED — evidence criteria (defined V002)

Current maturity, stated honestly: this package is a **tenant-pilot requirements-discovery baseline**. The workbook contains zero operational transaction rows (machine-verified), no user has run the workflow, and no product contract has been exercised. Nothing in this package is, or may be described as, completed live tenant validation. No tenant validation data may ever be fabricated to advance a register entry.

A register entry may move to `VALIDATED` only when ALL of the following exist and are referenced from the entry's evidence field:

1. **Product version reference** — the owning product release implementing the requirement (entry already IMPLEMENTED).
2. **Tenant contract/fixture exercise** — an acceptance or contract test, owned by this pilot package, exercising the product's published contract with IPBS tenant configuration/fixtures (permitted pilot content per TENANT-PILOT-PROMOTION-RULE.md), executed with machine-captured results.
3. **Representative usage evidence** — real IPBS operational records or a documented representative scenario executed by an IPBS user, with dates and actors.
4. **Usability/friction findings** — recorded observations from that usage (including "none"), feeding the register as new OBSERVED entries where applicable.
5. **Recorded acceptance** — a named IPBS acceptor, date, and outcome (accept / accept-with-conditions / reject), stored under `13-evidence/`.

Partial evidence keeps the entry at IMPLEMENTED with a note; the validator refuses VALIDATED without an evidence reference.
