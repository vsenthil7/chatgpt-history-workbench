# Cross-Product Dependencies and Unresolved Conflicts — V002

The tenant pilot discovers requirements; owning SaaS repositories decide reusable domain ownership. This file records every dependency on a decision that must be made outside this package, so the pilot never independently cements a product boundary. All items are OPEN.

| # | Dependency | Affected register entries | External decision needed | Risk if pilot decided alone |
|---|---|---|---|---|
| X-01 | CGWO architecture direction reportedly treats trackers/timesheets as potential external systems of record reached through bridges, with CGWO owning Execution Session / Plan Item / Allocation state | RPR-017 (and shape of RPR-015/016 contracts) | CGWO repository ADR on execution/timesheet boundary | Pilot would cement "consolidation → CGWO" from workbook evidence, contradicting the product architecture |
| X-02 | Whether a reusable human-attestation primitive exists at Platform level, or each context owns its own decision state machine over shared audit/identity primitives | RPR-006 (RPR-007 audit stays Platform per starter rule) | Platform repository boundary decision, informed by ≥2 genuinely cross-context uses | Shared core becomes a dumping ground for vocabulary-similar behaviour |
| X-03 | Referential-integrity split: Platform identifier primitives vs bounded-context internal integrity vs published-reference contracts | RPR-003, RPR-004 | Platform + each product confirm the decomposition in ADR-0004 | Central Platform service acquires knowledge of every product's internals |
| X-04 | Capability module boundary vs Platform resource attributes vs CGWO planning inputs | RPR-050, RPR-012 | Product-portfolio decision on ADR-0002 | A new SaaS product is created (or denied) without portfolio-level comparison |
| X-05 | UraiFlow proposal/commit contract: typed record schemas, versioning, validation/preview, idempotency, failure/rollback, authorization, tenant context | RPR-030, RPR-032; 06↔08 linkage | UraiFlow repository contract definition | Pilot's free-form workbook fields become a de-facto competing contract |
| X-06 | Reference-data mechanism vs vocabulary semantics ownership | RPR-008 | Platform confirms mechanism-only scope; each product claims its vocabularies | Global enum service couples all products |

**Note on evidence basis:** X-01's CGWO direction is reported by the independent reviewer from parallel CGWO V002 architecture work; the relevant CGWO artifacts are not part of this package and the claim is therefore recorded as an input to reconcile, not a verified fact. Reconciliation requires reading the current CGWO package directly.
