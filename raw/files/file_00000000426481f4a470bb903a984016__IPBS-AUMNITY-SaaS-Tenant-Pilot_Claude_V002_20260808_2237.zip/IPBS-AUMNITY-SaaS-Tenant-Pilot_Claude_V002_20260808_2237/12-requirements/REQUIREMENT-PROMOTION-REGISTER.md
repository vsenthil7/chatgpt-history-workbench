# Requirement Promotion Register — V002

**Source of truth:** `promotion-register.csv` (machine-readable). This narrative is cross-checked against it by `scripts/validate_register.py`; counts here are validated, never hand-maintained.

**Pipeline:** IPBS observation → generic requirement → owning SaaS product/module → status → implementation version → validation evidence.

**Status vocabulary:** `OBSERVED` → `CLASSIFIED` → `PROPOSED` (ADR-gated or ownership unresolved) → `PROMOTED` (accepted into owning product backlog) → `IMPLEMENTED` (owning-product version recorded) → `VALIDATED` (IPBS tenant evidence per VALIDATION-EVIDENCE-CRITERIA.md).

**Owner codes:** PLATFORM = AUMNITY Work Platform SaaS · CGWO = AUMNITY CGWO SaaS · URAIFLOW = UraiFlow SaaS · TENANT-IPBS = IPBS tenant configuration · NEW-MODULE = proposed bounded SaaS module · **CROSS-PRODUCT** (added V002) = ownership unresolved pending ADR and/or reconciliation with owning-product architectures; a CROSS-PRODUCT entry is always PROPOSED, its classification digit records the V001 candidate classification, and it can only leave CROSS-PRODUCT via an accepted ADR.

## V002 position

| Owner | Entries |
|---|---|
| PLATFORM | 6 |
| CGWO | 11 |
| URAIFLOW | 4 |
| TENANT-IPBS | 4 |
| CROSS-PRODUCT | 3 |
| NEW-MODULE (proposed) | 1 |
| **Total** | **29** |

| Status | Entries |
|---|---|
| CLASSIFIED | 25 |
| PROPOSED | 4 |

PROPOSED entries: RPR-003 (ADR-0004), RPR-006 (ADR-0003), RPR-017 (ADR-0003), RPR-050 (ADR-0002). No entry has an implementation version: no generic code exists, or may exist, inside this pilot.

## V002 changes from V001 (per independent review)

- **RPR-011 revised** (F-15): row-level `planned ≤ available` is insufficient; the requirement is aggregate allocation evaluation per resource per time window, with supervisory capacity evaluated separately.
- **RPR-015 revised** (F-16): the workbook cannot hold the pause/resume events its instructions promise; the requirement is a durable, immutable execution event history with derived current state.
- **RPR-016 revised** (F-17 + F-02/F-14): duration must be event-derived *active* time excluding pauses/interruptions, correct across midnight/DST/time zones, rejecting impossible intervals — not `End − Start`.
- **RPR-017 reworded and moved to CROSS-PRODUCT/PROPOSED** (F-18): consolidation was designed intent, not implemented behaviour, and its ownership (CGWO-internal vs external system-of-record via bridges) must be reconciled with the current CGWO architecture, not cemented from the workbook.
- **RPR-006 moved to CROSS-PRODUCT/PROPOSED**: three approve/reject/correct appearances in one tenant workbook with different domain semantics do not earn a shared Platform primitive; ADR-0003 reworked accordingly.
- **RPR-007 remains PLATFORM/CLASSIFIED** and is removed from ADR-0003 scope: audit/evidence is explicitly named a Platform primitive by the starter promotion rule; the requirement covers audit mechanics, not domain decision semantics.
- **RPR-003 decomposed and moved to CROSS-PRODUCT/PROPOSED** (ADR-0004): Platform owns identifier primitives; bounded contexts own internal integrity; cross-context references validate via published contracts.
- **RPR-008 narrowed**: Platform provides a reference-data *mechanism* only; vocabulary *semantics* stay with their bounded contexts. No global enum service.
- **RPR-030/032 reworded** (F-12): the workbook is a workflow/interface *hypothesis*; the UraiFlow product defines the actual contract, which the pilot consumes.
- **RPR-042 removed from ADR-0003 scope**: tenant-config classification follows rule 4 directly; generic billing remains not-proposed.

## Lifecycle rules (tightened in V002)

1. Observations enter as OBSERVED with evidence before classification.
2. ADR-gated entries and unresolved ownership are PROPOSED — never CLASSIFIED — until the gating ADR is ACCEPTED (machine-enforced: each ADR carries a `Gates:` line parsed by the validator).
3. CROSS-PRODUCT entries additionally require the reconciliation recorded in CROSS-PRODUCT-DEPENDENCIES.md before any owner assignment.
4. PROMOTED requires an owning-product backlog reference; IMPLEMENTED requires that product's version; VALIDATED requires evidence meeting VALIDATION-EVIDENCE-CRITERIA.md.
5. Legal transitions only move forward along the pipeline; regressions require an ADR.
