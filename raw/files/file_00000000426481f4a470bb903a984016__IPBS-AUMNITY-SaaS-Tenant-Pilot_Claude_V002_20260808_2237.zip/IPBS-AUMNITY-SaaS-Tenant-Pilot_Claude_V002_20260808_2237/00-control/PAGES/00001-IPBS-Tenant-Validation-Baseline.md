# Page 00001 — IPBS-Tenant-Validation-Baseline

**Session:** 08/08/2026 22:16 Europe/London · **Builder:** Claude · **Output artifact:** IPBS-AUMNITY-SaaS-Tenant-Pilot_Claude_V001_20260808_2216.zip
**Input artifact:** IPBS-AUMNITY-SaaS-Tenant-Pilot_ChatGPT_V001_20260808_1318.zip (all 16 files read; workbook fully decomposed)

## Scope executed (B001 + first half of B002)
1. Read the complete starter package and the preserved workbook (sheets, headers, all 27 data-validation lists, all formulas).
2. Produced `11-analysis/BASELINE-ANALYSIS.md` — 14 findings inventoried, nothing deleted or normalised.
3. Produced the initial Requirement Promotion Register — 29 entries: 8 PLATFORM, 12 CGWO, 4 URAIFLOW, 4 TENANT-IPBS, 1 NEW-MODULE (proposed).
4. Raised ADR-0001 (accepted: register discipline), ADR-0002 and ADR-0003 (proposed: capability-module and timesheet-split ownership — awaiting human approval).
5. Added RTM rows REG-001..004; ran validators; regenerated the package manifest.

## Deliberately NOT done
No product/domain source code, no schemas, no APIs, no workbook "fixes" — per the critical rule, the pilot owns no generic product code and the workbook is input evidence only.

## Open decisions for the human
- Approve/amend ADR-0002 (capability module) and ADR-0003 (timesheet split).
- Confirm the status vocabulary and owner codes in the register.

---

# V002 session — 08/08/2026 22:37

**Input:** Claude V001 ZIP + independent ChatGPT review (22:29). **Output:** IPBS-AUMNITY-SaaS-Tenant-Pilot_Claude_V002_20260808_2237.zip
**Page status:** V001 reviewed — corrections required → V002 corrections applied. Still a **requirements-discovery baseline**, not completed tenant validation.

## Corrections applied (see BASELINE-ANALYSIS §0 correction log)
- C-01: "27 validation lists" was wrong — machine-derived count is **22** DataValidation objects; workbook facts now generated, not asserted. (The "all 27 data-validation lists" statement in the V001 section above is superseded.)
- Findings F-15..F-18 added: aggregate-capacity false positive, event-history contradiction, elapsed-vs-active duration, declared-vs-implemented consolidation.
- Lifecycle contradiction fixed: ADR-gated entries (RPR-003/006/017/050) are now PROPOSED; new CROSS-PRODUCT owner code for unresolved ownership; ADR-0003 reworked (no "three appearances earn a primitive"); ADR-0004 added; ADR-0002/0003/0004 all remain PROPOSED — none silently approved.
- Real manifest validator, much stronger register validator, deterministic manifest + packaging, honest gate table, precise baseline-provenance claim, VALIDATED evidence criteria defined.

## Open decisions for the human (unchanged + new)
ADR-0002/0003/0004 approval; reconciliation with current CGWO / Platform / UraiFlow packages per CROSS-PRODUCT-DEPENDENCIES.md (X-01…X-06).
