# Changelog

## Claude V001 — 2026-08-08 22:16
First Claude build on the ChatGPT V001 starter. Baseline accepted (B001) and initial requirement classification/promotion model produced (B002 analysis half). 29-entry Requirement Promotion Register, 14-finding baseline analysis, ADR-0001..0003, RTM REG-001..004, register/manifest validators, full-package manifest regeneration. Zero product code by design; baseline preserved byte-identical.

## Claude V002 — 2026-08-08 22:37
Corrections build responding to the independent ChatGPT review of V001 (18 points, 4 blockers). Workbook facts machine-derived (22 DV objects — corrects V001's "27"); findings F-15..F-18 added (aggregate-capacity false positive, event-history contradiction, active-vs-elapsed duration, declared-vs-implemented consolidation); lifecycle contradiction fixed via CROSS-PRODUCT owner + machine-enforced ADR gating; ADR-0003 reworked (retracts "three appearances earn a primitive"), ADR-0004 added, none approved; RPR-003/008/030/032 reworded per boundary review; real manifest validator; register validator rewritten (9 check groups, 6/6 negative tests detected); deterministic manifest+packaging with reproducibility evidence; honest gate table; precise baseline-provenance claim; VALIDATED evidence criteria defined. Baseline workbook untouched.
