# AT-Life Operating System (AT-LOS) - V004

**Release:** `AT-LifeOperatingSystem_EvidenceExtractionAndScopeReset_Claude_V004_20260806_2350`
**Prepared by:** Claude
**Timestamp:** 06-Aug-2026 23:50 BST (Europe/London)
**Prototype subject:** Senthil
**Supersedes:** `AT-SubhaBhuvana_ConsultantMeetingTracker_ChatGPT_V003_20260806_1142.xlsx` and the V003 50-task planner.
**Does not supersede:** the V001 charter, methodology, naming standard or research landscape. Those stand.

## What V004 is

V001 to V003 built the architecture. V004 is the first release that runs the method on real data instead of describing it.

Three of the four things V003 promised were never done: the evidence table was empty, Q-001 was left open for a second version, and the consultant tracker was built from an unverified count. V004 does those three, and cuts the plan to what can actually be executed.

## What changed

1. **The consultant analysis was rebuilt from the raw WhatsApp export**, not from the V003 summary. Result: 27 scheduling cycles, 7 full calls held, 11% adherence to an agreed daily cadence. V003 recorded 22 cycles and 10 held. V003 was optimistic and is superseded.
2. **The evidence register is populated.** 31 evidence records, 11 observer claims and 8 internal contradictions, extracted from the V001-V003 documents and the raw exports, classified under the six-status model from the V001 methodology. The V002 evidence sheet had zero data rows.
3. **Q-001 is closed by written decision.** The 30-day proof metric is commitment follow-through, with a named data source, window, success test, failure test and stop rule.
4. **The plan is cut from 50 tasks to 12.** Nothing is deleted; deferred items keep their V003 ID and a named re-entry trigger.

## Package contents

| File | What it is |
|---|---|
| `00000_README` | This file |
| `00001_DecisionMemo_Q001ProofMetricAndScopeCut` | Closes Q-001. Records the scope cut and its reasons |
| `00002_Metadata` | Package metadata |
| `00010_RevisedProgrammePlan` | 12 active tasks, 15 deferred with triggers, 4 stopped outright |
| `03000_EvidenceRegister` | Populated evidence, observer claims, contradictions, provenance |
| `AT-SubhaBhuvana_CallEffectivenessAnalysis` | 27 cycles from the raw export, with trend and open gaps |
| `09998_ChangeLog` | Change log |
| `09999_Manifest` | SHA-256 manifest |

## Read in this order

1. `00001_DecisionMemo` - what was decided and why
2. `AT-SubhaBhuvana_CallEffectivenessAnalysis` - the evidence the decision rests on
3. `03000_EvidenceRegister`, sheet `03_Contradictions` - what the earlier versions committed to but did not do
4. `00010_RevisedProgrammePlan` - what runs next

## Two things stopped, not deferred

The Kognisence DMIT report on Kenishka is removed as a system input, and neither daughter is to be modelled. DMIT has no accepted scientific validity, and the V001 charter forbids creating a fixed label for a child. The V003 input list contradicted the charter on this point.

## Evidence boundary

Every observer claim in this package is unvalidated. Nothing here may be repeated to a third party as fact about Subha, Bhuvana, Durga or anyone else. The consultant analysis covers one WhatsApp thread only; phone and in-person contact are invisible in it, so 7 held calls is a floor, not a total.

## Known gaps

- 3 of 27 cycles remain UNCERTAIN pending Google Meet history
- 9 Drive recording links in the thread are unresolved
- Neither Subha nor Bhuvana has seen or validated any of this
- No lawful basis under UK GDPR has yet been established for third-party modelling (AT-052)
