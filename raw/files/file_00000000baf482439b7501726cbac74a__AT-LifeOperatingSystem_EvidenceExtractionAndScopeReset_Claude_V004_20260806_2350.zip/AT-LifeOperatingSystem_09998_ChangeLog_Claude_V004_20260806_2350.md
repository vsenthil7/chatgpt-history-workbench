# AT-LOS V004 Change Log

## Added

- Populated evidence register: 31 evidence records classified under the V001 six-status model. The V002 evidence sheet had zero data rows.
- Observer claim register: 11 claims Senthil has made about other people, each with alternative explanations not yet ruled out.
- Contradiction register: 8 conflicts between what the V001-V003 documents commit to and what the plan does.
- Provenance sheet mapping every evidence ID to its source document or export.
- Decision memo closing Q-001 with metric, data source, window, success test, failure test and stop rule.
- Revised programme plan: 12 active tasks, 15 deferred with named re-entry triggers, 4 stopped outright.
- Consultant call effectiveness analysis rebuilt from the raw WhatsApp export, with a 3-period trend, stated reasons for non-attendance, and 7 open gaps.
- Two new legal tasks, AT-052 and AT-053, gating all observer-model work.
- New commercial task AT-055 mapping the evidence schema onto IPBS CEaaS.

## Corrected

- Consultant meeting count: V003 recorded 22 cycles and 10 held. The raw export yields 27 cycles and 7 full calls held. The V003 tracker is superseded.
- Blocker attribution: 9 cycles lapsed on Subha's side and 7 on Bhuvana's. The V003 framing treated this as a single-party issue.
- 3 further cycles were lost to Google Meet failures rather than either party's choice.

## Removed

- IN-008, the Kognisence DMIT report on Kenishka, as a system input. Contradicts the V001 charter prohibition on fixed child labels; DMIT has no accepted scientific validity.
- All modelling of Sharani and Kenishka.

## Deferred with triggers

- Audio workstream in full: normalisation, diarisation, speaker identity, segment cutting.
- Conversation reconstruction and topic transition detection.
- Human State and sensor inference.
- SaaS multi-tenancy and B2B2C data-ownership design.
- Platform-versus-product architecture split, shared package and event contracts.
- Mind-model comparison and the education hypothesis.
- Bulk email, audio and document import.

## Unchanged

- V001 charter, methodology and collection standard, naming and versioning standard, research landscape and source register.
- V002 evidence rule that a statement about another person remains an observer-perspective record until that person validates, rejects or contextualises it.
