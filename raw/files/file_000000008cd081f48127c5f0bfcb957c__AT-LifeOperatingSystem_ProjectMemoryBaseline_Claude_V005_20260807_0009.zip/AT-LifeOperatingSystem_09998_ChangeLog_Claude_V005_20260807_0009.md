# AT-LOS V005 Change Log

## Added

- **Project Memory workbook** with twelve registers: Active Sprint, Next Sprint, Parking Lot, Research Repository, Decision Log, Deferred Decisions, Assumptions, Lessons Learned, Future Vision, Hallucination Prevention Register, Version History, Archive.
- **Hallucination Prevention Register**: 23 capabilities with their true state and the phrase not to use for each. Two implemented, three manual only, eight planned, ten vision/named-only/research/rejected.
- **Project Memory Standard** stating the nine rules and what each guards against.
- **Decision Log back-filled** with all 18 decisions from V003, V004 and V005, each with reason, owner, version and current status. D-005 marked superseded by D-013.
- **Assumptions register**: 9 entries, each naming what breaks if the assumption fails. AS-004 (Subha and Bhuvana will consent) and AS-008 (Senthil has capacity) are both rated Low confidence and both underpin dated work.
- **Parking Lot** with 14 items, each carrying a trigger, an expiry date and a stated outcome on expiry.
- **Deferred Decisions**: 7 questions deliberately unanswered, each naming what must exist first.
- **Lessons Learned**: 8 entries across V001-V005, including two live risks recorded against V005 itself.
- Three new decisions: D-016 (Project Memory adopted), D-017 (Parking Lot expiry), D-018 (no capability described above its register state).
- Three new tasks: AT-056 (run the 30-day measurement), AT-057 (automate it), AT-058 (meeting lifecycle extraction), plus AT-059 and AT-060 in Next Sprint.

## Changed

- V004 Revised Programme Plan folded into `01_ActiveSprint`. Do not maintain both.
- Active Sprint now 13 items, with Blocked distinguished from Planned by a named dependency.

## Additions to the structure proposed by ChatGPT

- Parking Lot items carry an **expiry**, not only a review trigger. An idea that reaches expiry without its trigger firing is rejected into the Archive.
- Every register row carries an **owner**.
- The memory is reviewed **monthly**, not per version.

## Recorded as live risks, not resolved

- The proposed ChatGPT/Claude division of labour could license unlimited architecture on the assumption someone else will cut it later. Parking Lot expiry is the control.
- The Project Memory itself could become the next thing that substitutes for building. Twelve registers is substantial structure for a project with no code.

## Unchanged

- V001 charter, methodology and collection standard, naming and versioning standard, research landscape.
- V004 decision memo, evidence register and consultant analysis, carried forward under their V004 filenames.
