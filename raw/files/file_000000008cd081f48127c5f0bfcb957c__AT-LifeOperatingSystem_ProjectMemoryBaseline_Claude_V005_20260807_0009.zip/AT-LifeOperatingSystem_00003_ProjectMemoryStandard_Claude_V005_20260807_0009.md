# Project Memory Standard

**AT-LOS | Claude | V005 | 07-Aug-2026 00:09 BST**

Purpose: one living document that survives across versions, across AI systems, and across gaps in Senthil's attention, so that no idea is rediscovered and no capability is spoken of as if it exists.

Structure proposed by ChatGPT on 06-Aug-2026. Adopted with two additions, marked below.

---

## 1. The registers

| Tab | Holds | Cannot hold |
|---|---|---|
| 01_ActiveSprint | Work being executed | Anything without a Decision Log reference |
| 02_NextSprint | Decided, not started | Anything without a named unblocker |
| 03_ParkingLot | Ideas kept, not worked | Anything without a trigger **and an expiry** |
| 04_ResearchRepository | Needs evidence before planning | Anything already decided |
| 05_DecisionLog | Every decision, reason, date, owner | Edits. Reversals are new rows |
| 06_DeferredDecisions | Deliberately unanswered questions | Questions nobody has raised |
| 07_Assumptions | Silent dependencies | Anything without a named failure consequence |
| 08_LessonsLearned | What each version got wrong | Praise |
| 09_FutureVision | Long-term IP | Dates |
| 10_HallucinationRegister | True state of every capability | Aspirational states |
| 11_VersionHistory | Added, removed, why, still open | Retrofitted entries |
| 12_Archive | Completed and rejected | Deletions |

## 2. Rules

1. **Nothing is deleted.** Completed work moves to Archive. Rejected work moves to Archive with a reason. Both stay readable.
2. **Every parked idea carries a review trigger and an expiry.** *(Addition to the proposed structure.)* A trigger alone produces an infinite backlog that feels like progress. On expiry, an idea whose trigger never fired is rejected in the Archive. Rejection is a decision, not a loss — and it can be reversed by a new Decision Log row.
3. **Every register row has an owner.** *(Addition.)* A register of unowned items is a wish list.
4. **Nothing enters Active Sprint without a Decision Log entry.** Vision cannot leak into execution by enthusiasm.
5. **The Decision Log is append-only.** To reverse D-005, write a new row that says so and mark D-005 superseded. Never edit the original.
6. **Every architecture change states why it changed.** In the Decision Log, not in prose.
7. **No capability may be described above its Hallucination Register state.** This binds humans and AI systems equally. "Planned" is not "built". "Vision only" is not "planned".
8. **Version History is written at release.** Never reconstructed later from memory.
9. **One review per month, not per version.** *(Addition.)* Twelve registers reviewed every time a package is produced would itself become the work.

## 3. What this standard is guarding against

Three failures, all of which have already happened in this project:

- **Rediscovery.** V002 and V003 both raised Q-001 as Critical and both left it open. Registers with owners and review dates prevent a question from silently recurring.
- **Capability drift.** By V003 the documents discussed conversation reconstruction, speaker identity and a Human State engine in language that did not distinguish them from working software. None existed. The Hallucination Register makes the boundary explicit and checkable.
- **Scope substitution.** V001 to V003 produced three packages in thirteen hours with one completed task, which was producing a package. Structure can substitute for building. The expiry rule and the monthly review cadence exist because this standard could easily become the next instance of the same failure.

## 4. Note on the ChatGPT / Claude division of labour

ChatGPT proposed: architecture and cross-domain synthesis on its side, execution planning and scope reduction on Claude's.

That split is workable, but it carries a risk worth recording, and it is logged as a live risk in 08_LessonsLearned: a permanent architecture role can license unlimited architecture, on the assumption that someone else will cut it later. The Parking Lot expiry rule is the specific control against that. Ideas may be parked freely; they may not be parked indefinitely.

The vision is not the problem. An unbounded vision with no eviction rule is.

## 5. Review

This standard is reviewed on 06-Sep-2026, alongside the 30-day follow-through measurement (D-010). If the measurement failed, the stop rule in the V004 decision memo applies to the Project Memory too: it becomes documentation of a closed project, not a live one.
