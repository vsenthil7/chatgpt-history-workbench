# AT-Life Operating System (AT-LOS) - V005

**Release:** `AT-LifeOperatingSystem_ProjectMemoryBaseline_Claude_V005_20260807_0009`
**Prepared by:** Claude
**Timestamp:** 07-Aug-2026 00:09 BST (Europe/London)
**Prototype subject:** Senthil
**Structure proposed by:** ChatGPT, 06-Aug-2026, adopted with two additions

## What V005 is

V005 adds one thing: a **Project Memory** — a single living workbook with twelve registers that carries the project across versions, across AI systems, and across gaps in attention.

It exists because three failures have already happened here: Q-001 was raised and abandoned twice; capabilities that do not exist were discussed as if they did; and three packages were produced in thirteen hours with one completed task.

## The twelve registers

`01_ActiveSprint` · `02_NextSprint` · `03_ParkingLot` · `04_ResearchRepository` · `05_DecisionLog` · `06_DeferredDecisions` · `07_Assumptions` · `08_LessonsLearned` · `09_FutureVision` · `10_HallucinationRegister` · `11_VersionHistory` · `12_Archive`

## Two additions to the proposed structure

1. **Parking Lot items carry an expiry, not only a review trigger.** A trigger alone produces a backlog that grows without limit and feels like progress. On expiry, an idea whose trigger never fired is rejected into the Archive — reversible by a new decision, but no longer silently pending.
2. **Every register row has an owner.** A register of unowned items is a wish list.

A third, smaller one: review the memory **monthly**, not per version, or maintaining it becomes the work.

## The register worth reading first

`10_HallucinationRegister` records the true state of all 23 capabilities ever discussed in this project. Two are implemented. Three are manual only. Eight are planned with no code. Eight are vision, named-only, research or rejected.

Rule D-018: no capability may be described above its state there — in any document, message or conversation, with a human or an AI.

## Package contents

| File | What it is |
|---|---|
| `00000_README` | This file |
| `00003_ProjectMemoryStandard` | The rules governing the memory and what they guard against |
| `00020_ProjectMemory` | The living workbook. Twelve registers |
| `00002_Metadata` | Package metadata |
| `AT-LifeOperatingSystem_00001_DecisionMemo_..._V004_...` | Carried forward unchanged. Closes Q-001 |
| `AT-LifeOperatingSystem_03000_EvidenceRegister_..._V004_...` | Carried forward unchanged |
| `AT-SubhaBhuvana_CallEffectivenessAnalysis_..._V004_...` | Carried forward unchanged |
| `09998_ChangeLog` | Change log |
| `09999_Manifest` | SHA-256 manifest |

V004 files keep their V004 filenames and hashes. They were not reissued under a V005 label, because nothing in them changed and the naming standard forbids overwriting an existing artifact. The V004 standalone plan is the one thing folded in — it now lives in `01_ActiveSprint`.

## Superseded

`AT-LifeOperatingSystem_00010_RevisedProgrammePlan_Claude_V004_20260806_2350.xlsx` — folded into the Project Memory. Do not maintain both.

Still standing unchanged: the V001 charter, methodology, naming standard and research landscape.

## State of the project, stated plainly

No code exists. Two capabilities are implemented, both of them workbooks. The evidence register and the consultant analysis were produced by hand. Nothing has been validated by Subha or Bhuvana. No lawful basis under UK GDPR has been established.

The next artefact should not be a document. It should be the 30-day measurement running, or a parser that works.
