# Architecture Decision Records

| ADR | Title | Status |
|---|---|---|
| ADR-001 | Repository layout, language and toolchain for the platform kernel | ACCEPTED |
| ADR-002 | Explicit tenant context and ports-and-adapters isolation model | ACCEPTED |
| ADR-003 | V002 first-slice scope: shared kernel only | ACCEPTED |
| ADR-004 | Deterministic in-repo mutation gate instead of external mutation tool | ACCEPTED |
| ADR-005 | RTM unification and baseline reference corrections | ACCEPTED |
| ADR-006 | Domain error taxonomy and edge mapping for tenant isolation | ACCEPTED |
| ADR-007 | Tenant/principal identity binding via PrincipalDirectory port and founding principal | ACCEPTED |
| ADR-008 | Structurally immutable event payloads | ACCEPTED |
| ADR-009 | Pinned toolchain contract and clean-room release validation | ACCEPTED |
| ADR-010 | Audit trust boundary: AuditLog is a protected service; AuditSink is infrastructure-trusted | ACCEPTED |
| ADR-011 | Tenant bootstrap atomicity via TenantProvisioner port (supersedes ADR-007's atomicity mechanism) | ACCEPTED |
| ADR-012 | Non-mutating, idempotent release validation with external verification evidence | ACCEPTED |
| ADR-013 | Public kernel boundary classification; OrganisationDirectory (protected) split from PlatformProvisioning (trusted admin) | ACCEPTED |
| ADR-014 | Audit actor attribution: actor is the authenticated acting caller; delegation deferred with declared consequence | ACCEPTED |
| ADR-015 | Current-document version labels are gate-enforced against ARTIFACT-VERSION | ACCEPTED |
| ADR-016 | Command unit of work: work object, evidence and audit persistence commit atomically | ACCEPTED |
| ADR-017 | Persistence integrity: create-vs-update semantics, duplicate-id rejection, optimistic concurrency | ACCEPTED |
| ADR-018 | Mutation-critical scope driven by defect history; integrity predicates centralised in guards module | AMENDED BY V006 REVIEW (see ADR-018 amendment) |
| ADR-019 | In-memory transaction serialisation: one mutex per shared store composition; nesting rejected | ENFORCEMENT SUPERSEDED BY ADR-021 |
| ADR-021 | Serialisation domain is machine-derived from shared transactional resources; independent locking impossible by construction | ACCEPTED |
| ADR-022 | Universal write-path participation: every mutation of a transactional store occurs inside its serialisation domain; ambient-join with coverage; adapter-level mechanical guard | ACCEPTED |
| ADR-020 | Defective-adapter invariant covers the whole aggregate: embedded principal references validated before disclosure | ACCEPTED |

---

## ADR-001 — Repository layout, language and toolchain
**Context.** The starter demands deterministic builds, 100% line+branch coverage on
executable product packages, architecture guards and machine-readable evidence. The
baseline recommends Python services (FastAPI later).
**Decision.** `platform/` is the product code root. Two packages:
`packages/aumnity_contracts` (pure shared contracts: IDs, tenant context, events, errors,
clock/id-generation protocols — no dependency on any other package) and
`packages/aumnity_kernel` (platform primitives: Organisation, Principal, Work Object
registry, Evidence, Policy, Audit; depends only on `aumnity_contracts`). Python 3.12,
pytest + coverage (branch), ruff, mypy (strict). All quality gates are runnable scripts
under `platform/scripts/gates/` producing JSON/text evidence under `platform/evidence/`.
`PYTHONHASHSEED=0` for gate runs; release ZIP built with normalised mtimes for
reproducibility.
**Consequences.** No web framework or database dependency in V002; the kernel is
importable by future `services/platform_api` without modification.

## ADR-002 — Explicit tenant context and ports-and-adapters
**Context.** SaaS guard: "Protected operations must carry explicit tenant/organisation
context and be tested for cross-tenant denial. Avoid global mutable tenant state."
**Decision.** Every protected kernel operation takes a `TenantContext`
(organisation id + acting principal id) as its first argument. Repositories and the audit
log are ports (Protocols) with in-memory adapters in V002. Repository reads are
tenant-filtered inside the kernel service, never left to the adapter alone: the service
re-checks `organisation_id` on every loaded aggregate and raises `TenantIsolationError`
on mismatch, so a defective adapter cannot silently leak. There is no module-level
mutable tenant state anywhere.
**Consequences.** A PostgreSQL adapter later implements the same ports and inherits the
same contract tests (deferred: RTM row INF-001).

## ADR-003 — V002 first-slice scope
**Context.** First build objective: "harden the platform boundary, define
tenant/organisation semantics and shared contracts, then build the minimum shared kernel
demanded by real bounded modules — not a speculative mega-core." Baseline minimum build
boundary and Brutal Readiness Audit both restrict initial scope.
**Decision.** V002 implements exactly: Organisation registry; Principal identity
(HUMAN/AI/SERVICE); Work Object registry with the baseline lifecycle state machine,
version increments, recursive decomposition (parent/child in same organisation),
minimal assignment-to-principal, immutable evidence attachment with SHA-256 content
reference, evidence-gated completion policy for critical work, and an append-only,
tenant-scoped audit trail emitting the baseline event names. Explicitly deferred with
declared RTM rows: Actor/Capability/Capacity (D02/D03), review-as-work-object (D04),
knowledge/handover (D05), UraiFlow bridge implementation (D06 — the source-system
constant and evidence linkage fields exist as contract only), SLA timers, AI gateway,
service catalogue, pricing, persistence adapter, HTTP edge, Playwright (no
browser-visible journey exists yet, so the Playwright obligation is not triggered).
**Consequences.** CGWO and UraiFlow consume the kernel through its public service API and
events; no bounded-product logic entered the kernel.

## ADR-004 — Deterministic in-repo mutation gate
**Context.** QA-002 requires mutation testing for critical domain/policy logic with
attached evidence. External mutation tools introduce nondeterminism and environment
coupling that conflict with the deterministic-build rule in this sandboxed pipeline.
**Decision.** `g07_mutation_gate.py` performs AST-based mutations (comparison-operator
swaps, boolean-operator swaps, constant flips, arithmetic swaps) over the declared
critical modules (`workobject/state.py`, `policy.py`), runs the fast unit suite per
mutant, and writes a machine-readable kill report. Threshold: 100% of generated mutants
killed; any survivor fails the gate and becomes explicit work.
**Limitation (honest).** The operator set is narrower than a full mutation tool; this is
recorded, not hidden. Adopting `mutmut` in CI proper is a declared follow-up (RTM QA-002
note).
**Consequences.** Mutation evidence is reproducible byte-for-byte across runs.

## ADR-005 — RTM unification and baseline reference corrections
**Context.** ISS-002/ISS-004: two unlinked RTMs and broken renamed references.
**Decision.** `06-traceability/RTM.md` (starter location) is the single authoritative
RTM. Baseline DW-FR-001…015 are imported into it with per-row status; the baseline RTM
file remains untouched under `10-baseline/` and is superseded by reference. Baseline
broken links are documented in `11-issues/BASELINE-ISSUES.md`; baseline files are never
edited, honouring the baseline-preservation rule.
**Consequences.** One requirement namespace; G09 enforces that every ENFORCED row maps to
collectable test node IDs.

## ADR-006 — Error taxonomy and isolation edge mapping
**Context.** Cross-tenant access must be denied and testable, but a public API must not
leak resource existence.
**Decision.** Kernel raises typed errors: `TenantIsolationError` (cross-tenant access),
`NotFoundError`, `InvalidTransitionError`, `PolicyViolationError`, `ValidationError`,
all subclassing `PlatformError`. The future HTTP edge MUST map `TenantIsolationError`
to the same external representation as `NotFoundError` (404) to avoid existence leaks;
inside the trust boundary the distinct type keeps isolation failures observable and
auditable. This mapping obligation is recorded as contract, tested at the edge when the
edge exists (deferred RTM row API-001).

## ADR-007 — Tenant/principal identity binding (V002 review Findings 1–2)

**Context.** ChatGPT's independent V002 review reproduced two exploits: a Work
Object could be created/assigned with a principal belonging to another
organisation, and a TenantContext mixing Organisation A with a principal from
Organisation B was accepted. DW-FR-013 cannot be ENFORCED while identity binding
is absent. Three concepts must be separated: authentication (out of kernel
scope), tenant/principal identity binding (this ADR — cannot be deferred), and
role/permission authorization (SEC-001, legitimately deferred).

**Decision.** The kernel validates principal membership through a
`PrincipalDirectory` port (`require_member(context, principal_id)`), implemented
in-process by `OrganisationRegistry`. Every protected `WorkObjectRegistry`
operation first *binds* the context (`require_member(context,
context.principal_id)`), and every principal reference an operation accepts
(owner, assignee) is proven a member of the context organisation. Unknown and
foreign principals raise the same `TenantIsolationError` so principal existence
in other tenants cannot be probed. `create_organisation` atomically creates the
founding principal, eliminating V002's unverified-bootstrap fixture limitation.
No CGWO/UraiFlow/IPBS coupling is introduced.

**Consequences.** Breaking change to `WorkObjectRegistry.__init__` and
`create_organisation` (product 0.1.0 → 0.2.0; no external consumer existed).
Denials occur before any state change or audit emission, so a rejected
operation leaves no trace other than the raised error.

## ADR-008 — Structurally immutable event payloads (V002 review Finding 3)

**Context.** `EventEnvelope` was a frozen dataclass, but `payload:
dict[str, str]` remained mutable; ChatGPT mutated a recorded audit entry through
its payload reference.

**Decision.** `payload` is typed `Mapping[str, str]`; `__post_init__`
defensively copies the caller's mapping and wraps the private copy in
`types.MappingProxyType`. Both the write boundary (caller keeps mutating their
own dict — envelope unaffected) and the read boundary (any holder of the
envelope gets a read-only view) are protected structurally, not by convention.
Payload keys and values are validated to be strings.

**Consequences.** Attempted mutation raises `TypeError`. Regression tests cover
tampering via a recorded audit entry and via the originally supplied dict.

## ADR-009 — Pinned toolchain and clean-room release validation (V002 review Findings 4–6, 9–10)

**Context.** V002 configured pytest/coverage/ruff/mypy but declared no
installable dependency contract; the review environment could not run the full
ladder; the G11 "smoke" ran only validator+manifest+pytest; two G11 scripts
existed; the artifact version was hard-coded in packaging logic.

**Decision.** (a) `platform/requirements-dev.txt` is the authoritative pinned
toolchain, mirrored in `[project.optional-dependencies].dev`. (b) One canonical
release gate, `scripts/gates/g11_release.py`: bootstrap a fresh venv from the
pins, run the COMPLETE ladder (`run_gates.py release`) in a pristine staged
copy, regenerate+verify the release manifest, build the ZIP twice
deterministically, then extract the exact final ZIP and run the full release
ladder inside the extraction. (c) `run_gates.py` gains build/release modes;
release mode requires the incoming manifest to verify BEFORE anything runs and
performs no regeneration, so drift can never be silently absorbed
(this control would have flagged the V002 stray `g11_package_release.py`).
(d) The artifact version is read from the root `ARTIFACT-VERSION` file.

**Consequences.** "Clean checkout reproduces the ladder" is now a tested claim
with pip-freeze evidence, not an environment assumption. Final-ZIP validation
results live next to the ZIP, since they cannot be stored inside the archive
whose bytes they describe.

## ADR-010 — Audit trust boundary (V003 review Findings 1–2)

**Context.** `AuditLog` is exported from `aumnity_kernel.__all__` and is
therefore a published surface, yet V003's `entries_for` bound only the
organisation id (a forged `TenantContext(Org-A, Principal-B)` read Org-A
history) and `record` accepted arbitrary envelopes (foreign-actor injection).
The claim "audit actor can never be foreign" held only for events emitted via
`WorkObjectRegistry`. The review demanded an explicit trust-model decision, not
a convenient point fix.

**Decision.** Model A, applied consistently: `AuditLog` is a PROTECTED
application service exactly like `WorkObjectRegistry`. It depends on
`PrincipalDirectory`; `entries_for(context)` binds the acting principal before
returning anything; `record(context, event)` binds the context, requires
`event.organisation_id == context.organisation_id`, and proves
`event.actor_principal_id` is a member of that organisation. This gives product
modules a safe tenant-bound event-recording contract. The raw `AuditSink` port
remains the infrastructure-trusted persistence boundary: it stays out of the
kernel `__all__`, is never handed to untrusted application code, and adapters
alone implement it. Violations raise `TenantIsolationError` uniformly.

**Consequences.** Breaking signature change (`record` takes context;
constructor takes the directory). Cross-module audit publication now cannot
forge another tenant's actor/org combination by construction. TEN-001,
DW-FR-013 and SaaS-002 evidence now includes the audit boundary.

## ADR-011 — Tenant bootstrap atomicity (V003 review Finding 3)

**Context.** ADR-007 stated `create_organisation` "atomically creates the
founding principal", but the implementation sequenced two independent
repository writes; the review injected a failing principal store and produced
an orphan organisation. Repository ports cannot honestly promise cross-write
atomicity.

**Decision.** Atomicity is placed where transactions actually exist: a
`TenantProvisioner` port with the contract "persist organisation AND founder
all-or-nothing; on failure neither remains visible". The registry constructs
both aggregates and makes ONE port call; it never sequences independent writes
for bootstrap. The in-memory adapter implements compensating rollback; the
future PostgreSQL adapter (INF-001) implements a database transaction. This
supersedes ADR-007's mechanism statement; the founding-principal semantics of
ADR-007 are unchanged.

**Consequences.** `OrganisationRegistry` gains a provisioner dependency
(breaking, no external consumer). A failure-injection regression proves no
partial tenant survives (RTM TEN-002). The claim is now backed by a port
contract an adapter can actually honour.

## ADR-012 — Non-mutating release validation (V003 review Finding 4)

**Context.** Release-mode gates wrote fresh `generated_at` evidence into
manifest-controlled files, so validating a released tree broke its own G01 on
the next run: validation was destructive and non-idempotent.

**Decision.** Shipped evidence inside the package is immutable. All
verification-time gate output is written to an external evidence directory
(`AUMNITY_EVIDENCE_DIR`; release mode defaults to a fresh temp dir). G11
step 5 proves the property: extract the final ZIP, digest every
manifest-controlled file, run the complete release ladder twice on the same
extraction with G01 verified after each run, digest again — both ladders must
pass and the digests must be identical, with no regeneration or cleanup.

**Consequences.** Release validation is read-only and repeatable by anyone,
any number of times. Build mode still writes into `platform/evidence/` (that
is how shipped evidence is produced) and regenerates the manifest at the end.

## ADR-013 — Public kernel boundary classification (V004 review Finding 1)

**Context.** `OrganisationRegistry` sat in `aumnity_kernel.__all__` with an
unscoped `get_organisation(organisation_id)`; the review read another tenant's
organisation name through the published surface. The V004 signature contract
introspected only `WorkObjectRegistry` (plus a separate AuditLog test), so the
drift escaped — exactly what the contract exists to prevent.

**Decision.** Every published name is explicitly classified, and the
classification is machine-checked (contract test
`TestPublicBoundaryInventory`): PROTECTED SERVICES (`WorkObjectRegistry`,
`AuditLog`, `OrganisationDirectory`) whose every public method must take
`TenantContext` first; VALUE TYPES; POLICY TYPES. TRUSTED, UNPUBLISHED
boundaries (`PlatformProvisioning`, `AuditSink`, `TenantProvisioner`) must NOT
appear in `__all__`. `OrganisationRegistry` is split accordingly:
`OrganisationDirectory` (published, protected) exposes `get_organisation(context)`
returning only the CALLER'S OWN organisation — no arbitrary-id lookup exists on
the published surface, making the exploit impossible by construction — plus
`create_principal` and `require_member`. `PlatformProvisioning` (trusted
platform-operator boundary, unpublished, like `AuditSink` under ADR-010) owns
`create_organisation`, which is unscoped by nature since it runs before any
tenant context exists. An unclassified export, a stale classification, or a
protected method without leading context fails G05.

**Consequences.** Breaking: `OrganisationRegistry` removed from the API
(0.3.0 → 0.4.0, no external consumer). Admin operations are now structurally
distinguishable from tenant services. Future exports must be classified to
ship.

## ADR-014 — Audit actor attribution semantics (V004 review Finding 3)

**Context.** ADR-010 blocked cross-tenant audit forgery, but a same-tenant
principal could still record an immutable event attributing an action to a
colleague: the envelope's single `actor_principal_id` field carried no
recorder/actor/delegation distinction, and V004's own regression exercised that
pattern as "valid".

**Decision.** `actor_principal_id` MEANS the authenticated acting caller.
`AuditLog.record` therefore requires `event.actor_principal_id ==
context.principal_id` (the bound context principal); a mismatch raises
`ValidationError` as an attribution-integrity violation. This single rule
subsumes the foreign-actor and unknown-actor cases (neither can equal a proven
member). Recording on behalf of another actor — recorder vs causal actor vs
on-behalf-of delegation — is a real future need and is DECLARED (RTM AUD-004)
as an explicit provenance contract with its own authorization, not an overload
of one field. This is deliberately NOT parked under SEC-001: the audit-integrity
consequence of deferral (no delegated recording exists at all until AUD-004
lands) is documented here.

**Consequences.** Services emit as themselves; `WorkObjectRegistry` already
complies by construction. Same-tenant impersonation is regression-tested from
the review's exact scenario.

## ADR-015 — Current-document version labels (V004 review Finding 4)

**Context.** V004 shipped current headings claiming V003/V002 (`platform/README.md`,
`12-adr/ADR-INDEX.md`, `00-control/READING-MAP.md`) while ARTIFACT-VERSION was
V004; G10's C7 pattern was too narrow to notice — the same class V003 Finding 5
was meant to eliminate, so that finding was only partially fixed.

**Decision.** Current, non-baseline navigational/metadata surfaces
(`platform/README.md`, `12-adr/ADR-INDEX.md`, everything under `00-control/`,
and the RTM heading) must be version-neutral or carry exactly
ARTIFACT-VERSION; G10 C7 enforces this for heading lines and reading-map
entries. Inherently historical records (CHANGELOG sections, per-release review
findings and handoffs, defect-log rows, ADR bodies describing which release a
decision responded to) legitimately carry old versions and are exempt by
scope, not by pattern-narrowness.

**Consequences.** A release that forgets to update current labels fails G10
instead of shipping; the three V004 stale headings are corrected and covered.

## ADR-002 — Addendum (V006, V005 review F2/F3, DEF-021/DEF-022)

The original ADR-002 claim — the kernel protects against defective adapters —
was materially stronger than the implementation: `children()` returned
repository results unvalidated, `evidence_for()` verified neither tenancy nor
work-object linkage of loaded records, `get_organisation()` returned whatever
row came back, and `require_member()` never checked that the returned
principal WAS the requested one (so a wrong-row adapter response counted as a
membership proof). All executed by the review. Hardening, not a competing ADR:
a dedicated `guards` module (`require_tenant_match`, `require_identity`)
through which EVERY repository-returned aggregate passes — work objects (id +
tenancy on get; tenancy + parentage on every child), evidence records (id +
tenancy + linkage), organisations (identity), principals (identity + tenancy,
with outcomes normalised to one "not accessible" message so unknown, foreign
and wrong-row remain indistinguishable — no existence oracle). Defective
adapters now fail closed, and the guards are mutation-critical (ADR-018).

## ADR-016 — Command unit of work (V005 review F1, DEF-020)

**Context.** Work Object create/transition and evidence attachment persisted
domain state and then appended the mandatory audit event; a fault-injected
audit sink left the work object persisted while the caller saw an exception —
the architecture's "state changes are audit-recorded" claim was false under
audit-write failure, and V005 had fixed exactly this class for tenant
bootstrap while leaving the main command boundary non-transactional.

**Decision.** A `UnitOfWork` port owns the command transaction: every mutating
`WorkObjectRegistry` command (create, every transition, attach_evidence) runs
its domain write(s) AND audit append inside one `unit_of_work.run(...)`. The
in-memory adapter snapshots the work-object store, evidence store and audit
sink, and on ANY failure restores all three wholesale and re-raises — the same
defined, non-raising rollback model as ADR-011. A transactional persistence
adapter (INF-001) implements `run` as a database transaction. No local
try/except patching: the boundary is architectural and port-shaped.

**Consequences.** A failed audit append now rolls the whole command back:
observed failure means nothing happened. Failure-injection regressions cover
create, transition and evidence attachment.

## ADR-017 — Persistence integrity (V005 review F5/F6, DEF-024/DEF-025)

**Context.** Repositories used bare dict assignment: a colliding id silently
overwrote existing aggregates (including across tenants, and including
"immutable" evidence via key replacement), and `save()` was unconditional so
two concurrent writers both produced "version 6" with the second silently
erasing the first. No ADR declared concurrency deferred — the gap was
undecided, not decided.

**Decision.** Decided and implemented in this slice. (a) Create-vs-update
semantics: `WorkObjectRepository.create` rejects an existing id; principal,
organisation and evidence `add` reject duplicates (`ValidationError`) —
uniqueness is enforced at the storage boundary, not entrusted to ID-generator
probability. (b) Optimistic concurrency: `WorkObjectRepository.update(work_object,
expected_version=...)` replaces state only when the stored version equals the
version this command read, else raises the new published `ConcurrencyError`;
the registry's read-bump-update flow passes the read version, so a concurrent
writer surfaces as a told conflict, never a silent lost update. The PostgreSQL
adapter maps this to `UPDATE ... WHERE version = expected_version`.

**Consequences.** `ConcurrencyError` joins the published error taxonomy
(contracts 0.5.0). Stale-write and duplicate-id regressions are permanent.

## ADR-018 — Mutation-critical scope from defect history (V005 review F7)

**Context.** G07's 47/47 was true but narrow: only `state.py` and `policy.py`
were mutated, while escaped defects (DEF-009, DEF-012, DEF-016..018,
DEF-020..023) repeatedly landed on tenancy/identity/audit predicates.

**Decision.** The integrity predicates are centralised in the `guards` module
(single place, small surface, heavily reused), and G07's critical set becomes:
`workobject/state.py`, `policy.py`, `guards.py`, `audit.py`,
`organisation.py`. Remaining exclusion, justified: `workobject/service.py`'s
branching is orchestration whose integrity decisions now live in `guards`;
mutating the orchestration wholesale would multiply runtime severalfold for
predicates already covered at their definition site. The operator set remains
as ADR-004 discloses; adopting a full external mutation tool in real CI is
still declared follow-up.

**Consequences.** The mutation headline now covers the modules where defects
actually escaped; guard predicates cannot be weakened without a killed-mutant
test failing.

## ADR-018 — Amendment (V006 review F2, DEF-028)

The original exclusion claim — service.py is "orchestration whose integrity
decisions now live in guards" — was not true of the shipped code: UnitOfWork
execution, evidence-state gating, evidence existence/link verification,
completion-policy invocation, expected-version propagation and write→audit
sequencing all live in `workobject/service.py`, and DEF-027 escaped across
exactly that excluded boundary. The exclusion is withdrawn: G07's
mutation-critical set now includes `workobject/service.py` and
`adapters/memory.py` (where transactional, CAS and duplicate-id integrity
lives). No mutation-scope exclusion of integrity-bearing modules remains.

## ADR-019 — In-memory transaction serialisation (V006 review F1, DEF-027)

**Context.** The V006 `InMemoryUnitOfWork` snapshotted whole stores and
restored them wholesale on failure with no lock; the review executed the race:
A snapshots → B commits READY/v2 → A fails → A's restore resurrects the
pre-B state, erasing B's committed transaction. ADR-016's "nothing happened"
and ADR-017's "the concurrent winner survives" contradicted each other in the
shipped adapter. The provisioner used the same technique and had the same
race.

**Decision.** A `TransactionMutex` serialises in-memory transactions: the
whole snapshot → operation → commit/rollback is one critical section, so no
commit can ever fall between another transaction's snapshot and restore.
EVERY transactional adapter composed over the same stores (unit of work AND
tenant provisioner) must share one mutex instance. Same-thread re-entry —
a transaction nested inside another over the same stores — raises
`ValidationError` explicitly instead of deadlocking: nesting is not a
supported contract. A transactional persistence adapter (INF-001) gets all of
this from database transactions and discards the mutex.

**Consequences.** Breaking constructor changes (0.6.0). The deterministic
two-thread regression proves the review's exact probe now serialises: B waits,
A rolls back, B commits, B survives. Nested and cross-adapter nesting attempts
are regression-tested.

## ADR-020 — Whole-aggregate reference integrity (V006 review F3, DEF-029)

**Context.** Aggregate revalidation stopped at the shell: a hostile repository
returning the requested id and correct organisation but foreign
requester/owner/assignee references passed `get()` and disclosed all three;
evidence verification skipped `submitted_by`. The broad "defective adapters
fail closed" claim was therefore incomplete.

**Decision.** The invariant is EXTENDED rather than the claim narrowed: before
any work object is disclosed or acted on, every embedded principal reference
(requester, owner, assignee when present) must be a proven member of the
context organisation, on `get()` and on every child in `children()`; evidence
records additionally prove `submitted_by` membership in both `evidence_for()`
and completion-time verification. Failures surface as the normalised
"not accessible" isolation error (no existence oracle).

**Consequences.** The review's poisoned-aggregate and foreign-submitter probes
are permanent regressions; read paths cost up to three extra principal lookups
per aggregate, accepted for the in-memory adapter and cheap for indexed
persistence.

## ADR-021 — Machine-enforced serialisation domains (V007 review F1, DEF-030)

**Context.** ADR-019's guarantee held only when every transaction boundary
over one store set was HANDED the same `TransactionMutex` — an instruction to
the programmer, not a property of the architecture. The V007 review executed
the permitted construction (same stores, two UoWs, two mutexes) and reproduced
the V006 lost-commit race against the shipped classes: FINAL DRAFT/v1. The
root problem: repositories, mutex and UoW were independent, paired only by
caller promise. ADR-019 is not rewritten; its enforcement model is superseded
here.

**Decision.** `same transactional resources ⇒ same serialisation domain`
becomes mechanically guaranteed. Every in-memory store belongs to at most one
serialisation domain (`bind_serialisation_domain`; binding into a second
domain raises; rebinding into the same domain is idempotent). Transactional
adapters no longer accept a mutex AT ALL: `InMemoryUnitOfWork` and
`InMemoryTenantProvisioner` DERIVE the domain from their participating stores
and reject construction when participants are unbound or belong to different
domains. `InMemoryPlatformStores` is the composition root that owns all
stores under one domain and manufactures both adapters, so the unit of work
and the provisioner cannot accidentally form separate serialisation domains
over shared resources. Two independently constructed UoWs over the same
stores now share one lock by construction — injecting different ones is not
an expressible program.

**Consequences.** Breaking constructor changes (0.7.0). Three permanent
regressions per the review: (a) independently locked boundaries over the same
stores impossible/rejected (no-mutex-parameter + derived-domain identity,
unbound rejection, mixed-domain rejection, second-domain binding rejection);
(b) the failed-A/concurrent-B interleaving rerun with two independently
constructed UoWs — B waits and survives; (c) composition-root identity across
UoW and provisioner. The domain-derivation predicates are inside the
mutation-critical memory adapter (ADR-018 as amended).

## ADR-022 — Universal write-path participation (V008 review F1/F2, DEF-032/DEF-033)

**Context.** ADR-021 locked TRANSACTIONS against each other but left
non-transactional writes to the same stores outside the regime:
`OrganisationDirectory.create_principal` wrote the principal store directly,
so a concurrent provisioning failure's rollback — a whole-store restore —
erased the committed principal (executed by the review through public APIs:
`created principal survives rollback: False`). The audit sink's direct
publication path had the same shape. The invariant that matters is not
"transactions serialise" but "EVERY write to a transactional store
participates in that store's transaction regime". Additionally,
`bind_serialisation_domain` mutated bindings before validating the whole set,
leaving a partially-bound composition after a failed call.

**Decision.**
1. Port-shaped participation: `OrganisationDirectory` and `AuditLog` take the
   `UnitOfWork` port; `create_principal` and `record` run their writes inside
   it. The composition root manufactures the coordinators
   (`identity_unit_of_work`, `audit_unit_of_work`, command `unit_of_work`) —
   no adapter coupling in kernel services.
2. Ambient join with coverage (evolves the V006 "nesting rejected" contract,
   deliberately): a coordinator invoked while a transaction is already active
   on the thread JOINS it iff the enclosing transaction's registered stores
   cover the coordinator's stores — then the enclosing snapshot/rollback fully
   protects the joined writes (audit publication inside registry commands).
   Uncovered nesting is rejected; bare same-thread lock re-entry still raises.
   The domain therefore registers the store set each transaction snapshots.
3. Mechanical guard for the future: in-memory store MUTATORS (`add`, `create`,
   `update`, `append`) refuse to run unless their domain's transaction is held
   by the current thread. A future mutating service that bypasses the
   transaction boundary fails at its first test, at the adapter, instead of
   becoming the next rollback-erasure victim. (A static import-time guard was
   considered and rejected as weaker: it cannot see call-path context, while
   the runtime guard is total, mutation-tested and coverage-forced.)
4. Atomic binding: `bind_serialisation_domain` preflights the whole store set
   and only then binds, so a failed call leaves every prior binding unchanged.

**Consequences.** Breaking constructor changes (0.8.0). The review's executed
exploit is a permanent deterministic two-thread regression through the PUBLIC
paths: B's `create_principal` is serialised behind A's failing provision and
its principal SURVIVES A's rollback. TXN-002's nesting evidence is updated to
the evolved contract. All new predicates are inside mutation-tested modules.
