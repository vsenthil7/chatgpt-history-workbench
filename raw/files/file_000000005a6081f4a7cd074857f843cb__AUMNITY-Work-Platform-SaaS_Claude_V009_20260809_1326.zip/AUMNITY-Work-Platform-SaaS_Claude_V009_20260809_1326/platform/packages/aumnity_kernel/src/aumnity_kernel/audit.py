"""Append-only, tenant-scoped audit trail over event envelopes.

Trust model (ADR-010, V003 review Findings 1–2): `AuditLog` is the PUBLISHED,
UNTRUSTED-CALLER boundary of the audit trail and is therefore a protected
kernel service like `WorkObjectRegistry` — every operation takes a
TenantContext and binds it through `PrincipalDirectory`. The raw `AuditSink`
port is the infrastructure-trusted persistence contract behind it; it is not
exported from the kernel package `__all__` and must never be handed to
untrusted application code.
"""

from aumnity_contracts import EventEnvelope, TenantContext, ValidationError

from aumnity_kernel.guards import require_tenant_match
from aumnity_kernel.ports import AuditSink, PrincipalDirectory, UnitOfWork


class AuditLog:
    """Published audit API: tenant-bound writes and reads.

    Writes are append-only. A recorded event must carry the caller's own
    organisation, and its actor must be a proven member of that organisation —
    an audit actor can never be foreign, at this boundary and not merely for
    events emitted via `WorkObjectRegistry`. Reads bind the acting principal
    before any entry is returned, so a forged context (Org-A + Principal-B)
    can neither read nor write Org-A history.
    """

    def __init__(
        self, sink: AuditSink, principals: PrincipalDirectory, unit_of_work: UnitOfWork
    ) -> None:
        self._sink = sink
        self._principals = principals
        self._unit_of_work = unit_of_work

    def record(self, context: TenantContext, event: EventEnvelope) -> None:
        """Append an event after proving tenant AND attribution integrity.

        ADR-014 (V004 review Finding 3): `actor_principal_id` means THE
        AUTHENTICATED ACTING CALLER, so it must equal the bound context
        principal — a same-tenant principal cannot mint an immutable audit
        entry attributing an action to a colleague. Recording on behalf of
        another actor requires explicit delegation provenance, which is a
        declared future contract (RTM AUD-004), not an overload of this field.
        """
        self._principals.require_member(context, context.principal_id)
        require_tenant_match(event.organisation_id, context, "event")
        # ADR-014: equality with the BOUND context principal is the single actor
        # rule; it subsumes the foreign/unknown-actor cases (a foreign or
        # unknown actor can never equal a proven member of this organisation).
        if event.actor_principal_id != context.principal_id:
            raise ValidationError(
                "event actor must be the acting principal (ADR-014); "
                "delegated recording is not yet a published contract"
            )
        # ADR-022: the append participates in the transaction regime — direct
        # publication opens its own transaction; inside a registry command it
        # joins the ambient one, whose snapshot covers the sink.
        self._unit_of_work.run(lambda: self._sink.append(event))

    def entries_for(self, context: TenantContext) -> tuple[EventEnvelope, ...]:
        """Return this organisation's entries; the acting principal is bound first."""
        self._principals.require_member(context, context.principal_id)
        return tuple(
            event
            for event in self._sink.all_events()
            if event.organisation_id == context.organisation_id
        )
