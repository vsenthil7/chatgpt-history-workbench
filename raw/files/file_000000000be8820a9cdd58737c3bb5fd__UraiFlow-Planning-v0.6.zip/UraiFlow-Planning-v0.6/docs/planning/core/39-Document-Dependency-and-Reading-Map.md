# UraiFlow Document Dependency and Reading Map

## Global documents read once at project start

1. `00-README.md`
2. `01-Product-Charter.md`
3. `11-Domain-Glossary.md`
4. `02-Architecture-Overview.md`
5. `15-Relational-Data-Model.md`
6. `21-Architecture-Decision-Records.md`
7. `38-Documentation-Control-and-Stop-Rule.md`
8. `40-Decision-Authority-and-Open-Decisions.md`
9. `24-Implementation-Control-Model.md`
10. `33-Local-Session-and-Git-Workflow.md`

## Read for every sprint

- `03-Sprint-Tracker.md`
- `04-Requirement-Traceability-Matrix.md`
- corresponding file in `docs/planning/sprint-context/`
- linked module planner
- relevant acceptance rows in `26-Acceptance-Criteria-Matrix.md`
- `05-Test-Strategy.md`
- `09-Definition-of-Done.md`

## Read only when linked

| Topic | Documents |
|---|---|
| Audio | 17, 28, module plan 05 |
| Providers | 06, 32, 34, module plan 06 |
| Privacy | 29 |
| API | 27 |
| Export | 18, module plan 13 |
| Release | 20, 36, 37, module plan 14 |
| Incident | 30 |
| Environments | 31 |
| parent work-platform bridge | 19 |
| Observability | 22, module plan 15 |

## Rule

Codex must not load the entire documentation pack into every sprint context. It reads the global baseline once, then only the sprint context pack and linked documents.
