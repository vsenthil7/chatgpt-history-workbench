# UraiFlow Thin Sprint Tracker v0.2

Keep this file thin. Detailed work remains in linked planners.

## Priority definitions

- **P0:** required for safe field capture
- **P1:** required for usable speech-assisted field operation
- **P2:** required for review, consolidation and professional continuation
- **P3:** enhancement after initial field use

| Sprint | Priority | Releasable outcome | Channel/version | Status | Planner/Evidence |
|---|---:|---|---|---|---|
| MS-00 | P0 | Repository, Docker, CI, migrations, evidence folders | Server baseline | NOT STARTED | Foundation planner |
| MS-01 | P0 | Company/profile, consent, fixed questions, local DB | Capture 0.1 | NOT STARTED | Mobile + questionnaire |
| MS-02 | P0 | Full audio recording, pause/resume, crash recovery | Capture 0.1 | NOT STARTED | Audio planner |
| MS-03 | P0 | Interview list, reopen/resume and local history | Capture 0.2 | NOT STARTED | Review/history planner |
| MS-04 | P0 | Backend interview persistence, media upload, idempotent sync | Capture 0.2 | NOT STARTED | API/sync planner |
| MS-05 | P1 | Segment creation and micro-transcription with fake/local adapter | Assist 0.1 | NOT STARTED | Transcription planner |
| MS-06 | P1 | Sarvam/OpenAI/Gemini adapters and provider configuration | Assist 0.2 | NOT STARTED | Provider/admin planner |
| MS-07 | P1 | On-screen provisional transcript and correction | Assist 0.2 | NOT STARTED | Transcript lifecycle |
| MS-08 | P2 | Native aggregate, English aggregate and interview detail page | Assist 0.3 | NOT STARTED | Review/history |
| MS-09 | P2 | Markdown/JSON/CSV export and Google Sheets connector | Assist 0.3 | NOT STARTED | Export planner |
| MS-10 | P2 | DWOS follow-up Work Object bridge | Server 0.3 | NOT STARTED | Work Object bridge |
| MS-11 | P2 | Full unit/integration/contract/Flutter/Playwright evidence | Release candidate | NOT STARTED | Test strategy |
| MS-12 | P3 | Question editing/reordering and spoken question drafting | Lab 0.4 | NOT STARTED | Questionnaire/admin |
| MS-13 | P3 | Dialler adapter boundary and call workflow prototype | Lab future | DEFERRED | Future planner |

## Release rule

Every completed micro-sprint must produce:

- tagged source state
- automated test evidence
- APK/server artefact where applicable
- release notes
- RTM update
- rollback artefact
