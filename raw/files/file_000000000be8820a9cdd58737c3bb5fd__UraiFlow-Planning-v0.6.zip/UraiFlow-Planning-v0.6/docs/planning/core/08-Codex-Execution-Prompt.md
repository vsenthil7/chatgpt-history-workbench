# Codex Execution Prompt — UraiFlow v0.1

Implement UraiFlow, the reusable conversation-capture and transcription module inside AUMNITY Work Platform.

## Mandatory reading order

1. `00-README.md`
2. `01-Product-Charter.md`
3. `02-Architecture-Overview.md`
4. `04-Requirement-Traceability-Matrix.md`
5. `05-Test-Strategy.md`
6. `06-AI-Provider-Abstraction.md`
7. all module plans
8. `09-Definition-of-Done.md`

## Rules

1. Do not silently shrink or reinterpret scope.
2. Before coding, map each RTM row to files/classes/tests.
3. Update the RTM when class or test names change.
4. Implement one sprint outcome at a time.
5. Run tests after each module.
6. Preserve failed-test output.
7. Verify provider capability through official docs and contract tests.
8. No provider secret in Flutter/client code.
9. APK-A and APK-B must share one codebase.
10. Compilation is not completion.
11. Use Docker for backend/database/local services.
12. Test migrations from an empty database.
13. Create and execute Playwright tests.
14. Create and execute Flutter unit/widget/integration tests.
15. Produce an evidence index linked to the RTM.
16. Stop and report honestly when credentials, device access or infrastructure facts are missing.

## Required outputs

- source
- Docker Compose
- `.env.example`
- migrations
- seed
- APK-A
- APK-B
- admin build
- OpenAPI/API docs
- unit tests
- integration tests
- provider contract tests
- Flutter tests
- Playwright tests
- coverage
- test evidence
- APK hashes
- runbook
- backup/restore
- updated tracker and RTM
- known issues
- final report

## Final report

- attempted
- completed
- failed
- deferred
- verified assumptions
- unverified assumptions
- changed decisions
- test counts
- coverage
- security results
- artefact paths/hashes
- deployment commands
- human UAT checklist


## v0.2 mandatory controls

- Implement the relational model before business endpoints.
- Implement state machines as explicit tested policies.
- Implement interview history/detail before calling capture complete.
- Preserve micro-transcript lineage and aggregate source IDs.
- Build three release channels only from shared source.
- Verify both Capture and Assist can coexist on one Android device.
- Do not implement export directly from UI state; use canonical server DTO.
- Emit audit/domain events for all lifecycle transitions.
- Link every failure to correlation/interview/segment/job identifiers.


## v0.3 execution controls

- Use the branch, session, sprint and evidence structures exactly.
- Do not begin a sprint before entry criteria pass.
- Do not add out-of-sprint features.
- Generate OpenAPI and contract fixtures.
- Execute Android lifecycle tests.
- Maintain prompt/model lineage.
- Maintain client/server compatibility.
- Produce benchmark evidence before fixing a default local model.
- Produce field go/no-go evidence before handing an APK to the interviewer.

## v0.4 context rule

For each sprint, read the corresponding `docs/planning/sprint-context/MS-xx.md`. Do not independently choose unrelated documents or load the entire pack. Follow its links, non-scope, entry and exit conditions. Planning v0.4 is frozen; discoveries use the open-decision or change-request template.
