# UraiFlow Definition of Done v0.1

A release candidate is done only when all applicable gates pass.

## Documentation

- architecture updated
- RTM complete
- sprint tracker current
- API and runbook written
- known issues explicit

## Build

- clean clone builds
- Docker Compose starts
- migrations run from zero
- seed imports
- APK-A builds
- APK-B builds
- admin builds
- hashes recorded

## Functional

Interview creation, consent, questions, recording, recovery, offline use, sync, transcription, correction, export and admin configuration pass.

## Automated quality

- static checks pass
- units pass
- integrations pass
- provider contracts pass with fixtures
- Flutter tests pass
- Playwright passes
- coverage gates pass
- no release-blocking security issue

## Resilience

Network loss, provider outage, duplicate sync, app restart and server restart pass.

## Evidence

Reports, screenshots/videos, coverage, hashes, command log and RTM links exist.

## Human UAT

Only after automation:

- look/feel
- Tamil readability
- control size
- interview comfort
- transcript usefulness
- visible glitches

Human UAT cannot replace missing automated tests.


## v0.2 additional completion gates

- interview history and detail page exists
- full recording, segments and transcript lineage are visible
- transcript aggregate can be rebuilt from source versions
- parallel Capture and Assist APKs install together
- state-transition tests pass
- event/audit records are emitted
- export DTO and spreadsheet mapping pass golden tests
- correlation IDs are visible in diagnostics
- no previous planning package was overwritten
