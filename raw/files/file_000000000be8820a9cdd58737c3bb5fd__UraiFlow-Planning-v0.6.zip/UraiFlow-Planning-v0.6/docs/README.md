# UraiFlow Documentation Index

| Folder | Purpose |
|---|---|
| `product/` | product behaviour, transcript lifecycle, exports and integration |
| `architecture/` | architecture, data model, events, state and diagrams |
| `planning/core/` | sprint tracker, RTM and central execution planning |
| `planning/modules/` | detailed module implementation planners |
| `planning/sprint-context/` | exact context to load for each sprint |
| `help/` | user-facing screen and workflow documentation |
| `api/` | API contracts and examples |
| `testing/` | test strategy, acceptance and release gates |
| `operations/` | environments, Android lifecycle, incidents and diagnostics |
| `governance/` | decisions, risks, version history, naming and change control |
