# UraiFlow Version History and Change Rationale

## v0.1 — Initial planning baseline

### Included

- product charter
- architecture overview
- thin sprint tracker
- requirement traceability matrix
- automated test strategy
- AI-provider abstraction
- risk/assumption/decision register
- Codex execution prompt
- definition of done
- module planners
- initial questionnaire seed

### Strengths

- provider-neutral design
- PostgreSQL runtime questionnaire model
- offline-first mobile direction
- Docker-first backend
- automated-test ownership assigned to Codex
- two APK profiles from one codebase
- preservation of original audio
- basic requirement-to-test traceability

### Gaps discovered during brutal review

1. No formal business-event catalogue.
2. No controlled domain glossary.
3. No state-machine specifications.
4. No end-to-end sequence diagrams.
5. No explicit relational data model.
6. No complete interview-review/history page design.
7. No complete export and consolidation flow.
8. No bridge between UraiFlow artefacts and parent work-platform Work Objects.
9. No release/versioning model for multiple APKs installed in parallel.
10. No formal ADR set.
11. No detailed transcript lifecycle and micro-transcription accumulation model.
12. No provider/model/prompt/export version lineage.
13. Insufficient observability and trace correlation.
14. Sprint priorities did not explicitly reflect next-day operational delivery.
15. RTM did not cover all missing design artefacts.

## Why the gaps occurred

The v0.1 pack focused first on implementation control, provider abstraction and test traceability. It captured the major requirements, but it did not fully formalise the domain lifecycle and operational review workflow. This left room for AI agents to interpret terms such as interview, recording, segment, transcript, answer and export differently.

## v0.2 — Domain-complete planning baseline

### Added

- domain glossary
- business-event catalogue
- state machines
- sequence specifications
- relational data model
- interview review/history module
- transcript lifecycle model
- Google Sheets and consolidated export architecture
- parent work-platform Work Object bridge
- release and parallel-install strategy
- ADR catalogue
- observability/correlation specification
- prioritised micro-sprint plan
- expanded RTM
- revised Codex execution prompt
- revised Definition of Done

## Version-control rule

No planning version may overwrite an earlier version.

Recommended Git tags:

```text
planning-v0.1
planning-v0.2
```

Recommended commits:

```text
docs: add UraiFlow planning baseline v0.1
docs: add domain-complete UraiFlow planning baseline v0.2
```

Every future version must record:

- what changed,
- why it changed,
- what requirement or risk triggered it,
- which documents were affected,
- and whether implementation artefacts must be migrated.


## v0.3 — Implementation-control and field-readiness baseline

### Trigger

A second brutal review found that v0.2 described the product domain well but did not fully control how Codex and other AI agents must execute, version, test, release, recover and hand over work.

### Added

- brutal gap audit
- implementation control
- enhanced sprint execution
- acceptance matrix
- API contracts
- Android lifecycle
- privacy/retention
- defect/incident/rollback
- environments
- prompt/model lineage
- local session/Git workflow
- provider benchmark
- test-data governance
- compatibility matrix
- field go/no-go

### Intent

v0.3 is the first version intended to be used as the direct planning baseline for a separate build project.

## v0.4 — Context-controlled implementation freeze

### Why

v0.3 controlled implementation generally but still required Codex to navigate many documents manually. v0.4 adds exact per-sprint context packs and defines when planning must stop.

### Added

- documentation stop rule
- document dependency map
- frozen/open decision authority
- sprint-to-code-test-evidence index
- change/open-decision templates
- final freeze report
- one context pack per sprint

### Baseline

v0.4 is frozen for implementation. Further planning requires an approved change request.

## v0.5 — Name, visual architecture, help centre and monorepo baseline

### Why

The implementation baseline required a human-readable numbered architecture page, screen-by-screen help documentation, repository layout and early name-conflict correction.

### Changes

- KuralFlow renamed to UraiFlow.
- DWOS parent reference renamed to AUMNITY Work Platform.
- Numbered HTML architecture diagram added.
- Help-document website added.
- Monorepo and future split criteria added.
- Preliminary name-search record added.
