# UraiFlow

UraiFlow is the provisional product name for the interview and conversation-evidence module.

## Product hierarchy

```text
AUMNITY                         Umbrella programme/company identity
└── Parent work platform        Product name not yet approved
    └── UraiFlow                Interview/conversation module
```

AUMNITY is not part of every class, event, screen or module name. It identifies ownership and product family.

## Repository structure

```text
uraiflow/
├── apps/
│   ├── mobile_flutter/
│   └── admin_web/
├── services/
│   ├── api_fastapi/
│   ├── worker/
│   └── local_stt/
├── packages/
│   ├── domain/
│   ├── contracts/
│   ├── provider_adapters/
│   └── shared_testkit/
├── infrastructure/
├── tests/
├── docs/
│   ├── product/
│   ├── architecture/
│   ├── planning/
│   │   ├── core/
│   │   ├── modules/
│   │   └── sprint-context/
│   ├── help/
│   ├── api/
│   ├── testing/
│   ├── operations/
│   └── governance/
├── sprints/
├── sessions/
└── evidence/
```

## Start reading

1. `docs/product/01-Product-Charter.md`
2. `docs/architecture/02-Architecture-Overview.md`
3. `docs/architecture/index.html`
4. `docs/planning/core/03-Sprint-Tracker.md`
5. `docs/planning/sprint-context/<CURRENT-SPRINT>.md`
6. `docs/help/index.html`
