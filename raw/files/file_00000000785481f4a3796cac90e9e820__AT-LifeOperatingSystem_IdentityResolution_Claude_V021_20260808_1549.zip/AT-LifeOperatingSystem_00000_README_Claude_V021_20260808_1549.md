# AT-Life Operating System (AT-LOS) - V021

**Release:** `AT-LifeOperatingSystem_IdentityResolution_Claude_V021_20260808_1549`
**Prepared by:** Claude · **08-Aug-2026 15:49 BST**

```
V021 — IdentityResolution

pytest                 315 passed, 1 skipped
coverage               1060 statements, 252 branches, 100% line and branch
architecture guards    49 collected
integration (real venv) 2 collected
mutation regression    16/16 killed
RTM                    80 passing + 1 skipped + 2 not enforced = 83
modules / products     11 declared, 2 product applications
test suites            17 built, 4 declared not built (3 external)
documentation          41 pages, 2 publication profiles
packages measured      at-cli, at-identity, at-ingest-core, at-ingest-llm-export, at-ingest-whatsapp, at-store
platform version       0.12.0

Facts measured: outcomes=True coverage=True
```

## The first domain package

Five releases of infrastructure, and now `at-identity` — the first package that
reasons about people rather than files. **6 of 11 packages, none partial.**

## A person is not their name

`person_id` is **opaque, random, assigned once, derived from nothing**. V008
already rejected `sha256(name)`: names collide, names change, and a hash of a
name is reversible. `PersonRef` carries **no name at all**.

## It never guesses

There is **no fuzzy matching**. An unknown name resolves to `None` and is listed
as unresolved.

A plausible guess presented as a resolution immediately becomes an assertion
about a real person, and every downstream record inherits it. `import` now
**observes** names without deciding who they are; `link` is a separate,
deliberate, attributed act.

## Manual authority runs one way

A manual decision overrides a rule or model. A rule or model **cannot** overwrite
a manual one — it raises. A model suggestion is recorded as a model suggestion and
is never promoted by being accepted quietly. And a manual decision **must record
who made it**: an unattributed override is not an override.

## Nothing is destroyed

Every link, unlink, merge and split is an append-only decision with who, when,
how and a note. Merge redirects and split restores, so a wrong merge is
recoverable. **A merge that cannot be explained later is indistinguishable from a
mistake.**

## What this does not do — stated in the tool's own output

```
NOTE  Knowing two names are one person says NOTHING about whether
      that person's data may be processed. Consent is at-consent's
      job and it does not exist yet.
```

**`at-consent` is still blocked** on DQ-012 and DQ-013. Identity does not unblock
it.

## Try it

```bash
python -m at_cli import <export> --database at.sqlite3   # observes names
python -m at_cli identity --database at.sqlite3          # lists the unresolved
python -m at_cli link Alice --database at.sqlite3 --by "your name"
```

## One thing worth telling you

A mutant that made **every person the same person** survived 313 passing tests —
because every identity test injected a deterministic id factory, so the real
generator was never exercised. Mutation testing found it; there is now a test for
the real generator, and a rule in the Standard.

## Next

`at-evidence` can proceed. **`at-consent` needs DQ-012 and DQ-013 from you.**
No product app or HTTP layer before DQ-014.

**AT-056 remains Not started.**
