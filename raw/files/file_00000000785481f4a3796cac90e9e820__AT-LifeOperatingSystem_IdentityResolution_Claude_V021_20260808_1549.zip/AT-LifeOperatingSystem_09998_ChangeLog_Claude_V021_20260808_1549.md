# AT-LOS V021 Change Log

**Release type:** capability. ADR-021. First L2 domain package.

## Added — `at-identity`

- **`PersonRef`** with an opaque, randomly assigned `person_id`, carrying no name.
- **`Alias`** records linking a raw display name to a person, with `ResolvedBy` = RULE / MODEL / MANUAL.
- **Manual authority**: MANUAL overrides RULE and MODEL; RULE and MODEL cannot overwrite MANUAL. A manual decision must name who made it.
- **No fuzzy matching.** `observe()` records a name; `resolve()` returns `None` for anything undecided; `unresolved()` keeps ambiguity visible.
- **Append-only `IdentityDecision`** log: link, unlink, merge, split with who, when, how, note.
- **Merge and split** destroy nothing; a merge is reversible; merge cycles terminate.
- **Workspace isolation**: identity never crosses workspaces.
- **`IdentityRegistry` port** with in-memory and SQLite implementations, one contract suite over both, schema-versioned.
- **68 tests**, 100% line and branch.

## Added — `at-cli`

`identity` (report, including unresolved names and decision history) and `link`
(manual, attributed). `import` now observes participant names and reports how
many are unresolved.

## Changed

`identity.toml` gains a `derived` flag: `person_id` is **assigned**, not derived,
so it declares no components and no constructor. RTM-54 reworded accordingly.

## Registered

`TST-INT-UNIT-IDENTITY` · RTM-76 to RTM-83 · MT-007 · two new mutation cases.

## Decisions

D-079 opaque assigned person_id · D-080 no fuzzy matching · D-081 manual decisions cannot be overwritten automatically · D-082 assigned vs derived identity declarations

## Not done

`at-consent` **still blocked** on DQ-012 and DQ-013. `at-evidence`, `at-questions`, `at-commitments`, `at-timeline` not started. No product application. No network API. **AT-056 remains Not started.**
