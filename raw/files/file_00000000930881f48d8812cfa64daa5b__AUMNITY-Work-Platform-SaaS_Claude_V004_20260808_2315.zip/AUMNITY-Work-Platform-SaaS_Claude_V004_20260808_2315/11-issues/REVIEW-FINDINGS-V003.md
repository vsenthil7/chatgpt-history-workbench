# Independent Review Findings — V003 (ChatGPT, 2026-08-08 23:01) and dispositions in V004

Source: ChatGPT review of `AUMNITY-Work-Platform-SaaS_Claude_V003_20260808_2246.zip`
(sha256 `112edd6ee69625c730131773b9f1996a1689cc1848569725ab0062bdab063aea`).
Rule applied: no finding may silently disappear.

| # | Finding | Disposition | Where |
|---|---|---|---|
| 1 | Forged TenantContext could read another tenant's audit trail via published `AuditLog.entries_for` | **FIXED** | ADR-010 trust model (decided architecturally, not point-patched): `AuditLog` is a protected service binding the acting principal via `PrincipalDirectory` on every read; regression `TestAuditBoundaryRegression::test_forged_context_audit_read_rejected`; DEF-012; RTM AUD-002 |
| 2 | Published `AuditLog.record` accepted foreign-actor event injection | **FIXED** | ADR-010: `record(context, event)` binds context, requires event org == context org, proves event actor membership — a safe tenant-bound recording contract for product modules; raw `AuditSink` stays infrastructure-trusted and out of `__all__`; regressions for foreign actor, unknown actor, forged context, cross-org write, valid same-tenant write/read, no cross-tenant disclosure; DEF-012 |
| 3 | `create_organisation` claimed atomicity two independent repository writes cannot provide | **FIXED (architecture chosen, not hidden)** | ADR-011: `TenantProvisioner` port owns all-or-nothing bootstrap where transactions live (memory adapter: compensating rollback; future PostgreSQL adapter: a transaction); failure-injection regression proves no orphan organisation survives; supersedes ADR-007's mechanism statement; DEF-014; RTM TEN-002 |
| 4 | Release validation mutated manifest-controlled evidence; not idempotent (second G01 failed) | **FIXED** | ADR-012: release-mode evidence goes to an external directory; G11 step 5 runs the full ladder TWICE on the same extracted final ZIP, verifies G01 after each run and compares manifest-controlled tree digests before/after — recorded in the release-validation sidecar; DEF-015 |
| 5 | Defect evidence stale and contradicting the V003 handoff; G10 missed it | **FIXED** | Single chronological log: shipped DEF-001..008 preserved verbatim (renumbering history destroys traceability), corrective entries continue as DEF-009..015, every cross-reference updated, correction notes appended to the shipped-era documents rather than rewriting them; root cause (silent no-op string replacement across two log lineages) recorded in DEF-013; G10 gains machine checks C5 (missing gate-script references must be marked historical), C6 (defect-ID consistency and uniqueness), C7 (stale artifact-slice labels); stale "V002 slice" strings removed from `pyproject.toml` and kernel docstring |

All V003 preservation items (principal binding, payload immutability, pinned
toolchain, single G11, ARTIFACT-VERSION source, G07 taxonomy, node-level RTM
references, incoming-manifest-first ordering, deterministic double build,
exact-final-ZIP validation, product boundary rules) are intact — see the V004
regression and contract suites. OD-001 remains **OPEN**.
