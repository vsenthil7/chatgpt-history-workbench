# Requirement Traceability Matrix — authoritative (V004)

Per ADR-005 this file is the single authoritative RTM. Baseline rows DW-FR-001…015
(`10-baseline/.../18-Requirement-Traceability-Matrix.md`) are imported below; the
baseline file is preserved unedited and superseded by reference.

Status values: ENFORCED (implemented + gate/test evidence, checked by G09),
PARTIAL (subset implemented; remainder declared), DECLARED (requirement accepted,
not yet implemented), DEFERRED (deliberately out of current scope), ACTIVE (process
rule in continuous use).

| ID | Requirement | Owner | Enforcement | Evidence/Test | Status |
|---|---|---|---|---|---|
| ARC-001 | Product code remains within declared bounded ownership | Architecture | architecture guard | `scripts/gates/g06_architecture_guard.py` `evidence/g06_architecture.json` | ENFORCED |
| ARC-002 | Cross-product reuse occurs through published contracts, not copied logic | Architecture | contract tests + dependency guard | `tests/contract/test_public_contracts.py` `evidence/g06_architecture.json` | ENFORCED |
| SaaS-001 | Reusable product code is tenant-neutral | Platform/Product | tenant-leak token guard | `scripts/gates/g06_architecture_guard.py` `evidence/g06_architecture.json` | ENFORCED |
| SaaS-002 | Tenant/org context is explicit at protected boundaries | Platform/Product | isolation tests + signature contract | `tests/contract/test_public_contracts.py::test_protected_operations_take_tenant_context_first` `tests/isolation/test_tenant_isolation.py::TestPrincipalBindingRegression::test_cross_tenant_acting_principal_rejected_on_read` `tests/isolation/test_tenant_isolation.py::TestAuditBoundaryRegression::test_forged_context_audit_read_rejected` | ENFORCED |
| QA-001 | New executable packages meet line+branch coverage policy (100%) | Engineering | coverage gate | `evidence/g04_coverage.json` `evidence/g04_coverage.txt` | ENFORCED |
| QA-002 | Critical domain/policy behavior is mutation tested | Engineering | mutation gate (scoped operators, ADR-004) | `scripts/gates/g07_mutation_gate.py` `evidence/g07_mutation.json` | ENFORCED |
| QA-003 | Escaped defects receive regression tests | Engineering | review/CI process | `evidence/defect-log.md` | ACTIVE |
| DOC-001 | Version, package, test-count and ADR references are consistency checked | Governance | docs gate | `scripts/gates/g10_docs_gate.py` `evidence/g10_docs.json` | ENFORCED |
| AI-001 | Claude build → independent ChatGPT ZIP review loop is used for releases | Governance | release checklist | `evidence/gate_ladder.json` | ACTIVE |
| DW-FR-001 | Create/version Work Object | Work Object registry (kernel) | unit tests + coverage | `tests/unit/test_workobject_lifecycle.py` | ENFORCED |
| DW-FR-002 | Recursive decomposition (parent/child, same organisation) | Work Object registry (kernel) | unit + isolation tests | `tests/unit/test_workobject_lifecycle.py` `tests/isolation/test_tenant_isolation.py` | ENFORCED |
| DW-FR-003 | Assign to human/AI/team with capability matching | Assignment module (deferred D02/D03) | minimal direct assignment only | `tests/unit/test_workobject_lifecycle.py` | PARTIAL |
| DW-FR-004 | Capture capacity/availability | Capacity module (deferred D03) | none yet | none yet | DECLARED |
| DW-FR-005 | Attach immutable evidence | Evidence (kernel) | unit tests, frozen dataclass | `tests/unit/test_workobject_lifecycle.py` `tests/unit/test_kernel_primitives.py` | ENFORCED |
| DW-FR-006 | Review as Work Object | Review module (deferred D04) | lifecycle REVIEW states only | `tests/unit/test_workobject_lifecycle.py` | PARTIAL |
| DW-FR-007 | Approval policy | Governance/kernel policy | completion policy only | `tests/unit/test_kernel_primitives.py` | PARTIAL |
| DW-FR-008 | Knowledge/handover | Knowledge module (deferred D05) | none yet | none yet | DECLARED |
| DW-FR-009 | SLA/priority | SLA module (deferred) | priority field only | none yet | DECLARED |
| DW-FR-010 | UraiFlow bridge | Integration (deferred D06) | source-system contract only | `tests/unit/test_contracts.py` | PARTIAL |
| DW-FR-011 | Provider-neutral AI gateway | AI gateway (deferred) | none yet | none yet | DECLARED |
| DW-FR-012 | Audit/version history | Audit (kernel) | unit tests, append-only sink, immutable payloads (AUD-001) | `tests/unit/test_workobject_lifecycle.py` `tests/unit/test_kernel_primitives.py` | ENFORCED |
| DW-FR-013 | Organisation isolation | Identity/tenancy (kernel) | isolation suite incl. principal binding (ADR-007) | `tests/isolation/test_tenant_isolation.py::test_cross_tenant_read_denied` `tests/isolation/test_tenant_isolation.py::TestPrincipalBindingRegression::test_foreign_owner_rejected` `tests/isolation/test_tenant_isolation.py::TestPrincipalBindingRegression::test_foreign_assignee_rejected` `tests/isolation/test_tenant_isolation.py::TestPrincipalBindingRegression::test_mismatched_context_principal_rejected_on_create` `tests/isolation/test_tenant_isolation.py::TestAuditBoundaryRegression::test_no_cross_tenant_event_disclosure` | ENFORCED |
| DW-FR-014 | Service catalogue | Operations (blocked by market evidence) | none | none | DEFERRED |
| DW-FR-015 | Commercial model / pricing | Pricing (blocked by market evidence) | none | none | DEFERRED |
| TEN-001 | Tenant/principal identity binding: acting principal and every accepted principal reference proven members of the context organisation (ADR-007) | Identity/tenancy (kernel) | PrincipalDirectory binding on every protected op | `tests/isolation/test_tenant_isolation.py::TestPrincipalBindingRegression::test_unknown_acting_principal_rejected` `tests/isolation/test_tenant_isolation.py::TestPrincipalBindingRegression::test_rejected_operation_writes_no_audit_event` `tests/isolation/test_tenant_isolation.py::TestPrincipalBindingRegression::test_same_tenant_owner_and_assignee_accepted` `tests/isolation/test_tenant_isolation.py::TestAuditBoundaryRegression::test_foreign_actor_audit_write_rejected` `tests/isolation/test_tenant_isolation.py::TestAuditBoundaryRegression::test_forged_context_audit_write_rejected` | ENFORCED |
| AUD-001 | Recorded audit events are structurally immutable (ADR-008) | Audit/contracts | read-only defensive payload copy | `tests/isolation/test_tenant_isolation.py::TestAuditImmutabilityRegression::test_recorded_payload_rejects_mutation` `tests/unit/test_contracts.py::TestEventPayloadImmutability::test_payload_is_read_only` | ENFORCED |
| AUD-002 | Published audit boundary is tenant-protected: forged contexts cannot read or write; audit actor can never be foreign (ADR-010) | Audit (kernel) | PrincipalDirectory binding on AuditLog reads and writes | `tests/isolation/test_tenant_isolation.py::TestAuditBoundaryRegression::test_forged_context_audit_read_rejected` `tests/isolation/test_tenant_isolation.py::TestAuditBoundaryRegression::test_foreign_actor_audit_write_rejected` `tests/isolation/test_tenant_isolation.py::TestAuditBoundaryRegression::test_unknown_actor_audit_write_rejected` `tests/isolation/test_tenant_isolation.py::TestAuditBoundaryRegression::test_cross_organisation_event_write_rejected` `tests/isolation/test_tenant_isolation.py::TestAuditBoundaryRegression::test_valid_same_tenant_write_and_read` | ENFORCED |
| TEN-002 | Tenant bootstrap is all-or-nothing: no partial tenant survives a failed founder persistence (ADR-011) | Identity/tenancy (kernel + adapters) | TenantProvisioner port contract; failure-injection regression | `tests/isolation/test_tenant_isolation.py::TestTenantBootstrapAtomicityRegression::test_failed_founder_persistence_leaves_no_organisation` `tests/isolation/test_tenant_isolation.py::TestTenantBootstrapAtomicityRegression::test_successful_bootstrap_persists_both` | ENFORCED |
| SEC-001 | Role/permission authorization beyond tenant identity binding (binding itself: TEN-001) | Platform (declared) | identity binding done; permissions not yet | none yet | DECLARED |
| INF-001 | PostgreSQL persistence adapter honouring kernel ports | Infrastructure (declared) | ports defined | `tests/contract/test_public_contracts.py` | DECLARED |
| API-001 | HTTP edge maps TenantIsolationError to NotFound externally (ADR-006) | Platform API (declared) | contract recorded in ADR-006 | none yet | DECLARED |
