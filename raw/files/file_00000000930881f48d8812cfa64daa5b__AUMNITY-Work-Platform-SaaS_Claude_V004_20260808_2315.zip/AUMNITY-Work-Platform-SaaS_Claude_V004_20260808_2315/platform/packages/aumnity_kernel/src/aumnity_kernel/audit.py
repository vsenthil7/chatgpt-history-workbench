"""Append-only, tenant-scoped audit trail over event envelopes.

Trust model (ADR-010, V003 review Findings 1–2): `AuditLog` is the PUBLISHED,
UNTRUSTED-CALLER boundary of the audit trail and is therefore a protected
kernel service like `WorkObjectRegistry` — every operation takes a
TenantContext and binds it through `PrincipalDirectory`. The raw `AuditSink`
port is the infrastructure-trusted persistence contract behind it; it is not
exported from the kernel package `__all__` and must never be handed to
untrusted application code.
"""

from aumnity_contracts import EventEnvelope, TenantContext, TenantIsolationError

from aumnity_kernel.ports import AuditSink, PrincipalDirectory


class AuditLog:
    """Published audit API: tenant-bound writes and reads.

    Writes are append-only. A recorded event must carry the caller's own
    organisation, and its actor must be a proven member of that organisation —
    an audit actor can never be foreign, at this boundary and not merely for
    events emitted via `WorkObjectRegistry`. Reads bind the acting principal
    before any entry is returned, so a forged context (Org-A + Principal-B)
    can neither read nor write Org-A history.
    """

    def __init__(self, sink: AuditSink, principals: PrincipalDirectory) -> None:
        self._sink = sink
        self._principals = principals

    def record(self, context: TenantContext, event: EventEnvelope) -> None:
        """Append an event after proving tenant/actor integrity (ADR-010)."""
        self._principals.require_member(context, context.principal_id)
        if event.organisation_id != context.organisation_id:
            raise TenantIsolationError("event organisation does not match the acting context")
        self._principals.require_member(context, event.actor_principal_id)
        self._sink.append(event)

    def entries_for(self, context: TenantContext) -> tuple[EventEnvelope, ...]:
        """Return this organisation's entries; the acting principal is bound first."""
        self._principals.require_member(context, context.principal_id)
        return tuple(
            event
            for event in self._sink.all_events()
            if event.organisation_id == context.organisation_id
        )
