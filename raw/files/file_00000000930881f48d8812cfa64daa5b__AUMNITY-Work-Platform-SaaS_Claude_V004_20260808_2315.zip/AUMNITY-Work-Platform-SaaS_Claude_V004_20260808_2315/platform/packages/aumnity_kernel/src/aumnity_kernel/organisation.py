"""Organisation (tenant) primitive and registry."""

from dataclasses import dataclass
from datetime import datetime

from aumnity_contracts import (
    Clock,
    IdGenerator,
    NotFoundError,
    OrganisationId,
    PrincipalId,
    TenantContext,
    TenantIsolationError,
    require_identifier,
)

from aumnity_kernel.identity import Principal, PrincipalKind
from aumnity_kernel.ports import OrganisationRepository, PrincipalRepository, TenantProvisioner


@dataclass(frozen=True, slots=True)
class Organisation:
    """A tenant boundary: company, team, NGO, partner or client."""

    organisation_id: OrganisationId
    name: str
    created_at: datetime

    def __post_init__(self) -> None:
        require_identifier(self.organisation_id, "organisation_id")
        require_identifier(self.name, "name")


class OrganisationRegistry:
    """Creates organisations and their principals; validates principal membership.

    Organisation creation is a platform-operator action and is the only
    operation in the kernel that does not take a TenantContext (there is no
    tenant yet); it atomically creates the founding principal so that every
    subsequent tenant-scoped operation has a real member principal to act as
    (ADR-007 — removes the V002 unverified-bootstrap limitation). Principal
    creation is tenant-scoped and requires a bound context like any other
    protected operation.
    """

    def __init__(
        self,
        organisations: OrganisationRepository,
        principals: PrincipalRepository,
        provisioner: TenantProvisioner,
        clock: Clock,
        ids: IdGenerator,
    ) -> None:
        self._organisations = organisations
        self._principals = principals
        self._provisioner = provisioner
        self._clock = clock
        self._ids = ids

    def create_organisation(
        self, name: str, founder_display_name: str, founder_kind: PrincipalKind
    ) -> tuple[Organisation, Principal]:
        """Create a tenant and its founding principal as one all-or-nothing unit.

        Atomicity is the TenantProvisioner adapter's contract (ADR-011): the
        registry hands both aggregates to one port call and never sequences
        independent repository writes itself.
        """
        organisation = Organisation(
            organisation_id=OrganisationId(self._ids.new_id("org")),
            name=name,
            created_at=self._clock.now(),
        )
        founder = Principal(
            principal_id=PrincipalId(self._ids.new_id("prn")),
            organisation_id=organisation.organisation_id,
            kind=founder_kind,
            display_name=founder_display_name,
        )
        self._provisioner.provision(organisation, founder)
        return organisation, founder

    def get_organisation(self, organisation_id: OrganisationId) -> Organisation:
        found = self._organisations.get(organisation_id)
        if found is None:
            raise NotFoundError(f"organisation not found: {organisation_id}")
        return found

    def create_principal(
        self, context: TenantContext, kind: PrincipalKind, display_name: str
    ) -> Principal:
        self.get_organisation(context.organisation_id)
        self.require_member(context, context.principal_id)
        principal = Principal(
            principal_id=PrincipalId(self._ids.new_id("prn")),
            organisation_id=context.organisation_id,
            kind=kind,
            display_name=display_name,
        )
        self._principals.add(principal)
        return principal

    def require_member(self, context: TenantContext, principal_id: PrincipalId) -> Principal:
        """Load a principal and prove it belongs to the context organisation.

        Unknown and foreign principals both raise TenantIsolationError so that
        probing another tenant's principal space is indistinguishable from
        referencing a principal that does not exist (ADR-002/ADR-006/ADR-007).
        """
        found = self._principals.get(principal_id)
        if found is None or found.organisation_id != context.organisation_id:
            raise TenantIsolationError(f"principal not accessible: {principal_id}")
        return found
