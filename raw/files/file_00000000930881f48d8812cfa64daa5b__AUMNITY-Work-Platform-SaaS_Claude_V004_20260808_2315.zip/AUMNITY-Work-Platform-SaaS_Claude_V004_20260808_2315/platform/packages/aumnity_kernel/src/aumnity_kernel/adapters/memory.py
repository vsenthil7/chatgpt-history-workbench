"""Deterministic in-memory adapters for kernel ports (ADR-002/ADR-003).

These are the default adapters for tests and for the future modular-monolith
bootstrap until the PostgreSQL adapter (deferred, RTM INF-001) exists.
"""

from collections.abc import Iterable
from dataclasses import replace

from aumnity_contracts import EventEnvelope, EvidenceId, OrganisationId, PrincipalId, WorkObjectId

from aumnity_kernel.evidence import EvidenceRecord
from aumnity_kernel.identity import Principal
from aumnity_kernel.organisation import Organisation
from aumnity_kernel.workobject.model import WorkObject


class InMemoryOrganisationRepository:
    def __init__(self) -> None:
        self._items: dict[OrganisationId, Organisation] = {}

    def add(self, organisation: Organisation) -> None:
        self._items[organisation.organisation_id] = organisation

    def get(self, organisation_id: OrganisationId) -> Organisation | None:
        return self._items.get(organisation_id)


class InMemoryPrincipalRepository:
    def __init__(self) -> None:
        self._items: dict[PrincipalId, Principal] = {}

    def add(self, principal: Principal) -> None:
        self._items[principal.principal_id] = principal

    def get(self, principal_id: PrincipalId) -> Principal | None:
        return self._items.get(principal_id)


class InMemoryTenantProvisioner:
    """Atomic bootstrap over the two in-memory stores (ADR-011).

    As an adapter it may know the concrete repositories; on founder-persistence
    failure it compensates by removing the organisation, so no partial tenant
    survives. This mirrors what a database transaction gives the future
    PostgreSQL adapter for free.
    """

    def __init__(
        self,
        organisations: InMemoryOrganisationRepository,
        principals: InMemoryPrincipalRepository,
    ) -> None:
        self._organisations = organisations
        self._principals = principals

    def provision(self, organisation: Organisation, founder: Principal) -> None:
        self._organisations.add(organisation)
        try:
            self._principals.add(founder)
        except Exception:
            del self._organisations._items[organisation.organisation_id]
            raise


class InMemoryWorkObjectRepository:
    """Stores defensive copies so callers cannot mutate persisted state in place."""

    def __init__(self) -> None:
        self._items: dict[WorkObjectId, WorkObject] = {}

    def save(self, work_object: WorkObject) -> None:
        self._items[work_object.work_object_id] = replace(work_object)

    def get(self, work_object_id: WorkObjectId) -> WorkObject | None:
        found = self._items.get(work_object_id)
        return replace(found) if found is not None else None

    def children_of(self, parent_id: WorkObjectId) -> Iterable[WorkObject]:
        return tuple(replace(item) for item in self._items.values() if item.parent_id == parent_id)


class InMemoryEvidenceRepository:
    def __init__(self) -> None:
        self._items: dict[EvidenceId, EvidenceRecord] = {}

    def add(self, record: EvidenceRecord) -> None:
        self._items[record.evidence_id] = record

    def get(self, evidence_id: EvidenceId) -> EvidenceRecord | None:
        return self._items.get(evidence_id)


class InMemoryAuditSink:
    """Append-only event store; no update or delete API exists by design."""

    def __init__(self) -> None:
        self._events: list[EventEnvelope] = []

    def append(self, event: EventEnvelope) -> None:
        self._events.append(event)

    def all_events(self) -> Iterable[EventEnvelope]:
        return tuple(self._events)
