# First Build Backlog — status updated in Claude V002

## B001 — Baseline acceptance — DONE (V002)
- Read all starter documents and the complete preserved baseline.
- Inventory contradictions/duplicates/stale names before deleting anything.
- Record architecture decisions rather than silently normalising history.

## B002 — Declare the first implementation slice — DONE (V002, domain core)
Turn the bounded architecture into a testable domain core with explicit contracts to AUMNITY Platform and UraiFlow, beginning with capacity/availability and planning state transitions.

## B003 — Tests first as contracts — PARTIAL (V002; see handoff deviation note)
Declare RTM rows, contract tests and architecture/tenant guards before implementation. Establish red evidence, then implement to green.

## B004 — Evidence-producing CI — PARTIAL (V002: evidence scripts exist; no CI pipeline yet)
Make test counts, coverage, mutation, package inventory and docs consistency machine-readable so narrative docs do not drift.

## B005 — Review package — DONE (this ZIP)
Create the next `<Product>_Claude_VNNN_YYYYMMDD_HHMM.zip` with complete source/tests/docs/evidence for independent ChatGPT review.

## V003 correction cycle — DONE
Independent review findings F01–F12 on V002 addressed; see `00-control/RELEASE-NOTES-V003.md`, ADR-007..009 and `tests/test_review_regressions.py`. Aggregate capacity governance (CapacityLedger, DOM-006) and event persistence remain the top declared debts before persistence/API work.

## V004 hardening cycle — DONE
Independent review findings F13–F19 on V003 addressed: runtime type integrity across the domain trust boundary (ADR-010), explicit wire decoding, creation-vs-rehydration factories, strict unit-tested mutation gate and structured error identity (ADR-011). See `00-control/RELEASE-NOTES-V004.md`. Feature expansion (persistence/API/matching/CapacityLedger) remains deliberately blocked pending baseline acceptance.
