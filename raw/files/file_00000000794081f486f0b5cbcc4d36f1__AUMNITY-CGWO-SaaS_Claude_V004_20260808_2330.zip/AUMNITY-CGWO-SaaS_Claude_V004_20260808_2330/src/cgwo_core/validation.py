"""Runtime type/shape guards for domain trust boundaries (ADR-010, F13/F14).

Python type annotations are not runtime constraints; these helpers make the
domain reject malformed runtime values with controlled ``DomainError``s
instead of crashing later with incidental ``AttributeError``s. The domain is
strict: constructors require proper enum/date/int/str instances. Raw wire
values are normalised only in explicit parsers (``contracts.from_wire``).
``bool`` is rejected where ``int`` is required, and ``datetime.date``
subclasses (including ``datetime.datetime``) are accepted for dates.
"""

from __future__ import annotations

from datetime import date
from enum import Enum

from cgwo_core.errors import (
    EXPECTED_DATE,
    EXPECTED_INT,
    EXPECTED_STR,
    WRONG_RUNTIME_TYPE,
    DomainError,
    build,
)


def require_str(value: object, field: str, exc_cls: type[DomainError]) -> str:
    if not isinstance(value, str):
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=EXPECTED_STR,
            actual=type(value).__name__,
        )
    return value


def require_optional_str(value: object, field: str, exc_cls: type[DomainError]) -> str | None:
    if value is None:
        return None
    return require_str(value, field, exc_cls)


def require_int(value: object, field: str, exc_cls: type[DomainError]) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=EXPECTED_INT,
            actual=type(value).__name__,
        )
    return value


def require_date(value: object, field: str, exc_cls: type[DomainError]) -> date:
    if not isinstance(value, date):
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=EXPECTED_DATE,
            actual=type(value).__name__,
        )
    return value


def require_enum[E: Enum](
    value: object, enum_cls: type[E], field: str, exc_cls: type[DomainError]
) -> E:
    if not isinstance(value, enum_cls):
        raise build(
            exc_cls,
            WRONG_RUNTIME_TYPE,
            field=field,
            expected=enum_cls.__name__,
            actual=type(value).__name__,
        )
    return value
