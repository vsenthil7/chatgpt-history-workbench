"""Plan Item state machine — baseline state catalogue with change-reason rules.

Construction semantics (ADR-010, review finding F16): ``PlanItem.create`` is
the only way to obtain a genuinely new item (always ``INITIAL_STATE``);
``PlanItem.rehydrate`` (or equivalent direct construction) is for trusted
persistence reload and enforces the same invariants, including runtime enum
validation (F13).

Review finding F03/F04 (V002): the change reason and the transition facts are
preserved on the returned :class:`PlanItemChange` record, which is the typed,
framework-neutral domain-change representation (ADR-008). No messaging
infrastructure is implied; timestamps/actors/correlation need clock and
identity contracts and are explicitly deferred (kept deterministic).
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum

from cgwo_core.errors import (
    CHANGE_REASON_REQUIRED,
    F_CHANGE_REASON,
    F_STATE,
    F_TARGET,
    F_TENANT_ID,
    F_WORK_OBJECT_REF,
    FIELD_BLANK,
    TRANSITION_NOT_ALLOWED,
    DomainError,
    build,
)
from cgwo_core.tenancy import TenantContext, assert_same_tenant
from cgwo_core.validation import require_enum, require_optional_str, require_str


class PlanItemState(str, Enum):
    CANDIDATE = "CANDIDATE"
    WEEK_PLANNED = "WEEK_PLANNED"
    DAY_PLANNED = "DAY_PLANNED"
    STARTED = "STARTED"
    PAUSED = "PAUSED"
    BLOCKED = "BLOCKED"
    INTERRUPTED = "INTERRUPTED"
    DEFERRED = "DEFERRED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


S = PlanItemState

#: Allowed transitions. Terminal states have empty target sets.
ALLOWED_TRANSITIONS: dict[PlanItemState, frozenset[PlanItemState]] = {
    S.CANDIDATE: frozenset({S.WEEK_PLANNED, S.DEFERRED, S.CANCELLED}),
    S.WEEK_PLANNED: frozenset({S.DAY_PLANNED, S.CANDIDATE, S.DEFERRED, S.CANCELLED}),
    S.DAY_PLANNED: frozenset({S.STARTED, S.WEEK_PLANNED, S.DEFERRED, S.CANCELLED}),
    S.STARTED: frozenset({S.PAUSED, S.BLOCKED, S.INTERRUPTED, S.COMPLETED, S.CANCELLED}),
    S.PAUSED: frozenset({S.STARTED, S.INTERRUPTED, S.DEFERRED, S.CANCELLED}),
    S.BLOCKED: frozenset({S.STARTED, S.DEFERRED, S.CANCELLED}),
    S.INTERRUPTED: frozenset({S.DAY_PLANNED, S.WEEK_PLANNED, S.DEFERRED, S.CANCELLED}),
    S.DEFERRED: frozenset({S.CANDIDATE, S.WEEK_PLANNED, S.CANCELLED}),
    S.COMPLETED: frozenset(),
    S.CANCELLED: frozenset(),
}

#: Targets that always demand an explicit change reason (adaptive replanning).
REASON_REQUIRED_TARGETS: frozenset[PlanItemState] = frozenset(
    {S.BLOCKED, S.INTERRUPTED, S.DEFERRED, S.CANCELLED}
)

#: Demotions (plan rollbacks) that also demand a change reason.
REASON_REQUIRED_DEMOTIONS: frozenset[tuple[PlanItemState, PlanItemState]] = frozenset(
    {(S.WEEK_PLANNED, S.CANDIDATE), (S.DAY_PLANNED, S.WEEK_PLANNED)}
)

#: Domain event type emitted per transition (baseline event catalogue).
EVENT_BY_TRANSITION: dict[tuple[PlanItemState, PlanItemState], str] = {
    (S.CANDIDATE, S.WEEK_PLANNED): "WeeklyPlanChanged",
    (S.WEEK_PLANNED, S.CANDIDATE): "WeeklyPlanChanged",
    (S.DEFERRED, S.WEEK_PLANNED): "WeeklyPlanChanged",
    (S.INTERRUPTED, S.WEEK_PLANNED): "WeeklyPlanChanged",
    (S.WEEK_PLANNED, S.DAY_PLANNED): "DailyPlanChanged",
    (S.DAY_PLANNED, S.WEEK_PLANNED): "DailyPlanChanged",
    (S.INTERRUPTED, S.DAY_PLANNED): "DailyPlanChanged",
    (S.STARTED, S.INTERRUPTED): "WorkInterrupted",
    (S.PAUSED, S.INTERRUPTED): "WorkInterrupted",
}

DEFAULT_EVENT = "PlanItemStateChanged"


class PlanItemInvariantError(DomainError):
    """Raised when a Plan Item violates a construction invariant."""


class InvalidTransitionError(DomainError):
    """Raised for a transition not present in ALLOWED_TRANSITIONS."""


class ChangeReasonRequiredError(DomainError):
    """Raised when a replanning transition lacks an explicit change reason."""


@dataclass(frozen=True, slots=True)
class PlanItemChange:
    """Typed domain-change record for one Plan Item transition (ADR-008)."""

    event_type: str
    tenant_id: str
    work_object_ref: str
    previous_state: PlanItemState
    new_state: PlanItemState
    change_reason: str | None
    item: PlanItem


#: The state every genuinely new Plan Item starts in (ADR-010, F16).
INITIAL_STATE = PlanItemState.CANDIDATE


def _validate_plan_item(tenant_id: object, work_object_ref: object, state: object) -> None:
    checked_tenant = require_str(tenant_id, F_TENANT_ID, PlanItemInvariantError)
    if not checked_tenant.strip():
        raise build(PlanItemInvariantError, FIELD_BLANK, field=F_TENANT_ID)
    checked_ref = require_str(work_object_ref, F_WORK_OBJECT_REF, PlanItemInvariantError)
    if not checked_ref.strip():
        raise build(PlanItemInvariantError, FIELD_BLANK, field=F_WORK_OBJECT_REF)
    require_enum(state, PlanItemState, F_STATE, PlanItemInvariantError)


def transition_plan_item(
    item: PlanItem,
    target: PlanItemState,
    ctx: TenantContext,
    change_reason: str | None = None,
) -> PlanItemChange:
    """Protected operation (ADR-009): apply one guarded state transition."""
    assert_same_tenant(ctx, item.tenant_id)
    checked_target = require_enum(target, PlanItemState, F_TARGET, InvalidTransitionError)
    if checked_target not in ALLOWED_TRANSITIONS[item.state]:
        raise build(
            InvalidTransitionError,
            TRANSITION_NOT_ALLOWED,
            source=item.state.value,
            target=checked_target.value,
        )
    needs_reason = (
        checked_target in REASON_REQUIRED_TARGETS
        or (item.state, checked_target) in REASON_REQUIRED_DEMOTIONS
    )
    checked_reason = require_optional_str(change_reason, F_CHANGE_REASON, ChangeReasonRequiredError)
    normalised_reason = (checked_reason or "").strip() or None
    if needs_reason and normalised_reason is None:
        raise build(
            ChangeReasonRequiredError,
            CHANGE_REASON_REQUIRED,
            source=item.state.value,
            target=checked_target.value,
        )
    return PlanItemChange(
        event_type=EVENT_BY_TRANSITION.get((item.state, checked_target), DEFAULT_EVENT),
        tenant_id=item.tenant_id,
        work_object_ref=item.work_object_ref,
        previous_state=item.state,
        new_state=checked_target,
        change_reason=normalised_reason,
        item=replace(item, state=checked_target),
    )


@dataclass(frozen=True, slots=True)
class PlanItem:
    """Placement of a Platform Work Object into a planning horizon (ADR-006 refs)."""

    tenant_id: str
    work_object_ref: str
    state: PlanItemState = PlanItemState.CANDIDATE

    def __post_init__(self) -> None:
        _validate_plan_item(self.tenant_id, self.work_object_ref, self.state)

    @classmethod
    def create(cls, tenant_id: str, work_object_ref: str) -> PlanItem:
        """Create a genuinely NEW Plan Item in the initial state (ADR-010).

        New aggregates never start mid-lifecycle; all later states are reached
        through guarded transitions.
        """
        return cls(tenant_id=tenant_id, work_object_ref=work_object_ref, state=INITIAL_STATE)

    @classmethod
    def rehydrate(cls, tenant_id: str, work_object_ref: str, state: PlanItemState) -> PlanItem:
        """Reload a previously persisted Plan Item (trusted rehydration, ADR-010).

        Direct construction and rehydration are the same code path on purpose:
        every invariant is enforced either way. The named factory exists so
        call sites state their intent and reviews can tell creation from
        reload.
        """
        return cls(tenant_id=tenant_id, work_object_ref=work_object_ref, state=state)

    def transition(
        self,
        target: PlanItemState,
        ctx: TenantContext,
        change_reason: str | None = None,
    ) -> PlanItemChange:
        return transition_plan_item(self, target, ctx, change_reason)
