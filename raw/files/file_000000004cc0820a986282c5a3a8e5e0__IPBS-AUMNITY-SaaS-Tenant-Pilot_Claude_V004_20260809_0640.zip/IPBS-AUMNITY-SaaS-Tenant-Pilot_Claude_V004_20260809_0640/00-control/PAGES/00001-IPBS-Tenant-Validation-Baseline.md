# Page 00001 — IPBS-Tenant-Validation-Baseline

**Session:** 08/08/2026 22:16 Europe/London · **Builder:** Claude · **Output artifact:** IPBS-AUMNITY-SaaS-Tenant-Pilot_Claude_V001_20260808_2216.zip
**Input artifact:** IPBS-AUMNITY-SaaS-Tenant-Pilot_ChatGPT_V001_20260808_1318.zip (all 16 files read; workbook fully decomposed)

## Scope executed (B001 + first half of B002)
1. Read the complete starter package and the preserved workbook (sheets, headers, all 27 data-validation lists, all formulas).
2. Produced `11-analysis/BASELINE-ANALYSIS.md` — 14 findings inventoried, nothing deleted or normalised.
3. Produced the initial Requirement Promotion Register — 29 entries: 8 PLATFORM, 12 CGWO, 4 URAIFLOW, 4 TENANT-IPBS, 1 NEW-MODULE (proposed).
4. Raised ADR-0001 (accepted: register discipline), ADR-0002 and ADR-0003 (proposed: capability-module and timesheet-split ownership — awaiting human approval).
5. Added RTM rows REG-001..004; ran validators; regenerated the package manifest.

## Deliberately NOT done
No product/domain source code, no schemas, no APIs, no workbook "fixes" — per the critical rule, the pilot owns no generic product code and the workbook is input evidence only.

## Open decisions for the human
- Approve/amend ADR-0002 (capability module) and ADR-0003 (timesheet split).
- Confirm the status vocabulary and owner codes in the register.

---

# V002 session — 08/08/2026 22:37

**Input:** Claude V001 ZIP + independent ChatGPT review (22:29). **Output:** IPBS-AUMNITY-SaaS-Tenant-Pilot_Claude_V002_20260808_2237.zip
**Page status:** V001 reviewed — corrections required → V002 corrections applied. Still a **requirements-discovery baseline**, not completed tenant validation.

## Corrections applied (see BASELINE-ANALYSIS §0 correction log)
- C-01: "27 validation lists" was wrong — machine-derived count is **22** DataValidation objects; workbook facts now generated, not asserted. (The "all 27 data-validation lists" statement in the V001 section above is superseded.)
- Findings F-15..F-18 added: aggregate-capacity false positive, event-history contradiction, elapsed-vs-active duration, declared-vs-implemented consolidation.
- Lifecycle contradiction fixed: ADR-gated entries (RPR-003/006/017/050) are now PROPOSED; new CROSS-PRODUCT owner code for unresolved ownership; ADR-0003 reworked (no "three appearances earn a primitive"); ADR-0004 added; ADR-0002/0003/0004 all remain PROPOSED — none silently approved.
- Real manifest validator, much stronger register validator, deterministic manifest + packaging, honest gate table, precise baseline-provenance claim, VALIDATED evidence criteria defined.

## Open decisions for the human (unchanged + new)
ADR-0002/0003/0004 approval; reconciliation with current CGWO / Platform / UraiFlow packages per CROSS-PRODUCT-DEPENDENCIES.md (X-01…X-06).

---

# V003 session — 08/08/2026 23:09

**Input:** Claude V002 ZIP + independent ChatGPT review (22:56, which independently reproduced the V002 hash). **Output:** IPBS-AUMNITY-SaaS-Tenant-Pilot_Claude_V003_20260808_2309.zip + external release attestation.
**Page status:** "V002 reviewed — architecture sound; governance corrections required" → V003 governance/integrity corrections applied. Candidate for **Tenant Requirements Discovery Baseline ACCEPTED**; live IPBS tenant validation remains a later phase.

## Blockers fixed
- Integrity boundary (ADR-0005): post-manifest exclusion directory abolished; the manifest covers every file; evidence corruption/addition is detected (M1–M3); manifest-dependent proofs moved to an external release attestation over the exact final payload — no circularity, no stale smoke transcripts.
- Lifecycle (ADR-0006): register schema v2 separates "no product code in the pilot" (permanent) from "record which EXTERNAL product release implemented a requirement" (required later); IMPLEMENTED/VALIDATED are reachable with machine prerequisites; pilot self-reference rejected; ADR↔RPR transition matrix (PROPOSED/ACCEPTED/REJECTED/SUPERSEDED) enforced.

## Majors/mediums fixed
CROSS-PRODUCT removed from the Owner field (owner=UNRESOLVED + decision_scope + candidate_owners; product analytics exclude it) · ADR-0002 addendum 2 records the capability/profile vs workforce-response decomposition question (X-04 updated) · RPR-007 narrowed to audit mechanism-vs-policy · structured evidence scheme WB:/F:/ADR:/DEP:/FILE: with exact-object resolution · inventory counters renamed (transaction_data_rows=0; operational_rows abolished) · RPR-021 reworded to the testable limits form · negative suite extended to 16 (all DETECTED), shipped as scripts/run_negative_tests.py.

## Open decisions (unchanged)
ADR-0002/0003/0004 remain PROPOSED pending reconciliation with the owning-product packages (X-01…X-06).

---

# V004 session — 09/08/2026 06:40

**Input:** Claude V003 ZIP + attestation + independent ChatGPT review (23:21), which independently confirmed the V003 hash/determinism/negative suite AND defeated the lifecycle with three reproduced attacks. **Output:** IPBS-AUMNITY-SaaS-Tenant-Pilot_Claude_V004_20260809_0640.zip + external attestation.
**Page status:** "V003 reviewed — integrity accepted; lifecycle evidence enforcement requires correction" → V004 lifecycle/evidence corrections applied. Integrity design untouched per review instruction.

## Blockers closed (each attack now a permanent regression test)
- CLASSIFIED→VALIDATED single-cell edit → durable lifecycle event log; status is a projection of history; state-skipping impossible (R13, L1–L8; ADR-0007).
- Four empty files as VALIDATED evidence → per-class JSON schemas semantically validated (E1–E8).
- Workbook JSON as implementation "proof" → provenance tokens against the machine-readable product registry (P1–P3); registry replaces hard-coded product names (point 7).
- Positive simulation P0 proves the enforced lifecycle is genuinely reachable — enforcement without a hard-coded ceiling.

## Unchanged by instruction
Integrity/attestation design (ADR-0005), workbook facts, owner model, ADR-0002/0003/0004 all PROPOSED, X-01…X-06 OPEN.
